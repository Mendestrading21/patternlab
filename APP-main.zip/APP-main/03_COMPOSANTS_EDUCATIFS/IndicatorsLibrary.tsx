/**
 * IndicatorsLibrary — bibliothèque interactive d'indicateurs techniques.
 * Grille de cartes (mini-graphe SVG) + fiche détaillée en dialog accessible.
 * 100% informatif (voix WMB), schémas originaux via IndicatorChart.
 */
import { useEffect, useMemo, useState } from "react";
import IndicatorChart from "@/components/IndicatorChart";
import { Reveal } from "@/components/Reveal";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  INDICATORS,
  FAMILY_LABELS,
  INDICATOR_FAMILIES,
  type Indicator,
  type IndicatorFamily,
} from "@/data/indicators";
import { getIndicatorCase } from "@/data/indicatorCases";
import { ArrowRight, Gauge, Eye, BookOpen, Info, Landmark, TrendingUp, Activity, BarChart3, Waves } from "lucide-react";
import PoleCrossLinks from "@/components/PoleCrossLinks";

// Icône par famille (filigrane de bannière).
const FAMILY_ICON: Record<IndicatorFamily, typeof Gauge> = {
  tendance: TrendingUp,
  momentum: Activity,
  volatilite: Waves,
  volume: BarChart3,
};

export default function IndicatorsLibrary() {
  const [active, setActive] = useState<IndicatorFamily | "all">("all");
  const [selected, setSelected] = useState<Indicator | null>(null);

  // Ouverture directe d'un indicateur via ?fiche=<slug> (recherche globale, partage).
  useEffect(() => {
    if (typeof window === "undefined") return;
    const slug = new URLSearchParams(window.location.search).get("fiche");
    if (!slug) return;
    const found = INDICATORS.find((ind) => ind.slug === slug);
    if (found) setSelected(found);
  }, []);

  const list = useMemo(
    () => (active === "all" ? INDICATORS : INDICATORS.filter((ind) => ind.family === active)),
    [active],
  );

  return (
    <section className="py-20 lg:py-28 bg-white">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#2E7D5B]/10 rounded-full text-xs font-semibold text-[#2E7D5B] uppercase tracking-wider mb-4">
            <Gauge size={14} /> Aperçu interactif
          </span>
          <h2 className="text-3xl lg:text-4xl font-bold text-[#344453]">Les indicateurs en images</h2>
          <p className="mt-4 text-[#1E1E1E]/60 text-lg">
            Cliquez sur un indicateur pour voir son schéma, ce qu'il mesure et comment il se lit.
          </p>
        </div>

        {/* disclaimer */}
        <div className="mx-auto max-w-3xl mb-8 flex items-start gap-3 rounded-xl border border-[#C8A962]/30 bg-[#C8A962]/[0.07] px-4 py-3">
          <Info size={18} className="mt-0.5 shrink-0 text-[#8A6E18]" />
          <p className="text-sm text-[#344453]/85 leading-relaxed">
            <span className="font-semibold text-[#344453]">Contenu informatif.</span> Les schémas sont calculés
            sur une série de démonstration. Aucun indicateur n'est un signal d'achat/vente.
          </p>
        </div>

        {/* filtres */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {INDICATOR_FAMILIES.map((fam) => {
            const isActive = active === fam.id;
            return (
              <button
                key={fam.id}
                onClick={() => setActive(fam.id)}
                className={`rounded-full px-4 py-2 text-sm font-semibold transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453] ${
                  isActive ? "bg-[#344453] text-white shadow-sm" : "bg-white text-[#344453]/80 border border-[#E1E6EA] hover:border-[#344453]/30"
                }`}
                aria-pressed={isActive}
              >
                {fam.label}
              </button>
            );
          })}
        </div>

        {/* grille */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {list.map((ind, i) => {
            const fam = FAMILY_LABELS[ind.family];
            return (
              <Reveal key={ind.slug} index={i} className="h-full">
              <button
                onClick={() => setSelected(ind)}
                className="group h-full w-full text-left flex flex-col rounded-2xl border border-[#E1E6EA] bg-white overflow-hidden hover:shadow-xl hover:-translate-y-1 hover:border-[#344453]/20 transition-all duration-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453]"
                aria-label={`${ind.name} — voir la fiche`}
              >
                <div className="h-1 w-full" style={{ backgroundColor: fam.color }} />
                <div className="relative overflow-hidden bg-gradient-to-br from-[#F8F9FA] to-[#F0F2F4] px-2 pt-2">
                  <span
                    className="absolute top-3 left-3 z-10 inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-bold"
                    style={{ color: fam.color, backgroundColor: `${fam.color}18` }}
                  >
                    {fam.label}
                  </span>
                  <div className="wmb-illu-zoom">
                    <IndicatorChart spec={ind.spec} height={180} />
                  </div>
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <h3 className="text-base font-bold text-[#344453]">{ind.name}</h3>
                  <p className="mt-0.5 text-xs text-[#344453]/50">{ind.english}</p>
                  <p className="mt-2.5 text-sm text-[#344453]/75 leading-relaxed">{ind.summary}</p>
                  <div className="mt-auto pt-4 flex items-center justify-end">
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#344453] group-hover:gap-2 transition-all">
                      Détails <ArrowRight size={13} />
                    </span>
                  </div>
                </div>
              </button>
              </Reveal>
            );
          })}
        </div>

        <PoleCrossLinks current="indicateurs" />
      </div>

      {/* fiche détail */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 gap-0">
          {selected && (
            <>
              {/* ─── BANNIÈRE COLORÉE (par famille) ─── */}
              <div
                className="relative overflow-hidden px-6 pt-7 pb-9"
                style={{ background: `linear-gradient(135deg, ${FAMILY_LABELS[selected.family].color} 0%, #1a2530 96%)` }}
              >
                {(() => {
                  const FamIcon = FAMILY_ICON[selected.family] ?? Gauge;
                  return <FamIcon className="absolute -right-5 -top-5 text-white/10" size={150} strokeWidth={1.3} />;
                })()}
                <DialogHeader className="relative text-left">
                  <span className="inline-flex w-fit items-center rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-white backdrop-blur-sm">
                    {FAMILY_LABELS[selected.family].label}
                  </span>
                  <DialogTitle className="mt-3 text-2xl lg:text-[28px] font-bold text-white leading-tight">{selected.name}</DialogTitle>
                  <p className="text-sm text-white/60">{selected.english}</p>
                </DialogHeader>
              </div>

              {/* ─── GRAPHE (chevauche la bannière) ─── */}
              <div className="relative -mt-5 px-6">
                <div className="overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white shadow-md">
                  <div className="h-1 w-full" style={{ backgroundColor: FAMILY_LABELS[selected.family].color }} />
                  <div className="bg-gradient-to-br from-[#F8F9FA] to-[#F0F2F4] p-2">
                    <IndicatorChart spec={selected.spec} height={240} />
                  </div>
                  <p className="border-t border-[#F0F2F4] px-4 py-2.5 text-center text-xs italic text-[#344453]/55 leading-snug">
                    {selected.summary}
                  </p>
                </div>
              </div>

              <div className="px-6 py-5 space-y-5">

                <div className="grid sm:grid-cols-2 gap-3">
                  <div className="rounded-xl border border-[#E1E6EA] bg-white p-3.5">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#344453]">
                      <Gauge size={13} /> Ce qu'il mesure
                    </div>
                    <p className="mt-1.5 text-sm text-[#344453]/75 leading-snug">{selected.measures}</p>
                  </div>
                  <div className="rounded-xl border border-[#E1E6EA] bg-white p-3.5">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#2E7D5B]">
                      <Eye size={13} /> Comment le lire
                    </div>
                    <p className="mt-1.5 text-sm text-[#344453]/75 leading-snug">{selected.reading}</p>
                  </div>
                </div>

                <div className="rounded-xl bg-[#344453] p-5 text-white">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#C8A962] mb-3">Scénario conditionnel</h4>
                  <ul className="space-y-2.5 text-sm leading-relaxed">
                    <li>
                      <span className="font-bold text-[#C8A962]">SI</span> <span className="text-white/85">{selected.scenario.si}</span>
                    </li>
                    <li>
                      <span className="font-bold text-[#7FB89E]">ALORS</span> <span className="text-white/85">{selected.scenario.alors}</span>
                    </li>
                    <li>
                      <span className="font-bold text-[#E0A07A]">SINON</span> <span className="text-white/85">{selected.scenario.sinon}</span>
                    </li>
                  </ul>
                </div>

                {(() => {
                  const rc = getIndicatorCase(selected.slug);
                  if (!rc) return null;
                  return (
                    <div className="rounded-xl border border-[#C8A962]/35 bg-[#C8A962]/[0.08] p-4">
                      <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#8A6E18]">
                        <Landmark size={13} /> Cas réel — {rc.title}
                      </div>
                      <p className="mt-2 text-sm text-[#344453]/85 leading-relaxed">{rc.detail}</p>
                    </div>
                  );
                })()}

                <div className="flex items-start gap-2 text-xs text-[#344453]/55 leading-relaxed">
                  <BookOpen size={14} className="mt-0.5 shrink-0" />
                  Schéma calculé sur une série de démonstration, à but pédagogique. Un indicateur se lit toujours
                  dans son contexte (tendance, volume, autres signaux) — jamais seul.
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
