/**
 * GlossaryConcepts — section « Concepts illustrés » du glossaire.
 * Chaque notion clé est montrée par une illustration SVG originale + expliquée
 * (définition, pourquoi, exemple, piège). 100% informatif (voix WMB).
 */
import { useEffect, useMemo, useState } from "react";
import ConceptIllustration from "@/components/ConceptIllustration";
import { Reveal } from "@/components/Reveal";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  GLOSSARY_CONCEPTS,
  CONCEPT_CATEGORY_LABELS,
  CONCEPT_CATEGORIES,
  type GlossaryConcept,
  type ConceptCategory,
} from "@/data/glossaryConcepts";
import { getConceptExtra } from "@/data/conceptExtras";
import { ArrowRight, Sparkles, BookOpen, Target, Lightbulb, AlertTriangle, Info, LayoutGrid, Brain, Trophy, RotateCcw, XCircle, Check, Search, TrendingUp, LineChart, ShieldAlert, Compass, Landmark } from "lucide-react";
import PoleCrossLinks from "@/components/PoleCrossLinks";

// Icône par catégorie (pour la bannière de fiche).
const CATEGORY_ICON: Record<ConceptCategory, typeof Target> = {
  marche: TrendingUp,
  analyse: LineChart,
  risque: ShieldAlert,
  strategie: Compass,
};

export default function GlossaryConcepts() {
  const [mode, setMode] = useState<"fiches" | "quiz">("fiches");
  const [active, setActive] = useState<ConceptCategory | "all">("all");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<GlossaryConcept | null>(null);

  // Ouverture directe d'une fiche via ?fiche=<slug> (recherche globale, partage).
  useEffect(() => {
    if (typeof window === "undefined") return;
    const slug = new URLSearchParams(window.location.search).get("fiche");
    if (!slug) return;
    const found = GLOSSARY_CONCEPTS.find((c) => c.slug === slug);
    if (found) {
      setMode("fiches");
      setSelected(found);
    }
  }, []);

  const norm = (s: string) => s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
  const q = norm(query.trim());
  const list = useMemo(
    () =>
      GLOSSARY_CONCEPTS.filter(
        (c) =>
          (active === "all" || c.category === active) &&
          (!q || norm(c.term).includes(q) || norm(c.english).includes(q) || norm(c.summary).includes(q)),
      ),
    [active, q],
  );

  return (
    <section className="py-20 lg:py-28 bg-white">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#C8A962]/15 rounded-full text-xs font-semibold text-[#8A6E18] uppercase tracking-wider mb-4">
            <Sparkles size={14} /> Concepts illustrés
          </span>
          <h2 className="text-3xl lg:text-4xl font-bold text-[#344453]">Comprendre en un coup d'œil</h2>
          <p className="mt-4 text-[#1E1E1E]/60 text-lg">
            Les notions clés de la bourse, <span className="font-semibold text-[#344453]">montrées</span> par un schéma
            et expliquées simplement.
          </p>
        </div>

        {/* sélecteur Fiches / Quiz */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex rounded-xl border border-[#E1E6EA] bg-white p-1">
            {([
              { id: "fiches", label: "Fiches illustrées", Icon: LayoutGrid },
              { id: "quiz", label: "Quiz", Icon: Brain },
            ] as const).map((m) => {
              const isActive = mode === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => setMode(m.id)}
                  className={`inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453] ${
                    isActive ? "bg-[#344453] text-white shadow-sm" : "text-[#344453]/70 hover:text-[#344453]"
                  }`}
                  aria-pressed={isActive}
                >
                  <m.Icon size={16} /> {m.label}
                </button>
              );
            })}
          </div>
        </div>

        {mode === "fiches" && (
        <>
        {/* recherche */}
        <div className="flex justify-center mb-5">
          <div className="relative w-full max-w-sm">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#344453]/40" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Rechercher un concept…"
              aria-label="Rechercher un concept"
              className="w-full rounded-xl border border-[#E1E6EA] bg-white py-2.5 pl-9 pr-3 text-sm text-[#344453] placeholder:text-[#344453]/40 focus:border-[#344453]/40 focus:outline-none"
            />
          </div>
        </div>

        {/* filtres */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {CONCEPT_CATEGORIES.map((cat) => {
            const isActive = active === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActive(cat.id)}
                className={`rounded-full px-4 py-2 text-sm font-semibold transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453] ${
                  isActive ? "bg-[#344453] text-white shadow-sm" : "bg-white text-[#344453]/80 border border-[#E1E6EA] hover:border-[#344453]/30"
                }`}
                aria-pressed={isActive}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* grille */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {list.map((c, i) => {
            const cat = CONCEPT_CATEGORY_LABELS[c.category];
            return (
              <Reveal key={c.slug} index={i} className="h-full">
              <button
                onClick={() => setSelected(c)}
                className="group h-full w-full text-left flex flex-col rounded-2xl border border-[#E1E6EA] bg-white overflow-hidden hover:shadow-xl hover:-translate-y-1 hover:border-[#344453]/20 transition-all duration-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453]"
                aria-label={`${c.term} — voir la fiche`}
              >
                <div className="h-1 w-full" style={{ backgroundColor: cat.color }} />
                <div className="relative overflow-hidden bg-gradient-to-br from-[#F8F9FA] to-[#F0F2F4] p-4 pb-2">
                  <span
                    className="absolute top-3 left-3 z-10 inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-bold"
                    style={{ color: cat.color, backgroundColor: `${cat.color}18` }}
                  >
                    {cat.label}
                  </span>
                  <div className="wmb-illu-zoom">
                    <ConceptIllustration type={c.illu} />
                  </div>
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <h3 className="text-base font-bold text-[#344453]">{c.term}</h3>
                  <p className="mt-0.5 text-xs text-[#344453]/50">{c.english}</p>
                  <p className="mt-2.5 text-sm text-[#344453]/75 leading-relaxed">{c.summary}</p>
                  <div className="mt-3 rounded-lg bg-[#2E7D5B]/[0.06] border border-[#2E7D5B]/15 px-3 py-2">
                    <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide text-[#2E7D5B]">
                      <Lightbulb size={11} /> Concret
                    </div>
                    <p className="mt-1 text-xs text-[#344453]/70 leading-snug line-clamp-3">{c.example}</p>
                  </div>
                  <div className="mt-auto pt-4 flex items-center justify-end">
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#344453] group-hover:gap-2 transition-all">
                      La fiche <ArrowRight size={13} />
                    </span>
                  </div>
                </div>
              </button>
              </Reveal>
            );
          })}
        </div>
        {list.length === 0 && (
          <p className="text-center text-sm text-[#344453]/55 py-10">
            Aucun concept ne correspond à « {query} ».
          </p>
        )}
        </>
        )}

        {mode === "quiz" && <ConceptQuiz />}

        <PoleCrossLinks current="glossaire" />
      </div>

      {/* fiche détail */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 gap-0">
          {selected && (() => {
            const cat = CONCEPT_CATEGORY_LABELS[selected.category];
            const CatIcon = CATEGORY_ICON[selected.category] ?? Target;
            const extra = getConceptExtra(selected.slug);
            return (
            <>
              {/* ─── BANNIÈRE COLORÉE ─── */}
              <div
                className="relative overflow-hidden px-6 pt-7 pb-9"
                style={{ background: `linear-gradient(135deg, ${cat.color} 0%, #1a2530 96%)` }}
              >
                <CatIcon className="absolute -right-5 -top-5 text-white/10" size={150} strokeWidth={1.3} />
                <DialogHeader className="relative text-left">
                  <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-white backdrop-blur-sm">
                    <CatIcon size={12} /> {cat.label}
                  </span>
                  <DialogTitle className="mt-3 text-2xl lg:text-[28px] font-bold text-white leading-tight">{selected.term}</DialogTitle>
                  <p className="text-sm text-white/60">{selected.english}</p>
                </DialogHeader>
              </div>

              {/* ─── ILLUSTRATION (chevauche la bannière) ─── */}
              <div className="relative -mt-5 px-6">
                <div className="overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white shadow-md">
                  <div className="h-1 w-full" style={{ backgroundColor: cat.color }} />
                  <div className="wmb-illu-grid wmb-illu-zoom p-4">
                    <ConceptIllustration type={selected.illu} />
                  </div>
                  <p className="border-t border-[#F0F2F4] px-4 py-2.5 text-center text-xs italic text-[#344453]/55 leading-snug">
                    {selected.summary}
                  </p>
                </div>
              </div>

              {/* ─── CORPS ─── */}
              <div className="px-6 py-5 space-y-4">
                {extra?.keyFigure && (
                  <div className="flex items-stretch gap-3 rounded-xl border border-[#C8A962]/40 bg-gradient-to-br from-[#C8A962]/[0.16] to-[#C8A962]/[0.04] p-4">
                    <div className="flex w-11 shrink-0 items-center justify-center rounded-lg bg-[#C8A962]/25 text-[#8A6E18]">
                      <Trophy size={20} />
                    </div>
                    <div>
                      <div className="text-[11px] font-bold uppercase tracking-wide text-[#8A6E18]">Chiffre clé — à retenir</div>
                      <p className="mt-1 text-sm font-semibold text-[#344453] leading-snug">{extra.keyFigure}</p>
                    </div>
                  </div>
                )}

                <p className="text-sm text-[#344453]/85 leading-relaxed">{selected.definition}</p>

                {extra?.caseStudy && (
                  <div className="relative rounded-xl border border-[#344453]/15 bg-[#344453]/[0.04] p-4 pl-5">
                    <span className="absolute left-0 top-3 bottom-3 w-1 rounded-full bg-[#344453]/40" />
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#344453]">
                      <Landmark size={13} /> Cas réel
                    </div>
                    <p className="mt-1.5 text-sm text-[#344453]/80 leading-relaxed">{extra.caseStudy}</p>
                  </div>
                )}

                <div className="space-y-3">
                  {[
                    { Icon: Target, label: "Pourquoi c'est important", value: selected.why, color: "#344453" },
                    { Icon: Lightbulb, label: "Exemple", value: selected.example, color: "#2E7D5B" },
                    { Icon: AlertTriangle, label: "À ne pas confondre", value: selected.confusion, color: "#B0413E" },
                  ].map((item) => (
                    <div key={item.label} className="relative rounded-xl border border-[#E1E6EA] bg-white p-3.5 pl-5">
                      <span className="absolute left-0 top-3 bottom-3 w-1 rounded-full" style={{ backgroundColor: item.color }} />
                      <div className="flex items-center gap-1.5 text-xs font-bold" style={{ color: item.color }}>
                        <span className="inline-flex h-5 w-5 items-center justify-center rounded-md" style={{ backgroundColor: `${item.color}18` }}>
                          <item.Icon size={12} />
                        </span>
                        {item.label}
                      </div>
                      <p className="mt-1.5 text-sm text-[#344453]/75 leading-snug">{item.value}</p>
                    </div>
                  ))}
                </div>

                <div className="flex items-start gap-2 text-xs text-[#344453]/55 leading-relaxed">
                  <BookOpen size={14} className="mt-0.5 shrink-0" />
                  Schéma pédagogique simplifié. Contenu informatif — aucun conseil d'investissement.
                </div>
              </div>
            </>
            );
          })()}
        </DialogContent>
      </Dialog>
    </section>
  );
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function ConceptQuiz() {
  const makeQuestion = () => {
    const item = GLOSSARY_CONCEPTS[Math.floor(Math.random() * GLOSSARY_CONCEPTS.length)];
    const others = GLOSSARY_CONCEPTS.filter((c) => c.slug !== item.slug);
    const distractors = shuffle(others).slice(0, 3).map((c) => c.term);
    return { item, options: shuffle([item.term, ...distractors]) };
  };

  const [q, setQ] = useState(makeQuestion);
  const [picked, setPicked] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [count, setCount] = useState(0);
  const [streak, setStreak] = useState(0);
  const [best, setBest] = useState(0);

  const answer = (term: string) => {
    if (picked) return;
    setPicked(term);
    setCount((c) => c + 1);
    const correct = term === q.item.term;
    if (correct) setScore((s) => s + 1);
    const ns = correct ? streak + 1 : 0;
    setStreak(ns);
    setBest((b) => Math.max(b, ns));
  };
  const next = () => {
    setPicked(null);
    setQ(makeQuestion());
  };
  const reset = () => {
    setPicked(null);
    setScore(0);
    setCount(0);
    setStreak(0);
    setBest(0);
    setQ(makeQuestion());
  };

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-sm">
          <Trophy size={16} className="text-[#C8A962]" />
          <span className="font-bold text-[#344453]">{score}</span>
          <span className="text-[#344453]/50">/ {count}</span>
          <span className="ml-3 text-[#344453]/50">Série</span>
          <span className="font-bold text-[#2E7D5B]">{streak}</span>
          {best > 0 && <span className="text-[#344453]/40">· record {best}</span>}
        </div>
        <button onClick={reset} className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#344453]/60 hover:text-[#344453] transition-colors">
          <RotateCcw size={13} /> Réinitialiser
        </button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white">
        <div className="bg-gradient-to-br from-[#F8F9FA] to-[#F0F2F4] p-5">
          <ConceptIllustration type={q.item.illu} />
        </div>
        <div className="p-5">
          <p className="mb-3 text-sm font-semibold text-[#344453]">Quel concept est illustré ?</p>
          <div className="grid gap-2.5 sm:grid-cols-2">
            {q.options.map((opt) => {
              const isCorrect = opt === q.item.term;
              const isPicked = opt === picked;
              let cls = "border-[#E1E6EA] hover:border-[#344453]/40 text-[#344453]";
              if (picked) {
                if (isCorrect) cls = "border-[#2E7D5B] bg-[#2E7D5B]/[0.07] text-[#2E7D5B]";
                else if (isPicked) cls = "border-[#B0413E] bg-[#B0413E]/[0.07] text-[#B0413E]";
                else cls = "border-[#E1E6EA] text-[#344453]/40";
              }
              return (
                <button
                  key={opt}
                  onClick={() => answer(opt)}
                  disabled={!!picked}
                  className={`flex items-center justify-between gap-2 rounded-xl border px-4 py-3 text-left text-sm font-medium transition-all ${cls}`}
                >
                  {opt}
                  {picked && isCorrect && <Check size={16} className="shrink-0" />}
                  {picked && isPicked && !isCorrect && <XCircle size={16} className="shrink-0" />}
                </button>
              );
            })}
          </div>

          {picked && (
            <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm">
                {picked === q.item.term ? (
                  <span className="font-semibold text-[#2E7D5B]">Bravo, c'est bien {q.item.term}.</span>
                ) : (
                  <span className="font-semibold text-[#B0413E]">Raté — c'était {q.item.term}.</span>
                )}
              </p>
              <button onClick={next} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#344453] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#2a3a47] transition-colors">
                Question suivante <ArrowRight size={15} />
              </button>
            </div>
          )}
        </div>
      </div>

      <p className="mt-4 text-center text-xs text-[#344453]/45">
        Entraînement ludique · {GLOSSARY_CONCEPTS.length} concepts · 100% informatif
      </p>
    </div>
  );
}
