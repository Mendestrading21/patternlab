/**
 * WMB Automation Email Templates V10 — Dark Shell + Light Core
 * ─────────────────────────────────────────────────────────────
 * Templates for all automated email sequences:
 * - Re-engagement (inactive 30 days)
 * - Expiration reminder (J-7 before cancel)
 * - Reactivation post-cancellation (J+3, J+7)
 * - Anniversary milestones (1m, 3m, 6m, 1y)
 * - Weekly admin report
 *
 * All use buildWmbEmailHtml for consistent branding.
 */
import { sendEmail, buildWmbEmailHtml } from "../email";

const SITE_URL = "https://wallstreetmarketbrief.ch";

// V10 Light Core tokens
const TEXT_DARK = "#1A1A1A";
const TEXT_BODY = "#374151";
const TEXT_CAPTION = "#6B7280";
const CARD_BG = "#F7F8FA";
const BORDER_LIGHT = "#E5E7EB";
const GREEN = "#16A34A";
const RED = "#DC2626";

// ═══════════ 1. RE-ENGAGEMENT (30 days inactive) ═══════════

export async function sendReengagementEmail(email: string): Promise<boolean> {
  const html = buildWmbEmailHtml({
    title: "On ne vous voit plus sur WMB",
    preheader: "Vos modules de la semaine vous attendent \u2014 ne manquez pas les derni\u00e8res analyses.",
    bodyHtml: `
      <p style="color:${TEXT_DARK};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Cela fait un moment que vous ne vous &ecirc;tes pas connect&eacute; &agrave; WallStreet Market Brief.
      </p>
      <p style="color:${TEXT_BODY};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Pendant ce temps, de nouvelles &eacute;ditions ont &eacute;t&eacute; publi&eacute;es : analyses de march&eacute;, revues d'actions, tendances macro et bien plus.
      </p>
      <p style="color:${TEXT_BODY};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Votre abonnement est toujours actif &mdash; profitez-en pour rattraper ce que vous avez manqu&eacute;.
      </p>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 8px;">
        <tr>
          <td style="padding:10px 14px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};font-size:14px;color:${TEXT_DARK};">Derni&egrave;res &eacute;ditions du Brief USA</td>
        </tr>
        <tr><td style="height:6px;"></td></tr>
        <tr>
          <td style="padding:10px 14px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};font-size:14px;color:${TEXT_DARK};">Revue Monde de la semaine</td>
        </tr>
        <tr><td style="height:6px;"></td></tr>
        <tr>
          <td style="padding:10px 14px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};font-size:14px;color:${TEXT_DARK};">Module Actions US mis &agrave; jour</td>
        </tr>
        <tr><td style="height:6px;"></td></tr>
        <tr>
          <td style="padding:10px 14px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};font-size:14px;color:${TEXT_DARK};">Revue Suisse hebdomadaire</td>
        </tr>
      </table>
    `,
    ctaText: "Reprendre ma lecture",
    ctaUrl: `${SITE_URL}/dashboard`,
  });

  return sendEmail({ to: email, subject: "Vos analyses WMB vous attendent", html, tag: "relance" });
}

// ═══════════ 2. EXPIRATION REMINDER (J-7 before cancel) ═══════════

export async function sendExpirationReminderEmail(
  email: string,
  expirationDate: string
): Promise<boolean> {
  const html = buildWmbEmailHtml({
    title: "Votre abonnement WMB expire bient\u00f4t",
    preheader: `Votre acc\u00e8s premium prend fin le ${expirationDate} \u2014 voici ce que vous perdez.`,
    bodyHtml: `
      <p style="color:${TEXT_DARK};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Votre abonnement WallStreet Market Brief est configur&eacute; pour se terminer le <strong style="color:${TEXT_DARK};">${expirationDate}</strong>.
      </p>
      <p style="color:${TEXT_BODY};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Apr&egrave;s cette date, vous perdrez l'acc&egrave;s &agrave; :
      </p>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:10px 14px;background-color:rgba(220,38,38,0.04);border-radius:8px;border:1px solid rgba(220,38,38,0.12);font-size:14px;color:${RED};line-height:1.8;">
            4 modules newsletter hebdomadaires (USA, Monde, Actions, Suisse)<br>
            Acad&eacute;mie compl&egrave;te (437+ le&ccedil;ons)<br>
            Outils premium (6 outils)<br>
            Archives compl&egrave;tes
          </td>
        </tr>
      </table>
      <p style="color:${TEXT_BODY};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Si vous souhaitez conserver votre acc&egrave;s, vous pouvez r&eacute;activer votre abonnement depuis votre espace compte.
      </p>
    `,
    ctaText: "G\u00e9rer mon abonnement",
    ctaUrl: `${SITE_URL}/compte`,
  });

  return sendEmail({ to: email, subject: `Votre abonnement WMB expire le ${expirationDate}`, html, tag: "relance" });
}

// ═══════════ 3. REACTIVATION POST-CANCELLATION ═══════════

export async function sendReactivationDay3Email(email: string): Promise<boolean> {
  const html = buildWmbEmailHtml({
    title: "Ce que vous manquez depuis votre d\u00e9part",
    preheader: "Les march\u00e9s n'attendent personne \u2014 voici ce qui s'est pass\u00e9 cette semaine.",
    bodyHtml: `
      <p style="color:${TEXT_DARK};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Depuis votre d&eacute;sabonnement, de nouvelles &eacute;ditions ont &eacute;t&eacute; publi&eacute;es sur WMB.
      </p>
      <p style="color:${TEXT_BODY};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Les march&eacute;s continuent de bouger, et chaque semaine apporte son lot de donn&eacute;es, de risques et d'opportunit&eacute;s &agrave; comprendre.
      </p>
      <p style="color:${TEXT_BODY};font-size:15px;line-height:1.7;margin:0 0 18px;">
        WMB vous faisait gagner 2 &agrave; 3 heures de veille par semaine. Si vous souhaitez reprendre, votre compte est toujours actif.
      </p>
    `,
    ctaText: "Revenir sur WMB",
    ctaUrl: `${SITE_URL}/pricing`,
  });

  return sendEmail({ to: email, subject: "Ce que vous manquez sur WMB", html, tag: "relance" });
}

export async function sendReactivationDay7Email(email: string): Promise<boolean> {
  const html = buildWmbEmailHtml({
    title: "Les march\u00e9s n'attendent pas",
    preheader: "Cela fait une semaine — votre compte WMB est toujours actif.",
    bodyHtml: `
      <p style="color:${TEXT_DARK};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Cela fait une semaine que vous avez quitt&eacute; WMB. Les march&eacute;s n'ont pas ralenti.
      </p>
      <p style="color:${TEXT_BODY};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Chaque dimanche, nos abonn&eacute;s re&ccedil;oivent un deck complet : tendance, chiffres cl&eacute;s, catalyseurs et risques. Votre compte est toujours actif &mdash; il ne manque plus que vous.
      </p>
    `,
    ctaText: "Reprendre mon abonnement",
    ctaUrl: `${SITE_URL}/pricing`,
  });

  return sendEmail({ to: email, subject: "WMB vous manque ? Les march\u00e9s n'attendent pas", html, tag: "relance" });
}

// ═══════════ 4. ANNIVERSARY MILESTONES ═══════════

const ANNIVERSARY_CONTENT: Record<string, { title: string; body: string }> = {
  "1m": {
    title: "1 mois avec WMB \u2014 Merci",
    body: `
      <p style="color:${TEXT_DARK};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Cela fait d&eacute;j&agrave; 1 mois que vous &ecirc;tes membre de WallStreet Market Brief.
      </p>
      <p style="color:${TEXT_BODY};font-size:15px;line-height:1.7;margin:0 0 18px;">
        En 4 semaines, vous avez re&ccedil;u 4 &eacute;ditions compl&egrave;tes, acc&eacute;d&eacute; &agrave; l'Acad&eacute;mie et aux outils premium.
        Continuez &agrave; explorer &mdash; chaque semaine apporte de nouvelles analyses.
      </p>
    `,
  },
  "3m": {
    title: "3 mois avec WMB \u2014 Vous \u00eates un habitu\u00e9",
    body: `
      <p style="color:${TEXT_DARK};font-size:15px;line-height:1.7;margin:0 0 18px;">
        3 mois de WMB, c'est environ 12 &eacute;ditions compl&egrave;tes, des dizaines de le&ccedil;ons de l'Acad&eacute;mie, et une vision claire des march&eacute;s chaque semaine.
      </p>
      <p style="color:${TEXT_BODY};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Vous faites partie des membres les plus engag&eacute;s. Merci pour votre confiance.
      </p>
    `,
  },
  "6m": {
    title: "6 mois avec WMB \u2014 Un semestre de clart\u00e9",
    body: `
      <p style="color:${TEXT_DARK};font-size:15px;line-height:1.7;margin:0 0 18px;">
        6 mois. 24 &eacute;ditions. Des centaines de donn&eacute;es analys&eacute;es et structur&eacute;es pour vous.
      </p>
      <p style="color:${TEXT_BODY};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Si vous &ecirc;tes sur un abonnement mensuel, pensez &agrave; l'annuel : vous &eacute;conomisez l'&eacute;quivalent de 2 mois.
      </p>
    `,
  },
  "1y": {
    title: "1 an avec WMB \u2014 Anniversaire",
    body: `
      <p style="color:${TEXT_DARK};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Un an. 52 &eacute;ditions. Vous avez travers&eacute; les hauts et les bas des march&eacute;s avec WMB &agrave; vos c&ocirc;t&eacute;s.
      </p>
      <p style="color:${TEXT_BODY};font-size:15px;line-height:1.7;margin:0 0 18px;">
        Merci pour votre fid&eacute;lit&eacute;. WMB continue d'&eacute;voluer et de s'am&eacute;liorer chaque semaine &mdash; gr&acirc;ce &agrave; des membres comme vous.
      </p>
    `,
  },
};

export async function sendAnniversaryEmail(
  email: string,
  milestone: "1m" | "3m" | "6m" | "1y"
): Promise<boolean> {
  const content = ANNIVERSARY_CONTENT[milestone];
  if (!content) return false;

  const html = buildWmbEmailHtml({
    title: content.title,
    preheader: content.title,
    bodyHtml: content.body,
    ctaText: "Acc\u00e9der \u00e0 WMB",
    ctaUrl: `${SITE_URL}/dashboard`,
  });

  return sendEmail({ to: email, subject: content.title, html, tag: "relance" });
}

// ═══════════ 5. WEEKLY ADMIN REPORT ═══════════

export interface WeeklyReportData {
  newUsers: number;
  newSubscribers: number;
  totalUsers: number;
  totalPaying: number;
  totalFree: number;
  totalNewsletterSubs: number;
  cancellations: number;
  mrr: string;
  emailsSent: number;
  emailsFailed: number;
  topPages: string[];
  automationsSummary: { type: string; count: number; errors: number }[];
}

export async function sendWeeklyAdminReport(data: WeeklyReportData): Promise<boolean> {
  const automationRows = data.automationsSummary
    .map(a => `<tr>
      <td style="padding:8px 12px;border-bottom:1px solid ${BORDER_LIGHT};font-size:13px;color:${TEXT_DARK};">${a.type}</td>
      <td style="padding:8px 12px;border-bottom:1px solid ${BORDER_LIGHT};font-size:13px;color:${GREEN};text-align:center;">${a.count}</td>
      <td style="padding:8px 12px;border-bottom:1px solid ${BORDER_LIGHT};font-size:13px;color:${a.errors > 0 ? RED : TEXT_DARK};text-align:center;">${a.errors}</td>
    </tr>`)
    .join("");

  const html = buildWmbEmailHtml({
    title: "Rapport Hebdomadaire WMB",
    preheader: `Semaine : +${data.newUsers} inscrits, ${data.totalPaying} payants, MRR ${data.mrr}`,
    bodyHtml: `
      <h2 style="color:${TEXT_DARK};font-size:18px;margin:0 0 16px;font-weight:700;">KPIs de la semaine</h2>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;">
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};width:50%;vertical-align:top;">
            <div style="font-size:24px;font-weight:700;color:${TEXT_DARK};">+${data.newUsers}</div>
            <div style="font-size:12px;color:${TEXT_CAPTION};margin-top:4px;">Nouveaux inscrits</div>
          </td>
          <td style="width:8px;"></td>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};width:50%;vertical-align:top;">
            <div style="font-size:24px;font-weight:700;color:${GREEN};">${data.mrr}</div>
            <div style="font-size:12px;color:${TEXT_CAPTION};margin-top:4px;">MRR</div>
          </td>
        </tr>
      </table>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;">
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};width:33%;vertical-align:top;">
            <div style="font-size:20px;font-weight:700;color:${TEXT_DARK};">${data.totalPaying}</div>
            <div style="font-size:12px;color:${TEXT_CAPTION};margin-top:4px;">Payants</div>
          </td>
          <td style="width:6px;"></td>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};width:33%;vertical-align:top;">
            <div style="font-size:20px;font-weight:700;color:${TEXT_DARK};">${data.totalFree}</div>
            <div style="font-size:12px;color:${TEXT_CAPTION};margin-top:4px;">Gratuits</div>
          </td>
          <td style="width:6px;"></td>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};width:33%;vertical-align:top;">
            <div style="font-size:20px;font-weight:700;color:${data.cancellations > 0 ? RED : TEXT_DARK};">${data.cancellations}</div>
            <div style="font-size:12px;color:${TEXT_CAPTION};margin-top:4px;">Annulations</div>
          </td>
        </tr>
      </table>

      <h2 style="color:${TEXT_DARK};font-size:18px;margin:0 0 12px;font-weight:700;">Automatisations</h2>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;border:1px solid ${BORDER_LIGHT};border-radius:8px;overflow:hidden;">
        <tr style="background-color:${CARD_BG};">
          <td style="padding:10px 12px;font-size:12px;font-weight:700;color:${TEXT_DARK};">Type</td>
          <td style="padding:10px 12px;font-size:12px;font-weight:700;color:${TEXT_DARK};text-align:center;">Envoy&eacute;s</td>
          <td style="padding:10px 12px;font-size:12px;font-weight:700;color:${TEXT_DARK};text-align:center;">Erreurs</td>
        </tr>
        ${automationRows}
      </table>

      <h2 style="color:${TEXT_DARK};font-size:18px;margin:0 0 12px;font-weight:700;">Emails</h2>
      <p style="color:${TEXT_BODY};font-size:14px;line-height:1.6;margin:0 0 24px;">
        ${data.emailsSent} envoy&eacute;s cette semaine${data.emailsFailed > 0 ? ` (${data.emailsFailed} &eacute;checs)` : ""}.
        Total base : ${data.totalUsers} inscrits + ${data.totalNewsletterSubs} subscribers newsletter.
      </p>
    `,
    ctaText: "Ouvrir le Dashboard Admin",
    ctaUrl: `${SITE_URL}/admin`,
  });

  return sendEmail({
    to: "contact@wallstreetmarketbrief.ch",
    subject: `[WMB Admin] Rapport S${getISOWeekNumber()} \u2014 +${data.newUsers} inscrits, MRR ${data.mrr}`,
    html,
  });
}

function getISOWeekNumber(): number {
  const now = new Date();
  const d = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
}
