/**
 * Send newsletter via Brevo HTTP API (bypasses SMTP port restrictions in sandbox)
 */
import "dotenv/config";

const BREVO_API_KEY = process.env.BREVO_API_KEY;
const BREVO_API_URL = "https://api.brevo.com/v3/smtp/email";

if (!BREVO_API_KEY) {
  console.error("BREVO_API_KEY not set");
  process.exit(1);
}

import { getDb } from "./server/db.ts";
import { users } from "./drizzle/schema.ts";
import { eq, and, sql } from "drizzle-orm";

import { BRIEF_SEMAINE_11 } from "./server/routers/editions/week11.ts";
import { MONDE_SEMAINE_11 } from "./server/routers/editions/mondeWeek11.ts";
import { ACTIONS_SEMAINE_11 } from "./server/routers/editions/actionsWeek11.ts";
import { SUISSE_SEMAINE_11 } from "./server/routers/editions/suisseWeek11.ts";

import {
  buildModuleUsaEmail,
  buildModuleMondeEmail,
  buildModuleActionsEmail,
  buildModuleSuisseEmail,
} from "./server/emails/templates.ts";

const SITE_URL = "https://wmbmarket-wf8nj4yl.manus.space";

async function sendViaBrevoApi(to, subject, html) {
  const payload = {
    sender: { name: "WallStreet Market Brief", email: "contact@wallstreetmarketbrief.ch" },
    to: [{ email: to }],
    subject,
    htmlContent: html,
  };

  try {
    const res = await fetch(BREVO_API_URL, {
      method: "POST",
      headers: {
        "accept": "application/json",
        "api-key": BREVO_API_KEY,
        "content-type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    if (res.ok) {
      const data = await res.json();
      console.log(`  ✓ Sent to ${to} (messageId: ${data.messageId})`);
      return true;
    } else {
      const errText = await res.text();
      console.error(`  ✗ Failed for ${to}: ${res.status} ${errText}`);
      return false;
    }
  } catch (err) {
    console.error(`  ✗ Error for ${to}:`, err.message);
    return false;
  }
}

async function main() {
  console.log("[Newsletter API] Starting send via Brevo HTTP API...");

  const db = await getDb();
  if (!db) { console.error("DB not available"); process.exit(1); }

  const recipients = await db
    .select({ email: users.email, name: users.name })
    .from(users)
    .where(
      and(
        eq(users.subscriptionActive, 1),
        sql`${users.email} IS NOT NULL AND ${users.email} != ''`
      )
    );

  const emails = recipients.filter(r => r.email).map(r => r.email);
  console.log(`[Newsletter API] Found ${emails.length} active subscribers: ${emails.join(", ")}`);

  if (emails.length === 0) {
    console.log("[Newsletter API] No subscribers, exiting.");
    process.exit(0);
  }

  // ─── Build USA email ───
  const d = BRIEF_SEMAINE_11;
  const usaEmail = {
    subject: `📊 Module USA — S${d.weekNumber} : ${d.title.split("—")[0]?.trim()}`,
    html: buildModuleUsaEmail({
      weekNumber: d.weekNumber,
      year: d.year,
      dateRange: d.dateRange,
      title: d.title,
      subtitle: d.subtitle,
      keyPointsPast: d.executiveSummary.weekPast.slice(0, 5),
      keyPointsAhead: d.executiveSummary.weekAhead.slice(0, 5),
      lectureWMB: d.executiveSummary.lectureWMB,
      sp500: { value: d.indices[0]?.value || "", change: d.indices[0]?.change1W || "" },
      nasdaq: { value: d.indices[1]?.value || "", change: d.indices[1]?.change1W || "" },
      dowJones: { value: d.indices[2]?.value || "", change: d.indices[2]?.change1W || "" },
      vix: { value: d.vix.value, regime: d.vix.regime.split("—")[0]?.trim() || d.vix.regime },
      signal: d.indicesSignal.split("—")[0]?.trim() || "Neutre",
      risk: "Géopolitique élevé",
      highlights: [
        `S&P 500 ${d.indices[0]?.change1W} sur la semaine`,
        `VIX à ${d.vix.value} — volatilité élevée`,
        d.executiveSummary.weekPast[4] || "",
      ].filter(Boolean),
      ctaUrl: `${SITE_URL}/dashboard`,
    }),
  };

  // ─── Build Monde email ───
  const dm = MONDE_SEMAINE_11;
  const mondeEmail = {
    subject: `🌍 Module Monde — S${dm.weekNumber} : ${dm.title.split("—")[0]?.trim()}`,
    html: buildModuleMondeEmail({
      weekNumber: dm.weekNumber,
      year: dm.year,
      dateRange: dm.dateRange,
      title: dm.title,
      subtitle: dm.subtitle,
      keyPointsPast: dm.executiveSummary.weekPast.slice(0, 5),
      keyPointsAhead: dm.executiveSummary.weekAhead.slice(0, 5),
      lectureWMB: dm.executiveSummary.lectureWMB,
      europeIndices: dm.indicesEurope.slice(0, 3).map(i => ({
        name: i.name, value: i.value, change: i.change1W,
      })),
      europeLecture: dm.europeLecture || "",
      asiaIndices: dm.indicesAsia.slice(0, 3).map(i => ({
        name: i.name, value: i.value, change: i.change1W,
      })),
      asiaLecture: dm.asiaLecture || "",
      forexPairs: dm.forex.slice(0, 3).map(f => ({
        pair: f.pair, value: f.value, change: f.change1W,
      })),
      forexLecture: dm.forexLecture || "",
      commodities: dm.commodities.slice(0, 4).map(c => ({
        name: c.name, value: c.value, change: c.change1W,
      })),
      commoditiesLecture: dm.commoditiesLecture || "",
      highlights: [
        dm.executiveSummary.weekPast[0] || "",
        dm.executiveSummary.weekPast[1] || "",
        dm.executiveSummary.weekPast[2] || "",
      ].filter(Boolean),
      ctaUrl: `${SITE_URL}/dashboard`,
    }),
  };

  // ─── Build Actions email ───
  const da = ACTIONS_SEMAINE_11;
  const actionsEmail = {
    subject: `📈 Module Actions — S${da.weekNumber} : ${da.title.split("—")[0]?.trim()}`,
    html: buildModuleActionsEmail({
      weekNumber: da.weekNumber,
      year: da.year,
      dateRange: da.dateRange,
      title: da.title,
      subtitle: da.subtitle,
      topGainers: da.topGainersLarge.slice(0, 5).map(g => ({
        ticker: g.ticker, company: g.company, perf: g.perf, catalyst: g.catalyst,
      })),
      topLosers: da.topLosersLarge.slice(0, 5).map(l => ({
        ticker: l.ticker, company: l.company, perf: l.perf, catalyst: l.catalyst,
      })),
      sectorHighlight: da.sectorsLecture.substring(0, 200),
      earningsHighlights: [
        "Oracle (ORCL) lundi — cloud revenue et carnet IA",
        "Adobe (ADBE) jeudi — Firefly adoption et guidance",
        "Dollar General (DG) jeudi — consommateur bas de gamme",
      ],
      watchlistItems: da.watchlist.slice(0, 5).map(w => ({
        ticker: w.ticker, reason: w.watchFor,
      })),
      ctaUrl: `${SITE_URL}/dashboard`,
    }),
  };

  // ─── Build Suisse email ───
  const ds = SUISSE_SEMAINE_11;
  const suisseEmail = {
    subject: `🇨🇭 Module Suisse — S${ds.weekNumber} : ${ds.title.split("—")[0]?.trim()}`,
    html: buildModuleSuisseEmail({
      weekNumber: ds.weekNumber,
      year: ds.year,
      dateRange: ds.dateRange,
      title: ds.title,
      subtitle: ds.subtitle,
      keyPointsPast: ds.executiveSummary.weekPast.slice(0, 5),
      keyPointsAhead: ds.executiveSummary.weekAhead.slice(0, 5),
      lectureWMB: ds.executiveSummary.lectureWMB,
      smiValue: "13 096",
      smiChange: "-6.56%",
      chfPairs: ds.chf.slice(0, 3).map(c => ({
        pair: c.pair, value: c.value, change: c.change1W,
      })),
      chfLecture: ds.chfLecture || "",
      bnsRate: ds.bns.rate,
      bnsStance: ds.bns.stance,
      blueChips: ds.blueChips.slice(0, 4).map(b => ({
        ticker: b.ticker, value: b.value, change: b.change1W,
      })),
      blueChipsLecture: ds.blueChipsLecture || "",
      topMovers: ds.topMovers.slice(0, 3).map(m => ({
        ticker: m.ticker, change: m.change1W,
      })),
      flopMovers: ds.flopMovers.slice(0, 3).map(m => ({
        ticker: m.ticker, change: m.change1W,
      })),
      highlights: [
        ds.executiveSummary.weekPast[0] || "",
        ds.executiveSummary.weekPast[1] || "",
        ds.executiveSummary.weekPast[2] || "",
      ].filter(Boolean),
      ctaUrl: `${SITE_URL}/dashboard`,
    }),
  };

  const modules = [
    { name: "USA", ...usaEmail },
    { name: "Monde", ...mondeEmail },
    { name: "Actions", ...actionsEmail },
    { name: "Suisse", ...suisseEmail },
  ];

  let totalSent = 0;
  let totalFailed = 0;

  for (const mod of modules) {
    console.log(`\n[Newsletter API] Sending ${mod.name} to ${emails.length} subscribers...`);
    for (const email of emails) {
      const ok = await sendViaBrevoApi(email, mod.subject, mod.html);
      if (ok) totalSent++; else totalFailed++;
      await new Promise(r => setTimeout(r, 500));
    }
    console.log(`[Newsletter API] ${mod.name} done.`);
    await new Promise(r => setTimeout(r, 2000));
  }

  console.log(`\n[Newsletter API] COMPLETE: ${totalSent} sent, ${totalFailed} failed across ${modules.length} modules to ${emails.length} subscribers.`);
  process.exit(0);
}

main().catch(err => {
  console.error("[Newsletter API] Fatal error:", err);
  process.exit(1);
});
