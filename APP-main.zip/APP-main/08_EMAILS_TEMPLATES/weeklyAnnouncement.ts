/**
 * WMB Weekly Announcement Email V11 — Unified V10 Design
 * ──────────────────────────────────────────────────────────────
 * Un seul email premium qui annonce la disponibilité de l'édition hebdomadaire.
 * Utilise le même wrapper V10 (buildGenericModuleEmail) que tous les autres emails
 * pour une cohérence visuelle parfaite : Dark Shell header + Light Core body.
 *
 * Structure :
 * 1. Header V10 (logo + gold accent line)
 * 2. Title bar (WALLSTREET MARKET BRIEF — Semaine XX)
 * 3. Scoreboard (S&P 500, Nasdaq, VIX, Brent, Or, 10Y) — light stat boxes
 * 4. Ce qu'il faut retenir (3 takeaways)
 * 5. Lecture WMB (teaser)
 * 6. Modules disponibles (4 modules)
 * 7. CTA principal
 * 8. Footer V10
 */

import {
  buildGenericModuleEmail,
  buildScoreboardGrid,
  emailComponents,
} from "./templates";

const SITE_URL = "https://wallstreetmarketbrief.ch";

// Design tokens (same as templates.ts for inline use)
const GOLD = "#C8A960";
const GREEN = "#16A34A";
const RED = "#DC2626";
const TEXT_DARK = "#1A1A1A";
const TEXT_BODY = "#374151";
const TEXT_CAPTION = "#6B7280";
const CARD_BG = "#F7F8FA";
const CARD_ELEVATED = "#F0F2F5";
const BORDER_LIGHT = "#E5E7EB";

export interface WeeklyAnnouncementData {
  weekNumber: number;
  year: number;
  dateRange: string;
  headline: string;
  subheadline: string;
  sp500: { value: string; change: string; positive: boolean };
  nasdaq: { value: string; change: string; positive: boolean };
  vix: { value: string; regime: string };
  oil: { value: string; change: string; positive: boolean };
  gold: { value: string; change: string; positive: boolean };
  tenYear: { value: string; change: string };
  takeaways: string[];
  lectureTeaser: string;
  modules: { name: string; icon: string; available: boolean }[];
  ctaUrl: string;
}

export function buildWeeklyAnnouncementEmail(data: WeeklyAnnouncementData): {
  subject: string;
  html: string;
} {
  const subject = `WMB S${data.weekNumber} — ${data.headline}`;

  // ═══════════ SCOREBOARD ═══════════
  const scoreboardHtml = buildScoreboardGrid([
    { label: "S&amp;P 500", value: data.sp500.value, change: data.sp500.change },
    { label: "Nasdaq", value: data.nasdaq.value, change: data.nasdaq.change },
    { label: "VIX", value: data.vix.value, change: data.vix.regime },
  ]);

  const scoreboardHtml2 = buildScoreboardGrid([
    { label: "Brent", value: data.oil.value, change: data.oil.change },
    { label: "Or (XAU)", value: data.gold.value, change: data.gold.change },
    { label: "10Y Yield", value: data.tenYear.value, change: data.tenYear.change },
  ]);

  // ═══════════ TAKEAWAYS ═══════════
  const takeawaysHtml = data.takeaways.map((t, i) => `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 10px;">
      <tr>
        <td style="padding:16px 18px;background-color:${CARD_BG};border-radius:10px;border:1px solid ${BORDER_LIGHT};">
          <table cellpadding="0" cellspacing="0" role="presentation" width="100%">
            <tr>
              <td style="width:36px;vertical-align:top;padding-top:2px;">
                <div style="width:30px;height:30px;border-radius:50%;background-color:${GOLD};text-align:center;line-height:30px;">
                  <span style="font-size:13px;font-weight:800;color:#FFFFFF;">${i + 1}</span>
                </div>
              </td>
              <td style="padding-left:14px;font-size:14px;color:${TEXT_DARK};line-height:1.7;font-weight:400;">${t}</td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  `).join("");

  // ═══════════ LECTURE WMB ═══════════
  const lectureHtml = `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:8px 0 0;">
      <tr>
        <td style="padding:20px 22px;background-color:${CARD_BG};border-radius:10px;border-left:4px solid ${GOLD};border-top:1px solid ${BORDER_LIGHT};border-right:1px solid ${BORDER_LIGHT};border-bottom:1px solid ${BORDER_LIGHT};">
          <table cellpadding="0" cellspacing="0" role="presentation" style="margin-bottom:12px;">
            <tr>
              <td>
                <span style="font-size:10px;letter-spacing:2.5px;text-transform:uppercase;color:${GOLD};font-weight:700;">LECTURE WMB</span>
              </td>
            </tr>
          </table>
          <p style="margin:0;font-size:14px;color:${TEXT_BODY};line-height:1.75;font-style:italic;">&laquo; ${data.lectureTeaser} &raquo;</p>
          <table cellpadding="0" cellspacing="0" role="presentation" style="margin-top:14px;">
            <tr>
              <td>
                <a href="${data.ctaUrl}" style="font-size:13px;color:${GOLD};font-weight:700;text-decoration:none;">Lire l'analyse compl&egrave;te &rarr;</a>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  `;

  // ═══════════ MODULES DISPONIBLES ═══════════
  const modulesHtml = `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin-top:8px;background-color:${CARD_BG};border-radius:10px;border:1px solid ${BORDER_LIGHT};overflow:hidden;">
      ${data.modules.map((m, i) => `
      <tr>
        <td style="padding:14px 18px;${i < data.modules.length - 1 ? `border-bottom:1px solid ${BORDER_LIGHT};` : ''}">
          <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
            <tr>
              <td style="width:42px;vertical-align:middle;">
                <div style="width:38px;height:38px;border-radius:10px;background-color:${CARD_ELEVATED};text-align:center;line-height:38px;border:1px solid ${BORDER_LIGHT};">
                  <span style="font-size:17px;">${m.icon}</span>
                </div>
              </td>
              <td style="padding-left:14px;vertical-align:middle;">
                <span style="font-size:15px;font-weight:700;color:${TEXT_DARK};letter-spacing:0.2px;">${m.name}</span>
              </td>
              <td style="text-align:right;vertical-align:middle;">
                ${m.available
                  ? `<span style="display:inline-block;padding:5px 14px;background-color:rgba(22,163,74,0.08);color:${GREEN};font-size:11px;font-weight:700;border-radius:16px;letter-spacing:0.5px;border:1px solid rgba(22,163,74,0.2);">DISPONIBLE</span>`
                  : `<span style="display:inline-block;padding:5px 14px;background-color:${CARD_BG};color:${TEXT_CAPTION};font-size:11px;font-weight:600;border-radius:16px;border:1px solid ${BORDER_LIGHT};">Bient&ocirc;t</span>`
                }
              </td>
            </tr>
          </table>
        </td>
      </tr>
      `).join("")}
    </table>
  `;

  // ═══════════ ASSEMBLE BODY HTML ═══════════
  const bodyHtml = `
    <p style="margin:0 0 24px;font-size:15px;color:${TEXT_BODY};line-height:1.7;">
      Votre briefing hebdomadaire <strong style="color:${TEXT_DARK};">Semaine ${data.weekNumber}</strong> est disponible. 
      Retrouvez ci-dessous les chiffres cl&eacute;s et les points essentiels de la semaine.
    </p>

    ${emailComponents.sectionHeading("Scoreboard", GOLD)}
    ${scoreboardHtml}
    ${emailComponents.spacer(4)}
    ${scoreboardHtml2}

    ${emailComponents.spacer(8)}
    ${emailComponents.sectionHeading("Ce qu'il faut retenir", GOLD)}
    ${takeawaysHtml}

    ${emailComponents.spacer(8)}
    ${lectureHtml}

    ${emailComponents.spacer(8)}
    ${emailComponents.sectionHeading("Modules disponibles", GOLD)}
    ${modulesHtml}

    ${emailComponents.spacer(12)}
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
      <tr>
        <td style="padding:16px;background-color:${CARD_BG};border-radius:8px;border:1px dashed ${BORDER_LIGHT};text-align:center;">
          <p style="margin:0;font-size:13px;color:${TEXT_CAPTION};">
            <strong style="color:${TEXT_DARK};">&Eacute;dition compl&egrave;te</strong> : scoreboard d&eacute;taill&eacute;, FX, taux, commodities, crypto, macro, Fed, secteurs, sc&eacute;narios et risques.
          </p>
        </td>
      </tr>
    </table>
  `;

  // ═══════════ BUILD FINAL EMAIL ═══════════
  const html = buildGenericModuleEmail({
    moduleType: "general",
    title: data.headline,
    subtitle: data.subheadline,
    weekNumber: data.weekNumber,
    year: data.year,
    dateRange: data.dateRange,
    bodyHtml: bodyHtml,
    ctaText: `Lire mon briefing S${data.weekNumber}`,
    ctaUrl: data.ctaUrl,
    footerText: "Vous recevez cet email car vous \u00eates inscrit(e) \u00e0 WallStreet Market Brief.",
    skipHeader: false,
    skipTitleBar: false,
  });

  return { subject, html };
}
