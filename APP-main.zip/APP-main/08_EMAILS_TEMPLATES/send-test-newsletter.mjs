/**
 * WMB Test Newsletter Send — Week 10 / 2026
 * Uses Brevo HTTP API (not SMTP) for reliable sending from sandbox
 */

const BREVO_API_KEY = process.env.BREVO_API_KEY || "REDACTED_BREVO_API_KEY";

const TEST_RECIPIENTS = [
  "elio_mendes@hotmail.com",
  "e.mendestrading@gmail.com",
];

const LOGO_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/bFoTCAIoZQkMLPib.png";
const SITE_URL = "https://wallstreetmarketbrief.ch";

// ═══════════ BREVO HTTP API SENDER ═══════════

async function sendEmailViaBrevo(to, subject, html) {
  try {
    const response = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: {
        "accept": "application/json",
        "api-key": BREVO_API_KEY,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        sender: { name: "WallStreet Market Brief", email: "contact@wallstreetmarketbrief.ch" },
        to: [{ email: to }],
        subject: subject,
        htmlContent: html,
        replyTo: { email: "contact@wallstreetmarketbrief.ch" },
      }),
    });
    
    const data = await response.json();
    if (response.ok) {
      console.log(`  [OK] ${to} — messageId: ${data.messageId}`);
      return true;
    } else {
      console.error(`  [FAIL] ${to} — ${JSON.stringify(data)}`);
      return false;
    }
  } catch (error) {
    console.error(`  [ERROR] ${to}:`, error.message);
    return false;
  }
}

// ═══════════ SHARED EMAIL COMPONENTS ═══════════

const FONT_STACK = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif";

function sharedStyles(accentColor) {
  return `
    body { margin: 0; padding: 0; background-color: #0A0C12; font-family: ${FONT_STACK}; -webkit-font-smoothing: antialiased; }
    a { color: ${accentColor}; text-decoration: none; }
    a:hover { text-decoration: underline; }
    img { border: 0; display: block; outline: none; }
    table { border-collapse: collapse; }
    p { margin: 0 0 16px; }
    @media only screen and (max-width: 620px) {
      .email-container { width: 100% !important; }
      .email-padding { padding-left: 20px !important; padding-right: 20px !important; }
      .mobile-full { width: 100% !important; display: block !important; }
      .stat-grid td { display: block !important; width: 100% !important; padding: 8px 0 !important; }
      .hero-title { font-size: 24px !important; line-height: 1.25 !important; }
    }
  `;
}

function buildHeader() {
  return `
    <tr>
      <td style="background-color:#0C1018;padding:24px 40px 20px;" class="email-padding">
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
          <tr><td align="center">
            <img src="${LOGO_URL}" alt="WMB" width="40" height="40" style="display:block;border-radius:10px;margin-bottom:10px;" />
          </td></tr>
          <tr><td align="center">
            <span style="color:#FFFFFF;font-size:16px;font-weight:700;letter-spacing:1.5px;">WALLSTREET MARKET BRIEF</span>
          </td></tr>
          <tr><td align="center" style="padding-top:4px;">
            <span style="color:rgba(255,255,255,0.2);font-size:9px;text-transform:uppercase;letter-spacing:3px;">Newsletter March\u00e9s Financiers</span>
          </td></tr>
        </table>
      </td>
    </tr>
  `;
}

function buildAccentLine(color = "#D4A853") {
  return `
    <tr>
      <td style="background-color:#0C1018;padding:0 40px;" class="email-padding">
        <div style="height:2px;background:linear-gradient(90deg,transparent,${color},transparent);"></div>
      </td>
    </tr>
  `;
}

function buildModuleTitleBar({ moduleLabel, title, subtitle, accentColor, weekInfo, emoji }) {
  return `
    <tr>
      <td style="background:linear-gradient(135deg,${accentColor},${accentColor}DD);padding:24px 40px;" class="email-padding">
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
          ${weekInfo ? `<tr><td>
            <span style="color:rgba(255,255,255,0.5);font-size:10px;text-transform:uppercase;letter-spacing:2px;font-weight:600;">${moduleLabel} \u2014 ${weekInfo}</span>
          </td></tr>` : ""}
          <tr><td style="padding-top:8px;">
            <h1 class="hero-title" style="margin:0;color:#FFFFFF;font-size:22px;font-weight:700;line-height:1.3;">${emoji ? emoji + " " : ""}${title}</h1>
          </td></tr>
          ${subtitle ? `<tr><td style="padding-top:6px;">
            <p style="margin:0;color:rgba(255,255,255,0.7);font-size:13px;line-height:1.5;">${subtitle}</p>
          </td></tr>` : ""}
        </table>
      </td>
    </tr>
  `;
}

function buildStatBox({ label, value, change, changePositive }) {
  const changeColor = changePositive ? "#2E7D5B" : "#B0413E";
  return `
    <td style="padding:12px;background-color:#F8F9FA;border-radius:8px;text-align:center;border:1px solid #E8EAED;">
      <p style="margin:0;font-size:10px;color:rgba(30,30,30,0.4);text-transform:uppercase;letter-spacing:1px;font-weight:600;">${label}</p>
      <p style="margin:4px 0 0;font-size:18px;font-weight:700;color:#344453;">${value}</p>
      ${change ? `<p style="margin:2px 0 0;font-size:12px;font-weight:600;color:${changeColor};">${change}</p>` : ""}
    </td>
  `;
}

function buildSectionHeading(text, accentColor) {
  return `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:24px 0 12px;">
      <tr>
        <td>
          <div style="display:inline-block;width:3px;height:16px;background-color:${accentColor};border-radius:2px;vertical-align:middle;margin-right:10px;"></div>
          <span style="font-size:14px;font-weight:700;color:#344453;text-transform:uppercase;letter-spacing:0.5px;vertical-align:middle;">${text}</span>
        </td>
      </tr>
    </table>
  `;
}

function buildBulletItem(text, accentColor) {
  return `
    <tr>
      <td style="padding:6px 0 6px 16px;">
        <table cellpadding="0" cellspacing="0" role="presentation"><tr>
          <td style="width:8px;vertical-align:top;padding-top:6px;"><div style="width:6px;height:6px;background-color:${accentColor};border-radius:50%;"></div></td>
          <td style="padding-left:10px;"><span style="font-size:13px;color:#1E1E1E;line-height:1.6;">${text}</span></td>
        </tr></table>
      </td>
    </tr>
  `;
}

function buildInfoCard({ label, note, accentColor }) {
  return `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:8px 0 16px;">
      <tr>
        <td style="padding:14px 16px;background-color:#F8F9FA;border-radius:8px;border-left:3px solid ${accentColor};">
          ${label ? `<p style="margin:0 0 4px;font-size:10px;color:rgba(30,30,30,0.4);text-transform:uppercase;letter-spacing:1px;font-weight:600;">${label}</p>` : ""}
          <p style="margin:0;font-size:13px;color:#344453;line-height:1.7;font-style:italic;">${note}</p>
        </td>
      </tr>
    </table>
  `;
}

function buildCta(text, url, bgColor) {
  return `
    <tr>
      <td style="padding:8px 40px 28px;background-color:#FFFFFF;text-align:center;" class="email-padding">
        <table cellpadding="0" cellspacing="0" role="presentation" style="margin:0 auto;">
          <tr>
            <td style="background-color:${bgColor};border-radius:10px;padding:14px 40px;">
              <a href="${url}" style="color:#FFFFFF;text-decoration:none;font-size:15px;font-weight:700;display:inline-block;letter-spacing:0.3px;">${text}</a>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  `;
}

function buildFooter(footerText) {
  return `
    <tr>
      <td style="padding:0 40px;background-color:#FFFFFF;" class="email-padding">
        <div style="height:1px;background-color:#E8EAED;"></div>
      </td>
    </tr>
    <tr>
      <td style="padding:20px 40px 16px;background-color:#FFFFFF;" class="email-padding">
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
          <tr><td align="center">
            <p style="margin:0 0 6px;color:rgba(30,30,30,0.35);font-size:11px;line-height:1.6;">
              ${footerText || "Vous recevez cet email car vous \u00eates abonn\u00e9(e) \u00e0 WallStreet Market Brief."}
            </p>
            <p style="margin:0;color:rgba(30,30,30,0.25);font-size:10px;line-height:1.5;">
              <a href="${SITE_URL}/compte" style="color:rgba(30,30,30,0.35);text-decoration:underline;">G\u00e9rer mes pr\u00e9f\u00e9rences</a>
              &nbsp;\u00b7&nbsp;
              <a href="${SITE_URL}/mentions-legales" style="color:rgba(30,30,30,0.35);text-decoration:underline;">Mentions l\u00e9gales</a>
            </p>
          </td></tr>
        </table>
      </td>
    </tr>
    <tr>
      <td style="background-color:#0C1018;padding:16px 40px;" class="email-padding">
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
          <tr><td align="center">
            <p style="margin:0;color:rgba(255,255,255,0.15);font-size:9px;line-height:1.6;letter-spacing:0.5px;">
              WallStreet Market Brief &mdash; Newsletter March\u00e9s Financiers<br>
              Ce contenu est purement informatif et ne constitue pas un conseil en investissement.<br>
              &copy; 2026 WallStreet Market Brief. Tous droits r\u00e9serv\u00e9s.
            </p>
          </td></tr>
        </table>
      </td>
    </tr>
  `;
}

function wrapEmail({ preheader, accentColor, innerHtml }) {
  return `<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="x-apple-disable-message-reformatting">
  <meta name="format-detection" content="telephone=no,address=no,email=no,date=no,url=no">
  <title>WallStreet Market Brief</title>
  ${preheader ? `<span style="display:none;font-size:1px;color:#0A0C12;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;">${preheader}${"&zwnj;&nbsp;".repeat(30)}</span>` : ""}
  <style>${sharedStyles(accentColor)}</style>
</head>
<body style="margin:0;padding:0;background-color:#0A0C12;">
  <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:#0A0C12;padding:24px 12px;">
    <tr>
      <td align="center">
        <table class="email-container" width="600" cellpadding="0" cellspacing="0" role="presentation" style="max-width:600px;width:100%;background-color:#FFFFFF;border-radius:12px;overflow:hidden;box-shadow:0 4px 32px rgba(0,0,0,0.4);">
          ${innerHtml}
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

// ═══════════ MODULE USA — S10 2026 ═══════════

function buildModuleUsaS10() {
  const mod = { accent: "#2E7D5B", label: "MODULE MARCH\u00c9 US", emoji: "\ud83d\udcca" };
  
  const innerHtml = `
    ${buildHeader()}
    ${buildAccentLine(mod.accent)}
    ${buildModuleTitleBar({
      moduleLabel: mod.label,
      title: "Tensions G\u00e9opolitiques & Rebond Technique",
      subtitle: "Le march\u00e9 dig\u00e8re le choc iranien \u2014 VIX en zone d'alerte, rebond sur signaux diplomatiques",
      accentColor: mod.accent,
      weekInfo: "Semaine 10",
      emoji: mod.emoji,
    })}

    <tr>
      <td style="padding:28px 40px;background-color:#FFFFFF;color:#1E1E1E;font-size:14px;line-height:1.7;" class="email-padding">

        <p style="margin:0 0 20px;font-size:12px;color:rgba(30,30,30,0.4);text-transform:uppercase;letter-spacing:1px;font-weight:600;">
          \ud83d\udcca 3 \u2013 5 mars 2026 \u2014 2026
        </p>

        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;" class="stat-grid">
          <tr>
            ${buildStatBox({ label: "S&P 500", value: "6,869", change: "+0.8%", changePositive: true })}
            <td style="width:8px;"></td>
            ${buildStatBox({ label: "Nasdaq", value: "22,807", change: "+1.3%", changePositive: true })}
            <td style="width:8px;"></td>
            ${buildStatBox({ label: "Dow Jones", value: "48,739", change: "+0.5%", changePositive: true })}
          </tr>
        </table>

        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;">
          <tr>
            <td style="padding:12px 16px;background-color:#F8F9FA;border-radius:8px;border:1px solid #E8EAED;">
              <span style="font-size:10px;color:rgba(30,30,30,0.4);text-transform:uppercase;letter-spacing:1px;font-weight:600;">VIX</span>
              <span style="font-size:16px;font-weight:700;color:#344453;margin-left:8px;">22.8</span>
              <span style="font-size:12px;color:#B0413E;margin-left:8px;">Zone d'alerte (+60% YTD)</span>
            </td>
          </tr>
        </table>

        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;">
          <tr>
            <td style="padding-right:6px;">
              <span style="display:inline-block;padding:6px 14px;background-color:#D4A85320;color:#B8860B;font-size:12px;font-weight:700;border-radius:6px;">Signal: Prudent</span>
            </td>
            <td>
              <span style="display:inline-block;padding:6px 14px;background-color:#B0413E20;color:#B0413E;font-size:12px;font-weight:700;border-radius:6px;">Risque: G\u00e9opolitique \u00e9lev\u00e9</span>
            </td>
          </tr>
        </table>

        ${buildSectionHeading("Semaine pass\u00e9e", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
          ${buildBulletItem("Lundi noir : le S&P 500 a chut\u00e9 de 1.5% et le Dow de 902 pts apr\u00e8s l'escalade militaire US/Isra\u00ebl en Iran", mod.accent)}
          ${buildBulletItem("VIX en spike \u00e0 28.15 intraday (+23%), plus haut niveau en 3 mois \u2014 vol en zone d'alerte", mod.accent)}
          ${buildBulletItem("Rebond technique mercredi (+0.8% S&P) sur signaux diplomatiques : l'Iran ouvre la porte aux n\u00e9gociations", mod.accent)}
          ${buildBulletItem("Or en vol \u00e0 $5,155/oz (+flight to safety), p\u00e9trole en forte hausse puis stabilisation", mod.accent)}
          ${buildBulletItem("Bitcoin rebondit \u00e0 $71,680 (+4%), plus haut d'un mois malgr\u00e9 le contexte g\u00e9opolitique", mod.accent)}
        </table>

        ${buildSectionHeading("Semaine \u00e0 venir", "#D4A853")}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
          ${buildBulletItem("Payrolls US (NFP) vendredi \u2014 test cl\u00e9 pour le march\u00e9 du travail", "#D4A853")}
          ${buildBulletItem("\u00c9volution du conflit Iran : diplomatie vs escalade, impact direct sur p\u00e9trole et volatilit\u00e9", "#D4A853")}
          ${buildBulletItem("PMI services ISM \u2014 confirmation ou non du ralentissement \u00e9conomique", "#D4A853")}
          ${buildBulletItem("Discours de membres de la Fed \u2014 guidance sur les taux dans un contexte inflationniste", "#D4A853")}
        </table>

        ${buildSectionHeading("Lecture WMB", mod.accent)}
        ${buildInfoCard({
          label: "Analyse",
          note: "Le march\u00e9 navigue entre deux forces oppos\u00e9es : la pression g\u00e9opolitique (conflit Iran, p\u00e9trole, inflation) et les signaux macro r\u00e9silients (ISM services, emploi). Le rebond de mercredi est technique et fragile \u2014 la volatilit\u00e9 reste \u00e9lev\u00e9e. SI la diplomatie progresse ET les payrolls sont solides, le march\u00e9 pourrait stabiliser au-dessus de 6,800. SINON, retour probable vers les 6,600-6,700 avec VIX au-dessus de 25.",
          accentColor: mod.accent,
        })}

        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:24px 0 0;">
          <tr>
            <td style="padding:16px;border-radius:8px;border:1px dashed #E1E6EA;text-align:center;">
              <p style="margin:0;font-size:13px;color:rgba(30,30,30,0.5);">
                \ud83d\udcd6 <strong>\u00c9dition compl\u00e8te</strong> : scoreboard d\u00e9taill\u00e9, FX, taux, cr\u00e9dit, commodities, crypto, macro, Fed, secteurs, sc\u00e9narios et risques.
              </p>
            </td>
          </tr>
        </table>

      </td>
    </tr>

    ${buildCta("Lire l'\u00e9dition compl\u00e8te", `${SITE_URL}/dashboard`, mod.accent)}
    ${buildFooter("Vous recevez cet email car vous \u00eates abonn\u00e9(e) au Module March\u00e9 US de WallStreet Market Brief.")}
  `;

  return {
    subject: "\ud83d\udcca Module USA \u2014 S10 : Tensions G\u00e9opolitiques & Rebond Technique",
    html: wrapEmail({ preheader: "\ud83d\udcca Tensions Iran, VIX en alerte, rebond technique \u2014 S10 2026", accentColor: mod.accent, innerHtml }),
  };
}

// ═══════════ MODULE MONDE — S10 2026 ═══════════

function buildModuleMondeS10() {
  const mod = { accent: "#0EA5E9", label: "MARCH\u00c9S MONDIAUX", emoji: "\ud83c\udf0d" };

  const innerHtml = `
    ${buildHeader()}
    ${buildAccentLine(mod.accent)}
    ${buildModuleTitleBar({
      moduleLabel: mod.label,
      title: "Choc P\u00e9trolier & Fuite vers la Qualit\u00e9",
      subtitle: "L'escalade au Moyen-Orient secoue les march\u00e9s mondiaux \u2014 l'or et le franc suisse en refuge",
      accentColor: mod.accent,
      weekInfo: "Semaine 10",
      emoji: mod.emoji,
    })}

    <tr>
      <td style="padding:28px 40px;background-color:#FFFFFF;color:#1E1E1E;font-size:14px;line-height:1.7;" class="email-padding">

        <p style="margin:0 0 20px;font-size:12px;color:rgba(30,30,30,0.4);text-transform:uppercase;letter-spacing:1px;font-weight:600;">
          \ud83c\udf0d 3 \u2013 5 mars 2026 \u2014 2026
        </p>

        ${buildSectionHeading("\ud83c\uddea\ud83c\uddfa Europe", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 16px;" class="stat-grid">
          <tr>
            ${buildStatBox({ label: "FTSE 100", value: "10,890", change: "-0.8%", changePositive: false })}
            <td style="width:8px;"></td>
            ${buildStatBox({ label: "DAX", value: "22,150", change: "-1.2%", changePositive: false })}
            <td style="width:8px;"></td>
            ${buildStatBox({ label: "CAC 40", value: "8,020", change: "-0.9%", changePositive: false })}
          </tr>
        </table>
        ${buildInfoCard({ label: "Lecture WMB", note: "L'Europe sous pression g\u00e9opolitique. Les valeurs \u00e9nergie et d\u00e9fense surperforment, mais les cycliques souffrent. Le DAX recule apr\u00e8s ses records historiques.", accentColor: mod.accent })}

        ${buildSectionHeading("\ud83c\uddef\ud83c\uddf5 Asie-Pacifique", "#E07A3A")}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 16px;" class="stat-grid">
          <tr>
            ${buildStatBox({ label: "Nikkei 225", value: "37,450", change: "-1.5%", changePositive: false })}
            <td style="width:8px;"></td>
            ${buildStatBox({ label: "Hang Seng", value: "22,890", change: "-0.7%", changePositive: false })}
            <td style="width:8px;"></td>
            ${buildStatBox({ label: "ASX 200", value: "8,120", change: "-0.4%", changePositive: false })}
          </tr>
        </table>
        ${buildInfoCard({ label: "Lecture WMB", note: "L'Asie amplifie les pertes US du lundi. Le Nikkei souffre de la force du yen (valeur refuge). La Chine fixe un objectif de croissance plus bas pour 2026.", accentColor: "#E07A3A" })}

        ${buildSectionHeading("\ud83d\udcb1 Forex", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:#F8F9FA;border-radius:8px;overflow:hidden;margin:0 0 8px;">
          <tr><td style="padding:8px 12px;border-bottom:1px solid #F0F1F3;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td><span style="font-size:13px;font-weight:700;color:#344453;">EUR/USD</span></td>
              <td style="text-align:center;"><span style="font-size:13px;color:rgba(30,30,30,0.6);">1.1612</span></td>
              <td style="text-align:right;"><span style="font-size:13px;font-weight:600;color:#B0413E;">-0.3%</span></td>
            </tr></table>
          </td></tr>
          <tr><td style="padding:8px 12px;border-bottom:1px solid #F0F1F3;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td><span style="font-size:13px;font-weight:700;color:#344453;">USD/JPY</span></td>
              <td style="text-align:center;"><span style="font-size:13px;color:rgba(30,30,30,0.6);">147.20</span></td>
              <td style="text-align:right;"><span style="font-size:13px;font-weight:600;color:#B0413E;">-1.1%</span></td>
            </tr></table>
          </td></tr>
          <tr><td style="padding:8px 12px;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td><span style="font-size:13px;font-weight:700;color:#344453;">GBP/USD</span></td>
              <td style="text-align:center;"><span style="font-size:13px;color:rgba(30,30,30,0.6);">1.2945</span></td>
              <td style="text-align:right;"><span style="font-size:13px;font-weight:600;color:#2E7D5B;">+0.2%</span></td>
            </tr></table>
          </td></tr>
        </table>

        ${buildSectionHeading("\ud83d\udee2\ufe0f Commodities", "#D4A853")}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:#F8F9FA;border-radius:8px;overflow:hidden;margin:0 0 8px;">
          <tr><td style="padding:8px 12px;border-bottom:1px solid #F0F1F3;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td><span style="font-size:13px;font-weight:700;color:#344453;">Or (XAU)</span></td>
              <td style="text-align:center;"><span style="font-size:13px;color:rgba(30,30,30,0.6);">$5,155</span></td>
              <td style="text-align:right;"><span style="font-size:13px;font-weight:600;color:#2E7D5B;">+2.8%</span></td>
            </tr></table>
          </td></tr>
          <tr><td style="padding:8px 12px;border-bottom:1px solid #F0F1F3;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td><span style="font-size:13px;font-weight:700;color:#344453;">WTI Crude</span></td>
              <td style="text-align:center;"><span style="font-size:13px;color:rgba(30,30,30,0.6);">$78.50</span></td>
              <td style="text-align:right;"><span style="font-size:13px;font-weight:600;color:#2E7D5B;">+5.2%</span></td>
            </tr></table>
          </td></tr>
          <tr><td style="padding:8px 12px;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td><span style="font-size:13px;font-weight:700;color:#344453;">Bitcoin</span></td>
              <td style="text-align:center;"><span style="font-size:13px;color:rgba(30,30,30,0.6);">$71,680</span></td>
              <td style="text-align:right;"><span style="font-size:13px;font-weight:600;color:#2E7D5B;">+4.0%</span></td>
            </tr></table>
          </td></tr>
        </table>

        ${buildSectionHeading("Lecture WMB", mod.accent)}
        ${buildInfoCard({
          label: "Analyse globale",
          note: "Le conflit Iran redistribue les cartes \u00e0 l'\u00e9chelle mondiale. Les actifs refuges (or, CHF, yen, Treasuries) surperforment. Le p\u00e9trole reste le principal vecteur de risque inflationniste. SI la diplomatie aboutit, les march\u00e9s pourraient retrouver leurs niveaux pr\u00e9-conflit. SINON, le risque de stagflation se renforce.",
          accentColor: mod.accent,
        })}

      </td>
    </tr>

    ${buildCta("Lire l'\u00e9dition compl\u00e8te", `${SITE_URL}/monde/1`, mod.accent)}
    ${buildFooter("Vous recevez cet email car vous \u00eates abonn\u00e9(e) au Module March\u00e9s Mondiaux de WallStreet Market Brief.")}
  `;

  return {
    subject: "\ud83c\udf0d Module Monde \u2014 S10 : Choc P\u00e9trolier & Fuite vers la Qualit\u00e9",
    html: wrapEmail({ preheader: "\ud83c\udf0d Choc Iran, or \u00e0 $5,155, march\u00e9s mondiaux sous pression \u2014 S10 2026", accentColor: mod.accent, innerHtml }),
  };
}

// ═══════════ MODULE ACTIONS — S10 2026 ═══════════

function buildModuleActionsS10() {
  const mod = { accent: "#D4A853", label: "MODULE ACTIONS US", emoji: "\ud83c\udfaf" };

  const innerHtml = `
    ${buildHeader()}
    ${buildAccentLine(mod.accent)}
    ${buildModuleTitleBar({
      moduleLabel: mod.label,
      title: "D\u00e9fense & \u00c9nergie en T\u00eate, Tech en Rebond",
      subtitle: "Rotation sectorielle marqu\u00e9e \u2014 les valeurs refuges surperforment",
      accentColor: mod.accent,
      weekInfo: "Semaine 10",
      emoji: mod.emoji,
    })}

    <tr>
      <td style="padding:28px 40px;background-color:#FFFFFF;color:#1E1E1E;font-size:14px;line-height:1.7;" class="email-padding">

        <p style="margin:0 0 20px;font-size:12px;color:rgba(30,30,30,0.4);text-transform:uppercase;letter-spacing:1px;font-weight:600;">
          \ud83c\udfaf 3 \u2013 5 mars 2026 \u2014 2026
        </p>

        ${buildSectionHeading("\ud83d\udcc8 Top Gagnants", "#2E7D5B")}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:#F8F9FA;border-radius:8px;overflow:hidden;margin:0 0 20px;">
          <tr><td style="padding:10px 12px;border-bottom:1px solid #F0F1F3;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td style="width:60px;"><span style="font-size:13px;font-weight:700;color:#344453;">STVN</span></td>
              <td><span style="font-size:12px;color:rgba(30,30,30,0.6);">Stevanato Group</span></td>
              <td style="text-align:right;width:70px;"><span style="font-size:13px;font-weight:700;color:#2E7D5B;">+16.8%</span></td>
            </tr><tr>
              <td colspan="3" style="padding-top:3px;"><span style="font-size:11px;color:rgba(30,30,30,0.4);">R\u00e9sultats au-dessus des attentes, guidance relev\u00e9e</span></td>
            </tr></table>
          </td></tr>
          <tr><td style="padding:10px 12px;border-bottom:1px solid #F0F1F3;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td style="width:60px;"><span style="font-size:13px;font-weight:700;color:#344453;">ROST</span></td>
              <td><span style="font-size:12px;color:rgba(30,30,30,0.6);">Ross Stores</span></td>
              <td style="text-align:right;width:70px;"><span style="font-size:13px;font-weight:700;color:#2E7D5B;">+7.2%</span></td>
            </tr><tr>
              <td colspan="3" style="padding-top:3px;"><span style="font-size:11px;color:rgba(30,30,30,0.4);">Earnings beat, consommateur r\u00e9silient</span></td>
            </tr></table>
          </td></tr>
          <tr><td style="padding:10px 12px;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td style="width:60px;"><span style="font-size:13px;font-weight:700;color:#344453;">MRNA</span></td>
              <td><span style="font-size:12px;color:rgba(30,30,30,0.6);">Moderna</span></td>
              <td style="text-align:right;width:70px;"><span style="font-size:13px;font-weight:700;color:#2E7D5B;">+6.4%</span></td>
            </tr><tr>
              <td colspan="3" style="padding-top:3px;"><span style="font-size:11px;color:rgba(30,30,30,0.4);">Pipeline oncologie prometteur, partenariat strat\u00e9gique</span></td>
            </tr></table>
          </td></tr>
        </table>

        ${buildSectionHeading("\ud83d\udcc9 Top Perdants", "#B0413E")}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:#F8F9FA;border-radius:8px;overflow:hidden;margin:0 0 20px;">
          <tr><td style="padding:10px 12px;border-bottom:1px solid #F0F1F3;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td style="width:60px;"><span style="font-size:13px;font-weight:700;color:#344453;">TMO</span></td>
              <td><span style="font-size:12px;color:rgba(30,30,30,0.6);">Thermo Fisher</span></td>
              <td style="text-align:right;width:70px;"><span style="font-size:13px;font-weight:700;color:#B0413E;">-3.6%</span></td>
            </tr><tr>
              <td colspan="3" style="padding-top:3px;"><span style="font-size:11px;color:rgba(30,30,30,0.4);">Guidance d\u00e9cevante, pression sur les marges</span></td>
            </tr></table>
          </td></tr>
          <tr><td style="padding:10px 12px;border-bottom:1px solid #F0F1F3;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td style="width:60px;"><span style="font-size:13px;font-weight:700;color:#344453;">DOCU</span></td>
              <td><span style="font-size:12px;color:rgba(30,30,30,0.6);">DocuSign</span></td>
              <td style="text-align:right;width:70px;"><span style="font-size:13px;font-weight:700;color:#B0413E;">-2.6%</span></td>
            </tr><tr>
              <td colspan="3" style="padding-top:3px;"><span style="font-size:11px;color:rgba(30,30,30,0.4);">Croissance ralentie, concurrence accrue</span></td>
            </tr></table>
          </td></tr>
          <tr><td style="padding:10px 12px;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td style="width:60px;"><span style="font-size:13px;font-weight:700;color:#344453;">LVS</span></td>
              <td><span style="font-size:12px;color:rgba(30,30,30,0.6);">Las Vegas Sands</span></td>
              <td style="text-align:right;width:70px;"><span style="font-size:13px;font-weight:700;color:#B0413E;">-2.5%</span></td>
            </tr><tr>
              <td colspan="3" style="padding-top:3px;"><span style="font-size:11px;color:rgba(30,30,30,0.4);">Exposition Asie, risque g\u00e9opolitique</span></td>
            </tr></table>
          </td></tr>
        </table>

        ${buildSectionHeading("Vue Sectorielle", mod.accent)}
        ${buildInfoCard({
          label: "Tendance",
          note: "Rotation claire vers les secteurs d\u00e9fensifs : \u00e9nergie (+3.2%), d\u00e9fense (+2.8%), utilities (+1.5%). La tech rebondit mercredi apr\u00e8s le sell-off de lundi. Les cycliques (consommation discr\u00e9tionnaire, voyage) restent sous pression.",
          accentColor: mod.accent,
        })}

        ${buildSectionHeading("Watchlist", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:#F8F9FA;border-radius:8px;overflow:hidden;margin:0 0 16px;">
          <tr><td style="padding:8px 12px;border-bottom:1px solid #F0F1F3;">
            <span style="font-size:13px;font-weight:700;color:${mod.accent};margin-right:8px;">LMT</span>
            <span style="font-size:12px;color:rgba(30,30,30,0.6);">D\u00e9fense, b\u00e9n\u00e9ficiaire direct du conflit Iran</span>
          </td></tr>
          <tr><td style="padding:8px 12px;border-bottom:1px solid #F0F1F3;">
            <span style="font-size:13px;font-weight:700;color:${mod.accent};margin-right:8px;">XOM</span>
            <span style="font-size:12px;color:rgba(30,30,30,0.6);">\u00c9nergie, levier p\u00e9trolier direct</span>
          </td></tr>
          <tr><td style="padding:8px 12px;">
            <span style="font-size:13px;font-weight:700;color:${mod.accent};margin-right:8px;">GLD</span>
            <span style="font-size:12px;color:rgba(30,30,30,0.6);">ETF Or, couverture g\u00e9opolitique</span>
          </td></tr>
        </table>

      </td>
    </tr>

    ${buildCta("Lire l'\u00e9dition compl\u00e8te", `${SITE_URL}/actions/1`, mod.accent)}
    ${buildFooter("Vous recevez cet email car vous \u00eates abonn\u00e9(e) au Module Actions US de WallStreet Market Brief.")}
  `;

  return {
    subject: "\ud83c\udfaf Module Actions \u2014 S10 : D\u00e9fense & \u00c9nergie en T\u00eate",
    html: wrapEmail({ preheader: "\ud83c\udfaf STVN +16.8%, rotation d\u00e9fensive, watchlist g\u00e9opolitique \u2014 S10 2026", accentColor: mod.accent, innerHtml }),
  };
}

// ═══════════ MODULE SUISSE — S10 2026 ═══════════

function buildModuleSuisseS10() {
  const mod = { accent: "#B0413E", label: "MODULE SUISSE", emoji: "\ud83c\udde8\ud83c\udded" };

  const innerHtml = `
    ${buildHeader()}
    ${buildAccentLine(mod.accent)}
    ${buildModuleTitleBar({
      moduleLabel: mod.label,
      title: "SMI sous Pression, CHF en Refuge",
      subtitle: "Le march\u00e9 suisse recule face au choc g\u00e9opolitique \u2014 le franc suisse joue son r\u00f4le de valeur refuge",
      accentColor: mod.accent,
      weekInfo: "Semaine 10",
      emoji: mod.emoji,
    })}

    <tr>
      <td style="padding:28px 40px;background-color:#FFFFFF;color:#1E1E1E;font-size:14px;line-height:1.7;" class="email-padding">

        <p style="margin:0 0 20px;font-size:12px;color:rgba(30,30,30,0.4);text-transform:uppercase;letter-spacing:1px;font-weight:600;">
          \ud83c\udde8\ud83c\udded 3 \u2013 5 mars 2026 \u2014 2026
        </p>

        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;" class="stat-grid">
          <tr>
            ${buildStatBox({ label: "SMI", value: "13,503", change: "-2.0%", changePositive: false })}
            <td style="width:8px;"></td>
            ${buildStatBox({ label: "Taux BNS", value: "0.25%" })}
            <td style="width:8px;"></td>
            <td style="padding:12px;background-color:#F8F9FA;border-radius:8px;text-align:center;border:1px solid #E8EAED;">
              <p style="margin:0;font-size:10px;color:rgba(30,30,30,0.4);text-transform:uppercase;letter-spacing:1px;font-weight:600;">CPI F\u00e9vrier</p>
              <p style="margin:4px 0 0;font-size:14px;font-weight:700;color:#344453;">+0.1% YoY</p>
            </td>
          </tr>
        </table>

        ${buildSectionHeading("\ud83c\udde8\ud83c\udded Franc Suisse", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:#F8F9FA;border-radius:8px;overflow:hidden;margin:0 0 8px;">
          <tr><td style="padding:8px 12px;border-bottom:1px solid #F0F1F3;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td><span style="font-size:13px;font-weight:700;color:#344453;">EUR/CHF</span></td>
              <td style="text-align:center;"><span style="font-size:13px;color:rgba(30,30,30,0.6);">0.9380</span></td>
              <td style="text-align:right;"><span style="font-size:13px;font-weight:600;color:#2E7D5B;">-0.5%</span></td>
            </tr></table>
          </td></tr>
          <tr><td style="padding:8px 12px;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td><span style="font-size:13px;font-weight:700;color:#344453;">USD/CHF</span></td>
              <td style="text-align:center;"><span style="font-size:13px;color:rgba(30,30,30,0.6);">0.8680</span></td>
              <td style="text-align:right;"><span style="font-size:13px;font-weight:600;color:#2E7D5B;">-0.8%</span></td>
            </tr></table>
          </td></tr>
        </table>
        ${buildInfoCard({ label: "Lecture WMB", note: "Le franc suisse se renforce nettement en tant que valeur refuge face au conflit Iran. L'EUR/CHF repasse sous 0.94, confirmant le statut de safe haven du CHF.", accentColor: mod.accent })}

        ${buildSectionHeading("Blue Chips SMI", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:#F8F9FA;border-radius:8px;overflow:hidden;margin:0 0 8px;">
          <tr><td style="padding:8px 12px;border-bottom:1px solid #F0F1F3;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td><span style="font-size:13px;font-weight:700;color:#344453;">NESN</span></td>
              <td style="text-align:center;"><span style="font-size:13px;color:rgba(30,30,30,0.6);">CHF 82.50</span></td>
              <td style="text-align:right;"><span style="font-size:13px;font-weight:600;color:#B0413E;">-1.2%</span></td>
            </tr></table>
          </td></tr>
          <tr><td style="padding:8px 12px;border-bottom:1px solid #F0F1F3;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td><span style="font-size:13px;font-weight:700;color:#344453;">ROG</span></td>
              <td style="text-align:center;"><span style="font-size:13px;color:rgba(30,30,30,0.6);">CHF 268.40</span></td>
              <td style="text-align:right;"><span style="font-size:13px;font-weight:600;color:#B0413E;">-0.8%</span></td>
            </tr></table>
          </td></tr>
          <tr><td style="padding:8px 12px;">
            <table width="100%" cellpadding="0" cellspacing="0"><tr>
              <td><span style="font-size:13px;font-weight:700;color:#344453;">NOVN</span></td>
              <td style="text-align:center;"><span style="font-size:13px;color:rgba(30,30,30,0.6);">CHF 89.20</span></td>
              <td style="text-align:right;"><span style="font-size:13px;font-weight:600;color:#2E7D5B;">+0.3%</span></td>
            </tr></table>
          </td></tr>
        </table>

        ${buildSectionHeading("Semaine pass\u00e9e", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
          ${buildBulletItem("SMI en baisse de 2% lundi, impact direct du conflit au Moyen-Orient", mod.accent)}
          ${buildBulletItem("CPI suisse stable \u00e0 +0.1% YoY en f\u00e9vrier \u2014 inflation ma\u00eetris\u00e9e", mod.accent)}
          ${buildBulletItem("CHF en forte demande : EUR/CHF sous 0.94, USD/CHF sous 0.87", mod.accent)}
        </table>

        ${buildSectionHeading("Lecture WMB", mod.accent)}
        ${buildInfoCard({
          label: "Analyse",
          note: "Le march\u00e9 suisse subit la correction g\u00e9opolitique mais reste r\u00e9silient gr\u00e2ce \u00e0 ses d\u00e9fensives (pharma, alimentaire). La BNS pourrait \u00eatre contrainte d'intervenir si le CHF continue de se renforcer. SI le conflit s'apaise, le SMI devrait retrouver les 13,800+. SINON, support technique \u00e0 13,400.",
          accentColor: mod.accent,
        })}

      </td>
    </tr>

    ${buildCta("Lire l'\u00e9dition compl\u00e8te", `${SITE_URL}/suisse/1`, mod.accent)}
    ${buildFooter("Vous recevez cet email car vous \u00eates abonn\u00e9(e) au Module Suisse de WallStreet Market Brief.")}
  `;

  return {
    subject: "\ud83c\udde8\ud83c\udded Module Suisse \u2014 S10 : SMI sous Pression, CHF en Refuge",
    html: wrapEmail({ preheader: "\ud83c\udde8\ud83c\udded SMI -2%, CHF en refuge, CPI stable \u2014 S10 2026", accentColor: mod.accent, innerHtml }),
  };
}

// ═══════════ SEND ALL 4 MODULES ═══════════

async function main() {
  console.log("=".repeat(50));
  console.log("  WMB Newsletter Test — Semaine 10 / 2026");
  console.log("  Via Brevo HTTP API");
  console.log("  Recipients:", TEST_RECIPIENTS.join(", "));
  console.log("=".repeat(50));
  console.log();

  const modules = [
    { name: "USA", ...buildModuleUsaS10() },
    { name: "Monde", ...buildModuleMondeS10() },
    { name: "Actions", ...buildModuleActionsS10() },
    { name: "Suisse", ...buildModuleSuisseS10() },
  ];

  let totalSent = 0;
  let totalFailed = 0;

  for (const mod of modules) {
    console.log(`\n--- Sending ${mod.name} ---`);
    console.log(`  Subject: ${mod.subject}`);
    for (const recipient of TEST_RECIPIENTS) {
      const success = await sendEmailViaBrevo(recipient, mod.subject, mod.html);
      if (success) totalSent++;
      else totalFailed++;
      // Small delay between sends
      await new Promise(r => setTimeout(r, 1000));
    }
  }

  console.log("\n" + "=".repeat(50));
  console.log(`  DONE: ${totalSent} sent, ${totalFailed} failed`);
  console.log(`  Total: ${totalSent + totalFailed} emails (4 modules x ${TEST_RECIPIENTS.length} recipients)`);
  console.log("=".repeat(50));
}

main().catch(console.error);
