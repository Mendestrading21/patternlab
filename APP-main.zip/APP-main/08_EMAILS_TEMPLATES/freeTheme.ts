/**
 * WMB Free Theme Email V10 — Dark Shell + Light Core
 * ─────────────────────────────────────────────────────────
 * Sent automatically on lead capture (email signup).
 * Delivers a teaser of the latest "Thème du Mois" with a link to read on the site.
 * NO PDF attachment — the goal is to drive traffic to the site.
 * The access token is stored in DB and verified on the reading page.
 *
 * Uses the same buildWmbEmailHtml as ALL other emails → consistent look everywhere.
 */
import { sendEmail, buildWmbEmailHtml } from "../email";
import { getDb } from "../db";
import { monthlyThemes, themeAccessTokens } from "../../drizzle/schema";
import { eq, desc } from "drizzle-orm";
import crypto from "crypto";

const SITE_URL = "https://wallstreetmarketbrief.ch";

// V10 Light Core tokens
const CARD_BG = "#F7F8FA";
const BORDER_LIGHT = "#E5E7EB";
const TEXT_DARK = "#1A1A1A";
const TEXT_BODY = "#374151";
const TEXT_CAPTION = "#6B7280";
const GOLD = "#C8A960";
const GREEN = "#16A34A";
const BLUE = "#2563EB";
const PURPLE = "#7C3AED";

/**
 * Get the latest published theme from the database
 */
async function getLatestPublishedTheme() {
  const db = await getDb();
  if (!db) return null;

  const rows = await db
    .select({
      id: monthlyThemes.id,
      slug: monthlyThemes.slug,
      title: monthlyThemes.title,
      subtitle: monthlyThemes.subtitle,
      sector: monthlyThemes.sector,
      readingTime: monthlyThemes.readingTime,
      publishedAt: monthlyThemes.publishedAt,
      executiveSummary: monthlyThemes.executiveSummary,
    })
    .from(monthlyThemes)
    .where(eq(monthlyThemes.status, "published"))
    .orderBy(desc(monthlyThemes.publishedAt), desc(monthlyThemes.id))
    .limit(1);

  return rows.length > 0 ? rows[0] : null;
}

/**
 * Generate a unique access token and store it in the database
 */
async function generateAndStoreAccessToken(email: string, themeSlug: string): Promise<string> {
  const data = `${email}:${themeSlug}:${Date.now()}:${crypto.randomBytes(16).toString("hex")}`;
  const token = crypto.createHash("sha256").update(data).digest("hex").substring(0, 32);

  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const expiresAt = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000);

  await db.insert(themeAccessTokens).values({
    email,
    themeSlug,
    token,
    expiresAt,
  });

  return token;
}

/**
 * Build the teaser summary from the theme's executive summary
 */
function extractTeaser(executiveSummary: string | null): string {
  if (!executiveSummary) return "";
  try {
    const parsed = JSON.parse(executiveSummary);
    if (parsed.verdict) return parsed.verdict;
    if (parsed.points && Array.isArray(parsed.points)) {
      return parsed.points.slice(0, 3).map((p: any) => p.text || p).join(" ");
    }
    if (typeof parsed === "string") return parsed;
  } catch {
    // Not JSON, use as-is
  }
  return executiveSummary.substring(0, 350);
}

/**
 * Build the rich body HTML for the free theme email — V10 Light Core
 * This goes inside the unified buildWmbEmailHtml wrapper
 */
function buildFreeThemeBody(opts: {
  userName: string;
  themeTitle: string;
  themeSubtitle: string | null;
  sector: string;
  readingTime: number;
  teaserText: string;
  readLink: string;
}): string {
  const { userName, themeTitle, themeSubtitle, sector, readingTime, teaserText, readLink } = opts;

  const truncatedTeaser = teaserText.length > 280
    ? teaserText.substring(0, 280) + "..."
    : teaserText;

  const monthNames = ["janvier", "f\u00e9vrier", "mars", "avril", "mai", "juin", "juillet", "ao\u00fbt", "septembre", "octobre", "novembre", "d\u00e9cembre"];
  const currentMonth = monthNames[new Date().getMonth()];
  const year = new Date().getFullYear();

  return `
    <p style="font-size:15px;color:${TEXT_DARK};line-height:1.7;margin:0 0 16px;">
      Bonjour <strong>${userName}</strong>,
    </p>
    <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 24px;">
      Merci pour votre int&eacute;r&ecirc;t pour <strong style="color:${TEXT_DARK};">WallStreet Market Brief</strong>. Comme promis, voici votre <strong style="color:${GOLD};">Th&egrave;me du Mois gratuit</strong> &mdash; une analyse sectorielle approfondie habituellement r&eacute;serv&eacute;e &agrave; nos abonn&eacute;s premium.
    </p>

    <!-- ═══ Theme Card — Dark banner on light body ═══ -->
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;border-radius:10px;overflow:hidden;border:1px solid ${BORDER_LIGHT};">
      <tr>
        <td style="background-color:#111318;padding:24px 28px 20px;">
          <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 12px;">
            <tr>
              <td>
                <span style="display:inline-block;padding:4px 12px;background-color:rgba(200,169,96,0.15);border:1px solid rgba(200,169,96,0.3);border-radius:20px;font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:${GOLD};">Th&egrave;me du Mois &mdash; ${currentMonth} ${year}</span>
              </td>
            </tr>
          </table>
          <h2 style="margin:0 0 8px;font-size:22px;font-weight:800;line-height:1.25;color:#FFFFFF;">${themeTitle}</h2>
          ${themeSubtitle ? `<p style="margin:0;font-size:13px;color:#9CA3AF;line-height:1.5;">${themeSubtitle}</p>` : ""}
        </td>
      </tr>
      <tr>
        <td style="background-color:${CARD_BG};padding:16px 28px;">
          <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
            <tr>
              <td style="padding:4px 10px;background-color:#FFFFFF;border-radius:4px;font-size:11px;font-weight:700;color:${TEXT_DARK};border:1px solid ${BORDER_LIGHT};">${sector}</td>
              <td width="8"></td>
              <td style="padding:4px 10px;background-color:#FFFFFF;border-radius:4px;font-size:11px;color:${TEXT_CAPTION};border:1px solid ${BORDER_LIGHT};">${readingTime} min de lecture</td>
              <td width="8"></td>
              <td style="padding:4px 10px;background-color:#FFFFFF;border-radius:4px;font-size:11px;color:${TEXT_CAPTION};border:1px solid ${BORDER_LIGHT};">16 sections</td>
            </tr>
          </table>
        </td>
      </tr>
    </table>

    <!-- ═══ Teaser excerpt ═══ -->
    ${truncatedTeaser ? `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;">
      <tr>
        <td style="padding:18px 22px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GOLD};">
          <p style="margin:0 0 4px;font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:${GOLD};font-weight:700;">Aper&ccedil;u de l'analyse</p>
          <p style="margin:0;font-size:13px;color:${TEXT_BODY};line-height:1.7;font-style:italic;">${truncatedTeaser}</p>
        </td>
      </tr>
    </table>
    ` : ""}

    <!-- ═══ What's inside — 4 pillars ═══ -->
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 8px;">
      <tr>
        <td>
          <div style="display:inline-block;width:3px;height:16px;background-color:${TEXT_DARK};border-radius:2px;vertical-align:middle;margin-right:10px;"></div>
          <span style="font-size:15px;font-weight:700;color:${TEXT_DARK};vertical-align:middle;">Ce que contient cette analyse</span>
        </td>
      </tr>
    </table>

    <!-- Pillar 1 -->
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:12px 0 8px;">
      <tr>
        <td style="padding:12px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
          <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
            <tr>
              <td style="width:28px;vertical-align:top;">
                <div style="width:24px;height:24px;background-color:rgba(37,99,235,0.08);border-radius:6px;text-align:center;line-height:24px;font-size:12px;color:${BLUE};font-weight:700;">1</div>
              </td>
              <td style="padding-left:10px;">
                <p style="margin:0;font-size:13px;font-weight:700;color:${TEXT_DARK};">Contexte &amp; Enjeux</p>
                <p style="margin:2px 0 0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">R&eacute;sum&eacute; ex&eacute;cutif, contexte macro, cartographie du secteur</p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>

    <!-- Pillar 2 -->
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 8px;">
      <tr>
        <td style="padding:12px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
          <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
            <tr>
              <td style="width:28px;vertical-align:top;">
                <div style="width:24px;height:24px;background-color:rgba(22,163,74,0.08);border-radius:6px;text-align:center;line-height:24px;font-size:12px;color:${GREEN};font-weight:700;">2</div>
              </td>
              <td style="padding-left:10px;">
                <p style="margin:0;font-size:13px;font-weight:700;color:${TEXT_DARK};">Analyse approfondie</p>
                <p style="margin:2px 0 0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">Moteurs de croissance, taille du march&eacute;, acteurs cl&eacute;s, ETF</p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>

    <!-- Pillar 3 -->
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 8px;">
      <tr>
        <td style="padding:12px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
          <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
            <tr>
              <td style="width:28px;vertical-align:top;">
                <div style="width:24px;height:24px;background-color:rgba(200,169,96,0.08);border-radius:6px;text-align:center;line-height:24px;font-size:12px;color:${GOLD};font-weight:700;">3</div>
              </td>
              <td style="padding-left:10px;">
                <p style="margin:0;font-size:13px;font-weight:700;color:${TEXT_DARK};">Catalyseurs &amp; Risques</p>
                <p style="margin:2px 0 0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">Triggers, matrice de risques, sc&eacute;narios SI/ALORS</p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>

    <!-- Pillar 4 -->
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;">
      <tr>
        <td style="padding:12px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
          <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
            <tr>
              <td style="width:28px;vertical-align:top;">
                <div style="width:24px;height:24px;background-color:rgba(124,58,237,0.08);border-radius:6px;text-align:center;line-height:24px;font-size:12px;color:${PURPLE};font-weight:700;">4</div>
              </td>
              <td style="padding-left:10px;">
                <p style="margin:0;font-size:13px;font-weight:700;color:${TEXT_DARK};">Outils de suivi</p>
                <p style="margin:2px 0 0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">Glossaire sectoriel, checklist, sources v&eacute;rifiables</p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>

    <!-- ═══ Trust badges ═══ -->
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;">
      <tr>
        <td style="padding:14px 18px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};" align="center">
          <span style="display:inline-block;padding:4px 10px;background-color:rgba(22,163,74,0.08);color:${GREEN};font-size:10px;font-weight:700;border-radius:4px;margin:2px;">100% Informatif</span>
          <span style="display:inline-block;padding:4px 10px;background-color:rgba(200,169,96,0.08);color:${GOLD};font-size:10px;font-weight:700;border-radius:4px;margin:2px;">Donn&eacute;es sourc&eacute;es</span>
          <span style="display:inline-block;padding:4px 10px;background-color:rgba(37,99,235,0.08);color:${BLUE};font-size:10px;font-weight:700;border-radius:4px;margin:2px;">Z&eacute;ro conseil</span>
        </td>
      </tr>
    </table>

    <!-- ═══ Upsell block ═══ -->
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 8px;">
      <tr>
        <td style="padding:18px 22px;background-color:#111318;border-radius:8px;">
          <p style="margin:0 0 6px;font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:${GOLD};font-weight:700;">Aller plus loin</p>
          <p style="margin:0 0 12px;font-size:13px;color:#9CA3AF;line-height:1.6;">
            Chaque dimanche, nos abonn&eacute;s re&ccedil;oivent 5 modules d'analyse : March&eacute; US, Actions US, March&eacute;s Mondiaux, Module Suisse, et le Th&egrave;me du Mois.
          </p>
          <table cellpadding="0" cellspacing="0" role="presentation">
            <tr>
              <td style="padding:8px 18px;border:1px solid rgba(200,169,96,0.4);border-radius:6px;">
                <a href="${SITE_URL}/pricing" style="color:${GOLD};text-decoration:none;font-size:12px;font-weight:700;letter-spacing:0.3px;">D&eacute;couvrir les offres &rarr;</a>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>

    <p style="margin:20px 0 0;font-size:14px;color:${TEXT_DARK};line-height:1.7;font-weight:600;">Cliquez ci-dessous pour lire l'analyse compl&egrave;te :</p>
  `;
}

/**
 * Send the latest theme of the month as a free teaser to new leads
 * Uses the unified buildWmbEmailHtml for consistent styling across ALL emails
 */
export async function sendFreeThemeEmail(
  email: string,
  name: string
): Promise<boolean> {
  try {
    const theme = await getLatestPublishedTheme();

    if (!theme) {
      console.log("[FreeTheme] No published theme found, skipping email");
      return false;
    }

    const userName = name || "cher investisseur";

    // Generate and store access token in DB
    const accessToken = await generateAndStoreAccessToken(email, theme.slug);
    const readLink = `${SITE_URL}/lire-theme/${theme.slug}?token=${accessToken}`;

    // Extract teaser text
    const teaserText = extractTeaser(theme.executiveSummary);

    // Build the body HTML (goes inside the unified wrapper)
    const bodyHtml = buildFreeThemeBody({
      userName,
      themeTitle: theme.title,
      themeSubtitle: theme.subtitle,
      sector: theme.sector,
      readingTime: theme.readingTime,
      teaserText,
      readLink,
    });

    // Use the SAME unified template as all other emails
    const html = buildWmbEmailHtml({
      title: `${userName}, votre analyse est pr&ecirc;te`,
      preheader: `Votre Th\u00e8me du Mois gratuit : ${theme.title}`,
      bodyHtml,
      ctaText: "Lire l'analyse compl\u00e8te",
      ctaUrl: readLink,
      accentColor: "#C8A960",
      footerText:
        "Vous recevez cet email car vous avez demand&eacute; le Th&egrave;me du Mois gratuit sur WallStreet Market Brief.",
    });

    const sent = await sendEmail({
      to: email,
      subject: `Votre analyse gratuite : ${theme.title}`,
      html,
      tag: "theme_du_mois",
    });

    if (sent) {
      console.log(`[FreeTheme] Email V10 sent to ${email} (theme: ${theme.slug}, token: ${accessToken.substring(0, 8)}...)`);
    }
    return sent;
  } catch (error) {
    console.error(`[FreeTheme] Error sending theme email:`, error);
    return false;
  }
}
