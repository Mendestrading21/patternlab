/**
 * WMB Welcome Email V10 — Dark Shell + Light Core
 * Sent after successful Stripe checkout
 * Adapted per subscription type: Newsletter / Academy / Pack Complet
 */

export type WelcomeEmailParams = {
  userName: string;
  userEmail: string;
  plan: "newsletter" | "formation" | "monthly" | "annual";
  userId: string;
};

const SITE_URL = "https://wallstreetmarketbrief.ch";

// V10 Light Core tokens
const CARD_BG = "#F7F8FA";
const BORDER_LIGHT = "#E5E7EB";
const TEXT_DARK = "#1A1A1A";
const TEXT_BODY = "#374151";
const TEXT_CAPTION = "#6B7280";
const GOLD = "#C8A960";
const GREEN = "#16A34A";
const BLUE = "#2563EB";
const RED_ACCENT = "#DC2626";

const PLAN_LABELS: Record<string, { name: string; price: string; interval: string }> = {
  newsletter: { name: "Briefs", price: "CHF 49", interval: "mois" },
  formation: { name: "Academy", price: "CHF 49", interval: "mois" },
  monthly: { name: "Premium", price: "CHF 49", interval: "mois" },
  annual: { name: "Premium Annuel", price: "CHF 490", interval: "an" },
};

function buildModulesBlock(): string {
  return `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:16px 0;">
      <tr>
        <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GREEN};border:1px solid ${BORDER_LIGHT};">
          <p style="margin:0 0 3px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Weekly Brief USA</p>
          <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">Tendances, macro, risques, volatilit&eacute;, sc&eacute;narios</p>
        </td>
      </tr>
      <tr><td style="height:6px;"></td></tr>
      <tr>
        <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GOLD};border:1px solid ${BORDER_LIGHT};">
          <p style="margin:0 0 3px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Module Actions US</p>
          <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">Top movers, secteurs, earnings, watchlist</p>
        </td>
      </tr>
      <tr><td style="height:6px;"></td></tr>
      <tr>
        <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${BLUE};border:1px solid ${BORDER_LIGHT};">
          <p style="margin:0 0 3px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Revue Monde</p>
          <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">Europe, Asie, &eacute;mergents, forex, commodities, crypto</p>
        </td>
      </tr>
      <tr><td style="height:6px;"></td></tr>
      <tr>
        <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${RED_ACCENT};border:1px solid ${BORDER_LIGHT};">
          <p style="margin:0 0 3px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Revue Suisse</p>
          <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">SMI, CHF, BNS, blue chips, &eacute;conomie suisse</p>
        </td>
      </tr>
    </table>`;
}

function buildAcademyBlock(): string {
  return `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:16px 0;">
      <tr>
        <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GOLD};border:1px solid ${BORDER_LIGHT};">
          <p style="margin:0 0 3px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Formation Compl&egrave;te</p>
          <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">Cours structur&eacute;s, vid&eacute;os, quiz interactifs, glossaires</p>
        </td>
      </tr>
      <tr><td style="height:6px;"></td></tr>
      <tr>
        <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GREEN};border:1px solid ${BORDER_LIGHT};">
          <p style="margin:0 0 3px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Th&eacute;matiques Avanc&eacute;es</p>
          <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">Indicateurs, strat&eacute;gies, analyse technique et fondamentale</p>
        </td>
      </tr>
      <tr><td style="height:6px;"></td></tr>
      <tr>
        <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${BLUE};border:1px solid ${BORDER_LIGHT};">
          <p style="margin:0 0 3px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Quiz et Exercices</p>
          <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">Testez vos connaissances, progressez &agrave; votre rythme</p>
        </td>
      </tr>
    </table>`;
}

/**
 * Send a welcome email to the NEW subscriber
 * Content adapts based on the plan type
 */
export async function sendWelcomeEmailToUser(params: WelcomeEmailParams): Promise<boolean> {
  try {
    const { sendEmail, buildWmbEmailHtml } = await import("../email");
    const { userName, userEmail, plan } = params;
    const planInfo = PLAN_LABELS[plan] || PLAN_LABELS.monthly;
    const displayName = userName || "cher abonn\u00e9";

    // Determine what to show based on plan
    const isNewsletter = plan === "newsletter";
    const isAcademy = plan === "formation";
    const isProPack = plan === "monthly" || plan === "annual";

    let accessDescription = "";
    let contentBlocks = "";
    let whatToExpect = "";

    if (isProPack) {
      accessDescription = `Votre abonnement <strong style="color:${TEXT_DARK};">${planInfo.name}</strong> (${planInfo.price}/${planInfo.interval}) est maintenant actif. Vous avez acc&egrave;s &agrave; l'ensemble de la plateforme : newsletter hebdomadaire, formation Acad&eacute;mie, et tous les outils.`;
      contentBlocks = `
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:20px 0 8px;">
          <tr>
            <td>
              <div style="display:inline-block;width:3px;height:16px;background-color:${GREEN};border-radius:2px;vertical-align:middle;margin-right:10px;"></div>
              <span style="font-size:14px;font-weight:700;color:${TEXT_DARK};vertical-align:middle;">Vos modules hebdomadaires</span>
            </td>
          </tr>
        </table>
        ${buildModulesBlock()}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:20px 0 8px;">
          <tr>
            <td>
              <div style="display:inline-block;width:3px;height:16px;background-color:${GOLD};border-radius:2px;vertical-align:middle;margin-right:10px;"></div>
              <span style="font-size:14px;font-weight:700;color:${TEXT_DARK};vertical-align:middle;">Votre formation Acad&eacute;mie</span>
            </td>
          </tr>
        </table>
        ${buildAcademyBlock()}
      `;
      whatToExpect = `
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:16px 0;">
          <tr>
            <td style="padding:16px 18px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
              <p style="margin:0 0 10px;font-size:12px;font-weight:700;color:${GOLD};letter-spacing:1px;text-transform:uppercase;">Ce qui vous attend</p>
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">2 modules hebdo + 3 contenus mensuels</span></td></tr>
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">Formation compl&egrave;te avec cours, quiz et th&eacute;matiques</span></td></tr>
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">Outils interactifs : simulateur, calculateurs, portefeuille virtuel</span></td></tr>
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">Chiffres sourc&eacute;s, sc&eacute;narios conditionnels, risques identifi&eacute;s</span></td></tr>
              </table>
            </td>
          </tr>
        </table>
      `;
    } else if (isAcademy) {
      accessDescription = `Votre abonnement <strong style="color:${TEXT_DARK};">${planInfo.name}</strong> (${planInfo.price}/${planInfo.interval}) est maintenant actif. Vous avez acc&egrave;s &agrave; l'int&eacute;gralit&eacute; de la formation Acad&eacute;mie WMB.`;
      contentBlocks = buildAcademyBlock();
      whatToExpect = `
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:16px 0;">
          <tr>
            <td style="padding:16px 18px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
              <p style="margin:0 0 10px;font-size:12px;font-weight:700;color:${GOLD};letter-spacing:1px;text-transform:uppercase;">Ce qui vous attend</p>
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">Cours structur&eacute;s du d&eacute;butant &agrave; l'avanc&eacute;</span></td></tr>
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">Quiz interactifs pour valider vos acquis</span></td></tr>
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">Glossaires et fiches th&eacute;matiques compl&egrave;tes</span></td></tr>
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">Progression &agrave; votre rythme, contenu mis &agrave; jour r&eacute;guli&egrave;rement</span></td></tr>
              </table>
            </td>
          </tr>
        </table>
      `;
    } else {
      accessDescription = `Votre abonnement <strong style="color:${TEXT_DARK};">${planInfo.name}</strong> (${planInfo.price}/${planInfo.interval}) est maintenant actif. Vous recevrez chaque dimanche les 4 modules de la newsletter hebdomadaire.`;
      contentBlocks = buildModulesBlock();
      whatToExpect = `
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:16px 0;">
          <tr>
            <td style="padding:16px 18px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
              <p style="margin:0 0 10px;font-size:12px;font-weight:700;color:${GOLD};letter-spacing:1px;text-transform:uppercase;">Ce qui vous attend chaque dimanche</p>
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">4 modules compl&eacute;mentaires chaque semaine</span></td></tr>
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">15 &agrave; 20 minutes de lecture par module</span></td></tr>
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">Chiffres sourc&eacute;s, sc&eacute;narios conditionnels, risques identifi&eacute;s</span></td></tr>
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">Aucun conseil, aucun signal &mdash; du contexte et de la clart&eacute;</span></td></tr>
              </table>
            </td>
          </tr>
        </table>
      `;
    }

    const html = buildWmbEmailHtml({
      title: `Bienvenue, ${displayName} !`,
      preheader: `Votre abonnement ${planInfo.name} est actif.`,
      bodyHtml: `
        <p style="font-size:15px;color:${TEXT_DARK};line-height:1.7;margin:0 0 16px;">
          Merci pour votre confiance !
        </p>
        <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 20px;">
          ${accessDescription}
        </p>
        ${contentBlocks}
        ${whatToExpect}
        <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0;">
          Vous pouvez d&egrave;s maintenant acc&eacute;der &agrave; votre espace membre pour consulter l'ensemble de vos contenus.
        </p>
      `,
      ctaText: "Acc\u00e9der \u00e0 mon espace membre",
      ctaUrl: `${SITE_URL}/dashboard`,
      footerText: `Vous recevez cet email suite \u00e0 votre abonnement ${planInfo.name} sur WallStreet Market Brief.`,
    });

    const sent = await sendEmail({
      to: userEmail,
      subject: `Bienvenue sur WallStreet Market Brief \u2014 Abonnement ${planInfo.name} activ\u00e9`,
      html,
      tag: "bienvenue",
    });

    if (sent) {
      console.log(`[Welcome] Welcome email sent to ${userEmail} (plan: ${plan})`);
    }
    return sent;
  } catch (error) {
    console.error(`[Welcome] Error sending welcome email:`, error);
    return false;
  }
}

export async function sendWelcomeNotification(params: WelcomeEmailParams): Promise<boolean> {
  const { userName, userEmail, plan, userId } = params;
  const planInfo = PLAN_LABELS[plan] || PLAN_LABELS.monthly;

  // Also send welcome email to the subscriber
  await sendWelcomeEmailToUser(params);

  const title = `Nouvel abonn\u00e9 WMB \u2014 ${userName || userEmail}`;

  const content = [
    `Un nouvel abonn\u00e9 vient de rejoindre WallStreet Market Brief.`,
    ``,
    `D\u00e9tails :`,
    `- Nom : ${userName || "Non renseign\u00e9"}`,
    `- Email : ${userEmail}`,
    `- Plan : ${planInfo.name} (${planInfo.price}/${planInfo.interval})`,
    `- ID utilisateur : ${userId}`,
    `- Date : ${new Date().toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}`,
    ``,
    `L'utilisateur a maintenant acc\u00e8s \u00e0 l'espace membre et aux \u00e9ditions.`,
  ].join("\n");

  // Admin notification is handled separately via sendAdminNotification in the webhook
  console.log(`[Welcome] Welcome email sent for user ${userId} (${userEmail}), plan=${plan}`);
  return true;
}
