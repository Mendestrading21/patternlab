/**
 * WMB Subscriber Onboarding Email Sequence (7 Steps + Loop)
 * ──────────────────────────────────────────────────────────
 * For email-only contacts (newsletterSubscribers without accounts)
 * Goal: Convert email subscribers → registered users → paying subscribers
 *
 * Step 1 (J+1): Découverte — what WMB is + link to free content
 * Step 2 (J+3): Valeur — show what they're missing (extrait newsletter)
 * Step 3 (J+5): Créer un compte — push to register (free benefits)
 * Step 4 (J+8): Dernière newsletter — aperçu + CTA inscription
 * Step 5 (J+11): Social proof + offre — testimonials + pricing
 * Step 6 (J+14): Briefing Quotidien — highlight daily briefing feature
 * Step 7 (J+18): Dernière chance — full recap + final CTA
 *
 * After step 7: 21-day pause, then loop restart (loopCount incremented)
 *
 * Design: "Dark Shell + Light Core" — unified with buildWmbEmailHtml
 */
import { sendEmail, buildWmbEmailHtml } from "../email";

const SITE_URL = "https://wallstreetmarketbrief.ch";

// V10 Light Core tokens
const CARD_BG = "#F7F8FA";
const BORDER_LIGHT = "#E5E7EB";
const TEXT_DARK = "#1A1A1A";
const TEXT_BODY = "#374151";
const TEXT_CAPTION = "#6B7280";
const GOLD = "#C8A960";
const GREEN = "#16A34A";
const BLUE = "#2563EB";

/**
 * Step 1 — Découverte (J+1)
 * Goal: Introduce WMB, explain what they'll receive, build trust
 */
export async function sendSubscriberStep1(email: string): Promise<boolean> {
  const html = buildWmbEmailHtml({
    title: "WallStreet Market Brief — Votre rendez-vous marchés",
    preheader: "Chaque dimanche, l'essentiel des marchés US en 20 minutes.",
    bodyHtml: `
      <p style="font-size:15px;color:${TEXT_DARK};line-height:1.7;margin:0 0 16px;">
        Merci de votre int&eacute;r&ecirc;t pour WallStreet Market Brief.
      </p>
      <p style="font-size:15px;color:${TEXT_BODY};line-height:1.7;margin:0 0 20px;">
        WMB, c'est une newsletter hebdomadaire qui r&eacute;sume l'essentiel des march&eacute;s financiers US de fa&ccedil;on claire, courte et structur&eacute;e. Chaque dimanche &agrave; 09h00, un deck PDF de 20&ndash;25 slides, pr&ecirc;t &agrave; lire en 15&ndash;20 minutes.
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GOLD};border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0 0 4px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Ce que vous recevrez</p>
            <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">Tendance du march&eacute; &bull; Chiffres cl&eacute;s &bull; Catalyseurs &bull; Risques &bull; Calendrier macro &bull; Sc&eacute;narios conditionnels</p>
          </td>
        </tr>
        <tr><td style="height:8px;"></td></tr>
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GREEN};border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0 0 4px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Notre r&egrave;gle &eacute;ditoriale</p>
            <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">Informatif et &eacute;ducatif uniquement. Pas de conseil, pas de signal, pas d'objectif de prix. Du contexte, des faits, des sc&eacute;narios.</p>
          </td>
        </tr>
      </table>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 24px;">
        En attendant la prochaine &eacute;dition, d&eacute;couvrez un extrait gratuit pour voir le format :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
        <tr>
          <td align="center">
            <a href="${SITE_URL}/extrait" style="display:inline-block;padding:12px 28px;background-color:${GOLD};color:#FFFFFF;font-weight:700;font-size:14px;text-decoration:none;border-radius:6px;">
              Lire un extrait gratuit
            </a>
          </td>
        </tr>
      </table>
    `,
  });

  return sendEmail({
    to: email,
    subject: "WMB — Votre rendez-vous marchés commence ici",
    html,
    tag: "subscriber_onboarding",
  });
}

/**
 * Step 2 — Valeur (J+3)
 * Goal: Show the value they're missing, tease premium content
 */
export async function sendSubscriberStep2(email: string): Promise<boolean> {
  const html = buildWmbEmailHtml({
    title: "Ce que nos lecteurs reçoivent chaque dimanche",
    preheader: "Aperçu d'une édition WMB — tendance, chiffres, risques.",
    bodyHtml: `
      <p style="font-size:15px;color:${TEXT_DARK};line-height:1.7;margin:0 0 16px;">
        Voici un aper&ccedil;u de ce que nos abonn&eacute;s re&ccedil;oivent chaque dimanche matin :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0 0 8px;font-weight:700;font-size:14px;color:${TEXT_DARK};">Exemple d'&eacute;dition type :</p>
            <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
              <tr><td style="padding:4px 0;font-size:13px;color:${TEXT_BODY};">1. R&eacute;gime de march&eacute; &amp; sentiment</td></tr>
              <tr><td style="padding:4px 0;font-size:13px;color:${TEXT_BODY};">2. Scoreboard indices (S&amp;P 500, Nasdaq, Dow)</td></tr>
              <tr><td style="padding:4px 0;font-size:13px;color:${TEXT_BODY};">3. Taux &amp; obligations (Fed, 10Y, 2Y)</td></tr>
              <tr><td style="padding:4px 0;font-size:13px;color:${TEXT_BODY};">4. Catalyseurs de la semaine</td></tr>
              <tr><td style="padding:4px 0;font-size:13px;color:${TEXT_BODY};">5. Calendrier macro</td></tr>
              <tr><td style="padding:4px 0;font-size:13px;color:${TEXT_BODY};">6. Risques &agrave; surveiller</td></tr>
              <tr><td style="padding:4px 0;font-size:13px;color:${TEXT_BODY};">7. Watchlist &amp; sc&eacute;narios SI/ALORS/SINON</td></tr>
            </table>
          </td>
        </tr>
      </table>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 8px;">
        Tout &ccedil;a en 20&ndash;25 slides, lisible en 15 minutes, avec des chiffres sourc&eacute;s et des sc&eacute;narios clairs.
      </p>
      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 24px;">
        Vous &eacute;conomisez 2&ndash;3 heures de veille par semaine.
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
        <tr>
          <td align="center">
            <a href="${SITE_URL}/extrait" style="display:inline-block;padding:12px 28px;background-color:${GOLD};color:#FFFFFF;font-weight:700;font-size:14px;text-decoration:none;border-radius:6px;">
              D&eacute;couvrir un extrait
            </a>
          </td>
        </tr>
      </table>
    `,
  });

  return sendEmail({
    to: email,
    subject: "Aperçu — ce que nos lecteurs reçoivent chaque dimanche",
    html,
    tag: "subscriber_onboarding",
  });
}

/**
 * Step 3 — Créer un compte (J+5)
 * Goal: Push to register a free account (unlock formation, quiz, glossaire)
 */
export async function sendSubscriberStep3(email: string): Promise<boolean> {
  const html = buildWmbEmailHtml({
    title: "Créez votre compte gratuit — débloquez plus de contenu",
    preheader: "Formation, quiz, glossaire, indicateurs — tout gratuit avec un compte.",
    bodyHtml: `
      <p style="font-size:15px;color:${TEXT_DARK};line-height:1.7;margin:0 0 16px;">
        Saviez-vous qu'en cr&eacute;ant un compte gratuit sur WMB, vous d&eacute;bloquez :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:12px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GREEN};border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0;font-size:13px;color:${TEXT_DARK};line-height:1.8;">
              &#10003; Formation gratuite (Module 1 complet)<br/>
              &#10003; Glossaire financier (1 007+ termes)<br/>
              &#10003; Quiz interactifs pour tester vos connaissances<br/>
              &#10003; Indicateurs techniques expliqu&eacute;s (54+)<br/>
              &#10003; Th&eacute;matique du mois gratuite<br/>
              &#10003; Simulateur de positions
            </p>
          </td>
        </tr>
      </table>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 24px;">
        Tout cela est 100% gratuit, sans engagement. Cr&eacute;ez votre compte en 30 secondes :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
        <tr>
          <td align="center">
            <a href="${SITE_URL}/register" style="display:inline-block;padding:12px 28px;background-color:${GREEN};color:#FFFFFF;font-weight:700;font-size:14px;text-decoration:none;border-radius:6px;">
              Cr&eacute;er mon compte gratuit
            </a>
          </td>
        </tr>
      </table>
    `,
  });

  return sendEmail({
    to: email,
    subject: "Débloquez formation, quiz et glossaire — gratuit",
    html,
    tag: "subscriber_onboarding",
  });
}

/**
 * Step 4 — Dernière newsletter (J+7)
 * Goal: Show a real newsletter preview, push to subscribe
 */
export async function sendSubscriberStep4(email: string): Promise<boolean> {
  const html = buildWmbEmailHtml({
    title: "Voici ce que vous avez manqué dimanche dernier",
    preheader: "La dernière édition WMB — tendance, chiffres, risques de la semaine.",
    bodyHtml: `
      <p style="font-size:15px;color:${TEXT_DARK};line-height:1.7;margin:0 0 16px;">
        Chaque dimanche &agrave; 09h00, nos abonn&eacute;s re&ccedil;oivent un deck complet. Voici un extrait de la derni&egrave;re &eacute;dition :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:16px;background-color:#111318;border-radius:8px;">
            <p style="margin:0 0 8px;font-weight:700;font-size:14px;color:#FFFFFF;">Derni&egrave;re &eacute;dition</p>
            <p style="margin:0 0 4px;font-size:12px;color:${GOLD};">R&eacute;gime : Haussier prudent</p>
            <p style="margin:0 0 4px;font-size:12px;color:#9CA3AF;">S&amp;P 500 : tendance positive, VIX stable</p>
            <p style="margin:0 0 4px;font-size:12px;color:#9CA3AF;">Catalyseur : r&eacute;sultats tech + donn&eacute;es emploi</p>
            <p style="margin:0;font-size:12px;color:#EF4444;">Risque : tensions g&eacute;opolitiques + inflation sticky</p>
          </td>
        </tr>
      </table>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 24px;">
        Pour recevoir l'&eacute;dition compl&egrave;te chaque dimanche, cr&eacute;ez votre compte et choisissez votre formule :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
        <tr>
          <td align="center">
            <a href="${SITE_URL}/pricing" style="display:inline-block;padding:12px 28px;background-color:${GOLD};color:#FFFFFF;font-weight:700;font-size:14px;text-decoration:none;border-radius:6px;">
              D&eacute;couvrir les offres
            </a>
          </td>
        </tr>
      </table>
    `,
  });

  return sendEmail({
    to: email,
    subject: "Ce que vous avez manqué dimanche dernier",
    html,
    tag: "subscriber_onboarding",
  });
}

/**
 * Step 5 — Social proof + offre finale (J+14)
 * Goal: Final push with social proof and urgency
 */
export async function sendSubscriberStep5(email: string): Promise<boolean> {
  const html = buildWmbEmailHtml({
    title: "Pourquoi des centaines d'investisseurs lisent WMB chaque dimanche",
    preheader: "Rejoignez une communauté d'investisseurs qui gagnent du temps et de la clarté.",
    bodyHtml: `
      <p style="font-size:15px;color:${TEXT_DARK};line-height:1.7;margin:0 0 20px;">
        Des centaines d'investisseurs ont choisi WMB pour rester inform&eacute;s sans y passer des heures.
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};border-left:3px solid ${BLUE};">
            <p style="margin:0 0 4px;font-size:13px;color:${TEXT_BODY};font-style:italic;">&laquo; Je lis WMB chaque dimanche matin avec mon caf&eacute;. En 15 minutes, j'ai une vision claire de la semaine. &raquo;</p>
            <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};">&mdash; Investisseur particulier, Suisse</p>
          </td>
        </tr>
        <tr><td style="height:8px;"></td></tr>
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};border-left:3px solid ${GOLD};">
            <p style="margin:0 0 4px;font-size:13px;color:${TEXT_BODY};font-style:italic;">&laquo; Avant WMB, je passais 3h le dimanche &agrave; lire des articles. Maintenant, tout est l&agrave;, structur&eacute;, en un seul document. &raquo;</p>
            <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};">&mdash; Trader ind&eacute;pendant, France</p>
          </td>
        </tr>
      </table>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:16px;background-color:#111318;border-radius:8px;text-align:center;">
            <p style="margin:0 0 4px;font-size:24px;font-weight:700;color:${GOLD};">CHF 49/mois</p>
            <p style="margin:0;font-size:12px;color:#9CA3AF;">Newsletter + Formation + Briefing Quotidien + Tous les outils</p>
          </td>
        </tr>
      </table>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 24px;">
        Rejoignez-nous et commencez &agrave; gagner du temps et de la clart&eacute; :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
        <tr>
          <td align="center">
            <a href="${SITE_URL}/pricing" style="display:inline-block;padding:12px 28px;background-color:${GOLD};color:#FFFFFF;font-weight:700;font-size:14px;text-decoration:none;border-radius:6px;">
              Rejoindre WMB maintenant
            </a>
          </td>
        </tr>
      </table>
    `,
  });

  return sendEmail({
    to: email,
    subject: "Pourquoi des centaines d'investisseurs lisent WMB",
    html,
    tag: "subscriber_onboarding",
  });
}

/**
 * Step 6 — Rappel Briefing Quotidien (J+14)
 * Goal: Highlight the daily briefing feature to re-engage
 */
export async function sendSubscriberStep6(email: string): Promise<boolean> {
  const html = buildWmbEmailHtml({
    title: "Chaque matin, un briefing en 2 minutes",
    preheader: "Le Briefing Quotidien WMB — les 5 chiffres qui comptent avant l'ouverture.",
    bodyHtml: `
      <p style="font-size:15px;color:${TEXT_DARK};line-height:1.7;margin:0 0 16px;">
        Saviez-vous que nos abonn&eacute;s re&ccedil;oivent aussi un <strong>Briefing Quotidien</strong> chaque matin ?
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GOLD};border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0 0 8px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Briefing Quotidien &mdash; chaque matin &agrave; 07h30</p>
            <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.6;">
              &bull; Futures US &amp; Europe avant l'ouverture<br/>
              &bull; Chiffres macro du jour (CPI, emploi, Fed...)<br/>
              &bull; Earnings &agrave; surveiller<br/>
              &bull; Risques &amp; catalyseurs de la journ&eacute;e<br/>
              &bull; Sentiment march&eacute; (VIX, put/call, flux)
            </p>
          </td>
        </tr>
      </table>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 24px;">
        2 minutes de lecture, chaque matin, pour commencer la journ&eacute;e inform&eacute;. Inclus dans l'abonnement premium.
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
        <tr>
          <td align="center">
            <a href="${SITE_URL}/briefing-quotidien" style="display:inline-block;padding:12px 28px;background-color:${GOLD};color:#FFFFFF;font-weight:700;font-size:14px;text-decoration:none;border-radius:6px;">
              D&eacute;couvrir le Briefing Quotidien
            </a>
          </td>
        </tr>
      </table>
    `,
  });

  return sendEmail({
    to: email,
    subject: "Chaque matin, un briefing marchés en 2 minutes",
    html,
    tag: "subscriber_onboarding",
  });
}

/**
 * Step 7 — Dernière chance + offre spéciale (J+18)
 * Goal: Final urgency push with exclusive offer
 */
export async function sendSubscriberStep7(email: string): Promise<boolean> {
  const html = buildWmbEmailHtml({
    title: "Dernière relance — votre accès WMB vous attend",
    preheader: "On ne vous relancera plus après cet email. Voici ce que vous manquez chaque semaine.",
    bodyHtml: `
      <p style="font-size:15px;color:${TEXT_DARK};line-height:1.7;margin:0 0 16px;">
        C'est notre dernier email de cette s&eacute;rie. Apr&egrave;s celui-ci, on vous laisse tranquille un moment.
      </p>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 20px;">
        Voici un r&eacute;cap de tout ce que WMB vous offre :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
            <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
              <tr>
                <td style="padding:4px 0;font-size:13px;color:${GREEN};">&#10003; Newsletter hebdo (20-25 slides PDF)</td>
              </tr>
              <tr>
                <td style="padding:4px 0;font-size:13px;color:${GREEN};">&#10003; Briefing Quotidien (chaque matin)</td>
              </tr>
              <tr>
                <td style="padding:4px 0;font-size:13px;color:${GREEN};">&#10003; Th&egrave;me du Mois (analyse approfondie)</td>
              </tr>
              <tr>
                <td style="padding:4px 0;font-size:13px;color:${GREEN};">&#10003; Formation compl&egrave;te (7 modules, 437+ le&ccedil;ons)</td>
              </tr>
              <tr>
                <td style="padding:4px 0;font-size:13px;color:${GREEN};">&#10003; Glossaire (1 007+ termes)</td>
              </tr>
              <tr>
                <td style="padding:4px 0;font-size:13px;color:${GREEN};">&#10003; Tous les outils (quiz, simulateur, indicateurs)</td>
              </tr>
            </table>
          </td>
        </tr>
      </table>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:16px;background-color:#111318;border-radius:8px;text-align:center;">
            <p style="margin:0 0 4px;font-size:24px;font-weight:700;color:${GOLD};">CHF 49/mois</p>
            <p style="margin:0 0 4px;font-size:13px;color:#9CA3AF;">ou CHF 399/an (2 mois offerts)</p>
            <p style="margin:0;font-size:11px;color:#6B7280;">Annulation en 1 clic &bull; Sans engagement</p>
          </td>
        </tr>
      </table>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
        <tr>
          <td align="center">
            <a href="${SITE_URL}/pricing" style="display:inline-block;padding:12px 28px;background-color:${GOLD};color:#FFFFFF;font-weight:700;font-size:14px;text-decoration:none;border-radius:6px;">
              Voir les offres
            </a>
          </td>
        </tr>
      </table>

      <p style="font-size:12px;color:${TEXT_CAPTION};line-height:1.6;margin:20px 0 0;text-align:center;">
        On vous recontactera dans quelques semaines. D'ici l&agrave;, vous continuez &agrave; recevoir la newsletter gratuite.
      </p>
    `,
  });

  return sendEmail({
    to: email,
    subject: "Dernière relance — tout WMB pour CHF 49/mois",
    html,
    tag: "subscriber_onboarding",
  });
}
