/**
 * One-shot script: Send email with the two latest editions to paid subscribers
 * Usage: node send-editions-email.mjs
 */
import 'dotenv/config';
import nodemailer from 'nodemailer';
import mysql from 'mysql2/promise';

// ═══════════ CONFIG ═══════════

const SITE_URL = "https://wmbmarket-wf8nj4yl.manus.space";
const LOGO_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/kYEPPfxXLhxbLFSH.png";

const EDITION_09 = {
  weekNumber: 9,
  title: "Tensions sur les Taux & Test IA — Le Marché à la Croisée des Chemins",
  subtitle: "PCE Core, NVIDIA earnings, Fed speakers",
  dateRange: "LUN 23/02 → VEN 27/02",
  slideCount: 25,
  pdfUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/jEjpOTTUufBKknDl.pdf",
  viewUrl: `${SITE_URL}/brief/1`,
};

const EDITION_08 = {
  weekNumber: 8,
  title: "Walmart Alerte & Tarifs Automobiles — Rotation Défensive",
  subtitle: "Walmart avertit, tarifs auto 25%, minutes FOMC hawkish",
  dateRange: "LUN 16/02 → VEN 20/02",
  slideCount: 23,
  pdfUrl: null,
  viewUrl: `${SITE_URL}/brief/2`,
};

// ═══════════ EMAIL HTML ═══════════

function buildEditionBlock(edition, index) {
  const pdfButton = edition.pdfUrl
    ? `<a href="${edition.pdfUrl}" style="display:inline-block;background-color:#D4A853;color:#0C1018;text-decoration:none;font-size:13px;font-weight:700;padding:10px 24px;border-radius:8px;letter-spacing:0.3px;margin-right:8px;">Télécharger le PDF</a>`
    : '';
  
  const viewButton = `<a href="${edition.viewUrl}" style="display:inline-block;background-color:#344453;color:#FFFFFF;text-decoration:none;font-size:13px;font-weight:600;padding:10px 24px;border-radius:8px;letter-spacing:0.3px;">Lire en ligne</a>`;

  return `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin-bottom:${index === 0 ? '28' : '0'}px;">
      <tr>
        <td style="background-color:#F4F5F5;border-radius:12px;padding:24px;border:1px solid #E1E6EA;">
          <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
            <tr>
              <td>
                <span style="display:inline-block;background-color:#344453;color:#FFFFFF;font-size:10px;font-weight:700;padding:4px 10px;border-radius:6px;text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;">
                  Semaine ${edition.weekNumber} — ${edition.slideCount} slides
                </span>
              </td>
            </tr>
            <tr>
              <td style="padding-top:12px;">
                <h2 style="margin:0;color:#344453;font-size:17px;font-weight:700;line-height:1.3;">${edition.title}</h2>
              </td>
            </tr>
            <tr>
              <td style="padding-top:6px;">
                <p style="margin:0;color:#1E1E1E;opacity:0.6;font-size:13px;line-height:1.5;">${edition.subtitle}</p>
              </td>
            </tr>
            <tr>
              <td style="padding-top:4px;">
                <p style="margin:0;color:#1E1E1E;opacity:0.4;font-size:12px;">${edition.dateRange}</p>
              </td>
            </tr>
            <tr>
              <td style="padding-top:16px;">
                ${pdfButton}${viewButton}
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>`;
}

function buildFullEmailHtml() {
  const bodyHtml = `
    <p style="margin:0 0 20px;color:#1E1E1E;font-size:15px;line-height:1.75;">
      Bonjour,
    </p>
    <p style="margin:0 0 24px;color:#1E1E1E;font-size:15px;line-height:1.75;">
      Voici vos <strong>deux dernières éditions</strong> du WallStreet Market Brief. Comme chaque semaine, vous y trouverez l'essentiel des marchés US : tendance, chiffres clés, catalyseurs et risques — structurés, sourcés, neutres.
    </p>

    ${buildEditionBlock(EDITION_09, 0)}

    <div style="height:1px;background-color:#E1E6EA;margin:24px 0;"></div>

    ${buildEditionBlock(EDITION_08, 1)}

    <div style="height:24px;"></div>
    <p style="margin:0;color:#1E1E1E;opacity:0.6;font-size:13px;line-height:1.6;">
      Bonne lecture et bonne semaine sur les marchés.
    </p>
    <p style="margin:12px 0 0;color:#1E1E1E;font-size:14px;font-weight:600;">
      — L'équipe WMB
    </p>
  `;

  return `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <span style="display:none;max-height:0;overflow:hidden;mso-hide:all;">Vos deux dernières éditions WMB — Semaines 08 & 09</span>
  <style>
    body { margin: 0; padding: 0; background-color: #0A0C12; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased; }
    a { color: #D4A853; }
    @media only screen and (max-width: 620px) {
      .email-container { width: 100% !important; }
      .email-padding { padding-left: 24px !important; padding-right: 24px !important; }
    }
  </style>
</head>
<body style="margin:0;padding:0;background-color:#0A0C12;">
  <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:#0A0C12;padding:32px 16px;">
    <tr>
      <td align="center">
        <table class="email-container" width="600" cellpadding="0" cellspacing="0" role="presentation" style="max-width:600px;width:100%;background-color:#FFFFFF;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.3);">
          
          <!-- HEADER -->
          <tr>
            <td style="background-color:#0C1018;padding:28px 40px 24px;" class="email-padding">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
                <tr><td align="center"><img src="${LOGO_URL}" alt="WMB" width="44" height="44" style="display:block;border-radius:10px;margin-bottom:12px;" /></td></tr>
                <tr><td align="center"><span style="color:#FFFFFF;font-size:18px;font-weight:700;letter-spacing:1px;">WALLSTREET MARKET BRIEF</span></td></tr>
                <tr><td align="center" style="padding-top:6px;"><span style="color:rgba(255,255,255,0.25);font-size:10px;text-transform:uppercase;letter-spacing:3px;">Newsletter Marchés Financiers</span></td></tr>
              </table>
            </td>
          </tr>

          <!-- GOLD LINE -->
          <tr>
            <td style="background-color:#0C1018;padding:0 40px;" class="email-padding">
              <div style="height:2px;background:linear-gradient(90deg,transparent,#D4A853,transparent);"></div>
            </td>
          </tr>

          <!-- TITLE -->
          <tr>
            <td style="background-color:#344453;padding:20px 40px;" class="email-padding">
              <h1 style="margin:0;color:#FFFFFF;font-size:20px;font-weight:600;line-height:1.4;">Vos éditions Semaine 08 & 09</h1>
            </td>
          </tr>

          <!-- BODY -->
          <tr>
            <td style="padding:32px 40px;color:#1E1E1E;font-size:15px;line-height:1.75;background-color:#FFFFFF;" class="email-padding">
              ${bodyHtml}
            </td>
          </tr>

          <!-- DIVIDER -->
          <tr>
            <td style="padding:0 40px;background-color:#FFFFFF;" class="email-padding">
              <div style="height:1px;background-color:#E1E6EA;"></div>
            </td>
          </tr>

          <!-- FOOTER -->
          <tr>
            <td style="padding:24px 40px 20px;background-color:#FFFFFF;" class="email-padding">
              <p style="margin:0;color:rgba(30,30,30,0.4);font-size:12px;line-height:1.6;text-align:center;">
                Vous recevez cet email car vous êtes abonné(e) premium à WallStreet Market Brief.
              </p>
            </td>
          </tr>

          <!-- BOTTOM BAR -->
          <tr>
            <td style="background-color:#0C1018;padding:20px 40px;" class="email-padding">
              <p style="margin:0;color:rgba(255,255,255,0.2);font-size:10px;line-height:1.6;letter-spacing:0.5px;text-align:center;">
                WallStreet Market Brief — Newsletter Marchés Financiers<br>
                Ce contenu est purement informatif et ne constitue pas un conseil en investissement.<br>
                <a href="${SITE_URL}/mentions-legales" style="color:rgba(255,255,255,0.3);text-decoration:underline;">Mentions légales</a>
              </p>
            </td>
          </tr>

        </table>

        <table width="600" cellpadding="0" cellspacing="0" role="presentation" style="max-width:600px;width:100%;margin-top:16px;">
          <tr>
            <td align="center">
              <p style="margin:0;color:rgba(255,255,255,0.15);font-size:10px;">
                &copy; 2026 WallStreet Market Brief. Tous droits réservés.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

// ═══════════ MAIN ═══════════

async function main() {
  console.log("[Send Editions] Starting...");

  // 1. Connect to DB
  const dbUrl = process.env.DATABASE_URL;
  if (!dbUrl) {
    console.error("[Send Editions] DATABASE_URL not set");
    process.exit(1);
  }

  const connection = await mysql.createConnection(dbUrl);

  // 2. Get paid subscribers
  const [rows] = await connection.execute(
    "SELECT id, email, name FROM users WHERE subscriptionActive = 1 AND email IS NOT NULL"
  );

  const subscribers = rows;
  console.log(`[Send Editions] Found ${subscribers.length} paid subscriber(s)`);

  if (subscribers.length === 0) {
    console.log("[Send Editions] No paid subscribers found. Exiting.");
    await connection.end();
    return;
  }

  // 3. Build email
  const html = buildFullEmailHtml();
  const subject = "WMB — Vos éditions Semaine 08 & 09 sont disponibles";

  // 4. Create transporter
  const transporter = nodemailer.createTransport({
    host: process.env.BREVO_SMTP_HOST || "smtp-relay.brevo.com",
    port: parseInt(process.env.BREVO_SMTP_PORT || "587", 10),
    secure: false,
    auth: {
      user: process.env.BREVO_SMTP_LOGIN,
      pass: process.env.BREVO_SMTP_PASSWORD,
    },
  });

  // 5. Send to each subscriber
  let sent = 0;
  let failed = 0;

  for (const sub of subscribers) {
    try {
      const info = await transporter.sendMail({
        from: '"WallStreet Market Brief" <contact@wallstreetmarketbrief.ch>',
        replyTo: "contact@wallstreetmarketbrief.ch",
        to: sub.email,
        subject,
        html,
      });
      console.log(`[Send Editions] ✓ Sent to ${sub.email} (${sub.name || 'N/A'}) — ${info.messageId}`);
      sent++;
    } catch (err) {
      console.error(`[Send Editions] ✗ Failed for ${sub.email}:`, err.message);
      failed++;
    }
  }

  console.log(`\n[Send Editions] Done — ${sent} sent, ${failed} failed`);
  await connection.end();
}

main().catch((err) => {
  console.error("[Send Editions] Fatal error:", err);
  process.exit(1);
});
