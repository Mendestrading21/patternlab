/**
 * Send Week 12 email campaign V3 — PREMIUM DESIGN
 * Via Brevo SMTP — All subscribers (users + newsletter)
 */
import 'dotenv/config';
import nodemailer from 'nodemailer';
import mysql from 'mysql2/promise';

const SITE_URL = "https://wallstreetmarketbrief.ch";

const transporter = nodemailer.createTransport({
  host: process.env.BREVO_SMTP_HOST || "smtp-relay.brevo.com",
  port: 465,
  secure: true,
  connectionTimeout: 10000,
  greetingTimeout: 10000,
  auth: {
    user: process.env.BREVO_SMTP_LOGIN,
    pass: process.env.BREVO_SMTP_PASSWORD,
  },
});

async function getDb() {
  return await mysql.createConnection(process.env.DATABASE_URL);
}

const SUBJECT = "WMB | Semaine 12 — S&P 500 sur la MM200, Brent >100$, FOMC en vue";

function buildPremiumEmail() {
  const year = new Date().getFullYear();
  
  return `<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <meta name="color-scheme" content="light dark"/>
  <meta name="supported-color-schemes" content="light dark"/>
  <title>${SUBJECT}</title>
  <!--[if mso]>
  <style>table{border-collapse:collapse;}td{padding:0;}</style>
  <![endif]-->
  <style>
    body,table,td,a{-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;}
    table,td{mso-table-lspace:0;mso-table-rspace:0;}
    body{margin:0;padding:0;width:100%!important;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;background-color:#0A0C12!important;}
    @media only screen and (max-width:620px){
      .outer{width:100%!important;}
      .pad{padding-left:16px!important;padding-right:16px!important;}
      .h1{font-size:20px!important;line-height:1.3!important;}
      .h2{font-size:16px!important;}
      .data-table td{padding:8px 8px!important;font-size:12px!important;}
      .mod-table td{padding:8px 8px!important;font-size:12px!important;}
      .cta-btn{padding:12px 28px!important;font-size:13px!important;}
      .body-text{font-size:13px!important;}
      .small-text{font-size:11px!important;}
    }
    @media(prefers-color-scheme:dark){
      body{background-color:#0A0C12!important;}
      .email-bg{background-color:#0A0C12!important;}
      .card-bg{background-color:#FFFFFF!important;}
      [data-ogsc] .card-bg{background-color:#FFFFFF!important;}
    }
    u+.body .email-bg{background-color:#0A0C12!important;}
  </style>
</head>
<body class="body" style="margin:0;padding:0;background-color:#0A0C12;">
  <table width="100%" cellpadding="0" cellspacing="0" role="presentation" class="email-bg" style="background-color:#0A0C12;padding:24px 8px;">
    <tr>
      <td align="center">
        <!-- ═══════ MAIN CARD ═══════ -->
        <table class="outer" width="600" cellpadding="0" cellspacing="0" role="presentation" style="max-width:600px;width:100%;border-radius:12px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,0.4);">
          
          <!-- ═══ HEADER — Dark ═══ -->
          <tr>
            <td style="background-color:#0C1018;padding:36px 44px 12px;" class="pad" align="center">
              <table cellpadding="0" cellspacing="0" role="presentation">
                <tr><td align="center"><span style="font-size:24px;font-weight:800;letter-spacing:8px;color:#ffffff;display:block;">WALLSTREET</span></td></tr>
                <tr><td align="center" style="padding-top:4px;"><span style="font-size:11px;font-weight:600;letter-spacing:6px;color:#9a8560;display:block;">MARKET BRIEF</span></td></tr>
              </table>
            </td>
          </tr>
          <!-- Gold accent line -->
          <tr><td style="background-color:#0C1018;padding:12px 44px 0;" class="pad"><div style="height:2px;background:linear-gradient(90deg,transparent 0%,#9a8560 30%,#C4A052 50%,#9a8560 70%,transparent 100%);"></div></td></tr>
          <!-- Edition badge -->
          <tr>
            <td style="background-color:#0C1018;padding:16px 44px 28px;" class="pad" align="center">
              <table cellpadding="0" cellspacing="0" role="presentation" style="border:1px solid rgba(154,133,96,0.3);border-radius:20px;padding:6px 18px;">
                <tr><td><span style="font-size:10px;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,0.4);">Semaine 12 &bull; 10 &ndash; 14 mars 2026</span></td></tr>
              </table>
            </td>
          </tr>

          <!-- ═══ BODY — White card ═══ -->
          <!-- Title -->
          <tr>
            <td class="card-bg" style="background-color:#FFFFFF;padding:32px 44px 0;" class="pad">
              <h1 class="h1" style="margin:0;font-size:22px;font-weight:800;line-height:1.35;color:#1a1a1a;">Correction Officielle, Broadcom Record et Rotation &Eacute;nergie</h1>
              <p style="margin:8px 0 0;font-size:13px;color:#9a8560;font-weight:600;letter-spacing:0.5px;">S&amp;P -10% depuis le sommet &bull; Brent >100$ &bull; FOMC cette semaine</p>
            </td>
          </tr>

          <!-- Divider -->
          <tr><td class="card-bg" style="background-color:#FFFFFF;padding:20px 44px 0;" class="pad"><div style="height:1px;background:linear-gradient(90deg,transparent,#e2e8f0,transparent);"></div></td></tr>

          <!-- Lecture WMB — Editorial summary -->
          <tr>
            <td class="card-bg" style="background-color:#FFFFFF;padding:20px 44px 0;" class="pad">
              <table cellpadding="0" cellspacing="0" role="presentation" style="width:100%;border-left:3px solid #9a8560;padding-left:16px;">
                <tr><td>
                  <p style="margin:0 0 4px;font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#9a8560;">Lecture WMB</p>
                  <p class="body-text" style="margin:0;font-size:14px;line-height:1.7;color:#4a5568;">Le S&amp;P 500 &agrave; 6 632 est sur sa moyenne mobile 200 jours &mdash; un niveau qui d&eacute;termine historiquement si une correction reste contenue ou s'acc&eacute;l&egrave;re. Le PIB Q4 &agrave; 0,7%, le NFP &agrave; -92K et le p&eacute;trole au-dessus de 100$ forment un cocktail stagflationniste. Le FOMC de cette semaine sera le juge de paix.</p>
                </td></tr>
              </table>
            </td>
          </tr>

          <!-- Points clés -->
          <tr>
            <td class="card-bg" style="background-color:#FFFFFF;padding:28px 44px 0;" class="pad">
              <h2 class="h2" style="margin:0 0 16px;font-size:17px;font-weight:700;color:#344453;letter-spacing:0.3px;">Points cl&eacute;s de la semaine</h2>
              <table cellpadding="0" cellspacing="0" role="presentation" style="width:100%;">
                <tr>
                  <td style="padding:0 0 12px;">
                    <table cellpadding="0" cellspacing="0" role="presentation"><tr>
                      <td style="width:6px;height:6px;background-color:#B0413E;border-radius:50;vertical-align:top;padding-top:7px;"></td>
                      <td style="padding-left:10px;"><span class="body-text" style="font-size:14px;line-height:1.6;color:#4a5568;"><strong style="color:#1a1a1a;">S&amp;P 500 &agrave; 6 632</strong> (<span style="color:#B0413E;font-weight:600;">-1,6%</span>) &mdash; pile sur la MM200, 3&egrave;me semaine de baisse</span></td>
                    </tr></table>
                  </td>
                </tr>
                <tr>
                  <td style="padding:0 0 12px;">
                    <table cellpadding="0" cellspacing="0" role="presentation"><tr>
                      <td style="width:6px;height:6px;background-color:#B0413E;border-radius:50;vertical-align:top;padding-top:7px;"></td>
                      <td style="padding-left:10px;"><span class="body-text" style="font-size:14px;line-height:1.6;color:#4a5568;"><strong style="color:#1a1a1a;">Brent au-dessus de 100$/baril</strong> &mdash; D&eacute;troit d'Ormuz quasi ferm&eacute;, +40% depuis le conflit</span></td>
                    </tr></table>
                  </td>
                </tr>
                <tr>
                  <td style="padding:0 0 12px;">
                    <table cellpadding="0" cellspacing="0" role="presentation"><tr>
                      <td style="width:6px;height:6px;background-color:#B0413E;border-radius:50;vertical-align:top;padding-top:7px;"></td>
                      <td style="padding-left:10px;"><span class="body-text" style="font-size:14px;line-height:1.6;color:#4a5568;"><strong style="color:#1a1a1a;">PIB Q4 r&eacute;vis&eacute; &agrave; 0,7%</strong> (contre 1,4%) &mdash; signal de stagflation</span></td>
                    </tr></table>
                  </td>
                </tr>
                <tr>
                  <td style="padding:0 0 12px;">
                    <table cellpadding="0" cellspacing="0" role="presentation"><tr>
                      <td style="width:6px;height:6px;background-color:#B0413E;border-radius:50;vertical-align:top;padding-top:7px;"></td>
                      <td style="padding-left:10px;"><span class="body-text" style="font-size:14px;line-height:1.6;color:#4a5568;"><strong style="color:#1a1a1a;">VIX &agrave; ~28</strong> &mdash; plus haut de 11 mois, Fear &amp; Greed &agrave; 20 (Extreme Fear)</span></td>
                    </tr></table>
                  </td>
                </tr>
                <tr>
                  <td style="padding:0 0 0;">
                    <table cellpadding="0" cellspacing="0" role="presentation"><tr>
                      <td style="width:6px;height:6px;background-color:#9a8560;border-radius:50;vertical-align:top;padding-top:7px;"></td>
                      <td style="padding-left:10px;"><span class="body-text" style="font-size:14px;line-height:1.6;color:#4a5568;"><strong style="color:#1a1a1a;">FOMC cette semaine</strong> &mdash; dot plot, projections &eacute;co et conf&eacute;rence Powell</span></td>
                    </tr></table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Chiffres clés — Data table -->
          <tr>
            <td class="card-bg" style="background-color:#FFFFFF;padding:28px 44px 0;" class="pad">
              <h2 class="h2" style="margin:0 0 14px;font-size:17px;font-weight:700;color:#344453;letter-spacing:0.3px;">Chiffres cl&eacute;s</h2>
              <table class="data-table" style="width:100%;border-collapse:collapse;font-size:13px;">
                <tr style="background-color:#344453;">
                  <td style="padding:10px 10px;color:#ffffff;font-weight:700;font-size:11px;letter-spacing:0.5px;text-transform:uppercase;border-bottom:2px solid #9a8560;">Indice</td>
                  <td style="padding:10px 10px;color:#ffffff;font-weight:700;font-size:11px;letter-spacing:0.5px;text-transform:uppercase;border-bottom:2px solid #9a8560;text-align:right;">Valeur</td>
                  <td style="padding:10px 10px;color:#ffffff;font-weight:700;font-size:11px;letter-spacing:0.5px;text-transform:uppercase;border-bottom:2px solid #9a8560;text-align:right;">1 sem.</td>
                  <td style="padding:10px 10px;color:#ffffff;font-weight:700;font-size:11px;letter-spacing:0.5px;text-transform:uppercase;border-bottom:2px solid #9a8560;text-align:right;">YTD</td>
                </tr>
                <tr style="background-color:#F8F9FA;">
                  <td style="padding:9px 10px;color:#344453;font-weight:600;border-bottom:1px solid #E8EBF0;">S&amp;P 500</td>
                  <td style="padding:9px 10px;color:#1a1a1a;text-align:right;border-bottom:1px solid #E8EBF0;">6 632</td>
                  <td style="padding:9px 10px;color:#B0413E;font-weight:700;text-align:right;border-bottom:1px solid #E8EBF0;">-1,6%</td>
                  <td style="padding:9px 10px;color:#B0413E;font-weight:600;text-align:right;border-bottom:1px solid #E8EBF0;">-3,1%</td>
                </tr>
                <tr>
                  <td style="padding:9px 10px;color:#344453;font-weight:600;border-bottom:1px solid #E8EBF0;">Nasdaq 100</td>
                  <td style="padding:9px 10px;color:#1a1a1a;text-align:right;border-bottom:1px solid #E8EBF0;">24 380</td>
                  <td style="padding:9px 10px;color:#B0413E;font-weight:700;text-align:right;border-bottom:1px solid #E8EBF0;">-0,2%</td>
                  <td style="padding:9px 10px;color:#B0413E;font-weight:600;text-align:right;border-bottom:1px solid #E8EBF0;">-4,2%</td>
                </tr>
                <tr style="background-color:#F8F9FA;">
                  <td style="padding:9px 10px;color:#344453;font-weight:600;border-bottom:1px solid #E8EBF0;">Dow Jones</td>
                  <td style="padding:9px 10px;color:#1a1a1a;text-align:right;border-bottom:1px solid #E8EBF0;">46 558</td>
                  <td style="padding:9px 10px;color:#B0413E;font-weight:700;text-align:right;border-bottom:1px solid #E8EBF0;">-1,0%</td>
                  <td style="padding:9px 10px;color:#B0413E;font-weight:600;text-align:right;border-bottom:1px solid #E8EBF0;">-2,8%</td>
                </tr>
                <tr>
                  <td style="padding:9px 10px;color:#344453;font-weight:600;border-bottom:1px solid #E8EBF0;">Russell 2000</td>
                  <td style="padding:9px 10px;color:#1a1a1a;text-align:right;border-bottom:1px solid #E8EBF0;">2 480</td>
                  <td style="padding:9px 10px;color:#B0413E;font-weight:700;text-align:right;border-bottom:1px solid #E8EBF0;">-0,9%</td>
                  <td style="padding:9px 10px;color:#B0413E;font-weight:600;text-align:right;border-bottom:1px solid #E8EBF0;">-5,5%</td>
                </tr>
                <tr style="background-color:#F8F9FA;">
                  <td style="padding:9px 10px;color:#344453;font-weight:600;border-bottom:1px solid #E8EBF0;">VIX</td>
                  <td style="padding:9px 10px;color:#1a1a1a;text-align:right;border-bottom:1px solid #E8EBF0;">~28</td>
                  <td colspan="2" style="padding:9px 10px;color:#B0413E;font-weight:700;text-align:right;border-bottom:1px solid #E8EBF0;">Stress &eacute;lev&eacute;</td>
                </tr>
                <!-- Separator -->
                <tr><td colspan="4" style="padding:0;height:3px;background-color:#E8EBF0;"></td></tr>
                <tr>
                  <td style="padding:9px 10px;color:#344453;font-weight:600;border-bottom:1px solid #E8EBF0;">10Y US</td>
                  <td style="padding:9px 10px;color:#1a1a1a;text-align:right;border-bottom:1px solid #E8EBF0;">4,28%</td>
                  <td colspan="2" style="padding:9px 10px;color:#B0413E;font-weight:700;text-align:right;border-bottom:1px solid #E8EBF0;">+14 bps</td>
                </tr>
                <tr style="background-color:#F8F9FA;">
                  <td style="padding:9px 10px;color:#344453;font-weight:600;border-bottom:1px solid #E8EBF0;">Or (XAU)</td>
                  <td style="padding:9px 10px;color:#1a1a1a;text-align:right;border-bottom:1px solid #E8EBF0;">5 020 $/oz</td>
                  <td colspan="2" style="padding:9px 10px;color:#B0413E;font-weight:600;text-align:right;border-bottom:1px solid #E8EBF0;">L&eacute;g. baisse</td>
                </tr>
                <tr>
                  <td style="padding:9px 10px;color:#344453;font-weight:600;border-bottom:1px solid #E8EBF0;">Brent</td>
                  <td style="padding:9px 10px;color:#1a1a1a;text-align:right;border-bottom:1px solid #E8EBF0;">~103 $/b</td>
                  <td colspan="2" style="padding:9px 10px;color:#B0413E;font-weight:700;text-align:right;border-bottom:1px solid #E8EBF0;">+40% (conflit)</td>
                </tr>
                <tr style="background-color:#F8F9FA;">
                  <td style="padding:9px 10px;color:#344453;font-weight:600;">Bitcoin</td>
                  <td style="padding:9px 10px;color:#1a1a1a;text-align:right;">70 800 $</td>
                  <td colspan="2" style="padding:9px 10px;color:#2E7D5B;font-weight:700;text-align:right;">+9% (conflit)</td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Modules disponibles -->
          <tr>
            <td class="card-bg" style="background-color:#FFFFFF;padding:28px 44px 0;" class="pad">
              <h2 class="h2" style="margin:0 0 14px;font-size:17px;font-weight:700;color:#344453;letter-spacing:0.3px;">Modules disponibles</h2>
              <table class="mod-table" style="width:100%;border-collapse:collapse;font-size:13px;">
                <tr style="background-color:#344453;">
                  <td style="padding:10px 10px;color:#ffffff;font-weight:700;font-size:11px;letter-spacing:0.5px;text-transform:uppercase;border-bottom:2px solid #9a8560;width:90px;">Module</td>
                  <td style="padding:10px 10px;color:#ffffff;font-weight:700;font-size:11px;letter-spacing:0.5px;text-transform:uppercase;border-bottom:2px solid #9a8560;">Contenu</td>
                  <td style="padding:10px 10px;color:#ffffff;font-weight:700;font-size:11px;letter-spacing:0.5px;text-transform:uppercase;border-bottom:2px solid #9a8560;text-align:center;width:60px;">Acc&egrave;s</td>
                </tr>
                <tr style="background-color:#F8F9FA;">
                  <td style="padding:10px 10px;color:#344453;font-weight:700;border-bottom:1px solid #E8EBF0;">Brief US</td>
                  <td style="padding:10px 10px;color:#4a5568;border-bottom:1px solid #E8EBF0;">S&amp;P sur MM200, stagflation, FOMC en vue</td>
                  <td style="padding:10px 10px;text-align:center;border-bottom:1px solid #E8EBF0;"><a href="${SITE_URL}/brief/12" style="display:inline-block;padding:4px 12px;background-color:#344453;color:#ffffff;font-size:11px;font-weight:700;text-decoration:none;border-radius:4px;">Lire</a></td>
                </tr>
                <tr>
                  <td style="padding:10px 10px;color:#344453;font-weight:700;border-bottom:1px solid #E8EBF0;">Actions US</td>
                  <td style="padding:10px 10px;color:#4a5568;border-bottom:1px solid #E8EBF0;">Broadcom +108%, Exxon ATH, Tesla -8.5%</td>
                  <td style="padding:10px 10px;text-align:center;border-bottom:1px solid #E8EBF0;"><a href="${SITE_URL}/actions/23" style="display:inline-block;padding:4px 12px;background-color:#344453;color:#ffffff;font-size:11px;font-weight:700;text-decoration:none;border-radius:4px;">Lire</a></td>
                </tr>
                <tr style="background-color:#F8F9FA;">
                  <td style="padding:10px 10px;color:#344453;font-weight:700;border-bottom:1px solid #E8EBF0;">Monde</td>
                  <td style="padding:10px 10px;color:#4a5568;border-bottom:1px solid #E8EBF0;">STOXX 600 en baisse, Nikkei -3.5%, P&eacute;trole >$100</td>
                  <td style="padding:10px 10px;text-align:center;border-bottom:1px solid #E8EBF0;"><a href="${SITE_URL}/monde/105" style="display:inline-block;padding:4px 12px;background-color:#344453;color:#ffffff;font-size:11px;font-weight:700;text-decoration:none;border-radius:4px;">Lire</a></td>
                </tr>
                <tr>
                  <td style="padding:10px 10px;color:#344453;font-weight:700;">Suisse</td>
                  <td style="padding:10px 10px;color:#4a5568;">SMI en correction, BNS &agrave; 0%, CHF fort</td>
                  <td style="padding:10px 10px;text-align:center;"><a href="${SITE_URL}/suisse/205" style="display:inline-block;padding:4px 12px;background-color:#344453;color:#ffffff;font-size:11px;font-weight:700;text-decoration:none;border-radius:4px;">Lire</a></td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Semaine à venir -->
          <tr>
            <td class="card-bg" style="background-color:#FFFFFF;padding:28px 44px 0;" class="pad">
              <h2 class="h2" style="margin:0 0 14px;font-size:17px;font-weight:700;color:#344453;letter-spacing:0.3px;">Semaine &agrave; venir</h2>
              <table style="width:100%;border-collapse:collapse;font-size:13px;">
                <tr>
                  <td style="padding:6px 0;color:#344453;font-weight:700;width:80px;vertical-align:top;">Mercredi</td>
                  <td style="padding:6px 0;color:#4a5568;">FOMC &mdash; D&eacute;cision de taux, dot plot, projections &eacute;co, conf&eacute;rence Powell <span style="color:#B0413E;font-weight:700;">[!]</span></td>
                </tr>
                <tr>
                  <td style="padding:6px 0;color:#344453;font-weight:700;vertical-align:top;">Jeudi</td>
                  <td style="padding:6px 0;color:#4a5568;">Jobless Claims &bull; Earnings : Micron (MU), Dollar Tree (DLTR)</td>
                </tr>
                <tr>
                  <td style="padding:6px 0;color:#344453;font-weight:700;vertical-align:top;">Vendredi</td>
                  <td style="padding:6px 0;color:#4a5568;">Quadruple Witching <span style="color:#B0413E;font-weight:700;">[!]</span> &bull; Earnings : FedEx (FDX), Carnival (CCL)</td>
                </tr>
                <tr>
                  <td style="padding:6px 0;color:#344453;font-weight:700;vertical-align:top;">Global</td>
                  <td style="padding:6px 0;color:#4a5568;">7 banques centrales &bull; Tencent &amp; Alibaba earnings</td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- CTA Button -->
          <tr>
            <td class="card-bg" style="background-color:#FFFFFF;padding:32px 44px 0;" class="pad" align="center">
              <table cellpadding="0" cellspacing="0" role="presentation">
                <tr><td style="border-radius:8px;background:linear-gradient(135deg,#344453 0%,#2a3742 100%);box-shadow:0 4px 12px rgba(52,68,83,0.3);">
                  <a class="cta-btn" href="${SITE_URL}/dashboard" style="display:inline-block;padding:15px 40px;color:#ffffff;font-size:14px;font-weight:700;text-decoration:none;letter-spacing:0.5px;">Acc&eacute;der &agrave; mon Dashboard &rarr;</a>
                </td></tr>
              </table>
            </td>
          </tr>

          <!-- Spacer -->
          <tr><td class="card-bg" style="background-color:#FFFFFF;padding:32px 0 0;"></td></tr>

          <!-- Disclaimer -->
          <tr>
            <td class="card-bg" style="background-color:#FFFFFF;padding:0 44px;" class="pad">
              <div style="height:1px;background:linear-gradient(90deg,transparent,#e2e8f0,transparent);"></div>
            </td>
          </tr>
          <tr>
            <td class="card-bg" style="background-color:#FFFFFF;padding:16px 44px 12px;" class="pad" align="center">
              <p class="small-text" style="margin:0;font-size:11px;color:#94a3b8;line-height:1.6;">Ce contenu est publi&eacute; &agrave; titre informatif et &eacute;ducatif uniquement.<br>Il ne constitue en aucun cas un conseil en investissement.</p>
            </td>
          </tr>

          <!-- Footer links -->
          <tr>
            <td class="card-bg" style="background-color:#FFFFFF;padding:0 44px 20px;" class="pad" align="center">
              <p style="margin:0;font-size:10px;color:#c0c0c0;line-height:1.5;">
                <a href="${SITE_URL}/dashboard" style="color:#94a3b8;text-decoration:underline;">Mon espace</a>
                &nbsp;&middot;&nbsp;
                <a href="${SITE_URL}/compte" style="color:#94a3b8;text-decoration:underline;">Pr&eacute;f&eacute;rences</a>
                &nbsp;&middot;&nbsp;
                <a href="${SITE_URL}/mentions-legales" style="color:#94a3b8;text-decoration:underline;">Mentions l&eacute;gales</a>
              </p>
            </td>
          </tr>

          <!-- Dark bottom bar -->
          <tr>
            <td style="background-color:#0C1018;padding:16px 44px;" class="pad" align="center">
              <p style="margin:0;color:rgba(255,255,255,0.12);font-size:9px;line-height:1.6;letter-spacing:0.3px;">
                &copy; ${year} WallStreet Market Brief &bull; Tous droits r&eacute;serv&eacute;s
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

// ═══════════ MAIN ═══════════
async function main() {
  console.log("[WMB] Starting Week 12 email campaign V3 (PREMIUM) via Brevo...");
  
  try {
    await transporter.verify();
    console.log("[WMB] ✓ SMTP connection verified");
  } catch (err) {
    console.error("[WMB] ✗ SMTP connection failed:", err.message);
    process.exit(1);
  }

  const db = await getDb();
  const [userRows] = await db.execute("SELECT DISTINCT email FROM users WHERE email IS NOT NULL AND email != ''");
  const [subscriberRows] = await db.execute("SELECT DISTINCT email FROM newsletterSubscribers WHERE unsubscribed = 0");
  
  const allEmails = new Set();
  for (const row of userRows) allEmails.add(row.email.toLowerCase().trim());
  for (const row of subscriberRows) allEmails.add(row.email.toLowerCase().trim());
  
  const recipients = [...allEmails].filter(e => e && e.includes('@'));
  console.log(`[WMB] Found ${userRows.length} users + ${subscriberRows.length} subscribers = ${recipients.length} unique recipients`);
  
  if (recipients.length === 0) {
    console.log("[WMB] No recipients found.");
    await db.end();
    process.exit(0);
  }

  const html = buildPremiumEmail();
  let sent = 0, failed = 0;
  const errors = [];

  for (const email of recipients) {
    try {
      await transporter.sendMail({
        from: '"WallStreet Market Brief" <contact@wallstreetmarketbrief.ch>',
        replyTo: 'contact@wallstreetmarketbrief.ch',
        to: email,
        subject: SUBJECT,
        html,
      });
      sent++;
      console.log(`[WMB] ✓ ${email} (${sent}/${recipients.length})`);
    } catch (err) {
      failed++;
      errors.push(email);
      console.error(`[WMB] ✗ ${email} — ${err.message}`);
    }
  }

  console.log(`\n[WMB] ═══ V3 PREMIUM COMPLETE ═══`);
  console.log(`[WMB] Total: ${recipients.length} | Sent: ${sent} | Failed: ${failed}`);
  if (errors.length) console.log(`[WMB] Failed: ${errors.join(', ')}`);

  await db.end();
  process.exit(0);
}

main().catch(err => { console.error("[WMB] Fatal:", err); process.exit(1); });
