/**
 * WMB Email Templates V10 — "Dark Shell + Light Core"
 * ────────────────────────────────────────────────────
 * Unified, responsive, premium email templates for all modules.
 * Consistent branding across: Module USA, Actions US, Monde, Suisse, Theme du Mois.
 * Optimized for: Desktop, iPad, iPhone — all email clients.
 *
 * Design V10 — Dark Shell + Light Core:
 * - Outer bg: #F5F5F5 (light grey)
 * - Header: #111318 dark shell + logo + gold accent line
 * - Body: #FFFFFF white — inverts to dark automatically in dark mode = perfect
 * - Cards/stats: #F7F8FA with subtle borders
 * - Text: #1A1A1A dark on light bg
 * - Accents: gold, green, red, blue per module
 * - Footer: links on light bg, disclaimer on dark #111318
 * - Max-width 600px, fluid on mobile
 * - Zero emoji in content
 */

const SITE_URL = "https://wallstreetmarketbrief.ch";

// ═══════════ DESIGN TOKENS V10 — Dark Shell + Light Core ═══════════
const SHELL_BG = "#111318";       // Header + footer dark background
const BODY_BG = "#FFFFFF";        // Main content background
const OUTER_BG = "#F5F5F5";       // Email outer background
const CARD_BG = "#F7F8FA";        // Elevated cards inside body
const CARD_ELEVATED = "#F0F2F5";  // Deeper cards / stat boxes
const BORDER_LIGHT = "#E5E7EB";   // Subtle borders
const TEXT_DARK = "#1A1A1A";      // Primary text on light bg
const TEXT_BODY = "#374151";      // Body text on light bg
const TEXT_CAPTION = "#6B7280";   // Captions, secondary on light bg
const TEXT_LIGHT = "#E8E8E8";     // Text on dark bg (header/footer)
const TEXT_DIM = "#9CA3AF";       // Muted text on dark bg
const GOLD = "#C8A960";           // Brand accent
const GREEN = "#16A34A";          // Positive — darker green for light bg readability
const RED = "#DC2626";            // Negative — darker red for light bg readability
const FONT_STACK = "'Helvetica Neue',Helvetica,Arial,sans-serif";

// White logo on transparent bg — for dark CSS header; Outlook dark mode inverts both bg + logo
const LOGO_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/QjZjRYVzCmdXGAxs.png";

// ═══════════ MODULE COLOR MAP ═══════════

export const MODULE_COLORS: Record<string, { accent: string; accentLight: string; label: string; emoji: string }> = {
  marche: { accent: "#16A34A", accentLight: "rgba(22,163,74,0.08)", label: "MODULE MARCHE US", emoji: "" },
  actions: { accent: "#C8A960", accentLight: "rgba(200,169,96,0.08)", label: "MODULE ACTIONS US", emoji: "" },
  debrief: { accent: "#E07A3A", accentLight: "rgba(224,122,58,0.08)", label: "DEBRIEF JOURNEE", emoji: "" },
  topactions: { accent: "#7C3AED", accentLight: "rgba(124,58,237,0.08)", label: "TOP ACTIONS DU MOIS", emoji: "" },
  mondial: { accent: "#2563EB", accentLight: "rgba(37,99,235,0.08)", label: "MARCHES MONDIAUX", emoji: "" },
  suisse: { accent: "#DC2626", accentLight: "rgba(220,38,38,0.08)", label: "MODULE SUISSE", emoji: "" },
  theme: { accent: "#DB2777", accentLight: "rgba(219,39,119,0.08)", label: "THEME DU MOIS", emoji: "" },
  etf: { accent: "#4F46E5", accentLight: "rgba(79,70,229,0.08)", label: "ETF & ALLOCATION", emoji: "" },
  general: { accent: "#C8A960", accentLight: "rgba(200,169,96,0.08)", label: "WALLSTREET MARKET BRIEF", emoji: "" },
};

// ═══════════ SHARED STYLES ═══════════

function sharedStyles(): string {
  return `
    :root{color-scheme:light dark;supported-color-schemes:light dark;}
    body{margin:0;padding:0;background-color:${OUTER_BG};font-family:${FONT_STACK};-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;}
    a{color:${GOLD};text-decoration:none;}
    img{border:0;display:block;outline:none;text-decoration:none;}
    table{border-collapse:collapse;}
    p{margin:0;}
    h1,h2,h3,h4{margin:0;}
    @media only screen and (max-width:620px){
      .email-container{width:100%!important;padding:0!important;}
      .pad{padding-left:20px!important;padding-right:20px!important;}
      .pad-sm{padding-left:16px!important;padding-right:16px!important;}
      .mobile-full{width:100%!important;display:block!important;}
      .mobile-center{text-align:center!important;}
      .mobile-hide{display:none!important;}
      .mobile-stack{display:block!important;width:100%!important;}
      .hero-title{font-size:20px!important;line-height:1.3!important;}
      .stat-grid td{display:block!important;width:100%!important;padding:6px 0!important;}
      .score-card{width:calc(50% - 12px)!important;margin:4px!important;}
      .card-grid td{display:block!important;width:100%!important;padding-bottom:10px!important;}
    }
  `;
}

// ═══════════ COMPONENT BUILDERS ═══════════

/** Dark header with white logo on transparent bg */
function buildHeader(): string {
  return `
    <tr>
      <td class="pad" style="background-color:${SHELL_BG};padding:32px 44px 18px;" align="center">
        <a href="https://wallstreetmarketbrief.ch" style="text-decoration:none;">
          <img src="${LOGO_URL}" alt="WallStreet Market Brief" width="240" style="display:block;max-width:240px;height:auto;" />
        </a>
        <p style="margin:14px 0 0;font-size:9px;letter-spacing:3px;text-transform:uppercase;color:${TEXT_DIM};">Newsletter March&eacute;s Financiers</p>
      </td>
    </tr>
    <tr>
      <td class="pad" style="background-color:${SHELL_BG};padding:0 44px;">
        <div style="height:2px;background:linear-gradient(90deg,transparent,${GOLD},transparent);"></div>
      </td>
    </tr>
  `;
}

/** Thin accent line separator */
function buildAccentLine(color: string = BORDER_LIGHT): string {
  return `
    <tr>
      <td class="pad" style="background-color:${BODY_BG};padding:0 44px;">
        <div style="height:1px;background:linear-gradient(90deg,transparent,${color},transparent);"></div>
      </td>
    </tr>
  `;
}

/** Module title bar — light body with accent label */
function buildModuleTitleBar(opts: {
  moduleLabel: string;
  title: string;
  subtitle?: string;
  accentColor: string;
  weekInfo?: string;
}): string {
  return `
    <tr>
      <td class="pad" style="background-color:${BODY_BG};padding:28px 44px 0;">
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
          <tr>
            <td>
              <p style="margin:0 0 4px;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:${opts.accentColor};font-weight:600;">${opts.moduleLabel}${opts.weekInfo ? ` &mdash; ${opts.weekInfo}` : ""}</p>
            </td>
          </tr>
          <tr>
            <td style="padding-top:8px;">
              <h1 class="hero-title" style="color:${TEXT_DARK};font-size:24px;font-weight:700;line-height:1.3;margin:0;">${opts.title}</h1>
            </td>
          </tr>
          ${opts.subtitle ? `
          <tr>
            <td style="padding-top:8px;">
              <p style="color:${TEXT_CAPTION};font-size:14px;line-height:1.6;margin:0;">${opts.subtitle}</p>
            </td>
          </tr>
          ` : ""}
        </table>
      </td>
    </tr>
  `;
}

/** Section heading inside the light body */
function buildSectionHeading(title: string, accentColor: string): string {
  return `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:28px 0 16px;">
      <tr>
        <td>
          <div style="display:inline-block;width:3px;height:18px;background-color:${accentColor};border-radius:2px;vertical-align:middle;margin-right:10px;"></div>
          <span style="font-size:16px;font-weight:700;color:${TEXT_DARK};vertical-align:middle;letter-spacing:0.3px;">${title}</span>
        </td>
      </tr>
    </table>
  `;
}

/** Info card with left accent border — light */
function buildInfoCard(opts: {
  label: string;
  value: string;
  note?: string;
  accentColor: string;
}): string {
  return `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 8px;">
      <tr>
        <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${opts.accentColor};">
          <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
            <tr>
              <td>
                <span style="font-size:13px;font-weight:700;color:${TEXT_DARK};">${opts.label}</span>
                <span style="font-size:13px;font-weight:700;color:${opts.accentColor};margin-left:8px;">${opts.value}</span>
              </td>
            </tr>
            ${opts.note ? `
            <tr>
              <td style="padding-top:4px;">
                <span style="font-size:12px;color:${TEXT_BODY};line-height:1.4;">${opts.note}</span>
              </td>
            </tr>
            ` : ""}
          </table>
        </td>
      </tr>
    </table>
  `;
}

/** Stat box — premium dark card for visual impact */
function buildStatBox(opts: {
  label: string;
  value: string;
  change?: string;
  changePositive?: boolean;
  note?: string;
}): string {
  const changeColor = opts.changePositive ? "#34D399" : "#F87171";
  const STAT_BG = "#1B2030";
  const STAT_BORDER = "#2A3148";
  return `
    <td style="padding:16px 10px 14px;background-color:${STAT_BG};border-radius:10px;text-align:center;border:1px solid ${STAT_BORDER};">
      <p style="margin:0;font-size:9px;color:#8B95A8;text-transform:uppercase;letter-spacing:1.5px;font-weight:700;white-space:nowrap;">${opts.label}</p>
      <p style="margin:6px 0 0;font-size:20px;font-weight:800;color:#FFFFFF;white-space:nowrap;letter-spacing:-0.5px;">${opts.value}</p>
      ${opts.change ? `<p style="margin:4px 0 0;font-size:12px;font-weight:700;color:${changeColor};white-space:nowrap;">${opts.change}</p>` : ""}
      ${opts.note ? `<p style="margin:3px 0 0;font-size:10px;color:#6B7585;white-space:nowrap;">${opts.note}</p>` : ""}
    </td>
  `;
}

/** Signal/Risk badge — light */
function buildBadge(opts: {
  text: string;
  type: "signal" | "risk" | "neutral" | "info";
}): string {
  const colors = {
    signal: { bg: "rgba(22,163,74,0.08)", text: GREEN, border: "rgba(22,163,74,0.2)" },
    risk: { bg: "rgba(220,38,38,0.08)", text: RED, border: "rgba(220,38,38,0.2)" },
    neutral: { bg: "rgba(200,169,96,0.08)", text: GOLD, border: "rgba(200,169,96,0.2)" },
    info: { bg: "rgba(37,99,235,0.08)", text: "#2563EB", border: "rgba(37,99,235,0.2)" },
  };
  const c = colors[opts.type];
  return `<span style="display:inline-block;padding:5px 12px;background-color:${c.bg};color:${c.text};font-size:12px;font-weight:600;border-radius:6px;border:1px solid ${c.border};">${opts.text}</span>`;
}

/** Bullet point list item — light */
function buildBulletItem(text: string, accentColor: string): string {
  return `
    <tr>
      <td style="padding:6px 0;vertical-align:top;">
        <table cellpadding="0" cellspacing="0" role="presentation">
          <tr>
            <td style="width:20px;vertical-align:top;padding-top:6px;">
              <div style="width:6px;height:6px;border-radius:50%;background-color:${accentColor};"></div>
            </td>
            <td style="font-size:14px;color:${TEXT_BODY};line-height:1.6;">${text}</td>
          </tr>
        </table>
      </td>
    </tr>
  `;
}

/** CTA button — on light body */
function buildCta(text: string, url: string, bgColor: string): string {
  return `
    <tr>
      <td class="pad" style="background-color:${BODY_BG};padding:28px 44px 0;" align="center">
        <table cellpadding="0" cellspacing="0" role="presentation">
          <tr>
            <td style="background-color:${bgColor};border-radius:8px;padding:14px 44px;">
              <a href="${url}" style="color:#FFFFFF;text-decoration:none;font-size:14px;font-weight:700;display:inline-block;letter-spacing:0.3px;">${text}</a>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  `;
}

/** Divider line — light */
function buildDivider(): string {
  return `
    <tr>
      <td class="pad" style="background-color:${BODY_BG};padding:0 44px;">
        <div style="height:1px;background-color:${BORDER_LIGHT};"></div>
      </td>
    </tr>
  `;
}

/** Professional footer — light links + dark disclaimer */
function buildFooter(footerText?: string, unsubscribeToken?: string): string {
  const year = new Date().getFullYear();
  return `
    <tr><td style="background-color:${BODY_BG};padding:28px 0 0;"></td></tr>
    ${buildDivider()}
    <tr>
      <td class="pad" style="background-color:${BODY_BG};padding:16px 44px 12px;" align="center">
        <p style="margin:0 0 6px;font-size:11px;color:${TEXT_CAPTION};line-height:1.6;">
          ${footerText || "Vous recevez cet email car vous \u00eates abonn\u00e9(e) \u00e0 WallStreet Market Brief."}
        </p>
        <p style="margin:0;font-size:10px;color:${TEXT_CAPTION};line-height:1.5;">
          <a href="${SITE_URL}/desabonnement" style="color:${TEXT_CAPTION};text-decoration:underline;">G\u00e9rer mes pr\u00e9f\u00e9rences</a>
          &nbsp;\u00b7&nbsp;
          <a href="${SITE_URL}/mentions-legales" style="color:${TEXT_CAPTION};text-decoration:underline;">Mentions l\u00e9gales</a>
          ${unsubscribeToken ? `&nbsp;\u00b7&nbsp;<a href="${SITE_URL}/api/unsubscribe?token=${unsubscribeToken}" style="color:${TEXT_CAPTION};text-decoration:underline;">Se d\u00e9sabonner</a>` : `&nbsp;\u00b7&nbsp;<a href="${SITE_URL}/desabonnement" style="color:${TEXT_CAPTION};text-decoration:underline;">Se d\u00e9sabonner</a>`}
        </p>
      </td>
    </tr>
    <tr>
      <td class="pad" style="background-color:${SHELL_BG};padding:16px 44px;" align="center">
        <p style="margin:0;color:${TEXT_DIM};font-size:9px;line-height:1.6;letter-spacing:0.3px;">
          Ce contenu est purement informatif et ne constitue pas un conseil en investissement.<br>
          &copy; ${year} WallStreet Market Brief. Tous droits r\u00e9serv\u00e9s.
        </p>
      </td>
    </tr>
  `;
}

// ═══════════ FULL EMAIL WRAPPER ═══════════

function wrapEmail(opts: {
  preheader?: string;
  accentColor: string;
  innerHtml: string;
}): string {
  const year = new Date().getFullYear();
  return `<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="x-apple-disable-message-reformatting">
  <meta name="format-detection" content="telephone=no,address=no,email=no,date=no,url=no">
  <meta name="color-scheme" content="light dark">
  <meta name="supported-color-schemes" content="light dark">
  <title>WallStreet Market Brief</title>
  ${opts.preheader ? `<span style="display:none;font-size:1px;color:${OUTER_BG};line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;">${opts.preheader}${"&zwnj;&nbsp;".repeat(30)}</span>` : ""}
  <!--[if mso]>
  <noscript><xml><o:OfficeDocumentSettings><o:AllowPNG/><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml></noscript>
  <![endif]-->
  <style>${sharedStyles()}</style>
</head>
<body style="margin:0;padding:0;background-color:${OUTER_BG};-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;">
  <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:${OUTER_BG};padding:24px 12px;">
    <tr>
      <td align="center">
        <table class="email-container" width="600" cellpadding="0" cellspacing="0" role="presentation" style="max-width:600px;width:100%;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08);">
          ${opts.innerHtml}
        </table>
        <table width="600" cellpadding="0" cellspacing="0" role="presentation" style="max-width:600px;width:100%;margin-top:12px;">
          <tr>
            <td align="center">
              <p style="margin:0;color:${TEXT_CAPTION};font-size:9px;">&copy; ${year} WMB</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

// ═══════════ MODULE-SPECIFIC TEMPLATES ═══════════

export interface ModuleUsaEmailData {
  weekNumber: number;
  year: number;
  dateRange: string;
  title: string;
  subtitle: string;
  keyPointsPast: string[];
  keyPointsAhead: string[];
  lectureWMB: string;
  sp500: { value: string; change: string };
  nasdaq: { value: string; change: string };
  dowJones: { value: string; change: string };
  vix: { value: string; regime: string };
  signal: string;
  risk: string;
  highlights: string[];
  ctaUrl?: string;
}

export function buildModuleUsaEmail(data: ModuleUsaEmailData): string {
  const mod = MODULE_COLORS.marche;
  const weekInfo = `Semaine ${String(data.weekNumber).padStart(2, "0")}`;
  const keyPointsPastHtml = data.keyPointsPast.map(p => buildBulletItem(p, mod.accent)).join("");
  const keyPointsAheadHtml = data.keyPointsAhead.map(p => buildBulletItem(p, GOLD)).join("");
  const highlightsHtml = data.highlights.map(h => buildBulletItem(h, mod.accent)).join("");

  const innerHtml = `
    ${buildHeader()}
    ${buildAccentLine(mod.accent)}
    ${buildModuleTitleBar({ moduleLabel: mod.label, title: data.title, subtitle: data.subtitle, accentColor: mod.accent, weekInfo })}
    <tr>
      <td class="pad" style="background-color:${BODY_BG};padding:28px 44px;color:${TEXT_BODY};font-size:14px;line-height:1.7;">
        <p style="margin:0 0 20px;font-size:12px;color:${TEXT_CAPTION};text-transform:uppercase;letter-spacing:1px;font-weight:600;">${data.dateRange} &mdash; ${data.year}</p>
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;table-layout:fixed;" class="stat-grid">
          <tr>
            ${buildStatBox({ label: "S&amp;P 500", value: data.sp500.value, change: data.sp500.change, changePositive: data.sp500.change.startsWith("+") })}
            <td style="width:8px;"></td>
            ${buildStatBox({ label: "Nasdaq", value: data.nasdaq.value, change: data.nasdaq.change, changePositive: data.nasdaq.change.startsWith("+") })}
            <td style="width:8px;"></td>
            ${buildStatBox({ label: "Dow Jones", value: data.dowJones.value, change: data.dowJones.change, changePositive: data.dowJones.change.startsWith("+") })}
          </tr>
        </table>
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;">
          <tr>
            <td style="padding:12px 16px;background-color:${CARD_ELEVATED};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
              <span style="font-size:10px;color:${TEXT_CAPTION};text-transform:uppercase;letter-spacing:1px;font-weight:600;">VIX</span>
              <span style="font-size:16px;font-weight:700;color:${TEXT_DARK};margin-left:8px;">${data.vix.value}</span>
              <span style="font-size:12px;color:${TEXT_BODY};margin-left:8px;">${data.vix.regime}</span>
            </td>
          </tr>
        </table>
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;">
          <tr>
            <td style="padding-right:6px;">${buildBadge({ text: "Signal: " + data.signal, type: "signal" })}</td>
            <td>${buildBadge({ text: "Risque: " + data.risk, type: "risk" })}</td>
          </tr>
        </table>
        ${buildSectionHeading("Semaine pass&eacute;e", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">${keyPointsPastHtml}</table>
        ${buildSectionHeading("Semaine &agrave; venir", GOLD)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">${keyPointsAheadHtml}</table>
        ${buildSectionHeading("Lecture WMB", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 8px;">
          <tr><td style="padding:16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${mod.accent};"><p style="margin:0;font-size:14px;color:${TEXT_BODY};line-height:1.7;font-style:italic;">${data.lectureWMB}</p></td></tr>
        </table>
        ${data.highlights.length > 0 ? `${buildSectionHeading("Points cl&eacute;s de l'&eacute;dition", mod.accent)}<table width="100%" cellpadding="0" cellspacing="0" role="presentation">${highlightsHtml}</table>` : ""}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:24px 0 0;">
          <tr><td style="padding:16px;background-color:${CARD_BG};border-radius:8px;border:1px dashed ${BORDER_LIGHT};text-align:center;"><p style="margin:0;font-size:13px;color:${TEXT_CAPTION};"><strong style="color:${TEXT_DARK};">&Eacute;dition compl&egrave;te</strong> : scoreboard d&eacute;taill&eacute;, FX, taux, cr&eacute;dit, commodities, crypto, macro, Fed, secteurs, sc&eacute;narios et risques.</p></td></tr>
        </table>
      </td>
    </tr>
    ${buildCta("Lire l'&eacute;dition compl&egrave;te", data.ctaUrl || SITE_URL + "/dashboard", mod.accent)}
    ${buildFooter("Vous recevez cet email car vous \u00eates abonn\u00e9(e) au Weekly Brief USA de WallStreet Market Brief.")}
  `;
  return wrapEmail({ preheader: data.title + " \u2014 S" + data.weekNumber + " " + data.year, accentColor: mod.accent, innerHtml });
}

// ═══════════ MODULE ACTIONS US ═══════════

export interface ModuleActionsEmailData {
  weekNumber: number;
  year: number;
  dateRange: string;
  title: string;
  subtitle: string;
  topGainers: { ticker: string; company: string; perf: string; catalyst: string }[];
  topLosers: { ticker: string; company: string; perf: string; catalyst: string }[];
  sectorHighlight: string;
  earningsHighlights: string[];
  watchlistItems: { ticker: string; reason: string }[];
  ctaUrl?: string;
}

function buildStockRow(s: { ticker: string; company: string; perf: string; catalyst: string }, color: string): string {
  return `<tr><td style="padding:10px 12px;border-bottom:1px solid ${BORDER_LIGHT};"><table width="100%" cellpadding="0" cellspacing="0" role="presentation"><tr><td style="width:60px;"><span style="font-size:13px;font-weight:700;color:${TEXT_DARK};">${s.ticker}</span></td><td><span style="font-size:12px;color:${TEXT_BODY};">${s.company}</span></td><td style="text-align:right;width:70px;"><span style="font-size:13px;font-weight:700;color:${color};">${s.perf}</span></td></tr><tr><td colspan="3" style="padding-top:3px;"><span style="font-size:11px;color:${TEXT_CAPTION};">${s.catalyst}</span></td></tr></table></td></tr>`;
}

export function buildModuleActionsEmail(data: ModuleActionsEmailData): string {
  const mod = MODULE_COLORS.actions;
  const weekInfo = `Semaine ${String(data.weekNumber).padStart(2, "0")}`;
  const gainersHtml = data.topGainers.slice(0, 5).map(g => buildStockRow(g, GREEN)).join("");
  const losersHtml = data.topLosers.slice(0, 5).map(l => buildStockRow(l, RED)).join("");
  const earningsHtml = data.earningsHighlights.map(e => buildBulletItem(e, mod.accent)).join("");
  const watchlistHtml = data.watchlistItems.slice(0, 5).map(w => `<tr><td style="padding:8px 12px;border-bottom:1px solid ${BORDER_LIGHT};"><span style="font-size:13px;font-weight:700;color:${mod.accent};margin-right:8px;">${w.ticker}</span><span style="font-size:12px;color:${TEXT_BODY};">${w.reason}</span></td></tr>`).join("");

  const innerHtml = `
    ${buildHeader()}
    ${buildAccentLine(mod.accent)}
    ${buildModuleTitleBar({ moduleLabel: mod.label, title: data.title, subtitle: data.subtitle, accentColor: mod.accent, weekInfo })}
    <tr>
      <td class="pad" style="background-color:${BODY_BG};padding:28px 44px;color:${TEXT_BODY};font-size:14px;line-height:1.7;">
        <p style="margin:0 0 20px;font-size:12px;color:${TEXT_CAPTION};text-transform:uppercase;letter-spacing:1px;font-weight:600;">${data.dateRange} &mdash; ${data.year}</p>
        ${buildSectionHeading("Top Gagnants", GREEN)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:${CARD_BG};border-radius:8px;overflow:hidden;margin:0 0 20px;border:1px solid ${BORDER_LIGHT};">${gainersHtml}</table>
        ${buildSectionHeading("Top Perdants", RED)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:${CARD_BG};border-radius:8px;overflow:hidden;margin:0 0 20px;border:1px solid ${BORDER_LIGHT};">${losersHtml}</table>
        ${buildSectionHeading("Vue Sectorielle", mod.accent)}
        ${buildInfoCard({ label: "Tendance", value: "", note: data.sectorHighlight, accentColor: mod.accent })}
        ${data.earningsHighlights.length > 0 ? `${buildSectionHeading("Earnings &amp; Guidance", mod.accent)}<table width="100%" cellpadding="0" cellspacing="0" role="presentation">${earningsHtml}</table>` : ""}
        ${data.watchlistItems.length > 0 ? `${buildSectionHeading("Watchlist", mod.accent)}<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:${CARD_BG};border-radius:8px;overflow:hidden;margin:0 0 16px;border:1px solid ${BORDER_LIGHT};">${watchlistHtml}</table>` : ""}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:24px 0 0;">
          <tr><td style="padding:16px;background-color:${CARD_BG};border-radius:8px;border:1px dashed ${BORDER_LIGHT};text-align:center;"><p style="margin:0;font-size:13px;color:${TEXT_CAPTION};"><strong style="color:${TEXT_DARK};">&Eacute;dition compl&egrave;te</strong> : top movers mid/small caps, vue sectorielle d&eacute;taill&eacute;e, th&egrave;mes dominants, voix influentes, radar &eacute;mergent.</p></td></tr>
        </table>
      </td>
    </tr>
    ${buildCta("Lire l'&eacute;dition compl&egrave;te", data.ctaUrl || SITE_URL + "/actions/1", mod.accent)}
    ${buildFooter("Vous recevez cet email car vous \u00eates abonn\u00e9(e) au Module Actions US de WallStreet Market Brief.")}
  `;
  return wrapEmail({ preheader: data.title + " \u2014 S" + data.weekNumber + " " + data.year, accentColor: mod.accent, innerHtml });
}

// ═══════════ MODULE MONDE ═══════════

export interface ModuleMondeEmailData {
  weekNumber: number;
  year: number;
  dateRange: string;
  title: string;
  subtitle: string;
  keyPointsPast: string[];
  keyPointsAhead: string[];
  lectureWMB: string;
  europeIndices: { name: string; value: string; change: string }[];
  europeLecture: string;
  asiaIndices: { name: string; value: string; change: string }[];
  asiaLecture: string;
  forexPairs: { pair: string; value: string; change: string }[];
  forexLecture: string;
  commodities: { name: string; value: string; change: string }[];
  commoditiesLecture: string;
  highlights: string[];
  ctaUrl?: string;
}

function buildDataRow(label: string, value: string, change: string): string {
  const changeColor = change.startsWith("+") ? GREEN : change.startsWith("-") ? RED : TEXT_CAPTION;
  return `<tr><td style="padding:8px 12px;border-bottom:1px solid ${BORDER_LIGHT};"><table width="100%" cellpadding="0" cellspacing="0" role="presentation"><tr><td><span style="font-size:13px;font-weight:700;color:${TEXT_DARK};">${label}</span></td><td style="text-align:center;"><span style="font-size:13px;color:${TEXT_BODY};">${value}</span></td><td style="text-align:right;"><span style="font-size:13px;font-weight:600;color:${changeColor};">${change}</span></td></tr></table></td></tr>`;
}

export function buildModuleMondeEmail(data: ModuleMondeEmailData): string {
  const mod = MODULE_COLORS.mondial;
  const weekInfo = `Semaine ${String(data.weekNumber).padStart(2, "0")}`;
  const keyPointsPastHtml = data.keyPointsPast.map(p => buildBulletItem(p, mod.accent)).join("");
  const keyPointsAheadHtml = data.keyPointsAhead.map(p => buildBulletItem(p, GOLD)).join("");
  const highlightsHtml = data.highlights.map(h => buildBulletItem(h, mod.accent)).join("");

  const europeHtml = data.europeIndices.slice(0, 3).length > 0 ? `<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 16px;table-layout:fixed;" class="stat-grid"><tr>${data.europeIndices.slice(0, 3).map(idx => buildStatBox({ label: idx.name, value: idx.value, change: idx.change, changePositive: idx.change.startsWith("+") })).join('<td style="width:8px;"></td>')}</tr></table>` : "";
  const asiaHtml = data.asiaIndices.slice(0, 3).length > 0 ? `<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 16px;table-layout:fixed;" class="stat-grid"><tr>${data.asiaIndices.slice(0, 3).map(idx => buildStatBox({ label: idx.name, value: idx.value, change: idx.change, changePositive: idx.change.startsWith("+") })).join('<td style="width:8px;"></td>')}</tr></table>` : "";
  const forexHtml = data.forexPairs.slice(0, 4).map(fx => buildDataRow(fx.pair, fx.value, fx.change)).join("");
  const commoditiesHtml = data.commodities.slice(0, 4).map(c => buildDataRow(c.name, c.value, c.change)).join("");

  const innerHtml = `
    ${buildHeader()}
    ${buildAccentLine(mod.accent)}
    ${buildModuleTitleBar({ moduleLabel: mod.label, title: data.title, subtitle: data.subtitle, accentColor: mod.accent, weekInfo })}
    <tr>
      <td class="pad" style="background-color:${BODY_BG};padding:28px 44px;color:${TEXT_BODY};font-size:14px;line-height:1.7;">
        <p style="margin:0 0 20px;font-size:12px;color:${TEXT_CAPTION};text-transform:uppercase;letter-spacing:1px;font-weight:600;">${data.dateRange} &mdash; ${data.year}</p>
        ${buildSectionHeading("Europe", mod.accent)}
        ${europeHtml}
        ${data.europeLecture ? buildInfoCard({ label: "Lecture WMB", value: "", note: data.europeLecture, accentColor: mod.accent }) : ""}
        ${buildSectionHeading("Asie-Pacifique", "#E07A3A")}
        ${asiaHtml}
        ${data.asiaLecture ? buildInfoCard({ label: "Lecture WMB", value: "", note: data.asiaLecture, accentColor: "#E07A3A" }) : ""}
        ${data.forexPairs.length > 0 ? `${buildSectionHeading("Forex", mod.accent)}<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:${CARD_BG};border-radius:8px;overflow:hidden;margin:0 0 8px;border:1px solid ${BORDER_LIGHT};">${forexHtml}</table>${data.forexLecture ? buildInfoCard({ label: "Lecture WMB", value: "", note: data.forexLecture, accentColor: mod.accent }) : ""}` : ""}
        ${data.commodities.length > 0 ? `${buildSectionHeading("Commodities", GOLD)}<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:${CARD_BG};border-radius:8px;overflow:hidden;margin:0 0 8px;border:1px solid ${BORDER_LIGHT};">${commoditiesHtml}</table>${data.commoditiesLecture ? buildInfoCard({ label: "Lecture WMB", value: "", note: data.commoditiesLecture, accentColor: GOLD }) : ""}` : ""}
        ${buildSectionHeading("Semaine pass&eacute;e", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">${keyPointsPastHtml}</table>
        ${buildSectionHeading("Semaine &agrave; venir", GOLD)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">${keyPointsAheadHtml}</table>
        ${buildSectionHeading("Lecture WMB", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 8px;"><tr><td style="padding:16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${mod.accent};"><p style="margin:0;font-size:14px;color:${TEXT_BODY};line-height:1.7;font-style:italic;">${data.lectureWMB}</p></td></tr></table>
        ${data.highlights.length > 0 ? `${buildSectionHeading("Points cl&eacute;s", mod.accent)}<table width="100%" cellpadding="0" cellspacing="0" role="presentation">${highlightsHtml}</table>` : ""}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:24px 0 0;"><tr><td style="padding:16px;background-color:${CARD_BG};border-radius:8px;border:1px dashed ${BORDER_LIGHT};text-align:center;"><p style="margin:0;font-size:13px;color:${TEXT_CAPTION};"><strong style="color:${TEXT_DARK};">&Eacute;dition compl&egrave;te</strong> : indices Europe/Asie, &eacute;mergents, forex, commodities, crypto, banques centrales, g&eacute;opolitique, sc&eacute;narios et risques.</p></td></tr></table>
      </td>
    </tr>
    ${buildCta("Lire l'&eacute;dition compl&egrave;te", data.ctaUrl || SITE_URL + "/monde/1", mod.accent)}
    ${buildFooter("Vous recevez cet email car vous \u00eates abonn\u00e9(e) au Module March\u00e9s Mondiaux de WallStreet Market Brief.")}
  `;
  return wrapEmail({ preheader: data.title + " \u2014 S" + data.weekNumber + " " + data.year, accentColor: mod.accent, innerHtml });
}

// ═══════════ MODULE SUISSE ═══════════

export interface ModuleSuisseEmailData {
  weekNumber: number;
  year: number;
  dateRange: string;
  title: string;
  subtitle: string;
  keyPointsPast: string[];
  keyPointsAhead: string[];
  lectureWMB: string;
  smiValue: string;
  smiChange: string;
  chfPairs: { pair: string; value: string; change: string }[];
  chfLecture: string;
  bnsRate: string;
  bnsStance: string;
  blueChips: { ticker: string; value: string; change: string }[];
  blueChipsLecture: string;
  topMovers: { ticker: string; change: string }[];
  flopMovers: { ticker: string; change: string }[];
  highlights: string[];
  ctaUrl?: string;
}

export function buildModuleSuisseEmail(data: ModuleSuisseEmailData): string {
  const mod = MODULE_COLORS.suisse;
  const weekInfo = `Semaine ${String(data.weekNumber).padStart(2, "0")}`;
  const keyPointsPastHtml = data.keyPointsPast.map(p => buildBulletItem(p, mod.accent)).join("");
  const keyPointsAheadHtml = data.keyPointsAhead.map(p => buildBulletItem(p, GOLD)).join("");
  const highlightsHtml = data.highlights.map(h => buildBulletItem(h, mod.accent)).join("");
  const chfHtml = data.chfPairs.slice(0, 4).map(fx => buildDataRow(fx.pair, fx.value, fx.change)).join("");
  const blueChipsHtml = data.blueChips.slice(0, 5).map(s => buildDataRow(s.ticker, s.value, s.change)).join("");
  const topMoversHtml = data.topMovers.slice(0, 3).map(m => `<span style="display:inline-block;padding:4px 10px;background-color:rgba(22,163,74,0.08);color:${GREEN};font-size:12px;font-weight:600;border-radius:6px;margin:2px 4px;">${m.ticker} ${m.change}</span>`).join("");
  const flopMoversHtml = data.flopMovers.slice(0, 3).map(m => `<span style="display:inline-block;padding:4px 10px;background-color:rgba(220,38,38,0.08);color:${RED};font-size:12px;font-weight:600;border-radius:6px;margin:2px 4px;">${m.ticker} ${m.change}</span>`).join("");

  const innerHtml = `
    ${buildHeader()}
    ${buildAccentLine(mod.accent)}
    ${buildModuleTitleBar({ moduleLabel: mod.label, title: data.title, subtitle: data.subtitle, accentColor: mod.accent, weekInfo })}
    <tr>
      <td class="pad" style="background-color:${BODY_BG};padding:28px 44px;color:${TEXT_BODY};font-size:14px;line-height:1.7;">
        <p style="margin:0 0 20px;font-size:12px;color:${TEXT_CAPTION};text-transform:uppercase;letter-spacing:1px;font-weight:600;">${data.dateRange} &mdash; ${data.year}</p>
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 16px;table-layout:fixed;" class="stat-grid">
          <tr>
            ${buildStatBox({ label: "SMI", value: data.smiValue, change: data.smiChange, changePositive: data.smiChange.startsWith("+") })}
            <td style="width:8px;"></td>
            ${buildStatBox({ label: "Taux BNS", value: data.bnsRate })}
            <td style="width:8px;"></td>
            <td style="padding:12px;background-color:${CARD_ELEVATED};border-radius:8px;text-align:center;border:1px solid ${BORDER_LIGHT};">
              <p style="margin:0;font-size:10px;color:${TEXT_CAPTION};text-transform:uppercase;letter-spacing:1px;font-weight:600;">Stance BNS</p>
              <p style="margin:4px 0 0;font-size:14px;font-weight:700;color:${TEXT_DARK};">${data.bnsStance}</p>
            </td>
          </tr>
        </table>
        ${buildSectionHeading("Franc Suisse", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:${CARD_BG};border-radius:8px;overflow:hidden;margin:0 0 8px;border:1px solid ${BORDER_LIGHT};">${chfHtml}</table>
        ${data.chfLecture ? buildInfoCard({ label: "Lecture WMB", value: "", note: data.chfLecture, accentColor: mod.accent }) : ""}
        ${buildSectionHeading("Blue Chips SMI", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:${CARD_BG};border-radius:8px;overflow:hidden;margin:0 0 8px;border:1px solid ${BORDER_LIGHT};">${blueChipsHtml}</table>
        ${data.blueChipsLecture ? buildInfoCard({ label: "Lecture WMB", value: "", note: data.blueChipsLecture, accentColor: mod.accent }) : ""}
        ${(data.topMovers.length > 0 || data.flopMovers.length > 0) ? `${buildSectionHeading("Top &amp; Flop de la semaine", mod.accent)}<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 16px;"><tr><td style="padding:12px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">${data.topMovers.length > 0 ? `<p style="margin:0 0 6px;font-size:11px;color:${TEXT_CAPTION};text-transform:uppercase;letter-spacing:1px;font-weight:600;">&#9650; Top</p><p style="margin:0 0 10px;">${topMoversHtml}</p>` : ""}${data.flopMovers.length > 0 ? `<p style="margin:0 0 6px;font-size:11px;color:${TEXT_CAPTION};text-transform:uppercase;letter-spacing:1px;font-weight:600;">&#9660; Flop</p><p style="margin:0;">${flopMoversHtml}</p>` : ""}</td></tr></table>` : ""}
        ${buildSectionHeading("Semaine pass&eacute;e", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">${keyPointsPastHtml}</table>
        ${buildSectionHeading("Semaine &agrave; venir", GOLD)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">${keyPointsAheadHtml}</table>
        ${buildSectionHeading("Lecture WMB", mod.accent)}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 8px;"><tr><td style="padding:16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${mod.accent};"><p style="margin:0;font-size:14px;color:${TEXT_BODY};line-height:1.7;font-style:italic;">${data.lectureWMB}</p></td></tr></table>
        ${data.highlights.length > 0 ? `${buildSectionHeading("Points cl&eacute;s", mod.accent)}<table width="100%" cellpadding="0" cellspacing="0" role="presentation">${highlightsHtml}</table>` : ""}
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:24px 0 0;"><tr><td style="padding:16px;background-color:${CARD_BG};border-radius:8px;border:1px dashed ${BORDER_LIGHT};text-align:center;"><p style="margin:0;font-size:13px;color:${TEXT_CAPTION};"><strong style="color:${TEXT_DARK};">&Eacute;dition compl&egrave;te</strong> : SMI d&eacute;taill&eacute;, blue chips, BNS, CHF, &eacute;conomie suisse, sc&eacute;narios et risques.</p></td></tr></table>
      </td>
    </tr>
    ${buildCta("Lire l'&eacute;dition compl&egrave;te", data.ctaUrl || SITE_URL + "/suisse/1", mod.accent)}
    ${buildFooter("Vous recevez cet email car vous \u00eates abonn\u00e9(e) au Module Suisse de WallStreet Market Brief.")}
  `;
  return wrapEmail({ preheader: data.title + " \u2014 S" + data.weekNumber + " " + data.year, accentColor: mod.accent, innerHtml });
}

// ═══════════ GENERIC MODULE EMAIL ═══════════

export interface GenericModuleEmailData {
  moduleType: keyof typeof MODULE_COLORS;
  weekNumber?: number;
  year?: number;
  dateRange?: string;
  title: string;
  subtitle?: string;
  bodyHtml: string;
  ctaText?: string;
  ctaUrl?: string;
  footerText?: string;
  skipTitleBar?: boolean;
  skipHeader?: boolean;
}

export function buildGenericModuleEmail(data: GenericModuleEmailData): string {
  const mod = MODULE_COLORS[data.moduleType] || MODULE_COLORS.general;
  const weekInfo = data.weekNumber ? `Semaine ${String(data.weekNumber).padStart(2, "0")}` : undefined;
  const titleBarHtml = data.skipTitleBar ? '' : buildModuleTitleBar({ moduleLabel: mod.label, title: data.title, subtitle: data.subtitle, accentColor: mod.accent, weekInfo });
  const headerHtml = data.skipHeader ? '' : buildHeader();
  const accentLineHtml = data.skipHeader ? '' : buildAccentLine(mod.accent);

  const innerHtml = `
    ${headerHtml}
    ${accentLineHtml}
    ${titleBarHtml}
    <tr>
      <td class="pad" style="background-color:${BODY_BG};padding:28px 44px;color:${TEXT_BODY};font-size:14px;line-height:1.7;">
        ${(!data.skipTitleBar && data.dateRange) ? `<p style="margin:0 0 20px;font-size:12px;color:${TEXT_CAPTION};text-transform:uppercase;letter-spacing:1px;font-weight:600;">${data.dateRange}${data.year ? ` &mdash; ${data.year}` : ""}</p>` : ""}
        ${data.bodyHtml}
      </td>
    </tr>
    ${(() => {
      const contentHasCta = data.bodyHtml.includes('Acceder a mon espace') || data.bodyHtml.includes('Acc\u00e9der') || data.bodyHtml.includes('border-radius:8px;padding:12px 36px');
      if (contentHasCta) return '';
      return data.ctaText && data.ctaUrl ? buildCta(data.ctaText, data.ctaUrl, mod.accent) : buildCta("Acc\u00e9der \u00e0 mon espace", SITE_URL + "/dashboard", mod.accent);
    })()}
    ${buildFooter(data.footerText)}
  `;
  return wrapEmail({ preheader: data.title + (data.weekNumber ? ` \u2014 S${data.weekNumber}` : ""), accentColor: mod.accent, innerHtml });
}

// ═══════════ EXPORT HELPERS FOR ADMIN ═══════════

export const emailComponents = {
  sectionHeading: buildSectionHeading,
  infoCard: buildInfoCard,
  statBox: buildStatBox,
  badge: buildBadge,
  bulletItem: buildBulletItem,
  divider: () => `<div style="height:1px;background-color:${BORDER_LIGHT};margin:20px 0;"></div>`,
  spacer: (height: number = 16) => `<div style="height:${height}px;"></div>`,
  quote: (text: string, accentColor: string = GOLD) => `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:16px 0;">
      <tr>
        <td style="padding:16px 20px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${accentColor};">
          <p style="margin:0;font-size:14px;color:${TEXT_BODY};line-height:1.7;font-style:italic;">${text}</p>
        </td>
      </tr>
    </table>
  `,
  highlight: (text: string, accentColor: string = GREEN) => `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:12px 0;">
      <tr>
        <td style="padding:14px 16px;background-color:rgba(22,163,74,0.06);border-radius:8px;border:1px solid rgba(22,163,74,0.15);">
          <p style="margin:0;font-size:14px;color:${TEXT_BODY};line-height:1.6;"><strong style="color:${accentColor};">&#9733;</strong> ${text}</p>
        </td>
      </tr>
    </table>
  `,
};

// ═══════════ VISUAL CHART COMPONENTS — Light Version ═══════════

export function buildPerformanceBar(opts: { label: string; value: string; percent: number; maxPercent?: number; }): string {
  const isPositive = opts.percent >= 0;
  const color = isPositive ? GREEN : RED;
  const max = opts.maxPercent || 100;
  const barWidth = Math.min(Math.abs(opts.percent) / max * 100, 100);
  return `<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:4px 0;"><tr><td style="width:120px;padding:8px 12px 8px 0;vertical-align:middle;"><span style="font-size:13px;font-weight:600;color:${TEXT_DARK};">${opts.label}</span></td><td style="vertical-align:middle;padding:8px 0;"><div style="background-color:${CARD_ELEVATED};border-radius:4px;height:20px;width:100%;position:relative;"><div style="background-color:${color};border-radius:4px;height:20px;width:${barWidth}%;min-width:2px;"></div></div></td><td style="width:70px;padding:8px 0 8px 12px;text-align:right;vertical-align:middle;"><span style="font-size:13px;font-weight:700;color:${color};">${opts.value}</span></td></tr></table>`;
}

export function buildVixGauge(opts: { value: number; regime: string; }): string {
  const v = opts.value;
  const GAUGE_BG = "#1B2030";
  const GAUGE_BORDER = "#2A3148";
  let color = "#34D399"; let label = "Calme";
  if (v >= 35) { color = "#F87171"; label = "Panique"; }
  else if (v >= 25) { color = "#FB923C"; label = "Stress"; }
  else if (v >= 15) { color = "#FBBF24"; label = "Vigilance"; }
  const gaugePercent = Math.min(v / 50 * 100, 100);
  return `<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:12px 0;"><tr><td style="padding:20px;background-color:${GAUGE_BG};border-radius:10px;border:1px solid ${GAUGE_BORDER};"><table width="100%" cellpadding="0" cellspacing="0" role="presentation"><tr><td><span style="font-size:9px;color:#8B95A8;text-transform:uppercase;letter-spacing:2px;font-weight:700;">INDICE VIX</span></td><td style="text-align:right;"><span style="font-size:11px;font-weight:700;color:${color};background-color:${color}15;padding:4px 12px;border-radius:12px;">${label}</span></td></tr><tr><td colspan="2" style="padding-top:12px;"><span style="font-size:36px;font-weight:800;color:#FFFFFF;letter-spacing:-1px;">${opts.value.toFixed(1)}</span><span style="font-size:12px;color:#6B7585;margin-left:10px;">${opts.regime}</span></td></tr><tr><td colspan="2" style="padding-top:14px;"><div style="background:linear-gradient(90deg,#34D399 0%,#34D399 30%,#FBBF24 30%,#FBBF24 50%,#FB923C 50%,#FB923C 70%,#F87171 70%,#F87171 100%);border-radius:6px;height:8px;width:100%;opacity:0.3;"></div><div style="background-color:${color};border-radius:6px;height:8px;width:${gaugePercent}%;margin-top:-8px;"></div></td></tr><tr><td colspan="2" style="padding-top:5px;"><table width="100%" cellpadding="0" cellspacing="0" role="presentation"><tr><td style="font-size:9px;color:#6B7585;">0</td><td style="font-size:9px;color:#6B7585;text-align:center;">15</td><td style="font-size:9px;color:#6B7585;text-align:center;">25</td><td style="font-size:9px;color:#6B7585;text-align:center;">35</td><td style="font-size:9px;color:#6B7585;text-align:right;">50</td></tr></table></td></tr></table></td></tr></table>`;
}

export function buildScoreboardGrid(items: { label: string; value: string; change: string; note?: string; }[]): string {
  const validItems = items.filter(item => item.label.trim());
  if (!validItems.length) return '';
  const STAT_BG = "#1B2030";
  const STAT_BORDER = "#2A3148";

  // Build individual stat cards as separate inline-block divs for natural wrapping
  const cards = validItems.map(item => {
    const isPos = item.change.startsWith("+");
    const changeColor = isPos ? "#34D399" : item.change.startsWith("-") ? "#F87171" : "#8B95A8";
    // Each card is a fixed-width inline-block that wraps naturally
    return `<div class="score-card" style="display:inline-block;vertical-align:top;width:130px;margin:4px;background-color:${STAT_BG};border-radius:10px;text-align:center;border:1px solid ${STAT_BORDER};padding:14px 8px 12px;">
      <p style="margin:0;font-size:9px;color:#8B95A8;text-transform:uppercase;letter-spacing:1.5px;font-weight:700;line-height:1.3;">${item.label}</p>
      <p style="margin:6px 0 0;font-size:18px;font-weight:800;color:#FFFFFF;letter-spacing:-0.3px;line-height:1.2;">${item.value.trim() || "&mdash;"}</p>
      <p style="margin:4px 0 0;font-size:12px;font-weight:700;color:${changeColor};line-height:1.2;">${item.change.trim() || "&mdash;"}</p>
      ${item.note ? `<p style="margin:3px 0 0;font-size:10px;color:#6B7585;line-height:1.2;">${item.note}</p>` : ''}
    </div>`;
  }).join('');

  return `<div style="margin:12px 0;text-align:center;font-size:0;">${cards}</div>`;
}

export function buildDataBarTable(opts: { title?: string; accentColor?: string; columns: { label: string; width?: string }[]; rows: { cells: string[]; barValue?: number; barMax?: number }[]; }): string {
  const accent = opts.accentColor || GOLD;
  const headerCells = opts.columns.map((col, i) => `<td style="padding:10px 12px;font-size:10px;font-weight:700;color:${TEXT_CAPTION};text-transform:uppercase;letter-spacing:1px;border-bottom:2px solid ${accent};${col.width ? `width:${col.width};` : ''}${i > 0 ? 'text-align:right;' : ''}">${col.label}</td>`).join('');
  const bodyRows = opts.rows.map(row => {
    const dataCells = row.cells.map((cell, i) => {
      const isNumeric = i > 0;
      const isChange = cell.startsWith('+') || cell.startsWith('-');
      let cellColor = TEXT_BODY; let fontWeight = '400';
      if (isChange && cell.startsWith('+')) { cellColor = GREEN; fontWeight = '700'; }
      else if (isChange && cell.startsWith('-')) { cellColor = RED; fontWeight = '700'; }
      else if (i === 0) { fontWeight = '600'; cellColor = TEXT_DARK; }
      return `<td style="padding:10px 12px;font-size:13px;color:${cellColor};font-weight:${fontWeight};border-bottom:1px solid ${BORDER_LIGHT};${isNumeric ? 'text-align:right;' : ''}">${cell}</td>`;
    }).join('');
    let barCell = '';
    if (row.barValue !== undefined) {
      const max = row.barMax || 100;
      const isPos = row.barValue >= 0;
      const barColor = isPos ? GREEN : RED;
      const barW = Math.min(Math.abs(row.barValue) / max * 100, 100);
      barCell = `<td style="padding:10px 12px;border-bottom:1px solid ${BORDER_LIGHT};width:120px;"><div style="background-color:${CARD_ELEVATED};border-radius:3px;height:14px;width:100%;"><div style="background-color:${barColor};border-radius:3px;height:14px;width:${barW}%;min-width:2px;"></div></div></td>`;
    }
    return `<tr>${dataCells}${barCell}</tr>`;
  }).join('');
  return `${opts.title ? buildSectionHeading(opts.title, accent) : ''}<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:${CARD_BG};border-radius:8px;overflow:hidden;border:1px solid ${BORDER_LIGHT};margin:8px 0 16px;"><tr>${headerCells}${opts.rows[0]?.barValue !== undefined ? '<td style="padding:10px 12px;font-size:10px;font-weight:700;color:' + TEXT_CAPTION + ';text-transform:uppercase;letter-spacing:1px;border-bottom:2px solid ' + accent + ';width:120px;">PERF</td>' : ''}</tr>${bodyRows}</table>`;
}

export function buildTrendIndicator(opts: { label: string; direction: 'up' | 'down' | 'flat'; value?: string; note?: string; }): string {
  const arrows = { up: '&#9650;', down: '&#9660;', flat: '&#9654;' };
  const colors = { up: GREEN, down: RED, flat: TEXT_CAPTION };
  const bgColors = { up: 'rgba(22,163,74,0.06)', down: 'rgba(220,38,38,0.06)', flat: 'rgba(107,114,128,0.06)' };
  return `<table cellpadding="0" cellspacing="0" role="presentation" style="margin:6px 0;display:inline-block;"><tr><td style="padding:8px 14px;background-color:${bgColors[opts.direction]};border-radius:8px;border:1px solid ${colors[opts.direction]}20;"><span style="font-size:14px;color:${colors[opts.direction]};">${arrows[opts.direction]}</span><span style="font-size:13px;font-weight:600;color:${TEXT_DARK};margin-left:6px;">${opts.label}</span>${opts.value ? `<span style="font-size:13px;font-weight:700;color:${colors[opts.direction]};margin-left:8px;">${opts.value}</span>` : ''}${opts.note ? `<br><span style="font-size:11px;color:${TEXT_CAPTION};">${opts.note}</span>` : ''}</td></tr></table>`;
}

export function buildProgressBar(opts: { label: string; percent: number; color?: string; showPercent?: boolean; }): string {
  const color = opts.color || GOLD;
  const pct = Math.min(Math.max(opts.percent, 0), 100);
  return `<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:6px 0;"><tr><td style="padding:4px 0;"><table width="100%" cellpadding="0" cellspacing="0" role="presentation"><tr><td><span style="font-size:12px;font-weight:600;color:${TEXT_DARK};">${opts.label}</span></td>${opts.showPercent !== false ? `<td style="text-align:right;"><span style="font-size:12px;font-weight:700;color:${color};">${pct}%</span></td>` : ''}</tr></table><div style="background-color:${CARD_ELEVATED};border-radius:4px;height:10px;width:100%;margin-top:4px;"><div style="background-color:${color};border-radius:4px;height:10px;width:${pct}%;"></div></div></td></tr></table>`;
}

export function buildCalloutBox(opts: { type: 'warning' | 'info' | 'success' | 'danger'; title: string; text: string; }): string {
  const styles = {
    warning: { bg: 'rgba(224,122,58,0.06)', border: '#E07A3A', icon: '&#9888;', iconColor: '#E07A3A' },
    info: { bg: 'rgba(37,99,235,0.06)', border: '#2563EB', icon: '&#8505;', iconColor: '#2563EB' },
    success: { bg: 'rgba(22,163,74,0.06)', border: GREEN, icon: '&#10003;', iconColor: GREEN },
    danger: { bg: 'rgba(220,38,38,0.06)', border: RED, icon: '&#9888;', iconColor: RED },
  };
  const s = styles[opts.type];
  return `<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:16px 0;"><tr><td style="padding:16px 20px;background-color:${s.bg};border-radius:10px;border-left:4px solid ${s.border};"><table width="100%" cellpadding="0" cellspacing="0" role="presentation"><tr><td style="width:30px;vertical-align:top;"><span style="font-size:18px;color:${s.iconColor};">${s.icon}</span></td><td><p style="margin:0 0 4px;font-size:14px;font-weight:700;color:${TEXT_DARK};">${opts.title}</p><p style="margin:0;font-size:13px;color:${TEXT_BODY};line-height:1.6;">${opts.text}</p></td></tr></table></td></tr></table>`;
}

export function buildMiniDonut(opts: { label: string; percent: number; color?: string; size?: number; }): string {
  const color = opts.color || GOLD;
  const size = opts.size || 64;
  const pct = Math.min(Math.max(opts.percent, 0), 100);
  const deg = Math.round(pct * 3.6);
  return `<table cellpadding="0" cellspacing="0" role="presentation" style="display:inline-block;margin:8px 12px;"><tr><td align="center"><div style="width:${size}px;height:${size}px;border-radius:50%;background:conic-gradient(${color} ${deg}deg, ${CARD_ELEVATED} ${deg}deg);display:flex;align-items:center;justify-content:center;"><div style="width:${size - 16}px;height:${size - 16}px;border-radius:50%;background-color:${BODY_BG};margin:8px;text-align:center;line-height:${size - 16}px;"><span style="font-size:14px;font-weight:800;color:${color};">${pct}%</span></div></div></td></tr><tr><td align="center" style="padding-top:6px;"><span style="font-size:10px;font-weight:600;color:${TEXT_CAPTION};text-transform:uppercase;letter-spacing:0.5px;">${opts.label}</span></td></tr></table>`;
}

export function buildHeatmapRow(items: { label: string; value: string; intensity: number; }[]): string {
  const HEAT_BG = "#1B2030";
  const HEAT_BORDER = "#2A3148";
  const cells = items.map(item => {
    const isPos = item.intensity >= 0;
    const absI = Math.min(Math.abs(item.intensity), 100);
    const opacity = Math.max(absI / 100 * 0.5, 0.08);
    const bgColor = isPos ? `rgba(52,211,153,${opacity})` : `rgba(248,113,113,${opacity})`;
    const valueColor = isPos ? '#34D399' : '#F87171';
    return `<td style="padding:14px 8px;background-color:${HEAT_BG};background-image:linear-gradient(135deg,${bgColor},transparent);text-align:center;border-radius:8px;border:1px solid ${HEAT_BORDER};"><p style="margin:0;font-size:9px;font-weight:700;color:#8B95A8;text-transform:uppercase;letter-spacing:1px;">${item.label}</p><p style="margin:4px 0 0;font-size:16px;font-weight:800;color:${valueColor};">${item.value}</p></td>`;
  }).join('<td style="width:6px;"></td>');
  return `<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:12px 0;" class="card-grid"><tr>${cells}</tr></table>`;
}

export function buildKeyMetricCard(opts: { label: string; value: string; change?: string; note?: string; accentColor?: string; }): string {
  const accent = opts.accentColor || GOLD;
  const isPos = opts.change?.startsWith('+');
  const changeColor = isPos ? GREEN : opts.change?.startsWith('-') ? RED : TEXT_CAPTION;
  return `<table cellpadding="0" cellspacing="0" role="presentation" style="display:inline-block;margin:8px;"><tr><td style="padding:16px 24px;background-color:${CARD_BG};border-radius:12px;border:1px solid ${BORDER_LIGHT};text-align:center;min-width:140px;"><p style="margin:0;font-size:10px;color:${TEXT_CAPTION};text-transform:uppercase;letter-spacing:1.5px;font-weight:700;">${opts.label}</p><p style="margin:6px 0 0;font-size:28px;font-weight:800;color:${accent};letter-spacing:-1px;">${opts.value}</p>${opts.change ? `<p style="margin:4px 0 0;font-size:14px;font-weight:700;color:${changeColor};">${opts.change}</p>` : ''}${opts.note ? `<p style="margin:4px 0 0;font-size:11px;color:${TEXT_CAPTION};">${opts.note}</p>` : ''}</td></tr></table>`;
}
