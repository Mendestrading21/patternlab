/**
 * WMB Free Account Welcome Email V10 — Dark Shell + Light Core
 * ─────────────────────────────────────────────────────────
 * Sent when a user creates a FREE account (via /tarif or register page).
 * Different from the paid welcome email (welcome.ts) and the theme-only email (freeTheme.ts).
 *
 * Content:
 * - Welcome message
 * - What WMB is and what it offers
 * - What the free account includes (discovery tier)
 * - What premium unlocks (soft upsell)
 * - Single CTA to dashboard
 */
import { sendEmail, buildWmbEmailHtml } from "../email";

const SITE_URL = "https://wallstreetmarketbrief.ch";

// V10 Light Core tokens
const CARD_BG = "#F7F8FA";
const BORDER_LIGHT = "#E5E7EB";
const TEXT_DARK = "#1A1A1A";
const TEXT_BODY = "#374151";
const TEXT_CAPTION = "#6B7280";
const GOLD = "#C8A960";
const GREEN = "#16A34A";
const BLUE = "#2563EB";

/**
 * Send a welcome email to a NEW free account user.
 * Explains what WMB is, what they get for free, and what premium unlocks.
 */
export async function sendFreeAccountWelcomeEmail(
  email: string,
  name: string
): Promise<boolean> {
  try {
    const displayName = name || "cher investisseur";

    const html = buildWmbEmailHtml({
      title: `Bienvenue sur WallStreet Market Brief`,
      preheader: "Votre compte gratuit est actif. D\u00e9couvrez ce qui vous attend.",
      bodyHtml: `
        <p style="font-size:15px;color:${TEXT_DARK};line-height:1.7;margin:0 0 16px;">
          Bienvenue sur <strong style="color:${TEXT_DARK};">WallStreet Market Brief</strong>.
        </p>
        <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 20px;">
          WMB est une plateforme d'information financi&egrave;re qui r&eacute;sume l'essentiel des march&eacute;s de mani&egrave;re claire, structur&eacute;e et p&eacute;dagogique. Aucun conseil, aucun signal &mdash; uniquement du contexte, des chiffres sourc&eacute;s et des sc&eacute;narios conditionnels.
        </p>

        <!-- ═══ Ce que vous avez avec votre compte gratuit ═══ -->
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 8px;">
          <tr>
            <td>
              <div style="display:inline-block;width:3px;height:16px;background-color:${GREEN};border-radius:2px;vertical-align:middle;margin-right:10px;"></div>
              <span style="font-size:14px;font-weight:700;color:${TEXT_DARK};vertical-align:middle;">Votre acc&egrave;s D&eacute;couverte (gratuit)</span>
            </td>
          </tr>
        </table>

        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:12px 0 24px;">
          <tr>
            <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GREEN};border:1px solid ${BORDER_LIGHT};">
              <p style="margin:0 0 3px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Terminal March&eacute;s</p>
              <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">Indices, crypto, calendrier &eacute;conomique &mdash; donn&eacute;es en temps r&eacute;el</p>
            </td>
          </tr>
          <tr><td style="height:6px;"></td></tr>
          <tr>
            <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GREEN};border:1px solid ${BORDER_LIGHT};">
              <p style="margin:0 0 3px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Outils gratuits</p>
              <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">Calculateur d'int&eacute;r&ecirc;ts compos&eacute;s, simulateur de dividendes</p>
            </td>
          </tr>
          <tr><td style="height:6px;"></td></tr>
          <tr>
            <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GREEN};border:1px solid ${BORDER_LIGHT};">
              <p style="margin:0 0 3px;font-weight:700;font-size:13px;color:${TEXT_DARK};">News financi&egrave;res</p>
              <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">5 articles par jour, r&eacute;sum&eacute;s et filtr&eacute;s</p>
            </td>
          </tr>
          <tr><td style="height:6px;"></td></tr>
          <tr>
            <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GREEN};border:1px solid ${BORDER_LIGHT};">
              <p style="margin:0 0 3px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Th&egrave;me du Mois</p>
              <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">Une analyse sectorielle approfondie offerte chaque mois</p>
            </td>
          </tr>
          <tr><td style="height:6px;"></td></tr>
          <tr>
            <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GREEN};border:1px solid ${BORDER_LIGHT};">
              <p style="margin:0 0 3px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Formation &amp; Glossaire</p>
              <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};line-height:1.5;">Acc&egrave;s au hub de formation et au glossaire de 1 007+ termes financiers</p>
            </td>
          </tr>
        </table>

        <!-- ═══ Ce que Premium débloque ═══ -->
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 8px;">
          <tr>
            <td>
              <div style="display:inline-block;width:3px;height:16px;background-color:${GOLD};border-radius:2px;vertical-align:middle;margin-right:10px;"></div>
              <span style="font-size:14px;font-weight:700;color:${TEXT_DARK};vertical-align:middle;">Ce que les abonn&eacute;s Premium d&eacute;bloquent</span>
            </td>
          </tr>
        </table>

        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:12px 0 24px;">
          <tr>
            <td style="padding:16px 18px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">5 modules (March&eacute; US, Actions US, Monde, Suisse)</span></td></tr>
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">Archives compl&egrave;tes de toutes les &eacute;ditions</span></td></tr>
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">Formation compl&egrave;te avec 437+ le&ccedil;ons et quiz</span></td></tr>
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">Outils avanc&eacute;s : screener, portefeuille virtuel, barom&egrave;tre</span></td></tr>
                <tr><td style="padding:4px 0;"><span style="color:${TEXT_BODY};font-size:12px;line-height:1.6;">Toutes les th&eacute;matiques sectorielles (pas seulement le mois en cours)</span></td></tr>
              </table>
            </td>
          </tr>
        </table>

        <!-- ═══ Upsell block ═══ -->
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;">
          <tr>
            <td style="padding:18px 22px;background-color:#111318;border-radius:8px;">
              <p style="margin:0 0 6px;font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:${GOLD};font-weight:700;">Aller plus loin</p>
              <p style="margin:0 0 12px;font-size:13px;color:#9CA3AF;line-height:1.6;">
                D&egrave;s CHF 49/mois, acc&eacute;dez &agrave; l'int&eacute;gralit&eacute; de la plateforme : modules, formation, outils avanc&eacute;s et archives compl&egrave;tes.
              </p>
              <table cellpadding="0" cellspacing="0" role="presentation">
                <tr>
                  <td style="padding:8px 18px;border:1px solid rgba(200,169,96,0.4);border-radius:6px;">
                    <a href="${SITE_URL}/pricing" style="color:${GOLD};text-decoration:none;font-size:12px;font-weight:700;letter-spacing:0.3px;">D&eacute;couvrir les offres &rarr;</a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>

        <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0;">
          Explorez d&egrave;s maintenant votre espace membre pour d&eacute;couvrir tout ce qui est disponible.
        </p>
      `,
      ctaText: "Acc\u00e9der \u00e0 mon espace",
      ctaUrl: `${SITE_URL}/dashboard`,
      footerText: "Vous recevez cet email suite \u00e0 la cr\u00e9ation de votre compte gratuit sur WallStreet Market Brief.",
    });

    const sent = await sendEmail({
      to: email,
      subject: "Bienvenue sur WallStreet Market Brief \u2014 Votre compte est actif",
      html,
      tag: "bienvenue",
    });

    if (sent) {
      console.log(`[WelcomeFree] Welcome email sent to ${email}`);
    }
    return sent;
  } catch (error) {
    console.error(`[WelcomeFree] Error sending welcome email:`, error);
    return false;
  }
}

/**
 * Send free welcome email + notify owner
 */
export async function sendFreeAccountWelcomeWithNotification(
  email: string,
  name: string,
  userId: string
): Promise<boolean> {
  // Send welcome email to user
  await sendFreeAccountWelcomeEmail(email, name);

  // Admin notification is handled via sendAdminNotification in emailAuth.ts
  console.log(`[WelcomeFree] Free welcome email sent for ${email}`);
  return true;
}
