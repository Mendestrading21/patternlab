"""
WMB — Send ALL email types to elio_mendes@hotmail.com for design verification
Uses Brevo HTTP API (not SMTP) for sandbox compatibility
"""
import os, json, time
from urllib.request import Request, urlopen

API_KEY = os.environ.get("BREVO_API_KEY", "")
SENDER = {"name": "WallStreet Market Brief", "email": "contact@wallstreetmarketbrief.ch"}
TO = [{"email": "elio_mendes@hotmail.com", "name": "Elio Mendes"}]
SITE = "https://wallstreetmarketbrief.ch"

# ─── Design tokens V5 ───
DARK = "#0C1018"
BG = "#f4f5f5"
CARD = "#ffffff"
TEXT = "#1a1a1a"
MUTED = "#64748b"
LIGHT = "#94a3b8"
BORDER = "#e2e8f0"
BRAND = "#344453"
GOLD = "#9a8560"
FONT = "'Helvetica Neue',Helvetica,Arial,sans-serif"

def wrap(title, preheader, body_html, cta_text=None, cta_url=None, footer_text=None, accent=BRAND):
    """Build full V5 email HTML"""
    pre = f'<span style="display:none;font-size:1px;color:{BG};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">{preheader}</span>' if preheader else ""
    
    cta = ""
    if cta_text and cta_url:
        cta = f'<tr><td style="padding:28px 44px 0;" class="pad" align="center"><a href="{cta_url}" style="display:inline-block;padding:14px 52px;background:{accent};color:#ffffff;font-size:13px;font-weight:700;text-decoration:none;border-radius:3px;letter-spacing:0.5px;">{cta_text}</a></td></tr>'
    
    foot = footer_text or "Vous recevez cet email car vous &ecirc;tes abonn&eacute;(e) &agrave; WallStreet Market Brief."
    year = "2026"
    
    return f"""<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="x-apple-disable-message-reformatting">
<meta name="format-detection" content="telephone=no,address=no,email=no,date=no,url=no">
<meta name="color-scheme" content="light">
<meta name="supported-color-schemes" content="light">
<title>WallStreet Market Brief</title>
{pre}
<style>
body{{margin:0;padding:0;background:{BG};font-family:{FONT};-webkit-font-smoothing:antialiased;color:{TEXT};}}
a{{color:{BRAND};text-decoration:none;}}
table{{border-collapse:collapse;}}
p{{margin:0;}}
@media only screen and (max-width:620px){{.outer{{width:100%!important;}}.pad{{padding-left:20px!important;padding-right:20px!important;}}.h1{{font-size:20px!important;}}}}
</style>
</head>
<body style="margin:0;padding:0;background:{BG};-webkit-text-size-adjust:100%;">
<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background:{BG};padding:24px 16px;">
<tr><td align="center">
<table class="outer" width="580" cellpadding="0" cellspacing="0" role="presentation" style="max-width:580px;width:100%;border-radius:4px;overflow:hidden;">

<!-- HEADER -->
<tr><td style="background:{DARK};padding:36px 44px 28px;" class="pad" align="center">
<table cellpadding="0" cellspacing="0" role="presentation">
<tr><td align="center"><span style="font-size:24px;font-weight:800;letter-spacing:7px;color:#ffffff;">WALLSTREET</span></td></tr>
<tr><td align="center" style="padding-top:3px;"><span style="font-size:11px;font-weight:600;letter-spacing:5px;color:{GOLD};">MARKET BRIEF</span></td></tr>
</table>
<table cellpadding="0" cellspacing="0" role="presentation" style="margin-top:20px;">
<tr><td align="center"><span style="font-size:9px;letter-spacing:3px;text-transform:uppercase;color:rgba(255,255,255,0.3);">Newsletter hebdomadaire &middot; Chaque dimanche</span></td></tr>
</table>
</td></tr>

<!-- GOLD LINE -->
<tr><td style="background:{DARK};padding:0 44px;" class="pad"><div style="height:2px;background:linear-gradient(90deg,transparent,{GOLD},transparent);"></div></td></tr>

<!-- TITLE -->
<tr><td style="background:{CARD};padding:32px 44px 0;" class="pad">
<h1 class="h1" style="margin:0;font-size:26px;font-weight:800;line-height:1.25;color:{TEXT};">{title}</h1>
</td></tr>

<!-- BODY -->
<tr><td style="background:{CARD};padding:20px 44px 0;color:{MUTED};font-size:14px;line-height:1.7;" class="pad">
{body_html}
</td></tr>

<!-- CTA -->
{cta}

<!-- SPACER -->
<tr><td style="background:{CARD};padding:28px 0 0;"></td></tr>

<!-- FOOTER LINE -->
<tr><td style="background:{CARD};padding:0 44px;" class="pad"><div style="height:1px;background:{BORDER};"></div></td></tr>

<!-- FOOTER -->
<tr><td style="background:{CARD};padding:20px 44px 28px;" class="pad" align="center">
<p style="margin:0 0 8px;font-size:11px;color:{LIGHT};line-height:1.6;">{foot}</p>
<p style="margin:0 0 12px;font-size:10px;color:#c0c0c0;line-height:1.5;">
<a href="{SITE}/compte" style="color:{LIGHT};text-decoration:underline;">G&eacute;rer mes pr&eacute;f&eacute;rences</a>
&nbsp;&middot;&nbsp;
<a href="{SITE}/mentions-legales" style="color:{LIGHT};text-decoration:underline;">Mentions l&eacute;gales</a>
&nbsp;&middot;&nbsp;
<a href="{SITE}/desabonnement" style="color:{LIGHT};text-decoration:underline;">Se d&eacute;sabonner</a>
</p>
<p style="margin:0;font-size:9px;color:#d0d0d0;line-height:1.6;">
Ce contenu est purement informatif et ne constitue pas un conseil en investissement.<br>
&copy; {year} WallStreet Market Brief. Tous droits r&eacute;serv&eacute;s.
</p>
</td></tr>

</table>
</td></tr>
</table>
</body>
</html>"""


def module_card(name, desc, color):
    return f'''<tr>
<td style="padding:16px;background-color:#F4F5F5;border-radius:10px;border-left:3px solid {color};">
<p style="margin:0 0 4px;font-weight:600;font-size:14px;color:#344453;">{name}</p>
<p style="margin:0;font-size:13px;color:rgba(30,30,30,0.5);">{desc}</p>
</td>
</tr>
<tr><td style="height:8px;"></td></tr>'''


def check_item(title, desc):
    return f'''<tr>
<td style="padding:14px 16px;background-color:#F4F5F5;border-radius:8px;border-bottom:1px solid #E1E6EA;">
<table width="100%" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td style="color:#2E7D5B;font-size:14px;font-weight:700;width:24px;vertical-align:top;">+</td>
<td style="padding-left:8px;">
<p style="margin:0;font-weight:600;font-size:14px;color:#344453;">{title}</p>
<p style="margin:2px 0 0;font-size:12px;color:rgba(30,30,30,0.4);">{desc}</p>
</td>
</tr>
</table>
</td>
</tr>
<tr><td style="height:6px;"></td></tr>'''


def detail_block(label, content, color="#2E7D5B"):
    return f'''<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:16px 0;">
<tr>
<td style="padding:16px;background-color:#F4F5F5;border-radius:10px;border-left:3px solid {color};">
<p style="margin:0 0 8px;font-weight:600;font-size:14px;color:#344453;">{label}</p>
<p style="margin:0;font-size:13px;color:rgba(30,30,30,0.7);line-height:1.8;">{content}</p>
</td>
</tr>
</table>'''


def send(subject, html):
    data = json.dumps({"sender": SENDER, "to": TO, "subject": subject, "htmlContent": html}).encode()
    req = Request("https://api.brevo.com/v3/smtp/email", data=data, headers={"api-key": API_KEY, "Content-Type": "application/json", "Accept": "application/json"}, method="POST")
    try:
        resp = urlopen(req)
        print(f"  OK ({resp.status}) — {subject}")
        return True
    except Exception as e:
        print(f"  FAIL — {subject}: {e}")
        return False


# ═══════════════════════════════════════════════════════
# 1. VERIFICATION EMAIL
# ═══════════════════════════════════════════════════════
print("\n1. Email de verification...")
send(
    "Verifiez votre adresse email -- WallStreet Market Brief",
    wrap(
        "Bienvenue, Elio !",
        "Verifiez votre adresse email pour activer votre compte WMB.",
        """<p>Merci de vous &ecirc;tre inscrit sur <strong>WallStreet Market Brief</strong>.</p>
        <p style="margin-top:12px;">Pour activer votre compte et acc&eacute;der &agrave; toutes les fonctionnalit&eacute;s, veuillez v&eacute;rifier votre adresse email en cliquant sur le bouton ci-dessous.</p>
        <p style="color:rgba(30,30,30,0.4);font-size:13px;margin-top:24px;">Si vous n'avez pas cr&eacute;&eacute; de compte, ignorez cet email.<br>Ce lien expire dans 24 heures.</p>""",
        "Verifier mon email",
        f"{SITE}/verify-email?token=test-token-123",
        "Vous recevez cet email suite &agrave; votre inscription sur WallStreet Market Brief."
    )
)
time.sleep(1)

# ═══════════════════════════════════════════════════════
# 2. RESET MOT DE PASSE
# ═══════════════════════════════════════════════════════
print("2. Email reset mot de passe...")
send(
    "Reinitialisation de votre mot de passe -- WallStreet Market Brief",
    wrap(
        "Bonjour, Elio",
        "Reinitialisez votre mot de passe WallStreet Market Brief.",
        """<p>Vous avez demand&eacute; la r&eacute;initialisation de votre mot de passe.</p>
        <p style="margin-top:12px;">Cliquez sur le bouton ci-dessous pour choisir un nouveau mot de passe.</p>
        <p style="color:rgba(30,30,30,0.4);font-size:13px;margin-top:24px;">Si vous n'avez pas demand&eacute; cette r&eacute;initialisation, ignorez cet email.<br>Ce lien expire dans 1 heure.</p>""",
        "Reinitialiser mon mot de passe",
        f"{SITE}/reset-password?token=test-token-456",
        "Vous recevez cet email suite &agrave; une demande de r&eacute;initialisation de mot de passe."
    )
)
time.sleep(1)

# ═══════════════════════════════════════════════════════
# 3. BIENVENUE — Abonnement BRIEFS (Newsletter seule)
# ═══════════════════════════════════════════════════════
print("3. Email bienvenue — Abonnement Briefs...")
modules = f'''<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:20px 0;">
{module_card("Module Marche US", "Tendances, macro, risques, volatilite, scenarios", "#2E7D5B")}
{module_card("Module Actions US", "Top movers, secteurs, earnings, watchlist", "#D4A853")}
{module_card("Revue Hebdo Monde", "Europe, Asie, emergents, forex, commodities, crypto", "#0EA5E9")}
{module_card("Revue Hebdo Suisse", "SMI, CHF, BNS, blue chips, economie suisse", "#EC4899")}
</table>'''

send(
    "Bienvenue sur WallStreet Market Brief -- Abonnement Briefs active",
    wrap(
        "Bienvenue, Elio !",
        "Votre abonnement Briefs est actif.",
        f"""<p>Merci pour votre confiance ! Votre abonnement <strong>Briefs</strong> (CHF 19/mois) est maintenant actif. Vous recevrez chaque dimanche les 4 modules de la newsletter hebdomadaire.</p>
        {modules}
        <p style="margin-top:20px;"><strong>Ce qui vous attend chaque dimanche :</strong></p>
        <ul style="padding-left:20px;color:rgba(30,30,30,0.6);font-size:14px;line-height:2;">
          <li>4 modules compl&eacute;mentaires chaque semaine</li>
          <li>15 &agrave; 20 minutes de lecture par module</li>
          <li>Chiffres sourc&eacute;s, sc&eacute;narios conditionnels, risques identifi&eacute;s</li>
          <li>Aucun conseil, aucun signal &mdash; du contexte et de la clart&eacute;</li>
        </ul>
        <p style="margin-top:20px;">Vous pouvez d&egrave;s maintenant acc&eacute;der &agrave; votre espace membre pour consulter l'ensemble de vos contenus.</p>""",
        "Acceder a mon espace membre",
        f"{SITE}/dashboard",
        "Vous recevez cet email suite &agrave; votre abonnement Briefs sur WallStreet Market Brief."
    )
)
time.sleep(1)

# ═══════════════════════════════════════════════════════
# 4. BIENVENUE — Abonnement ACADEMY (Formation seule)
# ═══════════════════════════════════════════════════════
print("4. Email bienvenue — Abonnement Academy...")
academy = f'''<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:20px 0;">
{module_card("Formation Complete", "Cours structures, videos, quiz interactifs, glossaires", "#344453")}
{module_card("Thematiques Avancees", "Indicateurs, strategies, analyse technique et fondamentale", "#D4A853")}
{module_card("Quiz et Exercices", "Testez vos connaissances, progressez a votre rythme", "#2E7D5B")}
</table>'''

send(
    "Bienvenue sur WallStreet Market Brief -- Abonnement Academy active",
    wrap(
        "Bienvenue, Elio !",
        "Votre abonnement Academy est actif.",
        f"""<p>Merci pour votre confiance ! Votre abonnement <strong>Academy</strong> (CHF 39/mois) est maintenant actif. Vous avez acc&egrave;s &agrave; l'int&eacute;gralit&eacute; de la formation Acad&eacute;mie WMB.</p>
        {academy}
        <p style="margin-top:20px;"><strong>Ce qui vous attend :</strong></p>
        <ul style="padding-left:20px;color:rgba(30,30,30,0.6);font-size:14px;line-height:2;">
          <li>Cours structur&eacute;s du d&eacute;butant &agrave; l'avanc&eacute;</li>
          <li>Quiz interactifs pour valider vos acquis</li>
          <li>Glossaires et fiches th&eacute;matiques compl&egrave;tes</li>
          <li>Progression &agrave; votre rythme, contenu mis &agrave; jour r&eacute;guli&egrave;rement</li>
        </ul>
        <p style="margin-top:20px;">Vous pouvez d&egrave;s maintenant acc&eacute;der &agrave; votre espace membre pour consulter l'ensemble de vos contenus.</p>""",
        "Acceder a mon espace membre",
        f"{SITE}/dashboard",
        "Vous recevez cet email suite &agrave; votre abonnement Academy sur WallStreet Market Brief."
    )
)
time.sleep(1)

# ═══════════════════════════════════════════════════════
# 5. BIENVENUE — Abonnement PRO PACK (Pack Complet)
# ═══════════════════════════════════════════════════════
print("5. Email bienvenue — Abonnement Pro Pack...")
send(
    "Bienvenue sur WallStreet Market Brief -- Abonnement Pro Pack active",
    wrap(
        "Bienvenue, Elio !",
        "Votre abonnement Pro Pack est actif.",
        f"""<p>Merci pour votre confiance ! Votre abonnement <strong>Pro Pack</strong> (CHF 49/mois) est maintenant actif. Vous avez acc&egrave;s &agrave; l'ensemble de la plateforme : newsletter hebdomadaire, formation Acad&eacute;mie, et tous les outils.</p>
        <p style="font-weight:600;font-size:15px;color:#344453;margin:24px 0 12px;">Vos modules hebdomadaires</p>
        {modules}
        <p style="font-weight:600;font-size:15px;color:#344453;margin:24px 0 12px;">Votre formation Academie</p>
        {academy}
        <p style="margin-top:20px;"><strong>Ce qui vous attend :</strong></p>
        <ul style="padding-left:20px;color:rgba(30,30,30,0.6);font-size:14px;line-height:2;">
          <li>4 modules compl&eacute;mentaires chaque dimanche</li>
          <li>Formation compl&egrave;te avec cours, quiz et th&eacute;matiques</li>
          <li>Outils interactifs : simulateur, calculateurs, portefeuille virtuel</li>
          <li>Chiffres sourc&eacute;s, sc&eacute;narios conditionnels, risques identifi&eacute;s</li>
        </ul>
        <p style="margin-top:20px;">Vous pouvez d&egrave;s maintenant acc&eacute;der &agrave; votre espace membre pour consulter l'ensemble de vos contenus.</p>""",
        "Acceder a mon espace membre",
        f"{SITE}/dashboard",
        "Vous recevez cet email suite &agrave; votre abonnement Pro Pack sur WallStreet Market Brief."
    )
)
time.sleep(1)

# ═══════════════════════════════════════════════════════
# 6. ONBOARDING — Guide de demarrage (J+1)
# ═══════════════════════════════════════════════════════
print("6. Email onboarding — Guide de demarrage...")
send(
    "Votre guide de demarrage -- WallStreet Market Brief",
    wrap(
        "Elio, decouvrez tout ce que WMB vous offre",
        "Outils premium, news financieres, formation -- votre guide de demarrage.",
        f"""<p>Vous avez cr&eacute;&eacute; votre compte hier &mdash; voici un tour rapide de ce qui vous attend.</p>
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:24px 0;">
        {module_card("Outils Premium", "Simulateur de portefeuille, scripts TradingView, strategies de trading -- directement dans votre espace membre.", "#344453")}
        {module_card("News Financieres", "Les actualites macro et marches les plus pertinentes, filtrees et resumees pour vous chaque jour.", "#2E7D5B")}
        {module_card("Outils Interactifs", "Calculateur d'interets composes, simulateur de dividendes -- des outils concrets pour vos decisions.", "#D4A853")}
        </table>
        <p>Tout cela est <strong>gratuit et accessible d&egrave;s maintenant</strong>. Connectez-vous pour explorer.</p>
        <p style="color:rgba(30,30,30,0.4);font-size:13px;margin-top:24px;"><strong>Envie d'aller plus loin ?</strong> L'abonnement Premium d&eacute;bloque la newsletter hebdomadaire (4 modules : USA, Monde, Suisse, Actions), toutes les &eacute;ditions en ligne, le portefeuille virtuel, et le scanner d'actions.</p>""",
        "Explorer mon espace",
        f"{SITE}/marches",
        "Vous recevez cet email car vous vous &ecirc;tes inscrit sur WallStreet Market Brief."
    )
)
time.sleep(1)

# ═══════════════════════════════════════════════════════
# 7. ONBOARDING — Premium Push (J+7)
# ═══════════════════════════════════════════════════════
print("7. Email onboarding — Premium Push...")
send(
    "Debloquez tout le potentiel de WMB -- Offre Premium",
    wrap(
        "Elio, pret a passer au niveau superieur ?",
        "Debloquez la newsletter premium et tous les outils avances.",
        f"""<p>Cela fait une semaine que vous avez rejoint WMB. Vous avez eu le temps de d&eacute;couvrir le terminal march&eacute;s, les news et les outils gratuits.</p>
        <p style="margin-top:12px;">Voici ce que vous d&eacute;bloquez avec <strong>l'abonnement Premium</strong> :</p>
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:20px 0;">
        {check_item("4 modules chaque semaine", "Marche US, Actions US, Monde, Suisse")}
        {check_item("Toutes les editions en ligne", "Toutes les editions passees, consultables et telechargeables")}
        {check_item("Outils avances", "Portefeuille virtuel, scanner d'actions, simulateur de position")}
        {check_item("Terminal complet", "Actions US detaillees, Forex, Commodities, Analyse 360")}
        </table>
        <p style="text-align:center;margin:24px 0 8px;">
          <strong style="font-size:18px;color:#344453;">D&egrave;s CHF 19/mois</strong><br>
          <span style="font-size:13px;color:rgba(30,30,30,0.4);">Briefs, Academy ou Pro Pack &mdash; Sans engagement</span>
        </p>
        <p style="color:rgba(30,30,30,0.4);font-size:13px;margin-top:24px;text-align:center;">Satisfait ou rembours&eacute; 14 jours &middot; R&eacute;siliation en un clic &middot; Paiement s&eacute;curis&eacute; Stripe</p>""",
        "Decouvrir les offres Premium",
        f"{SITE}/pricing",
        "Vous recevez cet email car vous vous &ecirc;tes inscrit sur WallStreet Market Brief.",
        accent="#D4A853"
    )
)
time.sleep(1)

# ═══════════════════════════════════════════════════════
# 8. ADMIN — Nouvelle inscription
# ═══════════════════════════════════════════════════════
print("8. Email admin — Nouvelle inscription...")
send(
    "[WMB Admin] Nouvel inscrit -- Elio Mendes",
    wrap(
        "Nouvelle inscription",
        "Nouvel inscrit -- Elio Mendes",
        f"""<p style="font-size:15px;color:#1E1E1E;">Un nouvel utilisateur vient de s'inscrire sur WallStreet Market Brief.</p>
        {detail_block("Details", "<strong>Nom :</strong> Elio Mendes<br><strong>Email :</strong> elio_mendes@hotmail.com<br><strong>Date :</strong> 5 mars 2026 &agrave; 16:30<br><strong>Methode :</strong> Email + mot de passe", "#2E7D5B")}""",
        "Voir le Dashboard Admin",
        f"{SITE}/admin",
        "Notification automatique &mdash; WallStreet Market Brief Admin",
        accent="#2E7D5B"
    )
)
time.sleep(1)

# ═══════════════════════════════════════════════════════
# 9. ADMIN — Nouveau paiement
# ═══════════════════════════════════════════════════════
print("9. Email admin — Nouveau paiement...")
send(
    "[WMB Admin] Nouveau paiement -- Elio Mendes (Pro Pack)",
    wrap(
        "Nouveau paiement recu",
        "Nouveau paiement -- Elio Mendes (Pro Pack)",
        f"""<p style="font-size:15px;color:#1E1E1E;">Un paiement a &eacute;t&eacute; re&ccedil;u sur WallStreet Market Brief.</p>
        {detail_block("Details du paiement", "<strong>Client :</strong> Elio Mendes<br><strong>Email :</strong> elio_mendes@hotmail.com<br><strong>Plan :</strong> Pro Pack (49 CHF/mois)<br><strong>Montant :</strong> 49.00 CHF<br><strong>Date :</strong> 5 mars 2026 &agrave; 16:30", "#D4A853")}""",
        "Voir le Dashboard Admin",
        f"{SITE}/admin",
        "Notification automatique &mdash; WallStreet Market Brief Admin",
        accent="#2E7D5B"
    )
)
time.sleep(1)

# ═══════════════════════════════════════════════════════
# 10. ADMIN — Nouvel abonnement
# ═══════════════════════════════════════════════════════
print("10. Email admin — Nouvel abonnement...")
send(
    "[WMB Admin] Nouvel abonne -- Elio Mendes (Pro Pack)",
    wrap(
        "Nouvel abonnement active",
        "Nouvel abonne -- Elio Mendes (Pro Pack)",
        f"""<p style="font-size:15px;color:#1E1E1E;">Un nouvel abonnement vient d'&ecirc;tre activ&eacute; sur WallStreet Market Brief.</p>
        {detail_block("Details de l'abonnement", "<strong>Client :</strong> Elio Mendes<br><strong>Email :</strong> elio_mendes@hotmail.com<br><strong>Plan :</strong> Pro Pack (49 CHF/mois)<br><strong>Montant :</strong> 49.00 CHF<br><strong>Date :</strong> 5 mars 2026 &agrave; 16:30", "#2E7D5B")}
        <p style="font-size:14px;color:rgba(30,30,30,0.6);margin-top:12px;">L'utilisateur a maintenant acc&egrave;s &agrave; l'espace membre et aux &eacute;ditions.</p>""",
        "Voir le Dashboard Admin",
        f"{SITE}/admin",
        "Notification automatique &mdash; WallStreet Market Brief Admin",
        accent="#2E7D5B"
    )
)
time.sleep(1)

# ═══════════════════════════════════════════════════════
# 11. ADMIN — Desabonnement
# ═══════════════════════════════════════════════════════
print("11. Email admin — Desabonnement...")
send(
    "[WMB Admin] Desabonnement -- Elio Mendes",
    wrap(
        "Abonnement annule",
        "Desabonnement -- Elio Mendes",
        f"""<p style="font-size:15px;color:#1E1E1E;">Un abonnement vient d'&ecirc;tre annul&eacute; sur WallStreet Market Brief.</p>
        {detail_block("Details", "<strong>Client :</strong> Elio Mendes<br><strong>Email :</strong> elio_mendes@hotmail.com<br><strong>Date :</strong> 5 mars 2026 &agrave; 16:30", "#B0413E")}""",
        "Voir le Dashboard Admin",
        f"{SITE}/admin",
        "Notification automatique &mdash; WallStreet Market Brief Admin",
        accent="#B0413E"
    )
)
time.sleep(1)

# ═══════════════════════════════════════════════════════
# 12. ADMIN — Echec de paiement
# ═══════════════════════════════════════════════════════
print("12. Email admin — Echec de paiement...")
send(
    "[WMB Admin] Echec de paiement -- Elio Mendes",
    wrap(
        "Echec de paiement",
        "Echec de paiement -- Elio Mendes",
        f"""<p style="font-size:15px;color:#1E1E1E;">Un paiement a &eacute;chou&eacute; sur WallStreet Market Brief.</p>
        {detail_block("Details", "<strong>Client :</strong> Elio Mendes<br><strong>Email :</strong> elio_mendes@hotmail.com<br><strong>Info :</strong> Carte refusee - fonds insuffisants<br><strong>Date :</strong> 5 mars 2026 &agrave; 16:30", "#B0413E")}""",
        "Voir le Dashboard Admin",
        f"{SITE}/admin",
        "Notification automatique &mdash; WallStreet Market Brief Admin",
        accent="#B0413E"
    )
)
time.sleep(1)

# ═══════════════════════════════════════════════════════
# 13. NEWSLETTER — Recap hebdomadaire du dimanche
# ═══════════════════════════════════════════════════════
print("13. Email newsletter — Recap hebdomadaire...")

def score_cell(label, value, change, color):
    return f'''<td style="padding:12px 8px;text-align:center;border-bottom:1px solid #e2e8f0;">
<p style="margin:0;font-size:9px;letter-spacing:1.5px;text-transform:uppercase;color:#94a3b8;">{label}</p>
<p style="margin:4px 0 0;font-size:22px;font-weight:800;color:#1a1a1a;">{value}</p>
<p style="margin:2px 0 0;font-size:12px;font-weight:600;color:{color};">{change}</p>
</td>'''

scoreboard = f'''<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:20px 0;background:#f8fafc;border-radius:8px;overflow:hidden;">
<tr>
{score_cell("S&amp;P 500", "5,954", "+0.5%", "#2E7D5B")}
{score_cell("NASDAQ", "18,847", "+0.7%", "#2E7D5B")}
{score_cell("VIX", "19.6", "-3.2%", "#2E7D5B")}
{score_cell("10Y", "4.25%", "+2bp", "#B0413E")}
</tr>
</table>'''

module_btn = lambda name, color: f'<td style="padding:4px;"><a href="{SITE}/dashboard" style="display:block;padding:10px 4px;background:{color};color:#ffffff;font-size:11px;font-weight:700;text-align:center;border-radius:4px;text-decoration:none;letter-spacing:0.5px;">{name}</a></td>'

send(
    "WMB -- Brief de la Semaine 10",
    wrap(
        "Tensions sur les Taux &amp; Test IA",
        "S&P 500 +0.5%, VIX 19.6, 10Y 4.25% -- vos 4 modules sont prets.",
        f"""<p style="font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#94a3b8;margin-bottom:16px;">Resume hebdomadaire &mdash; Semaine 10</p>
        <p style="font-size:14px;color:#64748b;margin-bottom:4px;">3 &ndash; 7 mars 2026</p>
        <p style="font-size:14px;color:#64748b;">Le marche digere les tensions sur les taux, le VIX se detend, rebond technique sur signaux diplomatiques.</p>
        {scoreboard}
        <p style="font-weight:700;font-size:15px;color:#1a1a1a;margin:24px 0 8px;">Resume express</p>
        <ul style="padding-left:20px;color:#64748b;font-size:13px;line-height:2;">
          <li>S&amp;P 500 : rebond technique apr&egrave;s test du support 5,900</li>
          <li>Nasdaq : rotation vers la tech apr&egrave;s correction de 3 semaines</li>
          <li>VIX : retour sous 20, signal de d&eacute;tente &agrave; court terme</li>
          <li>10Y US : 4.25%, le march&eacute; anticipe un statu quo de la Fed</li>
          <li>Or : $2,950/oz, nouveau record historique, flux refuge actifs</li>
        </ul>
        <p style="font-weight:700;font-size:15px;color:#1a1a1a;margin:24px 0 8px;">Lecture WMB</p>
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:12px 0;">
          <tr>
            <td style="padding:12px 16px;background:#f0fdf4;border-radius:6px;border-left:3px solid #2E7D5B;">
              <p style="margin:0;font-size:12px;font-weight:700;color:#2E7D5B;letter-spacing:1px;">SCENARIO HAUSSIER</p>
              <p style="margin:4px 0 0;font-size:13px;color:#64748b;">SI le VIX reste sous 20 et les taux se stabilisent, ALORS le S&amp;P pourrait viser 6,050-6,100.</p>
            </td>
          </tr>
          <tr><td style="height:8px;"></td></tr>
          <tr>
            <td style="padding:12px 16px;background:#fef2f2;border-radius:6px;border-left:3px solid #B0413E;">
              <p style="margin:0;font-size:12px;font-weight:700;color:#B0413E;letter-spacing:1px;">RISQUE</p>
              <p style="margin:4px 0 0;font-size:13px;color:#64748b;">SINON, si les taux repassent au-dessus de 4.40%, pression vendeuse probable sur la tech et les small caps.</p>
            </td>
          </tr>
        </table>
        <p style="font-weight:700;font-size:15px;color:#1a1a1a;margin:28px 0 12px;">Vos modules sont prets</p>
        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
          <tr>
            {module_btn("USA", "#2E7D5B")}
            {module_btn("Monde", "#0EA5E9")}
            {module_btn("Suisse", "#EC4899")}
            {module_btn("Actions", "#D4A853")}
          </tr>
        </table>""",
        "Acceder a mon espace",
        f"{SITE}/dashboard",
        "Vous recevez cet email car vous &ecirc;tes abonn&eacute;(e) &agrave; WallStreet Market Brief."
    )
)

print("\n" + "="*50)
print("TERMINE — 13 emails envoyes a elio_mendes@hotmail.com")
print("="*50)
