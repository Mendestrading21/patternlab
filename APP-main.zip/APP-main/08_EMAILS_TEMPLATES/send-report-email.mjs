/**
 * Send the latest WMB report email via Brevo SMTP
 */
import nodemailer from "nodemailer";
import dotenv from "dotenv";
dotenv.config();

const transporter = nodemailer.createTransport({
  host: process.env.BREVO_SMTP_HOST || "smtp-relay.brevo.com",
  port: parseInt(process.env.BREVO_SMTP_PORT || "587", 10),
  secure: false,
  auth: {
    user: process.env.BREVO_SMTP_LOGIN,
    pass: process.env.BREVO_SMTP_PASSWORD,
  },
});

// Dernier rapport — Semaine 8 (17-21 février 2026)
const reportHtml = `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <span style="display:none;max-height:0;overflow:hidden">WMB — Rapport Hebdomadaire Semaine 8 | S&P 500, Nasdaq, Fed, Macro US</span>
  <style>
    body { margin: 0; padding: 0; background-color: #F4F5F5; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
  </style>
</head>
<body style="margin:0;padding:0;background-color:#F4F5F5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#F4F5F5;padding:24px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background-color:#FFFFFF;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.08);">
          
          <!-- Header -->
          <tr>
            <td style="background-color:#1E1E1E;padding:32px 40px;text-align:center;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="text-align:center;">
                    <span style="color:#FFFFFF;font-size:20px;font-weight:700;letter-spacing:0.5px;">WALLSTREET MARKET BRIEF</span>
                  </td>
                </tr>
                <tr>
                  <td style="text-align:center;padding-top:8px;">
                    <span style="color:rgba(255,255,255,0.4);font-size:12px;text-transform:uppercase;letter-spacing:2px;">Rapport Hebdomadaire</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Title Bar -->
          <tr>
            <td style="background-color:#344453;padding:20px 40px;">
              <h1 style="margin:0;color:#FFFFFF;font-size:22px;font-weight:600;line-height:1.3;">Semaine 8 — 17 au 21 f&eacute;vrier 2026</h1>
              <p style="margin:8px 0 0;color:rgba(255,255,255,0.6);font-size:13px;">Module March&eacute; US &mdash; R&eacute;sum&eacute; hebdomadaire</p>
            </td>
          </tr>

          <!-- Scoreboard -->
          <tr>
            <td style="padding:28px 40px 0;">
              <h2 style="margin:0 0 16px;color:#344453;font-size:18px;font-weight:700;border-bottom:2px solid #344453;padding-bottom:8px;">Scoreboard</h2>
              <table width="100%" cellpadding="8" cellspacing="0" style="font-size:14px;border-collapse:collapse;">
                <tr style="background-color:#F4F5F5;">
                  <td style="font-weight:600;color:#344453;padding:10px 12px;">Indice</td>
                  <td style="font-weight:600;color:#344453;padding:10px 12px;text-align:right;">Cl&ocirc;ture</td>
                  <td style="font-weight:600;color:#344453;padding:10px 12px;text-align:right;">Variation</td>
                </tr>
                <tr>
                  <td style="padding:10px 12px;color:#1E1E1E;">S&P 500</td>
                  <td style="padding:10px 12px;text-align:right;color:#1E1E1E;">6 117</td>
                  <td style="padding:10px 12px;text-align:right;color:#2E7D5B;font-weight:600;">+1.47%</td>
                </tr>
                <tr style="background-color:#FAFAFA;">
                  <td style="padding:10px 12px;color:#1E1E1E;">Nasdaq 100</td>
                  <td style="padding:10px 12px;text-align:right;color:#1E1E1E;">21 920</td>
                  <td style="padding:10px 12px;text-align:right;color:#2E7D5B;font-weight:600;">+1.82%</td>
                </tr>
                <tr>
                  <td style="padding:10px 12px;color:#1E1E1E;">Dow Jones</td>
                  <td style="padding:10px 12px;text-align:right;color:#1E1E1E;">44 424</td>
                  <td style="padding:10px 12px;text-align:right;color:#2E7D5B;font-weight:600;">+0.95%</td>
                </tr>
                <tr style="background-color:#FAFAFA;">
                  <td style="padding:10px 12px;color:#1E1E1E;">VIX</td>
                  <td style="padding:10px 12px;text-align:right;color:#1E1E1E;">15.2</td>
                  <td style="padding:10px 12px;text-align:right;color:#2E7D5B;font-weight:600;">-8.4%</td>
                </tr>
                <tr>
                  <td style="padding:10px 12px;color:#1E1E1E;">EUR/USD</td>
                  <td style="padding:10px 12px;text-align:right;color:#1E1E1E;">1.0485</td>
                  <td style="padding:10px 12px;text-align:right;color:#B0413E;font-weight:600;">-0.32%</td>
                </tr>
                <tr style="background-color:#FAFAFA;">
                  <td style="padding:10px 12px;color:#1E1E1E;">US 10Y</td>
                  <td style="padding:10px 12px;text-align:right;color:#1E1E1E;">4.43%</td>
                  <td style="padding:10px 12px;text-align:right;color:#B0413E;font-weight:600;">+5 bps</td>
                </tr>
                <tr>
                  <td style="padding:10px 12px;color:#1E1E1E;">Or (XAU)</td>
                  <td style="padding:10px 12px;text-align:right;color:#1E1E1E;">$2 938</td>
                  <td style="padding:10px 12px;text-align:right;color:#2E7D5B;font-weight:600;">+1.85%</td>
                </tr>
                <tr style="background-color:#FAFAFA;">
                  <td style="padding:10px 12px;color:#1E1E1E;">Bitcoin</td>
                  <td style="padding:10px 12px;text-align:right;color:#1E1E1E;">$98 420</td>
                  <td style="padding:10px 12px;text-align:right;color:#2E7D5B;font-weight:600;">+3.21%</td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Tendance -->
          <tr>
            <td style="padding:28px 40px 0;">
              <h2 style="margin:0 0 12px;color:#344453;font-size:18px;font-weight:700;border-bottom:2px solid #344453;padding-bottom:8px;">Tendance de la semaine</h2>
              <p style="margin:0 0 12px;color:#1E1E1E;font-size:14px;line-height:1.7;">
                <strong>R&eacute;gime :</strong> <span style="color:#2E7D5B;font-weight:600;">Haussier</span> &mdash; Le S&P 500 a renou&eacute; avec ses plus hauts historiques, port&eacute; par les r&eacute;sultats solides de la tech et un ton plus accommodant de la Fed. Le Nasdaq 100 surperforme avec +1.82% sur la semaine.
              </p>
              <p style="margin:0 0 12px;color:#1E1E1E;font-size:14px;line-height:1.7;">
                <strong>Sentiment :</strong> L'indice Fear &amp; Greed est remont&eacute; en zone &laquo; Greed &raquo; (68/100). Le VIX a recul&eacute; de 8.4% &agrave; 15.2, signal de complaisance. Les flux entrants sur les ETF actions restent soutenus.
              </p>
              <p style="margin:0;color:#1E1E1E;font-size:14px;line-height:1.7;">
                <strong>Volatilit&eacute; :</strong> Faible. Le VIX sous 16 indique un march&eacute; confiant. Attention toutefois &agrave; la complaisance excessive &mdash; les retournements sont souvent brutaux quand le VIX est bas.
              </p>
            </td>
          </tr>

          <!-- Catalyseurs -->
          <tr>
            <td style="padding:28px 40px 0;">
              <h2 style="margin:0 0 12px;color:#344453;font-size:18px;font-weight:700;border-bottom:2px solid #344453;padding-bottom:8px;">Catalyseurs cl&eacute;s</h2>
              <ul style="margin:0;padding:0 0 0 20px;color:#1E1E1E;font-size:14px;line-height:2;">
                <li><strong>Minutes FOMC (mercredi)</strong> &mdash; Ton l&eacute;g&egrave;rement dovish, la Fed confirme sa patience. Pas de hausse en vue, premi&egrave;re baisse possible en juin.</li>
                <li><strong>R&eacute;sultats Walmart (jeudi)</strong> &mdash; Chiffre d'affaires au-dessus des attentes, le consommateur am&eacute;ricain reste r&eacute;silient.</li>
                <li><strong>PMI Flash (vendredi)</strong> &mdash; Services &agrave; 51.2 (expansion), Manufacturing &agrave; 49.8 (contraction l&eacute;g&egrave;re). &Eacute;conomie bic&eacute;phale.</li>
                <li><strong>NVIDIA earnings preview</strong> &mdash; Le march&eacute; anticipe des r&eacute;sultats explosifs la semaine prochaine. L'action a gagn&eacute; +4.2% en pr&eacute;-positionnement.</li>
              </ul>
            </td>
          </tr>

          <!-- Risques -->
          <tr>
            <td style="padding:28px 40px 0;">
              <h2 style="margin:0 0 12px;color:#B0413E;font-size:18px;font-weight:700;border-bottom:2px solid #B0413E;padding-bottom:8px;">Risques &agrave; surveiller</h2>
              <ul style="margin:0;padding:0 0 0 20px;color:#1E1E1E;font-size:14px;line-height:2;">
                <li><strong>Inflation sticky</strong> &mdash; Le CPI core reste &agrave; 3.3%, au-dessus de l'objectif. Si l'inflation ne baisse pas, la Fed pourrait reporter les baisses.</li>
                <li><strong>Concentration tech</strong> &mdash; Les Mag 7 repr&eacute;sentent 32% du S&P 500. Un miss sur NVIDIA la semaine prochaine pourrait d&eacute;clencher une correction.</li>
                <li><strong>G&eacute;opolitique</strong> &mdash; Tensions commerciales US-Chine persistantes. Nouveaux tarifs possibles sur les semi-conducteurs.</li>
                <li><strong>Complaisance VIX</strong> &mdash; VIX &agrave; 15.2, historiquement bas. Les retournements sont souvent violents depuis ces niveaux.</li>
              </ul>
            </td>
          </tr>

          <!-- Calendrier -->
          <tr>
            <td style="padding:28px 40px 0;">
              <h2 style="margin:0 0 12px;color:#344453;font-size:18px;font-weight:700;border-bottom:2px solid #344453;padding-bottom:8px;">Semaine prochaine &mdash; &Agrave; surveiller</h2>
              <table width="100%" cellpadding="8" cellspacing="0" style="font-size:13px;border-collapse:collapse;">
                <tr style="background-color:#F4F5F5;">
                  <td style="font-weight:600;color:#344453;padding:8px 12px;">Jour</td>
                  <td style="font-weight:600;color:#344453;padding:8px 12px;">&Eacute;v&eacute;nement</td>
                </tr>
                <tr>
                  <td style="padding:8px 12px;color:#1E1E1E;">Lundi</td>
                  <td style="padding:8px 12px;color:#1E1E1E;">Presidents' Day &mdash; March&eacute;s ferm&eacute;s</td>
                </tr>
                <tr style="background-color:#FAFAFA;">
                  <td style="padding:8px 12px;color:#1E1E1E;">Mardi</td>
                  <td style="padding:8px 12px;color:#1E1E1E;">Confiance consommateur (Conference Board)</td>
                </tr>
                <tr>
                  <td style="padding:8px 12px;color:#1E1E1E;">Mercredi</td>
                  <td style="padding:8px 12px;color:#1E1E1E;font-weight:600;color:#344453;">NVIDIA Earnings (Q4) &mdash; Apr&egrave;s cl&ocirc;ture</td>
                </tr>
                <tr style="background-color:#FAFAFA;">
                  <td style="padding:8px 12px;color:#1E1E1E;">Jeudi</td>
                  <td style="padding:8px 12px;color:#1E1E1E;">PIB US (2&egrave;me estimation Q4), Jobless claims</td>
                </tr>
                <tr>
                  <td style="padding:8px 12px;color:#1E1E1E;">Vendredi</td>
                  <td style="padding:8px 12px;color:#1E1E1E;">PCE Core (indicateur pr&eacute;f&eacute;r&eacute; de la Fed)</td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- CTA -->
          <tr>
            <td style="padding:32px 40px;">
              <table cellpadding="0" cellspacing="0" style="margin:0 auto;">
                <tr>
                  <td style="background-color:#344453;border-radius:8px;padding:14px 32px;">
                    <a href="https://wmbmarket-wf8nj4yl.manus.space/dashboard" style="color:#FFFFFF;text-decoration:none;font-size:15px;font-weight:600;display:inline-block;">Lire le rapport complet en ligne</a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Divider -->
          <tr>
            <td style="padding:0 40px;">
              <div style="height:1px;background-color:#E1E6EA;"></div>
            </td>
          </tr>

          <!-- Disclaimer -->
          <tr>
            <td style="padding:20px 40px;background-color:#F8F9FA;">
              <p style="margin:0;color:rgba(30,30,30,0.5);font-size:11px;line-height:1.6;font-style:italic;">
                <strong>Disclaimer :</strong> Ce contenu est purement informatif et &eacute;ducatif. Il ne constitue en aucun cas un conseil en investissement, une recommandation d'achat ou de vente, ni une incitation &agrave; investir. Les performances pass&eacute;es ne pr&eacute;jugent pas des performances futures. Consultez un conseiller financier agr&eacute;&eacute; avant toute d&eacute;cision d'investissement.
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding:24px 40px 32px;text-align:center;">
              <p style="margin:0 0 8px;color:rgba(30,30,30,0.4);font-size:12px;line-height:1.6;">
                Vous recevez cet email car vous &ecirc;tes abonn&eacute;(e) &agrave; WallStreet Market Brief.
              </p>
              <p style="margin:0;color:rgba(30,30,30,0.3);font-size:11px;">
                WallStreet Market Brief &mdash; Newsletter March&eacute;s Financiers<br>
                &copy; 2026 WallStreet Market Brief. Tous droits r&eacute;serv&eacute;s.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

async function main() {
  console.log("Vérification connexion SMTP Brevo...");
  
  try {
    await transporter.verify();
    console.log("SMTP OK — Envoi de l'email...");
  } catch (err) {
    console.error("Erreur SMTP:", err.message);
    process.exit(1);
  }

  try {
    const info = await transporter.sendMail({
      from: '"WallStreet Market Brief" <contact@wallstreetmarketbrief.ch>',
      replyTo: "contact@wallstreetmarketbrief.ch",
      to: "elio_mendes@hotmail.com",
      subject: "WMB — Rapport Semaine 8 | S&P 500 +1.47%, Nasdaq +1.82%, VIX en baisse",
      html: reportHtml,
    });

    console.log("Email envoyé avec succès !");
    console.log("Message ID:", info.messageId);
    console.log("Destinataire: elio_mendes@hotmail.com");
  } catch (err) {
    console.error("Erreur envoi:", err.message);
    process.exit(1);
  }
}

main();
