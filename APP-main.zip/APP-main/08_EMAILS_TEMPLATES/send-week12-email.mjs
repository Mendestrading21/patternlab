/**
 * Send Week 12 email campaign via Brevo SMTP
 * Fetches all users + newsletter subscribers, builds the email, sends via Brevo
 */
import 'dotenv/config';
import nodemailer from 'nodemailer';
import mysql from 'mysql2/promise';

// ═══════════ BREVO SMTP ═══════════
const transporter = nodemailer.createTransport({
  host: process.env.BREVO_SMTP_HOST || "smtp-relay.brevo.com",
  port: 465,
  secure: true,
  connectionTimeout: 10000,
  greetingTimeout: 10000,
  auth: {
    user: process.env.BREVO_SMTP_LOGIN,
    pass: process.env.BREVO_SMTP_PASSWORD,
  },
});

// ═══════════ DB CONNECTION ═══════════
async function getDb() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  return conn;
}

// ═══════════ EMAIL TEMPLATE V8 ═══════════
function buildEmailHtml(title, bodyHtml) {
  const OUTER_BG = "#0A0C12";
  const DARK = "#0C1018";
  const CARD = "#FFFFFF";
  const TEXT_PRIMARY = "#1a1a1a";
  const TEXT_SECONDARY = "#4a5568";
  const TEXT_LIGHT = "#94a3b8";
  const BORDER = "#e2e8f0";
  const BRAND = "#344453";
  const GOLD = "#9a8560";
  const SITE_URL = "https://wallstreetmarketbrief.ch";
  const year = new Date().getFullYear();

  return `<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>${title}</title>
  <style>
    body,table,td,a{-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;}
    table,td{mso-table-lspace:0;mso-table-rspace:0;}
    img{-ms-interpolation-mode:bicubic;border:0;height:auto;line-height:100%;outline:none;text-decoration:none;}
    body{margin:0;padding:0;width:100%!important;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;}
    @media only screen and (max-width:620px){
      .outer{width:100%!important;}
      .pad{padding-left:20px!important;padding-right:20px!important;}
      .h1{font-size:20px!important;}
    }
    @media(prefers-color-scheme:dark){
      .email-bg{background-color:${OUTER_BG}!important;}
      .card-bg{background-color:${CARD}!important;}
    }
  </style>
</head>
<body style="margin:0;padding:0;background-color:${OUTER_BG};-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;">
  <table width="100%" cellpadding="0" cellspacing="0" role="presentation" class="email-bg" style="background-color:${OUTER_BG};padding:24px 12px;">
    <tr>
      <td align="center">
        <table class="outer" width="600" cellpadding="0" cellspacing="0" role="presentation" style="max-width:600px;width:100%;border-radius:8px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.3);">
          <!-- HEADER -->
          <tr>
            <td style="background-color:${DARK};padding:32px 44px 24px;" class="pad" align="center">
              <table cellpadding="0" cellspacing="0" role="presentation">
                <tr><td align="center"><span style="font-size:22px;font-weight:800;letter-spacing:7px;color:#ffffff;">WALLSTREET</span></td></tr>
                <tr><td align="center" style="padding-top:3px;"><span style="font-size:10px;font-weight:600;letter-spacing:5px;color:${GOLD};">MARKET BRIEF</span></td></tr>
              </table>
              <table cellpadding="0" cellspacing="0" role="presentation" style="margin-top:16px;">
                <tr><td align="center"><span style="font-size:9px;letter-spacing:3px;text-transform:uppercase;color:rgba(255,255,255,0.25);">Newsletter March&eacute;s Financiers</span></td></tr>
              </table>
            </td>
          </tr>
          <!-- Gold line -->
          <tr><td style="background-color:${DARK};padding:0 44px;" class="pad"><div style="height:2px;background:linear-gradient(90deg,transparent,${GOLD},transparent);"></div></td></tr>
          <!-- TITLE -->
          <tr><td class="card-bg" style="background-color:${CARD};padding:32px 44px 0;" class="pad"><h1 class="h1" style="margin:0;font-size:24px;font-weight:800;line-height:1.3;color:${TEXT_PRIMARY};">${title}</h1></td></tr>
          <!-- BODY -->
          <tr><td class="card-bg" style="background-color:${CARD};padding:20px 44px 0;color:${TEXT_SECONDARY};font-size:14px;line-height:1.7;" class="pad">${bodyHtml}</td></tr>
          <!-- CTA -->
          <tr><td class="card-bg" style="background-color:${CARD};padding:28px 44px 0;" class="pad" align="center">
            <a href="${SITE_URL}/modules" style="display:inline-block;padding:14px 36px;background-color:${BRAND};color:#ffffff;font-size:14px;font-weight:700;text-decoration:none;border-radius:6px;letter-spacing:0.5px;">Acc&eacute;der aux modules</a>
          </td></tr>
          <!-- SPACER -->
          <tr><td class="card-bg" style="background-color:${CARD};padding:28px 0 0;"></td></tr>
          <!-- FOOTER DIVIDER -->
          <tr><td class="card-bg" style="background-color:${CARD};padding:0 44px;" class="pad"><div style="height:1px;background-color:${BORDER};"></div></td></tr>
          <!-- FOOTER -->
          <tr><td class="card-bg" style="background-color:${CARD};padding:20px 44px 16px;" class="pad" align="center">
            <p style="margin:0 0 8px;font-size:11px;color:${TEXT_LIGHT};line-height:1.6;">&copy; ${year} WallStreet Market Brief</p>
            <p style="margin:0;font-size:10px;color:#c0c0c0;line-height:1.5;">
              <a href="${SITE_URL}/compte" style="color:${TEXT_LIGHT};text-decoration:underline;">G&eacute;rer mes pr&eacute;f&eacute;rences</a>
              &nbsp;&middot;&nbsp;
              <a href="${SITE_URL}/mentions-legales" style="color:${TEXT_LIGHT};text-decoration:underline;">Mentions l&eacute;gales</a>
            </p>
          </td></tr>
          <!-- DARK BOTTOM BAR -->
          <tr><td style="background-color:${DARK};padding:16px 44px;" class="pad" align="center">
            <p style="margin:0;color:rgba(255,255,255,0.15);font-size:9px;line-height:1.6;letter-spacing:0.3px;">
              Ce contenu est purement informatif et ne constitue pas un conseil en investissement.<br>
              &copy; ${year} WallStreet Market Brief. Tous droits r&eacute;serv&eacute;s.
            </p>
          </td></tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

// ═══════════ WEEK 12 EMAIL CONTENT ═══════════
const SUBJECT = "WMB | Semaine 12 — Correction Officielle, Broadcom Record et Rotation Energie";

const BODY_HTML = `
<p style="color:#4a5568;font-size:15px;line-height:1.7;margin:0 0 20px;">
  Bonjour,<br><br>
  L'&eacute;dition <strong>Semaine 12</strong> (10 - 14 mars 2026) est disponible sur votre espace WallStreet Market Brief.
</p>

<h2 style="color:#344453;font-size:18px;margin:24px 0 12px;font-weight:700;">Points cl&eacute;s de la semaine</h2>
<ul style="color:#4a5568;font-size:14px;line-height:1.8;padding-left:20px;margin:0 0 20px;">
  <li>Le <strong>S&amp;P 500</strong> cl&ocirc;ture &agrave; 6 632 (-1,6%), pile sur sa moyenne mobile 200 jours — 3&egrave;me semaine de baisse cons&eacute;cutive</li>
  <li>Le <strong>Brent au-dessus de 100$/baril</strong> — D&eacute;troit d'Ormuz quasi ferm&eacute;, choc p&eacute;trolier en cours</li>
  <li><strong>PIB Q4 r&eacute;vis&eacute; &agrave; 0,7%</strong> (contre 1,4%) — signal de stagflation</li>
  <li><strong>VIX &agrave; ~28</strong> — plus haut de 11 mois, sentiment Extreme Fear</li>
  <li><strong>FOMC cette semaine</strong> — dot plot et conf&eacute;rence Powell d&eacute;termineront la direction</li>
</ul>

<h2 style="color:#344453;font-size:18px;margin:24px 0 12px;font-weight:700;">Chiffres cl&eacute;s</h2>
<table style="width:100%;border-collapse:collapse;font-size:14px;margin:0 0 20px;">
  <tr style="background:#F4F5F5;">
    <td style="padding:10px 12px;border:1px solid #E1E6EA;font-weight:600;color:#344453;">S&amp;P 500</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#1a1a1a;">6 632</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#B0413E;font-weight:600;">-1,6%</td>
  </tr>
  <tr>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;font-weight:600;color:#344453;">Nasdaq 100</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#1a1a1a;">24 380</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#B0413E;font-weight:600;">-0,2%</td>
  </tr>
  <tr style="background:#F4F5F5;">
    <td style="padding:10px 12px;border:1px solid #E1E6EA;font-weight:600;color:#344453;">VIX</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#1a1a1a;">~28</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#B0413E;font-weight:600;">Stress &eacute;lev&eacute;</td>
  </tr>
  <tr>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;font-weight:600;color:#344453;">10Y US</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#1a1a1a;">4,28%</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#B0413E;font-weight:600;">+14 bps</td>
  </tr>
  <tr style="background:#F4F5F5;">
    <td style="padding:10px 12px;border:1px solid #E1E6EA;font-weight:600;color:#344453;">EUR/USD</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#1a1a1a;">1,0550</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#B0413E;font-weight:600;">-1,7%</td>
  </tr>
  <tr>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;font-weight:600;color:#344453;">Or (XAU)</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#1a1a1a;">5 020 $/oz</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#B0413E;font-weight:600;">L&eacute;g&egrave;re baisse</td>
  </tr>
  <tr style="background:#F4F5F5;">
    <td style="padding:10px 12px;border:1px solid #E1E6EA;font-weight:600;color:#344453;">Bitcoin</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#1a1a1a;">70 800 $</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#2E7D5B;font-weight:600;">+9% (conflit)</td>
  </tr>
  <tr>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;font-weight:600;color:#344453;">Brent</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#1a1a1a;">~103 $/b</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#B0413E;font-weight:600;">+40% (conflit)</td>
  </tr>
</table>

<h2 style="color:#344453;font-size:18px;margin:24px 0 12px;font-weight:700;">Modules disponibles cette semaine</h2>
<table style="width:100%;border-collapse:collapse;font-size:14px;margin:0 0 20px;">
  <tr style="background:#F4F5F5;">
    <td style="padding:10px 12px;border:1px solid #E1E6EA;font-weight:700;color:#344453;">Brief US</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#4a5568;">S&amp;P -10%, Broadcom AI +108%, Exxon ATH, FOMC en vue</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;"><a href="https://wallstreetmarketbrief.ch/modules/brief/12" style="color:#344453;font-weight:600;text-decoration:underline;">Lire</a></td>
  </tr>
  <tr>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;font-weight:700;color:#344453;">Actions US</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#4a5568;">Broadcom AI +108%, Exxon ATH, Tesla -8.5%, FOMC en vue</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;"><a href="https://wallstreetmarketbrief.ch/modules/actions/23" style="color:#344453;font-weight:600;text-decoration:underline;">Lire</a></td>
  </tr>
  <tr style="background:#F4F5F5;">
    <td style="padding:10px 12px;border:1px solid #E1E6EA;font-weight:700;color:#344453;">Monde</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#4a5568;">STOXX 600 en Baisse, Nikkei -3.5%, P&eacute;trole >$100</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;"><a href="https://wallstreetmarketbrief.ch/modules/monde/105" style="color:#344453;font-weight:600;text-decoration:underline;">Lire</a></td>
  </tr>
  <tr>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;font-weight:700;color:#344453;">Suisse</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;color:#4a5568;">SMI en Correction, BNS &agrave; 0% et CHF Fort</td>
    <td style="padding:10px 12px;border:1px solid #E1E6EA;"><a href="https://wallstreetmarketbrief.ch/modules/suisse/205" style="color:#344453;font-weight:600;text-decoration:underline;">Lire</a></td>
  </tr>
</table>

<p style="color:#4a5568;font-size:14px;line-height:1.7;margin:20px 0 0;">
  <strong style="color:#344453;">Semaine &agrave; venir :</strong> FOMC (mercredi), Quadruple Witching (vendredi), earnings Micron/FedEx/Dollar Tree, 7 banques centrales.
</p>

<p style="color:#94a3b8;font-size:12px;margin:24px 0 0;border-top:1px solid #e2e8f0;padding-top:16px;">
  Ce contenu est publi&eacute; &agrave; titre informatif et &eacute;ducatif uniquement. Il ne constitue en aucun cas un conseil en investissement.
</p>
`;

// ═══════════ MAIN ═══════════
async function main() {
  console.log("[WMB] Starting Week 12 email campaign via Brevo...");
  
  // 1. Verify SMTP connection
  try {
    await transporter.verify();
    console.log("[WMB] ✓ SMTP connection verified");
  } catch (err) {
    console.error("[WMB] ✗ SMTP connection failed:", err.message);
    process.exit(1);
  }

  // 2. Get all recipients from DB (users + newsletter subscribers)
  const db = await getDb();
  
  // Get registered users with email
  const [userRows] = await db.execute(
    "SELECT DISTINCT email FROM users WHERE email IS NOT NULL AND email != ''"
  );
  
  // Get newsletter subscribers (not unsubscribed, not already in users)
  const [subscriberRows] = await db.execute(
    "SELECT DISTINCT email FROM newsletterSubscribers WHERE unsubscribed = 0"
  );
  
  // Merge and deduplicate
  const allEmails = new Set();
  for (const row of userRows) allEmails.add(row.email.toLowerCase().trim());
  for (const row of subscriberRows) allEmails.add(row.email.toLowerCase().trim());
  
  const recipients = [...allEmails].filter(e => e && e.includes('@'));
  console.log(`[WMB] Found ${userRows.length} users + ${subscriberRows.length} subscribers = ${recipients.length} unique recipients`);
  
  if (recipients.length === 0) {
    console.log("[WMB] No recipients found. Exiting.");
    await db.end();
    process.exit(0);
  }

  // 3. Build the email HTML
  const html = buildEmailHtml(SUBJECT, BODY_HTML);
  
  // 4. Send emails in batches
  let sent = 0;
  let failed = 0;
  const errors = [];
  const BATCH_SIZE = 50;
  const DELAY_MS = 1000;

  for (let i = 0; i < recipients.length; i += BATCH_SIZE) {
    const batch = recipients.slice(i, i + BATCH_SIZE);
    
    for (const email of batch) {
      try {
        await transporter.sendMail({
          from: '"WallStreet Market Brief" <contact@wallstreetmarketbrief.ch>',
          replyTo: 'contact@wallstreetmarketbrief.ch',
          to: email,
          subject: SUBJECT,
          html: html,
        });
        sent++;
        console.log(`[WMB] ✓ Sent to ${email} (${sent}/${recipients.length})`);
      } catch (err) {
        failed++;
        errors.push(email);
        console.error(`[WMB] ✗ Failed: ${email} — ${err.message}`);
      }
    }

    if (i + BATCH_SIZE < recipients.length) {
      console.log(`[WMB] Waiting ${DELAY_MS}ms before next batch...`);
      await new Promise(r => setTimeout(r, DELAY_MS));
    }
  }

  console.log(`\n[WMB] ═══════════ CAMPAIGN COMPLETE ═══════════`);
  console.log(`[WMB] Total recipients: ${recipients.length}`);
  console.log(`[WMB] Sent: ${sent}`);
  console.log(`[WMB] Failed: ${failed}`);
  if (errors.length > 0) console.log(`[WMB] Failed emails: ${errors.join(', ')}`);

  await db.end();
  process.exit(0);
}

main().catch(err => {
  console.error("[WMB] Fatal error:", err);
  process.exit(1);
});
