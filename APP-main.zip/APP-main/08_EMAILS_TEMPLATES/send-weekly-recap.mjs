/**
 * WMB Weekly Recap — UN SEUL email récapitulatif hebdomadaire
 * Indique que les modules sont disponibles sur le site
 * Utilise le VRAI logo WMB (barres + texte)
 */

const BREVO_API_KEY = process.env.BREVO_API_KEY || "";

const TEST_RECIPIENTS = [
  "elio_mendes@hotmail.com",
  "e.mendestrading@gmail.com",
];

// ═══ VRAI LOGO WMB (barres + texte, comme sur le site) ═══
const LOGO_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/jHcxBPuiCHcQtlDW.png";
const SITE_URL = "https://wallstreetmarketbrief.ch";

async function sendEmailViaBrevo(to, subject, html) {
  try {
    const response = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: {
        "accept": "application/json",
        "api-key": BREVO_API_KEY,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        sender: { name: "WallStreet Market Brief", email: "contact@wallstreetmarketbrief.ch" },
        to: [{ email: to }],
        subject,
        htmlContent: html,
        replyTo: { email: "contact@wallstreetmarketbrief.ch" },
      }),
    });
    const data = await response.json();
    if (response.ok) {
      console.log(\`  [OK] \${to} — messageId: \${data.messageId}\`);
      return true;
    } else {
      console.error(\`  [FAIL] \${to} — \${JSON.stringify(data)}\`);
      return false;
    }
  } catch (error) {
    console.error(\`  [ERROR] \${to}:\`, error.message);
    return false;
  }
}

function buildWeeklyRecapEmail() {
  const subject = "📊 WMB — Semaine 10 : Vos modules sont disponibles";
  const preheader = "Tensions Iran, VIX en alerte, rebond technique — vos 4 modules S10 sont en ligne";

  const html = \`<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="x-apple-disable-message-reformatting">
  <meta name="format-detection" content="telephone=no,address=no,email=no,date=no,url=no">
  <title>WallStreet Market Brief — Semaine 10</title>
  <span style="display:none;font-size:1px;color:#0A0C12;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;">\${preheader}\${"&zwnj;&nbsp;".repeat(30)}</span>
  <style>
    body { margin: 0; padding: 0; background-color: #0A0C12; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased; }
    a { color: #D4A853; text-decoration: none; }
    img { border: 0; display: block; outline: none; }
    table { border-collapse: collapse; }
    p { margin: 0 0 16px; }
    @media only screen and (max-width: 620px) {
      .email-container { width: 100% !important; }
      .email-padding { padding-left: 20px !important; padding-right: 20px !important; }
      .stat-grid td { display: block !important; width: 100% !important; padding: 6px 0 !important; }
      .module-grid td { display: block !important; width: 100% !important; padding-bottom: 12px !important; }
      .hero-title { font-size: 22px !important; line-height: 1.25 !important; }
      .logo-img { width: 200px !important; }
    }
  </style>
</head>
<body style="margin:0;padding:0;background-color:#0A0C12;">
  <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background-color:#0A0C12;padding:24px 12px;">
    <tr>
      <td align="center">
        <table class="email-container" width="600" cellpadding="0" cellspacing="0" role="presentation" style="max-width:600px;width:100%;background-color:#FFFFFF;border-radius:12px;overflow:hidden;box-shadow:0 4px 32px rgba(0,0,0,0.4);">

          <!-- ═══ HEADER avec VRAI LOGO ═══ -->
          <tr>
            <td style="background-color:#0C1018;padding:32px 40px 24px;" class="email-padding">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
                <tr>
                  <td align="center">
                    <img src="\${LOGO_URL}" alt="WallStreet Market Brief" class="logo-img" width="260" style="display:block;max-width:260px;height:auto;" />
                  </td>
                </tr>
                <tr>
                  <td align="center" style="padding-top:12px;">
                    <span style="color:rgba(255,255,255,0.25);font-size:9px;text-transform:uppercase;letter-spacing:3px;">Newsletter Marchés Financiers</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- ═══ ACCENT LINE ═══ -->
          <tr>
            <td style="background-color:#0C1018;padding:0 40px;" class="email-padding">
              <div style="height:2px;background:linear-gradient(90deg,transparent,#D4A853,transparent);"></div>
            </td>
          </tr>

          <!-- ═══ TITRE PRINCIPAL ═══ -->
          <tr>
            <td style="background:linear-gradient(135deg,#344453,#344453DD);padding:28px 40px;" class="email-padding">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
                <tr>
                  <td>
                    <span style="color:rgba(255,255,255,0.4);font-size:10px;text-transform:uppercase;letter-spacing:2px;font-weight:600;">Résumé Hebdomadaire — Semaine 10</span>
                  </td>
                </tr>
                <tr>
                  <td style="padding-top:10px;">
                    <h1 class="hero-title" style="margin:0;color:#FFFFFF;font-size:24px;font-weight:700;line-height:1.3;">Tensions Géopolitiques & Rebond Technique</h1>
                  </td>
                </tr>
                <tr>
                  <td style="padding-top:8px;">
                    <p style="margin:0;color:rgba(255,255,255,0.6);font-size:13px;line-height:1.5;">3 – 5 mars 2026 — Le marché digère le choc iranien, VIX en zone d'alerte, rebond sur signaux diplomatiques</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- ═══ SCOREBOARD RAPIDE ═══ -->
          <tr>
            <td style="padding:28px 40px 0;background-color:#FFFFFF;" class="email-padding">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;" class="stat-grid">
                <tr>
                  <td style="padding:12px;background-color:#F8F9FA;border-radius:8px;text-align:center;border:1px solid #E8EAED;">
                    <p style="margin:0;font-size:10px;color:rgba(30,30,30,0.4);text-transform:uppercase;letter-spacing:1px;font-weight:600;">S&P 500</p>
                    <p style="margin:4px 0 0;font-size:18px;font-weight:700;color:#344453;">6,869</p>
                    <p style="margin:2px 0 0;font-size:12px;font-weight:600;color:#2E7D5B;">+0.8%</p>
                  </td>
                  <td style="width:8px;"></td>
                  <td style="padding:12px;background-color:#F8F9FA;border-radius:8px;text-align:center;border:1px solid #E8EAED;">
                    <p style="margin:0;font-size:10px;color:rgba(30,30,30,0.4);text-transform:uppercase;letter-spacing:1px;font-weight:600;">Nasdaq</p>
                    <p style="margin:4px 0 0;font-size:18px;font-weight:700;color:#344453;">22,807</p>
                    <p style="margin:2px 0 0;font-size:12px;font-weight:600;color:#2E7D5B;">+1.3%</p>
                  </td>
                  <td style="width:8px;"></td>
                  <td style="padding:12px;background-color:#F8F9FA;border-radius:8px;text-align:center;border:1px solid #E8EAED;">
                    <p style="margin:0;font-size:10px;color:rgba(30,30,30,0.4);text-transform:uppercase;letter-spacing:1px;font-weight:600;">Dow Jones</p>
                    <p style="margin:4px 0 0;font-size:18px;font-weight:700;color:#344453;">48,739</p>
                    <p style="margin:2px 0 0;font-size:12px;font-weight:600;color:#2E7D5B;">+0.5%</p>
                  </td>
                </tr>
              </table>

              <!-- VIX -->
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
                <tr>
                  <td style="padding:10px 16px;background-color:#F8F9FA;border-radius:8px;border:1px solid #E8EAED;">
                    <span style="font-size:10px;color:rgba(30,30,30,0.4);text-transform:uppercase;letter-spacing:1px;font-weight:600;">VIX</span>
                    <span style="font-size:16px;font-weight:700;color:#344453;margin-left:8px;">22.8</span>
                    <span style="font-size:11px;color:#B0413E;margin-left:8px;">Zone d'alerte (+60% YTD)</span>
                  </td>
                </tr>
              </table>

              <!-- Badges -->
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 28px;">
                <tr>
                  <td>
                    <span style="display:inline-block;padding:5px 14px;background-color:rgba(212,168,83,0.1);color:#B8860B;font-size:12px;font-weight:700;border-radius:6px;margin-right:8px;">Signal: Prudent</span>
                    <span style="display:inline-block;padding:5px 14px;background-color:rgba(176,65,62,0.1);color:#B0413E;font-size:12px;font-weight:700;border-radius:6px;">Risque: Géopolitique élevé</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- ═══ RÉSUMÉ EXPRESS ═══ -->
          <tr>
            <td style="padding:0 40px;background-color:#FFFFFF;" class="email-padding">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 12px;">
                <tr>
                  <td>
                    <div style="display:inline-block;width:3px;height:16px;background-color:#344453;border-radius:2px;vertical-align:middle;margin-right:10px;"></div>
                    <span style="font-size:14px;font-weight:700;color:#344453;text-transform:uppercase;letter-spacing:0.5px;vertical-align:middle;">Ce qu'il faut retenir</span>
                  </td>
                </tr>
              </table>

              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 24px;">
                <tr><td style="padding:5px 0;"><table cellpadding="0" cellspacing="0"><tr>
                  <td style="width:20px;vertical-align:top;padding-top:6px;"><div style="width:6px;height:6px;border-radius:50%;background-color:#2E7D5B;"></div></td>
                  <td style="font-size:13px;color:#1E1E1E;line-height:1.6;">Lundi noir : S&P 500 -1.5%, Dow -902 pts après l'escalade US/Israël en Iran</td>
                </tr></table></td></tr>
                <tr><td style="padding:5px 0;"><table cellpadding="0" cellspacing="0"><tr>
                  <td style="width:20px;vertical-align:top;padding-top:6px;"><div style="width:6px;height:6px;border-radius:50%;background-color:#2E7D5B;"></div></td>
                  <td style="font-size:13px;color:#1E1E1E;line-height:1.6;">VIX spike à 28.15 intraday (+23%), plus haut en 3 mois</td>
                </tr></table></td></tr>
                <tr><td style="padding:5px 0;"><table cellpadding="0" cellspacing="0"><tr>
                  <td style="width:20px;vertical-align:top;padding-top:6px;"><div style="width:6px;height:6px;border-radius:50%;background-color:#2E7D5B;"></div></td>
                  <td style="font-size:13px;color:#1E1E1E;line-height:1.6;">Rebond mercredi (+0.8% S&P) sur signaux diplomatiques iraniens</td>
                </tr></table></td></tr>
                <tr><td style="padding:5px 0;"><table cellpadding="0" cellspacing="0"><tr>
                  <td style="width:20px;vertical-align:top;padding-top:6px;"><div style="width:6px;height:6px;border-radius:50%;background-color:#D4A853;"></div></td>
                  <td style="font-size:13px;color:#1E1E1E;line-height:1.6;">Or à $5,155/oz (flight to safety), Bitcoin rebondit à $71,680 (+4%)</td>
                </tr></table></td></tr>
                <tr><td style="padding:5px 0;"><table cellpadding="0" cellspacing="0"><tr>
                  <td style="width:20px;vertical-align:top;padding-top:6px;"><div style="width:6px;height:6px;border-radius:50%;background-color:#D4A853;"></div></td>
                  <td style="font-size:13px;color:#1E1E1E;line-height:1.6;">Rotation sectorielle : défense et énergie en tête, cycliques sous pression</td>
                </tr></table></td></tr>
              </table>

              <!-- Lecture WMB -->
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 28px;">
                <tr>
                  <td style="padding:16px;background-color:#F8F9FA;border-radius:8px;border-left:3px solid #344453;">
                    <p style="margin:0 0 4px;font-size:10px;color:rgba(30,30,30,0.4);text-transform:uppercase;letter-spacing:1px;font-weight:600;">Lecture WMB</p>
                    <p style="margin:0;font-size:13px;color:#344453;line-height:1.7;font-style:italic;">Le marché navigue entre pression géopolitique et signaux macro résilients. Le rebond de mercredi est technique et fragile. SI la diplomatie progresse ET les payrolls sont solides, stabilisation au-dessus de 6,800. SINON, retour vers 6,600-6,700.</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- ═══ SÉPARATEUR ═══ -->
          <tr>
            <td style="padding:0 40px;background-color:#FFFFFF;" class="email-padding">
              <div style="height:1px;background-color:#E8EAED;"></div>
            </td>
          </tr>

          <!-- ═══ VOS MODULES DISPONIBLES ═══ -->
          <tr>
            <td style="padding:28px 40px;background-color:#FFFFFF;" class="email-padding">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
                <tr>
                  <td align="center">
                    <span style="font-size:16px;font-weight:700;color:#344453;letter-spacing:0.3px;">Vos modules de la semaine</span>
                  </td>
                </tr>
                <tr>
                  <td align="center" style="padding-top:6px;">
                    <span style="font-size:12px;color:rgba(30,30,30,0.45);">Cliquez sur un module pour accéder à l'édition complète</span>
                  </td>
                </tr>
              </table>

              <!-- Module Cards -->
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" class="module-grid">
                <!-- Module USA -->
                <tr>
                  <td style="padding:0 0 12px;">
                    <a href="\${SITE_URL}/dashboard" style="text-decoration:none;display:block;">
                      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="border-radius:10px;overflow:hidden;border:1px solid #E8EAED;">
                        <tr>
                          <td style="width:5px;background-color:#2E7D5B;"></td>
                          <td style="padding:16px 20px;">
                            <table width="100%" cellpadding="0" cellspacing="0"><tr>
                              <td>
                                <p style="margin:0 0 2px;font-size:10px;color:rgba(30,30,30,0.35);text-transform:uppercase;letter-spacing:1.5px;font-weight:600;">📊 Module Marché US</p>
                                <p style="margin:0;font-size:15px;font-weight:700;color:#344453;">Tensions Géopolitiques & Rebond Technique</p>
                                <p style="margin:4px 0 0;font-size:12px;color:rgba(30,30,30,0.5);">S&P 500, Nasdaq, Dow, VIX, taux, macro, Fed, scénarios</p>
                              </td>
                              <td style="width:40px;text-align:right;vertical-align:middle;">
                                <span style="font-size:20px;color:#2E7D5B;">→</span>
                              </td>
                            </tr></table>
                          </td>
                        </tr>
                      </table>
                    </a>
                  </td>
                </tr>

                <!-- Module Monde -->
                <tr>
                  <td style="padding:0 0 12px;">
                    <a href="\${SITE_URL}/monde/1" style="text-decoration:none;display:block;">
                      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="border-radius:10px;overflow:hidden;border:1px solid #E8EAED;">
                        <tr>
                          <td style="width:5px;background-color:#0EA5E9;"></td>
                          <td style="padding:16px 20px;">
                            <table width="100%" cellpadding="0" cellspacing="0"><tr>
                              <td>
                                <p style="margin:0 0 2px;font-size:10px;color:rgba(30,30,30,0.35);text-transform:uppercase;letter-spacing:1.5px;font-weight:600;">🌍 Marchés Mondiaux</p>
                                <p style="margin:0;font-size:15px;font-weight:700;color:#344453;">Choc Pétrolier & Fuite vers la Qualité</p>
                                <p style="margin:4px 0 0;font-size:12px;color:rgba(30,30,30,0.5);">Europe, Asie, Forex, Commodities, Or, Pétrole, Bitcoin</p>
                              </td>
                              <td style="width:40px;text-align:right;vertical-align:middle;">
                                <span style="font-size:20px;color:#0EA5E9;">→</span>
                              </td>
                            </tr></table>
                          </td>
                        </tr>
                      </table>
                    </a>
                  </td>
                </tr>

                <!-- Module Actions -->
                <tr>
                  <td style="padding:0 0 12px;">
                    <a href="\${SITE_URL}/actions/1" style="text-decoration:none;display:block;">
                      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="border-radius:10px;overflow:hidden;border:1px solid #E8EAED;">
                        <tr>
                          <td style="width:5px;background-color:#D4A853;"></td>
                          <td style="padding:16px 20px;">
                            <table width="100%" cellpadding="0" cellspacing="0"><tr>
                              <td>
                                <p style="margin:0 0 2px;font-size:10px;color:rgba(30,30,30,0.35);text-transform:uppercase;letter-spacing:1.5px;font-weight:600;">🎯 Module Actions US</p>
                                <p style="margin:0;font-size:15px;font-weight:700;color:#344453;">Défense & Énergie en Tête, Tech en Rebond</p>
                                <p style="margin:4px 0 0;font-size:12px;color:rgba(30,30,30,0.5);">Top gagnants/perdants, rotation sectorielle, watchlist</p>
                              </td>
                              <td style="width:40px;text-align:right;vertical-align:middle;">
                                <span style="font-size:20px;color:#D4A853;">→</span>
                              </td>
                            </tr></table>
                          </td>
                        </tr>
                      </table>
                    </a>
                  </td>
                </tr>

                <!-- Module Suisse -->
                <tr>
                  <td style="padding:0;">
                    <a href="\${SITE_URL}/suisse/1" style="text-decoration:none;display:block;">
                      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="border-radius:10px;overflow:hidden;border:1px solid #E8EAED;">
                        <tr>
                          <td style="width:5px;background-color:#B0413E;"></td>
                          <td style="padding:16px 20px;">
                            <table width="100%" cellpadding="0" cellspacing="0"><tr>
                              <td>
                                <p style="margin:0 0 2px;font-size:10px;color:rgba(30,30,30,0.35);text-transform:uppercase;letter-spacing:1.5px;font-weight:600;">🇨🇭 Module Suisse</p>
                                <p style="margin:0;font-size:15px;font-weight:700;color:#344453;">SMI sous Pression, CHF en Refuge</p>
                                <p style="margin:4px 0 0;font-size:12px;color:rgba(30,30,30,0.5);">SMI, BNS, EUR/CHF, blue chips, analyse</p>
                              </td>
                              <td style="width:40px;text-align:right;vertical-align:middle;">
                                <span style="font-size:20px;color:#B0413E;">→</span>
                              </td>
                            </tr></table>
                          </td>
                        </tr>
                      </table>
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- ═══ CTA PRINCIPAL ═══ -->
          <tr>
            <td style="padding:8px 40px 28px;background-color:#FFFFFF;text-align:center;" class="email-padding">
              <table cellpadding="0" cellspacing="0" role="presentation" style="margin:0 auto;">
                <tr>
                  <td style="background-color:#344453;border-radius:10px;padding:14px 48px;">
                    <a href="\${SITE_URL}/dashboard" style="color:#FFFFFF;text-decoration:none;font-size:15px;font-weight:700;display:inline-block;letter-spacing:0.3px;">Accéder à mon espace</a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- ═══ SEMAINE À VENIR ═══ -->
          <tr>
            <td style="padding:0 40px;background-color:#FFFFFF;" class="email-padding">
              <div style="height:1px;background-color:#E8EAED;"></div>
            </td>
          </tr>
          <tr>
            <td style="padding:24px 40px;background-color:#FFFFFF;" class="email-padding">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 12px;">
                <tr>
                  <td>
                    <div style="display:inline-block;width:3px;height:16px;background-color:#D4A853;border-radius:2px;vertical-align:middle;margin-right:10px;"></div>
                    <span style="font-size:14px;font-weight:700;color:#344453;text-transform:uppercase;letter-spacing:0.5px;vertical-align:middle;">Semaine à venir</span>
                  </td>
                </tr>
              </table>
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
                <tr><td style="padding:5px 0;"><table cellpadding="0" cellspacing="0"><tr>
                  <td style="width:20px;vertical-align:top;padding-top:6px;"><div style="width:6px;height:6px;border-radius:50%;background-color:#D4A853;"></div></td>
                  <td style="font-size:13px;color:#1E1E1E;line-height:1.6;">Payrolls US (NFP) vendredi — test clé pour le marché du travail</td>
                </tr></table></td></tr>
                <tr><td style="padding:5px 0;"><table cellpadding="0" cellspacing="0"><tr>
                  <td style="width:20px;vertical-align:top;padding-top:6px;"><div style="width:6px;height:6px;border-radius:50%;background-color:#D4A853;"></div></td>
                  <td style="font-size:13px;color:#1E1E1E;line-height:1.6;">Évolution du conflit Iran : diplomatie vs escalade</td>
                </tr></table></td></tr>
                <tr><td style="padding:5px 0;"><table cellpadding="0" cellspacing="0"><tr>
                  <td style="width:20px;vertical-align:top;padding-top:6px;"><div style="width:6px;height:6px;border-radius:50%;background-color:#D4A853;"></div></td>
                  <td style="font-size:13px;color:#1E1E1E;line-height:1.6;">PMI services ISM — confirmation du ralentissement ?</td>
                </tr></table></td></tr>
              </table>
            </td>
          </tr>

          <!-- ═══ FOOTER ═══ -->
          <tr>
            <td style="padding:0 40px;background-color:#FFFFFF;" class="email-padding">
              <div style="height:1px;background-color:#E8EAED;"></div>
            </td>
          </tr>
          <tr>
            <td style="padding:20px 40px 16px;background-color:#FFFFFF;" class="email-padding">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
                <tr><td align="center">
                  <p style="margin:0 0 6px;color:rgba(30,30,30,0.35);font-size:11px;line-height:1.6;">
                    Vous recevez cet email car vous êtes abonné(e) à WallStreet Market Brief.
                  </p>
                  <p style="margin:0;color:rgba(30,30,30,0.25);font-size:10px;line-height:1.5;">
                    <a href="\${SITE_URL}/compte" style="color:rgba(30,30,30,0.35);text-decoration:underline;">Gérer mes préférences</a>
                    &nbsp;·&nbsp;
                    <a href="\${SITE_URL}/mentions-legales" style="color:rgba(30,30,30,0.35);text-decoration:underline;">Mentions légales</a>
                  </p>
                </td></tr>
              </table>
            </td>
          </tr>
          <tr>
            <td style="background-color:#0C1018;padding:16px 40px;" class="email-padding">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
                <tr><td align="center">
                  <p style="margin:0;color:rgba(255,255,255,0.15);font-size:9px;line-height:1.6;letter-spacing:0.5px;">
                    WallStreet Market Brief &mdash; Newsletter Marchés Financiers<br>
                    Ce contenu est purement informatif et ne constitue pas un conseil en investissement.<br>
                    &copy; 2026 WallStreet Market Brief. Tous droits réservés.
                  </p>
                </td></tr>
              </table>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>\`;

  return { subject, html };
}

async function main() {
  console.log("=".repeat(55));
  console.log("  WMB — Envoi du récapitulatif hebdomadaire S10/2026");
  console.log("  UN SEUL email avec les 4 modules disponibles");
  console.log("  Logo: VRAI logo WMB (barres + texte)");
  console.log("  Recipients:", TEST_RECIPIENTS.join(", "));
  console.log("=".repeat(55));

  const { subject, html } = buildWeeklyRecapEmail();
  console.log(\`\\nSubject: \${subject}\\n\`);

  let sent = 0;
  let failed = 0;

  for (const recipient of TEST_RECIPIENTS) {
    const success = await sendEmailViaBrevo(recipient, subject, html);
    if (success) sent++;
    else failed++;
    await new Promise(r => setTimeout(r, 1000));
  }

  console.log(\`\\n\${"=".repeat(55)}\`);
  console.log(\`  DONE: \${sent} sent, \${failed} failed\`);
  console.log("=".repeat(55));
}

main().catch(console.error);
