#!/usr/bin/env python3
"""
WMB Weekly Recap Email — V5 Ultra-Premium
Design: Hybrid dark header (like site nav) + white body
Cohérent avec le site wallstreetmarketbrief.ch
Zero emoji, lisible thème noir ET blanc iPhone
"""
import os, json, urllib.request

BREVO_KEY = os.environ.get("BREVO_API_KEY", "")
RECIPIENTS = ["elio_mendes@hotmail.com", "e.mendestrading@gmail.com"]
SENDER = {"name": "WallStreet Market Brief", "email": "contact@wallstreetmarketbrief.ch"}
SITE = "https://wallstreetmarketbrief.ch"

SUBJECT = "WMB -- Brief de la Semaine 10"

# ── Design tokens matching the site ──
DARK = "#0C1018"
DARK2 = "#151a26"
BRAND = "#344453"
GOLD = "#9a8560"
GREEN = "#2E7D5B"
RED = "#B0413E"
BLUE = "#0EA5E9"
PURPLE = "#8B5CF6"
ORANGE = "#E07A3A"
WHITE = "#ffffff"
BG = "#f4f5f5"
TEXT = "#1a1a1a"
MUTED = "#64748b"
LIGHT = "#94a3b8"
BORDER = "#e2e8f0"
CARD_BG = "#f8fafc"

HTML = f"""<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="x-apple-disable-message-reformatting">
<meta name="format-detection" content="telephone=no,address=no,email=no,date=no,url=no">
<meta name="color-scheme" content="light">
<meta name="supported-color-schemes" content="light">
<title>WMB -- Brief de la Semaine 10</title>
<span style="display:none;font-size:1px;color:{BG};line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">
S&amp;P 500 +0.8% | Nasdaq +1.3% | VIX 22.8 | Tensions Iran, rebond technique, or en refuge.
{"&zwnj;&nbsp;" * 40}
</span>
<style>
body {{ margin:0; padding:0; background:{BG}; font-family:'Helvetica Neue',Helvetica,Arial,sans-serif; -webkit-font-smoothing:antialiased; color:{TEXT}; }}
a {{ color:{BRAND}; text-decoration:none; }}
table {{ border-collapse:collapse; }}
p {{ margin:0; }}
@media only screen and (max-width:620px) {{
  .outer {{ width:100%!important; }}
  .pad {{ padding-left:20px!important; padding-right:20px!important; }}
  .h1 {{ font-size:20px!important; }}
  .stat-grid td {{ display:block!important; width:100%!important; padding:6px 0!important; }}
  .mod-grid td {{ display:block!important; width:100%!important; padding:6px 0!important; }}
}}
</style>
</head>
<body style="margin:0;padding:0;background:{BG};-webkit-text-size-adjust:100%;">
<table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="background:{BG};padding:24px 16px;">
<tr><td align="center">
<table class="outer" width="580" cellpadding="0" cellspacing="0" role="presentation" style="max-width:580px;width:100%;border-radius:4px;overflow:hidden;">

  <!-- ═══════ HEADER — Dark like site nav ═══════ -->
  <tr>
    <td style="background:{DARK};padding:36px 44px 28px;" class="pad" align="center">
      <table cellpadding="0" cellspacing="0" role="presentation">
        <tr><td align="center">
          <span style="font-size:24px;font-weight:800;letter-spacing:7px;color:{WHITE};">WALLSTREET</span>
        </td></tr>
        <tr><td align="center" style="padding-top:3px;">
          <span style="font-size:11px;font-weight:600;letter-spacing:5px;color:{GOLD};">MARKET BRIEF</span>
        </td></tr>
      </table>
      <table cellpadding="0" cellspacing="0" role="presentation" style="margin-top:20px;">
        <tr><td align="center">
          <span style="font-size:9px;letter-spacing:3px;text-transform:uppercase;color:rgba(255,255,255,0.3);">Newsletter hebdomadaire &middot; Chaque dimanche</span>
        </td></tr>
      </table>
    </td>
  </tr>

  <!-- ═══════ GOLD LINE ═══════ -->
  <tr>
    <td style="background:{DARK};padding:0 44px;" class="pad">
      <div style="height:2px;background:linear-gradient(90deg,transparent,{GOLD},transparent);"></div>
    </td>
  </tr>

  <!-- ═══════ TITLE SECTION — White ═══════ -->
  <tr>
    <td style="background:{WHITE};padding:32px 44px 0;" class="pad">
      <p style="margin:0 0 6px;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:{MUTED};font-weight:600;">Resume hebdomadaire &mdash; Semaine 10</p>
      <h1 class="h1" style="margin:0;font-size:26px;font-weight:800;line-height:1.25;color:{TEXT};">Tensions Geopolitiques &amp; Rebond Technique</h1>
      <p style="margin:10px 0 0;font-size:14px;color:{MUTED};line-height:1.6;">3 &ndash; 5 mars 2026 &mdash; Le marche digere le choc iranien, VIX en zone d'alerte, rebond sur signaux diplomatiques.</p>
    </td>
  </tr>

  <!-- ═══════ THIN LINE ═══════ -->
  <tr>
    <td style="background:{WHITE};padding:24px 44px 0;" class="pad">
      <div style="height:1px;background:{BORDER};"></div>
    </td>
  </tr>

  <!-- ═══════ SCOREBOARD ═══════ -->
  <tr>
    <td style="background:{WHITE};padding:24px 44px 0;" class="pad">
      <p style="margin:0 0 14px;font-size:10px;letter-spacing:2px;text-transform:uppercase;color:{MUTED};font-weight:600;">Scoreboard</p>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" class="stat-grid">
        <tr>
          <td style="width:25%;padding:14px 8px;background:{CARD_BG};border:1px solid {BORDER};text-align:center;border-radius:4px;">
            <p style="margin:0;font-size:9px;color:{LIGHT};text-transform:uppercase;letter-spacing:1px;font-weight:600;">S&amp;P 500</p>
            <p style="margin:6px 0 0;font-size:20px;font-weight:800;color:{TEXT};">5,954</p>
            <p style="margin:2px 0 0;font-size:12px;font-weight:600;color:{GREEN};">+0.8%</p>
          </td>
          <td style="width:4px;"></td>
          <td style="width:25%;padding:14px 8px;background:{CARD_BG};border:1px solid {BORDER};text-align:center;border-radius:4px;">
            <p style="margin:0;font-size:9px;color:{LIGHT};text-transform:uppercase;letter-spacing:1px;font-weight:600;">Nasdaq</p>
            <p style="margin:6px 0 0;font-size:20px;font-weight:800;color:{TEXT};">18,847</p>
            <p style="margin:2px 0 0;font-size:12px;font-weight:600;color:{GREEN};">+1.3%</p>
          </td>
          <td style="width:4px;"></td>
          <td style="width:25%;padding:14px 8px;background:{CARD_BG};border:1px solid {BORDER};text-align:center;border-radius:4px;">
            <p style="margin:0;font-size:9px;color:{LIGHT};text-transform:uppercase;letter-spacing:1px;font-weight:600;">VIX</p>
            <p style="margin:6px 0 0;font-size:20px;font-weight:800;color:{TEXT};">22.8</p>
            <p style="margin:2px 0 0;font-size:12px;font-weight:600;color:{RED};">Alerte</p>
          </td>
          <td style="width:4px;"></td>
          <td style="width:25%;padding:14px 8px;background:{CARD_BG};border:1px solid {BORDER};text-align:center;border-radius:4px;">
            <p style="margin:0;font-size:9px;color:{LIGHT};text-transform:uppercase;letter-spacing:1px;font-weight:600;">Or</p>
            <p style="margin:6px 0 0;font-size:20px;font-weight:800;color:{TEXT};">$5,155</p>
            <p style="margin:2px 0 0;font-size:12px;font-weight:600;color:{GREEN};">Refuge</p>
          </td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- ═══════ RESUME EXPRESS ═══════ -->
  <tr>
    <td style="background:{WHITE};padding:28px 44px 0;" class="pad">
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
        <tr>
          <td style="width:3px;background:{GREEN};border-radius:2px;"></td>
          <td style="padding-left:14px;">
            <p style="margin:0 0 4px;font-size:11px;letter-spacing:2px;text-transform:uppercase;color:{GREEN};font-weight:700;">Resume de la semaine</p>
          </td>
        </tr>
      </table>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin-top:14px;">
        <tr><td style="padding:6px 0;">
          <table cellpadding="0" cellspacing="0" role="presentation"><tr>
            <td style="width:6px;height:6px;border-radius:50%;background:{GREEN};vertical-align:top;padding-top:0;"></td>
            <td style="padding-left:12px;font-size:14px;color:{TEXT};line-height:1.65;">Escalade militaire Iran : les marches plongent lundi (-2% SMI, VIX a 28), puis rebondissent mardi sur des signaux diplomatiques.</td>
          </tr></table>
        </td></tr>
        <tr><td style="padding:6px 0;">
          <table cellpadding="0" cellspacing="0" role="presentation"><tr>
            <td style="width:6px;height:6px;border-radius:50%;background:{GREEN};vertical-align:top;padding-top:0;"></td>
            <td style="padding-left:12px;font-size:14px;color:{TEXT};line-height:1.65;">Or a $5,155/oz, Bitcoin a $71,680 : fuite vers les actifs refuges. Le franc suisse se renforce (EUR/CHF 0.9380).</td>
          </tr></table>
        </td></tr>
        <tr><td style="padding:6px 0;">
          <table cellpadding="0" cellspacing="0" role="presentation"><tr>
            <td style="width:6px;height:6px;border-radius:50%;background:{GREEN};vertical-align:top;padding-top:0;"></td>
            <td style="padding-left:12px;font-size:14px;color:{TEXT};line-height:1.65;">Rotation sectorielle : defense et energie en tete, tech et consommation sous pression. VIX +60% YTD.</td>
          </tr></table>
        </td></tr>
      </table>
    </td>
  </tr>

  <!-- ═══════ LECTURE WMB ═══════ -->
  <tr>
    <td style="background:{WHITE};padding:24px 44px 0;" class="pad">
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
        <tr>
          <td style="width:3px;background:{GOLD};border-radius:2px;"></td>
          <td style="padding-left:14px;">
            <p style="margin:0;font-size:11px;letter-spacing:2px;text-transform:uppercase;color:{GOLD};font-weight:700;">Lecture WMB</p>
          </td>
        </tr>
      </table>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin-top:14px;">
        <tr>
          <td style="padding:18px 20px;background:{CARD_BG};border-radius:4px;border-left:3px solid {GOLD};">
            <p style="margin:0;font-size:14px;color:{BRAND};line-height:1.7;font-style:italic;">SI l'Iran accepte un cessez-le-feu et que les negociations avancent, ALORS le VIX devrait revenir sous 20 et les indices pourraient retester leurs plus hauts. SINON, une escalade prolongee maintiendrait la volatilite elevee et favoriserait les actifs refuges (or, CHF, treasuries).</p>
          </td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- ═══════ THIN LINE ═══════ -->
  <tr>
    <td style="background:{WHITE};padding:28px 44px 0;" class="pad">
      <div style="height:1px;background:{BORDER};"></div>
    </td>
  </tr>

  <!-- ═══════ MODULES DISPONIBLES ═══════ -->
  <tr>
    <td style="background:{WHITE};padding:24px 44px 0;" class="pad">
      <p style="margin:0 0 16px;font-size:10px;letter-spacing:2px;text-transform:uppercase;color:{MUTED};font-weight:600;">Vos modules de la semaine</p>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" class="mod-grid">
        <!-- Row 1 -->
        <tr>
          <td style="width:48%;padding:0 0 8px;">
            <a href="{SITE}/dashboard" style="display:block;text-decoration:none;">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="border:1px solid {BORDER};border-radius:4px;overflow:hidden;">
                <tr><td style="height:3px;background:{GREEN};"></td></tr>
                <tr><td style="padding:16px 14px;">
                  <p style="margin:0 0 2px;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:{GREEN};font-weight:700;">USA</p>
                  <p style="margin:0;font-size:13px;font-weight:700;color:{TEXT};">Weekly Brief USA</p>
                  <p style="margin:4px 0 0;font-size:11px;color:{LIGHT};line-height:1.4;">S&amp;P, Nasdaq, VIX, macro, Fed, scenarios</p>
                </td></tr>
              </table>
            </a>
          </td>
          <td style="width:4%;"></td>
          <td style="width:48%;padding:0 0 8px;">
            <a href="{SITE}/dashboard" style="display:block;text-decoration:none;">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="border:1px solid {BORDER};border-radius:4px;overflow:hidden;">
                <tr><td style="height:3px;background:{BLUE};"></td></tr>
                <tr><td style="padding:16px 14px;">
                  <p style="margin:0 0 2px;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:{BLUE};font-weight:700;">MONDE</p>
                  <p style="margin:0;font-size:13px;font-weight:700;color:{TEXT};">Weekly Monde</p>
                  <p style="margin:4px 0 0;font-size:11px;color:{LIGHT};line-height:1.4;">Europe, Asie, emergents, forex, commodities</p>
                </td></tr>
              </table>
            </a>
          </td>
        </tr>
        <!-- Row 2 -->
        <tr>
          <td style="width:48%;padding:0 0 8px;">
            <a href="{SITE}/dashboard" style="display:block;text-decoration:none;">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="border:1px solid {BORDER};border-radius:4px;overflow:hidden;">
                <tr><td style="height:3px;background:{RED};"></td></tr>
                <tr><td style="padding:16px 14px;">
                  <p style="margin:0 0 2px;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:{RED};font-weight:700;">SUISSE</p>
                  <p style="margin:0;font-size:13px;font-weight:700;color:{TEXT};">Weekly Suisse</p>
                  <p style="margin:4px 0 0;font-size:11px;color:{LIGHT};line-height:1.4;">SMI, BNS, CHF, blue chips suisses</p>
                </td></tr>
              </table>
            </a>
          </td>
          <td style="width:4%;"></td>
          <td style="width:48%;padding:0 0 8px;">
            <a href="{SITE}/dashboard" style="display:block;text-decoration:none;">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="border:1px solid {BORDER};border-radius:4px;overflow:hidden;">
                <tr><td style="height:3px;background:{GOLD};"></td></tr>
                <tr><td style="padding:16px 14px;">
                  <p style="margin:0 0 2px;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:{GOLD};font-weight:700;">ACTIONS</p>
                  <p style="margin:0;font-size:13px;font-weight:700;color:{TEXT};">Actions de la Semaine</p>
                  <p style="margin:4px 0 0;font-size:11px;color:{LIGHT};line-height:1.4;">Top movers, rotations, earnings, watchlist</p>
                </td></tr>
              </table>
            </a>
          </td>
        </tr>
        <!-- Row 3 — Theme -->
        <tr>
          <td colspan="3" style="padding:0 0 4px;">
            <a href="{SITE}/dashboard" style="display:block;text-decoration:none;">
              <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="border:1px solid {BORDER};border-radius:4px;overflow:hidden;">
                <tr><td style="height:3px;background:linear-gradient(90deg,{PURPLE},{ORANGE});"></td></tr>
                <tr><td style="padding:16px 14px;">
                  <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
                    <tr>
                      <td>
                        <p style="margin:0 0 2px;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:{PURPLE};font-weight:700;">THEME DU MOIS</p>
                        <p style="margin:0;font-size:13px;font-weight:700;color:{TEXT};">Dossier approfondi</p>
                      </td>
                      <td style="text-align:right;vertical-align:middle;">
                        <span style="font-size:11px;color:{LIGHT};">Disponible pour les abonnes Premium</span>
                      </td>
                    </tr>
                  </table>
                </td></tr>
              </table>
            </a>
          </td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- ═══════ CTA ═══════ -->
  <tr>
    <td style="background:{WHITE};padding:28px 44px 0;" class="pad" align="center">
      <a href="{SITE}/dashboard" style="display:inline-block;padding:14px 52px;background:{BRAND};color:{WHITE};font-size:13px;font-weight:700;text-decoration:none;border-radius:3px;letter-spacing:0.5px;">Acceder a mes modules</a>
    </td>
  </tr>

  <!-- ═══════ SPACER ═══════ -->
  <tr><td style="background:{WHITE};padding:28px 0 0;"></td></tr>

  <!-- ═══════ FOOTER LINE ═══════ -->
  <tr>
    <td style="background:{WHITE};padding:0 44px;" class="pad">
      <div style="height:1px;background:{BORDER};"></div>
    </td>
  </tr>

  <!-- ═══════ FOOTER ═══════ -->
  <tr>
    <td style="background:{WHITE};padding:20px 44px 28px;" class="pad" align="center">
      <p style="margin:0 0 8px;font-size:11px;color:{LIGHT};line-height:1.6;">
        Vous recevez cet email car vous etes abonne(e) a WallStreet Market Brief.
      </p>
      <p style="margin:0 0 12px;font-size:10px;color:#c0c0c0;line-height:1.5;">
        <a href="{SITE}/compte" style="color:{LIGHT};text-decoration:underline;">Gerer mes preferences</a>
        &nbsp;&middot;&nbsp;
        <a href="{SITE}/mentions-legales" style="color:{LIGHT};text-decoration:underline;">Mentions legales</a>
      </p>
      <p style="margin:0;font-size:9px;color:#d0d0d0;line-height:1.6;">
        Ce contenu est purement informatif et ne constitue pas un conseil en investissement.<br>
        &copy; 2026 WallStreet Market Brief. Tous droits reserves.
      </p>
    </td>
  </tr>

</table>
</td></tr>
</table>
</body>
</html>"""

# ── Send via Brevo API ──
def send():
    for r in RECIPIENTS:
        payload = json.dumps({
            "sender": SENDER,
            "to": [{"email": r}],
            "subject": SUBJECT,
            "htmlContent": HTML
        }).encode()
        req = urllib.request.Request(
            "https://api.brevo.com/v3/smtp/email",
            data=payload,
            headers={"api-key": BREVO_KEY, "Content-Type": "application/json", "Accept": "application/json"},
            method="POST"
        )
        try:
            resp = urllib.request.urlopen(req)
            data = json.loads(resp.read())
            print(f"  [OK] {r} -- {data.get('messageId','')}")
        except Exception as e:
            print(f"  [FAIL] {r} -- {e}")

print("=" * 60)
print("  WMB V5 -- Hybrid dark header + white body")
print(f"  Objet : {SUBJECT}")
print(f"  Destinataires : {', '.join(RECIPIENTS)}")
print("=" * 60)
send()
print("=" * 60)
print("  DONE")
print("=" * 60)
