import "dotenv/config";

// Need to set up the database connection before importing newsletter
const { sendWeeklyNewsletterToSubscribers } = await import("./server/jobs/newsletter.ts");

async function main() {
  console.log("[Newsletter] Starting manual send...");
  try {
    const result = await sendWeeklyNewsletterToSubscribers();
    console.log("[Newsletter] Result:", JSON.stringify(result, null, 2));
    process.exit(0);
  } catch (err) {
    console.error("[Newsletter] Error:", err);
    process.exit(1);
  }
}

main();
