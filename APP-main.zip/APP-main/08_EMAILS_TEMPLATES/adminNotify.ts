/**
 * WMB Admin Email Notifications V10
 * Design V10: "Dark Shell + Light Core" — unified with buildWmbEmailHtml
 * Sends email notifications to contact@wallstreetmarketbrief.ch
 * for: new registrations, new payments, new subscriptions, cancellations, payment failures
 */

const ADMIN_EMAIL = "contact@wallstreetmarketbrief.ch";

// V10 Light Core tokens
const CARD_BG = "#F7F8FA";
const BORDER_LIGHT = "#E5E7EB";
const TEXT_DARK = "#1A1A1A";
const TEXT_BODY = "#374151";
const TEXT_CAPTION = "#6B7280";
const GREEN = "#16A34A";
const RED = "#DC2626";

interface AdminNotifyParams {
  type: "registration" | "payment" | "subscription" | "cancellation" | "payment_failed" | "free_theme" | "free_brief" | "free_account" | "pending_payment" | "contact";
  userName?: string;
  userEmail?: string;
  plan?: string;
  amount?: string;
  details?: string;
}

// Color-coded badges per event type — V10 light-safe colors
const EVENT_BADGES: Record<string, { color: string; bg: string; label: string }> = {
  registration: { color: "#2563EB", bg: "rgba(37,99,235,0.08)", label: "INSCRIPTION" },
  payment: { color: "#C8A960", bg: "rgba(200,169,96,0.08)", label: "PAIEMENT" },
  subscription: { color: "#16A34A", bg: "rgba(22,163,74,0.08)", label: "ABONNEMENT" },
  cancellation: { color: "#DC2626", bg: "rgba(220,38,38,0.08)", label: "ANNULATION" },
  payment_failed: { color: "#DC2626", bg: "rgba(220,38,38,0.08)", label: "\u00c9CHEC PAIEMENT" },
  free_theme: { color: "#8B5CF6", bg: "rgba(139,92,246,0.08)", label: "TH\u00c8ME GRATUIT" },
  free_brief: { color: "#06B6D4", bg: "rgba(6,182,212,0.08)", label: "BRIEF GRATUIT" },
  free_account: { color: "#2563EB", bg: "rgba(37,99,235,0.08)", label: "COMPTE GRATUIT" },
  pending_payment: { color: "#F59E0B", bg: "rgba(245,158,11,0.08)", label: "EN ATTENTE DE PAIEMENT" },
  contact: { color: "#F59E0B", bg: "rgba(245,158,11,0.08)", label: "MESSAGE CONTACT" },
};

function buildDetailRow(label: string, value: string): string {
  return `
    <tr>
      <td style="padding:6px 0;font-size:12px;color:${TEXT_CAPTION};font-weight:600;width:100px;vertical-align:top;">${label}</td>
      <td style="padding:6px 0;font-size:13px;color:${TEXT_DARK};line-height:1.5;">${value}</td>
    </tr>`;
}

/**
 * Send an admin notification email via Brevo SMTP
 */
export async function sendAdminNotification(params: AdminNotifyParams): Promise<boolean> {
  try {
    const { sendEmail, buildWmbEmailHtml } = await import("../email");

    const { type, userName, userEmail, plan, amount, details } = params;
    const date = new Date().toLocaleDateString("fr-FR", {
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });

    const badge = EVENT_BADGES[type] || EVENT_BADGES.registration;

    let subject = "";
    let title = "";
    let eventDescription = "";
    let accentColor = badge.color;

    switch (type) {
      case "registration":
        subject = `Nouvel inscrit \u2014 ${userName || userEmail}`;
        title = "Nouvelle inscription";
        eventDescription = "Un nouvel utilisateur vient de cr\u00e9er un compte sur WallStreet Market Brief.";
        break;
      case "payment":
        subject = `Nouveau paiement \u2014 ${userName || userEmail} (${plan || "\u2014"})`;
        title = "Nouveau paiement re\u00e7u";
        eventDescription = "Un paiement a \u00e9t\u00e9 trait\u00e9 avec succ\u00e8s sur WallStreet Market Brief.";
        break;
      case "subscription":
        subject = `Nouvel abonn\u00e9 \u2014 ${userName || userEmail} (${plan || "\u2014"})`;
        title = "Nouvel abonnement activ\u00e9";
        eventDescription = "Un nouvel abonnement vient d'\u00eatre activ\u00e9. L'utilisateur a maintenant acc\u00e8s \u00e0 l'espace membre.";
        break;
      case "cancellation":
        subject = `D\u00e9sabonnement \u2014 ${userName || userEmail}`;
        title = "Abonnement annul\u00e9";
        eventDescription = "Un abonnement vient d'\u00eatre annul\u00e9 sur WallStreet Market Brief.";
        break;
      case "payment_failed":
        subject = `\u00c9chec de paiement \u2014 ${userName || userEmail}`;
        title = "\u00c9chec de paiement";
        eventDescription = "Un paiement a \u00e9chou\u00e9 sur WallStreet Market Brief. V\u00e9rifiez le dashboard Stripe.";
        break;
      case "free_theme":
        subject = `Demande Th\u00e8me gratuit \u2014 ${userName || userEmail}`;
        title = "Nouvelle demande de Th\u00e8me du Mois";
        eventDescription = "Un visiteur a demand\u00e9 le Th\u00e8me du Mois gratuit sur WallStreet Market Brief.";
        break;
      case "free_brief":
        subject = `Demande Brief gratuit \u2014 ${userName || userEmail}`;
        title = "Nouvelle demande de Brief gratuit";
        eventDescription = "Un visiteur a demand\u00e9 un Brief gratuit (extrait) sur WallStreet Market Brief.";
        break;
      case "free_account":
        subject = `Nouveau compte gratuit \u2014 ${userName || userEmail}`;
        title = "Nouveau compte gratuit cr\u00e9\u00e9";
        eventDescription = "Un nouvel utilisateur a cr\u00e9\u00e9 un compte gratuit (D\u00e9couverte) sur WallStreet Market Brief.";
        break;
      case "pending_payment":
        subject = `Nouveau compte (paiement en cours) \u2014 ${userName || userEmail} (${plan || "\u2014"})`;
        title = "Nouveau compte \u2014 Paiement en cours";
        eventDescription = "Un nouvel utilisateur a cr\u00e9\u00e9 un compte et est en train de proc\u00e9der au paiement. L'abonnement sera activ\u00e9 d\u00e8s la confirmation du paiement.";
        break;
    }

    // Build detail rows dynamically
    let detailRows = "";
    if (userName) detailRows += buildDetailRow("Client", userName);
    if (userEmail) detailRows += buildDetailRow("Email", userEmail);
    if (plan) detailRows += buildDetailRow("Plan", plan);
    if (amount) detailRows += buildDetailRow("Montant", amount);
    detailRows += buildDetailRow("Date", date);
    if (details) detailRows += buildDetailRow("Info", details);

    const bodyHtml = `
      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 16px;">${eventDescription}</p>

      <!-- Event badge -->
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 16px;">
        <tr>
          <td style="padding:8px 14px;background-color:${badge.bg};border-radius:6px;display:inline-block;">
            <span style="font-size:11px;font-weight:700;letter-spacing:1px;color:${badge.color};">${badge.label}</span>
          </td>
        </tr>
      </table>

      <!-- Detail card -->
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:18px 20px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${badge.color};border:1px solid ${BORDER_LIGHT};">
            <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
              ${detailRows}
            </table>
          </td>
        </tr>
      </table>

      ${type === "subscription" ? `
      <p style="font-size:13px;color:${GREEN};line-height:1.6;margin:0;">
        L'utilisateur a d\u00e9sormais acc\u00e8s \u00e0 l'espace membre, aux \u00e9ditions et aux modules inclus dans son plan.
      </p>` : ""}

      ${type === "cancellation" ? `
      <p style="font-size:13px;color:${RED};line-height:1.6;margin:0;">
        L'acc\u00e8s premium sera d\u00e9sactiv\u00e9 \u00e0 la fin de la p\u00e9riode en cours.
      </p>` : ""}

      ${type === "payment_failed" ? `
      <p style="font-size:13px;color:${RED};line-height:1.6;margin:0;">
        V\u00e9rifiez le statut du paiement dans le dashboard Stripe pour plus de d\u00e9tails.
      </p>` : ""}
    `;

    const html = buildWmbEmailHtml({
      title,
      preheader: subject,
      bodyHtml,
      ctaText: "Voir le Dashboard Admin",
      ctaUrl: "https://wallstreetmarketbrief.ch/admin",
      footerText: "Notification automatique \u2014 WallStreet Market Brief Admin",
      accentColor,
    });

    const sent = await sendEmail({
      to: ADMIN_EMAIL,
      subject: `[WMB Admin] ${subject}`,
      html,
    });

    if (sent) {
      console.log(`[AdminNotify] Email sent to ${ADMIN_EMAIL} \u2014 type: ${type}`);
    } else {
      console.warn(`[AdminNotify] Failed to send email \u2014 type: ${type}`);
    }
    return sent;
  } catch (error) {
    console.error(`[AdminNotify] Error sending admin notification:`, error);
    return false;
  }
}
