/**
 * WMB — Email TEASER S11
 * Mode TEASER : quelques phrases d'accroche + chiffres clés (sans analyse) + CTA
 * Les abonnés gratuits voient le teaser, pas le contenu complet.
 * Via API HTTP Brevo
 */
import "dotenv/config";

const BREVO_API_KEY = process.env.BREVO_API_KEY;
const BREVO_API_URL = "https://api.brevo.com/v3/smtp/email";
if (!BREVO_API_KEY) {
  console.error("BREVO_API_KEY not set");
  process.exit(1);
}

import { getDb } from "./server/db.ts";
import { users } from "./drizzle/schema.ts";
import { eq, and, sql } from "drizzle-orm";
import {
  buildGenericModuleEmail,
  emailComponents,
} from "./server/emails/templates.ts";

const SITE_URL = "https://wallstreetmarketbrief.ch";
const { sectionHeading, statBox, divider, spacer, highlight } = emailComponents;
const GREEN = "#2E7D5B";
const GOLD = "#D4A853";
const RED = "#B0413E";
const DARK = "#344453";

// ─── Build TEASER body — NO free content ───
function buildTeaserBody() {
  let body = "";

  // ═══ ACCROCHE ═══
  body += `
    <p style="margin:0 0 20px;font-size:16px;color:#344453;line-height:1.7;">
      Bonjour,
    </p>
    <p style="margin:0 0 20px;font-size:16px;color:#344453;line-height:1.7;">
      Votre édition <strong>WMB Semaine 11</strong> est prête.
    </p>
    <p style="margin:0 0 24px;font-size:15px;color:#1E1E1E;line-height:1.7;">
      Cette semaine, les marchés ont vécu un tournant. Le S&P 500 clôture à 6 740 (-2,0%), sa troisième semaine de baisse consécutive. Le VIX frôle le seuil de panique à 29,49. Le pétrole bondit de 35% — la plus forte hausse depuis 1983 — pour dépasser $103 dimanche soir. Le NFP passe en négatif (-92K) pour la première fois depuis 2020. Paradoxe : l'or recule de 6% tandis que le dollar signe sa meilleure semaine depuis août. La semaine prochaine sera décisive avec le CPI mercredi.
    </p>
  `;

  // ═══ CHIFFRES CLÉS — juste les chiffres, pas d'analyse ═══
  body += sectionHeading("Les chiffres de la semaine", DARK);
  body += `
    <table width="100%" cellpadding="0" cellspacing="8" role="presentation" style="margin:0 0 16px;">
      <tr>
        ${statBox({ label: "S&P 500", value: "6 740", change: "-2,0%", changePositive: false })}
        ${statBox({ label: "VIX", value: "29.49", change: "+41%", changePositive: false })}
        ${statBox({ label: "Or", value: "$5 102", change: "-6,0%", changePositive: false })}
        ${statBox({ label: "WTI", value: "$103.06", change: "+35%", changePositive: false })}
      </tr>
    </table>
  `;
  body += spacer(8);

  // ═══ CE QUI VOUS ATTEND — titres des modules, pas de contenu ═══
  body += sectionHeading("Dans cette édition", GOLD);
  body += `
    <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
      <tr>
        <td style="padding:12px 16px;border-left:3px solid ${GREEN};background:#f8faf9;margin-bottom:8px;">
          <p style="margin:0;font-size:14px;font-weight:700;color:${DARK};">Revue USA</p>
          <p style="margin:4px 0 0;font-size:13px;color:#666;">Stagflation, emploi en chute, Fed piégée — ce que ça signifie</p>
        </td>
      </tr>
      <tr><td style="height:8px;"></td></tr>
      <tr>
        <td style="padding:12px 16px;border-left:3px solid #0EA5E9;background:#f6fafd;">
          <p style="margin:0;font-size:14px;font-weight:700;color:${DARK};">Revue Monde</p>
          <p style="margin:4px 0 0;font-size:13px;color:#666;">Europe, Asie, émergents, devises, crypto — le tour du monde en 5 minutes</p>
        </td>
      </tr>
      <tr><td style="height:8px;"></td></tr>
      <tr>
        <td style="padding:12px 16px;border-left:3px solid ${GOLD};background:#fdfaf5;">
          <p style="margin:0;font-size:14px;font-weight:700;color:${DARK};">Actions US</p>
          <p style="margin:4px 0 0;font-size:13px;color:#666;">Top movers, secteurs, earnings, watchlist — qui gagne, qui perd, pourquoi</p>
        </td>
      </tr>
      <tr><td style="height:8px;"></td></tr>
      <tr>
        <td style="padding:12px 16px;border-left:3px solid ${RED};background:#fdf6f6;">
          <p style="margin:0;font-size:14px;font-weight:700;color:${DARK};">Revue Suisse</p>
          <p style="margin:4px 0 0;font-size:13px;color:#666;">SMI, CHF, BNS — la pire semaine depuis avril 2025</p>
        </td>
      </tr>
      <tr><td style="height:8px;"></td></tr>
      <tr>
        <td style="padding:12px 16px;border-left:3px solid #EC4899;background:#fdf5f9;">
          <p style="margin:0;font-size:14px;font-weight:700;color:${DARK};">Fil Rouge</p>
          <p style="margin:4px 0 0;font-size:13px;color:#666;">CPI, Oracle, Adobe — les catalyseurs de la semaine prochaine</p>
        </td>
      </tr>
    </table>
  `;
  body += spacer(8);

  // ═══ TEASER CLIFFHANGER ═══
  body += highlight("La semaine prochaine sera la plus importante de 2026 à ce jour. CPI mercredi, Oracle lundi, Adobe jeudi — chaque jour apporte un catalyseur. L'analyse complète vous attend.", DARK);
  body += spacer(16);

  // ═══ DISCLAIMER ═══
  body += divider();
  body += `<p style="margin:16px 0 0;font-size:11px;color:rgba(30,30,30,0.35);line-height:1.5;text-align:center;">
    Contenu informatif et éducatif uniquement. Pas un conseil en investissement.
    <br>WallStreet Market Brief — wallstreetmarketbrief.ch
  </p>`;

  return body;
}

async function sendViaBrevoApi(to, subject, html) {
  const payload = {
    sender: { name: "WallStreet Market Brief", email: "contact@wallstreetmarketbrief.ch" },
    to: [{ email: to }],
    subject,
    htmlContent: html,
  };
  try {
    const res = await fetch(BREVO_API_URL, {
      method: "POST",
      headers: {
        "accept": "application/json",
        "api-key": BREVO_API_KEY,
        "content-type": "application/json",
      },
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      const data = await res.json();
      console.log(`  OK ${to} (messageId: ${data.messageId})`);
      return true;
    } else {
      const errText = await res.text();
      console.error(`  FAIL ${to}: ${res.status} ${errText}`);
      return false;
    }
  } catch (err) {
    console.error(`  ERROR ${to}:`, err.message);
    return false;
  }
}

async function main() {
  console.log("[WMB TEASER] Building teaser email for S11...");

  const bodyHtml = buildTeaserBody();
  const emailHtml = buildGenericModuleEmail({
    moduleType: "general",
    weekNumber: 11,
    year: 2026,
    dateRange: "LUN 03/03 → VEN 07/03",
    title: "Semaine 11 — Pétrole +35%, NFP -92K, VIX 29 — Trois Chocs en Une Semaine",
    subtitle: "VOTRE ÉDITION EST PRÊTE",
    bodyHtml,
    ctaText: "Lire l'édition complète",
    ctaUrl: `${SITE_URL}/dashboard`,
  });

  console.log("[WMB TEASER] Email built. Fetching subscribers...");

  const db = await getDb();
  if (!db) { console.error("DB not available"); process.exit(1); }

  const recipients = await db
    .select({ email: users.email, name: users.name })
    .from(users)
    .where(
      and(
        eq(users.subscriptionActive, 1),
        sql`${users.email} IS NOT NULL AND ${users.email} != ''`
      )
    );

  const emails = recipients.map(r => r.email).filter(Boolean);
  console.log(`[WMB TEASER] ${emails.length} subscribers: ${emails.join(", ")}`);

  if (emails.length === 0) {
    console.log("[WMB TEASER] No subscribers. Exiting.");
    process.exit(0);
  }

  const subject = "WMB S11 — Pétrole +35% ($103), NFP -92K, VIX 29 | Votre édition est prête";
  let sent = 0;
  let failed = 0;

  for (const email of emails) {
    const ok = await sendViaBrevoApi(email, subject, emailHtml);
    if (ok) sent++;
    else failed++;
    await new Promise(r => setTimeout(r, 500));
  }

  console.log(`\n[WMB TEASER] DONE: ${sent}/${emails.length} sent, ${failed} failed.`);
  process.exit(0);
}

main().catch(err => {
  console.error("[WMB TEASER] Fatal:", err);
  process.exit(1);
});
