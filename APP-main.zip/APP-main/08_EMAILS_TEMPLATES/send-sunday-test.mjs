/**
 * Script: Envoyer l'email du dimanche (newsletter hebdomadaire) à tous les abonnés
 * Usage: node send-sunday-test.mjs
 */
import 'dotenv/config';

// We need to call the admin endpoint on the running server
const BASE_URL = process.env.SITE_URL || "https://wallstreetmarketbrief.ch";
const LOCAL_URL = "http://localhost:3000";

async function main() {
  console.log("═══════════════════════════════════════════════════");
  console.log("  WMB — Envoi de l'email du dimanche (test)");
  console.log("═══════════════════════════════════════════════════");
  console.log("");

  // Use the newsletter job directly via dynamic import
  try {
    // Import the newsletter module
    const { sendWeeklyAnnouncementToAll } = await import("./server/jobs/newsletter.ts");
    
    console.log("[Envoi] Démarrage de l'envoi à tous les abonnés...");
    console.log("");
    
    const result = await sendWeeklyAnnouncementToAll();
    
    console.log("");
    console.log("═══════════════════════════════════════════════════");
    console.log("  RÉSULTAT DE L'ENVOI");
    console.log("═══════════════════════════════════════════════════");
    console.log(`  Destinataires: ${result.totalRecipients}`);
    console.log(`  Envoyés:       ${result.sent}`);
    console.log(`  Échoués:       ${result.failed}`);
    console.log(`  Sujet:         ${result.subject}`);
    console.log("═══════════════════════════════════════════════════");
    
    process.exit(0);
  } catch (err) {
    console.error("[Erreur]", err);
    process.exit(1);
  }
}

main();
