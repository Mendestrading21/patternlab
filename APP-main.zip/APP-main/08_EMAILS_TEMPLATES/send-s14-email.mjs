/**
 * WMB S14 — Send weekly announcement email to all subscribers
 * Triggers the existing newsletter system with S14 data
 */
import "dotenv/config";

// Dynamic import to use the existing newsletter job
async function main() {
  console.log("[WMB S14] Starting email send...");
  
  const { sendWeeklyAnnouncementToAll } = await import("./server/jobs/newsletter.ts");
  
  const result = await sendWeeklyAnnouncementToAll();
  
  console.log(`[WMB S14] ═══════════════════════════════════`);
  console.log(`[WMB S14] RÉSULTAT:`);
  console.log(`[WMB S14]   Destinataires: ${result.totalRecipients}`);
  console.log(`[WMB S14]   Envoyés: ${result.sent}`);
  console.log(`[WMB S14]   Échoués: ${result.failed}`);
  console.log(`[WMB S14]   Sujet: ${result.subject}`);
  console.log(`[WMB S14] ═══════════════════════════════════`);
  
  process.exit(0);
}

main().catch(err => {
  console.error("[WMB S14] Fatal error:", err);
  process.exit(1);
});
