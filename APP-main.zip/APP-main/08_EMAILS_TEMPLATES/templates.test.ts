/**
 * Tests for WMB email templates
 * Validates HTML generation, responsive structure, and module-specific branding
 */
import { describe, it, expect } from "vitest";
import {
  buildModuleUsaEmail,
  buildModuleActionsEmail,
  buildGenericModuleEmail,
  MODULE_COLORS,
  emailComponents,
  type ModuleUsaEmailData,
  type ModuleActionsEmailData,
} from "./templates";

// ═══════════ MODULE_COLORS ═══════════

describe("MODULE_COLORS", () => {
  it("should have all expected module types", () => {
    expect(MODULE_COLORS).toHaveProperty("marche");
    expect(MODULE_COLORS).toHaveProperty("actions");
    expect(MODULE_COLORS).toHaveProperty("theme");
    expect(MODULE_COLORS).toHaveProperty("mondial");
    expect(MODULE_COLORS).toHaveProperty("general");
  });

  it("each module should have accent, accentLight, label, and emoji", () => {
    for (const [key, mod] of Object.entries(MODULE_COLORS)) {
      expect(mod).toHaveProperty("accent");
      expect(mod).toHaveProperty("accentLight");
      expect(mod).toHaveProperty("label");
      expect(mod).toHaveProperty("emoji");
      expect(mod.accent).toMatch(/^#[0-9A-Fa-f]{6}$/);
    }
  });
});

// ═══════════ buildModuleUsaEmail ═══════════

describe("buildModuleUsaEmail", () => {
  const sampleData: ModuleUsaEmailData = {
    weekNumber: 9,
    year: 2026,
    dateRange: "24 fév. — 28 fév.",
    title: "Consolidation sous résistance",
    subtitle: "Le S&P 500 teste les 6 100 pts dans un contexte de prudence macro",
    keyPointsPast: [
      "Le S&P 500 a terminé la semaine en baisse de -0.8%",
      "Le VIX est remonté à 18.2, signalant un retour de la nervosité",
    ],
    keyPointsAhead: [
      "Publication du PCE core vendredi — indicateur clé pour la Fed",
      "Earnings de NVDA mardi après la clôture",
    ],
    lectureWMB: "Le marché reste en tendance haussière de fond mais la dynamique court terme s'essouffle.",
    sp500: { value: "6 012", change: "-0.8%" },
    nasdaq: { value: "19 432", change: "-1.2%" },
    dowJones: { value: "43 890", change: "-0.3%" },
    vix: { value: "18.2", regime: "Prudence" },
    signal: "Neutre",
    risk: "Modéré",
    highlights: [
      "La Fed maintient sa posture hawkish",
      "Les résultats tech restent solides mais les guidances déçoivent",
    ],
    ctaUrl: "https://wallstreetmarketbrief.ch/dashboard",
  };

  it("should generate valid HTML with DOCTYPE", () => {
    const html = buildModuleUsaEmail(sampleData);
    expect(html).toContain("<!DOCTYPE html>");
    expect(html).toContain("</html>");
  });

  it("should include the WMB header logo", () => {
    const html = buildModuleUsaEmail(sampleData);
    expect(html).toContain("WallStreet Market Brief");
  });

  it("should include module label and accent color", () => {
    const html = buildModuleUsaEmail(sampleData);
    expect(html).toContain(MODULE_COLORS.marche.label);
    expect(html).toContain(MODULE_COLORS.marche.accent);
  });

  it("should include the title and subtitle", () => {
    const html = buildModuleUsaEmail(sampleData);
    expect(html).toContain(sampleData.title);
    expect(html).toContain(sampleData.subtitle);
  });

  it("should include scoreboard data", () => {
    const html = buildModuleUsaEmail(sampleData);
    expect(html).toContain("S&P 500");
    expect(html).toContain("6 012");
    expect(html).toContain("-0.8%");
    expect(html).toContain("Nasdaq");
    expect(html).toContain("19 432");
    expect(html).toContain("VIX");
    expect(html).toContain("18.2");
  });

  it("should include key points for past and ahead", () => {
    const html = buildModuleUsaEmail(sampleData);
    expect(html).toContain("Semaine pass&eacute;e");
    expect(html).toContain("Semaine &agrave; venir");
    for (const point of sampleData.keyPointsPast) {
      expect(html).toContain(point);
    }
    for (const point of sampleData.keyPointsAhead) {
      expect(html).toContain(point);
    }
  });

  it("should include the Lecture WMB section", () => {
    const html = buildModuleUsaEmail(sampleData);
    expect(html).toContain("Lecture WMB");
    expect(html).toContain(sampleData.lectureWMB);
  });

  it("should include CTA button", () => {
    const html = buildModuleUsaEmail(sampleData);
    expect(html).toContain("dition compl");
    expect(html).toContain(sampleData.ctaUrl);
  });

  it("should include footer with disclaimer", () => {
    const html = buildModuleUsaEmail(sampleData);
    expect(html).toContain("ne constitue pas un conseil en investissement");
    expect(html).toContain("Weekly Brief USA");
  });

  it("should include responsive meta tags", () => {
    const html = buildModuleUsaEmail(sampleData);
    expect(html).toContain('name="viewport"');
    expect(html).toContain("width=device-width");
  });

  it("should include preheader text", () => {
    const html = buildModuleUsaEmail(sampleData);
    expect(html).toContain("S9 2026");
  });

  it("should have responsive email styles", () => {
    const html = buildModuleUsaEmail(sampleData);
    expect(html).toContain("@media");
    expect(html).toContain("max-width:600px");
  });
});

// ═══════════ buildModuleActionsEmail ═══════════

describe("buildModuleActionsEmail", () => {
  const sampleData: ModuleActionsEmailData = {
    weekNumber: 9,
    year: 2026,
    dateRange: "24 fév. — 28 fév.",
    title: "NVDA en tête, tech sous pression",
    subtitle: "Les résultats trimestriels dominent la semaine",
    topGainers: [
      { ticker: "NVDA", company: "NVIDIA", perf: "+8.2%", catalyst: "Résultats Q4 au-dessus des attentes" },
      { ticker: "CRM", company: "Salesforce", perf: "+5.1%", catalyst: "Guidance relevée" },
    ],
    topLosers: [
      { ticker: "SNOW", company: "Snowflake", perf: "-6.3%", catalyst: "Guidance décevante" },
      { ticker: "ZM", company: "Zoom", perf: "-4.1%", catalyst: "Croissance en ralentissement" },
    ],
    sectorHighlight: "La tech reste le secteur dominant avec +2.1% sur la semaine.",
    earningsHighlights: [
      "NVDA : BPA $0.89 vs $0.82 attendu, CA $39.3B vs $38.1B",
      "CRM : BPA $2.78 vs $2.65 attendu, guidance FY27 relevée",
    ],
    watchlistItems: [
      { ticker: "AAPL", reason: "Test du support à $220, earnings dans 2 semaines" },
      { ticker: "TSLA", reason: "Consolidation sous $280, volume en hausse" },
    ],
    ctaUrl: "https://wallstreetmarketbrief.ch/actions/1",
  };

  it("should generate valid HTML", () => {
    const html = buildModuleActionsEmail(sampleData);
    expect(html).toContain("<!DOCTYPE html>");
    expect(html).toContain("</html>");
  });

  it("should include Actions US module branding", () => {
    const html = buildModuleActionsEmail(sampleData);
    expect(html).toContain(MODULE_COLORS.actions.label);
    expect(html).toContain(MODULE_COLORS.actions.accent);
  });

  it("should include top gainers", () => {
    const html = buildModuleActionsEmail(sampleData);
    expect(html).toContain("Top Gagnants");
    expect(html).toContain("NVDA");
    expect(html).toContain("+8.2%");
    expect(html).toContain("CRM");
  });

  it("should include top losers", () => {
    const html = buildModuleActionsEmail(sampleData);
    expect(html).toContain("Top Perdants");
    expect(html).toContain("SNOW");
    expect(html).toContain("-6.3%");
  });

  it("should include sector highlight", () => {
    const html = buildModuleActionsEmail(sampleData);
    expect(html).toContain("Vue Sectorielle");
    expect(html).toContain(sampleData.sectorHighlight);
  });

  it("should include earnings highlights", () => {
    const html = buildModuleActionsEmail(sampleData);
    expect(html).toContain("Earnings");
    for (const earning of sampleData.earningsHighlights) {
      expect(html).toContain(earning);
    }
  });

  it("should include watchlist", () => {
    const html = buildModuleActionsEmail(sampleData);
    expect(html).toContain("Watchlist");
    expect(html).toContain("AAPL");
    expect(html).toContain("TSLA");
  });

  it("should include CTA with correct URL", () => {
    const html = buildModuleActionsEmail(sampleData);
    expect(html).toContain(sampleData.ctaUrl);
  });
});

// ═══════════ buildGenericModuleEmail ═══════════

describe("buildGenericModuleEmail", () => {
  it("should generate HTML for theme module", () => {
    const html = buildGenericModuleEmail({
      moduleType: "theme",
      title: "L'IA et les marchés financiers",
      subtitle: "Impact et perspectives pour 2026",
      bodyHtml: "<p>L'intelligence artificielle transforme les marchés...</p>",
    });
    expect(html).toContain("<!DOCTYPE html>");
    expect(html).toContain(MODULE_COLORS.theme.label);
    expect(html).toContain(MODULE_COLORS.theme.accent);
    expect(html).toContain("L'IA et les marchés financiers");
    expect(html).toContain("L'intelligence artificielle transforme les marchés");
  });

  it("should generate HTML for mondial module", () => {
    const html = buildGenericModuleEmail({
      moduleType: "mondial",
      weekNumber: 9,
      year: 2026,
      dateRange: "24 fév. — 28 fév.",
      title: "Tour d'horizon mondial",
      bodyHtml: "<p>Les marchés européens progressent...</p>",
    });
    expect(html).toContain(MODULE_COLORS.mondial.label);
    expect(html).toContain("Tour d'horizon mondial");
    expect(html).toContain("S9");
  });

  it("should fallback to general module for unknown types", () => {
    const html = buildGenericModuleEmail({
      moduleType: "unknown_type" as any,
      title: "Test",
      bodyHtml: "<p>Test content</p>",
    });
    expect(html).toContain("<!DOCTYPE html>");
    expect(html).toContain("Test content");
  });

  it("should include custom CTA when provided", () => {
    const html = buildGenericModuleEmail({
      moduleType: "theme",
      title: "Test",
      bodyHtml: "<p>Content</p>",
      ctaText: "Lire le thème complet",
      ctaUrl: "https://example.com/theme",
    });
    expect(html).toContain("Lire le thème complet");
    expect(html).toContain("https://example.com/theme");
  });

  it("should include custom footer text when provided", () => {
    const html = buildGenericModuleEmail({
      moduleType: "marche",
      title: "Test",
      bodyHtml: "<p>Content</p>",
      footerText: "Custom footer message",
    });
    expect(html).toContain("Custom footer message");
  });
});

// ═══════════ emailComponents helpers ═══════════

describe("emailComponents", () => {
  it("sectionHeading should generate HTML with accent color", () => {
    const html = emailComponents.sectionHeading("Test Heading", "#FF0000");
    expect(html).toContain("Test Heading");
    expect(html).toContain("#FF0000");
  });

  it("divider should generate a horizontal line", () => {
    const html = emailComponents.divider();
    expect(html).toContain("height:1px");
    expect(html).toContain("background-color:#E5E7EB");
  });

  it("spacer should generate a spacer with custom height", () => {
    const html = emailComponents.spacer(32);
    expect(html).toContain("height:32px");
  });

  it("spacer should default to 16px", () => {
    const html = emailComponents.spacer();
    expect(html).toContain("height:16px");
  });

  it("quote should generate a styled blockquote", () => {
    const html = emailComponents.quote("Test quote text", "#8B5CF6");
    expect(html).toContain("Test quote text");
    expect(html).toContain("#8B5CF6");
    expect(html).toContain("font-style:italic");
  });

  it("highlight should generate a highlighted block", () => {
    const html = emailComponents.highlight("Important info", "#2E7D5B");
    expect(html).toContain("Important info");
    expect(html).toContain("#2E7D5B");
  });

  it("bulletItem should generate a bullet point", () => {
    const html = emailComponents.bulletItem("Bullet text", "#344453");
    expect(html).toContain("Bullet text");
    expect(html).toContain("#344453");
  });
});
