/**
 * WMB Onboarding Email Sequence V10 — 7 Steps
 * ────────────────────────────────────────────
 * Step 1 (J+0): Welcome — sent on registration (handled by emailAuth)
 * Step 2 (J+1): Feature Guide — discover the platform
 * Step 3 (J+3): Formation & Glossaire — show educational value
 * Step 4 (J+5): Thématiques & Indicateurs — deepen engagement
 * Step 5 (J+7): Premium Push — convert free users to paid
 * Step 6 (J+10): Quiz & Badges — gamification, re-engagement
 * Step 7 (J+14): Social Proof & Last CTA — testimonials + final push
 *
 * Design V10: "Dark Shell + Light Core" — unified with buildWmbEmailHtml
 * Light body (#FFFFFF), dark header/footer (#111318), no emojis
 */
import { sendEmail, buildWmbEmailHtml } from "../email";

const SITE_URL = "https://wallstreetmarketbrief.ch";

// V10 Light Core tokens
const CARD_BG = "#F7F8FA";
const BORDER_LIGHT = "#E5E7EB";
const TEXT_DARK = "#1A1A1A";
const TEXT_BODY = "#374151";
const TEXT_CAPTION = "#6B7280";
const GOLD = "#C8A960";
const GREEN = "#16A34A";
const BLUE = "#2563EB";

/**
 * Step 2 — Feature Guide (sent ~24h after registration)
 * Goal: Show the user everything they can do for free, build habit
 */
export async function sendOnboardingGuide(
  email: string,
  name: string
): Promise<boolean> {
  const userName = name || "cher investisseur";

  const html = buildWmbEmailHtml({
    title: `${userName}, voici votre espace WMB`,
    preheader:
      "Terminal march\u00e9s, news, outils \u2014 votre guide de d\u00e9marrage rapide.",
    bodyHtml: `
      <p style="font-size:15px;color:${TEXT_DARK};line-height:1.7;margin:0 0 16px;">
        Bienvenue dans votre espace WMB. Voici ce que vous pouvez explorer d&egrave;s maintenant :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GOLD};border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0 0 4px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Terminal March&eacute;s</p>
            <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">Indices, actions, forex, commodities &mdash; toutes les donn&eacute;es en temps r&eacute;el dans un seul tableau de bord.</p>
          </td>
        </tr>
        <tr><td style="height:8px;"></td></tr>
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GREEN};border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0 0 4px;font-weight:700;font-size:13px;color:${TEXT_DARK};">News Financi&egrave;res</p>
            <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">Les actualit&eacute;s macro et march&eacute;s les plus pertinentes, filtr&eacute;es et r&eacute;sum&eacute;es pour vous chaque jour.</p>
          </td>
        </tr>
        <tr><td style="height:8px;"></td></tr>
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GOLD};border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0 0 4px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Outils Interactifs</p>
            <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">Calculateur d'int&eacute;r&ecirc;ts compos&eacute;s, simulateur de dividendes, portefeuille virtuel &mdash; des outils concrets pour vos d&eacute;cisions.</p>
          </td>
        </tr>
      </table>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 16px;">
        Tout cela est <strong style="color:${TEXT_DARK};">gratuit et accessible d&egrave;s maintenant</strong>. Connectez-vous pour explorer votre espace.
      </p>

      <p style="font-size:12px;color:${TEXT_CAPTION};margin:0;">
        Demain, nous vous pr&eacute;senterons la formation et le glossaire &mdash; deux outils essentiels pour progresser en bourse.
      </p>
    `,
    ctaText: "Explorer mon espace",
    ctaUrl: `${SITE_URL}/marches`,
    footerText:
      "Vous recevez cet email car vous vous \u00eates inscrit sur WallStreet Market Brief.",
  });

  return sendEmail({
    to: email,
    subject: "Votre guide de d\u00e9marrage \u2014 WallStreet Market Brief",
    html,
    tag: "onboarding",
  });
}

/**
 * Step 3 — Formation & Glossaire (sent ~3 days after registration)
 * Goal: Show educational value, build engagement before premium push
 */
export async function sendOnboardingFormation(
  email: string,
  name: string
): Promise<boolean> {
  const userName = name || "cher investisseur";

  const html = buildWmbEmailHtml({
    title: `${userName}, apprenez la bourse \u00e0 votre rythme`,
    preheader:
      "437+ le\u00e7ons, 1 007+ termes expliqu\u00e9s, 54 indicateurs \u2014 votre formation vous attend.",
    bodyHtml: `
      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 16px;">
        Vous avez d&eacute;couvert le terminal et les outils. Maintenant, passons &agrave; l'essentiel : <strong style="color:${TEXT_DARK};">comprendre les march&eacute;s</strong>.
      </p>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 20px;">
        WMB propose une formation compl&egrave;te, structur&eacute;e du d&eacute;butant &agrave; l'avanc&eacute; :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
            <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
              <tr>
                <td style="vertical-align:top;width:36px;">
                  <div style="width:28px;height:28px;background-color:${TEXT_DARK};border-radius:6px;text-align:center;line-height:28px;color:white;font-weight:700;font-size:13px;">1</div>
                </td>
                <td style="padding-left:12px;">
                  <p style="margin:0 0 2px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Formation &mdash; 437+ le&ccedil;ons</p>
                  <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">7 modules progressifs : bases, analyse technique, analyse fondamentale, gestion de portefeuille, psychologie, et strat&eacute;gies avanc&eacute;es.</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr><td style="height:8px;"></td></tr>
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
            <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
              <tr>
                <td style="vertical-align:top;width:36px;">
                  <div style="width:28px;height:28px;background-color:${GREEN};border-radius:6px;text-align:center;line-height:28px;color:white;font-weight:700;font-size:13px;">2</div>
                </td>
                <td style="padding-left:12px;">
                  <p style="margin:0 0 2px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Glossaire &mdash; 1 007+ termes</p>
                  <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">Chaque terme financier expliqu&eacute; simplement, avec des exemples concrets. Du RSI au P/E ratio, plus aucun terme ne vous &eacute;chappera.</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr><td style="height:8px;"></td></tr>
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
            <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
              <tr>
                <td style="vertical-align:top;width:36px;">
                  <div style="width:28px;height:28px;background-color:${GOLD};border-radius:6px;text-align:center;line-height:28px;color:white;font-weight:700;font-size:13px;">3</div>
                </td>
                <td style="padding-left:12px;">
                  <p style="margin:0 0 2px;font-weight:700;font-size:13px;color:${TEXT_DARK};">54 indicateurs techniques</p>
                  <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">Chaque indicateur expliqu&eacute; avec sa formule, son interpr&eacute;tation et des cas d'usage r&eacute;els. Moyennes mobiles, MACD, Bollinger, etc.</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 16px;">
        Commencez par le glossaire pour ma&icirc;triser le vocabulaire, puis plongez dans la formation &agrave; votre rythme.
      </p>

      <p style="font-size:12px;color:${TEXT_CAPTION};margin:0;">
        Dans 2 jours, nous vous pr&eacute;senterons les th&eacute;matiques sectorielles &mdash; un contenu exclusif pour approfondir vos analyses.
      </p>
    `,
    ctaText: "Commencer la formation",
    ctaUrl: `${SITE_URL}/formation`,
    accentColor: "${GREEN}",
    footerText:
      "Vous recevez cet email car vous vous \u00eates inscrit sur WallStreet Market Brief.",
  });

  return sendEmail({
    to: email,
    subject: "437+ le\u00e7ons vous attendent \u2014 Formation WMB",
    html,
    tag: "onboarding",
  });
}

/**
 * Step 4 — Thématiques & Indicateurs (sent ~5 days after registration)
 * Goal: Deepen engagement with sectoral themes and technical indicators
 */
export async function sendOnboardingThematiques(
  email: string,
  name: string
): Promise<boolean> {
  const userName = name || "cher investisseur";

  const html = buildWmbEmailHtml({
    title: `${userName}, explorez les th\u00e9matiques sectorielles`,
    preheader:
      "IA, d\u00e9fense, nucl\u00e9aire, biotech \u2014 15+ th\u00e9matiques d'investissement analys\u00e9es.",
    bodyHtml: `
      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 16px;">
        Vous avez d&eacute;couvert la formation et le glossaire. Aujourd'hui, d&eacute;couvrez un contenu que nos abonn&eacute;s appr&eacute;cient particuli&egrave;rement : <strong style="color:${TEXT_DARK};">les th&eacute;matiques sectorielles</strong>.
      </p>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 20px;">
        Chaque mois, WMB publie une analyse approfondie d'un secteur d'investissement :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0 0 6px;font-weight:700;font-size:14px;color:${TEXT_DARK};">Th&egrave;me du Mois &mdash; Gratuit</p>
            <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">Chaque mois, un secteur analys&eacute; en profondeur : drivers de croissance, risques, entreprises cl&eacute;s, et sc&eacute;narios conditionnels. Le th&egrave;me du mois est accessible gratuitement.</p>
          </td>
        </tr>
        <tr><td style="height:8px;"></td></tr>
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0 0 6px;font-weight:700;font-size:14px;color:${TEXT_DARK};">15+ th&eacute;matiques disponibles</p>
            <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">Intelligence artificielle, d&eacute;fense, nucl&eacute;aire, biotechnologie, cannabis, quantum computing, cybersecurit&eacute;, &eacute;nergie renouvelable, et bien d'autres.</p>
          </td>
        </tr>
        <tr><td style="height:8px;"></td></tr>
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0 0 6px;font-weight:700;font-size:14px;color:${TEXT_DARK};">54 indicateurs techniques</p>
            <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">RSI, MACD, Bollinger, Ichimoku, ADX&hellip; Chaque indicateur expliqu&eacute; avec formule, interpr&eacute;tation et exemples concrets pour vos analyses.</p>
          </td>
        </tr>
      </table>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 16px;">
        Commencez par le <strong style="color:${TEXT_DARK};">Th&egrave;me du Mois gratuit</strong> pour d&eacute;couvrir la qualit&eacute; de nos analyses sectorielles.
      </p>

      <p style="font-size:12px;color:${TEXT_CAPTION};margin:0;">
        Dans 2 jours, nous vous pr&eacute;senterons les offres Premium pour acc&eacute;der &agrave; tout le contenu WMB.
      </p>
    `,
    ctaText: "Lire le Th\u00e8me du Mois",
    ctaUrl: `${SITE_URL}/theme-du-mois`,
    accentColor: "#C8A960",
    footerText:
      "Vous recevez cet email car vous vous \u00eates inscrit sur WallStreet Market Brief.",
  });

  return sendEmail({
    to: email,
    subject: "15+ th\u00e9matiques d'investissement \u00e0 explorer \u2014 WMB",
    html,
    tag: "onboarding",
  });
}

/**
 * Step 5 — Premium Push (sent ~7 days after registration)
 * Goal: Convert free users to paid subscribers
 * Only sent to users who are NOT already premium
 */
export async function sendOnboardingPremiumPush(
  email: string,
  name: string
): Promise<boolean> {
  const userName = name || "cher investisseur";

  const html = buildWmbEmailHtml({
    title: `${userName}, pr\u00eat \u00e0 passer au niveau sup\u00e9rieur ?`,
    preheader:
      "D\u00e9bloquez 2 hebdo + 3 mensuels et tous les outils avanc\u00e9s.",
    bodyHtml: `
      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 16px;">
        Cela fait une semaine que vous avez rejoint WMB. Vous avez d&eacute;couvert le terminal march&eacute;s, la formation, le glossaire et les outils gratuits.
      </p>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 20px;">
        Voici ce que vous d&eacute;bloquez avec <strong style="color:${TEXT_DARK};">l'abonnement Premium</strong> :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:12px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
            <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
              <tr>
                <td style="color:${GREEN};font-size:14px;font-weight:800;width:20px;vertical-align:top;">+</td>
                <td style="padding-left:8px;">
                  <p style="margin:0;font-weight:700;font-size:13px;color:${TEXT_DARK};">2 modules hebdo + 3 contenus mensuels</p>
                  <p style="margin:2px 0 0;font-size:11px;color:${TEXT_CAPTION};">Brief USA, Monde, Suisse, Actions, Th&egrave;me du Mois</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr><td style="height:6px;"></td></tr>
        <tr>
          <td style="padding:12px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
            <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
              <tr>
                <td style="color:${GREEN};font-size:14px;font-weight:800;width:20px;vertical-align:top;">+</td>
                <td style="padding-left:8px;">
                  <p style="margin:0;font-weight:700;font-size:13px;color:${TEXT_DARK};">Toutes les &eacute;ditions en ligne</p>
                  <p style="margin:2px 0 0;font-size:11px;color:${TEXT_CAPTION};">Toutes les &eacute;ditions pass&eacute;es, consultables et t&eacute;l&eacute;chargeables</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr><td style="height:6px;"></td></tr>
        <tr>
          <td style="padding:12px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
            <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
              <tr>
                <td style="color:${GREEN};font-size:14px;font-weight:800;width:20px;vertical-align:top;">+</td>
                <td style="padding-left:8px;">
                  <p style="margin:0;font-weight:700;font-size:13px;color:${TEXT_DARK};">Outils avanc&eacute;s</p>
                  <p style="margin:2px 0 0;font-size:11px;color:${TEXT_CAPTION};">Portefeuille virtuel, scanner d'actions, simulateur de position</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr><td style="height:6px;"></td></tr>
        <tr>
          <td style="padding:12px 16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};">
            <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
              <tr>
                <td style="color:${GREEN};font-size:14px;font-weight:800;width:20px;vertical-align:top;">+</td>
                <td style="padding-left:8px;">
                  <p style="margin:0;font-weight:700;font-size:13px;color:${TEXT_DARK};">Terminal complet</p>
                  <p style="margin:2px 0 0;font-size:11px;color:${TEXT_CAPTION};">Actions US d&eacute;taill&eacute;es, Forex, Commodities, Analyse 360&deg;</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:18px;background-color:#111318;border-radius:8px;" align="center">
            <p style="margin:0 0 4px;font-size:20px;font-weight:800;color:#FFFFFF;">D&egrave;s CHF 49/mois</p>
            <p style="margin:0;font-size:12px;color:#9CA3AF;">D&eacute;couverte ou Premium &mdash; Sans engagement</p>
          </td>
        </tr>
      </table>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0;">
        <tr>
          <td align="center">
            <span style="display:inline-block;padding:4px 10px;background-color:rgba(22,163,74,0.08);color:${GREEN};font-size:10px;font-weight:700;border-radius:4px;margin:2px;">Satisfait ou rembours&eacute; 14j</span>
            <span style="display:inline-block;padding:4px 10px;background-color:rgba(200,169,96,0.08);color:${GOLD};font-size:10px;font-weight:700;border-radius:4px;margin:2px;">R&eacute;siliation en 1 clic</span>
            <span style="display:inline-block;padding:4px 10px;background-color:rgba(37,99,235,0.08);color:${BLUE};font-size:10px;font-weight:700;border-radius:4px;margin:2px;">Paiement s&eacute;curis&eacute;</span>
          </td>
        </tr>
      </table>
    `,
    ctaText: "D\u00e9couvrir les offres Premium",
    ctaUrl: `${SITE_URL}/pricing`,
    accentColor: "#C8A960",
    footerText:
      "Vous recevez cet email car vous vous \u00eates inscrit sur WallStreet Market Brief.",
  });

  return sendEmail({
    to: email,
    subject: "D\u00e9bloquez tout le potentiel de WMB \u2014 Offre Premium",
    html,
    tag: "onboarding",
  });
}

/**
 * Step 6 — Quiz & Badges (sent ~10 days after registration)
 * Goal: Re-engage with gamification, show quiz and badge system
 */
export async function sendOnboardingQuiz(
  email: string,
  name: string
): Promise<boolean> {
  const userName = name || "cher investisseur";

  const html = buildWmbEmailHtml({
    title: `${userName}, testez vos connaissances`,
    preheader:
      "500+ questions, badges \u00e0 d\u00e9bloquer \u2014 o\u00f9 en \u00eates-vous ?",
    bodyHtml: `
      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 16px;">
        Vous avez explor&eacute; la formation, le glossaire et les th&eacute;matiques. Il est temps de <strong style="color:${TEXT_DARK};">mesurer vos progr&egrave;s</strong>.
      </p>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 20px;">
        WMB propose un syst&egrave;me de quiz interactifs avec des badges &agrave; d&eacute;bloquer :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GOLD};border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0 0 4px;font-weight:700;font-size:13px;color:${TEXT_DARK};">500+ questions</p>
            <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">R&eacute;parties par th&egrave;me : bases, analyse technique, fondamentale, macro&eacute;conomie, et plus encore. Questions toujours diff&eacute;rentes.</p>
          </td>
        </tr>
        <tr><td style="height:8px;"></td></tr>
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GREEN};border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0 0 4px;font-weight:700;font-size:13px;color:${TEXT_DARK};">Badges &agrave; d&eacute;bloquer</p>
            <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">Obtenez 80% ou plus pour d&eacute;bloquer un badge par cat&eacute;gorie. Collectionnez-les tous pour prouver votre ma&icirc;trise.</p>
          </td>
        </tr>
        <tr><td style="height:8px;"></td></tr>
        <tr>
          <td style="padding:14px 16px;background-color:${CARD_BG};border-radius:8px;border-left:3px solid ${GOLD};border:1px solid ${BORDER_LIGHT};">
            <p style="margin:0 0 4px;font-weight:700;font-size:13px;color:${TEXT_DARK};">5 questions gratuites par th&egrave;me</p>
            <p style="margin:0;font-size:12px;color:${TEXT_CAPTION};line-height:1.5;">Testez-vous gratuitement sur chaque cat&eacute;gorie. Les quiz complets sont r&eacute;serv&eacute;s aux abonn&eacute;s.</p>
          </td>
        </tr>
      </table>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 16px;">
        Commencez par un quiz gratuit et voyez o&ugrave; vous en &ecirc;tes. Chaque question est une occasion d'apprendre.
      </p>

      <p style="font-size:12px;color:${TEXT_CAPTION};margin:0;">
        Dans quelques jours, nous partagerons les retours de nos abonn&eacute;s et une derni&egrave;re opportunit&eacute; de rejoindre la communaut&eacute; Premium.
      </p>
    `,
    ctaText: "Lancer un quiz",
    ctaUrl: `${SITE_URL}/quiz`,
    accentColor: "#C8A960",
    footerText:
      "Vous recevez cet email car vous vous \u00eates inscrit sur WallStreet Market Brief.",
  });

  return sendEmail({
    to: email,
    subject: "Testez vos connaissances \u2014 Quiz WMB",
    html,
    tag: "onboarding",
  });
}

/**
 * Step 7 — Social Proof & Last CTA (sent ~14 days after registration)
 * Goal: Final conversion push with testimonials and social proof
 * Only sent to users who are NOT already premium
 */
export async function sendOnboardingSocialProof(
  email: string,
  name: string
): Promise<boolean> {
  const userName = name || "cher investisseur";

  const html = buildWmbEmailHtml({
    title: `${userName}, ce que disent nos abonn\u00e9s`,
    preheader:
      "D\u00e9couvrez pourquoi des centaines d'investisseurs font confiance \u00e0 WMB chaque semaine.",
    bodyHtml: `
      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 16px;">
        Cela fait deux semaines que vous avez rejoint WMB. Vous avez explor&eacute; nos outils gratuits, la formation, les th&eacute;matiques et les quiz.
      </p>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 20px;">
        Voici ce que disent nos abonn&eacute;s Premium :
      </p>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};border-left:3px solid ${GOLD};">
            <p style="margin:0 0 8px;font-size:13px;color:${TEXT_DARK};line-height:1.6;font-style:italic;">&laquo; Je gagne 2 &agrave; 3 heures par semaine. Le format deck est parfait pour comprendre la tendance en 15 minutes le dimanche matin. &raquo;</p>
            <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};font-weight:600;">M.L. &mdash; Investisseur priv&eacute;, Gen&egrave;ve</p>
          </td>
        </tr>
        <tr><td style="height:8px;"></td></tr>
        <tr>
          <td style="padding:16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};border-left:3px solid ${GOLD};">
            <p style="margin:0 0 8px;font-size:13px;color:${TEXT_DARK};line-height:1.6;font-style:italic;">&laquo; Enfin une newsletter qui ne me dit pas quoi acheter. Du contexte, des chiffres, des risques &mdash; exactement ce dont j'ai besoin. &raquo;</p>
            <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};font-weight:600;">S.K. &mdash; Analyste financier, Zurich</p>
          </td>
        </tr>
        <tr><td style="height:8px;"></td></tr>
        <tr>
          <td style="padding:16px;background-color:${CARD_BG};border-radius:8px;border:1px solid ${BORDER_LIGHT};border-left:3px solid ${GREEN};">
            <p style="margin:0 0 8px;font-size:13px;color:${TEXT_DARK};line-height:1.6;font-style:italic;">&laquo; La formation est incroyablement compl&egrave;te. J'ai appris plus en 2 mois qu'en 2 ans de vid&eacute;os YouTube. &raquo;</p>
            <p style="margin:0;font-size:11px;color:${TEXT_CAPTION};font-weight:600;">A.R. &mdash; D&eacute;butant en bourse, Lausanne</p>
          </td>
        </tr>
      </table>

      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:18px;background-color:#111318;border-radius:8px;" align="center">
            <p style="margin:0 0 4px;font-size:20px;font-weight:800;color:#FFFFFF;">D&egrave;s CHF 49/mois</p>
            <p style="margin:0;font-size:12px;color:#9CA3AF;">Rejoignez la communaut&eacute; WMB Premium</p>
          </td>
        </tr>
      </table>

      <p style="font-size:14px;color:${TEXT_BODY};line-height:1.7;margin:0 0 16px;">
        C'est le dernier email de notre s&eacute;quence de bienvenue. Si vous avez des questions, r&eacute;pondez directement &agrave; cet email &mdash; nous lisons chaque message.
      </p>
    `,
    ctaText: "Rejoindre WMB Premium",
    ctaUrl: `${SITE_URL}/pricing`,
    accentColor: "#C8A960",
    footerText:
      "Dernier email de la s\u00e9quence de bienvenue. Vous recevez cet email car vous vous \u00eates inscrit sur WallStreet Market Brief.",
  });

  return sendEmail({
    to: email,
    subject: "Ce que disent nos abonn\u00e9s \u2014 WMB",
    html,
    tag: "onboarding",
  });
}
