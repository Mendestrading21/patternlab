/**
 * WMB Fil Rouge — Semaine 11 (MER 12/03 2026)
 * CPI Day, Oracle Résultats, Iran Semaine 2 — Volatilité Maximale
 */
import type { FilRougeModuleData } from "../filRouge";

export const FIL_ROUGE_SEMAINE_11: FilRougeModuleData = {
  id: 404,
  weekNumber: 11,
  year: 2026,
  dateRange: "MER 12/03 2026",
  title: "CPI Day, Oracle Résultats & Iran Semaine 2 — Le Marché Retient Son Souffle",
  subtitle: "FIL ROUGE — MID-WEEK UPDATE",
  publishedAt: "2026-03-12T06:30:00Z",

  delta: {
    summary: "Le marché entre dans la semaine la plus importante de 2026 à ce jour. Oracle publie lundi soir — premier vrai test de la demande IA cloud enterprise. Le CPI tombe mercredi matin — juge de paix sur la stagflation. Le VIX reste ancré au-dessus de 29, à un point du seuil de panique. Le pétrole se stabilise au-dessus de $90 sans nouvelle escalade Iran, mais la prime géopolitique reste intacte. Les investisseurs sont en mode attentiste — les volumes baissent, la volatilité monte, et personne ne veut se positionner avant le CPI.",
    indices: [
      { name: "S&P 500", value: "6 740", change: "-2.02% (sem. passée)" },
      { name: "Nasdaq", value: "21 478", change: "-1.24% (sem. passée)" },
      { name: "Dow Jones", value: "47 501", change: "-3.01% (sem. passée)" },
      { name: "Russell 2000", value: "2 525", change: "-4.07% (sem. passée)" },
    ],
    commodities: [
      { name: "WTI", value: "$103,06/b (dim.)", change: "+35% (sem. passee)" },
      { name: "Brent", value: "$106,79/b (dim.)", change: "+15,21% (dim.)" },
      { name: "Or", value: "$5 102/oz", change: "-6,0% (sem. passee)" },
    ],
    crypto: [
      { name: "Bitcoin", value: "$67 766", change: "+0,42% (sem. passee)" },
      { name: "Ethereum", value: "~$2 000", change: "~0% (sem. passee)" },
    ],
    lectureWMB: "Le delta depuis dimanche est explosif. Le petrole a bondi de 35% sur la semaine — la plus forte hausse depuis que les futures existent (1983) — pour atteindre 103,06 dollars dimanche soir. Le Nikkei plonge de 5,24% dimanche soir, sa pire seance depuis aout 2024. Les futures S&P 500 sont en forte baisse. Le VIX a 29,49 est a un point du seuil de panique (30). L'or recule de 6% sur la semaine a 5 102 dollars — paradoxalement, le dollar est le refuge numero un (DXY +1,4%, meilleure semaine depuis aout), pas l'or. Le Bitcoin a 67 766 dollars est la surprise : il resiste mieux que les actions, Bloomberg titrant 'Bitcoin Beats Risk Assets'. Le marche entre dans la semaine la plus importante de 2026 avec un cocktail explosif : CPI mercredi (juge de paix sur la stagflation), Oracle mardi soir (test IA cloud), et un conflit Iran qui entre dans sa 2eme semaine sans signe de desescalade.",
  },

  agenda72h: [
    "MERCREDI 12/03 — CPI février (08h30 ET) : L'ÉVÉNEMENT CLÉ de la semaine et potentiellement de l'année. Consensus +0,21% MoM, 2,4% YoY. Au-dessus de 2,5% = confirmation de la stagflation, sell-off probable, VIX au-dessus de 30. En dessous de 2,3% = soulagement massif, short squeeze tech, VIX sous 25.",
    "MERCREDI 12/03 — Core CPI février (08h30 ET) : Consensus +0,19% MoM, 2,4% YoY. Le core est plus important que le headline pour la Fed — c'est le chiffre qui déterminera les anticipations de taux.",
    "JEUDI 13/03 — Dollar General (DG) avant ouverture : Le baromètre du consommateur bas de gamme. Si DG déçoit, c'est un signal de récession avancé — le segment le plus vulnérable à l'inflation.",
    "JEUDI 13/03 — Adobe (ADBE) après clôture : Test de la monétisation IA créative avec Firefly. ARR Creative Cloud et guidance seront scrutés. La question clé : Firefly crée-t-il de la valeur incrémentale ou cannibalise-t-il ?",
    "JEUDI 13/03 — Ulta Beauty (ULTA) après clôture : Test du 'lipstick effect' — les consommateurs se tournent-ils vers les petits plaisirs quand ils ne peuvent plus se permettre les gros achats ?",
    "JEUDI 13/03 — Jobless Claims : Confirmation ou infirmation du NFP -92K. Si les claims augmentent, le marché du travail se dégrade vraiment.",
    "VENDREDI 14/03 — PCE janvier (08h30 ET) : L'indicateur préféré de la Fed pour mesurer l'inflation. Retardé par le shutdown partiel mais crucial pour les anticipations de taux.",
    "VENDREDI 14/03 — UMich Consumer Sentiment mars préliminaire : Impact de l'essence à +12% sur le moral des consommateurs. Un chiffre sous 60 serait alarmant.",
  ],

  watchlistUpdate: [
    { ticker: "ORCL", status: "Résultats lundi soir — OCI cloud growth est LE chiffre de la semaine. Au-dessus de 30% = bullish tech/IA. En dessous = correction accélérée.", level: "CRITIQUE" },
    { ticker: "CPI", status: "Mercredi 08h30 ET — consensus 2,4% YoY. Seuil critique : au-dessus de 2,5% = stagflation confirmée. En dessous de 2,3% = soulagement.", level: "CRITIQUE" },
    { ticker: "ADBE", status: "Jeudi après clôture — Firefly adoption rate, ARR Creative Cloud au-dessus de $14B, guidance. Le test de la monétisation IA créative.", level: "IMPORTANT" },
    { ticker: "DG", status: "Jeudi avant ouverture — same-store sales, impact inflation sur le consommateur bas de gamme. Le baromètre de la récession.", level: "IMPORTANT" },
    { ticker: "WTI", status: "103,06$ dimanche soir (+35% sur la semaine) — surveiller $110 (escalade Ormuz) ou $90 (desescalade). Chaque dollar compte pour l'inflation.", level: "CRITIQUE" },
    { ticker: "VIX", status: "29,49 — a un point du seuil de panique (30). Un CPI chaud le fait basculer. Sous 25 = soulagement. Futures VIX dimanche a 33+.", level: "CRITIQUE" },
  ],

  riskAlert: "ALERTE RISQUE MAXIMALE — La semaine 11 concentre les catalyseurs les plus importants de 2026 à ce jour. Le CPI mercredi est le juge de paix sur la stagflation — un chiffre au-dessus de 2,5% confirmerait le piège et pourrait déclencher un sell-off de 3-5% sur le S&P 500. Oracle lundi soir teste le narratif IA — si la demande cloud déçoit, c'est tout le secteur tech qui vacille. Le VIX à 29 est à un point du seuil de panique (30). Le conflit Iran entre dans sa 2ème semaine sans signe de désescalade — le pétrole au-dessus de $90 alimente l'inflation et comprime les marges. Le NFP à -92K signale un marché du travail en détérioration rapide. La combinaison de ces facteurs crée un environnement de risque asymétrique vers le bas (40% bear vs 15% bull). Ce n'est PAS le moment de prendre des risques directionnels importants — la prudence et la gestion du risque doivent primer sur la recherche de performance.",

  pdfUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663135061541/Wf8Nj4yLBCzwrPQSdtP8cC/filrouge-s11_9185d2d0.pdf",
  sources: "Données de marché : clôture US du vendredi 7 mars 2026 via Yahoo Finance, CNBC, Reuters, Nasdaq.com. Consensus CPI : Wells Fargo Economics, Bloomberg. Données VIX : CBOE. Données pétrole : CME Group, Reuters. Données crypto : CoinGecko. Or : pricegold.net.",
  disclaimer: "Ce document est produit à des fins strictement informatives et éducatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente d'actifs financiers, un conseil en investissement, ou une promesse de performance. Les marchés financiers sont par nature imprévisibles.",
};
