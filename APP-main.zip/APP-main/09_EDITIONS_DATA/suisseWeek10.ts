import type { SuisseModuleData } from "../suisse";

export const SUISSE_SEMAINE_10: SuisseModuleData = {
  id: 201,
  weekNumber: 10,
  year: 2026,
  dateRange: "LUN 24/02 - VEN 28/02",
  title: "SMI Record 14,014 -- PIB +0.1%, BNS Profit Record CHF 26.58 Mds",
  subtitle: "MODULE SUISSE",
  publishedAt: "2026-03-01T08:00:00Z",

  executiveSummary: {
    weekPast: [
      "SMI : 14,014 (+0.6% semaine, +8.2% YTD) -- nouveau record historique, 7e semaine consecutive de hausse. Le SMI surperforme le S&P 500 (+1.3% YTD) pour la premiere fois depuis 2019.",
      "PIB suisse T4 2025 : +0.1% QoQ -- en dessous du consensus de +0.2%. L'economie suisse est en stagnation, la croissance annuelle 2025 ressort a +0.9% (vs +1.3% en 2024).",
      "BNS : profit record de CHF 26.58 milliards en 2025 -- principalement sur les devises etrangeres (+CHF 20.8 Mds) et l'or (+CHF 5.8 Mds). C'est le 2e meilleur resultat de l'histoire de la BNS.",
      "Swiss Re : profit record de USD 3.2 milliards en 2025 -- dividende en hausse de 14% a CHF 7.35/action. Le titre bondit de +3.8% sur la semaine.",
      "EUR/CHF : 0.9350 -- plus bas depuis plus de 10 ans. Le franc suisse est en mode refuge total sur les frappes Iran et l'incertitude mondiale.",
      "Exportations horlogeres : en baisse de 3% YoY en janvier 2026 -- la Chine et Hong Kong reculent de 8%, signe de faiblesse persistante du luxe chinois.",
    ],
    weekAhead: [
      "Reunion BNS le 20 mars -- le marche anticipe un statu quo a 0.25% (60% de probabilite) ou une baisse a 0% (40%). Le PIB faible et l'inflation a 0.3% plaident pour une baisse.",
      "PMI suisse procure.ch (lundi) -- indicateur avance de l'activite manufacturiere. Consensus : 49.5 (contraction). Un chiffre sous 48 serait un signal d'alarme.",
      "Frappes Iran -- impact direct sur le CHF (valeur refuge). Si l'Iran riposte, l'EUR/CHF pourrait passer sous 0.92, forcant la BNS a intervenir.",
      "Earnings suisses : Adecco (emploi europeen, mardi), Baloise (assurance, mercredi), Straumann (medtech, jeudi). Ces resultats donneront le pouls de l'economie suisse.",
      "Decision BCE jeudi 6 mars -- impact indirect sur le CHF via l'EUR/CHF. Une BCE dovish affaiblirait l'euro et renforcerait le CHF.",
      "NFP US vendredi 6 mars -- impact sur l'USD/CHF. Un NFP faible renforcerait le CHF face au dollar.",
    ],
    lectureWMB: "Le SMI atteint un record historique a 14,014, porte par les defensives (Nestle, Roche, Novartis representent 55% de l'indice) et le flight-to-safety mondial. C'est la 7e semaine consecutive de hausse -- une serie qui n'avait pas ete observee depuis 2021. Mais sous la surface, l'economie suisse montre des signes de faiblesse : le PIB a +0.1% confirme une stagnation, les exportations horlogeres reculent, et l'inflation a 0.3% est dangereusement proche de la deflation. La BNS est dans un dilemme : le CHF trop fort (EUR/CHF 0.9350, plus bas 10 ans) penalise les exportateurs, mais une baisse a 0% enverrait un signal de panique. Le profit record de CHF 26.58 Mds donne a la BNS une marge de manoeuvre pour des interventions sur le marche des changes sans baisser les taux. Swiss Re (+3.8%) est le titre de la semaine avec un profit record et un dividende en hausse de 14%. Les frappes Iran renforcent le statut de refuge du CHF -- si l'escalade se poursuit, le CHF pourrait encore se renforcer, ce qui serait un probleme majeur pour l'industrie exportatrice suisse.",
  },

  chf: [
    { pair: "EUR/CHF", value: "0.9350", change1W: "-1.80%" },
    { pair: "USD/CHF", value: "0.8950", change1W: "-0.95%" },
    { pair: "GBP/CHF", value: "1.1250", change1W: "-1.20%" },
    { pair: "CHF/JPY", value: "167.20", change1W: "+0.30%" },
  ],
  chfLecture: "Le franc suisse est en mode refuge total et domine toutes les devises cette semaine. L'EUR/CHF a 0.9350 est au plus bas depuis plus de 10 ans -- un niveau qui n'avait pas ete atteint depuis la suppression du plancher EUR/CHF par la BNS en janvier 2015. Les flux risk-off lies aux frappes Iran, combines a la faiblesse structurelle de l'euro (croissance zone euro a +0.1% T4), poussent le CHF a la hausse. L'USD/CHF a 0.8950 montre que le CHF se renforce meme face au dollar -- un signe de stress extreme sur les marches. Le GBP/CHF recule de -1.20% malgre la relative resilience de l'economie britannique. Le CHF/JPY progresse legerement (+0.30%) car le yen est aussi en mode refuge. Un CHF fort a deux consequences opposees : il penalise les exportateurs suisses (Swatch -2%, Richemont -2.3%, Holcim -1.8%) mais protege le pouvoir d'achat des consommateurs et reduit le cout des importations. La BNS surveille de pres : si l'EUR/CHF passe sous 0.92, une intervention directe sur le marche des changes est probable (achats massifs d'euros). Le seuil psychologique de 0.90 serait un point de non-retour qui forcerait des mesures extraordinaires.",

  bns: {
    rate: "0.25%",
    inflation: "0.3% YoY (janvier 2026)",
    nextMeeting: "20 mars 2026",
    stance: "Accommodante -- la BNS a baisse 4 fois consecutivement en 2024-2025 (de 1.75% a 0.25%). Le marche anticipe un statu quo a 0.25% (60%) ou une baisse a 0% (40%).",
    lectureWMB: "La BNS est dans la position la plus delicate de toutes les grandes banques centrales. L'inflation a 0.3% est bien en dessous de la cible de 0-2%, ce qui justifierait theoriquement une baisse a 0% ou meme un retour aux taux negatifs. Mais le CHF fort est deja un probleme majeur pour les exportateurs -- des taux negatifs amplifieraient le signal de faiblesse economique et pourraient paradoxalement renforcer le CHF (les investisseurs interpreteraient une baisse a 0% comme un signe de panique). Le profit record de CHF 26.58 milliards en 2025 donne a la BNS une marge de manoeuvre considerable pour des interventions sur le marche des changes (achats d'euros) sans avoir a baisser les taux. Le scenario le plus probable pour le 20 mars : statu quo a 0.25% avec un signal dovish clair pour juin, accompagne d'interventions verbales sur le CHF. Si le PIB T1 2026 est negatif (recession technique), la BNS serait forcee de baisser a 0% en juin. Le marche des swaps de taux anticipe un taux directeur a 0% d'ici septembre 2026.",
  },

  blueChips: [
    { ticker: "NESN", value: "CHF 92.50", change1W: "+1.2%" },
    { ticker: "ROG", value: "CHF 278.40", change1W: "+0.8%" },
    { ticker: "NOVN", value: "CHF 98.60", change1W: "+0.5%" },
    { ticker: "UBSG", value: "CHF 31.20", change1W: "-1.5%" },
    { ticker: "ABBN", value: "CHF 52.80", change1W: "+2.1%" },
    { ticker: "ZURN", value: "CHF 548.00", change1W: "+0.3%" },
  ],
  blueChipsLecture: "Les defensives dominent le SMI cette semaine, confirmant le regime de flight-to-safety. Nestle (+1.2%) beneficie de son statut de valeur refuge par excellence -- le titre est en hausse de +12% YTD apres deux annees de sous-performance. Roche (+0.8%) et Novartis (+0.5%) profitent de la rotation vers la pharma et des pipelines solides (Roche : Columvi pour le lymphome, Novartis : Kisqali pour le cancer du sein). ABB (+2.1%) est le meilleur performer du SMI grace a la demande structurelle pour l'electrification et les data centers -- le titre est a +18% YTD et reste le proxy suisse pour le theme de l'IA. Zurich Insurance (+0.3%) est stable, soutenu par des resultats solides et un dividende attractif (yield ~5%). UBS (-1.5%) est le grand perdant : les financieres souffrent du risk-off general, et les craintes de contagion du credit prive (collapse de Market Financial Solutions au UK) pesent sur le sentiment. Le ratio defensives/cycliques du SMI est au plus haut depuis mars 2023 -- un signal de prudence du marche.",

  topMovers: [
    { ticker: "SREN", value: "CHF 142.50", change1W: "+3.8%" },
    { ticker: "ABBN", value: "CHF 52.80", change1W: "+2.1%" },
    { ticker: "LONN", value: "CHF 580.00", change1W: "+1.5%" },
    { ticker: "NESN", value: "CHF 92.50", change1W: "+1.2%" },
  ],
  topMoversLecture: "Swiss Re (+3.8%) est le grand gagnant de la semaine apres l'annonce de son profit record de USD 3.2 milliards en 2025 et d'un dividende en hausse de 14% a CHF 7.35/action. Le combined ratio a 84.7% est excellent (en dessous de 100% = rentabilite technique). Le titre est a +15% YTD et reste attractif avec un P/E de 11x. ABB (+2.1%) continue sa trajectoire haussiere grace a la demande d'electrification et de data centers -- les commandes ont augmente de 12% au T4 2025. Lonza (+1.5%) beneficie de la rotation vers la pharma/biotech et de l'amelioration de ses marges apres la restructuration. Le titre reste 30% en dessous de ses sommets de 2021, offrant un potentiel de rattrapage. Nestle (+1.2%) confirme son retour en grace apres deux annees difficiles -- le nouveau CEO Laurent Freixe a redonne confiance aux investisseurs avec un plan de restructuration credible.",

  flopMovers: [
    { ticker: "CFR", value: "CHF 148.00", change1W: "-2.3%" },
    { ticker: "HOLN", value: "CHF 88.50", change1W: "-1.8%" },
    { ticker: "UBSG", value: "CHF 31.20", change1W: "-1.5%" },
    { ticker: "SGSN", value: "CHF 92.00", change1W: "-0.9%" },
  ],
  flopMoversLecture: "Richemont (-2.3%) est le plus mauvais performer du SMI, penalise par les inquietudes sur le luxe chinois (exportations horlogeres -3% YoY en janvier, Chine -8%) et les tensions geopolitiques qui pesent sur le sentiment des consommateurs de luxe. Le titre reste a +5% YTD grace au rallye de janvier, mais la tendance est fragile. Holcim (-1.8%) souffre de la stagnation du secteur de la construction en Europe -- le PIB europeen a +0.1% ne soutient pas la demande de materiaux. Le spin-off de l'activite nord-americaine prevu en 2026 reste un catalyseur potentiel. UBS (-1.5%) est sous pression sur les financieres en mode risk-off -- le collapse de Market Financial Solutions au UK ravive les craintes de contagion du credit prive. SGS (-0.9%) recule legerement sur la faiblesse du commerce mondial et les tarifs US qui reduisent les volumes d'inspection.",

  economy: {
    gdp: "+0.1% QoQ (T4 2025) -- en dessous du consensus de +0.2%. Croissance annuelle 2025 : +0.9% (vs +1.3% en 2024).",
    unemployment: "2.8% (janvier 2026) -- stable, marche du travail resilient malgre la stagnation economique.",
    kof: "101.5 (fevrier 2026) -- legerement au-dessus de la moyenne long terme (100), signal de stabilisation.",
    highlights: [
      "PIB T4 2025 : +0.1% QoQ -- stagnation confirmee, en dessous du consensus de +0.2%. La croissance annuelle 2025 ressort a +0.9%, la plus faible depuis 2020 (hors COVID).",
      "BNS profit record : CHF 26.58 milliards en 2025 -- gains sur les devises etrangeres (+CHF 20.8 Mds) et l'or (+CHF 5.8 Mds). Les cantons et la Confederation recevront CHF 3 milliards de dividendes.",
      "Swiss Re : profit record USD 3.2 milliards en 2025 -- combined ratio a 84.7%, dividende +14% a CHF 7.35/action.",
      "Inflation : 0.3% YoY (janvier 2026) -- bien en dessous de la cible BNS de 0-2%. Risque de deflation si le CHF continue de se renforcer.",
      "Exportations horlogeres : -3% YoY en janvier 2026 -- la Chine et Hong Kong reculent de 8%. Les marques de luxe (Rolex, Patek Philippe) resistent mieux que les marques d'entree de gamme.",
      "Marche immobilier : les prix des appartements en propriete ont augmente de +2.1% en 2025, soutenus par les taux bas et la demande structurelle.",
    ],
    lectureWMB: "L'economie suisse presente un tableau contraste. D'un cote, le marche du travail reste resilient (chomage a 2.8%, quasi plein emploi) et le SMI atteint des records. De l'autre, la croissance est en stagnation (+0.1% T4), l'inflation est dangereusement basse (0.3%), et les exportations horlogeres reculent. La BNS est dans un dilemme classique : stimuler la croissance (baisse de taux) risque de gonfler les prix immobiliers deja eleves, tandis que ne rien faire risque de laisser le CHF se renforcer davantage et d'aggraver la stagnation. Le profit record de la BNS (CHF 26.58 Mds) est une bonne nouvelle pour les finances publiques (CHF 3 Mds de dividendes aux cantons) mais masque la fragilite de l'economie reelle. Le KOF a 101.5 suggere une stabilisation au T1 2026, mais les risques sont orientes a la baisse (tarifs US, CHF fort, ralentissement chinois). Pour un investisseur suisse : les defensives du SMI (Nestle, Roche, Novartis) offrent une protection naturelle, mais l'exposition aux cycliques et aux exportateurs doit etre geree avec prudence.",
  },

  scenarios: [
    { name: "Scenario A -- BNS Baisse a 0% + Desescalade Iran", probability: "20%", description: "La BNS surprend avec une baisse a 0% le 20 mars, accompagnee d'interventions sur le marche des changes. L'Iran ne riposte pas aux frappes. Le SMI continue sa hausse vers 14,500. L'EUR/CHF remonte vers 0.95. Les exportateurs (Swatch, Richemont, Holcim) rebondissent de 3-5%.", signal: "SMI > 14,200, EUR/CHF > 0.94, VIX < 18" },
    { name: "Scenario B -- Statu Quo BNS + Tensions Persistantes", probability: "45%", description: "La BNS maintient a 0.25% avec un signal dovish pour juin. Les tensions Iran persistent sans escalade majeure. Le SMI consolide autour de 14,000 (+/- 200 points). Le CHF reste fort mais stable. Les defensives continuent de surperformer.", signal: "SMI 13,800-14,200, EUR/CHF 0.93-0.94, VIX 18-22" },
    { name: "Scenario C -- CHF Trop Fort + Recession Technique", probability: "25%", description: "L'EUR/CHF passe sous 0.92 sur l'escalade Iran. Les exportateurs suisses souffrent massivement. Le PIB T1 2026 est negatif, confirmant une recession technique. La BNS est forcee d'intervenir massivement sur le marche des changes. Le SMI corrige de 3-5%.", signal: "SMI < 13,500, EUR/CHF < 0.92, exportateurs -5-10%" },
    { name: "Scenario D -- Choc Petrolier + Stagflation", probability: "10%", description: "Escalade majeure Iran, petrole > 100 USD. L'inflation remonte en Suisse via les couts energetiques. La BNS est piegee entre inflation et CHF fort -- impossible de baisser les taux. Le SMI corrige de 5-8%, les cycliques sont les plus touches.", signal: "Petrole > 100 USD, SMI < 13,200, inflation suisse > 1%" },
  ],
  risks: [
    { title: "Risque 1 -- CHF trop fort (EUR/CHF < 0.92)", description: "Si l'EUR/CHF passe sous 0.92, les exportateurs suisses seront severement penalises. Swatch, Richemont, Holcim et les PME exportatrices verraient leurs marges comprimees. La BNS pourrait etre forcee d'intervenir massivement sur le marche des changes (achats d'euros), comme elle l'a fait entre 2011 et 2015. Le seuil de 0.90 serait un point critique." },
    { title: "Risque 2 -- Recession technique (2 trimestres negatifs)", description: "Le PIB a +0.1% au T4 2025 est a la limite. Si le T1 2026 est negatif (possible avec le CHF fort et les tarifs US), la Suisse entrerait en recession technique pour la premiere fois depuis 2020. Impact : BNS forcee de baisser a 0%, sentiment des consommateurs en baisse, immobilier sous pression." },
    { title: "Risque 3 -- Effondrement du luxe chinois", description: "Richemont et Swatch dependent fortement de la Chine (25-30% du chiffre d'affaires). Les exportations horlogeres vers la Chine sont deja en baisse de 8% YoY. Si la reprise chinoise decooit (PIB chinois < 4.5%), ces titres pourraient corriger de 10-15%. Richemont est le plus expose." },
    { title: "Risque 4 -- Retour aux taux negatifs", description: "Si la BNS revient aux taux negatifs (sous 0%), les banques suisses seraient les premieres penalisees -- UBS verrait ses marges d'interet comprimees. Les fonds de pension suisses, deja sous pression avec des taux bas, seraient encore plus en difficulte. Le marche immobilier pourrait surchauffer davantage." },
  ],

  sources: "Swissinfo, Swissquote, BNS (rapport annuel 2025), SECO, KOF, Investing.com, Reuters, SIX Swiss Exchange, Federation de l'industrie horlogere suisse. Donnees de cloture vendredi 28 fevrier 2026.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente d'actifs financiers, un conseil en investissement, ou une promesse de performance. Les marches financiers sont par nature imprevisibles. Les performances passees ne prejugent pas des performances futures.",
};
