/**
 * WMB Monde — Semaine 14 (LUN 24/03 → VEN 28/03 2026)
 * Données vérifiées : MarketWatch, Reuters, CNBC, MLQ, Lombard Odier, Trading Economics
 * Clôture vendredi 27 mars 2026
 */
import type { MondeModuleData } from "../monde";
export const MONDE_SEMAINE_14: MondeModuleData = {
  id: 107,
  weekNumber: 14,
  year: 2026,
  dateRange: "LUN 24/03 → VEN 28/03",
  title: "5eme Semaine de Baisse Mondiale, Petrole >$100, Nasdaq en Correction",
  subtitle: "MODULE MONDE",
  publishedAt: "2026-03-29T07:00:00Z",
  headerImage: "",
  executiveSummary: {
    weekPast: [
      "Cinquieme semaine consecutive de baisse pour les marches mondiaux. Le STOXX 600 perd environ 1,5%, le DAX -1,8%, le CAC 40 -1,6%. L'Europe est entrainee par le sell-off US et le petrole au-dessus de $110.",
      "L'Asie sous pression : le Nikkei recule d'environ 1,5%, le Hang Seng perd 2,3% sur les tensions commerciales US-Chine et le petrole cher.",
      "Le petrole WTI franchit $100 pour la premiere fois depuis 2022. Le Brent reste autour de $110. CNBC alerte : le Detroit d'Ormuz doit etre reouvert d'ici mi-avril.",
      "L'or rebondit de 2,55% vendredi a $4 521 apres la chute massive de -10,23% la semaine precedente. Dead cat bounce ou retournement ?",
      "Le Bitcoin chute a $66 031 (-3,99%) — completement correle aux actifs risques, le narratif 'digital gold' est invalide.",
    ],
    weekAhead: [
      "Calendrier macro charge : Powell lundi, NFP vendredi 3 avril, ISM Manufacturing mercredi, ISM Services vendredi.",
      "Earnings : Nike (NKE) mardi — test du consommateur americain et mondial.",
      "BCE : pas de reunion prevue mais surveillance des declarations des membres sur l'impact du petrole.",
      "Surveillance du petrole : deadline CNBC mi-avril pour Hormuz — chaque jour qui passe augmente le risque.",
    ],
    lectureWMB: "La semaine 14 confirme que le sell-off est mondial. Aucune region n'est epargnee — US, Europe, Asie, emergents, tous en baisse. Le petrole au-dessus de $100 est le denominateur commun : il alimente l'inflation partout, comprime les marges des entreprises, et paralyse les banques centrales. Le VIX a 31 aux US se traduit par un VSTOXX eleve en Europe et une volatilite accrue en Asie. La divergence entre importateurs et exportateurs de petrole s'accentue — les pays du Golfe et les producteurs de commodities surperforment tandis que l'Inde, le Japon et l'Europe souffrent.",
  },
  indicesEurope: [
    { name: "STOXX 600", value: "~564", change1W: "-1,50%" },
    { name: "DAX 40", value: "~21 980", change1W: "-1,80%" },
    { name: "CAC 40", value: "~7 540", change1W: "-1,60%" },
    { name: "FTSE 100", value: "~9 780", change1W: "-1,40%" },
    { name: "IBEX 35", value: "~16 520", change1W: "-1,15%" },
    { name: "FTSE MIB", value: "~42 000", change1W: "-1,95%" },
  ],
  indicesEuropeLecture: "L'Europe enchaine sa 5eme semaine de baisse. Le STOXX 600 perd environ 1,5%. Le DAX est le plus touche (-1,8%), penalise par les industriels et l'automobile — le petrole cher augmente les couts de production. Le CAC 40 recule de 1,6%, le luxe sous pression avec le ralentissement du consommateur mondial. Le FTSE 100 resiste mieux (-1,4%) grace a son exposition a l'energie — BP et Shell beneficient du petrole au-dessus de $110. Le FTSE MIB italien est le plus penalise (-1,95%) avec les banques sous pression. L'IBEX 35 espagnol reste le plus resilient (-1,15%).",
  indicesAsia: [
    { name: "Nikkei 225", value: "~35 700", change1W: "-1,50%" },
    { name: "Hang Seng", value: "~24 200", change1W: "-2,30%" },
    { name: "Shanghai Composite", value: "~4 020", change1W: "-0,80%" },
    { name: "KOSPI", value: "~2 500", change1W: "-1,60%" },
    { name: "ASX 200", value: "~7 810", change1W: "-0,90%" },
  ],
  indicesAsiaLecture: "L'Asie continue de souffrir. Le Hang Seng est le plus penalise (-2,3%) — les tensions commerciales US-Chine et le petrole cher pesent lourdement sur l'economie chinoise (importateur net). Le Nikkei perd 1,5%, le yen se renforce ce qui pese sur les exportateurs japonais. Le KOSPI coreen (-1,6%) reste sous pression avec le secteur des semiconducteurs. L'ASX 200 australien resiste mieux (-0,9%) grace au secteur minier et energetique. Le Shanghai Composite est le plus resilient (-0,8%) grace aux mesures de soutien de la PBOC.",
  emergingMarkets: {
    msciEM: { value: "~1 055", change1W: "-1,50%" },
    highlights: [
      "Inde (Nifty 50) en baisse de ~2,0% — le petrole au-dessus de $100 est devastateur pour l'economie indienne (3eme importateur mondial)",
      "Bresil (Ibovespa) stable — Petrobras et Vale beneficient des prix des commodities",
      "Turquie et pays du Golfe en hausse — les producteurs petroliers regionaux profitent de la crise",
      "Afrique du Sud (JSE) en baisse — le rand sous pression face au dollar fort",
    ],
    lectureWMB: "Les emergents souffrent avec le MSCI EM a environ -1,50%. Le dollar fort (DXY 100,20) et le petrole cher sont un double coup dur pour les importateurs. L'Inde est la plus exposee — le petrole au-dessus de $100 creuse le deficit commercial et alimente l'inflation domestique. Le Bresil resiste grace a Petrobras et aux exportations de commodities. La divergence au sein des emergents s'accentue entre importateurs et exportateurs de petrole — un theme qui pourrait durer des mois si le conflit Iran persiste.",
  },
  forex: [
    { pair: "DXY", value: "100,20", change1W: "+0,80%" },
    { pair: "EUR/USD", value: "1,0756", change1W: "-0,70%" },
    { pair: "EUR/CHF", value: "~0,948", change1W: "-0,15%" },
    { pair: "USD/JPY", value: "~149,50", change1W: "-0,50%" },
    { pair: "GBP/USD", value: "1,2920", change1W: "-0,40%" },
    { pair: "USD/CHF", value: "0,8814", change1W: "+0,20%" },
  ],
  forexLecture: "Le dollar se renforce significativement — DXY a 100,20, en hausse de 0,8% sur la semaine. Le mouvement est double : safe-haven demand (conflit Iran) et taux US eleves (10Y a 4,44%). L'EUR/USD recule a 1,0756 — l'euro souffre de l'exposition energetique europeenne. Le franc suisse reste fort (USD/CHF 0,8814) — valeur refuge par excellence. Le yen se renforce (USD/JPY ~149,50) sur la reduction du carry trade. La livre sterling recule a 1,2920 sur les craintes d'impact du petrole cher sur l'economie britannique.",
  commodities: [
    { name: "Or (XAU)", value: "4 521 $/oz", change1W: "+0,30%" },
    { name: "Argent (XAG)", value: "~31 $/oz", change1W: "+1,50%" },
    { name: "WTI", value: "101,18 $/b", change1W: "+7,09%" },
    { name: "Brent", value: "~110 $/b", change1W: "+3,50%" },
    { name: "Cuivre", value: "~3,85 $/lb", change1W: "-2,50%" },
  ],
  commoditiesLecture: "Le petrole domine tout. Le WTI franchit $100 pour la premiere fois depuis 2022 a $101,18 (+7,09%). Le Brent reste autour de $110. CNBC alerte que le Detroit d'Ormuz doit etre reouvert d'ici mi-avril — un ultimatum de fait. Le petrole a bondi de 40%+ depuis le debut du conflit Iran. L'or rebondit legerement (+0,30% sur la semaine) apres la chute massive de -10,23% la semaine precedente. Le rebond de vendredi (+2,55%) pourrait etre un dead cat bounce ou un vrai retournement — a surveiller. Le cuivre recule a ~$3,85/lb sur les craintes de ralentissement mondial.",
  crypto: [
    { name: "Bitcoin (BTC)", value: "66 031 $", change1W: "-3,99%" },
    { name: "Ethereum (ETH)", value: "~1 950 $", change1W: "-3,50%" },
    { name: "Solana (SOL)", value: "~122 $", change1W: "-4,70%" },
  ],
  cryptoLecture: "Le Bitcoin chute a $66 031 (-3,99%), bien en dessous des $70 000. Le narratif 'digital gold' est completement invalide — le BTC chute en meme temps que les actions et ne joue aucun role de valeur refuge. Ethereum sous-performe a ~$1 950. Solana chute de 4,7%. Le marche crypto est pleinement correle aux actifs risques dans cet environnement de stress geopolitique et monetaire.",
  centralBanks: [
    { name: "Fed (FOMC)", rate: "3,50-3,75%", lastDecision: "Statu quo 19 mars", nextMeeting: "Fin avril 2026" },
    { name: "BCE", rate: "2,50%", lastDecision: "Statu quo mars", nextMeeting: "17 avril 2026" },
    { name: "BoJ", rate: "0,50%", lastDecision: "Statu quo mars", nextMeeting: "Avril 2026" },
    { name: "BNS", rate: "0,00%", lastDecision: "Statu quo 20 mars", nextMeeting: "Juin 2026" },
    { name: "PBOC", rate: "3,10% (LPR 1Y)", lastDecision: "Statu quo mars", nextMeeting: "Avril 2026" },
    { name: "BoE", rate: "4,50%", lastDecision: "Statu quo mars", nextMeeting: "Mai 2026" },
  ],
  centralBanksLecture: "Toutes les grandes banques centrales restent en mode pause. Le petrole au-dessus de $100 cree un dilemme universel : l'inflation energetique pousse vers le haut, le ralentissement economique pousse vers le bas. La Fed est la plus exposee — Powell parle lundi et le marche cherchera tout signal. La BCE surveille l'impact du petrole sur l'inflation en zone euro. La BoJ fait face a un yen qui se renforce (carry trade en reduction). La BNS a 0% n'a plus aucune marge — le franc fort reste un probleme structurel. La PBOC pourrait assouplir davantage si le ralentissement chinois s'accentue.",
  geopolitics: [
    { title: "Iran — Conflit en cours (5eme semaine)", description: "Le conflit US/Israel-Iran entre dans sa 5eme semaine. Le petrole WTI franchit $100. CNBC rapporte que le Detroit d'Ormuz doit etre reouvert d'ici mi-avril ou les disruptions s'aggraveront significativement. Les volumes de trading restent au plus haut de 2026." },
    { title: "Commerce US-Chine — Tensions persistantes", description: "Les tarifs sur les exportations tech chinoises restent en place. Le Hang Seng perd 2,3% sur la semaine. Apple et NVIDIA restent exposes aux perturbations de la supply chain." },
    { title: "Transition Fed — Warsh en mai", description: "Kevin Warsh se prepare a prendre la presidence de la Fed en mai 2026. Le marche anticipe un ton plus hawkish. Les taux longs montent en anticipation (10Y a 4,44%)." },
    { title: "Europe — Dependance energetique", description: "L'Europe reste vulnerabl au petrole cher. Le DAX et le CAC 40 souffrent. Les gouvernements europeens discutent de mesures d'urgence pour le consommateur." },
  ],
  geopoliticsLecture: "Le risque geopolitique reste au niveau maximum. Le conflit Iran entre dans sa 5eme semaine — la plus longue crise petroliere depuis 2019. Le franchissement de $100 par le WTI est un seuil psychologique majeur. La deadline CNBC de mi-avril pour Hormuz ajoute une urgence temporelle. Les tensions commerciales US-Chine restent en arriere-plan mais pourraient resurgir. La transition a la Fed ajoute une couche d'incertitude. L'Europe est prise en etau entre la dependance energetique et le ralentissement economique.",
  scenarios: [
    { name: "Constructif", probability: "10%", description: "Desescalade Iran, petrole sous $90, banques centrales dovish — rallye de soulagement mondial de 5-8%.", signal: "VIX sous 22, petrole sous 90$, DXY sous 98" },
    { name: "Base", probability: "45%", description: "Statu quo geopolitique, petrole $95-110, consolidation des marches — volatilite elevee, rotation vers l'energie.", signal: "VIX 25-32, petrole 95-110$" },
    { name: "Negatif", probability: "45%", description: "Escalade Iran (Hormuz), petrole au-dessus de $120, stagflation mondiale — sell-off de 10%+, credit se tend.", signal: "VIX >35, petrole >120$, 10Y >4,60%" },
  ],
  risks: [
    { title: "Escalade Iran = Petrole >$120", description: "Si le Detroit d'Ormuz est directement menace ou bloque, le petrole pourrait depasser $120-130. Impact devastateur sur l'inflation mondiale et les marges des entreprises." },
    { title: "Stagflation mondiale", description: "L'inflation energetique combinee au ralentissement economique cree un scenario de stagflation dans toutes les grandes economies. Les banques centrales sont paralysees." },
    { title: "Refinancement dette US = Risque systemique", description: "$10 trillions de dette US a refinancer dans un contexte de taux eleves et de demande faiblissante. Risque de crise de confiance obligataire." },
    { title: "Concentration Mag 7 = Risque de contagion", description: "Les Mag 7 representent 30-35% du S&P 500 et 40-45% du Nasdaq. Leur chute simultanee (-$850B en une semaine) amplifie la baisse des indices mondiaux." },
  ],
  pdfUrl: "",
  sources: "Donnees de marche : AIMS FX, MLQ.ai, CNBC, MarketWatch, Reuters, cloture vendredi 27 mars 2026. Banques centrales : Fed, BCE, BoJ, BNS, BoE, PBOC. Geopolitique : Reuters, CNBC. Commodities : CME Group, CNBC. Crypto : CoinDesk. Europe : Lombard Odier, Trading Economics.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
};
