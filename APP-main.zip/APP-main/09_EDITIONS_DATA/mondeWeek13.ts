/**
 * WMB Monde — Semaine 13 (LUN 17/03 → VEN 21/03 2026)
 * Données vérifiées : MarketWatch, Reuters, Morningstar, AA, Chase/J.P. Morgan
 */
import type { MondeModuleData } from "../monde";
export const MONDE_SEMAINE_13: MondeModuleData = {
  id: 106,
  weekNumber: 13,
  year: 2026,
  dateRange: "LUN 17/03 → VEN 21/03",
  title: "Sell-Off Global : 4eme Semaine de Baisse, Or en Chute Libre, Petrole au-dessus de $110",
  subtitle: "MODULE MONDE",
  publishedAt: "2026-03-22T08:00:00Z",
  headerImage: "",
  executiveSummary: {
    weekPast: [
      "Quatrieme semaine consecutive de baisse pour les marches mondiaux. Le STOXX 600 perd 1,78%, le DAX -2,01%, le CAC 40 -1,82%. L'Europe ne resiste plus — la divergence avec les US se reduit.",
      "L'Asie reste sous pression : Nikkei en baisse, Hang Seng penalise par les tensions commerciales US-Chine et le petrole cher.",
      "L'or s'effondre de 10,23% sur la semaine a $4 507 — pire semaine depuis des annees. La hausse des taux US et le dollar fort ont provoque un decrochage massif.",
      "Le petrole continue de monter : Brent $112,3 (+3,4%), WTI $98,1 (+2,6%). Le conflit Iran reste le catalyseur principal.",
      "Le Bitcoin passe sous $70 000 a ~$69 907, perdant son statut de valeur refuge temporaire.",
    ],
    weekAhead: [
      "Calendrier macro leger : Construction Spending lundi, Initial Claims jeudi.",
      "Earnings : Chewy, Cintas, Paychex, Jefferies mercredi. Carnival vendredi — impact direct du conflit Iran sur les croisieres.",
      "Surveillance du petrole : toute escalade supplementaire au Moyen-Orient pourrait envoyer le Brent au-dessus de $120.",
      "Kevin Warsh se prepare a remplacer Powell a la Fed en mai — le marche anticipe un ton plus hawkish.",
    ],
    lectureWMB: "La semaine 13 marque un tournant. L'or, considere comme valeur refuge ultime, s'effondre de plus de 10% — un signal que les taux reels montent trop vite et que le dollar ecrase tout. Le petrole au-dessus de $110 alimente l'inflation et reduit les marges de manoeuvre des banques centrales. Le VIX a 26,78 confirme un regime de stress. Le marche est pris en etau entre inflation energetique et ralentissement economique — un scenario de stagflation qui se materialise progressivement.",
  },
  indicesEurope: [
    { name: "STOXX 600", value: "573,28", change1W: "-1,78%" },
    { name: "DAX 40", value: "22 380", change1W: "-2,01%" },
    { name: "CAC 40", value: "7 666", change1W: "-1,82%" },
    { name: "FTSE 100", value: "9 918", change1W: "-1,44%" },
    { name: "IBEX 35", value: "16 714", change1W: "-1,14%" },
    { name: "FTSE MIB", value: "42 841", change1W: "-1,97%" },
  ],
  indicesEuropeLecture: "L'Europe ne resiste plus. Le STOXX 600 perd 1,78% — la quatrieme semaine de baisse consecutive. Le DAX est le plus touche (-2,01%), penalise par les industriels et l'automobile qui souffrent du petrole cher. Le CAC 40 recule de 1,82%, le luxe et les banques sous pression. Le FTSE 100 resiste mieux (-1,44%) grace a son exposition a l'energie — BP et Shell beneficient du petrole au-dessus de $110. L'IBEX 35 espagnol est le plus resilient (-1,14%). La divergence Europe/US se reduit — les deux zones souffrent desormais du meme probleme : l'inflation energetique liee au conflit Iran.",
  indicesAsia: [
    { name: "Nikkei 225", value: "~36 200", change1W: "-1,60%" },
    { name: "Hang Seng", value: "~24 800", change1W: "-2,60%" },
    { name: "Shanghai Composite", value: "~4 050", change1W: "-1,10%" },
    { name: "KOSPI", value: "~2 540", change1W: "-1,55%" },
    { name: "ASX 200", value: "~7 880", change1W: "-0,90%" },
  ],
  indicesAsiaLecture: "L'Asie continue de souffrir. Le Hang Seng est le plus penalise (-2,60%) sur les craintes de tarifs supplementaires US et l'impact du petrole cher sur l'economie chinoise (importateur net). Le Nikkei perd 1,60%, le yen se renforce legerement ce qui pese sur les exportateurs. Le KOSPI coreen (-1,55%) reste sous pression avec le secteur semis. L'ASX 200 australien resiste mieux (-0,90%) grace au secteur minier et energetique qui beneficie des prix eleves des commodities.",
  emergingMarkets: {
    msciEM: { value: "~1 070", change1W: "-1,40%" },
    highlights: [
      "Inde (Nifty 50) en baisse de ~1,8% — le petrole au-dessus de $110 est devastateur pour l'economie indienne (3eme importateur mondial)",
      "Bresil (Ibovespa) stable a legerement positif — Petrobras et Vale beneficient des prix des commodities",
      "Turquie (BIST 100) en hausse — les producteurs petroliers regionaux profitent de la crise",
    ],
    lectureWMB: "Les emergents souffrent avec le MSCI EM a environ -1,40%. Le dollar fort (DXY 96,36) et le petrole cher sont un double coup dur. L'Inde est la plus exposee — le petrole au-dessus de $110 creuse le deficit commercial et alimente l'inflation domestique. Le Bresil resiste grace a Petrobras et aux exportations de commodities. La divergence au sein des emergents s'accentue entre importateurs et exportateurs de petrole.",
  },
  forex: [
    { pair: "DXY", value: "96,36", change1W: "+0,50%" },
    { pair: "EUR/USD", value: "1,1550", change1W: "+0,95%" },
    { pair: "EUR/CHF", value: "~0,910", change1W: "-0,10%" },
    { pair: "USD/JPY", value: "~147,50", change1W: "-0,75%" },
    { pair: "GBP/USD", value: "1,296", change1W: "-0,50%" },
    { pair: "USD/CHF", value: "0,788", change1W: "-0,30%" },
  ],
  forexLecture: "Le marche des changes reflete la confusion ambiante. Le DXY a 96,36 reste relativement bas historiquement malgre une hausse de 0,5% sur la semaine. L'EUR/USD a 1,1550 reste eleve — l'euro beneficie des flux sortant des US malgre l'exposition energetique europeenne. Le franc suisse reste fort (USD/CHF 0,788) — valeur refuge par excellence dans cet environnement. Le yen se renforce legerement (USD/JPY ~147,50) sur la reduction du carry trade, signal classique de risk-off. La livre sterling recule a 1,296 sur les craintes d'impact du petrole cher sur l'economie britannique.",
  commodities: [
    { name: "Or (XAU)", value: "4 507 $/oz", change1W: "-10,23%" },
    { name: "Argent (XAG)", value: "~30 $/oz", change1W: "-8,00%" },
    { name: "WTI", value: "98,10 $/b", change1W: "+2,60%" },
    { name: "Brent", value: "112,30 $/b", change1W: "+3,40%" },
    { name: "Cuivre", value: "~3,95 $/lb", change1W: "-3,60%" },
  ],
  commoditiesLecture: "Le fait marquant de la semaine est l'effondrement de l'or : -10,23% a $4 507. C'est la pire semaine pour le metal jaune depuis des annees. La hausse des taux reels US (10Y a 4,39%) et les appels de marge sur les positions leveragees ont provoque un decrochage en cascade. Le petrole continue de monter — Brent $112,30 (+3,4%), WTI $98,10 (+2,6%) — le conflit Iran et les perturbations du Detroit d'Ormuz maintiennent la pression. Le cuivre recule a ~$3,95/lb sur les craintes de ralentissement mondial. L'argent suit l'or en baisse (-8%).",
  crypto: [
    { name: "Bitcoin (BTC)", value: "69 907 $", change1W: "-1,44%" },
    { name: "Ethereum (ETH)", value: "2 134 $", change1W: "-2,10%" },
    { name: "Solana (SOL)", value: "~128 $", change1W: "-5,20%" },
  ],
  cryptoLecture: "Le Bitcoin passe sous les $70 000 pour la premiere fois depuis fevrier. Le pattern est dangereux — similaire a la chute de novembre-janvier ($90K vers $60K). Ethereum sous-performe a $2 134. Solana chute de 5,2%. Le narratif 'digital gold' est mis a mal par la chute simultanee de l'or et du BTC. Le marche crypto est correle aux actifs risques dans cet environnement de stress.",
  centralBanks: [
    { name: "Fed (FOMC)", rate: "3,50-3,75%", lastDecision: "Statu quo 17-18 mars", nextMeeting: "Fin avril 2026" },
    { name: "BCE", rate: "2,50%", lastDecision: "Statu quo mars", nextMeeting: "17 avril 2026" },
    { name: "BoJ", rate: "0,50%", lastDecision: "Statu quo mars", nextMeeting: "Avril 2026" },
    { name: "BNS", rate: "0,00%", lastDecision: "Statu quo 20 mars", nextMeeting: "Juin 2026" },
    { name: "PBOC", rate: "3,10% (LPR 1Y)", lastDecision: "Statu quo mars", nextMeeting: "Avril 2026" },
    { name: "BoE", rate: "4,50%", lastDecision: "Statu quo mars", nextMeeting: "Mai 2026" },
  ],
  centralBanksLecture: "Toutes les grandes banques centrales ont maintenu leurs taux cette semaine — Fed, BCE, BoJ, BNS, BoE. Le message est unanime : le conflit Iran et le petrole cher creent trop d'incertitude pour agir. La Fed est dans la position la plus delicate — l'inflation energetique pousse vers le haut, le ralentissement economique pousse vers le bas. Le marche ne price plus qu'une seule baisse de 25 bps d'ici fin 2026, et 27% de probabilite d'une HAUSSE. Kevin Warsh, qui remplace Powell en mai, est percu comme plus hawkish. La BNS a 0% n'a plus aucune marge — le franc fort reste un probleme pour les exportateurs suisses.",
  geopolitics: [
    { title: "Iran — Conflit en cours (4eme semaine)", description: "Le conflit US/Israel-Iran entre dans sa 4eme semaine. Le petrole reste au-dessus de $110 (Brent). Les perturbations du Detroit d'Ormuz restent le risque principal. Aucune desescalade concrete malgre les rumeurs diplomatiques. Les volumes de trading sont au plus haut de 2026." },
    { title: "Commerce US-Chine — Tensions persistantes", description: "Les tensions commerciales restent elevees. Les tarifs sur les exportations tech chinoises pesent sur le Hang Seng et les semis. Apple et NVIDIA restent exposes." },
    { title: "Transition Fed — Warsh remplace Powell", description: "Kevin Warsh se prepare a prendre la presidence de la Fed en mai 2026. Le marche anticipe un ton plus hawkish. Les taux longs montent en anticipation (10Y a 4,39%)." },
  ],
  geopoliticsLecture: "Le risque geopolitique reste au niveau maximum. Le conflit Iran est le catalyseur dominant — il alimente le petrole, l'inflation, et paralyse les banques centrales. La transition a la Fed ajoute une couche d'incertitude supplementaire. Les tensions commerciales US-Chine restent en arriere-plan mais pourraient resurgir a tout moment. Le marche est dans un regime de 'risk-off persistant' — les volumes eleves confirment que les institutionnels se repositionnent.",
  scenarios: [
    { name: "Constructif", probability: "10%", description: "Cessez-le-feu Iran, petrole sous $90, Fed dovish en avril — rallye de soulagement mondial, or rebondit, VIX sous 18.", signal: "VIX sous 18, petrole sous 90$, DXY sous 95" },
    { name: "Base", probability: "45%", description: "Statu quo geopolitique, petrole $100-115, consolidation des marches — volatilite elevee, rotation vers l'energie et les defensives.", signal: "VIX 22-28, petrole 100-115$" },
    { name: "Negatif", probability: "45%", description: "Escalade Iran (Detroit d'Ormuz), petrole au-dessus de $130, stagflation confirmee — sell-off de 10%+, or rebondit, credit se tend.", signal: "VIX superieur a 30, petrole superieur a 130$, 10Y superieur a 4,60%" },
  ],
  risks: [
    { title: "Escalade Iran = Petrole au-dessus de $130", description: "Si le Detroit d'Ormuz est directement menace, le petrole pourrait depasser $130. Impact devastateur sur l'inflation mondiale et les marges des entreprises." },
    { title: "Stagflation = Piege pour les Banques Centrales", description: "L'inflation energetique combinee au ralentissement economique cree un scenario de stagflation. Les banques centrales ne peuvent ni baisser (inflation) ni monter (recession) les taux." },
    { title: "Chute de l'Or = Appels de Marge en Cascade", description: "La chute de 10% de l'or pourrait declencher des appels de marge supplementaires sur les positions leveragees, amplifiant le sell-off sur d'autres classes d'actifs." },
    { title: "Transition Fed = Incertitude Politique Monetaire", description: "Le remplacement de Powell par Warsh en mai cree une incertitude sur la direction de la politique monetaire US. Le marche pourrait surreagir a tout signal hawkish." },
  ],
  pdfUrl: "",
  sources: "Donnees de marche : MarketWatch, Reuters, Morningstar, AA, AP, cloture vendredi 21 mars 2026. Banques centrales : Fed, BCE, BoJ, BNS, BoE, PBOC. Geopolitique : Reuters, Chase/J.P. Morgan. Commodities : CME Group, Morningstar. Crypto : CoinDesk, Binance.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
};
