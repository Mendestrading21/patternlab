/**
 * WMB Brief — Semaine 11 (LUN 03/03 → VEN 07/03 2026)
 * Module USA — Pétrole, NFP et Stagflation : Trois Chocs en Une Semaine
 * Données vérifiées : Yahoo Finance Historical, CNBC, Investing.com, BLS
 * Clôture vendredi 6 mars 2026 + futures dimanche 8 mars
 */
import type { BriefData } from "../brief";

export const BRIEF_SEMAINE_11: BriefData = {
  id: 0,
  weekNumber: 11,
  year: 2026,
  dateRange: "LUN 03/03 → VEN 07/03",
  title: "Pétrole, NFP et Stagflation : Trois Chocs en Une Semaine",
  subtitle: "MODULE USA",
  publishedAt: "2026-03-09T08:00:00Z",
  headerImage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663135061541/Wf8Nj4yLBCzwrPQSdtP8cC/oil-surge-iran_e9cbd66b.jpg",

  executiveSummary: {
    weekPast: [
      "Le S&P 500 clôture a 6 740,02 vendredi, en recul de 2,0% sur la semaine. Le Dow Jones perd 3,0% (sa pire semaine depuis septembre 2024), tandis que le Nasdaq recule de 1,2%. La pression vendeuse a ete constante, alimentee par le choc petrolier et le NFP catastrophique.",
      "Le rapport emploi de fevrier a provoque un choc : -92 000 emplois non-agricoles, contre un consensus de +50 000. C'est le premier NFP negatif depuis decembre 2020, directement lie aux coupes federales DOGE et aux greves dans le secteur sante. Le taux de chomage remonte a 4,4%.",
      "Le petrole a connu sa plus forte hausse hebdomadaire depuis que les futures existent (1983) : le WTI bondit de 35% sur la semaine pour atteindre 103 dollars dimanche soir. Le conflit US-Iran (7eme jour), les menaces sur le Detroit d'Ormuz et la coupe de production du Koweit sont les catalyseurs directs.",
      "Le VIX cloture a 29,49 vendredi, son plus haut depuis octobre 2025. Les futures VIX dimanche soir atteignent 33,63 (+41%), signalant que le mode panique pourrait s'installer des lundi.",
      "Paradoxe notable : l'or recule de 6% sur la semaine malgre le contexte geopolitique, tandis que le dollar connait sa meilleure semaine depuis aout (DXY a 99,52). Le flight-to-safety se dirige vers le dollar et les Treasuries, pas vers l'or.",
    ],
    weekAhead: [
      "CPI fevrier mercredi 11 mars a 8h30 ET — c'est le rendez-vous de la semaine. Consensus : +2,4% YoY headline et core. Un chiffre au-dessus de 2,6% confirmerait le diagnostic de stagflation.",
      "PCE Price Index janvier vendredi 13 mars — retarde par le government shutdown, ce rapport sort enfin. C'est l'indicateur d'inflation prefere de la Fed.",
      "UMich Consumer Sentiment mars preliminaire vendredi — premier apercu de l'impact de la guerre Iran et de la hausse de l'essence (+12% en une semaine) sur le moral des menages.",
      "Les futures dimanche soir sont en forte baisse : VIX a 33,63, Nikkei -5,24%, DAX -2,48%. La semaine commence sous pression maximale avec le petrole au-dessus de 103 dollars.",
    ],
    lectureWMB: "La semaine qui vient de s'ecouler a cristallise un scenario que les marches redoutaient depuis des mois : la stagflation. D'un cote, l'emploi recule avec un NFP a -92 000, un chiffre qui a pris tout le monde a contre-pied. De l'autre, les pressions inflationnistes s'intensifient brutalement — le petrole bondit de 35% sur la semaine (record historique) et le WTI depasse 103 dollars dimanche soir. Paradoxalement, l'or recule de 6% — le flight-to-safety se dirige vers le dollar (meilleure semaine depuis aout, DXY a 99,52) et les Treasuries, pas vers les metaux precieux. La Fed se retrouve dans un etau classique : elle ne peut ni baisser les taux pour soutenir l'emploi (l'inflation accelere) ni les maintenir sans risquer de prolonger le ralentissement. Le VIX cloture a 29,49, aux portes du seuil de panique, et les futures dimanche soir atteignent 33,63. BlackRock limite les retraits sur un fonds de credit prive — un signal d'alarme precoce. Le CPI de mercredi sera le juge de paix. Mais la semaine commence deja sous haute tension : le Nikkei plonge de 5,24%, le DAX perd 2,48%, et Goldman Sachs rapporte que les hedge funds augmentent massivement leurs positions short.",
  },

  indices: [
    { ticker: "S&P 500", value: "6 740,02", change1W: "-2,0%", changeYTD: "+14,59%" },
    { ticker: "Nasdaq Composite", value: "22 387,68", change1W: "-1,2%", changeYTD: "+10,8%" },
    { ticker: "Dow Jones Ind.", value: "47 501,55", change1W: "-3,0%", changeYTD: "+4,2%" },
    { ticker: "Russell 2000", value: "2 525,30", change1W: "-2,3%", changeYTD: "+3,1%" },
  ],
  indicesSignal: "Signal baissier confirme. Le Dow Jones est le pire performer a -3,0% — sa pire semaine depuis septembre 2024. Le S&P 500 recule de 2,0% pour la troisieme semaine consecutive de baisse. Le Russell 2000 perd 2,3%, confirmant que les small caps sont sous pression. Seul le Nasdaq limite la casse a -1,2%, soutenu par un rebond partiel des semis en milieu de semaine.",
  indicesInvalidation: "Niveau d'invalidation : une cloture sous 6 500 points sur le S&P 500 confirmerait une correction de plus de 3,5% depuis les niveaux actuels et ouvrirait la voie vers 6 200.",
  indicesLecture: "La semaine a ete sans repit. Le Dow Jones a ete le plus touche a -3,0% (sa pire semaine depuis septembre 2024), plombe par ses composantes cycliques et financieres. Le S&P 500 a lache 2,0% pour tomber a 6 740, sa troisieme semaine consecutive de baisse — mais il reste en territoire positif YTD a +14,59%, ce qui montre que la correction est encore moderee par rapport aux gains accumules. Le Nasdaq a relativement mieux resiste a -1,2%, soutenu par le rebond de NVIDIA et Broadcom en milieu de semaine apres des resultats solides. Le Russell 2000 perd 2,3%, les small caps souffrant de la combinaison petrole cher et craintes de recession. Les futures dimanche soir amplifient la baisse : le Nikkei plonge de 5,24%, le DAX perd 2,48%. Si cette tendance se confirme lundi matin, le S&P pourrait ouvrir sous 6 600. Le support cle se situe a 6 500 — en dessous, la correction s'accelererait vers 6 200.",

  vix: {
    value: "29.49",
    regime: "Zone de stress extreme. Le VIX cloture a 29,49 vendredi, son plus haut depuis octobre 2025. Les futures dimanche soir atteignent 33,63 (+41,44%).",
    watch: "Au-dessus de 30, le mode panique s'installe historiquement pour 2 a 3 semaines. Les ventes forcees des fonds systematiques s'enclenchent. Sous 25, le marche respire. Les futures a 33,63 suggerent que le seuil de 30 sera franchi des lundi.",
    lectureWMB: "Le VIX a 29,49 en cloture — pas en intraday, en cloture — c'est le signal le plus clair de la semaine. Mais le vrai chiffre a surveiller, c'est le future VIX dimanche soir a 33,63 (+41,44%). Historiquement, quand le VIX franchit 30 en cloture, les ventes forcees des fonds systematiques s'enclenchent et la volatilite se nourrit d'elle-meme pendant 2 a 3 semaines. Goldman Sachs rapporte que les hedge funds augmentent massivement leurs positions short sur les actions US — un signal de conviction baissiere institutionnelle. Le ratio put/call est en hausse, confirmant que les institutionnels se couvrent massivement. Avec les futures en forte baisse dimanche soir et le petrole au-dessus de 103 dollars, le VIX devrait franchir 30 des lundi matin — ce qui declencherait un cycle de deleveraging. A contrario, un CPI dovish mercredi pourrait le ramener vers 22-24 et offrir un point d'entree pour les contrariants.",
  },

  fx: [
    { pair: "DXY", value: "99,52", note: "Dollar en forte hausse — meilleure semaine depuis aout, flight-to-safety vers le billet vert" },
    { pair: "EUR/USD", value: "1,1536", note: "Euro en baisse de 0,73% — le dollar attire les flux refuges" },
    { pair: "USD/CHF", value: "0,7800", note: "CHF en leger recul — le dollar domine meme face au franc suisse" },
    { pair: "GBP/USD", value: "1,3319", note: "Livre en baisse de 0,71% — faiblesse generalisee face au dollar" },
    { pair: "USD/JPY", value: "158,58", note: "Yen sous pression — carry trade et force du dollar" },
  ],
  fxAlert: "Niveau d'alerte : DXY au-dessus de 100 confirmerait un renforcement structurel du dollar lie au flight-to-safety.",
  fxInvalidation: "Niveau d'invalidation : DXY sous 98 invaliderait le scenario de force dollar et signalerait un retour du risk-on.",
  fxLecture: "Le dollar raconte une histoire qui merite attention. Le DXY grimpe a 99,52, sa meilleure semaine depuis aout, porte par un flight-to-safety massif vers le billet vert. C'est un changement de regime par rapport aux semaines precedentes ou le dollar faiblissait. L'EUR/USD recule a 1,1536 (-0,73%), le GBP/USD a 1,3319 (-0,71%) — toutes les devises majeures cedent face au dollar. Meme le franc suisse recule legerement avec l'USD/CHF a 0,7800 (+0,61%), bien que le CHF reste proche de ses plus hauts depuis 2015 contre l'euro (EUR/CHF a 0,8998). Le yen est le plus touche a 158,58, ecrase par le carry trade et la force du dollar. Pour les investisseurs suisses exposes aux actifs US, c'est un double tranchant : la hausse du dollar compense partiellement les pertes sur les indices. Le paradoxe du moment : le petrole monte (signal inflationniste) ET le dollar monte (signal de peur). Quand les deux montent ensemble, c'est que le marche est en mode panique pure.",

  rates: [
    { label: "Taux 10 ans US", value: "4,133%", note: "En legere baisse — les Treasuries beneficient du flight-to-safety malgre les craintes d'inflation" },
    { label: "Taux 5 ans US", value: "3,715%", note: "En baisse de 0,75% — la partie intermediaire de la courbe anticipe un ralentissement" },
    { label: "Courbe 2s10s", value: "+15 bps", note: "Pentification moderee — le marche price un ralentissement avec inflation persistante" },
  ],
  fedFunds: "4,25% – 4,50%",
  fedProba: "Statu quo en mars (18-19 mars) : 98% de probabilite. Prochaine baisse possible en juin-juillet. Environ 50 bps de cuts prices pour 2026.",
  ratesLecture: "Les taux racontent une histoire plus nuancee que les indices. Le 10 ans US recule legerement a 4,133%, beneficiant du flight-to-safety vers les Treasuries malgre les craintes d'inflation liees au petrole. C'est un signal que le marche obligataire, pour l'instant, prie davantage le ralentissement economique que l'inflation. Le 5 ans a 3,715% confirme cette lecture — la partie intermediaire de la courbe anticipe un ralentissement. Mais attention : le choc petrolier n'est pas encore dans les donnees d'inflation. Le CPI de mercredi reflete fevrier, pas mars. L'impact du petrole a 103 dollars apparaitra dans le CPI de mars et avril. La courbe 2s10s se pentifie moderement a +15 bps. Pour les detenteurs d'obligations, c'est un environnement mixte : le flight-to-safety soutient les prix a court terme, mais l'inflation petroliere menace a moyen terme.",

  credit: {
    spreadsIG: "Spreads IG en legere hausse a environ 105 bps — tension moderee mais tendance haussiere depuis trois semaines",
    spreadsHY: "Spreads HY a environ 360 bps — elargissement notable, le stress commence a se materialiser",
    sofr: "SOFR a 4,31% — stable, la liquidite interbancaire fonctionne normalement",
    alert: "Surveiller : spreads HY au-dessus de 400 bps serait le seuil de stress. L'episode BlackRock (limites de retraits sur fonds de credit prive) est un signal d'alarme precoce.",
    lectureWMB: "Le credit commence a montrer des signes de tension. Les spreads HY passent a 360 bps — pas encore en zone de stress (le seuil est a 400), mais la tendance est clairement haussiere. Le signal le plus preoccupant de la semaine vient de BlackRock, qui a impose des limites de retraits sur son fonds HPS Corporate Lending Fund — c'est la premiere fois que le plus gros gestionnaire d'actifs au monde prend une telle mesure sur ce vehicule. Quand BlackRock commence a fermer les vannes, c'est que quelque chose se passe sous la surface. Le SOFR reste stable a 4,31%, ce qui est rassurant pour le marche monetaire — mais les fissures dans le credit prive meritent une surveillance rapprochee. Si d'autres gestionnaires suivent, c'est un risque de contagion vers le credit public.",
  },

  commodities: [
    { name: "Or", symbol: "XAU", value: "5 102 $/oz", note: "En baisse de 6% sur la semaine — paradoxalement, le flight-to-safety va vers le dollar, pas vers l'or" },
    { name: "Argent", symbol: "XAG", value: "~30 $/oz", note: "En baisse egalement — les metaux precieux souffrent de la force du dollar" },
    { name: "WTI", symbol: "CL", value: "103,06 $/b (dim.)", note: "+35% sur la semaine — plus forte hausse depuis que les futures existent (1983)" },
    { name: "Brent", symbol: "BZ", value: "106,79 $/b (dim.)", note: "+15,21% dimanche — le Brent depasse 106 dollars" },
  ],
  commoditiesLecture: "Le petrole est le sujet dominant — et il vient de franchir un nouveau palier. Le WTI a bondi de 35% sur la semaine, la plus forte hausse depuis que les futures petroliers existent (1983). Dimanche soir, il se negocie a 103,06 dollars, le Brent a 106,79 dollars. Les catalyseurs sont multiples : la guerre US-Iran entre dans son 7eme jour, le Qatar menace un force majeure sur les exportations du Golfe, le Koweit coupe sa production. Chaque hausse de 10 dollars du petrole ajoute entre 0,2% et 0,4% a l'inflation US. L'or, en revanche, surprend a la baisse : -6% sur la semaine malgre le contexte geopolitique. L'explication : le dollar est le refuge numero un cette semaine (DXY +1,4%), et un dollar fort pese mecaniquement sur l'or libelle en dollars. C'est un signal que le marche fait confiance au dollar comme valeur refuge ultime — pour l'instant. Si le conflit s'enlise et que l'inflation se materialise dans les donnees, l'or pourrait reprendre son role de couverture.",

  crypto: [
    { name: "Bitcoin", symbol: "BTC", value: "67 766 $", note: "En legere hausse de 0,42% — 'Bitcoin beats risk assets' selon Bloomberg" },
    { name: "Ethereum", symbol: "ETH", value: "~2 000 $", note: "Stable — resilience relative face au sell-off actions" },
  ],
  cryptoLecture: "Le Bitcoin a 67 766 dollars (+0,42%) est la surprise de la semaine. Alors que les indices actions plongent et que le VIX explose, le BTC resiste et meme progresse legerement. Bloomberg titre 'Bitcoin Beats Risk Assets as Oil Surges on Iran War Concerns'. C'est un signal interessant : pour la premiere fois dans un choc geopolitique majeur, le Bitcoin se comporte davantage comme un actif refuge que comme un actif risque. Cela dit, une semaine ne fait pas une tendance. Le support critique reste a 63 000 dollars (moyenne mobile 200 jours). Le catalyseur pour un mouvement directionnel serait le CPI de mercredi : un chiffre dovish pourrait relancer le rally crypto via les anticipations de baisse de taux.",

  keyPoints: [
    { title: "NFP -92 000 — Premier Chiffre Negatif Depuis Decembre 2020", description: "Le rapport emploi de fevrier est un choc. La perte nette de 92 000 emplois est directement liee aux coupes federales DOGE et aux greves dans le secteur sante. Le taux de chomage remonte a 4,4%. Les salaires restent fermes a +3,8% YoY, creant un cocktail stagflationniste." },
    { title: "Petrole +35% — Record Historique Depuis 1983", description: "Le WTI a connu sa plus forte hausse hebdomadaire depuis que les futures existent. A 103 dollars dimanche soir, le choc petrolier est deja comparable a 2022. Le Qatar menace un force majeure, le Koweit coupe sa production. L'impact inflationniste sera massif dans les prochaines publications." },
    { title: "Or -6% Malgre la Guerre — Le Dollar est le Vrai Refuge", description: "Paradoxe de la semaine : l'or recule de 6% malgre le conflit US-Iran. Le DXY grimpe a 99,52, sa meilleure semaine depuis aout. Le dollar est le refuge numero un, pas l'or." },
    { title: "VIX a 29,49 — Futures a 33,63 Dimanche Soir", description: "Le VIX cloture aux portes de la panique. Les futures dimanche soir a 33,63 (+41%) signalent que le seuil de 30 sera franchi des lundi. Goldman rapporte que les hedge funds augmentent massivement leurs shorts." },
    { title: "BlackRock Limite les Retraits — Signal d'Alarme Credit", description: "BlackRock impose pour la premiere fois des limites de retraits sur son fonds HPS Corporate Lending Fund (-7% vendredi). Quand le plus gros gestionnaire d'actifs au monde ferme les vannes, c'est un signal precoce de stress dans le credit prive." },
  ],
  keyPointsLecture: "Cinq signaux convergent vers un meme diagnostic : stagflation en acceleration. L'emploi s'effondre (NFP -92 000), le petrole explose (+35%, record depuis 1983), le VIX est aux portes de la panique (futures a 33,63), BlackRock limite les retraits, et Goldman rapporte une montee massive des shorts institutionnels. Le seul element positif : le Bitcoin resiste (+0,42%) et le S&P 500 reste en territoire positif YTD (+14,59%), ce qui montre que la correction est encore moderee par rapport aux gains accumules. Mais la semaine 12 sera decisive : CPI mercredi, PCE vendredi, et les developpements en Iran donneront enfin une direction claire.",

  timeline: [
    { day: "Lundi", date: "09/03", events: ["Ouverture sous pression (futures en forte baisse, Nikkei -5,24%)", "Pas d'evenement macro majeur"] },
    { day: "Mardi", date: "10/03", events: ["NFIB Small Business Index (fevrier)", "Existing Home Sales (fevrier)", "Oracle (ORCL) — resultats apres cloture [!]"] },
    { day: "Mercredi", date: "11/03", events: ["CPI fevrier (8h30 ET) [!] — EVENEMENT CLE DE LA SEMAINE", "Core CPI fevrier (8h30 ET) [!]", "Federal Budget Balance (fevrier)"] },
    { day: "Jeudi", date: "12/03", events: ["Weekly Jobless Claims", "Building Permits + Housing Starts (fevrier)", "Trade Balance (janvier)", "Adobe (ADBE) — resultats apres cloture [!]"] },
    { day: "Vendredi", date: "13/03", events: ["PCE Price Index janvier (retarde) [!]", "Core PCE janvier [!]", "UMich Consumer Sentiment mars preliminaire [!]", "Durable Goods + JOLTS (retardes par shutdown)"] },
  ],

  macroContext: "L'economie americaine envoie des signaux contradictoires qui dessinent un tableau de stagflation. Le NFP de fevrier (-92 000) est le pire chiffre depuis decembre 2020. L'ISM Manufacturing reste en expansion a 52,4% mais les prix accelerent. L'ISM Services est solide a 56,1. Le petrole a 103 dollars est un choc exogene que personne ne controle. Le dollar a 99,52 et l'or en baisse de 6% montrent que le flight-to-safety va vers le billet vert.",
  macroExpectations: "Le CPI mercredi est l'indicateur le plus surveille de la semaine. Le consensus est a +2,4% YoY headline et core. Au-dessus de 2,6%, c'est la confirmation de la stagflation et un sell-off probable. En dessous de 2,2%, le marche pourrait connaitre un short squeeze violent car beaucoup de fonds sont positionnes a la baisse. Le PCE vendredi (retarde par le shutdown) donnera une deuxieme lecture de l'inflation. L'UMich Consumer Sentiment vendredi sera impacte par la hausse de l'essence (+12% en une semaine).",
  macroScenarios: [
    { label: "Constructif", description: "CPI inferieur ou egal a 2,2% YoY, desescalade Iran, Oracle solide — soulagement massif, short squeeze, rebond technique de 3 a 5% sur le S&P." },
    { label: "Neutre", description: "CPI entre 2,3% et 2,5% YoY, Iran contenu sans escalade — consolidation avec volatilite extreme, range 6 400-6 700 sur le S&P." },
    { label: "Negatif", description: "CPI au-dessus de 2,6% YoY, escalade Iran, petrole vers 120 dollars — confirmation stagflation, sell-off vers 6 200-6 400 sur le S&P." },
  ],
  macroCalendar: [
    { date: "Lun. 09/03", time: "—", indicator: "Pas d'evenement macro majeur", consensus: "—", previous: "—", sensitiveAssets: "Futures, petrole" },
    { date: "Mar. 10/03", time: "06:00 ET", indicator: "NFIB Small Business Index", consensus: "100.5", previous: "102.8", sensitiveAssets: "Small caps, Russell 2000" },
    { date: "Mer. 11/03", time: "08:30 ET", indicator: "CPI fevrier (headline)", consensus: "+2,4% YoY", previous: "3,0% YoY", sensitiveAssets: "TOUS — evenement majeur" },
    { date: "Mer. 11/03", time: "08:30 ET", indicator: "Core CPI fevrier", consensus: "+2,4% YoY", previous: "3,3% YoY", sensitiveAssets: "TOUS — evenement majeur" },
    { date: "Jeu. 12/03", time: "08:30 ET", indicator: "Jobless Claims", consensus: "225K", previous: "213K", sensitiveAssets: "USD, Taux 2Y" },
    { date: "Ven. 13/03", time: "08:30 ET", indicator: "PCE Price Index janvier (retarde)", consensus: "~2,5% YoY", previous: "2,6% YoY", sensitiveAssets: "TOUS — indicateur Fed prefere" },
    { date: "Ven. 13/03", time: "10:00 ET", indicator: "UMich Consumer Sentiment (mars prelim.)", consensus: "63.0", previous: "64.7", sensitiveAssets: "Consumer, USD" },
  ],
  macroLecture: "Le contexte macro est le plus tendu depuis le debut de l'annee. Le NFP a -92 000 a fait basculer le narratif de 'soft landing' vers 'recession possible'. Le petrole a 103 dollars (dimanche soir) transforme le 'possible' en 'probable' si la tendance se maintient. Mais les donnees sont contradictoires : l'ISM Manufacturing reste en expansion (52,4%), les services sont solides (56,1), et les jobless claims sont historiquement bas (213 000). C'est la definition meme de la stagflation : certains indicateurs pointent vers la recession, d'autres vers l'inflation. Le CPI de mercredi est la derniere donnee d'inflation avant le FOMC du 18-19 mars. Plusieurs rapports retardes par le government shutdown sortent enfin cette semaine (PCE, Durable Goods, JOLTS) — ce qui cree un embouteillage de donnees vendredi. La semaine 12 sera celle de la verite.",

  fedContext: "La Fed maintient ses taux a 4,25%-4,50% et entre en periode de blackout avant le FOMC du 18-19 mars. Le marche price 98% de probabilite de statu quo en mars. Le NFP catastrophique (-92 000) plaide pour une baisse de taux, mais le petrole au-dessus de 103 dollars plaide contre. La Fed est dans un piege stagflationniste classique.",
  fedLecture: "La Fed fait face a son pire dilemme depuis 2022. D'un cote, l'emploi s'effondre — un NFP a -92 000 justifierait une baisse de taux immediate. De l'autre, le petrole depasse 103 dollars — ce qui interdit toute baisse sous peine d'alimenter l'inflation. Le FOMC du 18-19 mars sera un non-evenement en termes de decision (statu quo quasi certain), mais le dot plot et les projections economiques seront scrutes a la loupe. Si la Fed revise a la hausse ses projections d'inflation ET a la baisse ses projections de croissance, ce sera la confirmation officielle du scenario stagflationniste. Le CPI de mercredi et le PCE de vendredi donneront a Powell ses dernieres donnees avant de monter au pupitre.",
  fedSpeakers: [
    { name: "Blackout Period", date: "Semaine complete", stance: "La Fed entre en periode de blackout avant le FOMC du 18-19 mars. Aucun discours officiel — le silence de la Fed laisse le marche seul face a ses doutes." },
  ],
  fedAlert: "Periode de blackout Fed — aucun discours. Le CPI de mercredi et le PCE de vendredi seront les dernieres donnees majeures d'inflation avant le FOMC du 18-19 mars.",

  sectors: [
    { name: "Energie", perf1W: 12.50 },
    { name: "Defense/Aerospatial", perf1W: 6.20 },
    { name: "Biens Conso. Base", perf1W: 1.15 },
    { name: "Utilities", perf1W: 0.87 },
    { name: "Sante", perf1W: 0.42 },
    { name: "Communication", perf1W: -1.45 },
    { name: "Immobilier", perf1W: -1.12 },
    { name: "Industriels", perf1W: -2.18 },
    { name: "Tech", perf1W: -1.85 },
    { name: "Financiers", perf1W: -3.87 },
    { name: "Materiaux", perf1W: -7.00 },
    { name: "Conso. Discretionnaire", perf1W: -4.50 },
  ],
  sectorsLecture: "La rotation sectorielle raconte toute l'histoire du marche en un coup d'oeil. L'energie domine largement a +12,50%, portee par la flambee du petrole (+35%) — Chevron, Exxon et les producteurs independants sont les grands gagnants, avec des upgrades de Citi. La defense/aerospatial suit a +6,20% (Northrop Grumman, Raytheon, Lockheed Martin). Derriere, les defensives tiennent le fort : Consumer Staples (+1,15%), Utilities (+0,87%) et Sante (+0,42%) confirment un flight-to-quality classique. A l'oppose, les materiaux sont le pire secteur a -7,00% (pire semaine depuis un an). La conso discretionnaire perd 4,50% — les airlines, les croisieres (Royal Caribbean -10%) et les homebuilders souffrent directement du petrole cher. Les financieres cedent 3,87%, plombees par BlackRock (-7%). La tech limite la casse a -1,85%, soutenue par le rebond des semis (NVIDIA, Broadcom, Marvell) en milieu de semaine.",
  sectorsScenarios: "Si le CPI est chaud : l'energie continue de monter, les defensives resistent, la tech et la conso discretionnaire prolongent leur baisse. Si le CPI est froid : rebond technique sur la tech et les financieres, l'energie consolide. Si desescalade Iran : les airlines et croisieres rebondissent de 5 a 10%, l'energie corrige.",

  stocksMarketMoving: [
    { ticker: "ORCL", company: "Oracle", date: "Mar. 10/03", timing: "Apres cloture", consensus: "BPA ~1,70$, revenus ~14,5 Mds$", watchFor: "Cloud revenue growth via OCI, carnet de commandes IA, guidance", risk: "Croissance cloud decevante vs AWS/Azure", sensitivity: "Forte sur le secteur cloud et IA enterprise" },
    { ticker: "ADBE", company: "Adobe", date: "Jeu. 12/03", timing: "Apres cloture", consensus: "BPA ~4,95$, revenus ~5,7 Mds$", watchFor: "Adoption Firefly (IA generative), ARR Creative Cloud", risk: "Cannibalisation par les outils IA gratuits", sensitivity: "Forte sur le secteur SaaS et IA creative" },
    { ticker: "DG", company: "Dollar General", date: "Jeu. 12/03", timing: "Avant ouverture", consensus: "BPA ~1,50$", watchFor: "Same-store sales, impact inflation sur le consommateur bas de gamme", risk: "Marges sous pression (petrole, transport)", sensitivity: "Moderee — barometre consommation defensive" },
  ],
  stocksLecture: "Oracle mardi soir est le titre le plus important de la semaine. Le marche veut savoir si la demande IA se traduit en revenus cloud reels via OCI. Apres une baisse significative YTD, les attentes sont basses — ce qui cree un potentiel de surprise positive. Adobe jeudi testera la monetisation de l'IA creative avec Firefly. Dollar General donnera le pouls du consommateur bas de gamme — un barometre crucial en periode de stagflation.",

  mag7: [
    { ticker: "NVDA", perfYTD: "-12,5%", catalyst: "Rebond en milieu de semaine sur annonce d'un nouveau processeur d'inference. Sensibilite directe aux resultats d'Oracle.", positive: false },
    { ticker: "AAPL", perfYTD: "-3,2%", catalyst: "Sous pression. L'Apple Event n'a pas suffi a relancer le titre.", positive: false },
    { ticker: "MSFT", perfYTD: "-9,8%", catalyst: "Azure sous pression concurrentielle. Les resultats d'Oracle testeront la dynamique cloud.", positive: false },
    { ticker: "AMZN", perfYTD: "-16,4%", catalyst: "Pire performer du groupe — AWS vs Oracle OCI, consommation en berne.", positive: false },
    { ticker: "GOOGL", perfYTD: "-8,1%", catalyst: "Sous pression sur les ad revenues. Sensibilite au CPI et Oracle.", positive: false },
    { ticker: "META", perfYTD: "+3,8%", catalyst: "Seul Mag 7 encore positif YTD — resilience portee par la monetisation IA.", positive: true },
    { ticker: "TSLA", perfYTD: "-14,7%", catalyst: "Le petrole cher devrait aider les EV en theorie, mais les tarifs pesent.", positive: false },
  ],
  mag7Lecture: "Les Magnificent 7 sont desormais tous negatifs YTD sauf META (+3,8%) — un changement de regime qu'il faut prendre au serieux. Pour la premiere fois depuis 2022, les sept geants ne portent plus le marche. Amazon est le pire performer a -16,4% YTD, suivi de Tesla (-14,7%) et NVIDIA (-12,5%). Le rebond de NVIDIA en milieu de semaine (annonce d'un nouveau processeur d'inference) et les resultats solides de Broadcom ont offert un repit temporaire au secteur semi. Oracle mardi sera un test indirect pour tout le groupe : si la demande IA cloud est forte, NVDA et MSFT pourraient rebondir. Si Oracle decoit, c'est tout le narratif IA qui sera remis en question.",

  themes: [
    { title: "Stagflation — Le Scenario Redoute Prend Forme", description: "La combinaison NFP -92 000 + petrole +35% + salaires +3,8% YoY est la definition textbook de la stagflation. C'est le pire scenario pour la Fed et les marches car il elimine toute marge de manoeuvre monetaire. Historiquement, les periodes de stagflation sont les plus destructrices pour les portefeuilles actions-obligations traditionnels." },
    { title: "Le Dollar Comme Refuge Numero Un", description: "Paradoxe de la semaine : l'or recule de 6% tandis que le dollar grimpe (DXY +1,4%, meilleure semaine depuis aout). Le flight-to-safety va vers le billet vert et les Treasuries, pas vers les metaux precieux. C'est un signal que le marche fait confiance a la solidite relative de l'economie US malgre le choc." },
    { title: "Petrole et Inflation — L'Impot Invisible", description: "Le petrole n'est pas qu'un chiffre — c'est un impot invisible sur chaque consommateur et chaque entreprise. Les prix de l'essence ont augmente de 12% en une semaine. Les airlines, croisieres et transport souffrent directement. Et chaque dollar de plus au baril se retrouve dans le CPI quelques semaines plus tard." },
  ],
  divergences: "Les strategistes sont profondement divises. Les bulls voient la correction comme une opportunite d'achat : le S&P est encore a +14,59% YTD, les fondamentaux IA sont intacts, l'emploi est un bruit temporaire. Les bears voient un changement de regime structurel : stagflation, fin du cycle tech, geopolitique incontrolable. Goldman rapporte que les hedge funds augmentent massivement leurs shorts — un signal de conviction baissiere institutionnelle. Le CPI de mercredi tranchera le debat — au moins a court terme.",
  surprises: "Surprise haussiere : CPI sous 2,2% + desescalade Iran — rallye de soulagement de 3 a 5%, short squeeze violent. Surprise baissiere : CPI au-dessus de 2,6% + escalade Iran + Oracle decoit — correction de 5 a 8% supplementaire, VIX au-dessus de 35.",

  voices: [
    { name: "CPI fevrier — Mercredi 11 mars", role: "Indicateur d'inflation", description: "Le chiffre le plus important de la semaine. Consensus : +2,4% YoY. C'est la derniere donnee d'inflation avant le FOMC du 18-19 mars. Wells Fargo previent que 'les progres sur la baisse de l'inflation stagnent'." },
    { name: "Larry Fink / BlackRock", role: "CEO BlackRock", description: "BlackRock a impose des limites de retraits sur son fonds HPS Corporate Lending Fund — une premiere. Le titre chute de 7% vendredi. Signal d'alarme pour le credit prive." },
    { name: "Goldman Sachs", role: "Banque d'investissement", description: "Rapporte que les hedge funds augmentent massivement leurs positions short sur les actions US. C'est un signal de conviction baissiere institutionnelle qui pese sur le sentiment." },
  ],

  policyContext: "Le conflit US-Iran entre dans son 7eme jour. Trump declare qu'il n'y aura 'pas de deal sans reddition inconditionnelle'. Le Qatar menace un force majeure sur les exportations du Golfe. Le Koweit coupe sa production petroliere. Le petrole a 103 dollars dimanche soir. Les tarifs douaniers de 10% sont en vigueur et commencent a se repercuter sur les prix.",
  policyCards: [
    { title: "Conflit US-Iran — 7eme Jour", description: "Le conflit s'intensifie. Trump refuse tout compromis ('pas de deal sans reddition inconditionnelle'). Le Qatar menace un force majeure. Le Koweit coupe sa production. Le petrole depasse 103 dollars. Le Detroit d'Ormuz (20% du petrole mondial) reste le risque principal." },
    { title: "Tarifs Trump — L'Inflation Silencieuse", description: "Les tarifs de 10% sont en vigueur. Les entreprises commencent a repercuter les hausses sur les consommateurs — c'est une inflation 'made in policy' qui s'ajoute au choc petrolier." },
    { title: "FOMC 18-19 mars — La Semaine d'Apres", description: "La reunion FOMC approche. Le CPI de mercredi et le PCE de vendredi seront les dernieres donnees avant la decision. Le dot plot sera plus important que la decision elle-meme." },
  ],
  policyScenarios: [
    { label: "Desescalade", description: "Accord ou cessez-le-feu Iran — le petrole retombe vers 80-85 dollars, rallye de soulagement, VIX sous 22." },
    { label: "Statu quo", description: "Conflit contenu sans escalade majeure — petrole entre 95 et 115 dollars, volatilite extreme." },
    { label: "Escalade", description: "Menace directe sur le Detroit d'Ormuz — petrole au-dessus de 130 dollars, VIX au-dessus de 40, correction majeure." },
  ],
  policyLecture: "Le risque geopolitique est le facteur dominant du marche. La guerre US-Iran entre dans son 7eme jour sans aucun signe de desescalade. Trump refuse tout compromis, le Qatar menace un force majeure sur les exportations du Golfe, le Koweit coupe sa production. Le petrole a 103 dollars dimanche soir pourrait atteindre 130-150 dollars si le Detroit d'Ormuz est menace — un scenario que le Qatar evoque explicitement. Les tarifs douaniers ajoutent une couche supplementaire de pression sur les prix. Et le FOMC du 18-19 mars sera le prochain test majeur. Le marche navigue entre trois risques simultanes — geopolitique, inflation et recession — et aucun n'est sous controle.",

  earnings: [
    { day: "Mardi", date: "10/03", timing: "Apres cloture", ticker: "ORCL", company: "Oracle", consensus: "BPA ~1,70$", watchFor: "Cloud revenue via OCI, carnet IA, guidance", risk: "Croissance cloud decevante vs AWS/Azure", highlight: true },
    { day: "Jeudi", date: "12/03", timing: "Avant ouverture", ticker: "DG", company: "Dollar General", consensus: "BPA ~1,50$", watchFor: "Same-store sales, impact inflation", risk: "Marges sous pression", highlight: false },
    { day: "Jeudi", date: "12/03", timing: "Apres cloture", ticker: "ADBE", company: "Adobe", consensus: "BPA ~4,95$", watchFor: "Firefly adoption, ARR Creative Cloud", risk: "Cannibalisation IA gratuite", highlight: true },
  ],
  earningsLecture: "Oracle mardi soir est l'evenement earnings de la semaine. Le marche veut savoir si la demande IA se traduit en dollars reels via OCI. Adobe jeudi testera la monetisation de l'IA creative. Dollar General donnera le pouls du consommateur bas de gamme — un barometre crucial en periode de stagflation.",

  scenarios: [
    { name: "Scenario Bull", probability: "~10%", description: "CPI inferieur ou egal a 2,2% YoY, desescalade Iran, Oracle solide. Short squeeze violent, rebond technique.", result: "S&P 500 +3 a 5%, VIX retombe sous 22", signal: "Petrole sous 90$, 10Y sous 4.00%, DXY sous 99" },
    { name: "Scenario Base", probability: "~40%", description: "CPI entre 2,3% et 2,5% YoY, Iran contenu sans escalade. Consolidation avec volatilite extreme.", result: "S&P 500 entre -2% et +1%, range 6 400-6 700", signal: "VIX entre 25 et 32, petrole 95-115$" },
    { name: "Scenario Bear", probability: "~50%", description: "CPI superieur a 2,6% YoY, escalade Iran, petrole vers 120$+. Confirmation stagflation, sell-off generalise.", result: "S&P 500 -4 a 8%, test du support 6 200", signal: "VIX superieur a 35, petrole superieur a 120$, 10Y superieur a 4.30%" },
  ],
  risks: [
    { title: "Risque 1 — Petrole au-dessus de 120$ = Recession", description: "Si le petrole se maintient au-dessus de 120 dollars, l'impact sur les marges des entreprises et le pouvoir d'achat des consommateurs sera devastateur. Historiquement, chaque choc petrolier majeur a ete suivi d'une recession dans les 6 a 12 mois." },
    { title: "Risque 2 — CPI Chaud = Confirmation Stagflation", description: "Un CPI au-dessus de 2,6% YoY confirmerait le scenario stagflationniste. La Fed serait piegee. Les marches perdraient le filet de securite du 'Fed put'." },
    { title: "Risque 3 — VIX au-dessus de 30 = Ventes Forcees", description: "Les futures VIX a 33,63 dimanche soir signalent que le seuil de 30 sera franchi des lundi. Les fonds systematiques declenchent des ventes automatiques. La volatilite se nourrit d'elle-meme pendant 2 a 3 semaines." },
    { title: "Risque 4 — Contagion Credit Prive", description: "L'episode BlackRock est un signal d'alarme. Si d'autres gestionnaires limitent les retraits, c'est un risque de contagion vers le credit public. Les spreads HY a 360 bps se rapprochent du seuil de stress a 400." },
  ],
  scenarioDisclaimer: "Les scenarios presentes sont des hypotheses educatives basees sur des donnees publiques. Ils ne constituent pas des previsions certaines ni des recommandations d'investissement.",
  scenariosLecture: "Le risque est nettement asymetrique vers le bas — 50% de probabilite bear contre seulement 10% bull. C'est un ratio 5:1 en faveur du risque baissier, le plus eleve depuis le debut de l'annee. Le petrole a 103 dollars dimanche soir, combine aux futures VIX a 33,63 et au Nikkei a -5,24%, suggere que la semaine commence sous haute pression. Le CPI de mercredi est le catalyseur binaire qui tranchera entre consolidation et panique. Dans un environnement stagflationniste, les actifs reels (commodities, petrole, TIPS) surperforment historiquement. Le dollar reste le refuge numero un. La semaine 12 sera celle de la verite : CPI mercredi, PCE vendredi, puis FOMC la semaine d'apres.",

  glossary: [
    { term: "Stagflation", definition: "Combinaison de stagnation economique et d'inflation elevee. Le pire scenario pour les banques centrales car les outils monetaires traditionnels sont inefficaces." },
    { term: "CPI", definition: "Consumer Price Index — indice des prix a la consommation. Mesure l'inflation du point de vue du consommateur." },
    { term: "PCE", definition: "Personal Consumption Expenditures — indicateur d'inflation prefere de la Fed, plus large que le CPI." },
    { term: "Fed Put", definition: "Croyance que la Fed interviendra pour soutenir les marches en cas de chute. Ce filet disparait quand l'inflation est elevee." },
    { term: "Dot Plot", definition: "Graphique montrant les projections de taux de chaque membre du FOMC. Publie trimestriellement." },
    { term: "Short Squeeze", definition: "Mouvement de hausse violent provoque par les vendeurs a decouvert qui rachetent leurs positions." },
    { term: "Flight-to-Safety", definition: "Mouvement de fuite vers les actifs refuges (dollar, Treasuries, CHF) en periode de stress." },
    { term: "Force Majeure", definition: "Clause juridique permettant a un producteur de suspendre ses livraisons en cas de circonstances exceptionnelles (guerre, catastrophe)." },
    { term: "DOGE", definition: "Department of Government Efficiency — initiative de reduction des depenses federales qui a contribue aux pertes d'emplois publics." },
    { term: "Detroit d'Ormuz", definition: "Passage maritime entre l'Iran et Oman par lequel transite environ 20% du petrole mondial. Sa fermeture provoquerait un choc petrolier majeur." },
  ],
  pdfUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663135061541/Wf8Nj4yLBCzwrPQSdtP8cC/brief-s11_54c008f0.pdf",
  sources: "Donnees de marche (indices, VIX, commodities, crypto) : Yahoo Finance Historical + Quote Pages, cloture vendredi 6 mars 2026. Futures dimanche : Yahoo Finance pre-market 8 mars 2026. Donnees macro (NFP, ISM) : Bureau of Labor Statistics (BLS), ISM. Geopolitique : Reuters, CNBC, WSJ, NPR. Anticipations Fed : CME FedWatch. Donnees internationales : Yahoo Finance, MarketScreener. Calendrier S12 : Kiplinger, S&P Global. Top movers : FinancialSense, CNBC, Bloomberg.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance. Les marches financiers sont par nature imprevisibles. L'environnement actuel de stagflation potentielle et de conflit geopolitique cree une incertitude exceptionnelle — toute decision d'investissement doit etre prise avec une prudence accrue et en consultant un professionnel agree.",
};
