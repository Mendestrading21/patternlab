import type { MondeModuleData } from "../monde";

export const MONDE_SEMAINE_10: MondeModuleData = {
  id: 101,
  weekNumber: 10,
  year: 2026,
  dateRange: "LUN 24/02 - VEN 28/02",
  title: "STOXX 600 Record, DAX +14.5% YTD, Frappes Iran -- Petrole en Spike",
  subtitle: "MODULE MONDE",
  publishedAt: "2026-03-01T08:00:00Z",

  executiveSummary: {
    weekPast: [
      "STOXX 600 : 559 -- nouveau record historique, +10.5% YTD. L'Europe surperforme les USA pour la premiere fois depuis 2017.",
      "DAX 40 : 22,551 (+0.8% semaine, +14.5% YTD) -- meilleure performance mondiale parmi les grands indices, portee par la defense et les industriels.",
      "Nikkei 225 : 37,155 (-2.9% semaine) -- sous pression sur les tarifs auto US (25%) et le yen fort a 149.5/USD.",
      "Hang Seng : 22,941 (-3.3% semaine) -- prise de profits apres un rallye de +20% YTD sur la tech chinoise.",
      "Or : 2,867 USD/oz -- nouveau record historique, +11% YTD. Achats massifs des banques centrales (Chine, Inde) et flux refuge sur Iran.",
      "Frappes US-Israel sur l'Iran (28 fevrier) -- petrole Brent +5% en after-hours. Risque d'escalade vers un conflit regional.",
    ],
    weekAhead: [
      "Decision BCE jeudi 6 mars -- le marche hesite entre statu quo et baisse de 25 bps a 2.50%. Impact direct sur EUR/USD et actions europeennes.",
      "NFP US vendredi 6 mars -- chiffre cle pour la trajectoire des taux Fed. Consensus : ~180K emplois.",
      "ISM Manufacturing US (lundi) et ISM Services (jeudi) -- indicateurs avances de l'activite economique.",
      "Reaction de l'Iran aux frappes -- la fenetre de reponse est de 48-72h. Escalade ou desescalade ? Impact direct sur petrole, or et VIX.",
      "Earnings non-US : Adecco (emploi europeen), Pernod Ricard (luxe/conso), Baloise (assurance CH), Straumann (medtech CH).",
      "Plan de defense europeen de 800 milliards EUR -- les details d'allocation pourraient etre annonces cette semaine.",
    ],
    lectureWMB: "La rotation mondiale hors tech US s'accelere et devient structurelle. Le STOXX 600 en record et le DAX a +14.5% YTD confirment que les flux institutionnels se dirigent massivement vers l'Europe -- c'est la premiere fois depuis 2017 que l'Europe surperforme les USA sur un debut d'annee. Les catalyseurs sont clairs : plan de defense de 800 Mds EUR, valorisations attractives (P/E 14x vs 22x pour le S&P 500), et rotation sectorielle vers les industriels et la defense. Le Nikkei est le grand perdant (-2.9%) sur les tarifs auto et le yen fort. Les frappes Iran ajoutent un risque geopolitique majeur -- le petrole et l'or sont les grands gagnants. La semaine a venir sera dominee par la decision BCE (jeudi) et le NFP US (vendredi). Pour un investisseur base en CHF, le CHF fort (EUR/CHF 0.9350, plus bas 10 ans) reduit la performance des actifs europeens en termes reels -- un facteur a prendre en compte dans l'allocation.",
  },

  indicesEurope: [
    { name: "STOXX 600", value: "559", change1W: "+0.2%" },
    { name: "DAX 40", value: "22,551", change1W: "+0.8%" },
    { name: "CAC 40", value: "8,111", change1W: "+0.7%" },
    { name: "FTSE 100", value: "8,809", change1W: "+1.0%" },
    { name: "IBEX 35", value: "13,250", change1W: "+0.5%" },
    { name: "MIB (Italie)", value: "38,400", change1W: "+0.3%" },
  ],
  indicesEuropeLecture: "L'Europe est la star incontestee de 2026. Le STOXX 600 atteint un nouveau record a 559, porte par la rotation mondiale hors tech US et des flux institutionnels massifs. Le DAX surperforme avec +14.5% YTD -- sa meilleure performance sur un debut d'annee depuis 2015 -- tire par les industriels (Siemens +22% YTD, SAP +18% YTD) et surtout la defense (Rheinmetall +45% YTD sur le plan de 800 Mds EUR). Le FTSE 100 (+1.0%) beneficie du petrole en hausse (BP, Shell representent 15% de l'indice) et des miniers. Le CAC 40 (+0.7%) est soutenu par la defense (Safran +28% YTD, Thales +35% YTD) et le rebond du luxe (LVMH +8% depuis les plus bas de janvier). L'IBEX 35 (+0.5%) profite des banques espagnoles (Santander, BBVA) qui beneficient des taux encore eleves. Le MIB italien (+0.3%) est en leger retrait, penalise par les spreads BTP-Bund qui se sont legerement ecartes. Le plan de defense europeen de 800 milliards EUR est un catalyseur structurel qui pourrait soutenir les indices europeens pendant plusieurs trimestres -- c'est un changement de paradigme pour le secteur de la defense en Europe.",

  indicesAsia: [
    { name: "Nikkei 225", value: "37,155", change1W: "-2.9%" },
    { name: "Hang Seng", value: "22,941", change1W: "-3.3%" },
    { name: "Shanghai Composite", value: "3,320", change1W: "-0.5%" },
    { name: "KOSPI", value: "2,532", change1W: "-1.2%" },
    { name: "ASX 200", value: "8,296", change1W: "-1.8%" },
  ],
  indicesAsiaLecture: "L'Asie est sous pression generalisee cette semaine, avec des dynamiques differentes selon les marches. Le Nikkei 225 (-2.9%) souffre d'un double choc : les tarifs auto US de 25% sur les importations (Toyota, Honda, Nissan representent ~15% de l'indice) et le yen fort a 149.5/USD qui penalise les exportateurs. La BoJ en mode resserrement (hausse a 0.50% en janvier) ajoute une pression supplementaire. Le Hang Seng (-3.3%) corrige apres un rallye spectaculaire de +20% YTD -- c'est une prise de profits classique sur la tech chinoise (Alibaba -5%, Tencent -4%, BYD -3%). Le Shanghai Composite (-0.5%) est relativement resilient grace au soutien du gouvernement chinois (stimulus fiscal cible). Le KOSPI (-1.2%) est penalise par Samsung (-3%) et les semi-conducteurs, dans un contexte de guerre commerciale US-Chine sur les puces. L'ASX 200 (-1.8%) recule sur les matieres premieres hors petrole (minerai de fer -2%, cuivre -0.5%). Point cle : la divergence Europe/Asie est la plus marquee depuis 2020 -- les flux se deplacent de l'Asie vers l'Europe.",

  emergingMarkets: {
    msciEM: { value: "1,095", change1W: "-1.5%" },
    highlights: [
      "MSCI EM : -1.5% semaine -- sous pression sur le dollar fort et les tensions Iran. L'indice reste a +3.2% YTD.",
      "Inde (Nifty 50) : 22,124 (-2.5%) -- correction technique apres un rallye de +8% en fevrier. Les fondamentaux restent solides (PIB +6.5%, demographie favorable).",
      "Bresil (Bovespa) : 122,800 (-1.8%) -- real sous pression face au dollar, taux Selic a 13.25%. La banque centrale bresilienne pourrait monter encore.",
      "Turquie : lira en baisse de -3% apres l'arrestation du maire d'Istanbul Ekrem Imamoglu. Crise politique majeure, les investisseurs fuient les actifs turcs.",
      "Mexique (IPC) : 52,400 (-1.0%) -- les tarifs US sur les importations mexicaines pesent sur le sentiment.",
    ],
    lectureWMB: "Les emergents souffrent du double choc : dollar fort (DXY a 107) et tensions Iran qui font monter la prime de risque. L'Inde corrige de -2.5% apres un rallye mais reste structurellement attractive -- c'est le marche emergent prefere des institutionnels grace a sa croissance du PIB (+6.5%) et sa demographie. Le Bresil est penalise par les taux eleves (Selic a 13.25%) et la faiblesse du real -- la banque centrale bresilienne est piegee entre inflation et croissance. La Turquie est un cas a part : l'arrestation du maire d'Istanbul cree une incertitude politique majeure qui fait fuir les capitaux etrangers. Le Mexique souffre des tarifs US. Pour un investisseur base en CHF, les emergents offrent du rendement mais avec un risque de change significatif -- le CHF fort amplifie les pertes en termes reels.",
  },

  forex: [
    { pair: "EUR/USD", value: "1.0380", change1W: "-0.56%" },
    { pair: "USD/JPY", value: "149.50", change1W: "+0.3%" },
    { pair: "GBP/USD", value: "1.2580", change1W: "-0.4%" },
    { pair: "EUR/CHF", value: "0.9350", change1W: "-1.80%" },
    { pair: "USD/CHF", value: "0.8950", change1W: "-0.95%" },
    { pair: "AUD/USD", value: "0.6250", change1W: "-1.2%" },
  ],
  forexLecture: "Le marche des changes est domine par deux themes : la force du dollar face aux devises europeennes et asiatiques, et la force du franc suisse en mode refuge. L'EUR/CHF a 0.9350 est au plus bas depuis 10 ans -- le franc suisse est le grand gagnant FX de la semaine, porte par les flux refuge (frappes Iran) et la stabilite economique suisse. L'USD/CHF a 0.8950 montre que le CHF se renforce meme face au dollar. Le yen se stabilise autour de 149.5 apres les commentaires de la BoJ sur une possible hausse a 0.75% -- si la BoJ confirme, le yen pourrait se renforcer a 145/USD, ce qui serait tres negatif pour le Nikkei. L'AUD recule de -1.2% sur la faiblesse des matieres premieres hors petrole et les craintes de ralentissement chinois. La decision BCE jeudi pourrait faire bouger l'EUR/USD de 1-2% selon le ton de Lagarde. Pour un investisseur suisse : le CHF fort reduit mecaniquement la valeur en CHF de tous les investissements en devises etrangeres -- un facteur structurel a prendre en compte dans l'allocation.",

  commodities: [
    { name: "Brent", value: "$74.04", change1W: "+5.0% (after-hours Iran)" },
    { name: "WTI", value: "$70.35", change1W: "+4.8% (after-hours Iran)" },
    { name: "Or", value: "$2,867", change1W: "+2.1% (record)" },
    { name: "Argent", value: "$31.50", change1W: "+1.8%" },
    { name: "Cuivre", value: "$9,450", change1W: "-0.5%" },
    { name: "Gaz Naturel (EU)", value: "EUR 38.50/MWh", change1W: "+3.2%" },
  ],
  commoditiesLecture: "Le petrole est LE sujet de la semaine a venir. Le Brent bondit de +5% en after-hours vendredi sur les frappes US-Israel en Iran. Si l'Iran riposte -- notamment par une fermeture du detroit d'Ormuz (par lequel transite 20% du petrole mondial) -- le Brent pourrait atteindre 90-100 USD, un niveau qui relancerait les craintes inflationnistes mondiales et compliquerait la tache de toutes les banques centrales. L'or atteint un nouveau record a 2,867 USD/oz (+11% YTD), porte par trois forces convergentes : les achats massifs des banques centrales (la Chine a achete 225 tonnes en 2025, l'Inde 100 tonnes), les flux refuge sur les tensions Iran, et le dollar relativement faible. L'argent suit a 31.50 USD (+1.8%), soutenu par la demande industrielle (panneaux solaires, electronique) en plus de son role refuge. Le cuivre recule legerement (-0.5%) sur les craintes de ralentissement chinois -- la Chine represente 55% de la demande mondiale de cuivre. Le gaz naturel europeen remonte de +3.2% a 38.50 EUR/MWh sur les tensions geopolitiques, mais reste loin des pics de 2022 (>300 EUR/MWh).",

  crypto: [
    { name: "Bitcoin", value: "$84,500", change1W: "-4.2%" },
    { name: "Ethereum", value: "$2,280", change1W: "-6.1%" },
    { name: "Solana", value: "$138", change1W: "-8.5%" },
  ],
  cryptoLecture: "Les cryptos sont en mode risk-off generalisee. Le Bitcoin recule de -4.2% a 84,500 USD, sous pression apres le hack massif de Bybit (1.5 milliard USD vole -- le plus gros hack crypto de l'histoire) et les tensions Iran. Le BTC ne joue toujours pas son role de 'or numerique' en periode de crise geopolitique -- l'or physique reste le refuge prefere des investisseurs institutionnels. L'Ethereum (-6.1%) sous-performe, penalise par la concurrence des Layer 2 et le manque de catalyseur haussier. Solana (-8.5%) est la plus touchee, victime de la rotation hors altcoins et des doutes sur la durabilite de son ecosysteme DeFi. Le support cle pour le BTC se situe a 78,000 USD (MM200). Un retour sous ce niveau ouvrirait la voie vers 70,000 USD. Le catalyseur pour un rebond serait une desescalade rapide du conflit Iran et un retour de l'appetit pour le risque.",

  centralBanks: [
    { name: "BCE", rate: "2.75%", lastDecision: "Baisse 25 bps (janvier 2026)", nextMeeting: "6 mars 2026" },
    { name: "BoJ", rate: "0.50%", lastDecision: "Hausse 25 bps (janvier 2026)", nextMeeting: "13-14 mars 2026" },
    { name: "BoE", rate: "4.50%", lastDecision: "Baisse 25 bps (fevrier 2026)", nextMeeting: "20 mars 2026" },
    { name: "BNS", rate: "0.25%", lastDecision: "Baisse 25 bps (decembre 2025)", nextMeeting: "20 mars 2026" },
    { name: "RBA", rate: "4.10%", lastDecision: "Baisse 25 bps (fevrier 2026)", nextMeeting: "1er avril 2026" },
  ],
  centralBanksLecture: "La BCE est le catalyseur principal de la semaine (decision jeudi 6 mars). Le marche est divise : 55% anticipent un statu quo a 2.75%, 45% une baisse de 25 bps a 2.50%. Les arguments pour une baisse sont la croissance faible en zone euro (PIB +0.1% T4 2025) et l'inflation en recul (2.4% en fevrier). Les arguments pour un statu quo sont le petrole en hausse (risque inflationniste) et les salaires encore dynamiques. Le ton de Lagarde en conference de presse sera determinant. La BoJ est en mode resserrement -- la hausse a 0.50% en janvier etait la premiere depuis 2007. Si la BoJ signale une hausse a 0.75% en mars, le yen pourrait se renforcer brutalement a 145/USD, ce qui serait un choc pour les exportateurs japonais et le carry trade mondial. La BoE a baisse en fevrier mais reste prudente avec une inflation encore a 3.0%. La BNS est dans une position delicate : le CHF trop fort penalise les exportateurs suisses, mais une baisse a 0% (taux negatifs ?) serait un signal extreme. La RBA a commence son cycle de baisse en fevrier -- l'Australie ralentit avec la Chine.",

  geopolitics: [
    { title: "Frappes US-Israel sur l'Iran", description: "Les frappes du 28 fevrier ciblent les installations nucleaires iraniennes. C'est l'evenement geopolitique le plus significatif depuis l'invasion de l'Ukraine en 2022. Le petrole bondit de +5% en after-hours. La fenetre de reponse iranienne est de 48-72h. Si l'Iran riposte (attaque sur les installations petrolieres du Golfe, fermeture du detroit d'Ormuz par lequel transite 20% du petrole mondial), le Brent pourrait atteindre 90-100 USD. Impact : energie en forte hausse, tech en baisse, or en hausse, VIX > 25. Les stocks de defense (Lockheed Martin, Raytheon, Rheinmetall, Safran) seraient les grands gagnants." },
    { title: "Tarifs auto US (25%)", description: "Les tarifs de 25% sur les importations automobiles penalisent directement le Japon (Toyota -4%, Honda -3%), la Coree (Hyundai -5%, Kia -4%) et l'Allemagne (BMW -2%, Mercedes -2%). Le Nikkei et le KOSPI sont sous pression. L'Allemagne est partiellement protegee par la production locale aux USA (BMW Spartanburg, Mercedes Tuscaloosa). Les constructeurs europeens avec une forte production US (Volkswagen, BMW) sont moins exposes que les japonais." },
    { title: "Plan de defense europeen (800 Mds EUR)", description: "L'UE annonce un plan de 800 milliards EUR pour la defense sur 5 ans -- c'est un changement de paradigme historique. Beneficiaires directs : Rheinmetall (Allemagne, +45% YTD), Safran et Thales (France, +28% et +35% YTD), BAE Systems (UK, +22% YTD), Leonardo (Italie, +30% YTD). Ce plan pourrait ajouter 0.3-0.5% de croissance au PIB europeen par an et creer un nouveau secteur de croissance structurelle en Europe." },
    { title: "Turquie -- arrestation du maire d'Istanbul", description: "L'arrestation d'Ekrem Imamoglu, principal opposant a Erdogan et maire d'Istanbul, cree une crise politique majeure. La lira turque chute de -3% en une semaine. Les investisseurs fuient les actifs turcs -- les ETF Turquie enregistrent des sorties record. Le risque est une deterioration de l'Etat de droit qui eloignerait durablement les investisseurs etrangers." },
  ],
  geopoliticsLecture: "Le risque geopolitique est au plus haut depuis le debut de l'annee, avec quatre foyers de tension simultanes. Les frappes Iran sont le catalyseur principal -- la reaction de Teheran dans les 48-72h determinera si le marche reste en mode risk-off ou se stabilise. Historiquement, les chocs geopolitiques sont absorbes en 2-4 semaines si le conflit reste contenu (precedent : assassinat de Soleimani en janvier 2020, marches en hausse 3 semaines apres). Les tarifs auto US sont un risque structurel pour le Japon et la Coree -- c'est un changement permanent, pas un choc temporaire. Le plan de defense europeen est le seul catalyseur positif : il transforme structurellement le secteur de la defense en Europe et pourrait soutenir les indices europeens pendant plusieurs trimestres. La crise turque est un risque localise mais illustre la fragilite des marches emergents face aux chocs politiques.",

  scenarios: [
    { name: "Scenario A -- Desescalade Iran + BCE Dovish", probability: "20%", description: "L'Iran ne riposte pas militairement (negociations diplomatiques via la Chine). La BCE baisse de 25 bps a 2.50% avec un ton accommodant. Le STOXX 600 continue sa hausse vers 570. Le petrole revient sous 70 USD. L'or consolide autour de 2,800 USD.", signal: "STOXX 600 > 565, Brent < 70, VIX < 18, EUR/USD > 1.05" },
    { name: "Scenario B -- Tensions Persistantes + Statu Quo BCE", probability: "40%", description: "L'Iran menace mais ne riposte pas militairement (rhetorique agressive sans action). La BCE maintient a 2.75% en citant le risque petrolier. Les marches consolident dans une fourchette etroite. Le petrole reste entre 72-78 USD. L'or se maintient au-dessus de 2,850 USD.", signal: "STOXX 600 550-560, Brent 72-78, VIX 18-22, EUR/USD 1.03-1.04" },
    { name: "Scenario C -- Escalade Moderee + Petrole > 85", probability: "25%", description: "L'Iran riposte de maniere limitee (attaque sur des bases US en Irak, tirs de missiles sur des cibles militaires). Le petrole monte a 85 USD. Les marches corrigent de 2-3%. Les defensives et l'energie surperforment. L'or depasse 2,900 USD.", signal: "STOXX 600 < 545, Brent > 85, Or > 2,900, VIX > 22" },
    { name: "Scenario D -- Escalade Majeure + Ormuz", probability: "15%", description: "L'Iran ferme le detroit d'Ormuz ou attaque des installations petrolieres saoudiennes. Petrole > 100 USD. Correction de 5-10% sur les marches mondiaux. Panique sur les marches obligataires. L'or depasse 3,000 USD. Le VIX depasse 30.", signal: "Brent > 100, VIX > 30, Or > 3,000, Nikkei < 35,000" },
  ],
  risks: [
    { title: "Risque 1 -- Escalade Iran vers un conflit regional", description: "Si l'Iran riposte aux frappes par une attaque sur les installations petrolieres du Golfe ou une fermeture du detroit d'Ormuz, le petrole pourrait bondir a 90-100 USD. Impact : energie en forte hausse, tout le reste en baisse. Le VIX pourrait depasser 25-30. Les marches emergents seraient les plus touches (importateurs nets de petrole). L'or et le CHF seraient les refuges privilegies." },
    { title: "Risque 2 -- Tarifs US sur l'Europe (auto + luxe)", description: "Trump pourrait annoncer des tarifs cibles sur l'automobile et le luxe europeen dans les semaines a venir. Impact potentiel : DAX -3-5%, CAC 40 -2-3%. Les secteurs les plus exposes sont l'automobile (BMW, Mercedes, VW), le luxe (LVMH, Hermes, Kering) et l'agroalimentaire (vins, fromages). Ce risque pourrait effacer une partie des gains YTD du STOXX 600." },
    { title: "Risque 3 -- Correction tech chinoise", description: "Le Hang Seng a gagne +20% YTD sur le rallye de la tech chinoise (Alibaba, Tencent, BYD). Une prise de profits massive pourrait entrainer une correction de 5-10% sur la tech chinoise. Le catalyseur serait une deception sur les resultats ou un durcissement reglementaire de Pekin." },
    { title: "Risque 4 -- Yen fort et demantelement du carry trade", description: "Si la BoJ signale une hausse a 0.75% en mars, le yen pourrait se renforcer brutalement a 145/USD. Impact : Nikkei -5%, carry trade mondial sous pression (les investisseurs qui empruntent en yen pour investir en actifs risques devraient deboucler leurs positions). Ce scenario rappelle le mini-krach d'aout 2024 cause par le demantelement du carry trade." },
  ],

  sources: "CNBC, Reuters, Bloomberg, LPL Research, Rubie Wealth, Yahoo Finance, ECB, BoJ, BoE, BNS, RBA, World Gold Council, OPEC. Donnees de cloture vendredi 28 fevrier 2026.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente d'actifs financiers, un conseil en investissement, ou une promesse de performance. Les marches financiers sont par nature imprevisibles. Les performances passees ne prejugent pas des performances futures.",
};
