/**
 * WMB Brief — Semaine 10 (LUN 02/03 → VEN 06/03 2026)
 * Module USA — Frappes Iran, Pétrole en Spike & NFP Décisif
 */
import type { BriefData } from "../brief";

export const BRIEF_SEMAINE_10: BriefData = {
  id: 0, // Overridden to 1 in brief.ts via BRIEF_S10 spread
  weekNumber: 10,
  year: 2026,
  dateRange: "LUN 02/03 → VEN 06/03",
  title: "Frappes Iran, Pétrole en Spike & NFP Décisif — Semaine à Haut Risque",
  subtitle: "MODULE USA",
  publishedAt: "2026-03-01T08:00:00Z",

  executiveSummary: {
    weekPast: [
      "S&P 500 -0,81% sur la semaine à 6 878 — Nasdaq -5,09% sur février, pire mois depuis mars 2025.",
      "PPI (inflation producteurs) +0,8% m/m — bien au-dessus des attentes, repousse les baisses de taux.",
      "NVIDIA -7,34% sur février — doutes IA persistants, Mag 7 en baisse de -6,87% YTD.",
      "Goldman Sachs -7% — contagion crédit UK (collapse Market Financial Solutions).",
      "Frappes US-Israel sur l'Iran (28 fév) — pétrole +5%, risque géopolitique majeur.",
    ],
    weekAhead: [
      "Réaction des marchés aux frappes Iran — Dow futures ouvrent dimanche soir.",
      "NFP (rapport emploi) vendredi 6 mars — chiffre clé pour la trajectoire des taux Fed.",
      "ISM Manufacturing (lundi) & ISM Services (jeudi) — indicateurs avancés.",
      "Earnings : Broadcom (AVGO), CrowdStrike (CRWD), Costco (COST), Marvell (MRVL).",
      "Berkshire Hathaway — 1er rapport sous Greg Abel (post-Buffett).",
    ],
    lectureWMB: "La semaine s'annonce comme l'une des plus volatiles de 2026. Les frappes US-Israel sur l'Iran changent la donne géopolitique : le pétrole pourrait atteindre $80-90/baril, ce qui relancerait les craintes inflationnistes au pire moment (PPI déjà chaud). Le NFP de vendredi sera déterminant : un marché de l'emploi trop fort repousserait les baisses de taux, un marché trop faible alimenterait les craintes de récession. Broadcom mercredi sera le test décisif pour le narratif IA après la déception NVIDIA. Prudence maximale — mais les corrections créent des opportunités pour les investisseurs patients.",
  },

  indices: [
    { ticker: "S&P 500", value: "6 878.88", change1W: "-0.81%", changeYTD: "+0.12%" },
    { ticker: "Nasdaq Composite", value: "22 668.21", change1W: "-1.23%", changeYTD: "-2.75%" },
    { ticker: "Dow Jones Ind.", value: "48 977.92", change1W: "-1.62%", changeYTD: "+1.58%" },
  ],
  indicesSignal: "Signal baissier — le Nasdaq perd plus de 5% sur février, sa pire performance mensuelle depuis mars 2025. Risque de gap down lundi sur les frappes Iran.",
  indicesInvalidation: "Niveau d'invalidation : clôture sous 6 700 pts sur le S&P 500.",
  indicesLecture: "Février se termine sur une note très négative. Le Nasdaq perd 5,09% sur le mois — sa pire performance mensuelle depuis mars 2025. Le software tech (ETF IGV) est en chute libre sur le mois. La largeur du marché se dégrade : les gains sont concentrés sur les défensives (Consumer Staples +2,59%, Utilities +2,53%) tandis que la tech (-2,15%) et les financières (-2,43%) reculent. Le S&P 500 reste quasi flat YTD (+0,12%) tandis que le Dow surperforme (+1,58% YTD). Le support clé se situe à 6 700 pts — en dessous, la correction pourrait s'accélérer vers 6 500. L'ouverture de lundi sera cruciale : les futures Dow ouvrent dimanche soir et donneront la première indication de la réaction aux frappes Iran.",

  vix: {
    value: "19.86",
    regime: "Volatilité élevée — en hausse depuis le début de l'année. Spike attendu lundi.",
    watch: "VIX a clôturé à 19,86 vendredi. Lundi pourrait voir un spike au-dessus de 25 sur les frappes Iran.",
    lectureWMB: "Le VIX a bondi d'un tiers depuis le début de l'année, reflétant l'accumulation de risques (inflation, IA, géopolitique). Le niveau actuel de ~20 est déjà élevé, mais les frappes Iran pourraient le propulser au-dessus de 25 lundi — un niveau qui signalerait un mode risk-off franc. Au-dessus de 30, ce serait la panique. Historiquement, les pics de VIX liés à des événements géopolitiques sont souvent de courte durée (1-2 semaines) si le conflit reste contenu.",
  },

  fx: [
    { pair: "DXY", value: "97.61", note: "Dollar en baisse — DXY sous 100 pour la première fois depuis 2022" },
    { pair: "EUR/USD", value: "1.182", note: "Euro fort — dollar faible sur les craintes de ralentissement US" },
    { pair: "USD/CHF", value: "0.77", note: "Franc suisse refuge — CHF très fort face au dollar" },
  ],
  fxAlert: "Niveau d'alerte : DXY < 96 (confirmerait un affaiblissement structurel du dollar)",
  fxInvalidation: "Niveau d'invalidation : DXY > 100 (retour au-dessus du seuil psychologique)",
  fxLecture: "Le dollar est sous pression structurelle avec le DXY à 97,61 — sous le seuil psychologique de 100 pour la première fois depuis 2022. Le franc suisse reste très fort à 0,77 CHF/USD, reflétant les flux refuge. L'EUR/USD à 1,182 montre la faiblesse relative du dollar face à l'euro. Les frappes Iran pourraient temporairement renforcer le dollar (flight-to-safety), mais la tendance de fond reste baissière. Pour les investisseurs suisses : le CHF fort réduit la valeur en CHF des investissements en USD — un facteur à prendre en compte dans l'allocation.",

  rates: [
    { label: "Taux 10 ans US", value: "3.96%", note: "Sous 4% pour la première fois depuis novembre — flight-to-safety" },
    { label: "Taux 2 ans US", value: "3.38%", note: "Plus bas depuis 2022 — anticipations de baisse Fed" },
    { label: "Courbe 2s10s", value: "+58 bps", note: "Pentification marquée — normalisation" },
  ],
  fedFunds: "3.50% – 3.75%",
  fedProba: "Statu quo en mars : ~96% de probabilité (CME FedWatch). Prochaine baisse possible en juin.",
  ratesLecture: "Le 10 ans US est passé sous 4% pour la première fois depuis novembre (3,96%), porté par le flight-to-safety. Le 2 ans est tombé à 3,38% — son plus bas depuis 2022 — reflétant les anticipations de baisse de taux. La courbe 2s10s s'est pentifiée à +58 bps, signe de normalisation. Les frappes Iran devraient accentuer la demande de Treasuries lundi. Paradoxe : si le pétrole spike durablement au-dessus de $80, l'inflation remonterait et les taux longs pourraient repartir à la hausse. Le NFP de vendredi sera déterminant : un chiffre fort (>200K) repousserait les baisses de taux, un chiffre faible (<150K) relancerait les espoirs de baisse en juin.",

  credit: {
    spreadsIG: "Spreads IG stables à ~95 bps — pas de stress systémique",
    spreadsHY: "Spreads HY à ~330 bps — légère tension post-crédit UK",
    sofr: "SOFR à 3.67% — liquidité abondante",
    alert: "Surveiller : contagion crédit UK (Market Financial Solutions collapse), ETF HYG, spreads HY > 400 bps",
    lectureWMB: "Le collapse de Market Financial Solutions au Royaume-Uni a créé des ondes de choc dans le secteur financier (Goldman Sachs -7%, banques régionales sous pression). Les spreads HY ont légèrement augmenté à 330 bps mais restent loin des niveaux de stress (>400 bps). Le risque principal serait une contagion du crédit privé : si d'autres prêteurs privés révèlent des problèmes, les spreads pourraient s'élargir rapidement. Le SOFR reste stable, ce qui indique que le marché monétaire fonctionne normalement.",
  },

  commodities: [
    { name: "Or", symbol: "XAU", value: "~5 200 $/oz", note: "Sommets historiques — safe-haven + Iran + dollar faible" },
    { name: "Argent", symbol: "XAG", value: "~89 $/oz", note: "Surperformance vs or — demande industrielle + refuge" },
    { name: "WTI", symbol: "CL", value: "~67.29 $", note: "Spike attendu post-Iran, potentiel $80-90" },
    { name: "Brent", symbol: "BZ", value: "~72.87 $", note: "Prime géopolitique massive — risque Hormuz" },
  ],
  commoditiesLecture: "L'or est à des sommets historiques au-dessus de 5 200 $/oz, porté par le dollar faible, les tensions géopolitiques et la demande des banques centrales. Le pétrole est LE sujet de la semaine à venir. Les frappes US-Israel sur l'Iran pourraient faire bondir le WTI de $67 vers $80-90 si le conflit s'intensifie. Si le Détroit d'Ormuz est menacé (20% du pétrole mondial y transite), le Brent pourrait atteindre $90-100. L'argent surperforme à ~89 $/oz, porté par la demande industrielle et refuge. Pour les investisseurs : l'énergie (XLE) et les défensives sont les secteurs à privilégier en cas d'escalade.",

  crypto: [
    { name: "Bitcoin", symbol: "BTC", value: "~65 000 $", note: "Sous pression — risk-off global, -23% depuis les sommets de janvier" },
    { name: "Ethereum", symbol: "ETH", value: "~1 850 $", note: "Sous-performance relative — rotation vers BTC" },
  ],
  cryptoLecture: "Le Bitcoin est sous pression à ~65 000 $, en baisse de 23% depuis les sommets de janvier (~84 000 $). Contrairement à l'or (sommets historiques), le BTC se comporte comme un actif risqué en période de crise géopolitique. Un retour sous 60 000 $ est possible si le VIX dépasse 25. Le support clé se situe à 58 000 $ (MM200). L'Ethereum sous-performe à ~1 850 $. Le catalyseur pour un rebond serait une désescalade rapide du conflit Iran.",

  keyPoints: [
    { title: "Frappes US-Israel sur l'Iran", description: "Événement géopolitique majeur du 28 février. Pétrole +5%, risque d'escalade vers un conflit régional. Deadline nucléaire 1-6 mars." },
    { title: "PPI Chaud — Inflation Persistante", description: "PPI +0,8% m/m (vs +0,3% attendu), PPI core +3,6% YoY. Repousse les baisses de taux Fed au-delà de juin." },
    { title: "Rotation Défensive Accélérée", description: "Consumer Staples +2,69%, Utilities +2,67% vs Tech -1,8%, Financials -2,24%. Flight-to-safety classique." },
    { title: "Crédit UK — Contagion Fears", description: "Collapse de Market Financial Solutions (UK). Goldman Sachs -7%, banques sous pression. Risque de contagion crédit privé." },
    { title: "NVIDIA Négatif YTD", description: "Le titre phare de l'IA passe en territoire négatif sur l'année. Doutes sur les valorisations IA et le capex." },
  ],
  keyPointsLecture: "Cinq forces convergentes créent un environnement de marché particulièrement complexe : (1) le choc géopolitique Iran qui fait monter le pétrole et la prime de risque, (2) l'inflation persistante qui repousse les baisses de taux, (3) la rotation défensive qui signale un changement de régime, (4) les tensions sur le crédit privé, et (5) les doutes sur le narratif IA. Cette combinaison est rare et justifie une prudence accrue. Historiquement, les marchés absorbent les chocs géopolitiques en 2-4 semaines si le conflit reste contenu.",

  timeline: [
    { day: "Lundi", date: "02/03", events: ["ISM Manufacturing PMI (15h00 ET)", "Réaction marchés aux frappes Iran", "Norwegian Cruise Line (NCLH)"] },
    { day: "Mardi", date: "03/03", events: ["Target (TGT) — avant ouverture", "Best Buy (BBY) — avant ouverture", "CrowdStrike (CRWD) — après clôture", "Apple Event annoncé"] },
    { day: "Mercredi", date: "04/03", events: ["ADP Employment Change", "Broadcom (AVGO) — après clôture [!]", "Okta (OKTA) — après clôture", "Brown-Forman (BF.B)"] },
    { day: "Jeudi", date: "05/03", events: ["ISM Services PMI", "Jobless Claims", "Costco (COST)", "Marvell Technology (MRVL)", "Caterpillar (CAT) — fireside chat CONEXPO"] },
    { day: "Vendredi", date: "06/03", events: ["Nonfarm Payrolls (NFP) [!]", "Unemployment Rate", "Deadline nucléaire Iran (1-6 mars)"] },
  ],

  macroContext: "L'économie US reste résiliente mais les signaux d'alerte se multiplient. Le PPI de janvier (+0,8% m/m) est le chiffre le plus chaud depuis des mois, signalant que l'inflation ne recule plus. Le Chicago PMI a bondi à 57,7 (expansion la plus rapide en 3,75 ans), ce qui est positif pour la croissance mais négatif pour l'inflation. Le marché du travail reste solide mais montre des signes de normalisation. Le choc pétrolier lié aux frappes Iran pourrait relancer l'inflation via les coûts de transport et d'énergie — un scénario cauchemar pour la Fed.",
  macroExpectations: "Le NFP vendredi est l'indicateur le plus surveillé. Consensus : ~180K emplois. Au-dessus de 200K → Fed hawkish. En dessous de 150K → craintes de ralentissement. L'ISM Manufacturing lundi donnera le ton pour la semaine.",
  macroScenarios: [
    { label: "Constructif", description: "NFP 150-180K, ISM > 50, désescalade Iran — goldilocks pour les marchés." },
    { label: "Neutre", description: "NFP 180-220K, ISM stable, Iran contenu — consolidation avec volatilité." },
    { label: "Négatif", description: "NFP > 250K ou < 100K, escalade Iran, pétrole > $85 — sell-off généralisé." },
  ],
  macroCalendar: [
    { date: "Lun. 02/03", time: "10:00 ET", indicator: "ISM Manufacturing PMI", consensus: "50.5", previous: "50.9", sensitiveAssets: "USD, Industriels, S&P 500" },
    { date: "Mer. 04/03", time: "08:15 ET", indicator: "ADP Employment Change", consensus: "145K", previous: "183K", sensitiveAssets: "USD, Taux 2Y" },
    { date: "Jeu. 05/03", time: "10:00 ET", indicator: "ISM Services PMI", consensus: "53.0", previous: "52.8", sensitiveAssets: "USD, S&P 500" },
    { date: "Jeu. 05/03", time: "08:30 ET", indicator: "Jobless Claims", consensus: "220K", previous: "219K", sensitiveAssets: "USD, Taux 2Y" },
    { date: "Ven. 06/03", time: "08:30 ET", indicator: "Nonfarm Payrolls", consensus: "180K", previous: "143K", sensitiveAssets: "Tous les actifs — événement majeur" },
    { date: "Ven. 06/03", time: "08:30 ET", indicator: "Unemployment Rate", consensus: "4.0%", previous: "4.0%", sensitiveAssets: "USD, S&P 500, Taux" },
  ],

  fedContext: "La Fed maintient ses taux à 3,50%-3,75%. Le PPI chaud de janvier (+0,8% m/m core) a confirmé que l'inflation reste un problème. Le marché n'anticipe aucune baisse avant juin au plus tôt (96% de probabilité de statu quo en mars). Le choc pétrolier lié aux frappes Iran complique encore la tâche de la Fed : si le pétrole reste au-dessus de $80 pendant plusieurs semaines, l'inflation pourrait repartir à la hausse, forçant la Fed à maintenir ses taux élevés plus longtemps — voire à envisager une hausse.",
  fedLecture: "La Fed est prise en étau : l'économie ralentit (tech en correction, crédit sous tension) mais l'inflation ne recule pas (PPI chaud, pétrole en hausse). Avec des taux à 3,50%-3,75%, la Fed a déjà baissé de 175 bps depuis le pic, mais le marché veut plus. Le NFP de vendredi sera déterminant : un marché de l'emploi trop fort donnerait à la Fed une raison de ne rien faire, un marché trop faible pourrait forcer une baisse préventive. Les discours des membres Fed cette semaine seront scrutés pour tout commentaire sur l'impact des frappes Iran sur les perspectives d'inflation.",
  fedSpeakers: [
    { name: "Discours Fed multiples", date: "Semaine complète", stance: "Plusieurs membres de la Fed s'exprimeront cette semaine. Tout commentaire sur l'impact du pétrole sur l'inflation sera market-moving." },
  ],
  fedAlert: "Un commentaire hawkish sur l'inflation post-PPI ou post-pétrole serait très négatif pour les marchés.",

  sectors: [
    { name: "Biens Conso. Base", perf1W: 2.59 },
    { name: "Utilities", perf1W: 2.53 },
    { name: "Santé", perf1W: 1.68 },
    { name: "Énergie", perf1W: 1.64 },
    { name: "Materials", perf1W: 0.89 },
    { name: "Immobilier", perf1W: 0.68 },
    { name: "Communication", perf1W: -0.58 },
    { name: "Industriels", perf1W: -0.71 },
    { name: "Conso. Discrétionnaire", perf1W: -0.97 },
    { name: "Tech", perf1W: -2.15 },
    { name: "Financiers", perf1W: -2.43 },
  ],
  sectorsLecture: "La rotation défensive est nette : Consumer Staples (+2,59%) et Utilities (+2,53%) dominent tandis que Tech (-2,15%) et Financières (-2,43%) ferment la marche. L'énergie (+1,64%) devrait accélérer la semaine prochaine avec le spike pétrolier post-Iran. La Santé (+1,68%) confirme son statut défensif. Les stocks de défense (Lockheed Martin, Raytheon, Northrop Grumman) devraient bondir lundi. La Consommation Discrétionnaire (-0,97%) souffre des craintes de ralentissement.",
  sectorsScenarios: "Si le conflit Iran s'intensifie : énergie et défense en forte hausse, tech et consommation discrétionnaire en baisse. Si désescalade rapide : rebond technique possible sur la tech, mais la tendance de fond reste à la prudence. Le NFP de vendredi pourrait changer la donne sectorielle : un chiffre faible favoriserait les secteurs sensibles aux taux (immobilier, utilities), un chiffre fort pèserait sur les mêmes secteurs.",

  stocksMarketMoving: [
    { ticker: "AVGO", company: "Broadcom", date: "Mer. 04/03", timing: "Après clôture", consensus: "Revenus ~19,2 Mds$, BPA ajusté ~1.50$", watchFor: "Croissance AI semiconductor, guidance VMware, diversification revenus", risk: "Guidance décevante post-NVIDIA, compression des multiples IA", sensitivity: "Très forte sur l'ensemble du Nasdaq et du secteur semi-conducteurs" },
    { ticker: "CRWD", company: "CrowdStrike", date: "Mar. 03/03", timing: "Après clôture", consensus: "BPA ~0.85$, ARR en croissance", watchFor: "Adoption plateforme Falcon, impact Anthropic Claude sur la cybersécurité", risk: "Ralentissement de la croissance ARR, concurrence Palo Alto", sensitivity: "Forte sur le secteur cybersécurité" },
    { ticker: "TGT", company: "Target", date: "Mar. 03/03", timing: "Avant ouverture", consensus: "BPA ~2.10$, revenus ~31 Mds$", watchFor: "Premier rapport sous le nouveau CEO Michael Fiddelke, guidance 2026", risk: "Commentaires négatifs sur la consommation ou les tarifs", sensitivity: "Modérée sur la consommation discrétionnaire" },
    { ticker: "COST", company: "Costco", date: "Jeu. 05/03", timing: "", consensus: "BPA ~4.10$, revenus en croissance", watchFor: "Momentum membership, pricing power, comparable sales", risk: "Valorisation élevée (~50x PE), marge sous pression", sensitivity: "Modérée sur la consommation" },
    { ticker: "MRVL", company: "Marvell Technology", date: "Jeu. 05/03", timing: "", consensus: "BPA ~0.60$, revenus en forte croissance", watchFor: "Custom silicon pour hyperscalers (Amazon, Google), carnet de commandes IA", risk: "Dépendance aux dépenses capex des hyperscalers", sensitivity: "Forte sur les semi-conducteurs" },
  ],
  stocksLecture: "Broadcom est le titre le plus important de la semaine — il prend le relais de NVIDIA comme baromètre IA. Avec un consensus à ~19,2 Mds$ de revenus, les attentes sont élevées. Le marché cherche une confirmation que la demande IA est réelle au-delà de NVIDIA. CrowdStrike est le test pour le secteur cybersécurité post-Anthropic Claude. Target donnera le pouls de la consommation américaine sous un nouveau CEO. Costco est le proxy pour la résilience du consommateur. Marvell est un indicateur clé de la demande de custom silicon IA.",

  mag7: [
    { ticker: "NVDA", perfYTD: "-7.34%", catalyst: "En baisse de 7,34% sur février. Clôture à $177,81. Sensibilité aux résultats de Broadcom (confirmation ou infirmation du narratif IA).", positive: false },
    { ticker: "AAPL", perfYTD: "+1.81%", catalyst: "Apple Event annoncé cette semaine. Clôture à $264,18. Seul Mag 7 positif sur février.", positive: true },
    { ticker: "MSFT", perfYTD: "-6.5%", catalyst: "Clôture à $392,74. Sensibilité aux résultats de CrowdStrike (concurrence cybersécurité) et Broadcom (IA).", positive: false },
    { ticker: "AMZN", perfYTD: "-12.24%", catalyst: "Le plus mauvais performer du groupe. Clôture à $210,00. Sensibilité aux commentaires sur la consommation (Target, Costco).", positive: false },
    { ticker: "GOOGL", perfYTD: "-4.5%", catalyst: "Clôture à ~$309. Sensibilité aux résultats de Broadcom (IA) et au sentiment général sur la tech.", positive: false },
    { ticker: "META", perfYTD: "+9.54%", catalyst: "Meilleur performer Mag 7 sur février. Clôture à $648,18. Résilience remarquable.", positive: true },
    { ticker: "TSLA", perfYTD: "-5.0%", catalyst: "Clôture à $402,51. Très volatile. Sensibilité au pétrole (concurrence EV vs ICE) et aux tarifs.", positive: false },
  ],
  mag7Lecture: "Les Magnificent 7 sont en baisse de -6,87% YTD en tant que groupe (indice CNBC Mag 7). Seuls META (+9,54%) et AAPL (+1,81%) sont positifs sur février. Amazon reste le plus mauvais performer (-12,24% sur février). NVIDIA a perdu 7,34% sur le mois après la déception post-earnings. L'Apple Event annoncé cette semaine pourrait redonner du momentum à AAPL. Broadcom mercredi sera le catalyseur pour l'ensemble du groupe : si les résultats confirment la demande IA, un rebond technique est possible.",

  themes: [
    { title: "Choc Géopolitique Iran", description: "Les frappes US-Israel sur l'Iran sont le plus gros événement géopolitique depuis l'invasion de l'Ukraine en 2022. Le pétrole pourrait atteindre $80-100 si le conflit s'intensifie. Impact direct sur l'inflation, les taux et les marges des entreprises." },
    { title: "Inflation Persistante — Piège de la Fed", description: "Le PPI chaud (+0,8% m/m) combiné au spike pétrolier crée un cocktail inflationniste dangereux. La Fed est piégée : elle ne peut pas baisser les taux (inflation) ni les monter (croissance fragile)." },
    { title: "Fin du Règne des Mag 7 ?", description: "Pour la première fois depuis 2023, les 7 Magnificent sont tous négatifs YTD. La rotation vers les défensives et l'énergie pourrait être structurelle, pas juste tactique." },
  ],
  divergences: "Les stratégistes sont divisés : certains voient la correction comme une opportunité d'achat historique (fondamentaux IA intacts, économie résiliente). D'autres pensent que le marché entre dans un nouveau régime (inflation + géopolitique + fin de cycle tech). Cette divergence crée des opportunités mais aussi des risques accrus.",
  surprises: "Une désescalade rapide Iran (accord nucléaire avant le 6 mars) pourrait provoquer un rallye massif de soulagement. À l'inverse, une fermeture du Détroit d'Ormuz serait un cygne noir pour les marchés mondiaux.",

  voices: [
    { name: "Réaction des marchés aux frappes Iran", role: "Événement géopolitique", description: "Les futures Dow ouvrent dimanche soir. La réaction initiale donnera le ton pour toute la semaine. Pétrole, or, VIX et dollar seront les premiers indicateurs." },
    { name: "Greg Abel / Berkshire Hathaway", role: "Nouveau CEO Berkshire", description: "Premier rapport sous Greg Abel (post-Buffett). Les commentaires sur la valorisation du marché et les allocations de capital seront scrutés. Berkshire détient ~$300 Mds de cash — un signal sur le timing d'investissement." },
    { name: "Membres de la Fed", role: "Politique monétaire", description: "Plusieurs discours cette semaine. Tout commentaire sur l'impact du pétrole sur l'inflation ou sur le calendrier de baisse des taux sera market-moving." },
  ],

  policyContext: "Trois risques politiques convergent : (1) frappes Iran et deadline nucléaire 1-6 mars, (2) tarifs globaux de 10% déjà en vigueur avec menace de hausse à 15%, (3) incertitude budgétaire. Le pétrole est le canal de transmission principal vers les marchés.",
  policyCards: [
    { title: "Frappes US-Israel sur l'Iran — 28 février", description: "Les États-Unis et Israël ont lancé des frappes massives sur l'Iran. L'Iran a riposté — riposte plus large que les attaques de l'été dernier. Trump a donné un deadline du 1-6 mars pour un accord nucléaire. Si pas d'accord, menace de frappes supplémentaires. Le Détroit d'Ormuz (20% du pétrole mondial) est le risque principal." },
    { title: "Tarifs Trump — Escalade Commerciale", description: "Les tarifs globaux de 10% sont entrés en vigueur mardi 25 février. Trump menace de les porter à 15%. Impact sur les marges des entreprises importatrices et sur l'inflation des biens de consommation." },
  ],
  policyScenarios: [
    { label: "Désescalade", description: "Accord nucléaire Iran avant le 6 mars — pétrole retombe à $70, rallye de soulagement massif sur les indices." },
    { label: "Conflit contenu", description: "Pas d'accord mais pas d'escalade majeure — pétrole $75-85, volatilité élevée mais pas de crash." },
    { label: "Escalade", description: "Fermeture Ormuz ou frappes supplémentaires — pétrole > $90, VIX > 30, correction de 5-10% sur les indices." },
  ],
  policyLecture: "Le risque géopolitique est au plus haut depuis l'invasion de l'Ukraine. Les frappes Iran sont le facteur le plus imprévisible de la semaine. Le deadline nucléaire du 1-6 mars coïncide exactement avec la semaine de trading, ce qui signifie que chaque jour pourrait apporter une nouvelle escalade ou désescalade. Les marchés asiatiques et européens ouvrant avant Wall Street réagiront en premier. Les tarifs Trump ajoutent une couche d'incertitude supplémentaire.",

  earnings: [
    { day: "Samedi", date: "01/03", timing: "", ticker: "BRK.B", company: "Berkshire Hathaway", consensus: "", watchFor: "1er rapport sous Greg Abel, allocations de capital, $300 Mds de cash", risk: "Commentaires négatifs sur la valorisation du marché", highlight: true },
    { day: "Lundi", date: "02/03", timing: "", ticker: "NCLH", company: "Norwegian Cruise Line", consensus: "BPA ~0.15$", watchFor: "Demande de croisières, pricing power", risk: "Impact pétrole sur les coûts", highlight: false },
    { day: "Mardi", date: "03/03", timing: "Avant ouverture", ticker: "TGT", company: "Target", consensus: "BPA ~2.10$", watchFor: "Premier rapport nouveau CEO, guidance 2026", risk: "Consommation en ralentissement", highlight: false },
    { day: "Mardi", date: "03/03", timing: "Avant ouverture", ticker: "BBY", company: "Best Buy", consensus: "BPA ~2.40$", watchFor: "Demande électronique, impact IA sur les ventes", risk: "Tarifs sur les importations tech", highlight: false },
    { day: "Mardi", date: "03/03", timing: "Après clôture", ticker: "CRWD", company: "CrowdStrike", consensus: "BPA ~0.85$", watchFor: "ARR, adoption Falcon, impact Anthropic Claude", risk: "Ralentissement croissance", highlight: true },
    { day: "Mercredi", date: "04/03", timing: "Après clôture", ticker: "AVGO", company: "Broadcom", consensus: "Revenus ~19,2 Mds$", watchFor: "AI semiconductor, VMware synergies, guidance", risk: "Compression multiples IA post-NVIDIA", highlight: true },
    { day: "Mercredi", date: "04/03", timing: "Après clôture", ticker: "OKTA", company: "Okta", consensus: "BPA ~0.75$", watchFor: "Croissance identity management, adoption cloud", risk: "Concurrence Microsoft Entra", highlight: false },
    { day: "Jeudi", date: "05/03", timing: "", ticker: "COST", company: "Costco", consensus: "BPA ~4.10$", watchFor: "Membership momentum, comparable sales", risk: "Valorisation élevée (~50x PE)", highlight: false },
    { day: "Jeudi", date: "05/03", timing: "", ticker: "MRVL", company: "Marvell Technology", consensus: "BPA ~0.60$", watchFor: "Custom silicon IA, carnet de commandes", risk: "Dépendance capex hyperscalers", highlight: true },
  ],
  earningsLecture: "La saison des résultats est presque terminée, mais cette semaine concentre des publications décisives. Broadcom mercredi est l'événement principal : après la déception NVIDIA, le marché a besoin d'une confirmation que la demande IA est réelle. CrowdStrike mardi testera le secteur cybersécurité. Berkshire Hathaway samedi sera le premier rapport sous Greg Abel — les commentaires sur le marché et les $300 Mds de cash seront scrutés. Target et Best Buy donneront le pouls de la consommation américaine face aux tarifs.",

  scenarios: [
    { name: "Scénario Bull", probability: "~15%", description: "Désescalade Iran rapide (accord nucléaire). Broadcom publie des résultats exceptionnels. NFP en zone goldilocks (150-180K). Rebond technique massif.", result: "S&P 500 +3-5%, Nasdaq +4-6%", signal: "VIX retombe sous 18, pétrole sous $70" },
    { name: "Scénario Base", probability: "~50%", description: "Conflit Iran contenu mais pas résolu. Broadcom publie de bons résultats en ligne. NFP proche du consensus. Volatilité élevée mais pas de crash.", result: "S&P 500 -1% à +1%, forte volatilité intraday", signal: "VIX entre 20 et 25, pétrole $75-85" },
    { name: "Scénario Bear", probability: "~35%", description: "Escalade Iran (Ormuz menacé). Broadcom déçoit. NFP trop fort (>250K, Fed hawkish) ou trop faible (<100K, récession). Sell-off généralisé.", result: "S&P 500 -3-7%, Nasdaq -5-8%", signal: "VIX > 28, pétrole > $85, 10Y < 3.80%" },
  ],
  risks: [
    { title: "Risque 1 — Escalade Iran / Ormuz", description: "Si le conflit s'intensifie et que le Détroit d'Ormuz est menacé, le pétrole pourrait dépasser $90-100. Impact direct sur l'inflation, les marges des entreprises et le sentiment des investisseurs. C'est le risque de type 'cygne noir' de la semaine." },
    { title: "Risque 2 — Inflation + Pétrole = Fed Piégée", description: "Le PPI chaud combiné au spike pétrolier crée un cocktail inflationniste. Si la Fed doit reporter encore les baisses de taux, les valorisations des actions de croissance seraient sous pression prolongée." },
    { title: "Risque 3 — NFP Extrême", description: "Un NFP trop fort (>250K) confirmerait le scénario 'higher for longer'. Un NFP trop faible (<100K) déclencherait des craintes de récession. Les deux scénarios extrêmes sont négatifs pour les marchés." },
  ],
  scenarioDisclaimer: "Les scénarios présentés sont des hypothèses éducatives basées sur des données publiques disponibles au moment de la rédaction. Ils ne constituent pas des prévisions certaines ni des recommandations d'investissement.",
  scenariosLecture: "Le scénario de base (50%) est une semaine de forte volatilité sans direction claire. Le risque est nettement asymétrique vers le bas (35% bear vs 15% bull) en raison de l'accumulation de facteurs négatifs (Iran, inflation, rotation). Le pétrole est la variable clé : au-dessus de $85, le scénario bear devient dominant. En dessous de $75, le scénario bull reprend de la force. Le NFP de vendredi sera le deuxième catalyseur majeur.",

  glossary: [
    { term: "Détroit d'Ormuz", definition: "Passage maritime stratégique entre l'Iran et Oman. 20% du pétrole mondial y transite. Sa fermeture serait un choc pétrolier mondial." },
    { term: "Flight-to-Safety", definition: "Mouvement des investisseurs vers les actifs refuges (Treasuries, or, CHF, USD) en période de crise." },
    { term: "ISM PMI", definition: "Institute for Supply Management Purchasing Managers' Index. Au-dessus de 50 = expansion, en dessous = contraction." },
    { term: "NFP", definition: "Nonfarm Payrolls : nombre d'emplois créés hors agriculture. Indicateur clé du marché du travail US." },
    { term: "PPI", definition: "Producer Price Index : indice des prix à la production, indicateur avancé de l'inflation." },
    { term: "Risk-Off", definition: "Mode de marché où les investisseurs réduisent leur exposition aux actifs risqués (actions, crypto) au profit des actifs refuges." },
    { term: "Spike", definition: "Mouvement de prix brutal et rapide, généralement à la hausse, souvent déclenché par un événement inattendu." },
    { term: "VIX", definition: "CBOE Volatility Index : volatilité implicite du S&P 500 sur 30 jours. 'L'indice de la peur'." },
    { term: "Custom Silicon", definition: "Puces semi-conducteurs conçues sur mesure pour un client spécifique (ex: Google TPU, Amazon Graviton)." },
    { term: "ARR", definition: "Annual Recurring Revenue : revenu annuel récurrent, métrique clé pour les entreprises SaaS." },
    { term: "Cygne Noir", definition: "Événement rare, imprévisible et à fort impact sur les marchés. Concept popularisé par Nassim Taleb." },
    { term: "Higher for Longer", definition: "Scénario où la Fed maintient des taux élevés sur une période prolongée." },
  ],
  sources: "Les données macro (PPI, ISM, NFP) sont issues des publications officielles du Bureau of Labor Statistics (BLS) et de l'ISM. Les données de marché (indices, taux, VIX, commodities, crypto) sont basées sur la clôture US du vendredi 28 février 2026 (Nasdaq.com, CNBC, Reuters, Yahoo Finance). Les informations sur les frappes Iran proviennent de Reuters, AP, Forbes, Investors.com. Les anticipations Fed sont basées sur l'outil FedWatch de CME Group. Les données de résultats d'entreprises sont issues de sources d'information financière publiques.",
  disclaimer: "Ce document est produit à des fins strictement informatives et éducatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente d'actifs financiers, un conseil en investissement, ou une promesse de performance. Les marchés financiers sont par nature imprévisibles. Les frappes sur l'Iran créent une incertitude exceptionnelle — toute décision d'investissement doit être prise avec une prudence accrue.",
};
