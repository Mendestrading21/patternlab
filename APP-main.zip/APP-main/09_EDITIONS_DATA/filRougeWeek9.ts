/**
 * WMB Fil Rouge — Semaine 9 (MER 25/02/2026)
 * NVIDIA Beat Massif, PCE en Vue & Tarifs Confirmes -- Midweek Update
 */
import type { FilRougeModuleData } from "../filRouge";

export const FIL_ROUGE_SEMAINE_9: FilRougeModuleData = {
  id: 402,
  weekNumber: 9,
  year: 2026,
  dateRange: "MER 25/02 2026",
  title: "NVIDIA Beat Massif, PCE en Vue & Tarifs Confirmes -- Midweek Update",
  subtitle: "Delta marche post-NVIDIA, agenda 72h PCE + tarifs, watchlist update, alerte risque",
  publishedAt: "2026-02-25T06:30:00Z",

  delta: {
    summary: "NVIDIA a publie des resultats Q4 au-dessus des attentes (CA $38.9B vs $38.5B consensus, +66% YoY). Le Nasdaq a bondi de +2.1% mercredi soir en after-hours. Le S&P 500 progresse de +0.8% sur la semaine. Cependant, le marche reste prudent avant le PCE de vendredi et l'entree en vigueur des tarifs le 4 mars.",
    indices: [
      { name: "S&P 500", value: "6 085", change: "+0.8%" },
      { name: "Nasdaq 100", value: "22 150", change: "+2.1%" },
      { name: "Dow Jones", value: "44 180", change: "+0.3%" },
      { name: "Russell 2000", value: "2 295", change: "-0.4%" },
      { name: "VIX", value: "16.80", change: "+1.2 pts" }
    ],
    commodities: [
      { name: "Or (XAU)", value: "4 750 $/oz", change: "+0.6%" },
      { name: "WTI", value: "73.20 $", change: "+0.8%" },
      { name: "Cuivre", value: "4.30 $/lb", change: "+1.1%" }
    ],
    crypto: [
      { name: "Bitcoin", value: "93 500 $", change: "+1.5%" },
      { name: "Ethereum", value: "3 450 $", change: "+2.2%" },
      { name: "Solana", value: "175 $", change: "+3.8%" }
    ],
    lectureWMB: "Le beat NVIDIA a relance le momentum tech mais le marche reste en mode 'attente PCE'. Le VIX a monte a 16.80 malgre le rally tech -- signe que les operateurs couvrent leurs positions avant vendredi. Les small caps (Russell -0.4%) ne participent pas au rally, ce qui confirme que le mouvement est concentre sur les mega-caps tech. L'or continue de monter (+0.6%) malgre le risk-on -- les banques centrales continuent d'acheter."
  },

  agenda72h: [
    "JEUDI 26/02 -- PIB Q4 revise (08:30 ET) : consensus +2.3%, confirmation de la croissance moderee",
    "JEUDI 26/02 -- Jobless Claims (08:30 ET) : consensus 215K, marche de l'emploi toujours solide",
    "JEUDI 26/02 -- Salesforce earnings (AC) : test de la monetisation IA Agentforce",
    "JEUDI 26/02 -- Snowflake earnings (AC) : croissance product revenue en question",
    "VENDREDI 27/02 -- PCE Core (08:30 ET) : consensus 2.6% YoY -- LE chiffre de la semaine",
    "VENDREDI 27/02 -- Personal Income & Spending : sante du consommateur",
    "VENDREDI 27/02 -- Chicago PMI : indicateur regional d'activite",
    "LUNDI 03/03 -- ISM Manufacturing : premier indicateur de mars",
    "MARDI 04/03 -- Tarifs 25% Canada/Mexique entrent en vigueur"
  ],

  watchlistUpdate: [
    { ticker: "NVDA", status: "Beat Q4 -- CA $38.9B (+66% YoY), guidances Q1 $41B vs $40B consensus", level: "Support 130 $ / Resistance 155 $" },
    { ticker: "HD", status: "Resultats mardi en ligne -- SSS +3.2%, guidance prudente sur les tarifs", level: "Support 380 $ / Resistance 410 $" },
    { ticker: "CRM", status: "Earnings jeudi AC -- consensus CA $10.0B, focus Agentforce", level: "Support 285 $ / Resistance 320 $" },
    { ticker: "GM", status: "En baisse -3.5% sur les tarifs confirmes -- 40% des pieces du Canada/Mexique", level: "Support 48 $ / Resistance 55 $" },
    { ticker: "VST", status: "Vistra +4.2% sur le rally NVIDIA -- theme energie IA renforce", level: "Support 95 $ / Resistance 115 $" }
  ],

  riskAlert: "ALERTE RISQUE : Double catalyseur vendredi/mardi. Le PCE de vendredi peut changer la trajectoire des taux (consensus 2.6%, au-dessus = hawkish). Les tarifs 25% Canada/Mexique entrent en vigueur mardi 4 mars -- impact direct sur l'auto (GM, Ford), l'agriculture (ADM, BG) et l'energie. Le marche n'a pas encore pleinement price ces tarifs. SI PCE > 2.8% ET tarifs maintenus, correction de 3-5% possible sur le S&P 500 la semaine prochaine. Surveillez le VIX : au-dessus de 20, le risk-off s'accelere.",

  sources: "Sources : Bloomberg, Reuters, NVIDIA IR, CME FedWatch, BEA, BLS. Donnees au 25/02/2026.",
  disclaimer: "WallStreet Market Brief est un document informatif et educatif. Il ne constitue en aucun cas un conseil en investissement."
};
