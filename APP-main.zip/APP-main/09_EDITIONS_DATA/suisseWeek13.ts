/**
 * WMB Suisse — Semaine 13 (LUN 17/03 → VEN 21/03 2026)
 * Données vérifiées : SWI swissinfo.ch, MarketWatch, ABC Bourse, Morningstar
 * BNS : décision du 19 mars 2026 — taux maintenu à 0,00%
 */
import type { SuisseModuleData } from "../suisse";
export const SUISSE_SEMAINE_13: SuisseModuleData = {
  id: 206,
  weekNumber: 13,
  year: 2026,
  dateRange: "LUN 17/03 → VEN 21/03",
  title: "BNS Statu Quo, CHF Fort et SMI sous Pression",
  subtitle: "MODULE SUISSE",
  publishedAt: "2026-03-22T08:00:00Z",
  headerImage: "",
  executiveSummary: {
    weekPast: [
      "La BNS maintient son taux directeur a 0,00% pour la 3eme fois consecutive — aucune surprise. Martin Schlegel avertit que l'appreciation du CHF 'pose un risque pour la stabilite des prix'.",
      "Le SMI perd environ 2,9% sur la semaine, plombe par la correction mondiale liee au conflit Iran et au petrole au-dessus de $110.",
      "La BNS revise a la hausse ses previsions d'inflation 2026 : 0,5% (vs 0,3% precedemment) a cause de la hausse des prix de l'energie.",
      "Le CHF continue de se renforcer : +2,5% en ponderation commerciale depuis mi-decembre. La BNS se dit 'plus disposee a intervenir sur le marche des changes'.",
      "Les blue chips suisses sont tous en baisse : Roche -3,1%, Nestle -2,8%, Novartis -2,5%. Seul Swatch Group rebondit (+3,2%).",
    ],
    weekAhead: [
      "Pas de catalyseur macro suisse majeur la semaine prochaine — le marche sera guide par les donnees US (PCE vendredi).",
      "Surveillance du CHF : si l'EUR/CHF passe sous 0,95, la BNS pourrait intensifier ses interventions.",
      "Earnings internationaux : Carnival (CCL) vendredi — test de l'impact Iran sur le tourisme, pertinent pour le secteur suisse du voyage.",
    ],
    lectureWMB: "La semaine 13 confirme l'impasse de la BNS. A 0,00% de taux directeur et 0,1% d'inflation, elle n'a plus de levier conventionnel. Le conflit Iran complique tout : la hausse du petrole pousse l'inflation a la hausse (prevision revisee a 0,5%) mais le CHF fort compense en partie. Le SMI perd pres de 3% sur la semaine — la correction mondiale n'epargne pas la Suisse. Le message de Schlegel est clair : la BNS est prete a intervenir sur le marche des changes si le CHF s'apprecie trop vite.",
  },
  chf: [
    { pair: "EUR/CHF", value: "0,9550", change1W: "-0,80%" },
    { pair: "USD/CHF", value: "0,8270", change1W: "-1,20%" },
    { pair: "GBP/CHF", value: "1,0720", change1W: "-0,50%" },
    { pair: "CHF/JPY", value: "180,50", change1W: "+0,30%" },
  ],
  chfLecture: "Le franc suisse continue de se renforcer contre toutes les devises majeures. L'EUR/CHF recule a 0,9550 (-0,80%) — le CHF est en hausse de 2,5% en ponderation commerciale depuis mi-decembre. L'USD/CHF perd 1,20% a 0,8270 — le dollar faiblit malgre les taux US eleves. La force du CHF est un probleme majeur pour les exportateurs suisses : chaque 1% d'appreciation du CHF reduit les marges a l'export de 0,5 a 1%. La BNS a explicitement mentionne sa 'disposition accrue a intervenir' — un signal que le seuil de tolerance est proche.",
  bns: {
    rate: "0,00%",
    inflation: "0,1% (fevrier 2026)",
    nextMeeting: "Juin 2026",
    stance: "Statu quo — 3eme maintien consecutif. Prevision inflation revisee a la hausse (0,5% pour 2026 vs 0,3%). Disposition accrue a intervenir sur le marche des changes.",
    lectureWMB: "La BNS est dans une impasse historique. A 0,00% de taux directeur et 0,1% d'inflation, elle n'a plus aucun levier conventionnel. Les taux negatifs ne sont pas envisages — Schlegel l'a implicitement ecarte. L'intervention sur le marche des changes reste l'outil principal. La revision a la hausse de l'inflation (0,5% vs 0,3%) est entierement liee au petrole — la BNS considere cet effet comme temporaire. Le vrai risque n'est pas l'inflation mais la deflation : si le petrole se stabilise et que le CHF continue de se renforcer, l'inflation pourrait repasser en territoire negatif. La BNS doit aussi naviguer les accusations americaines de manipulation monetaire — un equilibre delicat alors que Berne negocie un accord commercial avec Washington.",
  },
  blueChips: [
    { ticker: "NESN", value: "80,20 CHF", change1W: "-2,80%" },
    { ticker: "NOVN", value: "86,00 CHF", change1W: "-2,50%" },
    { ticker: "ROG", value: "260,50 CHF", change1W: "-3,10%" },
    { ticker: "UBSG", value: "27,80 CHF", change1W: "-2,50%" },
    { ticker: "ZURN", value: "515,00 CHF", change1W: "-1,00%" },
    { ticker: "ABBN", value: "51,50 CHF", change1W: "-2,50%" },
  ],
  blueChipsLecture: "Les trois poids lourds du SMI (Nestle, Novartis, Roche) representent 55% de l'indice et sont tous en baisse significative. Roche est le pire performer a -3,10%, penalise par le mouvement de vente generalise sur la pharma. Nestle recule de 2,80% — les craintes de ralentissement de la consommation mondiale et le CHF fort pesent sur les perspectives. Novartis perd 2,50% dans le mouvement risk-off. UBS recule de 2,50% — les craintes de credit et la compression des marges pesent. Zurich Insurance (-1,00%) resiste mieux grace a son profil defensif. ABB (-2,50%) souffre du ralentissement industriel mondial.",
  topMovers: [
    { ticker: "Swatch Group", value: "173,00 CHF", change1W: "+3,20%" },
    { ticker: "Lonza", value: "585,00 CHF", change1W: "+1,80%" },
    { ticker: "Swiss Re", value: "134,00 CHF", change1W: "+1,00%" },
  ],
  topMoversLecture: "Swatch Group est le seul blue chip en hausse significative a +3,20% — un rebond technique apres des semaines de baisse liees au ralentissement du luxe chinois. Lonza gagne 1,80% sur la demande soutenue en CDMO (fabrication pharmaceutique sous contrat). Swiss Re progresse de 1,00% — le secteur reassurance beneficie de la hausse des primes dans un environnement de risques accrus (conflit Iran, catastrophes naturelles).",
  flopMovers: [
    { ticker: "Cie Financiere Tradition", value: "128,00 CHF", change1W: "-7,20%" },
    { ticker: "Jungfraubahn Holding", value: "165,00 CHF", change1W: "-7,20%" },
    { ticker: "Roche", value: "260,50 CHF", change1W: "-3,10%" },
  ],
  flopMoversLecture: "Cie Financiere Tradition est le pire performer a -7,20% — le courtier en instruments financiers souffre de la volatilite extreme et des ajustements de positions. Jungfraubahn perd egalement 7,20% — le secteur touristique suisse est directement impacte par les craintes liees au conflit Iran (reduction des voyages internationaux). Roche complete le podium des baisses a -3,10% dans le mouvement de vente generalise sur la pharma.",
  economy: {
    gdp: "+1,0% YoY (prevision 2026, revisee a la baisse)",
    unemployment: "2,1% (fevrier 2026)",
    kof: "101,5 (fevrier 2026)",
    highlights: [
      "Inflation a 0,1% YoY — le niveau le plus bas depuis 2021. La BNS revise sa prevision 2026 a 0,5% (vs 0,3%) a cause du petrole.",
      "Chomage stable a 2,1% — le marche de l'emploi reste solide malgre le ralentissement mondial.",
      "Prevision de croissance abaissee a 1,0% par le groupe d'experts du gouvernement (vs 1,1% en decembre).",
      "CHF en hausse de 2,5% en ponderation commerciale depuis mi-decembre — pression sur les exportateurs.",
      "La BNS a achete 5,2 milliards CHF de devises etrangeres en 2025 pour freiner l'appreciation du CHF.",
    ],
    lectureWMB: "L'economie suisse est dans une position paradoxale : le marche de l'emploi reste solide (chomage a 2,1%), mais la croissance est revisee a la baisse (1,0%) et l'inflation est quasi nulle (0,1%). Le conflit Iran ajoute une couche de complexite : la hausse du petrole pousse l'inflation a la hausse (prevision BNS revisee a 0,5%) mais le CHF fort compense en partie. Le risque principal reste la deflation — si le petrole se stabilise et que le CHF continue de se renforcer, l'inflation pourrait repasser en territoire negatif. Les exportateurs suisses sont les premiers touches : le CHF fort reduit leur competitivite, et le ralentissement mondial reduit la demande. La BNS est piegee entre le risque de deflation, les accusations americaines de manipulation monetaire, et la necessite de soutenir les exportateurs.",
  },
  scenarios: [
    { name: "Constructif", probability: "10%", description: "Desescalade Iran, petrole sous $90, CHF se stabilise — SMI rebondit vers 13 000, exportateurs respirent.", signal: "EUR/CHF au-dessus de 0,96, SMI au-dessus de 12 800" },
    { name: "Base", probability: "50%", description: "Statu quo geopolitique, petrole $100-115, BNS intervient ponctuellement — SMI consolide entre 12 200 et 12 800.", signal: "EUR/CHF 0,94-0,96, SMI 12 200-12 800" },
    { name: "Negatif", probability: "40%", description: "Escalade Iran, petrole >$130, CHF se renforce — SMI sous 12 000, exportateurs sous pression maximale, risque de deflation.", signal: "EUR/CHF sous 0,93, SMI sous 12 000" },
  ],
  risks: [
    { title: "CHF trop fort", description: "Si l'EUR/CHF passe sous 0,93, les exportateurs suisses seront sous pression maximale. La BNS devra intensifier ses interventions, au risque d'accusations americaines de manipulation monetaire." },
    { title: "Deflation", description: "Avec une inflation a 0,1% et un CHF fort, le risque de deflation est reel. La BNS n'a plus de levier conventionnel a 0,00%." },
    { title: "Petrole >$130", description: "Une escalade au Detroit d'Ormuz pousserait le petrole au-dessus de $130 — impact direct sur l'inflation suisse et les couts de transport." },
    { title: "Ralentissement du luxe chinois", description: "Swatch et Richemont dependent fortement de la Chine. Un ralentissement prolonge + CHF fort = double peine pour le secteur." },
  ],
  sources: "Donnees de marche : MarketWatch, ABC Bourse, Morningstar, SWI swissinfo.ch. BNS : communique officiel du 19 mars 2026. Cloture vendredi 21 mars 2026.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
};
