/**
 * WMB Monde — Semaine 11 (LUN 03/03 → VEN 07/03 2026)
 * Choc Petrolier Global : Europe, Asie et Emergents Sous Pression
 * Donnees verifiees : Yahoo Finance, CNBC, Reuters, MarketScreener
 * Cloture vendredi 6 mars 2026 + futures dimanche 8 mars
 */
import type { MondeModuleData } from "../monde";

export const MONDE_SEMAINE_11: MondeModuleData = {
  id: 104,
  weekNumber: 11,
  year: 2026,
  dateRange: "LUN 03/03 → VEN 07/03",
  title: "Choc Petrolier Global : Europe, Asie et Emergents Sous Pression",
  subtitle: "REVUE MONDE",
  publishedAt: "2026-03-09T08:00:00Z",
  headerImage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663135061541/Wf8Nj4yLBCzwrPQSdtP8cC/europe-stoxx_9d04086b.jpg",

  executiveSummary: {
    weekPast: [
      "L'Europe a subi une semaine de correction generalisee. Le DAX lache 2,48% pour cloturer a 22 963,69, le CAC 40 recule de 2,48% a 7 794,94, et le FTSE 100 perd 1,92% a 10 087. L'Euro Stoxx 50 cede 2,85% a 5 556,85. Le plan de relance budgetaire allemand de 800 milliards d'euros a ete totalement eclipse par le choc petrolier et la guerre US-Iran.",
      "L'Asie est en chute libre dimanche soir. Le Nikkei 225 plonge de 5,24% a 52 707,50 — sa pire seance depuis le mini-crash d'aout 2024. Le Hang Seng recule de 1,35% a 25 408,46, Shanghai cede 0,67% a 4 096,60. Le BSE Sensex indien perd 2,27% a 77 124,26. L'Australie (ASX 200) chute de 2,88%.",
      "Le petrole est le catalyseur global. Le WTI a bondi de 35% sur la semaine — la plus forte hausse depuis que les futures existent (1983) — pour atteindre 103,06 dollars dimanche soir. Le Brent depasse 106,79 dollars.",
      "Paradoxe majeur : l'or recule de 6% sur la semaine a 5 102 dollars l'once malgre le contexte geopolitique. Le flight-to-safety va vers le dollar (DXY +1,4%, meilleure semaine depuis aout) et les Treasuries, pas vers les metaux precieux.",
    ],
    weekAhead: [
      "CPI americain mercredi 11 mars — l'indicateur le plus surveille au monde cette semaine. Consensus : +2,4% YoY. Un chiffre au-dessus de 2,6% confirmerait le diagnostic de stagflation globale.",
      "Jobless Claims jeudi 12 mars — apres le NFP catastrophique (-92 000), le marche scrutera tout indicateur d'emploi.",
      "PCE Price Index vendredi 13 mars (retarde par le shutdown) — indicateur d'inflation prefere de la Fed.",
      "UMich Consumer Sentiment vendredi 13 mars — premier apercu de l'impact de la guerre Iran et de l'essence (+12% en une semaine) sur le moral des menages.",
    ],
    lectureWMB: "Le choc petrolier a transforme une correction technique en crise de confiance globale. L'Europe, qui surperformait les US depuis janvier grace au plan de relance allemand et a la rotation geographique, se retrouve piegee par sa dependance energetique — le DAX perd 2,48%, le CAC 40 2,48%. L'Asie est en chute libre dimanche soir : le Nikkei plonge de 5,24%, sa pire seance depuis aout 2024. Les emergents importateurs de petrole (Inde, Turquie) souffrent doublement — inflation importee et fuite de capitaux. Le paradoxe de la semaine : l'or recule de 6% alors que le dollar grimpe de 1,4% — le billet vert est le refuge numero un, pas les metaux precieux. Le CPI americain de mercredi sera le juge de paix pour les marches mondiaux. Mais avec le petrole au-dessus de 103 dollars et le Nikkei en chute libre, la semaine commence deja sous haute tension.",
  },

  indicesEurope: [
    { name: "Euro STOXX 50", value: "5 556,85", change1W: "-2,85%" },
    { name: "DAX 40 (Allemagne)", value: "22 963,69", change1W: "-2,48%" },
    { name: "CAC 40 (France)", value: "7 794,94", change1W: "-2,48%" },
    { name: "FTSE 100 (UK)", value: "10 087,00", change1W: "-1,92%" },
  ],
  indicesEuropeLecture: "L'Europe a subi une semaine de correction generalisee, avec des baisses allant de -1,92% (FTSE 100) a -2,85% (Euro Stoxx 50). Le DAX lache 2,48% a 22 963,69 — le plan de relance allemand de 800 milliards d'euros qui avait porte l'indice a des records en fevrier est desormais totalement eclipse par le choc petrolier. Le CAC 40 recule de 2,48% a 7 794,94, le luxe (LVMH, Hermes) ne suffisant plus a compenser les cycliques. Le FTSE 100 perd 1,92% a 10 087 — relativement protege par le poids de l'energie (BP, Shell beneficient du petrole cher). Le message cle : l'Europe reste structurellement vulnerable a tout choc energetique exogene. Si le petrole se maintient au-dessus de 100 dollars, la surperformance europeenne du T1 sera effacee. Le plan de relance allemand reste un catalyseur positif a moyen terme, mais il est noye dans le bruit geopolitique a court terme.",

  indicesAsia: [
    { name: "Nikkei 225 (Japon)", value: "52 707,50", change1W: "-5,24%" },
    { name: "Hang Seng (Hong Kong)", value: "25 408,46", change1W: "-1,35%" },
    { name: "Shanghai Composite", value: "4 096,60", change1W: "-0,67%" },
    { name: "S&P/ASX 200 (Australie)", value: "8 823,60", change1W: "-2,88%" },
    { name: "BSE Sensex (Inde)", value: "77 124,26", change1W: "-2,27%" },
  ],
  indicesAsiaLecture: "L'Asie est en chute libre dimanche soir. Le Nikkei 225 plonge de 5,24% a 52 707,50 — sa pire seance depuis le mini-crash d'aout 2024. Le Japon souffre doublement : importateur net de petrole et yen faible (USD/JPY a 158,58). L'Australie (ASX 200) perd 2,88%, l'Inde (Sensex) 2,27%. Le Hang Seng limite la casse a -1,35% grace aux valeurs tech chinoises et aux mesures de relance de Pekin. Shanghai ne cede que 0,67%, confirmant que la Chine joue un role de stabilisateur relatif dans la tempete — le NPC a fixe un objectif de 5% de croissance et annonce des mesures de stimulus. Le message cle : l'Asie est divisee entre les gagnants relatifs (Chine, exportateurs de commodities) et les perdants (Japon, Inde, importateurs de petrole). Si le petrole reste au-dessus de 100 dollars, le Nikkei pourrait tester 50 000 — un niveau psychologique majeur.",

  emergingMarkets: {
    msciEM: { value: "~1 050", change1W: "-2,5%" },
    highlights: [
      "Le MSCI Emerging Markets recule d'environ 2,5% — les importateurs de petrole (Inde -2,27%, Turquie, Thailande) souffrent le plus.",
      "L'Inde (Sensex -2,27% a 77 124) est particulierement vulnerable : le pays importe 85% de son petrole, et chaque hausse de 10 dollars du baril coute environ 15 milliards de dollars a l'economie.",
      "La Chine reste le stabilisateur : Shanghai ne cede que 0,67%, soutenu par le NPC (objectif 5% de croissance) et les mesures de stimulus fiscal.",
      "L'Australie (ASX 200 -2,88%) souffre malgre son statut d'exportateur de commodities — les sorties de capitaux dominent a court terme.",
    ],
    lectureWMB: "Les emergents sont le maillon faible du choc petrolier. Les importateurs nets de petrole (Inde, Turquie, Thailande) subissent un double choc : inflation importee et fuite de capitaux vers les actifs refuges (dollar, Treasuries). L'Inde est le cas le plus preoccupant : le Sensex perd 2,27% a 77 124, et chaque hausse de 10 dollars du baril coute environ 15 milliards de dollars a l'economie indienne. La Chine est un cas a part — le NPC a fixe un objectif de 5% de croissance et annonce des mesures de stimulus, ce qui explique la resilience relative de Shanghai (-0,67%). Si le petrole se maintient au-dessus de 100 dollars, plusieurs banques centrales emergentes seront forcees de remonter leurs taux — ce qui aggraverait le ralentissement economique.",
  },

  forex: [
    { pair: "DXY", value: "99,52", change1W: "+1,4%" },
    { pair: "EUR/USD", value: "1,1536", change1W: "-0,73%" },
    { pair: "GBP/USD", value: "1,3319", change1W: "-0,71%" },
    { pair: "USD/JPY", value: "158,58", change1W: "+0,52%" },
    { pair: "USD/CHF", value: "0,7800", change1W: "+0,61%" },
    { pair: "EUR/CHF", value: "0,8998", change1W: "-0,14%" },
    { pair: "AUD/USD", value: "~0,6250", change1W: "-1,2%" },
  ],
  forexLecture: "Le dollar domine tout — le DXY grimpe a 99,52, sa meilleure semaine depuis aout (+1,4%). C'est un changement de regime majeur : le flight-to-safety va massivement vers le billet vert. L'EUR/USD recule a 1,1536 (-0,73%), le GBP/USD a 1,3319 (-0,71%). Le yen est sous pression a 158,58 — ecrase par le carry trade et la force du dollar, ce qui aggrave le probleme du Japon (importateur de petrole en dollars). Le franc suisse recule legerement contre le dollar (USD/CHF a 0,7800, +0,61%) mais reste proche de ses plus hauts depuis 2015 contre l'euro (EUR/CHF a 0,8998). Le paradoxe du moment : le petrole monte (signal inflationniste) ET le dollar monte (signal de peur). Quand les deux montent ensemble, c'est que le marche est en mode panique pure — il cherche la securite du dollar avant tout.",

  commodities: [
    { name: "WTI Crude", value: "103,06 $/b (dim.)", change1W: "+35%" },
    { name: "Brent Crude", value: "106,79 $/b (dim.)", change1W: "+15,21% (dim.)" },
    { name: "Or (XAU)", value: "5 102 $/oz", change1W: "-6,0%" },
    { name: "Argent (XAG)", value: "~29 $/oz", change1W: "-5%" },
    { name: "Gaz Naturel", value: "~4,10 $/MMBtu", change1W: "+8%" },
  ],
  commoditiesLecture: "Le petrole domine tout. Le WTI a bondi de 35% sur la semaine — la plus forte hausse depuis que les futures petroliers existent (1983) — pour atteindre 103,06 dollars dimanche soir. Le Brent depasse 106,79 dollars. Les catalyseurs sont multiples : la guerre US-Iran entre dans son 7eme jour, le Qatar menace un force majeure sur les exportations du Golfe, le Koweit coupe sa production. Chaque hausse de 10 dollars du petrole ajoute entre 0,2% et 0,4% a l'inflation mondiale. L'or, en revanche, surprend a la baisse : -6% sur la semaine a 5 102 dollars l'once. L'explication : le dollar est le refuge numero un cette semaine (DXY +1,4%), et un dollar fort pese mecaniquement sur l'or libelle en dollars. Le gaz naturel monte d'environ 8%, entraine par le petrole. Si le Detroit d'Ormuz est menace, le petrole pourrait tester 130-150 dollars — un niveau qui provoquerait une recession mondiale.",

  crypto: [
    { name: "Bitcoin (BTC)", value: "67 766 $", change1W: "+0,42%" },
    { name: "Ethereum (ETH)", value: "~2 000 $", change1W: "~0%" },
  ],
  cryptoLecture: "Le Bitcoin a 67 766 dollars (+0,42%) est la surprise de la semaine. Alors que les indices actions plongent et que le VIX explose, le BTC resiste et meme progresse legerement. Bloomberg titre 'Bitcoin Beats Risk Assets as Oil Surges on Iran War Concerns'. Pour la premiere fois dans un choc geopolitique majeur, le Bitcoin se comporte davantage comme un actif refuge que comme un actif risque. Ethereum tient a environ 2 000 dollars, montrant une resilience relative. Le support critique du BTC se situe a 63 000 dollars (moyenne mobile 200 jours).",

  centralBanks: [
    { name: "Fed (USA)", rate: "4,25%-4,50%", lastDecision: "Statu quo (janvier)", nextMeeting: "18-19 mars 2026" },
    { name: "BCE (Zone Euro)", rate: "2,65%", lastDecision: "Baisse 25 bps (janvier)", nextMeeting: "Avril 2026" },
    { name: "BoE (UK)", rate: "4,50%", lastDecision: "Statu quo (fevrier)", nextMeeting: "20 mars 2026" },
    { name: "BoJ (Japon)", rate: "0,50%", lastDecision: "Hausse 25 bps (janvier)", nextMeeting: "14 mars 2026" },
    { name: "BNS (Suisse)", rate: "0,25%", lastDecision: "Baisse 25 bps (decembre)", nextMeeting: "20 mars 2026" },
    { name: "PBoC (Chine)", rate: "3,10% (LPR 1Y)", lastDecision: "Statu quo (fevrier)", nextMeeting: "20 mars 2026" },
  ],
  centralBanksLecture: "Les banques centrales font face au meme dilemme que la Fed : le petrole au-dessus de 100 dollars interdit les baisses de taux, mais le ralentissement economique les justifierait. La BoJ se reunit vendredi 14 mars — le yen faible (158,58) et le petrole cher creent une pression inflationniste au Japon qui pourrait justifier une nouvelle hausse. La BNS (20 mars) est dans une position unique : le franc suisse fort (EUR/CHF a 0,8998, proche du plus haut depuis 2015) et l'inflation basse lui donnent plus de marge de manoeuvre que ses pairs — mais les reserves de change sont tombees a 710 milliards CHF en fevrier, leur plus bas depuis mai 2025. La PBoC maintient le statu quo mais pourrait assouplir si le ralentissement chinois s'intensifie. Le message global : les banques centrales sont paralysees par le choc petrolier.",

  geopolitics: [
    { title: "Conflit US-Iran — 7eme Jour, Aucune Desescalade", description: "Le conflit entre dans son 7eme jour. Trump refuse tout compromis ('pas de deal sans reddition inconditionnelle'). Le Qatar menace un force majeure sur les exportations du Golfe. Le Koweit coupe sa production. Le petrole depasse 103 dollars. Le Detroit d'Ormuz (20% du petrole mondial) reste le risque principal." },
    { title: "Plan de Relance Allemand — 800 Milliards EUR", description: "L'Allemagne a annonce un plan massif d'infrastructure et de defense de 800 milliards d'euros. C'est un tournant historique pour la politique budgetaire allemande, mais le choc petrolier a totalement eclipse l'impact positif. Le DAX perd 2,48% malgre cette annonce." },
    { title: "Chine — NPC et Relance Ciblee", description: "Le NPC a fixe un objectif de croissance de 5% pour 2026 et annonce des mesures de stimulus fiscal. Shanghai ne cede que 0,67% — la Chine joue un role de stabilisateur relatif dans la tempete." },
    { title: "Nikkei -5,24% — Pire Seance Depuis Aout 2024", description: "Le Nikkei plonge de 5,24% dimanche soir a 52 707,50. Le Japon souffre doublement : importateur net de petrole et yen faible. C'est un signal de fragilite structurelle pour la troisieme economie mondiale." },
  ],
  geopoliticsLecture: "La geopolitique est redevenue le premier driver des marches mondiaux. Le conflit US-Iran est le risque systemique numero un : le petrole au-dessus de 103 dollars dimanche soir, les menaces sur le Detroit d'Ormuz, et l'intransigeance de Trump creent un cocktail explosif. Le plan de relance allemand est structurellement positif pour l'Europe, mais son impact est noye dans le bruit geopolitique. La Chine joue un role stabilisateur avec ses injections de liquidites et son objectif de croissance a 5%. Le Nikkei -5,24% montre que les marches asiatiques sont fragiles — le Japon est le maillon faible de l'Asie developpee face au choc petrolier. La semaine prochaine sera dominee par le CPI americain (mercredi), la BoJ (vendredi) et les developpements en Iran — trois facteurs qui determineront si le choc petrolier se propage dans l'economie reelle.",

  scenarios: [
    { name: "Scenario Constructif", probability: "~10%", description: "Desescalade Iran, CPI US dovish, stimulus chinois amplifie. Rebond technique global de 2 a 4%.", signal: "Petrole sous 90$, VIX sous 22, Nikkei rebond" },
    { name: "Scenario Base", probability: "~40%", description: "Iran contenu sans escalade, CPI US entre 2,3% et 2,5%, BoJ statu quo. Consolidation avec volatilite extreme.", signal: "Petrole 95-115$, VIX 25-32, rotation defensive" },
    { name: "Scenario Negatif", probability: "~50%", description: "Escalade Iran, CPI US superieur a 2,6%, petrole vers 120$+. Sell-off global, emergents sous pression maximale.", signal: "Petrole superieur a 120$, VIX superieur a 35, Nikkei sous 50 000" },
  ],

  risks: [
    { title: "Petrole au-dessus de 120$ = Recession Mondiale", description: "Si le petrole se maintient au-dessus de 120 dollars, l'impact sur l'economie mondiale sera devastateur. L'Europe et le Japon, importateurs nets, seraient les plus touches. Le Qatar evoque explicitement la possibilite d'un petrole a 150 dollars." },
    { title: "Nikkei en Chute Libre — Contagion Asiatique", description: "Le Nikkei -5,24% dimanche soir est un signal d'alarme. Si la baisse se prolonge sous 50 000, les appels de marge et les ventes forcees pourraient provoquer une contagion vers les autres marches asiatiques." },
    { title: "Fermeture du Detroit d'Ormuz", description: "20% du petrole mondial transite par le Detroit d'Ormuz. Sa fermeture provoquerait un choc petrolier comparable a 1973 — le petrole pourrait depasser 150 dollars." },
    { title: "Banques Centrales Paralysees", description: "Le choc petrolier place toutes les banques centrales dans un dilemme impossible : baisser les taux pour soutenir la croissance alimenterait l'inflation, les maintenir aggraverait le ralentissement." },
  ],

  pdfUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663135061541/Wf8Nj4yLBCzwrPQSdtP8cC/monde-s11_a0c87e28.pdf",
  sources: "Donnees de marche : Yahoo Finance, cloture vendredi 6 mars 2026 + futures dimanche 8 mars 2026. Indices europeens : Euronext, LSE, Yahoo Finance. Indices asiatiques : TSE, HKEX, SSE, Yahoo Finance. Commodities : NYMEX, ICE, Yahoo Finance. Geopolitique : Reuters, CNBC, WSJ, NPR. Banques centrales : BCE, BoJ, Fed, BNS. Donnees suisses : MarketScreener, rttnews.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance. Les marches financiers sont par nature imprevisibles.",
};
