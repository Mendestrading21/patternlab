/**
 * WMB Fil Rouge — Semaine 13 (LUN 17/03 → VEN 21/03 2026)
 * Données vérifiées : MarketWatch, Morningstar, AP, Investopedia, SWI swissinfo.ch
 */
import type { FilRougeModuleData } from "../filRouge";
export const FIL_ROUGE_SEMAINE_13: FilRougeModuleData = {
  id: 406,
  weekNumber: 13,
  year: 2026,
  dateRange: "LUN 17/03 → VEN 21/03",
  title: "4eme Semaine de Baisse, Fed Statu Quo, Petrole >$110 et Or en Chute Libre",
  subtitle: "FIL ROUGE",
  publishedAt: "2026-03-22T08:00:00Z",
  headerImage: "",
  delta: {
    summary: "Le S&P 500 enchaine sa 4eme semaine consecutive de baisse (-1,9%). Le FOMC maintient les taux a 3,50-3,75% comme attendu, mais le dot plot ne montre qu'une seule baisse en 2026. Le petrole depasse $112 sur fond de conflit Iran. L'or s'effondre de 10% sur la semaine — la pire chute depuis 2020. Le VIX bondit a 26,78. Le Russell 2000 entre en territoire de correction.",
    indices: [
      { name: "S&P 500", value: "6 506,48", change: "-1,90% (hebdo)" },
      { name: "Nasdaq Composite", value: "21 647,61", change: "-2,10% (hebdo)" },
      { name: "Dow Jones", value: "45 577,47", change: "-2,10% (hebdo)" },
      { name: "Russell 2000", value: "2 438,45", change: "-2,30% (hebdo)" },
      { name: "VIX", value: "26,78", change: "+11,3% (vendredi)" },
    ],
    commodities: [
      { name: "WTI", value: "98,10 $/b", change: "+2,6% (hebdo)" },
      { name: "Brent", value: "112,30 $/b", change: "+3,4% (hebdo)" },
      { name: "Or (Comex)", value: "4 507 $/oz", change: "-10,23% (hebdo)" },
    ],
    crypto: [
      { name: "Bitcoin", value: "69 907 $", change: "-1,44% (hebdo)" },
      { name: "Ethereum", value: "2 134 $", change: "-2,10% (hebdo)" },
    ],
    lectureWMB: "La semaine 13 est marquee par trois faits majeurs. Premierement, la Fed maintient les taux mais le dot plot ne montre qu'une seule baisse en 2026 — le marche perd l'espoir de baisses multiples. Deuxiemement, le petrole depasse $112 sur fond de conflit Iran — chaque $10 de hausse ajoute +0,35% a l'inflation US. Troisiemement, l'or s'effondre de 10% en une semaine — la pire chute depuis 2020, liee a la hausse des taux reels et aux appels de marge. Le VIX a 26,78 confirme un regime de stress. Le Russell 2000 en correction signale que les petites capitalisations, plus sensibles au credit, souffrent le plus. Le Bitcoin passe sous $70 000 — la correlation avec les actifs risques reste elevee.",
  },
  agenda72h: [
    "LUNDI 23/03 — Construction Spending (janvier). Pas de catalyseur macro majeur.",
    "MARDI 24/03 — Earnings : Smithfield Foods (SFD), Core & Main (CNM). Conference Board Consumer Confidence (mars).",
    "MERCREDI 25/03 — Earnings : Chewy (CHWY), Cintas (CTAS), Paychex (PAYX), Jefferies (JEF). Durable Goods Orders (fevrier).",
    "JEUDI 26/03 — Initial Jobless Claims (semaine du 21/03). Earnings : Commercial Metals (CMC). GDP Q4 revision finale.",
    "VENDREDI 27/03 — PCE Price Index (fevrier) — CATALYSEUR MAJEUR. Earnings : Carnival (CCL) — test de l'impact Iran sur le tourisme.",
  ],
  watchlistUpdate: [
    { ticker: "MU", status: "Earnings spectaculaires : EPS $12,20 (vs $1,56 YoY). Le titre a bondi de 8% apres la cloture. La demande HBM pour l'IA est explosive.", level: "105,00$" },
    { ticker: "XOM", status: "Beneficiaire direct du petrole >$110. Le secteur Energy est le seul en hausse cette semaine (+2,99%).", level: "128,00$" },
    { ticker: "CCL", status: "Earnings vendredi 27/03 — test critique de l'impact du conflit Iran sur le tourisme et les croisieres.", level: "18,50$" },
    { ticker: "SEDG", status: "Top gainer de la semaine a +38% — rebond technique massif sur le solaire.", level: "28,00$" },
    { ticker: "KLAR", status: "Top loser de la semaine a -20,8% — la fintech suedoise chute apres des resultats decevants.", level: "42,00$" },
  ],
  riskAlert: "RISQUE PRINCIPAL : PCE vendredi 27 mars. C'est l'indicateur d'inflation prefere de la Fed. Si le Core PCE depasse 2,8% (consensus 2,7%), le marche pourrait perdre 3-5% en une seance — cela confirmerait le scenario de stagflation (inflation en hausse + croissance en baisse). RISQUE SECONDAIRE : Petrole. Si le Brent depasse $120 (escalade Iran au Detroit d'Ormuz), l'impact sur l'inflation serait immediat et severe. Chaque $10 de hausse = +0,35% d'inflation US. RISQUE CREDIT : Le VIX a 26,78 et la hausse des taux reels (10Y a 4,39%) compriment les conditions financieres. Les spreads HY sont a surveiller — un franchissement de 400 bps declencherait des ventes forcees. RISQUE TRANSITION FED : Kevin Warsh remplace Powell en mai — incertitude sur la politique monetaire future.",
  sources: "Donnees de marche : MarketWatch, Morningstar, AP, Investopedia, AA. Fed : communique FOMC 18 mars 2026. Cloture vendredi 20 mars 2026.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
};
