/**
 * WMB Suisse — Semaine 14 (LUN 24/03 → VEN 28/03 2026)
 * Données vérifiées : Lombard Odier, SIX, BNS, Trading Economics, Reuters
 * Clôture vendredi 27 mars 2026
 */
import type { SuisseModuleData } from "../suisse";
export const SUISSE_SEMAINE_14: SuisseModuleData = {
  id: 207,
  weekNumber: 14,
  year: 2026,
  dateRange: "LUN 24/03 → VEN 28/03",
  title: "SMI en Baisse, BNS a 0% Sans Marge, CHF Refuge Absolu",
  subtitle: "MODULE SUISSE",
  publishedAt: "2026-03-29T07:00:00Z",
  headerImage: "",
  executiveSummary: {
    weekPast: [
      "Le SMI recule d'environ 1,2% sur la semaine, entraine par le sell-off mondial et le petrole au-dessus de $100. Les valeurs exportatrices souffrent du CHF fort.",
      "La BNS a maintenu son taux directeur a 0,00% le 20 mars. Comme l'analyse Lombard Odier : la BNS est 'prudente' et se concentre sur le franc dans un contexte d'incertitude.",
      "Le CHF se renforce encore — USD/CHF a 0,8814, EUR/CHF autour de 0,948. Le franc reste la valeur refuge par excellence en Europe.",
      "Nestle, Roche et Novartis reculent — les trois poids lourds du SMI sont sous pression du CHF fort et du ralentissement mondial.",
      "L'inflation suisse reste proche de zero (0,1-0,3%) — le risque deflationniste persiste malgre le petrole cher.",
    ],
    weekAhead: [
      "Pas de reunion BNS prevue avant juin 2026. Surveillance des declarations des membres sur l'impact du petrole.",
      "KOF Barometer a surveiller — indicateur avance de l'economie suisse.",
      "Surveillance du CHF : si le franc continue de se renforcer, la BNS pourrait intervenir verbalement.",
      "Earnings suisses : pas de gros resultats cette semaine, mais surveillance de l'impact du petrole sur les industriels.",
    ],
    lectureWMB: "La Suisse est dans une position unique : le CHF fort protege le pouvoir d'achat des consommateurs face au petrole cher, mais penalise les exportateurs. La BNS a 0% n'a plus aucune marge de manoeuvre — elle ne peut ni baisser (deja a zero) ni monter (inflation proche de zero). Le SMI souffre moins que les indices US (-1,2% vs -1,67% pour le S&P 500) grace a son caractere defensif (pharma, alimentation), mais la tendance reste baissiere. Le franc suisse est le grand gagnant de cette crise — il joue pleinement son role de valeur refuge.",
  },
  chf: [
    { pair: "USD/CHF", value: "0,8814", change1W: "+0,20%" },
    { pair: "EUR/CHF", value: "~0,948", change1W: "-0,15%" },
    { pair: "GBP/CHF", value: "~1,138", change1W: "-0,30%" },
    { pair: "CHF/JPY", value: "~169,5", change1W: "+0,40%" },
  ],
  chfLecture: "Le franc suisse continue de se renforcer face a toutes les devises sauf le dollar (USD/CHF +0,20% sur la semaine). L'EUR/CHF recule a ~0,948 — l'euro souffre de l'exposition energetique europeenne. Comme l'analyse Lombard Odier, la BNS se concentre sur le franc dans un contexte d'incertitude. Le CHF est la devise la plus forte d'Europe — son statut de valeur refuge est renforce par le conflit Iran et la stabilite politique suisse. Le risque : un CHF trop fort penalise les exportateurs (horlogerie, machines, pharma export).",
  bns: {
    rate: "0,00%",
    inflation: "~0,1-0,3% (proche de zero)",
    nextMeeting: "Juin 2026",
    stance: "Prudente — focus sur le franc et l'incertitude mondiale. Pas de marge pour baisser davantage.",
    lectureWMB: "La BNS est dans une impasse totale. Le taux directeur a 0% signifie zero marge de manoeuvre conventionnelle. L'inflation proche de zero (0,1-0,3%) ne justifie pas une hausse. Le CHF fort est un probleme pour les exportateurs mais un bouclier pour les consommateurs face au petrole cher. Lombard Odier note que la BNS reste 'prudente' et se concentre sur le franc — une intervention verbale ou sur le marche des changes est possible si le CHF se renforce trop rapidement. La prochaine reunion en juin sera cruciale — d'ici la, la BNS navigue a vue.",
  },
  blueChips: [
    { ticker: "NESN", value: "~CHF 88", change1W: "-1,30%" },
    { ticker: "ROG", value: "~CHF 265", change1W: "-0,80%" },
    { ticker: "NOVN", value: "~CHF 92", change1W: "-0,90%" },
    { ticker: "UBSG", value: "~CHF 28", change1W: "-1,50%" },
    { ticker: "ZURN", value: "~CHF 540", change1W: "-0,60%" },
    { ticker: "ABBN", value: "~CHF 48", change1W: "-1,80%" },
  ],
  blueChipsLecture: "Les blue chips suisses sont toutes en baisse. ABB (-1,8%) est le plus penalise — l'industriel souffre du ralentissement du commerce mondial et du petrole cher. UBS (-1,5%) recule sur les craintes de credit et la volatilite des marches. Nestle (-1,3%) est sous pression du CHF fort qui penalise les revenus a l'etranger. Roche (-0,8%) et Novartis (-0,9%) resistent mieux grace a leur caractere defensif. Zurich Insurance (-0,6%) est le plus resilient — les assureurs beneficient des taux eleves.",
  topMovers: [
    { ticker: "SLHN", value: "~CHF 280", change1W: "+1,20%" },
    { ticker: "SREN", value: "~CHF 130", change1W: "+0,80%" },
    { ticker: "SCMN", value: "~CHF 82", change1W: "+0,50%" },
  ],
  topMoversLecture: "Les gagnants de la semaine sont les valeurs defensives et les assureurs. Swiss Life (+1,2%) beneficie des taux eleves et de la demande pour les produits d'assurance-vie. Swiss Re (+0,8%) profite du meme theme. Swisscom (+0,5%) est defensif par nature — les telecoms resistent dans les periodes de stress.",
  flopMovers: [
    { ticker: "ABBN", value: "~CHF 48", change1W: "-1,80%" },
    { ticker: "LONN", value: "~CHF 520", change1W: "-2,10%" },
    { ticker: "GEBN", value: "~CHF 115", change1W: "-1,90%" },
  ],
  flopMoversLecture: "Les perdants sont les industriels et les cycliques. Lonza (-2,1%) souffre du ralentissement mondial et des craintes sur la demande pharma. Geberit (-1,9%) est penalise par la hausse des taux longs qui pese sur la construction. ABB (-1,8%) est expose au commerce mondial et au petrole cher.",
  economy: {
    gdp: "+0,1% T4 2025 (stagnation)",
    unemployment: "~2,5% (stable, bas historique)",
    kof: "~100 (neutre)",
    highlights: [
      "L'economie suisse stagne — PIB +0,1% au T4 2025. Le CHF fort pese sur les exportations.",
      "Le chomage reste bas a ~2,5% — le marche du travail est resilient.",
      "L'inflation proche de zero (0,1-0,3%) — risque deflationniste persistant malgre le petrole cher.",
      "Le KOF Barometer autour de 100 — signal neutre, ni expansion ni contraction.",
      "Le petrole cher est partiellement compense par le CHF fort — l'impact sur le consommateur suisse est moindre qu'en zone euro.",
    ],
    lectureWMB: "L'economie suisse est en stagnation douce. Le PIB a +0,1% est decevant mais le chomage a 2,5% montre un marche du travail solide. Le paradoxe suisse : l'inflation est proche de zero malgre le petrole au-dessus de $100 — le CHF fort absorbe une grande partie du choc energetique. C'est un avantage pour le consommateur suisse mais un probleme pour la BNS qui ne peut pas justifier une hausse de taux. La Suisse reste un ilot de stabilite relative dans un monde en crise.",
  },
  scenarios: [
    { name: "Constructif", probability: "15%", description: "Desescalade Iran, petrole sous $90, CHF se stabilise — SMI rebondit vers 12 800-13 000.", signal: "EUR/CHF au-dessus de 0,96, VIX sous 22" },
    { name: "Base", probability: "50%", description: "Statu quo geopolitique, CHF reste fort, SMI consolide entre 11 800-12 400.", signal: "EUR/CHF 0,94-0,96, SMI range" },
    { name: "Negatif", probability: "35%", description: "Escalade Iran, petrole >$120, CHF s'envole — SMI sous 11 500, BNS intervient.", signal: "EUR/CHF sous 0,93, SMI sous 11 500" },
  ],
  risks: [
    { title: "CHF trop fort = Pression exportateurs", description: "Si l'EUR/CHF passe sous 0,93, les exportateurs suisses (horlogerie, machines, pharma) seront severement penalises. La BNS pourrait etre forcee d'intervenir." },
    { title: "BNS a 0% = Aucune marge", description: "La BNS ne peut ni baisser (deja a zero) ni monter (inflation nulle) les taux. En cas de crise, les outils conventionnels sont epuises." },
    { title: "Stagnation prolongee", description: "Le PIB a +0,1% pourrait devenir negatif si le commerce mondial ralentit davantage. La Suisse est une economie ouverte, dependante des exportations." },
    { title: "Deflation", description: "L'inflation proche de zero pourrait basculer en deflation si le CHF continue de se renforcer. Un scenario que la BNS veut absolument eviter." },
  ],
  pdfUrl: "",
  sources: "Donnees de marche : SIX Swiss Exchange, Lombard Odier, Trading Economics, Reuters, cloture vendredi 27 mars 2026. BNS : communique du 20 mars 2026. Economie : SECO, KOF.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
};
