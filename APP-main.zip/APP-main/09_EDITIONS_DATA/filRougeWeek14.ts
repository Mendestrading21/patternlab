/**
 * WMB Fil Rouge — Semaine 14 (MER 26/03 2026)
 * Données vérifiées : CNBC, Reuters, MLQ, Trading Economics, WSJ
 * Point mi-semaine — Clôture mercredi 26 mars 2026
 */
import type { FilRougeModuleData } from "../filRouge";
export const FIL_ROUGE_SEMAINE_14: FilRougeModuleData = {
  id: 407,
  weekNumber: 14,
  year: 2026,
  dateRange: "MER 26/03 2026",
  title: "5e Semaine de Pertes, Nasdaq en Correction, Iran Escalade — Risk-Off Total",
  subtitle: "Delta marche, agenda 72h, watchlist, alerte petrole/Iran/stagflation",
  publishedAt: "2026-03-29T07:00:00Z",
  pdfUrl: "",
  headerImage: "",
  delta: {
    summary: "Le S&P 500 boucle sa 5e semaine consecutive de pertes — la pire serie depuis 2022. Le Nasdaq entre officiellement en correction (-10,27% depuis le pic). Le petrole au-dessus de $100 est le catalyseur central. Le VIX a 30,43 signale un marche en mode stress. Les Mag 7 ont perdu $850 milliards de capitalisation en une seule semaine. Le regime de marche bascule de 'correction ordonnee' a 'risk-off generalise'.",
    indices: [
      { name: "S&P 500", value: "5 580,94", change: "-1,67% (5e semaine de baisse)" },
      { name: "Dow Jones", value: "41 583,90", change: "-1,00% (5e semaine de baisse)" },
      { name: "Nasdaq", value: "17 322,99", change: "-2,59% (correction officielle -10,27%)" },
      { name: "Russell 2000", value: "~2 010", change: "-2,80% (bear market -20%+ depuis pic)" },
      { name: "VIX", value: "30,43", change: "+22% (zone de stress)" },
    ],
    commodities: [
      { name: "Petrole WTI", value: "$101,40", change: "+4,2% (au-dessus de $100)" },
      { name: "Petrole Brent", value: "$105,20", change: "+3,8%" },
      { name: "Or", value: "$2 940", change: "-2,1% (liquidation pour couvrir les marges)" },
      { name: "Argent", value: "$32,50", change: "-1,5%" },
    ],
    crypto: [
      { name: "Bitcoin", value: "$84 300", change: "-3,5% (correlation risk-off)" },
      { name: "Ethereum", value: "$1 980", change: "-5,2%" },
    ],
    lectureWMB: "Le delta de la semaine confirme le basculement en mode risk-off. Le S&P 500 perd 1,67% — c'est la 5e semaine consecutive de baisse, du jamais vu depuis 2022. Le Nasdaq entre en correction officielle a -10,27% depuis son pic. Le petrole au-dessus de $100 est le facteur dominant — il pousse les taux a la hausse (10Y a 4,44%), comprime les multiples tech, et menace la consommation. L'or recule paradoxalement (-2,1%) car les investisseurs liquident pour couvrir les appels de marge — un signal de stress, pas de confiance. Le Bitcoin suit le mouvement risk-off. Le VIX a 30,43 est le signal le plus clair : le marche est en mode peur.",
  },
  agenda72h: [
    "Lundi 30/03 — Fed Chair Powell Speech (14:30 UTC) : Le marche cherchera des indices sur la reaction de la Fed au petrole >$100 et a l'inflation. Ton hawkish = sell-off supplementaire. Ton dovish = rallye de soulagement.",
    "Mardi 31/03 — Nike (NKE) Earnings After-Hours : Test direct du consommateur americain. Consumer Discretionary a -12% MTD. Si Nike guide a la baisse, c'est un signal de recession consommateur.",
    "Mercredi 01/04 — ISM Manufacturing PMI (10:00 ET) : Sous 50 = contraction. Le secteur manufacturier est sous pression du petrole cher et des tarifs.",
    "Vendredi 03/04 — Nonfarm Payrolls NFP (08:30 ET) : Le chiffre le plus important du mois. Un NFP faible + inflation elevee = stagflation confirmee. Un NFP fort = la Fed peut rester patiente.",
  ],
  watchlistUpdate: [
    { ticker: "META", status: "Survendue — CNBC identifie Meta parmi les plus survendues du S&P 500. Potentiel rebond technique si VIX retombe sous 25.", level: "ALERTE" },
    { ticker: "NVDA", status: "Correction -14% YTD — demande IA intacte (Micron confirme) mais multiple en compression. Surveiller earnings Q1.", level: "SURVEILLANCE" },
    { ticker: "XOM", status: "Momentum — petrole >$100, Goldman upgrade $130+. Marges record. Risque : desescalade Iran = correction 10-15%.", level: "MOMENTUM" },
    { ticker: "NKE", status: "Earnings mardi — test du consommateur. Consumer sentiment a 53,3, essence a $3,96/gallon. Consensus ~$0,75 EPS.", level: "CATALYSEUR" },
    { ticker: "RTX", status: "Defense +22% MTD — beneficiaire direct du conflit Iran. Carnets de commandes records.", level: "MOMENTUM" },
  ],
  riskAlert: "ALERTE RISQUE ELEVEE — Le petrole au-dessus de $100 est le risque numero 1. Chaque hausse de $10 du petrole ajoute ~0,5% a l'inflation US et reduit le PIB de 0,3% (Goldman Sachs). Le scenario d'escalade Iran (frappes sur Hormuz, petrole >$120) ferait basculer le marche en bear market. Le VIX a 30,43 est a son plus haut de 2026. Les spreads HY a 440 bps signalent un stress credit naissant. Le consumer sentiment a 53,3 est au plus bas de 2026. La combinaison petrole + taux + geopolitique cree un cocktail explosif. Semaine S15 decisive : Powell lundi, Nike mardi, ISM mercredi, NFP vendredi. Quatre catalyseurs en 5 jours qui peuvent faire basculer le marche dans un sens ou dans l'autre.",
  sources: "CNBC, Reuters, MLQ, WSJ, Trading Economics, Goldman Sachs, AIMS FX, ABC News, Business Insider, Lombard Odier. Cloture vendredi 27 mars 2026.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
};
