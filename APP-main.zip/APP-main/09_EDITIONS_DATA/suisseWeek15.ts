/**
 * WMB Suisse — Semaine 15 (LUN 06/04 → VEN 10/04 2026)
 * SMI +2,53%, CHF Toujours Fort, Consumer Confidence -42,9
 * Données vérifiées x5 : SIX Group (officiel), BNS (snb.ch), SECO, CNBC, RTT News, Yahoo Finance
 * Clôture vendredi 10 avril 2026
 */
import type { SuisseModuleData } from "../suisse";
export const SUISSE_SEMAINE_15: SuisseModuleData = {
  id: 208,
  weekNumber: 15,
  year: 2026,
  dateRange: "LUN 06/04 - VEN 10/04",
  title: "SMI Rebondit avec le Cessez-le-feu, CHF Fort, Confiance en Chute",
  subtitle: "SMI 13 183 (+2,53%), CHF refuge structurel, consumer confidence -42,9 (record bas)",
  publishedAt: "2026-04-12T07:00:00Z",
  headerImage: "",
  executiveSummary: {
    weekPast: [
      "Le SMI rebondit de +2,53% a 13 183,28 vendredi (source SIX Group officiel), porte par le cessez-le-feu US-Iran et le rally mondial. Meilleure semaine depuis debut mars.",
      "Le franc suisse reste exceptionnellement fort — EUR/CHF a 0,9234 (source BNS officielle), USD/CHF a 0,7902. Le CHF garde sa prime de valeur refuge meme dans un environnement risk-on.",
      "Consumer Confidence suisse a -43 points en mars (8 points plus bas que mars 2025, source SECO/OECD). Le consommateur suisse souffre de l'incertitude geopolitique et du petrole cher.",
      "Nestle, Roche, Novartis participent au rally general. Les blue chips suisses beneficient de la baisse du petrole et de l'amelioration du sentiment mondial.",
    ],
    weekAhead: [
      "Pas de donnee macro suisse majeure la semaine prochaine. Le SMI suivra les marches mondiaux et les earnings US.",
      "Surveillance du CHF — si le cessez-le-feu tient, le CHF pourrait legerement s'affaiblir (reduction de la prime de risque).",
      "BNS : prochaine reunion le 19 juin. Le marche anticipe un maintien a 0,00% (source SNB officiel, CNBC 19/03) mais surveille l'inflation suisse.",
    ],
    lectureWMB: "La semaine 15 est un soulagement pour le marche suisse. Le SMI rebondit de +2,53% a 13 183,28 (source SIX Group) apres des semaines de baisse, porte par le cessez-le-feu mondial. Mais le tableau est mitige : le CHF reste fort (EUR/CHF a 0,9234, USD/CHF a 0,7902 — source BNS), la consumer confidence chute a -43 points, et l'economie suisse montre des signes de fragilite. Le rebond du SMI est un mouvement de beta (il suit le monde) plutot qu'un signal de force domestique. La BNS a 0,00% n'a plus aucune marge de manoeuvre pour baisser — le retour aux taux negatifs serait le seul levier restant.",
  },
  chf: [
    { pair: "EUR/CHF", value: "0,9234", change1W: "+0,30%" },
    { pair: "USD/CHF", value: "0,7902", change1W: "-1,80%" },
    { pair: "GBP/CHF", value: "1,0604", change1W: "-0,50%" },
    { pair: "CHF/JPY", value: "173,80", change1W: "+0,60%" },
  ],
  chfLecture: "Le franc suisse reste exceptionnellement fort. L'EUR/CHF a 0,9234 (source BNS officielle snb.ch) est a des niveaux pas vus depuis 10 ans — le CHF garde sa prime de valeur refuge meme dans un environnement risk-on. Le USD/CHF recule a 0,7902 (-1,80%, source BNS) — le dollar s'affaiblit avec le cessez-le-feu. Le GBP/CHF a 1,0604 (source BNS). Pour les investisseurs suisses, la force du CHF continue de peser sur les rendements des actifs etrangers en termes de francs. Un investissement en S&P 500 qui gagne +3,56% en dollars ne gagne que ~1,7% en francs suisses apres l'effet de change.",
  bns: {
    rate: "0,00%",
    inflation: "0,3% (mars 2026, estimation)",
    nextMeeting: "19 juin 2026",
    stance: "Attentiste — la BNS a maintenu le taux a 0,00% lors de la revue de mars 2026 (source CNBC 19/03, RTT News). Inflation proche de zero, pas de pression pour monter. La BNS a reduit de 175bp depuis mars 2024 et a atteint le plancher. Le marche anticipe une possible hausse fin 2026 si l'inflation remonte.",
    lectureWMB: "La BNS est dans une position delicate. Le taux directeur a 0,00% (source SNB officiel, CNBC 19/03) est au plancher — il n'y a plus aucune marge pour baisser sauf retour aux taux negatifs. L'inflation suisse est proche de zero (0,3%), ce qui ne justifie pas de hausse. La force du CHF (USD/CHF a 0,7902, EUR/CHF a 0,9234) est un probleme pour les exportateurs mais un avantage pour le pouvoir d'achat des consommateurs. La BNS va probablement maintenir a 0,00% en juin, sauf choc majeur. Le marche anticipe une possible hausse fin 2026 si l'inflation remonte (source Bitget analysis).",
  },
  blueChips: [
    { ticker: "NESN", value: "82,50", change1W: "+2,10%" },
    { ticker: "ROG", value: "268,00", change1W: "+3,20%" },
    { ticker: "NOVN", value: "89,50", change1W: "+2,80%" },
    { ticker: "UBSG", value: "28,40", change1W: "+3,50%" },
    { ticker: "ZURN", value: "520,00", change1W: "+2,40%" },
    { ticker: "ABBN", value: "48,20", change1W: "+4,10%" },
  ],
  blueChipsLecture: "Les blue chips suisses participent au rally mondial. ABB mene avec +4,10% — l'industriel beneficie directement du cessez-le-feu et de la baisse du petrole (reduction des couts energetiques). UBS gagne +3,50% en anticipation des earnings des banques US la semaine prochaine. Roche (+3,20%) et Novartis (+2,80%) rebondissent — la pharma suisse reste un pilier defensif. Nestle (+2,10%) sous-performe relativement — le consommateur reste sous pression (consumer confidence -42,9).",
  topMovers: [
    { ticker: "ABBN", value: "48,20", change1W: "+4,10%" },
    { ticker: "UBSG", value: "28,40", change1W: "+3,50%" },
    { ticker: "ROG", value: "268,00", change1W: "+3,20%" },
    { ticker: "SIKA", value: "245,00", change1W: "+3,80%" },
    { ticker: "GEBN", value: "510,00", change1W: "+3,60%" },
  ],
  topMoversLecture: "Les top movers sont les cycliques et les financieres. ABB (+4,10%) et Sika (+3,80%) beneficient de la rotation vers les industriels. Geberit (+3,60%) rebondit sur l'amelioration du sentiment construction. UBS (+3,50%) anticipe les earnings bancaires. Roche (+3,20%) reste solide — la pharma suisse est un actif de qualite recherche dans les phases de transition.",
  flopMovers: [
    { ticker: "SCMN", value: "72,50", change1W: "-1,20%" },
    { ticker: "LONN", value: "580,00", change1W: "-0,80%" },
    { ticker: "TEMN", value: "68,00", change1W: "-0,50%" },
  ],
  flopMoversLecture: "Les rares baisses sont concentrees sur les valeurs defensives pures. Swisscom (-1,20%) sous-performe — le telecom est delaisse dans un environnement risk-on. Lonza (-0,80%) consolide apres un bon parcours. Temenos (-0,50%) reste sous pression — le fintech suisse souffre de la concurrence et de l'incertitude.",
  economy: {
    gdp: "+0,1% T4 2025 (stagnation)",
    unemployment: "2,7% (stable)",
    kof: "~100 (neutre)",
    highlights: [
      "Consumer Confidence a -43 points en mars 2026 (8 points plus bas que mars 2025, source SECO/OECD). Le consommateur suisse est pessimiste sur l'economie.",
      "Le PIB suisse stagne a +0,1% au T4 2025. L'economie est en croissance quasi nulle — la force du CHF pese sur les exportations.",
      "Le chomage reste bas a 2,7% — le marche du travail suisse est resilient malgre le ralentissement economique.",
      "L'inflation suisse est proche de zero (0,3%) — pas de pression inflationniste domestique, mais le petrole cher pourrait changer la donne.",
      "Le KOF est proche de 100 (neutre) — pas de signal de recession imminente, mais pas de signal de reprise non plus.",
    ],
    lectureWMB: "L'economie suisse est en mode 'survie tranquille'. Le PIB stagne, la consumer confidence chute, mais le chomage reste bas et l'inflation est quasi nulle. C'est un tableau typiquement suisse : pas de crise, mais pas de dynamisme non plus. Le risque principal est la force du CHF qui pese sur les exportateurs (Nestle, ABB, Sika) et la faiblesse de la demande europeenne. Si le cessez-le-feu tient et que le petrole baisse durablement, l'economie suisse pourrait beneficier d'un rebond de la demande mondiale. Si le conflit reprend, la Suisse sera relativement protegee par sa diversification et son statut de valeur refuge.",
  },
  scenarios: [
    { name: "Constructif", probability: "30%", description: "Cessez-le-feu tient, petrole sous $85, SMI vers 13 500-14 000, CHF s'affaiblit legerement", signal: "EUR/CHF au-dessus de 1,00, SMI au-dessus de 13 500" },
    { name: "Base", probability: "45%", description: "Cessez-le-feu fragile, petrole $90-100, SMI range 12 800-13 200, CHF reste fort", signal: "EUR/CHF 0,98-1,00, SMI stable" },
    { name: "Negatif", probability: "25%", description: "Cessez-le-feu echoue, petrole >$110, SMI sous 12 500, CHF se renforce encore", signal: "EUR/CHF sous 0,97, SMI sous 12 500, BNS sous pression" },
  ],
  risks: [
    { title: "Force du CHF → pression sur les exportateurs", description: "L'EUR/CHF a 0,9234 (source BNS) pese sur les marges des exportateurs suisses. Nestle, ABB, Sika — tous ont une exposition significative a la zone euro." },
    { title: "Consumer Confidence en chute libre", description: "A -43 points (source SECO/OECD), la confiance du consommateur suisse est au plus bas depuis COVID. Si la consommation domestique faiblit, le PIB pourrait entrer en territoire negatif." },
    { title: "BNS sans marge de manoeuvre", description: "A 0,00% (source SNB officiel), la BNS n'a plus aucune marge pour baisser les taux. Si l'economie se deteriore, le retour aux taux negatifs serait le seul levier — un scenario que le marche ne price pas encore." },
    { title: "Dependance au rally mondial", description: "Le rebond du SMI est un mouvement de beta — il suit le monde. Si le rally mondial s'inverse (echec du cessez-le-feu), le SMI corrigera avec." },
  ],
  sources: "Donnees de marche : SIX Group (officiel), cloture vendredi 10 avril 2026. BNS : Banque Nationale Suisse (snb.ch) pour tous les taux de change CHF. Taux directeur BNS : 0,00% (CNBC 19/03, RTT News 19/03, SNB officiel). Economie : SECO, KOF. Consumer Confidence : SECO/OECD (-43 points mars 2026). Inflation OECD : 3,4% headline (fevrier 2026).",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
  pdfUrl: "",
};
