/**
 * WMB Brief USA — Semaine 8 (16/02 – 20/02/2026)
 * Fed Minutes, Walmart Earnings & Rebond Tech — Marché en Équilibre
 */
import type { BriefData } from "../brief";

export const BRIEF_SEMAINE_8: BriefData = {
  id: 3,
  weekNumber: 8,
  year: 2026,
  dateRange: "LUN 16/02 - VEN 20/02",
  title: "Fed Minutes, Walmart Earnings & Rebond Tech -- Marche en Equilibre",
  subtitle: "Minutes FOMC, Walmart Q4, rebond tech, marché en consolidation",
  publishedAt: "2026-02-15T08:00:00Z",

  executiveSummary: {
    weekPast: [
      "S&P 500 en hausse de +1.1% — rebond technique après la correction de début février",
      "CPI de janvier à 3.0% YoY — légèrement au-dessus des attentes (2.9%)",
      "Retail Sales en baisse de -0.9% — premier signal de faiblesse du consommateur",
      "Le Nasdaq rebondit de +1.8% porté par les semi-conducteurs",
      "L'or franchit les 4 700 $/oz pour la première fois"
    ],
    weekAhead: [
      "Minutes du FOMC mercredi — détails sur le débat interne de la Fed",
      "Walmart Q4 earnings jeudi avant l'ouverture — baromètre de la consommation",
      "PMI Flash (S&P Global) vendredi — premier indicateur d'activité de février",
      "Existing Home Sales jeudi — santé du marché immobilier",
      "Lundi férié (Presidents' Day) — marchés fermés"
    ],
    lectureWMB: "La semaine 8 est une semaine de transition. Le marché a rebondi après la correction de début février mais le CPI au-dessus des attentes a refroidi les espoirs de baisse de taux. Les minutes du FOMC donneront le ton : si les membres sont plus hawkish qu'attendu, le rebond pourrait s'essouffler. Walmart est le baromètre ultime de la consommation US — après les Retail Sales décevantes, le marché sera très attentif à leurs commentaires sur le consommateur."
  },

  indices: [
    { ticker: "SPX", value: "6 040", change1W: "+1.1%", changeYTD: "+2.5%" },
    { ticker: "NDX", value: "21 630", change1W: "+1.8%", changeYTD: "+4.4%" },
    { ticker: "DJIA", value: "44 050", change1W: "+0.6%", changeYTD: "+2.8%" },
    { ticker: "RUT", value: "2 310", change1W: "+0.9%", changeYTD: "+0.8%" }
  ],
  indicesSignal: "Rebond technique en cours — le S&P 500 reconquiert les 6 000. Le Nasdaq mène, signe que le risk-on revient.",
  indicesInvalidation: "Clôture sous 5 980 sur le S&P 500 invaliderait le rebond et ouvrirait la voie vers 5 900.",
  indicesLecture: "Le rebond de la semaine 7 se confirme avec le S&P 500 qui reconquiert les 6 040. Le Nasdaq mène (+1.8%) porté par les semi-conducteurs (SOX +3.2%). Le Dow sous-performe (+0.6%) car les défensives marquent une pause après leur surperformance récente. Les small caps (Russell +0.9%) participent au rebond, ce qui est un signe de santé. Le volume reste modéré, ce qui tempère l'optimisme — un rebond sur faible volume est souvent fragile.",

  vix: {
    value: "15.40",
    regime: "Volatilité normale — retour au calme après le spike de début février",
    watch: "VIX pourrait remonter si les minutes du FOMC sont hawkish mercredi.",
    lectureWMB: "Le VIX est revenu à 15.40 après avoir touché 19 début février sur le CPI surprise. Ce retour au calme est cohérent avec le rebond des indices. Cependant, le VIX reste au-dessus de sa moyenne de janvier (~13), ce qui indique que le marché n'est pas totalement serein. Les minutes du FOMC mercredi sont le prochain catalyseur de volatilité. Historiquement, les minutes provoquent un mouvement de 0.5-1% sur le S&P dans les 2 heures suivant la publication."
  },

  fx: [
    { pair: "DXY", value: "101.20", note: "Dollar en légère hausse — soutenu par le CPI au-dessus des attentes" },
    { pair: "EUR/USD", value: "1.075", note: "Euro faible — BCE dovish, données européennes mitigées" },
    { pair: "USD/CHF", value: "0.89", note: "Franc suisse stable — pas de stress majeur" }
  ],
  fxAlert: "Niveau d'alerte : DXY > 102.5 (confirmerait un renforcement du dollar sur les taux élevés)",
  fxInvalidation: "Niveau d'invalidation : DXY < 100 (retour à la faiblesse, signal dovish)",
  fxLecture: "Le dollar se renforce légèrement à 101.20 après le CPI au-dessus des attentes. La logique est simple : inflation plus élevée = taux plus hauts plus longtemps = dollar plus fort. L'EUR/USD recule à 1.075 car la BCE est perçue comme plus dovish que la Fed. Le CHF reste stable à 0.89, sans flux refuge significatif. Pour les investisseurs suisses, le léger renforcement du dollar est positif pour les positions en actifs US.",

  rates: [
    { label: "Taux 10 ans US", value: "4.32%", note: "En hausse — CPI au-dessus des attentes repousse les baisses de taux" },
    { label: "Taux 2 ans US", value: "4.20%", note: "Hausse marquée — marché reprice les attentes Fed" },
    { label: "Courbe 2s10s", value: "+12 bps", note: "Quasi plate — incertitude sur la politique monétaire" }
  ],
  fedFunds: "4.25% – 4.50%",
  fedProba: "Statu quo en mars : ~99%. Première baisse possible en juin (~40% de probabilité).",
  ratesLecture: "Le CPI de la semaine 7 a provoqué un repricing significatif des taux. Le 10 ans est remonté à 4.32% et le 2 ans à 4.20%. Le marché ne price plus que 40% de probabilité d'une baisse en juin (vs 55% avant le CPI). Les minutes du FOMC mercredi sont cruciales : si les membres expriment des inquiétudes sur l'inflation sticky, les taux pourraient tester 4.40%. À l'inverse, un ton plus équilibré pourrait ramener le 10 ans vers 4.25%.",

  credit: {
    spreadsIG: "Spreads IG à ~82 bps — conditions de crédit excellentes",
    spreadsHY: "Spreads HY à ~305 bps — pas de stress",
    sofr: "SOFR à 4.31% — liquidité abondante",
    alert: "Surveiller : émissions HY en hausse — les entreprises profitent des conditions favorables",
    lectureWMB: "Le marché du crédit reste en excellente santé. Les spreads IG à 82 bps sont proches de leurs plus bas historiques. Les émissions obligataires sont soutenues, avec $45B d'IG émis la semaine dernière — les entreprises profitent des conditions favorables avant une éventuelle détérioration. Le HY à 305 bps ne montre aucun signe de stress. Le seul point d'attention : la concentration des émissions dans le secteur tech/IA pourrait créer un risque sectoriel si la thèse IA déçoit."
  },

  commodities: [
    { name: "Or", symbol: "XAU", value: "~4 720 $/oz", note: "Nouveau record — achats banques centrales + inflation sticky" },
    { name: "Argent", symbol: "XAG", value: "~68 $/oz", note: "Suit l'or — ratio or/argent élevé" },
    { name: "WTI", symbol: "CL", value: "~72.80 $", note: "Stable — OPEC+ maintient les coupes" },
    { name: "Brent", symbol: "BZ", value: "~76.50 $", note: "Légère prime géopolitique" },
    { name: "Cuivre", symbol: "HG", value: "~4.25 $/lb", note: "En hausse — optimisme sur la Chine" }
  ],
  commoditiesLecture: "L'or franchit les 4 700 $ pour la première fois, porté par les achats des banques centrales et l'inflation sticky. Le métal jaune est en hausse de +8% YTD. Le pétrole reste stable autour de 72-76 $, l'OPEC+ maintenant ses coupes de production. Le cuivre progresse sur l'optimisme lié aux stimulus chinois. Les matières premières agricoles sont sous pression sur les craintes de tarifs Trump (maïs -2%, soja -1.5%).",

  crypto: [
    { name: "Bitcoin", symbol: "BTC", value: "~95 000 $", note: "Rally continu — flux ETF spot record" },
    { name: "Ethereum", symbol: "ETH", value: "~3 400 $", note: "Rebond — upgrade Pectra en vue" },
    { name: "Solana", symbol: "SOL", value: "~170 $", note: "Surperformance — activité DeFi record" }
  ],
  cryptoLecture: "Le Bitcoin poursuit son rally vers les 100 000 $ avec des flux ETF spot record ($2.5B la semaine dernière). L'approbation de nouveaux ETF crypto (Solana, XRP) alimente l'optimisme. Ethereum rebondit à 3 400 $ avant l'upgrade Pectra prévue en mars. Le marché crypto est déconnecté des craintes macro — tant que les flux ETF restent positifs, la tendance est haussière.",

  keyPoints: [
    { title: "CPI au-dessus des attentes", description: "3.0% YoY vs 2.9% attendu. L'inflation reste sticky, repoussant les espoirs de baisse de taux." },
    { title: "Retail Sales en baisse", description: "-0.9% en janvier — la plus forte baisse depuis mars 2025. Le consommateur montre des signes de fatigue." },
    { title: "Rebond tech", description: "Le Nasdaq rebondit de +1.8% porté par les semi-conducteurs. NVIDIA +4%, AMD +3.5%, Broadcom +2.8%." },
    { title: "Or record", description: "L'or franchit 4 700 $/oz — les banques centrales achètent massivement (Chine +30 tonnes en janvier)." }
  ],
  keyPointsLecture: "La semaine 7 a envoyé des signaux contradictoires : l'inflation reste élevée mais la consommation faiblit. Ce paradoxe est au cœur du débat Fed. Les minutes de mercredi révéleront comment les membres interprètent ces données. Le rebond tech est encourageant mais fragile — il repose sur l'anticipation des earnings NVIDIA la semaine prochaine. L'or record confirme que les investisseurs cherchent des couvertures.",

  timeline: [
    { day: "Lundi", date: "16/02", events: ["Presidents' Day — Marchés fermés", "Pas de données économiques"] },
    { day: "Mardi", date: "17/02", events: ["Empire State Manufacturing Index", "Reprise des échanges après le long weekend"] },
    { day: "Mercredi", date: "18/02", events: ["Minutes du FOMC (14h00 ET)", "Housing Starts & Building Permits", "Industrial Production"] },
    { day: "Jeudi", date: "19/02", events: ["Walmart Q4 Earnings (avant ouverture)", "Existing Home Sales", "Jobless Claims", "Philadelphia Fed Manufacturing"] },
    { day: "Vendredi", date: "20/02", events: ["PMI Flash S&P Global (Manufacturing + Services)", "Michigan Consumer Sentiment (final)"] }
  ],

  macroContext: "L'économie US envoie des signaux mixtes. Le CPI à 3.0% montre que l'inflation reste sticky. Les Retail Sales à -0.9% suggèrent un consommateur qui ralentit. Le marché de l'emploi reste solide (NFP +143K en janvier). Le PIB Q4 initial à 2.3% confirme une croissance modérée.",
  macroExpectations: "Le marché cherche des indices sur la santé du consommateur (Walmart) et la direction de la Fed (minutes). Un PMI Flash solide vendredi rassurerait sur la croissance.",
  macroScenarios: [
    { label: "Soft Landing Confirmé", description: "Minutes dovish + Walmart solide + PMI > 52 → S&P vers 6 080, taux 10 ans vers 4.25%" },
    { label: "Stagflation Risk", description: "Minutes hawkish + Walmart déçoit + PMI < 50 → S&P vers 5 950, VIX > 18" },
    { label: "Consolidation", description: "Données mixtes → S&P range 6 000-6 050, marché attend NVIDIA S9" }
  ],
  macroCalendar: [
    { date: "17/02", time: "08:30", indicator: "Empire State Manufacturing", consensus: "-2.0", previous: "-12.6", sensitiveAssets: "Industrials, USD" },
    { date: "18/02", time: "14:00", indicator: "Minutes FOMC", consensus: "N/A", previous: "N/A", sensitiveAssets: "Treasuries, USD, Indices, Or" },
    { date: "18/02", time: "08:30", indicator: "Housing Starts", consensus: "1.40M", previous: "1.50M", sensitiveAssets: "Homebuilders, Real Estate" },
    { date: "19/02", time: "10:00", indicator: "Existing Home Sales", consensus: "4.10M", previous: "4.24M", sensitiveAssets: "Real Estate, Homebuilders" },
    { date: "20/02", time: "09:45", indicator: "PMI Flash Manufacturing", consensus: "51.5", previous: "51.2", sensitiveAssets: "Industrials, USD, Indices" },
    { date: "20/02", time: "09:45", indicator: "PMI Flash Services", consensus: "53.0", previous: "52.9", sensitiveAssets: "Services, Consumer, Indices" }
  ],
  macroLecture: "Les minutes du FOMC sont le catalyseur macro de la semaine. Le marché veut savoir si les membres ont discuté d'un changement de cap face à l'inflation sticky. Le PMI Flash de vendredi est le premier indicateur d'activité de février — un chiffre sous 50 (contraction) serait un signal d'alarme. L'immobilier (Housing Starts, Existing Home Sales) devrait confirmer le ralentissement du secteur sous le poids des taux élevés.",

  fedContext: "La Fed a maintenu les taux à 4.25-4.50% en janvier. Le CPI à 3.0% complique la tâche de Powell. Le marché anticipe que les minutes révéleront un débat interne entre hawks (pas de baisse avant 2027) et doves (baisse possible en juin).",
  fedSpeakers: [
    { name: "Austan Goolsbee", date: "17/02", stance: "Dovish — insiste sur le ralentissement du marché de l'emploi" },
    { name: "Michelle Bowman", date: "18/02", stance: "Hawkish — préoccupée par l'inflation persistante" },
    { name: "John Williams", date: "20/02", stance: "Neutre — data-dependent, attend plus de données" }
  ],
  fedAlert: "Surveiller : le ton des minutes sur l'inflation. Si le mot 'persistent' apparaît plus de 5 fois, signal hawkish.",
  fedLecture: "Les minutes du FOMC sont le document le plus important de la semaine. Le marché cherche des indices sur trois questions : (1) combien de membres pensent que l'inflation est trop élevée pour baisser les taux ? (2) y a-t-il eu un débat sur l'impact des tarifs Trump sur l'inflation ? (3) quel est le seuil de données qui déclencherait une baisse ? Les Fed speakers de la semaine donneront des indices complémentaires — Goolsbee (dovish) vs Bowman (hawkish) illustrent la division interne.",

  sectors: [
    { name: "Technology", perf1W: 1.8 },
    { name: "Healthcare", perf1W: 0.4 },
    { name: "Financials", perf1W: 0.7 },
    { name: "Consumer Discretionary", perf1W: 0.5 },
    { name: "Consumer Staples", perf1W: -0.2 },
    { name: "Industrials", perf1W: 0.9 },
    { name: "Energy", perf1W: 0.3 },
    { name: "Utilities", perf1W: -0.5 },
    { name: "Materials", perf1W: 1.1 },
    { name: "Real Estate", perf1W: -0.8 },
    { name: "Communication Services", perf1W: 1.3 }
  ],
  sectorsLecture: "Le rebond est mené par la Tech (+1.8%) et les Communication Services (+1.3%), signe d'un retour du risk-on. Les Materials (+1.1%) profitent du stimulus chinois. Les défensives (Utilities -0.5%, Staples -0.2%) sous-performent après leur surperformance récente. Le Real Estate (-0.8%) souffre des taux élevés. Cette rotation retour vers la croissance est un signal positif mais doit être confirmée par les earnings NVIDIA la semaine prochaine.",
  sectorsScenarios: "SI minutes dovish → continuation du rebond tech, Nasdaq vers 22 000. SI minutes hawkish → retour vers les défensives, Utilities et Healthcare surperforment.",

  stocksMarketMoving: [
    { ticker: "WMT", company: "Walmart", date: "19/02", timing: "Before Open", consensus: "EPS $1.51, CA $178B", watchFor: "Same-store sales, e-commerce growth, guidance FY27", risk: "Consommateur en ralentissement, pression sur les marges", sensitivity: "Élevée — baromètre de la consommation US" },
    { ticker: "BKNG", company: "Booking Holdings", date: "20/02", timing: "After Close", consensus: "EPS $38.50, CA $5.1B", watchFor: "Travel demand, ADR trends, international exposure", risk: "Ralentissement du voyage, impact dollar fort", sensitivity: "Modérée — indicateur du secteur voyage" }
  ],
  stocksLecture: "Walmart est LE stock de la semaine. Après les Retail Sales décevantes (-0.9%), le marché veut savoir si le plus grand retailer du monde confirme le ralentissement. Les commentaires sur le consommateur seront scrutés mot par mot. Booking Holdings donnera un signal sur la demande de voyage — un secteur qui a été résilient mais qui montre des signes de normalisation.",

  mag7: [
    { ticker: "AAPL", perfYTD: "+0.8%", catalyst: "Services growth, iPhone demand stable", positive: true },
    { ticker: "MSFT", perfYTD: "+2.5%", catalyst: "Azure IA en croissance, Copilot traction", positive: true },
    { ticker: "GOOGL", perfYTD: "+4.2%", catalyst: "Search IA, YouTube, cloud acceleration", positive: true },
    { ticker: "AMZN", perfYTD: "+3.9%", catalyst: "AWS momentum, advertising growth", positive: true },
    { ticker: "NVDA", perfYTD: "+6.8%", catalyst: "Anticipation earnings S9, Blackwell demand", positive: true },
    { ticker: "META", perfYTD: "+5.5%", catalyst: "Reels monetization, efficiency gains", positive: true },
    { ticker: "TSLA", perfYTD: "-3.8%", catalyst: "Guerre des prix en Chine, Robotaxi delays", positive: false }
  ],
  mag7Lecture: "Les Magnificent 7 mènent le rebond avec 6 sur 7 en hausse YTD. NVIDIA (+6.8%) est le leader avant ses earnings de la semaine 9. Google (+4.2%) et Meta (+5.5%) surperforment sur la monétisation IA. Tesla reste le maillon faible (-3.8%) sur la guerre des prix en Chine et les retards du Robotaxi. Le poids des Mag 7 dans le S&P (~31%) signifie que leur performance dicte la direction de l'indice.",

  themes: [
    { title: "Inflation Sticky", description: "Le CPI à 3.0% confirme que l'inflation ne baisse plus aussi vite. Le 'last mile' vers 2% sera long et douloureux." },
    { title: "Consommateur sous pression", description: "Retail Sales -0.9%, épargne en baisse, crédit revolving en hausse. Le consommateur US montre des signes de fatigue." },
    { title: "IA — Pré-NVIDIA", description: "Tout le marché attend NVIDIA S9. Les semi-conducteurs rebondissent en anticipation. La thèse IA est intacte mais les valorisations sont exigeantes." },
    { title: "Or refuge", description: "L'or à 4 700 $ reflète les achats des banques centrales et la demande de couverture contre l'inflation et la géopolitique." }
  ],
  divergences: "Divergence entre le CPI (inflation haute) et les Retail Sales (consommation faible). Divergence entre le marché actions (rebond) et le marché obligataire (taux en hausse).",
  surprises: "La force du rebond tech malgré le CPI au-dessus des attentes. L'or qui continue de monter malgré un dollar en hausse (corrélation historique négative brisée).",

  voices: [
    { name: "Jerome Powell", role: "Président de la Fed", description: "Lors de son témoignage au Congrès : 'Nous n'avons pas besoin de nous précipiter pour ajuster les taux.' Message clair : patience." },
    { name: "Doug McMillon", role: "CEO Walmart", description: "Avant les earnings : 'Le consommateur est résilient mais plus sélectif dans ses achats.' Signal de prudence." },
    { name: "Howard Marks", role: "Co-Chairman Oaktree", description: "Memo : 'Les marchés sont chers mais pas en bulle. La sélectivité sera la clé en 2026.'" }
  ],

  policyContext: "Trump prépare l'annonce de tarifs sur le Canada et le Mexique (prévue pour la semaine 9). Le Congrès débat du plafond de la dette. Le DOGE (Department of Government Efficiency) annonce $50B d'économies identifiées.",
  policyCards: [
    { title: "Tarifs en préparation", description: "Trump prépare des tarifs de 25% sur le Canada et le Mexique. Annonce attendue le weekend du 22-23 février." },
    { title: "Plafond de la dette", description: "Le Congrès doit relever le plafond avant juin. Les négociations commencent — risque de shutdown si blocage." },
    { title: "DOGE — Coupes budgétaires", description: "Le Department of Government Efficiency annonce $50B d'économies. Impact sur les contractors gouvernementaux (Leidos, SAIC, Booz Allen)." }
  ],
  policyScenarios: [
    { label: "Tarifs annoncés", description: "SI tarifs confirmés le weekend → ouverture lundi S9 en baisse, auto et agriculture sous pression" },
    { label: "Tarifs reportés", description: "SI tarifs reportés → soulagement, S&P pourrait tester 6 080" }
  ],
  policyLecture: "La politique est un facteur de risque croissant. Les tarifs Trump sur le Canada/Mexique sont le sujet numéro un — le marché espère un report mais se prépare au pire. Le plafond de la dette est un risque à moyen terme (juin) mais les marchés ne le pricent pas encore. Le DOGE crée de l'incertitude pour les contractors gouvernementaux — un secteur qui représente $150B de revenus annuels.",

  earnings: [
    { day: "Jeudi", date: "19/02", timing: "Before Open", ticker: "WMT", company: "Walmart", consensus: "EPS $1.51", watchFor: "Same-store sales, e-commerce, guidance FY27", risk: "Consommateur en ralentissement", highlight: true },
    { day: "Vendredi", date: "20/02", timing: "After Close", ticker: "BKNG", company: "Booking Holdings", consensus: "EPS $38.50", watchFor: "Travel demand, ADR, international", risk: "Normalisation du voyage", highlight: false },
    { day: "Mardi", date: "17/02", timing: "Before Open", ticker: "MDT", company: "Medtronic", consensus: "EPS $1.37", watchFor: "Organic growth, new product pipeline", risk: "Pression sur les prix healthcare", highlight: false },
    { day: "Mercredi", date: "18/02", timing: "After Close", ticker: "SNPS", company: "Synopsys", consensus: "EPS $3.75", watchFor: "EDA demand, chip design activity", risk: "Cycle semi-conducteurs", highlight: false }
  ],
  earningsLecture: "Walmart domine le calendrier. Le consensus attend un EPS de $1.51 et un CA de $178B. Les same-store sales sont le chiffre clé — au-dessus de +4%, le marché sera rassuré sur le consommateur. En dessous de +2%, les craintes de ralentissement s'intensifieront. Synopsys donnera un signal sur l'activité de design de puces — un indicateur avancé pour les semi-conducteurs.",

  scenarios: [
    { name: "Bull — Minutes Dovish + Walmart Beat", probability: "30%", description: "Minutes équilibrées, Walmart bat les attentes avec guidance solide", result: "S&P 500 vers 6 080, Nasdaq vers 22 000, VIX < 14", signal: "Walmart +5%, taux 10 ans vers 4.25%" },
    { name: "Base — Données Mixtes", probability: "45%", description: "Minutes neutres, Walmart en ligne avec les attentes", result: "S&P 500 range 6 000-6 050, marché attend NVIDIA S9", signal: "Consolidation, volume modéré" },
    { name: "Bear — Minutes Hawkish + Walmart Déçoit", probability: "25%", description: "Minutes révèlent un débat sur la hausse des taux, Walmart prévient d'un ralentissement", result: "S&P 500 vers 5 950, VIX > 18, rotation défensive", signal: "Walmart -5%, taux 10 ans vers 4.40%" }
  ],
  risks: [
    { title: "Inflation Persistante", description: "Le CPI à 3.0% montre que l'inflation ne baisse plus. Si le PCE S9 confirme, la Fed pourrait ne pas baisser les taux en 2026." },
    { title: "Consommateur en Fatigue", description: "Retail Sales -0.9% + épargne en baisse + crédit en hausse = cocktail dangereux pour la croissance." },
    { title: "Tarifs Imminents", description: "L'annonce des tarifs Trump le weekend pourrait provoquer un gap baissier lundi S9." },
    { title: "Concentration du Marché", description: "Le rebond est mené par les Mag 7. Si NVIDIA déçoit S9, tout le rebond pourrait s'effondrer." }
  ],
  scenarioDisclaimer: "Ces scénarios sont des hypothèses pédagogiques basées sur les données disponibles au 15/02/2026. Ils ne constituent en aucun cas des prévisions ou des recommandations d'investissement.",
  scenariosLecture: "Le scénario de base (45%) est une semaine de consolidation avant le catalyseur NVIDIA de S9. Le bull case (30%) nécessite des minutes dovish ET un Walmart solide — une combinaison possible mais pas certaine. Le bear case (25%) serait déclenché par des minutes hawkish qui remettraient en question toute baisse de taux en 2026. La clé : les minutes mercredi à 14h00 ET donneront le ton pour le reste de la semaine.",

  glossary: [
    { term: "FOMC Minutes", definition: "Compte-rendu détaillé de la réunion du Federal Open Market Committee — révèle les débats internes de la Fed." },
    { term: "CPI", definition: "Consumer Price Index — mesure l'inflation des prix à la consommation. Publié mensuellement par le BLS." },
    { term: "Retail Sales", definition: "Ventes au détail — mesure la consommation des ménages, qui représente ~70% du PIB US." },
    { term: "PMI Flash", definition: "Purchasing Managers' Index préliminaire — premier indicateur d'activité du mois en cours. Au-dessus de 50 = expansion." },
    { term: "Same-Store Sales", definition: "Ventes à périmètre comparable — mesure la croissance organique d'un retailer en excluant les nouvelles ouvertures." },
    { term: "Sticky Inflation", definition: "Inflation persistante qui ne baisse pas malgré les taux élevés — souvent liée aux services et au logement." }
  ],
  sources: "Sources : Bloomberg, Reuters, CME FedWatch, BLS, Census Bureau, Fed Minutes, Walmart IR, S&P Global PMI. Données au 15/02/2026.",
  disclaimer: "⚠️ WallStreet Market Brief est un document strictement informatif. Il ne constitue en aucun cas un conseil en investissement, une recommandation d'achat ou de vente, ni un signal de trading. Les scénarios présentés sont des hypothèses pédagogiques. Consultez un conseiller financier agréé avant toute décision d'investissement."
};
