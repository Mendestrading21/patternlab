/**
 * WMB Suisse — Semaine 12 (LUN 10/03 → VEN 14/03 2026)
 * Données vérifiées : SIX, BNS, Reuters, Swissinfo
 */
import type { SuisseModuleData } from "../suisse";
export const SUISSE_SEMAINE_12: SuisseModuleData = {
  id: 205,
  weekNumber: 12,
  year: 2026,
  dateRange: "LUN 10/03 → VEN 14/03",
  title: "SMI en Correction, BNS a 0% et CHF Fort",
  subtitle: "MODULE SUISSE",
  publishedAt: "2026-03-15T08:00:00Z",
  headerImage: "",
  executiveSummary: {
    weekPast: [
      "Le SMI perd 2,7% sur la semaine a 12 839 points — sa pire semaine depuis octobre 2025. Les trois poids lourds (Nestle, Novartis, Roche) representent 55% de l'indice et pesent tous.",
      "Le franc suisse reste fort contre l'euro (EUR/CHF 0,9030) mais recule face au dollar (USD/CHF 0,8830). Le flight-to-safety beneficie au CHF.",
      "L'inflation suisse tombe a 0,1% YoY en fevrier — le niveau le plus bas depuis 2021. La BNS n'a plus de marge pour baisser ses taux.",
      "Swatch Group (-4,2%) et Richemont (-3,1%) souffrent du ralentissement du luxe chinois.",
    ],
    weekAhead: [
      "BNS 20 mars — decision de taux. Statu quo attendu a 0%. Le marche surveillera les commentaires sur le CHF et l'inflation.",
      "FOMC 17-18 mars — impact indirect sur le CHF via le dollar. Un FOMC hawkish renforcerait le dollar et affaiblirait le CHF.",
      "Donnees KOF mars — indicateur avance de l'activite economique suisse.",
    ],
    lectureWMB: "La Suisse n'echappe pas au sell-off mondial. Le SMI perd 2,7% sur la semaine, penalise par ses trois poids lourds defensifs qui ne jouent plus leur role de refuge dans un environnement de stagflation. Le CHF reste fort contre l'euro mais recule face au dollar — un signe que le flight-to-safety mondial va vers le dollar, pas vers le franc. La BNS est dans une impasse : l'inflation a 0,1% ne justifie plus de baisses de taux, mais le CHF fort pese sur les exportateurs. La decision du 20 mars sera un non-evenement (statu quo a 0%), mais les commentaires de Jordan sur le CHF seront scrutees.",
  },
  chf: [
    { pair: "EUR/CHF", value: "0,9030", change1W: "-0,15%" },
    { pair: "USD/CHF", value: "0,8830", change1W: "+0,80%" },
    { pair: "GBP/CHF", value: "1,1410", change1W: "-0,25%" },
    { pair: "CHF/JPY", value: "168,30", change1W: "-0,50%" },
  ],
  chfLecture: "Le franc suisse reste fort contre l'euro (EUR/CHF 0,9030) mais recule face au dollar (USD/CHF 0,8830, +0,80%). C'est la dynamique classique en periode de stress : le CHF est un refuge contre l'euro mais pas contre le dollar quand le DXY est en mode rally. Le GBP/CHF recule legerement a 1,1410. Le CHF/JPY baisse a 168,30 — le yen se renforce egalement en mode risk-off. Pour les exportateurs suisses, la force du CHF contre l'euro reste le probleme principal — chaque 1% de hausse du CHF coute environ 0,5% de marge aux entreprises exposees a la zone euro.",
  bns: {
    rate: "0,00%",
    inflation: "0,1% YoY (fevrier 2026)",
    nextMeeting: "20 mars 2026",
    stance: "Statu quo attendu. La BNS est a 0% avec une inflation a 0,1% — elle n'a plus de marge pour baisser. Le marche n'anticipe aucun mouvement. Les commentaires sur le CHF fort seront le point d'attention principal.",
    lectureWMB: "La BNS est dans une impasse historique. A 0% de taux directeur et 0,1% d'inflation, elle n'a plus aucun levier conventionnel. Les taux negatifs ne sont pas a l'ordre du jour (Thomas Jordan l'a explicitement ecarte). L'intervention sur le marche des changes reste l'outil principal — la BNS continue d'acheter des devises etrangeres pour limiter l'appreciation du CHF. Mais dans un environnement ou le dollar est le refuge numero un, les interventions de la BNS ont un impact limite. La decision du 20 mars sera un statu quo — l'attention se portera sur les projections d'inflation et les commentaires sur le CHF.",
  },
  blueChips: [
    { ticker: "NESN", value: "82,50 CHF", change1W: "-2,80%" },
    { ticker: "NOVN", value: "88,20 CHF", change1W: "-2,50%" },
    { ticker: "ROG", value: "268,00 CHF", change1W: "-3,10%" },
    { ticker: "UBSG", value: "28,50 CHF", change1W: "-1,80%" },
    { ticker: "ZURN", value: "520,00 CHF", change1W: "-1,20%" },
    { ticker: "ABBN", value: "52,80 CHF", change1W: "-2,00%" },
  ],
  blueChipsLecture: "Les trois poids lourds du SMI (Nestle, Novartis, Roche) representent 55% de l'indice et pesent tous cette semaine. Roche est le pire performer a -3,10%, penalise par des resultats d'essais cliniques decevants sur un traitement anti-obesite. Nestle recule de 2,80% sur les craintes de ralentissement de la consommation mondiale. Novartis perd 2,50% dans un mouvement de vente generalise sur la pharma. UBS recule de 1,80% — les craintes de credit et la compression des marges pesent. Zurich Insurance (-1,20%) et ABB (-2,00%) completent le tableau baissier. Aucun blue chip n'est en territoire positif cette semaine.",
  topMovers: [
    { ticker: "Rheinmetall (cotee aussi a Zurich)", value: "1 450 CHF", change1W: "+8,00%" },
    { ticker: "Lonza", value: "580,00 CHF", change1W: "+1,50%" },
    { ticker: "Swiss Re", value: "132,00 CHF", change1W: "+0,80%" },
  ],
  topMoversLecture: "Rheinmetall (cotee egalement a Zurich) est le grand gagnant de la semaine a +8%, porte par le plan de defense europeen de 800 milliards d'euros. Lonza gagne 1,50% sur la demande soutenue en CDMO (fabrication pharmaceutique). Swiss Re progresse de 0,80% — le secteur reassurance beneficie de la hausse des primes dans un environnement de risques accrus.",
  flopMovers: [
    { ticker: "Swatch Group", value: "168,00 CHF", change1W: "-4,20%" },
    { ticker: "Richemont", value: "145,00 CHF", change1W: "-3,10%" },
    { ticker: "Roche", value: "268,00 CHF", change1W: "-3,10%" },
  ],
  flopMoversLecture: "Swatch Group est le pire performer du SMI a -4,20%, penalise par le ralentissement du luxe chinois et la force du CHF qui reduit la competitivite a l'export. Richemont suit a -3,10% pour les memes raisons — le luxe suisse est doublement penalise par la Chine et le CHF. Roche perd egalement 3,10% apres des resultats d'essais cliniques decevants.",
  economy: {
    gdp: "+1,3% YoY (Q4 2025)",
    unemployment: "2,1% (fevrier 2026)",
    kof: "101,5 (fevrier 2026)",
    highlights: [
      "Inflation a 0,1% YoY — le niveau le plus bas depuis 2021. Risque de deflation si le petrole se stabilise.",
      "Chomage stable a 2,1% — le marche de l'emploi reste solide malgre le ralentissement.",
      "KOF a 101,5 — legerement au-dessus de la moyenne, signalant une croissance moderee.",
      "Exportations horlogeres en baisse de 5% en janvier — impact du CHF fort et du ralentissement chinois.",
    ],
    lectureWMB: "L'economie suisse est dans une position paradoxale : le marche de l'emploi reste solide (chomage a 2,1%), la croissance est positive (+1,3%), mais l'inflation est quasi nulle (0,1%) et les exportations souffrent du CHF fort. Le risque principal n'est pas la recession mais la deflation — si le petrole se stabilise et que le CHF continue de se renforcer, l'inflation pourrait passer en territoire negatif. Les exportations horlogeres en baisse de 5% sont un signal d'alerte pour le secteur du luxe. La BNS est piegee : elle ne peut plus baisser les taux et ses interventions sur le marche des changes ont un impact limite.",
  },
  scenarios: [
    { name: "Constructif", probability: "15%", description: "FOMC dovish, desescalade Iran, CHF se stabilise — SMI rebondit vers 13 200, exportateurs respirent.", signal: "EUR/CHF au-dessus de 0,92, SMI au-dessus de 13 000" },
    { name: "Base", probability: "50%", description: "BNS statu quo, FOMC neutre — SMI consolide entre 12 500 et 13 000, CHF reste fort.", signal: "EUR/CHF 0,89-0,91, SMI 12 500-13 000" },
    { name: "Negatif", probability: "35%", description: "FOMC hawkish, escalade Iran, CHF se renforce — SMI sous 12 500, exportateurs sous pression maximale.", signal: "EUR/CHF sous 0,89, SMI sous 12 500" },
  ],
  risks: [
    { title: "CHF trop fort = Pression sur les exportateurs", description: "Si l'EUR/CHF passe sous 0,89, les exportateurs suisses (horlogerie, pharma, machines) verront leurs marges comprimees de maniere significative." },
    { title: "Deflation = BNS sans munitions", description: "Si l'inflation passe en territoire negatif, la BNS n'aura plus d'outils conventionnels. Les taux negatifs ont ete explicitement ecartes par Thomas Jordan." },
    { title: "Ralentissement luxe chinois = Swatch et Richemont", description: "Si la Chine ne relance pas sa consommation, le secteur du luxe suisse continuera de souffrir. Les exportations horlogeres sont deja en baisse de 5%." },
  ],
  pdfUrl: "",
  sources: "Donnees de marche : SIX Swiss Exchange, BNS, Reuters, Swissinfo. Economie : SECO, KOF, OFS. Cloture vendredi 14 mars 2026.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
};
