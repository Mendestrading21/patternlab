/**
 * WMB Fil Rouge — Semaine 12 (LUN 10/03 → VEN 14/03 2026)
 * Données vérifiées : Yahoo Finance, MarketWatch, Reuters, CNBC
 */
import type { FilRougeModuleData } from "../filRouge";
export const FIL_ROUGE_SEMAINE_12: FilRougeModuleData = {
  id: 405,
  weekNumber: 12,
  year: 2026,
  dateRange: "LUN 10/03 → VEN 14/03",
  title: "Correction Officielle, FOMC en Vue et Nvidia GTC",
  subtitle: "FIL ROUGE",
  publishedAt: "2026-03-15T08:00:00Z",
  headerImage: "",
  delta: {
    summary: "Le S&P 500 entre en correction de -5% depuis ses plus hauts de fevrier. Le CPI en ligne (+2,4%) a offert un repit temporaire mais le petrole au-dessus de 97$ et les Mag 7 en correction de 15% dominent le sentiment. Le FOMC de mercredi prochain et Nvidia GTC lundi sont les deux catalyseurs de la semaine 13.",
    indices: [
      { name: "S&P 500", value: "6 632,19", change: "-1,60% (hebdo)" },
      { name: "Nasdaq 100", value: "24 380", change: "-2,00% (hebdo)" },
      { name: "Dow Jones", value: "46 558", change: "-1,30% (hebdo)" },
      { name: "Russell 2000", value: "2 480", change: "-3,50% (hebdo)" },
      { name: "VIX", value: "28,50", change: "+3,2 pts (hebdo)" },
    ],
    commodities: [
      { name: "WTI", value: "97,00 $/b", change: "-5,8% (hebdo)" },
      { name: "Brent", value: "100,20 $/b", change: "-6,1% (hebdo)" },
      { name: "Or", value: "5 020 $/oz", change: "-0,5% (hebdo)" },
    ],
    crypto: [
      { name: "Bitcoin", value: "70 800 $", change: "+2,0% (hebdo)" },
      { name: "Ethereum", value: "2 096 $", change: "+0,5% (hebdo)" },
    ],
    lectureWMB: "Le delta de la semaine 12 confirme la correction. Le S&P 500 est a -5% depuis ses plus hauts de fevrier. Le VIX a touche 29 avant de retomber a 28,50 — le stress reste eleve. Le petrole se stabilise mais reste au-dessus de 97$. Le Bitcoin a ~70 800$ surperforme les actions pour la 2eme semaine consecutive. Le FOMC de mercredi et Nvidia GTC lundi sont les deux evenements qui determineront si la correction s'accelere ou si un rebond technique se materialise.",
  },
  agenda72h: [
    "LUNDI 16/03 — Nvidia GTC 2026 debut. Empire State Manufacturing Index mars.",
    "MARDI 17/03 — Retail Sales fevrier. Nvidia GTC keynote Jensen Huang.",
    "MERCREDI 18/03 — FOMC decision de taux + dot plot + projections. Conference de presse Powell 14h30 ET. Housing Starts.",
    "JEUDI 19/03 — Jobless Claims. Philly Fed Manufacturing. Earnings : Micron (MU), FedEx (FDX), Accenture (ACN).",
    "VENDREDI 20/03 — BNS decision de taux. PBOC decision LPR. Earnings : Nike (NKE).",
  ],
  watchlistUpdate: [
    { ticker: "NVDA", status: "GTC lundi — catalyseur de rebond ou sell the news. Support a 160$, resistance a 200$.", level: "180,25$" },
    { ticker: "XOM", status: "ATH — trade energie dominant. Si petrole reste au-dessus de 100$, objectif 135$.", level: "120,50$" },
    { ticker: "META", status: "Seul Mag 7 positif YTD (+3,2%). Resilience portee par la monetisation IA.", level: "620,00$" },
    { ticker: "MU", status: "Earnings jeudi — test de la demande HBM pour l'IA. Catalyseur potentiel.", level: "95,00$" },
    { ticker: "FDX", status: "Earnings jeudi — barometer de l'activite economique mondiale.", level: "250,00$" },
  ],
  riskAlert: "RISQUE PRINCIPAL : FOMC mercredi 18 mars. Le dot plot et les projections economiques sont plus importants que la decision de taux elle-meme. Si le dot plot ne montre qu'une seule baisse de taux en 2026 (vs 2 attendues), le marche pourrait perdre 3-5% en une seance. Surveiller egalement les projections d'inflation et de croissance — des revisions a la hausse de l'inflation ou a la baisse de la croissance confirmeraient le scenario de stagflation. RISQUE SECONDAIRE : Nvidia GTC lundi. Si les annonces decoivent, NVIDIA pourrait perdre 10% et entrainer tout le secteur tech. RISQUE CREDIT : Spreads HY a 380 bps, en approche du seuil de stress a 400 bps. Un franchissement de ce seuil pourrait declencher des ventes forcees dans les fonds de credit.",
  sources: "Donnees de marche : Yahoo Finance, MarketWatch, Reuters, CNBC. Cloture vendredi 14 mars 2026.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
};
