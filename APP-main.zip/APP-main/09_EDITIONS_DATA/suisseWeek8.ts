import type { SuisseModuleData } from "../suisse";

export const SUISSE_SEMAINE_8: SuisseModuleData = {
  id: 203,
  weekNumber: 8,
  year: 2026,
  dateRange: "LUN 16/02 - VEN 20/02",
  title: "Le SMI flirte avec les 14'000 points, Roche en vedette",
  subtitle: "La BNS reste prudente face à une inflation persistante, tandis que le franc suisse fait preuve de stabilité. Les valeurs défensives mènent la danse.",
  publishedAt: "2026-02-15T08:00:00Z",
  executiveSummary: {
    weekPast: [
      "Le SMI a progressé de +1.2%, clôturant juste en dessous de la barre psychologique des 14'000 points.",
      "Roche a surperformé le marché grâce à des nouvelles positives sur un médicament en développement.",
      "Les données sur l'inflation américaine ont tempéré l'enthousiasme, ravivant les craintes d'un resserrement monétaire prolongé de la Fed.",
      "Le franc suisse est resté stable face à l'euro et au dollar, confirmant son statut de valeur refuge."
    ],
    weekAhead: [
      "Publication des chiffres de l'emploi en Suisse, attendus stables.",
      "Le discours du président de la BNS, Thomas Jordan, sera scruté pour des indices sur la future politique monétaire.",
      "Les résultats d'entreprises du quatrième trimestre continuent d'animer le marché.",
      "L'évolution des tensions géopolitiques et leur impact sur les prix de l'énergie resteront un facteur clé."
    ],
    lectureWMB: "Une semaine de consolidation pour le marché suisse, qui a su résister aux vents contraires venus des États-Unis. La résilience des 'blue chips' et la stabilité du franc sont des signaux positifs, mais la prudence reste de mise face aux incertitudes macroéconomiques. La BNS semble jouer la montre, une stratégie qui pourrait s'avérer payante à moyen terme."
  },
  chf: [
    { pair: "EUR/CHF", value: "0.9855", change1W: "+0.15%" },
    { pair: "USD/CHF", value: "0.9120", change1W: "-0.20%" },
    { pair: "GBP/CHF", value: "1.1550", change1W: "+0.05%" }
  ],
  chfLecture: "Le franc suisse a montré une force tranquille, s'appréciant légèrement contre un dollar affaibli par des données mitigées, tout en cédant un peu de terrain face à un euro résilient. Cette stabilité reflète la confiance des investisseurs dans l'économie suisse malgré le contexte international incertain.",
  bns: {
    rate: "1.75%",
    inflation: "1.9%",
    nextMeeting: "19/03/2026",
    stance: "Neutre avec un biais restrictif",
    lectureWMB: "La BNS maintient son taux directeur, signalant qu'elle reste vigilante face à une inflation qui, bien que maîtrisée, demeure au-dessus de la cible. La prochaine réunion sera cruciale pour déterminer si un assouplissement est envisageable avant l'été, un scénario qui semble de moins en moins probable."
  },
  blueChips: [
    { ticker: "ROG", value: "372.50 CHF", change1W: "+3.8%" },
    { ticker: "NOVN", value: "95.80 CHF", change1W: "+1.5%" },
    { ticker: "NESN", value: "82.10 CHF", change1W: "-0.5%" }
  ],
  blueChipsLecture: "Les poids lourds pharmaceutiques ont porté le SMI. Roche a brillé, soutenu par son pipeline de produits. Novartis a également bien performé. Nestlé, en revanche, a légèrement reculé, pénalisé par des inquiétudes sur la croissance des volumes dans un contexte de prix élevés.",
  topMovers: [
    { ticker: "LOGN", value: "92.30 CHF", change1W: "+5.2%" },
    { ticker: "ADEN", value: "45.60 CHF", change1W: "+4.1%" },
    { ticker: "UBSG", value: "28.90 CHF", change1W: "+3.5%" }
  ],
  topMoversLecture: "Logitech a rebondi sur des perspectives de demande améliorées pour ses périphériques. Adecco a profité de chiffres de l'emploi solides en Europe. UBS a continué sur sa lancée positive, la confiance des investisseurs dans l'intégration de Credit Suisse se renforçant.",
  flopMovers: [
    { ticker: "GIVN", value: "3980.00 CHF", change1W: "-2.8%" },
    { ticker: "SGSN", value: "2450.00 CHF", change1W: "-2.1%" },
    { ticker: "HOLN", value: "65.40 CHF", change1W: "-1.9%" }
  ],
  flopMoversLecture: "Givaudan a souffert de prises de bénéfices après sa forte performance récente. SGS a été affecté par des craintes de ralentissement dans le commerce mondial. Holcim a pâti d'un secteur de la construction moins dynamique en début d'année.",
  economy: {
    gdp: "+0.9% (annuel)",
    unemployment: "2.1%",
    kof: "101.5",
    highlights: [
      "La croissance du PIB pour 2026 est prévue modeste mais positive.",
      "Le taux de chômage reste à un niveau historiquement bas.",
      "Le baromètre KOF suggère une croissance proche de la moyenne à court terme."
    ],
    lectureWMB: "L'économie suisse fait preuve d'une belle résilience. La consommation intérieure et un marché du travail robuste soutiennent l'activité. Cependant, la faiblesse de la demande extérieure, notamment en provenance de l'Allemagne, reste un frein majeur à une croissance plus forte."
  },
  scenarios: [
    {
      name: "Atterrissage en douceur",
      probability: "60%",
      description: "L'inflation continue de ralentir progressivement, permettant à la BNS d'amorcer un cycle d'assouplissement prudent au second semestre. Le SMI se maintient au-dessus des 13'500 points.",
      signal: "Hausse"
    },
    {
      name: "Stagflation persistante",
      probability: "30%",
      description: "L'inflation reste élevée, forçant la BNS à maintenir des taux restrictifs plus longtemps que prévu. La croissance économique stagne, pesant sur les bénéfices des entreprises.",
      signal: "Baisse"
    },
    {
      name: "Choc externe",
      probability: "10%",
      description: "Une escalade géopolitique ou une crise financière dans une économie majeure provoque une aversion au risque généralisée. Le franc s'apprécie fortement, pénalisant les exportations.",
      signal: "Baisse"
    }
  ],
  risks: [
    { title: "Inflation importée", description: "Une nouvelle flambée des prix de l'énergie ou des matières premières pourrait raviver les pressions inflationnistes." },
    { title: "Ralentissement de la zone euro", description: "La dépendance de la Suisse à son principal partenaire commercial, la zone euro, constitue un risque majeur en cas de récession prolongée." },
    { title: "Appréciation du franc", description: "En cas de tensions sur les marchés, le statut de valeur refuge du franc pourrait entraîner une appréciation rapide et pénaliser la compétitivité des entreprises suisses." }
  ],
  sources: "SIX Swiss Exchange, Reuters, Bloomberg, Office Fédéral de la Statistique, KOF",
  disclaimer: "Ces informations sont fournies à titre indicatif et ne constituent pas un conseil en investissement."
};
