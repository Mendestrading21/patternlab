import type { FilRougeModuleData } from "../filRouge";

export const FIL_ROUGE_SEMAINE_10: FilRougeModuleData = {
  id: 401,
  weekNumber: 10,
  year: 2026,
  dateRange: "MER 26/02 2026",
  title: "Frappes Iran, Petrole en Spike, Nvidia -8.5% -- Risk-Off Generalise",
  subtitle: "FIL ROUGE",
  publishedAt: "2026-02-26T06:30:00Z",

  delta: {
    summary: "Les frappes US-Israel sur l'Iran dominent le sentiment de marche cette semaine. Le petrole Brent bondit de +5% en after-hours vendredi, atteignant 74 USD. Nvidia chute de -8.5% sur la semaine apres des resultats mitiges -- la guidance pour le T1 2026 a decu le marche malgre un chiffre d'affaires record de 39.3 Mds USD (+78% YoY). Le VIX remonte a 19.6, en hausse de 15% sur la semaine, signalant une montee de la nervossite. Le S&P 500 passe en territoire negatif YTD (-0.93%), tandis que le STOXX 600 europeen atteint un nouveau record a 559. L'or atteint un nouveau sommet historique a 2,867 USD/oz, confirme comme le refuge numero un des investisseurs institutionnels. Le Bitcoin recule de -4.2% a 84,500 USD -- il ne joue pas son role de valeur refuge en periode de crise geopolitique.",
    indices: [
      { name: "S&P 500", value: "5,861", change: "-1.0% (semaine) -- sous la MM50 (5,920), support cle a 5,800" },
      { name: "Nasdaq 100", value: "20,550", change: "-2.4% (semaine) -- correction de -5% depuis le sommet de fevrier" },
      { name: "STOXX 600", value: "559", change: "+0.2% (semaine, record) -- l'Europe surperforme les USA" },
      { name: "DAX 40", value: "22,551", change: "+0.8% (semaine, +14.5% YTD) -- defense et industriels en tete" },
      { name: "SMI", value: "14,014", change: "+0.6% (semaine, record) -- 7e semaine consecutive de hausse" },
      { name: "VIX", value: "19.6", change: "+15% (semaine) -- zone d'alerte > 22, panique > 25" },
    ],
    commodities: [
      { name: "Brent", value: "$74.04", change: "+5.0% (after-hours Iran) -- si Ormuz menace, objectif 90-100 USD" },
      { name: "WTI", value: "$70.35", change: "+4.8% (after-hours Iran) -- les raffineurs US sous pression" },
      { name: "Or", value: "$2,867", change: "+2.1% (semaine, record historique) -- +11% YTD, achats banques centrales" },
      { name: "Argent", value: "$31.50", change: "+1.8% (semaine) -- demande industrielle + refuge" },
    ],
    crypto: [
      { name: "Bitcoin", value: "$84,500", change: "-4.2% (semaine) -- hack Bybit 1.5 Mds USD + risk-off Iran" },
      { name: "Ethereum", value: "$2,280", change: "-6.1% (semaine) -- sous-performance, concurrence Layer 2" },
    ],
    lectureWMB: "Le marche est en mode risk-off generalisee avec une convergence rare de facteurs negatifs. Les frappes US-Israel sur l'Iran sont le catalyseur geopolitique le plus significatif depuis l'invasion de l'Ukraine en 2022 -- le petrole bondit, l'or atteint un record, les cryptos chutent. Nvidia -8.5% confirme la rotation hors Mag 7 : le titre phare de l'IA est desormais negatif YTD (-7.34%), un signal puissant de changement de regime. Le STOXX 600 en record montre que la rotation vers l'Europe est reelle et structurelle -- les flux institutionnels se deplacent vers les valorisations plus attractives (P/E 14x vs 22x S&P 500) et le secteur de la defense europeen (plan de 800 Mds EUR). Le VIX a 19.6 n'est pas encore en zone de panique (>25) mais la tendance est clairement a la hausse. Le S&P 500 sous la MM50 (5,920) est un signal technique negatif -- si le support de 5,800 cede, la prochaine zone est 5,650 (MM200). La semaine a venir sera decisive avec le NFP vendredi, les earnings Broadcom mercredi, et surtout la reaction de l'Iran aux frappes dans les 48-72h.",
  },

  agenda72h: [
    "JEUDI 27/02 : PIB US T4 (2e estimation) -- consensus +2.3% annualise. Un chiffre sous 2% signalerait un ralentissement plus prononce que prevu et poserait la question d'un atterrissage brutal. Au-dessus de 2.5% = positif pour la croissance mais negatif pour les baisses de taux Fed.",
    "JEUDI 27/02 : Jobless Claims -- consensus 220K. Au-dessus de 240K = signal de faiblesse du marche du travail, ce qui serait paradoxalement positif pour les taux (dovish Fed) mais negatif pour les cycliques. En dessous de 210K = marche du travail toujours tendu.",
    "VENDREDI 28/02 : PCE Core (inflation preferee de la Fed) -- consensus +0.3% MoM, +2.6% YoY. C'est l'indicateur le plus surveille par la Fed. Au-dessus de +0.4% MoM = hawkish, repousse les baisses de taux au-dela de juin. En dessous de +0.2% = dovish, ouvre la porte a une baisse en mai.",
    "VENDREDI 28/02 : Personal Spending & Income -- indicateur de la sante du consommateur US. Un ralentissement des depenses confirmerait les craintes de recession. Le consommateur represente 70% du PIB US.",
    "EARNINGS MAJEURS : Block (SQ) -- fintech, indicateur de la sante des PME. Dell (DELL) -- demande IA enterprise. HP (HPQ) -- PC/impression. Best Buy (BBY) -- consommation electronique. Ces resultats donneront le pouls de la tech/retail.",
    "GEOPOLITIQUE CRITIQUE : Reaction de l'Iran aux frappes US-Israel -- la fenetre de reponse est de 48-72h. Trois scenarios : (1) pas de riposte = desescalade, petrole revient sous 70 USD, (2) riposte limitee = petrole 75-85 USD, marches -1-2%, (3) escalade majeure (Ormuz) = petrole > 100 USD, marches -5-10%.",
  ],

  watchlistUpdate: [
    { ticker: "S&P 500", status: "Sous la MM50 (5,920) -- signal technique negatif. Support cle a 5,800 (MM100). Si ce niveau cede, la prochaine zone est 5,650 (MM200). Le RSI a 42 n'est pas encore en zone de survente (<30).", level: "5,861" },
    { ticker: "Nasdaq 100", status: "Correction de -5% depuis le sommet de fevrier. Support a 20,200 (MM100). La rotation hors tech est le theme dominant. Les semi-conducteurs (SOX) sont en baisse de -8% sur le mois.", level: "20,550" },
    { ticker: "VIX", status: "En hausse a 19.6 (+15% semaine). Zone d'alerte au-dessus de 22. Zone de panique au-dessus de 25. Le VVIX (volatilite de la volatilite) est egalement en hausse, signalant que le marche anticipe plus de turbulences.", level: "19.6" },
    { ticker: "Or", status: "Record historique a 2,867 USD/oz (+11% YTD). Tendance haussiere intacte. Prochaine resistance psychologique a 3,000 USD. Les achats des banques centrales (Chine, Inde) soutiennent structurellement la demande.", level: "$2,867" },
    { ticker: "Brent", status: "Spike Iran a 74 USD (+5% after-hours). Resistance a 80 USD. Si l'Iran riposte, objectif 90-100 USD. Si desescalade, retour vers 68-70 USD. Le spread Brent-WTI s'elargit, signe de tension sur l'offre.", level: "$74.04" },
    { ticker: "EUR/CHF", status: "Plus bas 10 ans a 0.9350. Le CHF est en mode refuge total. Si les tensions Iran s'intensifient, l'EUR/CHF pourrait passer sous 0.92, forcant la BNS a intervenir. Seuil critique : 0.90.", level: "0.9350" },
    { ticker: "Bitcoin", status: "Sous pression a 84,500 USD (-4.2% semaine). Le hack Bybit (1.5 Mds USD) et le risk-off Iran pesent. Support cle a 78,000 USD (MM200). Le BTC ne joue pas son role de refuge -- l'or reste prefere.", level: "$84,500" },
  ],

  riskAlert: "ALERTE RISQUE ELEVEE -- Les frappes US-Israel sur l'Iran (28 fevrier) constituent l'evenement geopolitique le plus significatif depuis l'invasion de l'Ukraine en fevrier 2022. Trois facteurs de risque convergent simultanement : (1) le risque d'escalade Iran avec un impact direct sur le petrole (20% du petrole mondial transite par le detroit d'Ormuz), (2) l'inflation persistante (PPI +0.8% MoM, le plus chaud depuis des mois) qui empeche la Fed de baisser les taux, et (3) la rotation hors Mag 7 qui signale un changement de regime sur les marches. Si l'Iran riposte dans les 48-72h (attaque sur des installations petrolieres du Golfe, fermeture du detroit d'Ormuz), le petrole pourrait bondir a 90-100 USD, les marches actions corriger de 3-5%, et le VIX depasser 25-30. Les refuges naturels sont l'or (record a 2,867 USD), le CHF (EUR/CHF 0.9350), les Treasuries US, et les secteurs defensifs (Utilities, Consumer Staples, Sante). Les secteurs les plus exposes en cas d'escalade : tech (Nasdaq), consommation discretionnaire, et financieres. Historiquement, les chocs geopolitiques sont absorbes en 2-4 semaines si le conflit reste contenu -- mais si le detroit d'Ormuz est menace, c'est un scenario de type 'cygne noir' avec des consequences imprevisibles.",

  sources: "CNBC, Reuters, Bloomberg, Yahoo Finance, CME FedWatch, LPL Research, Rubie Wealth, World Gold Council, OPEC. Donnees de mi-semaine mercredi 26 fevrier 2026.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente d'actifs financiers, un conseil en investissement, ou une promesse de performance. Les marches financiers sont par nature imprevisibles. Les performances passees ne prejugent pas des performances futures.",
};
