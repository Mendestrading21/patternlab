import type { FilRougeModuleData } from "../filRouge";

export const FIL_ROUGE_SEMAINE_8: FilRougeModuleData = {
  id: 402,
  weekNumber: 8,
  year: 2026,
  dateRange: 'MER 18/02 2026',
  title: 'Minutes de la Fed & Rebond de la Tech',
  subtitle: 'Les investisseurs applaudissent le ton accommodant de la Fed, provoquant un rebond des valeurs technologiques.',
  publishedAt: '2026-02-18T06:30:00Z',
  delta: {
    summary: 'Les marchés ont réagi positivement à la publication des minutes de la dernière réunion de la Réserve Fédérale, qui ont révélé une approche plus prudente que prévu concernant les futures hausses de taux. Ce ton \'dovish\' a rassuré les investisseurs, entraînant une baisse de la volatilité (VIX) et un regain d\'intérêt pour les actifs à risque, notamment les valeurs technologiques du Nasdaq. Le pétrole est resté stable, les préoccupations concernant l\'offre étant contrebalancées par les perspectives d\'une demande mondiale modérée.',
    indices: [
      { name: 'S&P 500', value: '5,450.20', change: '+1.2%' },
      { name: 'Nasdaq', value: '18,150.75', change: '+2.1%' },
      { name: 'Dow Jones', value: '41,890.10', change: '+0.8%' },
      { name: 'VIX', value: '13.50', change: '-8.2%' },
    ],
    commodities: [
      { name: 'Pétrole WTI', value: '82.50 USD', change: '+0.5%' },
      { name: 'Or', value: '2,350.00 USD', change: '+1.5%' },
    ],
    crypto: [
      { name: 'Bitcoin', value: '85,200.50 USD', change: '+4.5%' },
      { name: 'Ethereum', value: '5,100.00 USD', change: '+6.2%' },
    ],
    lectureWMB: 'Analyse approfondie des minutes de la Fed et de leur impact sur les différentes classes d\'actifs. Focus sur les secteurs technologiques les plus prometteurs dans ce nouvel environnement de marché.',
  },
  agenda72h: [
    'Publication des résultats trimestriels de Walmart (WMT).',
    'Discours de Christine Lagarde (BCE) sur les perspectives économiques en zone euro.',
    'Publication de l\'indice PMI manufacturier aux États-Unis.',
  ],
  watchlistUpdate: [
    { ticker: 'NVDA', status: 'Surperformance', level: 'Augmentation de la pondération' },
    { ticker: 'WMT', status: 'Neutre', level: 'Attente des résultats trimestriels' },
    { ticker: 'XOM', status: 'Sous-performance', level: 'Surveillance des niveaux de support' },
  ],
  riskAlert: 'La réaction positive du marché pourrait être de courte durée. La persistance de l\'inflation sous-jacente reste un risque majeur qui pourrait contraindre la Fed à adopter une politique plus restrictive plus tard dans l\'année.',
  sources: 'Bloomberg, Reuters, The Wall Street Journal, Federal Reserve.',
  disclaimer: 'Les informations contenues dans cette newsletter sont fournies à titre informatif uniquement et ne constituent pas un conseil en investissement. WallStreet Market Brief n\est pas responsable des décisions d\investissement prises sur la base de ces informations.',
};
