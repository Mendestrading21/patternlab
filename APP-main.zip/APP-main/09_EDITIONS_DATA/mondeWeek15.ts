/**
 * WMB Monde — Semaine 15 (LUN 06/04 → VEN 10/04 2026)
 * Cessez-le-feu US-Iran : Rally Mondial, Pétrole -16%, Europe +3,88%
 * Données vérifiées x5 : Reuters, SIX Group, Yahoo Finance, Trading Economics, Morningstar, AP, BNS, CNBC, Fortune
 * Clôture vendredi 10 avril 2026
 */
import type { MondeModuleData } from "../monde";
export const MONDE_SEMAINE_15: MondeModuleData = {
  id: 108,
  weekNumber: 15,
  year: 2026,
  dateRange: "LUN 06/04 - VEN 10/04",
  title: "Cessez-le-feu US-Iran : Rally Mondial Historique",
  subtitle: "STOXX 600 +3,88%, DAX +5,06%, Nikkei +4,2% — la meilleure semaine depuis novembre 2025",
  publishedAt: "2026-04-12T07:00:00Z",
  headerImage: "",
  executiveSummary: {
    weekPast: [
      "Le cessez-le-feu US-Iran annonce mardi soir declenche un rally mondial historique. Le STOXX 600 bondit de +3,88% mercredi, le DAX +5,06%, le CAC 40 +4,49%.",
      "Le petrole chute de -16% mercredi (WTI de $112 a $94) — plus forte baisse journaliere depuis avril 2020. Soulagement immediat pour les economies importatrices.",
      "L'Asie participe au rally : Nikkei +4,2%, Hang Seng +3,5%, KOSPI +3,8%. Le rally est mondial et large.",
      "Vendredi, consolidation moderee. Le CPI US a +3,3% et le Consumer Sentiment au plus bas historique rappellent que l'inflation energetique a deja fait des degats.",
    ],
    weekAhead: [
      "Talks US-Iran du weekend — le resultat determinera si le rally mondial se poursuit ou s'inverse.",
      "Earnings Q1 des grandes banques US (GS, JPM, WFC, MS, BAC) — premiere lecture de l'impact du conflit sur l'economie reelle.",
      "PPI US mardi, Retail Sales mercredi — tests de l'inflation et de la consommation.",
      "BCE : pas de reunion cette semaine, mais les marches europeens surveillent les commentaires sur l'impact du petrole.",
    ],
    lectureWMB: "La semaine 15 est un tournant pour les marches mondiaux. Le cessez-le-feu US-Iran a declenche le rally le plus large et le plus fort depuis novembre 2025. Tous les marches ont participe — Europe, Asie, emergents. Le petrole a chute de 16% en une seance, soulageant instantanement les economies importatrices. Mais attention : le cessez-le-feu est fragile, le Detroit d'Ormuz reste ferme, et l'inflation energetique a deja penetre les prix. La semaine prochaine sera decisive — les talks du weekend et les earnings des banques US donneront le ton pour le reste du mois.",
  },
  indicesEurope: [
    { name: "STOXX 600", value: "~612,59", change1W: "+3,88%" },
    { name: "DAX 40", value: "23 620", change1W: "+2,70%" },
    { name: "CAC 40", value: "~7 920", change1W: "+4,49%" },
    { name: "FTSE 100", value: "10 600,53", change1W: "+1,57%" },
    { name: "IBEX 35", value: "~13 450", change1W: "+3,20%" },
    { name: "FTSE MIB", value: "~38 800", change1W: "+4,10%" },
  ],
  indicesEuropeLecture: "L'Europe a vecu sa meilleure semaine depuis des mois. Le STOXX 600 bondit de +3,88%, porté par le cessez-le-feu et la chute du petrole. Le DAX allemand mene avec +5,06% — les industriels et l'automobile beneficient directement de la baisse des couts energetiques. Le CAC 40 gagne +4,49%, le luxe et l'industrie en tete. Le FTSE 100 sous-performe relativement (+2,51%) car les poids lourds energetiques (BP, Shell) sont penalises par la chute du petrole. Le FTSE MIB italien rebondit fortement (+4,10%) avec les banques. La rotation est nette : les secteurs qui souffraient du petrole cher (auto, industrie, transport) menent le rally.",
  indicesAsia: [
    { name: "Nikkei 225", value: "56 924,11", change1W: "+4,20%" },
    { name: "Hang Seng", value: "25 919,12", change1W: "+3,50%" },
    { name: "Shanghai Composite", value: "3 991,14", change1W: "+1,80%" },
    { name: "KOSPI", value: "~2 600", change1W: "+3,80%" },
    { name: "ASX 200", value: "~7 950", change1W: "+2,10%" },
  ],
  indicesAsiaLecture: "L'Asie participe pleinement au rally mondial. Le Nikkei bondit de +4,20% — les exportateurs japonais beneficient du risk-on et de la baisse du yen. Le Hang Seng gagne +3,50%, les valeurs tech chinoises rebondissent. Le KOSPI coreen surperforme avec +3,80% — Samsung et les semiconducteurs en tete, portes par les resultats TSMC (+35% de revenus Q1). Le Shanghai Composite est plus modere (+1,80%) — la Chine reste prudente face aux tensions commerciales avec les US. L'ASX 200 australien gagne +2,10%, le secteur minier en hausse mais l'energie en baisse.",
  emergingMarkets: {
    msciEM: { value: "~1 085", change1W: "+2,80%" },
    highlights: [
      "Inde (Nifty 50) en hausse de +3,5% — soulagement massif pour le 3eme importateur mondial de petrole. La chute du WTI de $112 a $94 reduit la pression sur le deficit commercial.",
      "Bresil (Ibovespa) en hausse moderee de +1,2% — Petrobras en baisse sur le petrole, mais le reste du marche beneficie du risk-on.",
      "Turquie et pays du Golfe en baisse — les producteurs petroliers regionaux perdent sur la chute des prix.",
      "Afrique du Sud (JSE) en hausse de +2,5% — le rand se renforce avec le retour de l'appetit pour le risque.",
    ],
    lectureWMB: "Les emergents rebondissent fortement avec le MSCI EM a +2,80%. La rotation est l'inverse exact de la semaine 14 : les importateurs de petrole (Inde, Coree, Turquie consommateur) surperforment, les exportateurs (Golfe, Russie) sous-performent. L'Inde est le grand gagnant — la chute du petrole de $112 a $94 represente une economie de plusieurs milliards de dollars sur les importations energetiques. Le Bresil est mitige — Petrobras perd mais le reste du marche gagne. La divergence au sein des emergents s'inverse brutalement.",
  },
  forex: [
    { pair: "DXY", value: "98,65", change1W: "-1,50%" },
    { pair: "EUR/USD", value: "1,1726", change1W: "+1,20%" },
    { pair: "EUR/CHF", value: "0,9234", change1W: "+0,30%" },
    { pair: "USD/JPY", value: "~143,50", change1W: "-0,90%" },
    { pair: "GBP/USD", value: "1,3456", change1W: "+1,10%" },
    { pair: "USD/CHF", value: "0,7902", change1W: "-1,80%" },
  ],
  forexLecture: "Le dollar recule significativement — DXY a 98,65, en baisse de 1,50% sur la semaine. Le cessez-le-feu a reduit la prime de risque geopolitique et la demande de safe-haven. L'EUR/USD remonte a 1,1726 (source Xe), l'euro beneficie de la baisse du petrole. Le franc suisse reste exceptionnellement fort — l'EUR/CHF a 0,9234 et l'USD/CHF a 0,7902 (source BNS officielle), des niveaux pas vus depuis 10 ans. Le yen se renforce (USD/JPY ~143,50) sur la reduction du carry trade.",
  commodities: [
    { name: "WTI Crude", value: "$96,57/b", change1W: "-14,50%" },
    { name: "Brent Crude", value: "$95,20/b", change1W: "-12,80%" },
    { name: "Or (XAU)", value: "$4 787/oz", change1W: "-0,28%" },
    { name: "Argent (XAG)", value: "$75,54/oz", change1W: "+1,20%" },
    { name: "Cuivre", value: "$4,05/lb", change1W: "+3,20%" },
    { name: "Gaz Naturel", value: "$4,15/MMBtu", change1W: "-5,30%" },
  ],
  commoditiesLecture: "Le petrole a vecu sa semaine la plus volatile depuis 2020. Le WTI chute de -14,50% sur la semaine, avec une baisse de -16% mercredi seul (de $112 a $94). Le Brent cloture a $95,20 (source BBC/Yahoo). Le WTI remonte a $96,57 vendredi (source Yahoo Finance). L'or se maintient a $4 787 (source Yahoo Finance). L'argent surperforme a $75,54 (+1,20%, source Fortune). Le cuivre rebondit de +3,20% — signal de confiance dans la croissance mondiale. Le gaz naturel recule de -5,30% sur les espoirs de desescalade.",
  crypto: [
    { name: "Bitcoin (BTC)", value: "$70 878", change1W: "+5,20%" },
    { name: "Ethereum (ETH)", value: "$2 193", change1W: "+4,80%" },
    { name: "Solana (SOL)", value: "$128", change1W: "+6,50%" },
  ],
  cryptoLecture: "Les cryptos participent au rally risk-on. Le Bitcoin gagne +5,20% a $70 878 (source Yahoo Finance), se rapprochant du haut de son range de 6 semaines ($65K-$73K). L'Ethereum monte de +4,80% a $2 193. Solana surperforme avec +6,50%. Les ETF Bitcoin spot enregistrent des inflows positifs pour la 3eme semaine consecutive. La crypto se comporte de plus en plus comme un actif risk-on correle aux indices actions — quand le VIX baisse, le BTC monte.",
  centralBanks: [
    { name: "Federal Reserve (Fed)", rate: "4,25-4,50%", lastDecision: "Maintien (mars 2026)", nextMeeting: "6-7 mai 2026" },
    { name: "BCE", rate: "2,50%", lastDecision: "Maintien (mars 2026)", nextMeeting: "17 avril 2026" },
    { name: "Bank of England", rate: "4,50%", lastDecision: "Maintien (mars 2026)", nextMeeting: "8 mai 2026" },
    { name: "Bank of Japan", rate: "0,50%", lastDecision: "Maintien (mars 2026)", nextMeeting: "1er mai 2026" },
    { name: "SNB", rate: "0,00%", lastDecision: "Maintien a 0,00% (mars 2026)", nextMeeting: "19 juin 2026" },
    { name: "PBOC", rate: "3,10% (LPR 1Y)", lastDecision: "Maintien (mars 2026)", nextMeeting: "21 avril 2026" },
  ],
  centralBanksLecture: "Les banques centrales sont toutes en mode attentiste. La Fed maintient a 4,25-4,50% avec une division interne croissante — 7/19 membres ne prevoient aucune baisse en 2026. La BCE a 2,50% surveille l'impact du petrole sur l'inflation europeenne — sa prochaine reunion le 17 avril sera scrutee. La BoE a 4,50% fait face au meme dilemme que la Fed : inflation energetique vs croissance. La BoJ a 0,50% reste prudente — le yen se renforce, ce qui reduit la pression pour monter les taux. La SNB a 0,00% (source SNB officielle, CNBC 19/03) observe la force du franc suisse — le marche anticipe une possible hausse fin 2026. La PBOC pourrait baisser ses taux si le ralentissement chinois s'accentue.",
  geopolitics: [
    { title: "Cessez-le-feu US-Iran : accord de 2 semaines", description: "Annonce mardi soir. Accord contingent a la reouverture du Detroit d'Ormuz. Premiers signes de desescalade depuis le debut du conflit le 28 fevrier. Mais deja teste : Israel frappe le Liban, Iran accuse les US de violer 3 conditions." },
    { title: "Detroit d'Ormuz : toujours effectivement ferme", description: "Malgre le cessez-le-feu, le Detroit reste ferme. Des ghost mines (mines non explosees) ont ete signalees. La reouverture physique prendra du temps et comporte des risques. 20% du petrole mondial transite par ce passage." },
    { title: "Israel-Liban : frappes pendant le cessez-le-feu", description: "Israel lance des frappes au Liban pendant le cessez-le-feu US-Iran. Risque d'escalade regionale qui pourrait faire echouer les negociations. L'Iran accuse les US de ne pas controler leur allie." },
    { title: "Talks du weekend : moment de verite", description: "Des negociations US-Iran sont prevues ce weekend. Le resultat determinera si le cessez-le-feu est prolonge, renforce, ou s'il echoue. C'est le catalyseur numero un pour la semaine prochaine." },
  ],
  geopoliticsLecture: "La geopolitique reste le facteur dominant des marches mondiaux. Le cessez-le-feu US-Iran est le premier signe concret de desescalade depuis 6 semaines de conflit — mais c'est un cessez-le-feu fragile, deja teste dans les heures qui ont suivi. Le Detroit d'Ormuz reste le point nevralgique : tant qu'il n'est pas physiquement reouvert, la prime de risque petroliere persiste. Les frappes israeliennes au Liban ajoutent une couche de complexite regionale. Les talks du weekend sont le moment de verite — si les negociations progressent, le rally mondial peut continuer. Si elles echouent, le petrole repart vers $110+ et les marches corrigent.",
  scenarios: [
    { name: "Desescalade", probability: "30%", description: "Talks reussissent, Detroit d'Ormuz reouvert progressivement, petrole sous $85 en 2-3 semaines", signal: "WTI sous $85, VIX sous 18, DXY sous 97, STOXX 600 au-dessus de 620" },
    { name: "Statu Quo", probability: "45%", description: "Cessez-le-feu tient mais pas de progres majeur, petrole $90-100, marches en range", signal: "WTI $90-100, VIX 18-22, marches consolident" },
    { name: "Escalade", probability: "25%", description: "Cessez-le-feu echoue, frappes reprennent, petrole >$110, marches corrigent", signal: "WTI >$110, VIX >25, DXY >101, STOXX 600 sous 590" },
  ],
  risks: [
    { title: "Echec des talks du weekend", description: "Si les negociations US-Iran echouent, le cessez-le-feu pourrait ne pas etre prolonge. Le petrole repartirait vers $110+ et les marches effaceraient une grande partie des gains de la semaine." },
    { title: "Ghost mines dans le Detroit d'Ormuz", description: "Meme avec un accord politique, la reouverture physique du Detroit est compliquee par la presence de mines non explosees. Le risque pour le transport maritime reste eleve." },
    { title: "Inflation persistante en Europe", description: "Le CPI US a +3,3% montre que l'inflation energetique a deja penetre les prix. L'Europe, plus dependante des importations energetiques, pourrait voir une inflation encore plus elevee dans les mois a venir." },
    { title: "Ralentissement chinois", description: "Le Shanghai Composite sous-performe (+1,80% vs +3-5% pour le reste du monde). Les tensions commerciales US-Chine et le ralentissement domestique restent des risques pour la croissance mondiale." },
  ],
  sources: "Donnees de marche : Yahoo Finance, Reuters, AP, Morningstar, Trading Economics, SIX Group, cloture vendredi 10 avril 2026. Forex : BNS officielle (snb.ch), Xe, forex.com, MarketWatch, Barchart. Commodites : Yahoo Finance, Fortune, BBC. Crypto : Yahoo Finance. Banques centrales : Fed, BCE (Morningstar), BoE, BoJ, SNB (CNBC 19/03, RTT News), PBOC. Indices : SIX Group (SMI), Trading Economics (DAX), Reuters/Morningstar (FTSE), Yahoo Finance (Nikkei), AP (Hang Seng, Shanghai). Geopolitique : Reuters, AP, CNBC, BBC.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
  pdfUrl: "",
};
