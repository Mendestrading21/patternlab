/**
 * WMB Monde — Semaine 12 (LUN 10/03 → VEN 14/03 2026)
 * Données vérifiées : Yahoo Finance, MarketWatch, Reuters, CNBC
 */
import type { MondeModuleData } from "../monde";
export const MONDE_SEMAINE_12: MondeModuleData = {
  id: 105,
  weekNumber: 12,
  year: 2026,
  dateRange: "LUN 10/03 → VEN 14/03",
  title: "Europe Resiste, Asie Sous Pression et Dollar Dominant",
  subtitle: "MODULE MONDE",
  publishedAt: "2026-03-15T08:00:00Z",
  headerImage: "",
  executiveSummary: {
    weekPast: [
      "L'Europe surperforme les US pour la 4eme semaine consecutive. Le STOXX 600 ne perd que 0,47% contre -2,27% pour Le S&P 500. Le DAX est meme en leger gain (+0,30%), porte par le secteur defense.",
      "L'Asie souffre davantage : Nikkei -2,10%, Hang Seng -1%, KOSPI -1,50%. Les craintes de tarifs US sur la Chine et la correction tech pesent.",
      "Le dollar repasse au-dessus de 100 (DXY 100,2). Le petrole se stabilise autour de 97-103$ avec le Brent au-dessus de 100$.",
      "Le Bitcoin a ~71 000$ surperforme les actions pour la 2eme semaine consecutive.",
    ],
    weekAhead: [
      "FOMC 17-18 mars — dot plot et projections economiques = direction du marche mondial.",
      "BNS 20 mars — decision de taux, statu quo attendu a 0%.",
      "PBOC 20 mars — baisse possible de 10 bps du LPR pour soutenir l'economie chinoise.",
      "Nvidia GTC lundi — catalyseur potentiel pour le secteur tech mondial.",
    ],
    lectureWMB: "La divergence geographique est le theme dominant de la semaine 12. L'Europe surperforme grace au plan de defense de 800 milliards d'euros et des valorisations plus attractives (P/E 14x vs 20x pour le S&P). L'Asie souffre des tarifs US et du ralentissement chinois. Le dollar domine le marche des changes. Le FOMC de mercredi prochain sera le catalyseur mondial — il determinera si la rotation US vers Europe se poursuit ou si un sell-off generalise s'installe.",
  },
  indicesEurope: [
    { name: "STOXX 600", value: "595,00", change1W: "-0,47%" },
    { name: "DAX 40", value: "23 447", change1W: "+0,30%" },
    { name: "CAC 40", value: "7 912", change1W: "-0,85%" },
    { name: "FTSE 100", value: "8 632", change1W: "-0,35%" },
    { name: "IBEX 35", value: "13 250", change1W: "+0,15%" },
  ],
  indicesEuropeLecture: "L'Europe surperforme les Etats-Unis pour la quatrieme semaine consecutive. Le STOXX 600 ne perd que 0,47% contre -1,6% pour le S&P 500. Le DAX est meme en leger gain (+0,30%), porte par le secteur defense (Rheinmetall +8%) et les industriels qui beneficient du plan de defense europeen de 800 milliards d'euros. Le CAC 40 souffre davantage (-0,85%), penalise par le luxe (LVMH -2%) et les banques. Le FTSE 100 resiste (-0,35%) grace a son exposition a l'energie et a la pharma. La rotation US vers Europe est un theme dominant — les flux sortent des Mag 7 pour aller vers des valorisations plus raisonnables en Europe. Le P/E du STOXX 600 est a 14x contre 20x pour le S&P 500.",
  indicesAsia: [
    { name: "Nikkei 225", value: "36 790", change1W: "-2,10%" },
    { name: "Hang Seng", value: "25 466", change1W: "-1,00%" },
    { name: "Shanghai Composite", value: "4 095", change1W: "-0,80%" },
    { name: "KOSPI", value: "2 580", change1W: "-1,50%" },
    { name: "ASX 200", value: "7 950", change1W: "-0,60%" },
  ],
  indicesAsiaLecture: "L'Asie souffre davantage que l'Europe dans cet environnement de risk-off. Le Nikkei perd 2,10%, penalise par la hausse du yen qui pese sur les exportateurs japonais. Le Hang Seng recule de 1% sur les craintes de tarifs supplementaires US sur la Chine. Shanghai ne perd que 0,80% grace aux mesures de stimulus de la PBOC. Le KOSPI coreen (-1,50%) souffre de la correction des semis (Samsung, SK Hynix). L'ASX 200 australien resiste mieux (-0,60%) grace a son exposition au mining et aux banques.",
  emergingMarkets: {
    msciEM: { value: "1 085", change1W: "-1,20%" },
    highlights: [
      "Inde (Nifty 50) en baisse de 1,2% — le petrole cher pese sur l'economie indienne (importateur net)",
      "Bresil (Ibovespa) stable — le real beneficie des prix des commodities",
      "Turquie (BIST 100) en hausse de 2% — le petrole profite aux producteurs regionaux",
    ],
    lectureWMB: "Les emergents sont sous pression avec le MSCI EM a -1,20%. L'Inde souffre du petrole cher (importateur net), le Bresil resiste grace aux commodities, la Turquie beneficie du petrole. La force du dollar (DXY 100,2) est un vent contraire pour tous les emergents — elle rencherit le service de la dette en dollars et provoque des sorties de capitaux.",
  },
  forex: [
    { pair: "DXY", value: "100,2", change1W: "+0,80%" },
    { pair: "EUR/USD", value: "1,0550", change1W: "-1,70%" },
    { pair: "EUR/CHF", value: "0,9121", change1W: "-0,20%" },
    { pair: "USD/JPY", value: "148,63", change1W: "-0,80%" },
    { pair: "GBP/USD", value: "1,2930", change1W: "-0,90%" },
    { pair: "USD/CNY", value: "7,24", change1W: "+0,10%" },
  ],
  forexLecture: "Le dollar domine le marche des changes pour la cinquieme semaine consecutive. Le DXY a 100,2 repasse au-dessus du seuil psychologique de 100, porte par le flight-to-safety et les differentiels de taux. L'EUR/USD s'effondre a 1,0550 — un plus bas de 7 mois, pire semaine depuis 2024 (-1,7%) — l'euro souffre de l'exposition energetique du continent au conflit Iran. Le franc suisse reste fort contre l'euro (EUR/CHF 0,9121) mais recule face au dollar. Le yen se renforce legerement (USD/JPY 148,63) sur la reduction du carry trade — un signal de risk-off. Le yuan chinois est stable a 7,24, la PBOC defendant activement le fix quotidien.",
  commodities: [
    { name: "Or (XAU)", value: "5 020 $/oz", change1W: "-0,50%" },
    { name: "Argent (XAG)", value: "~32 $/oz", change1W: "+1,50%" },
    { name: "WTI", value: "97,00 $/b", change1W: "-5,80%" },
    { name: "Brent", value: "100,20 $/b", change1W: "-6,10%" },
    { name: "Cuivre", value: "~4,10 $/lb", change1W: "-2,30%" },
  ],
  commoditiesLecture: "Le petrole se stabilise apres le spike de la semaine derniere. Le WTI a 97$ et le Brent a 100,20$ restent au-dessus des seuils psychologiques majeurs. Goldman Sachs voit le Brent a 110-120$ en cas d'escalade. L'or se stabilise a 5 020$ — le dollar fort limite son potentiel de hausse. Le cuivre reste sous pression a 4,10$/lb sur les craintes de ralentissement chinois.",
  crypto: [
    { name: "Bitcoin (BTC)", value: "70 800 $", change1W: "+2,00%" },
    { name: "Ethereum (ETH)", value: "2 096 $", change1W: "+0,50%" },
    { name: "Solana (SOL)", value: "~135 $", change1W: "-1,20%" },
  ],
  cryptoLecture: "Le Bitcoin a ~70 800$ (+2%) continue de surperformer les actions dans le sell-off. Le narratif 'digital gold' gagne en credibilite. Ethereum sous-performe le BTC avec un ratio ETH/BTC en baisse continue. Le catalyseur pour un mouvement directionnel serait le FOMC de mercredi.",
  centralBanks: [
    { name: "Fed (FOMC)", rate: "3,50-3,75%", lastDecision: "Statu quo janvier", nextMeeting: "17-18 mars 2026" },
    { name: "BCE", rate: "2,50%", lastDecision: "Baisse de 25 bps en janvier", nextMeeting: "17 avril 2026" },
    { name: "BoJ", rate: "0,50%", lastDecision: "Hausse de 25 bps en janvier", nextMeeting: "13-14 mars 2026" },
    { name: "BNS", rate: "0,00%", lastDecision: "Baisse de 25 bps en decembre", nextMeeting: "20 mars 2026" },
    { name: "PBOC", rate: "3,10% (LPR 1Y)", lastDecision: "Statu quo en fevrier", nextMeeting: "20 mars 2026" },
  ],
  centralBanksLecture: "Les banques centrales sont dans des positions tres differentes. La Fed est piegee entre inflation et ralentissement — le FOMC de mercredi sera le moment de verite. La BCE est en mode dovish avec une baisse attendue en avril. La BoJ hesite a poursuivre son resserrement — le yen fort complique la donne. La BNS est a 0% avec une inflation a 0,1% — elle n'a plus de marge de manoeuvre. La PBOC pourrait baisser ses taux de 10 bps pour soutenir l'economie chinoise.",
  geopolitics: [
    { title: "Iran — Conflit US-Iran (3eme semaine)", description: "Le petrole se stabilise autour de 97-100$ apres le spike a 103$. Des rumeurs de negociations diplomatiques circulent mais aucune desescalade concrete. Le Detroit d'Ormuz reste le risque principal — une menace directe enverrait le petrole au-dessus de 120$." },
    { title: "Commerce US-Chine — Nouvelle enquete", description: "Nouvelle enquete commerciale de Trump sur la Chine. Tarifs supplementaires possibles sur les exportations technologiques chinoises. Impact direct sur Apple, NVIDIA et tout le secteur semis." },
    { title: "Europe — Plan de defense 800 milliards", description: "Plan de defense europeen de 800 milliards d'euros annonce par la Commission. Rheinmetall +8% sur la semaine. Rotation des flux vers le secteur defense europeen." },
  ],
  geopoliticsLecture: "Le risque geopolitique reste eleve mais s'est legerement attenue. Le conflit Iran se stabilise sans desescalade concrete. La guerre commerciale US-Chine s'intensifie avec une nouvelle enquete visant les exportations tech chinoises. L'Europe prend un virage strategique avec un plan de defense de 800 milliards d'euros — les actions defense europeennes sont les grands gagnants.",
  scenarios: [
    { name: "Constructif", probability: "15%", description: "Desescalade Iran, FOMC dovish, stimulus chinois efficace — rallye mondial, rotation vers les emergents, petrole sous 85$.", signal: "VIX sous 18, DXY sous 99, petrole sous 85$" },
    { name: "Base", probability: "45%", description: "Statu quo geopolitique, FOMC sans surprise — consolidation, Europe continue de surperformer les US.", signal: "VIX 19-23, petrole 90-100$" },
    { name: "Negatif", probability: "40%", description: "Escalade Iran, FOMC hawkish, tarifs Chine — sell-off mondial, petrole au-dessus de 120$, VIX au-dessus de 30.", signal: "VIX superieur a 25, DXY superieur a 102" },
  ],
  risks: [
    { title: "Escalade Iran = Petrole au-dessus de 120$", description: "Si le conflit s'intensifie et menace le Detroit d'Ormuz, le petrole pourrait depasser 120$. Impact devastateur sur l'inflation mondiale." },
    { title: "Tarifs Chine = Choc Supply Chain Tech", description: "Des tarifs supplementaires sur les exportations tech chinoises impacteraient directement les chaines d'approvisionnement mondiales." },
    { title: "Ralentissement Chinois = Commodities en Baisse", description: "Si la Chine ne parvient pas a relancer sa croissance, le cuivre et les commodities industrielles pourraient chuter." },
  ],
  pdfUrl: "",
  sources: "Donnees de marche : Yahoo Finance, MarketWatch, Reuters, CNBC, cloture vendredi 14 mars 2026. Banques centrales : Fed, BCE, BoJ, BNS, PBOC. Geopolitique : Reuters, Al Jazeera, FT. Commodities : CME Group, LME. Crypto : CoinGecko.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
};
