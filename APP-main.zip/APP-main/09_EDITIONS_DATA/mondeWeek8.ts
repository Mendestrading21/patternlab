import type { MondeModuleData } from "../monde";

export const MONDE_SEMAINE_8: MondeModuleData = {
  id: 103,
  weekNumber: 8,
  year: 2026,
  dateRange: 'LUN 16/02 - VEN 20/02',
  title: 'Stabilité en Europe, la Chine dans l\'expectative',
  subtitle: 'Les marchés digèrent les minutes de la Fed tandis que la BoJ surprend.',
  publishedAt: '2026-02-15T08:00:00Z',
  executiveSummary: {
    weekPast: [
      'Les marchés américains ont connu une semaine volatile, terminant en légère hausse, soutenus par un rebond des valeurs technologiques et des résultats d\'entreprise solides, notamment ceux de Walmart.',
      'En Europe, les indices ont affiché une performance stable, les investisseurs restant prudents face aux signaux mitigés sur l\'inflation et la croissance.',
      'La Banque du Japon (BoJ) a surpris les marchés en signalant une possible hausse de taux plus tôt que prévu, provoquant une appréciation du yen.',
      'Les rendements obligataires se sont tendus en début de semaine suite à la publication des minutes de la Fed, confirmant une approche attentiste sur les baisses de taux.',
    ],
    weekAhead: [
      'La publication des chiffres de l\'inflation en zone euro sera l\'événement majeur, très attendu pour évaluer la trajectoire de la BCE.',
      'Aux États-Unis, les données sur les commandes de biens durables et la confiance des consommateurs donneront de nouvelles indications sur la santé de l\'économie.',
      'Les investisseurs suivront de près les développements en Chine, où des mesures de soutien à l\'économie sont toujours attendues.',
      'La saison des résultats se poursuit avec plusieurs publications importantes dans le secteur de la distribution et de la technologie.',
    ],
    lectureWMB: 'La semaine a été marquée par une dichotomie entre la résilience de l\'économie américaine et les incertitudes persistantes en Europe et en Asie. La surprise venant de la BoJ a rebattu les cartes sur le marché des changes, tandis que la Fed maintient son cap. La prudence reste de mise, mais le rebond de la tech et la baisse du VIX suggèrent un retour de l\'appétit pour le risque, bien que sélectif.',
  },
  indicesEurope: [
    { name: 'EURO STOXX 50', value: '4,850.12', change1W: '+0.5%' },
    { name: 'FTSE 100', value: '7,720.45', change1W: '+0.2%' },
    { name: 'DAX', value: '17,150.88', change1W: '+0.8%' },
    { name: 'CAC 40', value: '7,890.21', change1W: '+0.6%' },
  ],
  indicesEuropeLecture: 'Les indices européens ont clôturé la semaine en légère hausse, dans des volumes d\'échanges modérés. La stabilité prévaut alors que les investisseurs évaluent les perspectives économiques contrastées. Le secteur du luxe a bien performé, tandis que les valeurs bancaires ont été pénalisées par l\'aplatissement de la courbe des taux.',
  indicesAsia: [
    { name: 'Nikkei 225', value: '38,500.65', change1W: '-1.2%' },
    { name: 'Hang Seng', value: '16,200.33', change1W: '+1.5%' },
    { name: 'Shanghai Comp.', value: '2,950.78', change1W: '+0.5%' },
  ],
  indicesAsiaLecture: 'Le Nikkei a corrigé suite aux déclarations de la BoJ, le renforcement du yen pesant sur les valeurs exportatrices. En Chine, les marchés ont légèrement rebondi dans l\'attente de mesures de relance concrètes après les congés du Nouvel An lunaire. L\'incertitude demeure élevée.',
  emergingMarkets: {
    msciEM: { value: '1,050.25', change1W: '+0.9%' },
    highlights: [
      'Le Brésil a bénéficié de la hausse des prix des matières premières.',
      'L\'Inde continue d\'attirer les flux de capitaux étrangers, malgré des valorisations élevées.',
      'La Turquie fait face à une inflation toujours galopante, pesant sur sa devise.',
    ],
    lectureWMB: 'Les marchés émergents ont affiché une performance positive, tirés par l\'Asie hors Japon et l\'Amérique Latine. L\'indice MSCI EM a progressé, reflétant un optimisme prudent des investisseurs. La divergence des politiques monétaires entre les pays émergents et développés reste un thème central.',
  },
  forex: [
    { pair: 'EUR/USD', value: '1.0750', change1W: '-0.2%' },
    { pair: 'USD/JPY', value: '148.50', change1W: '-1.5%' },
    { pair: 'GBP/USD', value: '1.2580', change1W: '+0.1%' },
    { pair: 'USD/CHF', value: '0.8850', change1W: '+0.3%' },
  ],
  forexLecture: 'Le Yen a été le grand gagnant de la semaine, s\'appréciant fortement face au dollar suite aux spéculations sur un resserrement monétaire de la BoJ. L\'euro est resté sous pression face au dollar, dans un contexte d\'incertitude sur la politique de la BCE.',
  commodities: [
    { name: 'Pétrole (WTI)', value: '78.50', change1W: '+2.5%' },
    { name: 'Or', value: '2,030.10', change1W: '+0.8%' },
    { name: 'Cuivre', value: '3.85', change1W: '+1.2%' },
  ],
  commoditiesLecture: 'Les prix du pétrole ont progressé sur fond de tensions géopolitiques persistantes au Moyen-Orient et de signes d\'une demande robuste. L\'or a consolidé ses gains, jouant son rôle de valeur refuge, tandis que les métaux industriels ont été soutenus par les espoirs de relance en Chine.',
  crypto: [
    { name: 'Bitcoin (BTC)', value: '51,800', change1W: '+3.5%' },
    { name: 'Ethereum (ETH)', value: '2,950', change1W: '+5.2%' },
  ],
  cryptoLecture: 'Le marché des cryptomonnaies a poursuivi sur sa lancée positive, avec un Bitcoin qui se maintient au-dessus du seuil psychologique des 50 000 $. L\'appétit pour le risque et l\'intérêt institutionnel croissant continuent de soutenir le secteur.',
  centralBanks: [
    { name: 'FED (États-Unis)', rate: '5.25% - 5.50%', lastDecision: 'Maintien', nextMeeting: 'Mars' },
    { name: 'BCE (Zone Euro)', rate: '4.50%', lastDecision: 'Maintien', nextMeeting: 'Mars' },
    { name: 'BoJ (Japon)', rate: '-0.10%', lastDecision: 'Maintien', nextMeeting: 'Mars' },
    { name: 'BNS (Suisse)', rate: '1.75%', lastDecision: 'Maintien', nextMeeting: 'Mars' },
  ],
  centralBanksLecture: 'La publication des minutes de la Fed a confirmé une approche prudente, douchant les espoirs d\'une baisse de taux imminente en mars. La surprise est venue de la BoJ, dont le changement de ton suggère qu\'une sortie de sa politique de taux négatifs pourrait intervenir dès le deuxième trimestre. La BCE et la BNS restent en mode observation.',
  geopolitics: [
    { title: 'Tensions en Mer Rouge', description: 'Les attaques des Houthis continuent de perturber le commerce maritime mondial, entraînant une hausse des coûts de fret et des délais de livraison.' },
    { title: 'Élections à Taïwan', description: 'Les suites de l\'élection présidentielle sont suivies de près, avec un impact potentiel sur les relations sino-américaines et l\'industrie des semi-conducteurs.' },
  ],
  geopoliticsLecture: 'Le paysage géopolitique reste tendu, avec des points de friction multiples qui pourraient rapidement impacter les marchés. La situation en Mer Rouge est un facteur inflationniste à ne pas négliger.',
  scenarios: [
    { name: 'Atterrissage en douceur', probability: '60%', description: 'L\'inflation continue de ralentir sans provoquer de récession majeure, permettant aux banques centrales de commencer à assouplir leur politique au second semestre.', signal: 'positif' },
    { name: 'Stagflation', probability: '25%', description: 'L\'inflation reste persistante tandis que la croissance ralentit, plaçant les banques centrales dans une position délicate.', signal: 'négatif' },
    { name: 'Ré-accélération', probability: '15%', description: 'La croissance économique surprend à la hausse, forçant les banques centrales à maintenir des taux élevés plus longtemps, voire à les augmenter de nouveau.', signal: 'neutre' },
  ],
  risks: [
    { title: 'Erreur de politique monétaire', description: 'Un assouplissement trop rapide pourrait relancer l\'inflation, tandis qu\'un resserrement excessif pourrait provoquer une récession.' },
    { title: 'Choc géopolitique', description: 'Une escalade des tensions actuelles (Ukraine, Moyen-Orient, Taïwan) pourrait entraîner une flambée des prix de l\'énergie et une aversion au risque généralisée.' },
    { title: 'Ralentissement chinois', description: 'Une absence de mesures de relance efficaces en Chine pèserait sur la croissance mondiale et les prix des matières premières.' },
  ],
  sources: 'Reuters, Bloomberg, The Wall Street Journal, Financial Times, S&P Global Market Intelligence',
  disclaimer: 'Les informations contenues dans cette newsletter sont fournies à titre informatif uniquement et ne constituent pas un conseil en investissement. WallStreet Market Brief décline toute responsabilité quant à l\'exactitude ou l\'exhaustivité des informations fournies.',
};
