/**
 * WMB Module Suisse — Semaine 11 (LUN 03/03 → VEN 07/03 2026)
 * SMI -6.56%, CHF Valeur Refuge, SNB 20 mars — Choc Pétrolier Global
 */
import type { SuisseModuleData } from "../suisse";

export const SUISSE_SEMAINE_11: SuisseModuleData = {
  id: 204,
  weekNumber: 11,
  year: 2026,
  dateRange: "LUN 03/03 → VEN 07/03",
  title: "SMI -6,56%, CHF Valeur Refuge & SNB le 20 Mars — Choc Pétrolier Global",
  subtitle: "REVUE SUISSE",
  publishedAt: "2026-03-08T08:00:00Z",

  executiveSummary: {
    weekPast: [
      "SMI à 13 096 — chute brutale de 6,56% sur cinq jours, la pire semaine depuis avril 2025. L'indice passe en territoire négatif YTD (-1,30%), effaçant d'un coup les gains patiemment accumulés depuis janvier.",
      "Healthcare SMI en recul de 2,16% vendredi — Roche et Novartis, qui représentent à eux seuls ~40% du poids de l'indice, ont entraîné le SMI dans leur sillage. Quand les poids lourds tombent, l'indice n'a aucune chance.",
      "CHF en mode valeur refuge maximale : EUR/CHF à 0,903 (plus bas depuis le choc de 2015), USD/CHF à 0,781. Le franc suisse absorbe les flux de capitaux fuyant le risque mondial.",
      "Inflation suisse à 0,1% YoY en février — quasi nulle, bien en dessous de la cible BNS de 0-2%. C'est à la fois une bonne nouvelle pour le pouvoir d'achat et un casse-tête pour la politique monétaire.",
      "Chômage stable à 3,2% en février — le marché du travail suisse reste remarquablement résilient malgré le ralentissement économique global.",
      "Accord UE-Suisse : package de deals signé pour une relation élargie — un catalyseur positif structurel pour les exportateurs et l'accès au marché unique européen.",
    ],
    weekAhead: [
      "Pas de données macro suisses majeures cette semaine — le SMI sera piloté par le sentiment global et les données US.",
      "CPI US mercredi 12 mars — impact indirect mais puissant sur le SMI via le sentiment global. Un CPI chaud renforcerait le CHF (flight-to-safety), un CPI froid l'affaiblirait.",
      "SNB : prochaine réunion le 20 mars — le marché anticipe un statu quo à 0,25%, mais le CHF fort pourrait forcer la main de la BNS.",
      "Conflit US-Iran : impact direct sur le CHF (valeur refuge) et indirect sur les exportateurs suisses (demande mondiale en baisse).",
      "Pas de publication earnings majeure dans le SMI cette semaine — l'attention sera sur les résultats US (Oracle, Adobe).",
      "BoJ jeudi 13-14 mars : impact sur le yen et indirectement sur le CHF via les flux de carry trade.",
    ],
    lectureWMB: "Le SMI a vécu sa pire semaine depuis avril 2025 avec une chute de 6,56% qui efface tous les gains de début d'année. L'indice est désormais en territoire négatif YTD (-1,30%) — un retournement brutal pour un marché qui semblait bien orienté en janvier. Le problème est structurel : Roche et Novartis, qui pèsent ~40% de l'indice, ont été les plus touchés vendredi (-2,16% pour le healthcare), entraînant mécaniquement le SMI. Le CHF joue pleinement son rôle de valeur refuge avec EUR/CHF à 0,903 — un niveau qu'on n'avait pas vu depuis le choc de 2015. C'est une protection pour les épargnants suisses mais un handicap croissant pour les exportateurs qui voient leurs marges se comprimer. L'inflation quasi nulle (0,1% YoY) donne théoriquement à la BNS une marge de manœuvre pour baisser les taux, mais le taux directeur est déjà à 0,25% — le dernier palier avant le retour aux taux négatifs. La réunion BNS du 20 mars sera cruciale : si le CHF continue de se renforcer, la BNS pourrait être contrainte d'agir, que ce soit par une baisse de taux ou par des interventions sur le marché des changes.",
  },

  chf: [
    { pair: "EUR/CHF", value: "0,8998", change1W: "-0,14%" },
    { pair: "USD/CHF", value: "0,7800", change1W: "+0,61%" },
    { pair: "GBP/CHF", value: "~1,04", change1W: "-0,5%" },
    { pair: "CHF/JPY", value: "~203", change1W: "+0,3%" },
  ],
  chfLecture: "Le franc suisse est en mode valeur refuge maximale. L'EUR/CHF a 0,8998 touche un niveau qu'on n'avait pas vu depuis le fameux 15 janvier 2015, quand la BNS avait abandonne le plancher a 1,20. C'est un seuil psychologique et technique majeur qui a historiquement declenche des interventions de la BNS. Le USD/CHF a 0,7800 est paradoxal cette semaine : le dollar monte globalement (DXY +1,4%, meilleure semaine depuis aout) MAIS le CHF monte encore plus fort — le franc suisse est la devise refuge numero un, devant meme le dollar. Le CHF/JPY monte a 203 — les deux grandes devises refuges se disputent les flux, mais le CHF gagne grace a la stabilite politique suisse. Pour les investisseurs suisses, le message est clair : le CHF fort reduit mecaniquement la performance des actifs etrangers. Un portefeuille 60% actions US / 40% obligations a perdu environ 4% en CHF cette semaine (2% de baisse des marches + 2% de renforcement du CHF). La BNS surveille de pres : ses reserves de change ont baisse a CHF 710 milliards en fevrier (plus bas depuis mai 2025), ce qui suggere qu'elle n'intervient pas activement pour affaiblir le CHF — du moins pas encore.",

  bns: {
    rate: "0.25%",
    inflation: "0.1% YoY (février 2026)",
    nextMeeting: "20 mars 2026",
    stance: "Attentiste — inflation quasi nulle mais taux déjà au plancher. Le CHF fort complique la donne.",
    lectureWMB: "La BNS est dans une position délicate — peut-être la plus complexe depuis 2015. L'inflation à 0,1% YoY est bien en dessous de la cible (0-2%), ce qui justifierait en théorie une baisse de taux pour stimuler l'économie. Mais le taux directeur est déjà à 0,25% — le dernier palier avant le retour aux taux négatifs, un territoire que la BNS a quitté en septembre 2022 et qu'elle ne souhaite pas retrouver. Le CHF fort (EUR/CHF 0,903) pèse sur les exportateurs — l'horlogerie, les machines et la pharma voient leurs marges se comprimer — mais protège le pouvoir d'achat des consommateurs suisses. Les réserves de change à CHF 710 milliards (en baisse) suggèrent que la BNS n'intervient pas activement sur le marché des changes. Le marché anticipe un statu quo le 20 mars avec une probabilité de ~70%, mais une baisse à 0% n'est pas exclue (~25% de probabilité) si le CHF continue de se renforcer. Le retour aux taux négatifs serait un signal fort — et un cauchemar pour les épargnants et les banques suisses qui se souviennent encore de la période 2015-2022.",
  },

  blueChips: [
    { ticker: "NESN", value: "CHF 80.24", change1W: "-1.5%" },
    { ticker: "ROG", value: "CHF 341.20", change1W: "-2.93%" },
    { ticker: "NOVN", value: "CHF 123.26", change1W: "-1.25%" },
    { ticker: "UBSG", value: "CHF 29.84", change1W: "-2.45%" },
    { ticker: "ZURN", value: "CHF 529.80", change1W: "-1.01%" },
    { ticker: "ABBN", value: "CHF 66.42", change1W: "-0.24%" },
  ],
  blueChipsLecture: "Aucun blue chip du SMI n'échappe au sell-off global cette semaine — c'est un bain de sang généralisé. Roche (-2,93%) est le plus touché, pénalisé par la rotation hors healthcare et les craintes de ralentissement des dépenses pharma mondiales. UBS (-2,45%) souffre des craintes de crédit qui frappent tout le secteur bancaire mondial — l'épisode BlackRock (limites de retraits sur fonds de crédit privé) a secoué la confiance. Nestlé (-1,5%) tient relativement bien grâce à son profil ultra-défensif (alimentation = demande stable), mais même le géant de Vevey n'est pas immunisé. Novartis (-1,25%) recule dans le sillage de Roche. Zurich Insurance (-1,01%) est sous pression malgré un profil qui devrait bénéficier des taux élevés. ABB (-0,24%) est le seul à résister honorablement — son exposition à l'électrification et l'automatisation offre une certaine protection structurelle.",

  topMovers: [
    { ticker: "SREN (Swiss Re)", value: "CHF 135", change1W: "+1.2%" },
    { ticker: "GIVN (Givaudan)", value: "CHF 3 850", change1W: "+0.5%" },
  ],
  topMoversLecture: "Très peu de gagnants cette semaine dans le SMI — on les compte sur les doigts d'une main. Swiss Re (+1,2%) est le rare rescapé, porté par son profil de réassureur : dans un environnement de risque élevé (conflit Iran, catastrophes naturelles), les primes de réassurance augmentent mécaniquement. C'est le business model qui bénéficie du chaos. Givaudan (+0,5%) résiste grâce à son positionnement ultra-défensif dans les arômes et parfums — la demande pour les ingrédients alimentaires et les fragrances est structurellement stable, indépendamment du cycle économique. Ces deux valeurs illustrent le flight-to-quality en cours sur le marché suisse.",

  flopMovers: [
    { ticker: "UBSG (UBS)", value: "CHF 29.84", change1W: "-2.45%" },
    { ticker: "ABBN (ABB)", value: "CHF 66.42", change1W: "-0.24%" },
    { ticker: "ROG (Roche)", value: "CHF 341.20", change1W: "-2.93%" },
    { ticker: "NOVN (Novartis)", value: "CHF 123.26", change1W: "-1.25%" },
    { ticker: "LONN (Lonza)", value: "CHF 504.20", change1W: "-2.02%" },
  ],
  flopMoversLecture: "Roche (-2,93%) est le plus gros perdant du SMI cette semaine — et c'est un problème pour tout l'indice vu son poids de ~20%. Le titre souffre de la rotation hors healthcare et des craintes de ralentissement des dépenses pharma. UBS (-2,45%) est pénalisé par les craintes de crédit mondiales et la baisse des marchés financiers — ses revenus de gestion de fortune et d'investment banking sont directement corrélés à la santé des marchés. Lonza (-2,02%) recule car le CDMO (sous-traitance pharma) est sensible aux budgets R&D des grandes pharma, qui pourraient être réduits. Novartis (-1,25%) suit Roche dans la baisse du healthcare. ABB (-0,24%) est le moins touché grâce à son exposition à l'électrification et l'automatisation industrielle — des méga-trends qui transcendent le cycle.",

  economy: {
    gdp: "PIB Q4 2025 : +0,1% QoQ — stagnation confirmée, l'économie suisse fait du surplace",
    unemployment: "3,2% (février 2026) — stable, marché du travail remarquablement résilient",
    kof: "KOF Economic Barometer : en baisse en février — signal avancé de ralentissement",
    highlights: [
      "Inflation à 0,1% YoY — quasi nulle, bien en dessous de la cible BNS (0-2%). Le risque de déflation refait surface dans les discussions.",
      "PMI manufacturier en baisse en février — le secteur industriel suisse souffre du CHF fort et du ralentissement de la demande mondiale.",
      "Accord UE-Suisse signé — accès au marché unique élargi, positif pour les exportateurs à moyen terme. Un catalyseur structurel sous-estimé.",
      "Réserves de change BNS : CHF 710 Mds (plus bas depuis mai 2025) — la BNS laisse le CHF se renforcer, pour l'instant.",
      "Chômage stable à 3,2% — le marché du travail reste le point fort de l'économie suisse, mais le KOF en baisse suggère que ça pourrait changer.",
    ],
    lectureWMB: "L'économie suisse est dans un état paradoxal : pas assez de croissance pour être optimiste, pas assez de faiblesse pour être alarmiste. Le PIB stagne (+0,1% au Q4), le marché du travail reste solide (chômage 3,2%), mais l'inflation est quasi nulle (0,1%) et le PMI manufacturier baisse — des signaux contradictoires qui compliquent la tâche de la BNS. Le KOF Economic Barometer en baisse est un signal avancé préoccupant : historiquement, quand le KOF baisse pendant 3 mois consécutifs, le PIB suit 6 mois plus tard. Les exportateurs suisses sont pris en étau entre le CHF fort (qui réduit leur compétitivité) et le ralentissement de la demande mondiale (qui réduit les volumes). L'accord UE-Suisse est un point positif structurel sous-estimé — il élargit l'accès au marché unique européen et réduit les barrières réglementaires. La BNS a peu de marge de manœuvre avec un taux à 0,25% — le retour aux taux négatifs est le dernier recours, et il n'est plus impossible.",
  },

  scenarios: [
    { name: "Scénario Bull", probability: "~15%", description: "Désescalade Iran rapide. CPI US froid (sous 2,3%). Le CHF s'affaiblit (EUR/CHF remonte vers 0,93). Le SMI rebondit vers 13 500 grâce au soulagement global et à la baisse de la prime de risque.", signal: "EUR/CHF au-dessus de 0,93, pétrole sous $85, VIX sous 22" },
    { name: "Scénario Base", probability: "~50%", description: "Iran contenu sans escalade. CPI US en ligne (2,3-2,5%). CHF stable autour de 0,90. Le SMI consolide dans un range 12 800-13 200, avec une forte volatilité intraday mais pas de direction claire.", signal: "EUR/CHF 0,89-0,91, SMI range-bound, volatilité élevée" },
    { name: "Scénario Bear", probability: "~35%", description: "Escalade Iran (menace Ormuz). CPI US chaud (au-dessus de 2,5%). Le CHF se renforce fortement (EUR/CHF sous 0,88). Le SMI teste 12 500 — la BNS pourrait être forcée d'intervenir verbalement.", signal: "EUR/CHF sous 0,88, BNS intervention verbale, pétrole au-dessus de $100" },
  ],
  risks: [
    { title: "Risque 1 — CHF Trop Fort / Retour aux Taux Négatifs", description: "Si le CHF continue de se renforcer (EUR/CHF sous 0,88), la BNS pourrait être contrainte de revenir aux taux négatifs — un scénario cauchemardesque pour les épargnants et les banques suisses. Les taux négatifs pénalisent les dépôts, compriment les marges bancaires et créent des distorsions sur le marché immobilier." },
    { title: "Risque 2 — Exportateurs Suisses en Danger", description: "Le CHF fort + le ralentissement mondial = double peine pour les exportateurs suisses. L'horlogerie (Swatch, Richemont), les machines (ABB, Schindler) et la pharma (Roche, Novartis) voient leurs marges se comprimer. Si l'EUR/CHF reste sous 0,90 pendant plusieurs mois, des avertissements sur résultats sont possibles." },
    { title: "Risque 3 — Healthcare en Correction Prolongée", description: "Roche et Novartis représentent ~40% du SMI. Si la rotation hors healthcare continue — portée par le risk-off global et les craintes de réduction des budgets pharma — le SMI sous-performera structurellement les indices européens (DAX, CAC 40) qui sont moins concentrés." },
  ],
  pdfUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663135061541/Wf8Nj4yLBCzwrPQSdtP8cC/suisse-s11_50037545.pdf",
  sources: "Données SMI : SIX Swiss Exchange (clôture 7 mars 2026). Données BNS : Banque Nationale Suisse, communiqué février 2026. Inflation et chômage : OFS (Office Fédéral de la Statistique). Données FX : Bloomberg, Reuters, Yahoo Finance. KOF : KOF Swiss Economic Institute, ETH Zurich.",
  disclaimer: "Ce document est produit à des fins strictement informatives et éducatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente d'actifs financiers, un conseil en investissement, ou une promesse de performance. Les marchés financiers sont par nature imprévisibles.",
};
