/**
 * WMB Actions US — Semaine 9 (23/02 – 27/02/2026)
 * NVIDIA Domine, Rotation Sectorielle & Tarifs en Embuscade
 */
import type { ActionsModuleData } from "../actions";

export const ACTIONS_SEMAINE_9: ActionsModuleData = {
  id: 12,
  weekNumber: 9,
  year: 2026,
  dateRange: "LUN 23/02 - VEN 27/02",
  title: "NVIDIA Domine, Rotation Sectorielle & Tarifs en Embuscade",
  subtitle: "NVIDIA Q4, Salesforce, Home Depot, rotation défensive, tarifs Trump",
  publishedAt: "2026-02-22T08:00:00Z",

  executiveSummary: {
    weekPast: [
      "Le Nasdaq a reculé de -0.85% en mode attentiste avant NVIDIA",
      "Rotation sectorielle marquée : Utilities +1.1%, Tech -1.2%",
      "Les semi-conducteurs consolident après le rebond de S8 (SOX -0.5%)",
      "Le volume reste modéré — le marché attend les catalyseurs de S9"
    ],
    weekAhead: [
      "NVIDIA Q4 mercredi après la clôture — LE catalyseur du trimestre",
      "Salesforce et Snowflake jeudi — test du software enterprise",
      "Home Depot et Lowe's mardi — santé du consommateur et de l'immobilier",
      "Tarifs Trump 25% sur Canada/Mexique effectifs le 4 mars — impact sur l'auto et l'agriculture"
    ],
    lectureWMB: "La semaine 9 est dominée par NVIDIA. L'action représente ~7% du S&P 500 et son mouvement post-earnings peut déplacer l'indice de 1-2%. Le consensus attend un CA de $38.5B (+65% YoY) mais le whisper number est à $40B. Au-delà des chiffres, le marché veut entendre Jensen Huang sur la demande Blackwell, les restrictions chinoises et la monétisation de l'IA. Home Depot et Lowe's donneront un signal sur le consommateur et l'immobilier."
  },

  signalVsBruit: {
    signal: [
      "NVIDIA guidances Q1 — le chiffre le plus important de la semaine",
      "Rotation vers les défensives — les institutionnels se positionnent prudemment",
      "Tarifs Trump 25% — impact réel sur les marges des entreprises exposées",
      "PCE core vendredi — confirmation ou infirmation de l'inflation sticky"
    ],
    bruit: [
      "Rumeurs de split NVIDIA — pas de confirmation, spéculation pure",
      "Tweets Trump sur les marchés — bruit politique sans impact structurel",
      "Comparaisons NVIDIA vs Cisco 2000 — contexte fondamentalement différent"
    ],
    lectureWMB: "Le signal cette semaine est clair : NVIDIA et le PCE. Tout le reste est du bruit. La rotation défensive est un signal important car elle montre que les institutionnels se préparent à un scénario de volatilité. Les tarifs sont un signal à moyen terme — le marché les traite encore comme du bruit politique mais l'impact sur les marges sera réel si maintenus."
  },

  topGainersLarge: [
    { rank: 1, ticker: "UNH", company: "UnitedHealth", perf: "+3.8%", catalyst: "Relèvement de guidance, Medicare Advantage solide" },
    { rank: 2, ticker: "PG", company: "Procter & Gamble", perf: "+2.9%", catalyst: "Rotation défensive, pricing power confirmé" },
    { rank: 3, ticker: "NEE", company: "NextEra Energy", perf: "+2.7%", catalyst: "Demande énergie data centers IA, dividende attractif" },
    { rank: 4, ticker: "JNJ", company: "Johnson & Johnson", perf: "+2.4%", catalyst: "Pipeline pharma solide, rotation healthcare" },
    { rank: 5, ticker: "KO", company: "Coca-Cola", perf: "+2.1%", catalyst: "Résultats internationaux solides, pricing power" }
  ],
  topGainersLargeLecture: "Les gagnants de la semaine sont tous des défensives — UnitedHealth, P&G, NextEra, J&J, Coca-Cola. Cette domination des défensives est le signe d'un marché qui se prépare à un événement binaire (NVIDIA). NextEra profite du thème 'énergie pour l'IA' qui continue d'attirer les flux. Le pricing power de P&G et Coca-Cola rassure dans un contexte d'inflation sticky.",

  topLosersLarge: [
    { rank: 1, ticker: "TSLA", company: "Tesla", perf: "-4.2%", catalyst: "Guerre des prix Chine, Robotaxi delays, Musk distraction DOGE" },
    { rank: 2, ticker: "NFLX", company: "Netflix", perf: "-3.1%", catalyst: "Prise de profits après le rally Q4, valorisation tendue" },
    { rank: 3, ticker: "AMD", company: "AMD", perf: "-2.8%", catalyst: "Craintes de concurrence NVIDIA Blackwell, MI300X demand" },
    { rank: 4, ticker: "BA", company: "Boeing", perf: "-2.5%", catalyst: "Nouveaux problèmes de qualité, retards livraisons 737 MAX" },
    { rank: 5, ticker: "GM", company: "General Motors", perf: "-2.3%", catalyst: "Tarifs 25% Canada/Mexique — 40% des pièces importées" }
  ],
  topLosersLargeLecture: "Tesla continue de sous-performer (-4.2%) sur un cocktail de problèmes : guerre des prix en Chine, retards Robotaxi, et la distraction Musk/DOGE. AMD recule avant NVIDIA earnings — le marché craint que Blackwell creuse l'écart. GM est le premier casualty des tarifs Trump — 40% des pièces auto viennent du Canada et du Mexique. Boeing reste dans la tourmente avec de nouveaux problèmes de qualité.",

  topGainersMidSmall: [
    { rank: 1, ticker: "SMCI", company: "Super Micro Computer", perf: "+8.5%", catalyst: "Anticipation NVIDIA beat, demande serveurs IA" },
    { rank: 2, ticker: "MSTR", company: "MicroStrategy", perf: "+6.2%", catalyst: "Bitcoin à 92K, achat supplémentaire de BTC" },
    { rank: 3, ticker: "PLTR", company: "Palantir", perf: "+5.1%", catalyst: "Contrat gouvernemental DOGE, IA defense" },
    { rank: 4, ticker: "AXON", company: "Axon Enterprise", perf: "+4.3%", catalyst: "Résultats solides, adoption IA dans la sécurité" },
    { rank: 5, ticker: "DECK", company: "Deckers Outdoor", perf: "+3.8%", catalyst: "HOKA continue de surperformer, guidance relevée" }
  ],
  topGainersMidSmallLecture: "Super Micro Computer mène les mid-caps (+8.5%) en anticipation d'un beat NVIDIA — SMCI est le proxy le plus direct sur la demande de serveurs IA. Palantir profite du thème DOGE/IA gouvernemental. Deckers (HOKA) continue sa trajectoire impressionnante dans le footwear performance. MicroStrategy suit le Bitcoin à 92K.",

  topLosersMidSmall: [
    { rank: 1, ticker: "RIVN", company: "Rivian", perf: "-7.2%", catalyst: "Cash burn élevé, production en dessous des attentes" },
    { rank: 2, ticker: "LCID", company: "Lucid Motors", perf: "-5.8%", catalyst: "Livraisons décevantes, dilution actionnaires" },
    { rank: 3, ticker: "SNAP", company: "Snap", perf: "-4.5%", catalyst: "Perte d'utilisateurs, concurrence TikTok/Reels" },
    { rank: 4, ticker: "BYND", company: "Beyond Meat", perf: "-4.1%", catalyst: "Ventes en baisse continue, restructuration" },
    { rank: 5, ticker: "PARA", company: "Paramount Global", perf: "-3.9%", catalyst: "Incertitude fusion Skydance, perte abonnés streaming" }
  ],
  topLosersMidSmallLecture: "Les EV continuent de souffrir — Rivian (-7.2%) et Lucid (-5.8%) brûlent du cash sans atteindre la rentabilité. Le marché perd patience avec les promesses non tenues. Snap (-4.5%) perd des utilisateurs face à TikTok et Reels. Beyond Meat (-4.1%) illustre la fin du hype des protéines végétales. Ces baisses montrent que le marché punit sévèrement les entreprises sans chemin clair vers la profitabilité.",

  sectors: [
    { sector: "Technology", perf: "-1.2%", note: "Attentisme pré-NVIDIA", positive: false },
    { sector: "Healthcare", perf: "+0.8%", note: "Rotation défensive, UNH en tête", positive: true },
    { sector: "Financials", perf: "-0.3%", note: "Taux stables, pas de catalyseur", positive: false },
    { sector: "Consumer Discretionary", perf: "-0.9%", note: "Craintes consommateur + tarifs", positive: false },
    { sector: "Consumer Staples", perf: "+0.6%", note: "Pricing power, rotation défensive", positive: true },
    { sector: "Industrials", perf: "-0.5%", note: "Tarifs pèsent sur le sentiment", positive: false },
    { sector: "Energy", perf: "+0.2%", note: "Pétrole stable, dividendes attractifs", positive: true },
    { sector: "Utilities", perf: "+1.1%", note: "Demande IA + rotation défensive", positive: true },
    { sector: "Materials", perf: "-0.4%", note: "Dollar stable, pas de catalyseur", positive: false },
    { sector: "Real Estate", perf: "+0.3%", note: "Taux stables, légère reprise", positive: true },
    { sector: "Communication Services", perf: "-0.7%", note: "Netflix en baisse, Meta consolide", positive: false }
  ],
  sectorsLecture: "La rotation défensive est le thème dominant. Les Utilities (+1.1%) mènent grâce au double catalyseur : demande énergie IA + rotation défensive. Le Healthcare (+0.8%) profite de la rotation et des résultats solides de UNH. La Tech (-1.2%) est en mode attentiste avant NVIDIA. Le Consumer Discretionary (-0.9%) souffre des craintes sur le consommateur et les tarifs. Cette configuration sectorielle est typique d'un marché en fin de cycle ou avant un catalyseur binaire.",

  techSemis: {
    overview: "Les semi-conducteurs consolident avant NVIDIA earnings. Le SOX recule de -0.5% après le rebond de +3.2% la semaine précédente.",
    highlights: [
      { title: "NVIDIA — Countdown", description: "L'action consolide à -1.5% avant les earnings mercredi. Le marché attend un CA de $38.5B et des guidances Q1 > $40B. Les options impliquent un mouvement de ±8% post-earnings." },
      { title: "AMD — Sous pression", description: "AMD recule de -2.8% sur les craintes que Blackwell creuse l'écart avec MI300X. Le marché doute de la capacité d'AMD à rivaliser dans le haut de gamme IA." },
      { title: "ASML — Stable", description: "ASML reste stable (+0.3%) — les commandes EUV restent solides et les restrictions chinoises n'impactent pas encore le carnet de commandes." }
    ],
    lectureWMB: "Le secteur semi-conducteurs est en mode binaire : tout dépend de NVIDIA mercredi. Un beat massif relancerait le rally du SOX vers les 5 500. Un miss pourrait déclencher une correction de 8-10% sur le secteur. AMD est le plus vulnérable car un beat NVIDIA confirmerait la domination de Blackwell. ASML est le plus résilient car la demande EUV est structurelle."
  },

  softwareCloud: {
    overview: "Le software enterprise attend Salesforce et Snowflake jeudi. Le secteur consolide après un Q4 solide.",
    highlights: [
      { title: "Salesforce — Test Agentforce", description: "Le marché attend la confirmation que l'IA Agentforce se traduit en revenus. Consensus : CA $10.0B (+8% YoY)." },
      { title: "Snowflake — Croissance en question", description: "Le marché veut voir une croissance product revenue > 25%. En dessous, les multiples se comprimeront." },
      { title: "ServiceNow — Momentum IA", description: "ServiceNow reste le favori du secteur après des résultats Q4 exceptionnels. L'IA Now Platform attire les entreprises." }
    ],
    lectureWMB: "Le software enterprise est à un point d'inflexion. Le marché veut voir la preuve que l'IA se traduit en revenus récurrents, pas juste en dépenses d'infrastructure. Salesforce et Snowflake sont les tests clés. Si les deux battent les attentes avec une croissance IA visible, le secteur pourrait re-rater. Si les résultats sont mitigés, la compression des multiples continuera."
  },

  healthcare: {
    overview: "Le Healthcare surperforme (+0.8%) porté par la rotation défensive et les résultats solides de UnitedHealth.",
    highlights: [
      { title: "UnitedHealth — Leader", description: "UNH +3.8% après un relèvement de guidance. Medicare Advantage reste le moteur de croissance." },
      { title: "Eli Lilly — GLP-1 Momentum", description: "Eli Lilly reste fort sur la demande de Mounjaro/Zepbound. Le marché des GLP-1 devrait atteindre $100B d'ici 2030." },
      { title: "Medtronic — Earnings S8", description: "Medtronic publie mardi — le marché attend une croissance organique de 5% et des commentaires sur le pipeline." }
    ],
    lectureWMB: "Le Healthcare est le secteur défensif le plus attractif actuellement. UnitedHealth combine croissance (Medicare Advantage) et défense (healthcare essentiel). Eli Lilly est le growth play du secteur avec les GLP-1. Le risque principal reste la régulation des prix des médicaments, mais le Congrès actuel est peu enclin à légiférer sur ce sujet."
  },

  financials: {
    overview: "Les financières sont flat (-0.3%) — les taux stables ne fournissent pas de catalyseur directionnel.",
    highlights: [
      { title: "JPMorgan — Stable", description: "JPM consolide après ses résultats Q4 solides. Jamie Dimon prévient sur l'impact des tarifs." },
      { title: "Goldman Sachs — Trading fort", description: "Goldman profite de la volatilité pour ses revenus de trading. Le M&A reste en dessous des attentes." },
      { title: "Banques régionales — Sous pression", description: "Les banques régionales (KRE -1.2%) souffrent de l'immobilier commercial et des taux élevés." }
    ],
    lectureWMB: "Les financières sont dans un no man's land. Les taux élevés sont bons pour les marges d'intérêt mais mauvais pour la demande de crédit. Les banques régionales restent le maillon faible avec l'exposition à l'immobilier commercial. Le catalyseur serait une baisse de taux (pas avant juin au minimum) ou une reprise du M&A."
  },

  cyclicals: {
    overview: "Les cycliques souffrent (-0.5%) sur les craintes de tarifs et de ralentissement.",
    highlights: [
      { title: "GM & Ford — Tarifs", description: "GM -2.3%, Ford -1.8% sur les tarifs 25% Canada/Mexique. 40% des pièces auto sont importées de ces pays." },
      { title: "Caterpillar — Chine", description: "CAT reste stable grâce à l'exposition au stimulus chinois. Les commandes de machines de construction augmentent." },
      { title: "FedEx — Indicateur avancé", description: "FedEx consolide — les volumes de colis sont un indicateur avancé de l'activité économique." }
    ],
    lectureWMB: "Les cycliques sont les plus exposées aux tarifs Trump. L'industrie automobile serait la plus touchée : GM et Ford importent 40% de leurs pièces du Canada et du Mexique. Si les tarifs sont maintenus, l'impact sur les marges serait de 200-300 bps. Caterpillar est le contrepoids positif grâce à l'exposition chinoise."
  },

  consumption: {
    overview: "La consommation est sous pression (-0.9%) après les Retail Sales décevantes de S7.",
    highlights: [
      { title: "Home Depot — Test immobilier", description: "HD publie mardi. Le marché attend des same-store sales de +3% et des commentaires sur la demande de rénovation." },
      { title: "Lowe's — Comparaison", description: "Lowe's publie aussi mardi. La comparaison HD vs LOW donnera un signal clair sur le consommateur." },
      { title: "Nike — Restructuration", description: "Nike continue sa restructuration sous le nouveau CEO. Les ventes DTC sont le focus." }
    ],
    lectureWMB: "Le secteur de la consommation est à un point critique. Les Retail Sales de -0.9% en janvier ont sonné l'alarme. Home Depot et Lowe's donneront un signal crucial mardi : si les deux déçoivent, le marché devra repriser le risque de ralentissement du consommateur. Le crédit revolving en hausse (+$15B en janvier) et l'épargne en baisse (taux d'épargne à 3.8%) sont des signaux préoccupants."
  },

  earningsWinners: [
    { rank: 1, ticker: "UNH", company: "UnitedHealth", detail: "Guidance relevée, Medicare Advantage +12% YoY, marges en expansion" },
    { rank: 2, ticker: "AXON", company: "Axon Enterprise", detail: "CA +32% YoY, adoption IA dans la sécurité publique, ARR record" },
    { rank: 3, ticker: "DECK", company: "Deckers (HOKA)", detail: "HOKA +25% YoY, guidance relevée, expansion internationale" },
    { rank: 4, ticker: "PANW", company: "Palo Alto Networks", detail: "Platformization en avance, ARR cybersécurité +28%" },
    { rank: 5, ticker: "SPOT", company: "Spotify", detail: "Abonnés premium record, marges en forte amélioration" }
  ],
  earningsWinnersLecture: "Les gagnants de la saison earnings partagent un point commun : une croissance organique forte combinée à une expansion des marges. UnitedHealth montre que le Healthcare peut être à la fois défensif et en croissance. HOKA (Deckers) continue de prendre des parts de marché à Nike. Palo Alto confirme que la cybersécurité est un secteur structurellement en croissance.",

  earningsLosers: [
    { rank: 1, ticker: "RIVN", company: "Rivian", detail: "Production en dessous des attentes, cash burn $1.5B/trimestre, guidance abaissée" },
    { rank: 2, ticker: "SNAP", company: "Snap", detail: "DAU en baisse pour la première fois, revenus pub sous pression" },
    { rank: 3, ticker: "PARA", company: "Paramount", detail: "Perte abonnés streaming, incertitude fusion Skydance" },
    { rank: 4, ticker: "BYND", company: "Beyond Meat", detail: "CA -15% YoY, restructuration en cours, cash runway limité" },
    { rank: 5, ticker: "LCID", company: "Lucid Motors", detail: "Livraisons 50% sous les objectifs, dilution massive" }
  ],
  earningsLosersLecture: "Les perdants illustrent les thèmes de 2026 : les EV non-rentables (Rivian, Lucid) sont punis, les réseaux sociaux de niche (Snap) perdent face aux géants, et les modes passées (Beyond Meat) s'effondrent. Le marché n'a plus de patience pour les entreprises qui brûlent du cash sans chemin clair vers la profitabilité.",

  guidanceThemes: [
    { title: "IA — Investissement vs Monétisation", description: "Les entreprises investissent massivement dans l'IA mais peu montrent des revenus concrets. Le marché veut voir le ROI." },
    { title: "Tarifs — Incertitude sur les marges", description: "Plusieurs entreprises (GM, Ford, Walmart) mentionnent les tarifs comme risque pour les marges 2026." },
    { title: "Consommateur sélectif", description: "Le consommateur dépense toujours mais est plus sélectif. Le trading down (premium → value) s'accélère." }
  ],
  guidanceLecture: "Les thèmes de guidance de la saison Q4 sont clairs : l'IA est un investissement massif mais les revenus tardent, les tarifs créent de l'incertitude sur les marges, et le consommateur devient plus prudent. Ces trois thèmes convergeront la semaine prochaine avec NVIDIA (IA), les tarifs (4 mars), et le PCE (consommateur).",

  analystMoves: [
    { title: "NVIDIA — Goldman relève à $180", description: "Goldman Sachs relève son objectif de prix NVIDIA à $180 (vs $160) avant les earnings, citant la demande Blackwell." },
    { title: "Tesla — Morgan Stanley abaisse à $250", description: "Morgan Stanley réduit son objectif Tesla de $300 à $250 sur les craintes de guerre des prix et les retards Robotaxi." },
    { title: "Home Depot — JPMorgan maintient Surpondérer", description: "JPMorgan maintient HD à Surpondérer avec un objectif de $420, citant la résilience du marché de la rénovation." }
  ],
  analystLecture: "Les mouvements d'analystes reflètent la polarisation du marché. NVIDIA est relevé par Goldman (confiance dans Blackwell), Tesla est abaissé par Morgan Stanley (réalisme sur les défis), et Home Depot est maintenu (confiance dans la rénovation). Le consensus reste constructif sur la tech IA mais de plus en plus prudent sur les EV et la consommation.",

  corporateActions: [
    { title: "Broadcom — Rachat d'actions $10B", description: "Broadcom annonce un programme de rachat de $10B, signal de confiance dans les flux de trésorerie." },
    { title: "Disney — Restructuration streaming", description: "Disney annonce une restructuration de sa division streaming avec un focus sur la profitabilité." },
    { title: "Pfizer — Cession actifs non-core", description: "Pfizer vend sa division santé animale pour $5B pour se recentrer sur l'oncologie et les vaccins." }
  ],
  corporateLecture: "Les actions corporate de la semaine montrent des entreprises qui optimisent leur allocation de capital. Broadcom rachète ses actions (signal de sous-valorisation perçue), Disney restructure pour la profitabilité (fin de la course aux abonnés), et Pfizer se recentre (post-COVID pivot). Ces mouvements sont positifs pour les actionnaires.",

  regulation: [
    { title: "Tarifs 25% Canada/Mexique", description: "Trump confirme les tarifs de 25% effectifs le 4 mars. Impact direct sur l'auto, l'agriculture et l'énergie." },
    { title: "Régulation IA — Sénat", description: "Le Sénat examine un projet de transparence des modèles IA. Impact limité à court terme sur les Big Tech." },
    { title: "SEC — Crypto ETFs", description: "La SEC examine de nouvelles demandes d'ETF crypto (Solana, XRP). Décisions attendues en Q2." }
  ],
  regulationLecture: "Les tarifs sont le sujet réglementaire numéro un. L'impact serait significatif : +0.5% d'inflation, -0.3% de PIB selon les estimations de JPMorgan. La régulation IA reste à un stade précoce — le projet du Sénat est modéré et ne devrait pas impacter les Big Tech à court terme. Les ETF crypto sont un catalyseur positif pour le secteur.",

  emergingThemes: [
    { number: 1, title: "Énergie pour l'IA", facts: "Les data centers IA consomment 10x plus d'énergie que les data centers traditionnels. La demande d'électricité pourrait doubler d'ici 2030.", hypothesis: "Les utilities et les producteurs d'énergie nucléaire (Constellation, Vistra) sont les grands gagnants de la révolution IA.", counterSignal: "L'efficacité énergétique des puces s'améliore rapidement — la demande pourrait être surestimée." },
    { number: 2, title: "Reshoring accéléré par les tarifs", facts: "Les tarifs Trump accélèrent le rapatriement de la production aux US. Les dépenses de construction de factories sont à un record.", hypothesis: "Les industriels US (Caterpillar, Deere) et les constructeurs (Vulcan, Martin Marietta) en profitent.", counterSignal: "Le reshoring prend 3-5 ans — l'impact à court terme est limité." },
    { number: 3, title: "GLP-1 au-delà de l'obésité", facts: "Les études montrent des bénéfices des GLP-1 sur les maladies cardiovasculaires, Alzheimer et les addictions.", hypothesis: "Le marché adressable des GLP-1 pourrait atteindre $150B d'ici 2030 (vs $50B estimé actuellement).", counterSignal: "Les effets secondaires à long terme sont inconnus — risque réglementaire si des problèmes émergent." }
  ],
  emergingThemesLecture: "Trois thèmes émergents à surveiller. L'énergie pour l'IA est le plus immédiat — les utilities surperforment depuis 6 mois sur cette thèse. Le reshoring est un thème à moyen terme accéléré par les tarifs. Les GLP-1 au-delà de l'obésité pourraient être le thème santé de la décennie. Ces trois thèmes ont en commun d'être structurels (pas cycliques) et de bénéficier de catalyseurs politiques.",

  radarStocks: [
    { rank: 1, ticker: "VST", company: "Vistra Energy", activity: "Volume 3x la moyenne, options call en hausse", catalyst: "Demande énergie IA + nucléaire renaissance", risks: "Régulation environnementale, coûts de maintenance" },
    { rank: 2, ticker: "APP", company: "AppLovin", activity: "Insiders achètent, volume en hausse", catalyst: "IA advertising, croissance mobile gaming", risks: "Dépendance Apple/Google, régulation privacy" },
    { rank: 3, ticker: "CRWD", company: "CrowdStrike", activity: "Flux institutionnels positifs", catalyst: "Cybersécurité post-incidents, platform consolidation", risks: "Concurrence Palo Alto, valorisation élevée" },
    { rank: 4, ticker: "CELH", company: "Celsius Holdings", activity: "Short interest en baisse, volume en hausse", catalyst: "Prise de parts de marché vs Monster/Red Bull", risks: "Distribution Pepsi, concurrence intense" },
    { rank: 5, ticker: "DUOL", company: "Duolingo", activity: "Analystes relèvent, options bullish", catalyst: "IA dans l'éducation, croissance abonnés premium", risks: "Monétisation internationale, concurrence gratuite" }
  ],
  radarLecture: "Le radar de la semaine met en lumière des actions avec une activité inhabituelle. Vistra Energy est le play énergie/IA le plus direct. AppLovin profite de l'IA dans la publicité mobile. CrowdStrike reste le leader cybersécurité malgré l'incident de 2024. Celsius prend des parts de marché dans les boissons énergétiques. Duolingo est le play IA/éducation. Ces actions ne sont pas des recommandations — elles méritent une analyse approfondie.",

  influentialVoices: [
    { name: "Jensen Huang", role: "CEO NVIDIA", idea: "La demande pour Blackwell dépasse tout ce que nous avons vu. L'IA est la plus grande opportunité technologique de notre vie.", whyFollowed: "CEO de la plus grande entreprise de semi-conducteurs. Ses commentaires pré-earnings donnent le ton." },
    { name: "Jamie Dimon", role: "CEO JPMorgan", idea: "Les tarifs pourraient ajouter 0.5-1% d'inflation. Le marché sous-estime le risque géopolitique.", whyFollowed: "Le banquier le plus influent de Wall Street. Ses avertissements sont souvent prophétiques." },
    { name: "Cathie Wood", role: "CEO ARK Invest", idea: "L'IA va créer $20T de valeur d'ici 2030. Les valorisations actuelles sont justifiées par la croissance future.", whyFollowed: "Voix contrarian influente. Ses thèses sur l'innovation sont suivies par les retail investors." }
  ],
  voicesLecture: "Trois voix à écouter cette semaine. Jensen Huang (NVIDIA) est optimiste avant les earnings — ses commentaires seront scrutés mercredi. Jamie Dimon (JPMorgan) prévient sur les tarifs et la géopolitique — un signal de prudence des institutionnels. Cathie Wood (ARK) reste ultra-bullish sur l'IA — représentative du sentiment retail. La divergence Dimon/Wood illustre la polarisation du marché.",

  watchlist: [
    { ticker: "NVDA", angle: "Earnings Q4 mercredi", watchFor: "CA > $40B, guidances Q1, commentaires Blackwell et Chine" },
    { ticker: "HD", angle: "Earnings mardi", watchFor: "Same-store sales > +3%, guidance FY27, commentaires consommateur" },
    { ticker: "CRM", angle: "Earnings jeudi", watchFor: "Agentforce adoption, cloud growth > 20%, marges" },
    { ticker: "GM", angle: "Impact tarifs", watchFor: "Commentaires management sur les tarifs, ajustement production" },
    { ticker: "VST", angle: "Énergie IA", watchFor: "Contrats data centers, capacité nucléaire, volume" }
  ],
  watchlistLecture: "La watchlist de la semaine est centrée sur les catalyseurs binaires. NVIDIA est le numéro un — tout le marché en dépend. Home Depot est le baromètre du consommateur. Salesforce teste la monétisation IA. GM est le proxy tarifs. Vistra est le thème émergent énergie/IA. Ces 5 actions couvrent les 5 thèmes de la semaine.",

  calendar: [
    { day: "Lundi", date: "23/02", events: ["Dallas Fed Manufacturing Index", "Futures ouvrent — réaction aux tarifs"] },
    { day: "Mardi", date: "24/02", events: ["Home Depot earnings (BO)", "Lowe's earnings (BO)", "Consumer Confidence", "Case-Shiller Home Prices"] },
    { day: "Mercredi", date: "25/02", events: ["NVIDIA Q4 earnings (AC)", "New Home Sales", "EIA Petroleum"] },
    { day: "Jeudi", date: "26/02", events: ["Salesforce earnings (AC)", "Snowflake earnings (AC)", "PIB Q4 révisé", "Jobless Claims"] },
    { day: "Vendredi", date: "27/02", events: ["PCE Core", "Personal Income & Spending", "Chicago PMI"] }
  ],
  calendarLecture: "Le calendrier de la semaine 9 est exceptionnel. Mardi : Home Depot + Consumer Confidence = signal consommateur. Mercredi : NVIDIA = signal IA/tech. Jeudi : Salesforce + PIB = signal software + macro. Vendredi : PCE = signal inflation. Chaque jour apporte un catalyseur majeur — la volatilité sera élevée.",

  earningsToWatch: [
    { day: "Mardi", date: "24/02", timing: "Before Open", ticker: "HD", company: "Home Depot", watchFor: "Same-store sales, housing outlook", highlight: true },
    { day: "Mardi", date: "24/02", timing: "Before Open", ticker: "LOW", company: "Lowe's", watchFor: "DIY vs Pro, guidance", highlight: false },
    { day: "Mercredi", date: "25/02", timing: "After Close", ticker: "NVDA", company: "NVIDIA", watchFor: "CA, guidances Q1, Blackwell", highlight: true },
    { day: "Jeudi", date: "26/02", timing: "After Close", ticker: "CRM", company: "Salesforce", watchFor: "Agentforce, cloud growth", highlight: true },
    { day: "Jeudi", date: "26/02", timing: "After Close", ticker: "SNOW", company: "Snowflake", watchFor: "Product revenue, NRR", highlight: false }
  ],
  earningsToWatchLecture: "Cinq earnings à surveiller, trois sont des must-watch (HD, NVDA, CRM). Home Depot mardi donnera le ton sur le consommateur. NVIDIA mercredi est l'événement de la semaine. Salesforce jeudi testera la monétisation IA dans le software. Lowe's et Snowflake sont des confirmations secondaires.",

  scenarios: [
    { name: "Bull — NVIDIA Beat + PCE Soft", probability: "30%", triggers: "NVIDIA CA > $40B + PCE ≤ 2.6%", signals: "Nasdaq +3-5%, SOX vers 5 500, VIX < 14", invalidation: "NVIDIA miss sur les guidances" },
    { name: "Base — Mixed", probability: "45%", triggers: "NVIDIA en ligne, PCE à 2.7%", signals: "Marché flat, rotation continue, volume modéré", invalidation: "Choc exogène (tarifs, géopolitique)" },
    { name: "Bear — NVIDIA Miss ou PCE Hot", probability: "25%", triggers: "NVIDIA guidances décevantes ou PCE > 2.9%", signals: "Nasdaq -3-5%, VIX > 22, flight-to-safety", invalidation: "NVIDIA beat massif malgré le PCE" }
  ],
  risks: [
    { title: "NVIDIA Guidance Miss", description: "Un ralentissement de la demande Blackwell ou des restrictions chinoises renforcées déclencherait une correction tech de 5-8%." },
    { title: "Tarifs 25% maintenus", description: "Si les tarifs sont maintenus le 4 mars, l'auto et l'agriculture seraient immédiatement impactées. GM, Ford, ADM en première ligne." },
    { title: "PCE Surprise haussière", description: "Un PCE > 2.9% repousserait les baisses de taux et pèserait sur les valuations growth." },
    { title: "Consommateur en panne", description: "Si Home Depot et Lowe's déçoivent mardi, combiné aux Retail Sales de S7, le signal de ralentissement serait confirmé." }
  ],
  scenarioDisclaimer: "Ces scénarios sont des hypothèses pédagogiques basées sur les données disponibles au 22/02/2026. Ils ne constituent en aucun cas des prévisions ou des recommandations d'investissement.",
  conclusion: "La semaine 9 est la plus importante du trimestre. NVIDIA, PCE et tarifs — trois catalyseurs qui peuvent changer la direction du marché. La rotation défensive suggère que les institutionnels se préparent au pire tout en espérant le meilleur. La clé : ne pas réagir émotionnellement aux headlines mais attendre les données.",
  conclusionLecture: "En résumé : surveillez NVIDIA mercredi pour le signal tech/IA, le PCE vendredi pour le signal macro/Fed, et les tarifs pour le risque politique. La combinaison de ces trois facteurs déterminera si le marché reprend sa tendance haussière ou entre en correction. Restez informés, restez disciplinés.",
  sources: "Sources : Bloomberg, Reuters, CME FedWatch, BLS, BEA, NVIDIA IR, Salesforce IR, Home Depot IR, Goldman Sachs Research, JPMorgan Research, Morgan Stanley Research. Données au 22/02/2026.",
  disclaimer: "⚠️ WallStreet Market Brief est un document strictement informatif. Il ne constitue en aucun cas un conseil en investissement, une recommandation d'achat ou de vente, ni un signal de trading. Consultez un conseiller financier agréé avant toute décision d'investissement."
};
