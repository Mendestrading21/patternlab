/**
 * WMB Brief USA — Semaine 9 (23/02 – 27/02/2026)
 * NVIDIA Earnings, PCE Inflation & Tarifs Douaniers — Volatilité Attendue
 */
import type { BriefData } from "../brief";
export const BRIEF_SEMAINE_9: BriefData = {
  id: 2,
  weekNumber: 9,
  year: 2026,
  dateRange: "LUN 23/02 - VEN 27/02",
  title: "NVIDIA Earnings, PCE Inflation & Tarifs Douaniers -- Volatilite Attendue",
  subtitle: "NVIDIA Q4, PCE core, tarifs Trump, rotation sectorielle",
  publishedAt: "2026-02-22T08:00:00Z",

  executiveSummary: {
    weekPast: [
      "S&P 500 en légère baisse (-0.42%) après une semaine de consolidation post-records",
      "Les minutes de la Fed confirment une pause prolongée — aucune baisse avant juin au minimum",
      "Walmart publie des résultats solides mais prévient d'un ralentissement de la consommation",
      "Le dollar rebondit légèrement (DXY 100.8) sur les anticipations de taux stables",
      "L'or atteint un nouveau record à 4 850 $/oz sur les tensions géopolitiques"
    ],
    weekAhead: [
      "NVIDIA Q4 earnings mercredi — le catalyseur le plus attendu du trimestre",
      "PCE core vendredi — indicateur d'inflation préféré de la Fed",
      "Trump annonce de nouveaux tarifs sur le Canada et le Mexique (25%)",
      "Confiance du consommateur (Conference Board) mardi",
      "PIB US révisé (Q4) jeudi — confirmation du ralentissement ?"
    ],
    lectureWMB: "La semaine 9 est un tournant potentiel pour le marché. NVIDIA est devenu le baromètre du sentiment sur l'IA — un beat massif relancerait le rally tech, un miss pourrait déclencher une correction de 5-8% sur le Nasdaq. Le PCE core de vendredi est tout aussi crucial : au-dessus de 2.8%, la Fed n'a aucune raison de baisser les taux avant septembre. Les tarifs Trump ajoutent une couche d'incertitude — le marché n'a pas encore pricé l'impact sur les marges des entreprises importatrices."
  },

  indices: [
    { ticker: "SPX", value: "6 015", change1W: "-0.42%", changeYTD: "+2.1%" },
    { ticker: "NDX", value: "21 450", change1W: "-0.85%", changeYTD: "+3.5%" },
    { ticker: "DJIA", value: "44 200", change1W: "+0.15%", changeYTD: "+3.2%" },
    { ticker: "RUT", value: "2 280", change1W: "-1.2%", changeYTD: "-0.5%" }
  ],
  indicesSignal: "Consolidation sous les records — le S&P 500 teste le support 6 000. Divergence Dow/Nasdaq en faveur des défensives.",
  indicesInvalidation: "Clôture sous 5 950 sur le S&P 500 invaliderait la tendance haussière court terme.",
  indicesLecture: "Le marché est en mode attentiste avant NVIDIA et le PCE. Le S&P 500 consolide autour de 6 015 après avoir touché un record à 6 080 la semaine précédente. La divergence entre le Dow (+0.15%) et le Nasdaq (-0.85%) confirme la rotation vers les défensives. Les small caps (Russell 2000 -1.2%) souffrent davantage, reflétant les craintes sur la croissance domestique. Le support clé est à 6 000 — en dessous, on pourrait voir une accélération vers 5 900.",

  vix: {
    value: "16.20",
    regime: "Volatilité modérée — en hausse avant NVIDIA earnings",
    watch: "VIX pourrait spike au-dessus de 20 si NVIDIA déçoit mercredi soir.",
    lectureWMB: "Le VIX à 16.20 est légèrement au-dessus de sa moyenne de février (~15), reflétant la nervosité pré-NVIDIA. Historiquement, le VIX augmente de 2-3 points dans les 48h précédant les earnings NVIDIA. Un miss enverrait le VIX au-dessus de 22 rapidement. À l'inverse, un beat massif pourrait le ramener sous 14. Le ratio put/call sur les options NVIDIA est à 0.85, indiquant un biais légèrement baissier du marché des options."
  },

  fx: [
    { pair: "DXY", value: "100.80", note: "Dollar stable — rebond technique après la baisse de janvier" },
    { pair: "EUR/USD", value: "1.082", note: "Euro sous pression — BCE dovish vs Fed hawkish" },
    { pair: "USD/CHF", value: "0.88", note: "Franc suisse stable — pas de flux refuge majeur" }
  ],
  fxAlert: "Niveau d'alerte : DXY > 102 (confirmerait un renforcement structurel du dollar)",
  fxInvalidation: "Niveau d'invalidation : DXY < 99 (retour à la faiblesse de janvier)",
  fxLecture: "Le dollar se stabilise à 100.80 après sa correction de janvier. La divergence de politique monétaire (Fed en pause vs BCE qui pourrait baisser en avril) soutient le billet vert. Le CHF reste stable à 0.88, sans flux refuge significatif cette semaine. Les tarifs Trump sur le Canada/Mexique pourraient paradoxalement renforcer le dollar à court terme (flight-to-safety) mais l'affaiblir à moyen terme (inflation importée). Pour les investisseurs suisses, la stabilité du CHF/USD est une bonne nouvelle pour les positions en actifs américains.",

  rates: [
    { label: "Taux 10 ans US", value: "4.28%", note: "Stable — marché attend le PCE vendredi" },
    { label: "Taux 2 ans US", value: "4.15%", note: "Légère hausse — Fed en pause prolongée" },
    { label: "Courbe 2s10s", value: "+13 bps", note: "Légèrement pentifiée — normalisation lente" }
  ],
  fedFunds: "4.25% – 4.50%",
  fedProba: "Statu quo en mars : ~98%. Prochaine baisse possible en juin (~35% de probabilité).",
  ratesLecture: "Les taux restent stables en attendant le PCE de vendredi. Le 10 ans à 4.28% reflète un marché qui ne croit plus à des baisses rapides de la Fed. Le 2 ans à 4.15% a légèrement monté après les minutes hawkish de la Fed. La courbe 2s10s à +13 bps continue sa normalisation lente. Le PCE core est le catalyseur : au-dessus de 2.8% YoY, les taux longs pourraient tester 4.40%. En dessous de 2.6%, on reverrait les espoirs de baisse en juin.",

  credit: {
    spreadsIG: "Spreads IG à ~85 bps — conditions de crédit saines",
    spreadsHY: "Spreads HY à ~310 bps — pas de stress",
    sofr: "SOFR à 4.30% — liquidité normale",
    alert: "Surveiller : impact tarifs sur les émetteurs HY exposés au commerce international",
    lectureWMB: "Le marché du crédit reste sain avec des spreads IG à 85 bps et HY à 310 bps — bien en dessous des niveaux de stress. Les émissions obligataires restent soutenues, signe de confiance. Le risque principal serait un choc sur les entreprises exposées aux tarifs (auto, retail, agriculture) qui pourrait élargir les spreads HY sectoriellement. Le SOFR stable à 4.30% confirme que la liquidité interbancaire fonctionne normalement."
  },

  commodities: [
    { name: "Or", symbol: "XAU", value: "~4 850 $/oz", note: "Nouveau record — tensions géopolitiques + achats banques centrales" },
    { name: "Argent", symbol: "XAG", value: "~72 $/oz", note: "Suit l'or — demande industrielle solide" },
    { name: "WTI", symbol: "CL", value: "~71.50 $", note: "Stable — équilibre offre/demande" },
    { name: "Brent", symbol: "BZ", value: "~75.20 $", note: "Prime géopolitique modérée" },
    { name: "Cuivre", symbol: "HG", value: "~4.35 $/lb", note: "En hausse — stimulus chinois" }
  ],
  commoditiesLecture: "L'or continue sa marche vers les 5 000 $ avec un nouveau record à 4 850 $. Les achats des banques centrales (Chine, Inde, Turquie) restent le moteur principal. Le pétrole est stable autour de 71-75 $, l'OPEC+ maintenant ses coupes. Le cuivre profite des annonces de stimulus chinois. Les tarifs Trump pourraient créer de la volatilité sur les matières premières agricoles (maïs, soja) si le Canada et le Mexique ripostent.",

  crypto: [
    { name: "Bitcoin", symbol: "BTC", value: "~92 000 $", note: "Consolidation après le rally de janvier" },
    { name: "Ethereum", symbol: "ETH", value: "~3 200 $", note: "Sous-performance vs BTC — rotation vers les altcoins" },
    { name: "Solana", symbol: "SOL", value: "~165 $", note: "Forte activité DeFi — volumes en hausse" }
  ],
  cryptoLecture: "Le Bitcoin consolide autour de 92 000 $ après son rally de janvier (+15%). Les flux ETF spot restent positifs mais ralentissent. Ethereum sous-performe à 3 200 $ tandis que Solana attire les flux DeFi. Le marché crypto est en mode attentiste avant les données macro de la semaine. Un PCE élevé serait négatif pour les cryptos (taux plus hauts plus longtemps).",

  keyPoints: [
    { title: "NVIDIA — Le verdict de l'IA", description: "Mercredi après la clôture. Consensus : CA $38.5B (+65% YoY). Le marché attend surtout les guidances Q1 et les commentaires sur Blackwell." },
    { title: "PCE Core — L'inflation qui compte", description: "Vendredi 8h30 ET. Consensus : +2.7% YoY. Au-dessus de 2.8%, la Fed reste en pause jusqu'en septembre minimum." },
    { title: "Tarifs Trump — Canada & Mexique", description: "25% de tarifs annoncés sur les importations canadiennes et mexicaines. Impact direct sur l'auto, l'agriculture et l'énergie." },
    { title: "Rotation sectorielle en cours", description: "Les défensives (Utilities, Healthcare, Staples) surperforment la tech depuis 2 semaines. Signal de prudence du marché." }
  ],
  keyPointsLecture: "Quatre catalyseurs majeurs cette semaine. NVIDIA est le plus important : l'action représente ~7% du S&P 500 et son mouvement post-earnings peut déplacer l'indice de 1-2%. Le PCE est le deuxième : c'est l'indicateur que la Fed regarde le plus attentivement. Les tarifs sont le wildcard — le marché n'a pas encore pricé l'impact complet. La rotation sectorielle suggère que les institutionnels se positionnent défensivement.",

  timeline: [
    { day: "Lundi", date: "23/02", events: ["Futures ouvrent — première réaction aux tarifs du weekend", "Dallas Fed Manufacturing Index"] },
    { day: "Mardi", date: "24/02", events: ["Conference Board Consumer Confidence", "Case-Shiller Home Prices", "Début de la semaine NVIDIA"] },
    { day: "Mercredi", date: "25/02", events: ["NVIDIA Q4 Earnings (après clôture)", "New Home Sales", "EIA Petroleum Status"] },
    { day: "Jeudi", date: "26/02", events: ["PIB US Q4 (2e estimation)", "Durable Goods Orders", "Jobless Claims"] },
    { day: "Vendredi", date: "27/02", events: ["PCE Core (8h30 ET)", "Personal Income & Spending", "Chicago PMI"] }
  ],

  macroContext: "L'économie US montre des signes de ralentissement modéré. Le PIB Q4 devrait être révisé à la baisse (~2.1% vs 2.3% initial). La consommation reste le pilier mais Walmart a signalé un consommateur plus prudent. L'inflation PCE core devrait rester sticky autour de 2.7%, bien au-dessus de la cible de 2%.",
  macroExpectations: "Le marché attend une confirmation du soft landing. Un PCE > 2.8% relancerait les craintes de stagflation. Un PIB < 2.0% alimenterait les craintes de récession. Le scénario idéal : PCE à 2.6% et PIB à 2.1%.",
  macroScenarios: [
    { label: "Goldilocks", description: "PCE ≤ 2.6%, PIB ~2.1% → Rally S&P vers 6 100, taux 10 ans vers 4.15%" },
    { label: "Stagflation Lite", description: "PCE ≥ 2.9%, PIB < 2.0% → Correction S&P vers 5 900, VIX > 20" },
    { label: "Status Quo", description: "PCE 2.7%, PIB 2.1% → Marché flat, attente de la réunion Fed de mars" }
  ],
  macroCalendar: [
    { date: "24/02", time: "10:00", indicator: "Consumer Confidence", consensus: "104.5", previous: "104.1", sensitiveAssets: "S&P 500, USD, Consumer Discretionary" },
    { date: "26/02", time: "08:30", indicator: "PIB Q4 (2e estimation)", consensus: "2.1%", previous: "2.3%", sensitiveAssets: "Treasuries, USD, Indices" },
    { date: "26/02", time: "08:30", indicator: "Durable Goods Orders", consensus: "-0.3%", previous: "+0.5%", sensitiveAssets: "Industrials, Transports" },
    { date: "27/02", time: "08:30", indicator: "PCE Core YoY", consensus: "2.7%", previous: "2.8%", sensitiveAssets: "Treasuries, Or, Tech, Indices" },
    { date: "27/02", time: "08:30", indicator: "Personal Spending", consensus: "+0.3%", previous: "+0.7%", sensitiveAssets: "Retail, Consumer Discretionary" }
  ],
  macroLecture: "La macro de la semaine 9 est dominée par le PCE de vendredi. Le consensus à 2.7% serait un léger progrès vs 2.8% le mois précédent, mais insuffisant pour que la Fed change de cap. Le PIB Q4 révisé à 2.1% confirmerait un ralentissement ordonné. Les Durable Goods Orders en baisse (-0.3%) refléteraient l'incertitude des entreprises face aux tarifs. Le Consumer Confidence est le premier indicateur à surveiller mardi — un chiffre sous 100 serait un signal d'alerte.",

  fedContext: "La Fed est en mode pause. Les minutes de la semaine 8 ont confirmé que les membres veulent voir 'plus de progrès sur l'inflation' avant toute baisse. Le dot plot de décembre indiquait 2 baisses en 2026, mais le marché n'en price plus qu'une seule (juin ou septembre).",
  fedSpeakers: [
    { name: "Christopher Waller", date: "24/02", stance: "Hawkish — insiste sur la patience face à l'inflation sticky" },
    { name: "Raphael Bostic", date: "25/02", stance: "Neutre — data-dependent, pas pressé de bouger" },
    { name: "Mary Daly", date: "26/02", stance: "Dovish — préoccupée par le marché de l'emploi" }
  ],
  fedAlert: "Surveiller : réaction des Fed speakers au PCE de vendredi. Si PCE > 2.8%, les hawks domineront le discours.",
  fedLecture: "La Fed est clairement en mode 'higher for longer'. Les minutes ont révélé que plusieurs membres sont préoccupés par l'impact inflationniste des tarifs Trump. Le marché ne price plus que 35% de probabilité d'une baisse en juin. Le PCE de vendredi est crucial : un chiffre au-dessus de 2.8% repousserait les baisses à septembre voire décembre. La divergence entre la Fed (en pause) et la BCE (qui pourrait baisser en avril) continue de soutenir le dollar.",

  sectors: [
    { name: "Technology", perf1W: -1.2 },
    { name: "Healthcare", perf1W: 0.8 },
    { name: "Financials", perf1W: -0.3 },
    { name: "Consumer Discretionary", perf1W: -0.9 },
    { name: "Consumer Staples", perf1W: 0.6 },
    { name: "Industrials", perf1W: -0.5 },
    { name: "Energy", perf1W: 0.2 },
    { name: "Utilities", perf1W: 1.1 },
    { name: "Materials", perf1W: -0.4 },
    { name: "Real Estate", perf1W: 0.3 },
    { name: "Communication Services", perf1W: -0.7 }
  ],
  sectorsLecture: "La rotation défensive se confirme : Utilities (+1.1%), Healthcare (+0.8%) et Staples (+0.6%) mènent tandis que Tech (-1.2%) et Consumer Discretionary (-0.9%) reculent. Cette divergence est typique d'un marché qui se prépare à un catalyseur binaire (NVIDIA). L'énergie reste stable (+0.2%) malgré les tarifs, soutenue par le pétrole.",
  sectorsScenarios: "SI NVIDIA beat → rotation retour vers la tech, Nasdaq +3-5% en une semaine. SI NVIDIA miss → accélération de la rotation défensive, Utilities et Healthcare surperforment encore.",

  stocksMarketMoving: [
    { ticker: "NVDA", company: "NVIDIA", date: "25/02", timing: "After Close", consensus: "EPS $0.89, CA $38.5B", watchFor: "Guidances Q1, demande Blackwell, commentaires sur la Chine", risk: "Miss sur les guidances ou ralentissement de la demande IA", sensitivity: "Très élevée — peut déplacer le S&P de 1-2%" },
    { ticker: "CRM", company: "Salesforce", date: "26/02", timing: "After Close", consensus: "EPS $2.61, CA $10.0B", watchFor: "Croissance cloud, adoption IA Agentforce, marges", risk: "Ralentissement des dépenses IT enterprise", sensitivity: "Élevée — baromètre du software enterprise" },
    { ticker: "SNOW", company: "Snowflake", date: "26/02", timing: "After Close", consensus: "EPS $0.18, CA $905M", watchFor: "Product revenue growth, net revenue retention", risk: "Compression des multiples si croissance < 25%", sensitivity: "Modérée — indicateur du cloud data" }
  ],
  stocksLecture: "NVIDIA est LE stock de la semaine. Son poids dans les indices (~7% du S&P, ~12% du Nasdaq) en fait un market mover systémique. Salesforce et Snowflake donneront le ton du software enterprise. Le marché sera particulièrement attentif aux commentaires sur l'IA : est-ce que les dépenses IA se traduisent en revenus concrets ou reste-t-on dans la phase d'investissement ?",

  mag7: [
    { ticker: "AAPL", perfYTD: "+1.5%", catalyst: "iPhone 17 rumors, services en croissance", positive: true },
    { ticker: "MSFT", perfYTD: "+3.2%", catalyst: "Azure IA, Copilot adoption, cloud growth", positive: true },
    { ticker: "GOOGL", perfYTD: "+5.1%", catalyst: "Search IA, YouTube premium, cloud", positive: true },
    { ticker: "AMZN", perfYTD: "+4.8%", catalyst: "AWS growth, advertising, retail margins", positive: true },
    { ticker: "NVDA", perfYTD: "+8.5%", catalyst: "Blackwell ramp, data center demand", positive: true },
    { ticker: "META", perfYTD: "+6.2%", catalyst: "Reels monetization, Reality Labs progress", positive: true },
    { ticker: "TSLA", perfYTD: "-5.3%", catalyst: "Guerre des prix, Robotaxi delays, Musk distraction", positive: false }
  ],
  mag7Lecture: "Les Magnificent 7 restent le moteur du marché avec 6 sur 7 en territoire positif YTD. NVIDIA mène (+8.5%) avant ses earnings. Tesla est le seul en négatif (-5.3%) sur les craintes de guerre des prix et les retards du Robotaxi. La concentration du marché reste un risque : les Mag 7 représentent ~32% du S&P 500. Un miss NVIDIA pourrait effacer 1-2% de l'indice en une seule séance.",

  themes: [
    { title: "IA — Phase 2 : Monétisation", description: "Le marché passe de 'qui investit dans l'IA' à 'qui gagne de l'argent avec l'IA'. NVIDIA earnings = test décisif." },
    { title: "Tarifs Trump — Retour du protectionnisme", description: "25% sur Canada/Mexique. Impact direct sur l'auto (GM, F), l'agriculture (ADM, BG), et l'énergie (pétrole canadien)." },
    { title: "Rotation défensive", description: "Les institutionnels réduisent l'exposition tech et augmentent les défensives. Signal de prudence, pas de panique." },
    { title: "Inflation sticky", description: "Le PCE core reste au-dessus de 2.5% depuis 18 mois. La Fed n'a pas de marge pour baisser les taux." }
  ],
  divergences: "Divergence entre le Dow (record) et le Nasdaq (en consolidation). Divergence entre les flux ETF (positifs sur les défensives) et le sentiment retail (toujours bullish tech).",
  surprises: "Walmart qui prévient d'un ralentissement de la consommation alors que les données macro restent solides. L'or qui continue de monter malgré un dollar stable.",

  voices: [
    { name: "Jamie Dimon", role: "CEO JPMorgan", description: "Prévient que les tarifs pourraient ajouter 0.5-1% d'inflation et ralentir la croissance de 0.3-0.5%." },
    { name: "Jensen Huang", role: "CEO NVIDIA", description: "Avant les earnings : 'La demande pour Blackwell dépasse tout ce que nous avons vu.' Le marché attend la confirmation." },
    { name: "Larry Fink", role: "CEO BlackRock", description: "Recommande une surpondération des actifs réels (or, infrastructure) face à l'inflation sticky." }
  ],

  policyContext: "Trump intensifie la guerre commerciale avec l'annonce de tarifs de 25% sur le Canada et le Mexique, effectifs le 4 mars. Le Congrès débat d'un nouveau package fiscal incluant des baisses d'impôts pour les entreprises.",
  policyCards: [
    { title: "Tarifs Canada/Mexique 25%", description: "Effectifs le 4 mars. Secteurs impactés : automobile, agriculture, énergie. Le Canada et le Mexique préparent des mesures de rétorsion." },
    { title: "Package fiscal Trump", description: "Baisses d'impôts corporate de 21% à 15% pour les entreprises qui produisent aux US. Financement incertain." },
    { title: "Régulation IA", description: "Le Sénat examine un projet de loi sur la transparence des modèles IA. Impact limité sur les Big Tech à court terme." }
  ],
  policyScenarios: [
    { label: "Escalade commerciale", description: "SI tarifs maintenus + rétorsion Canada/Mexique → inflation +0.5%, PIB -0.3%, auto et agriculture sous pression" },
    { label: "Négociation", description: "SI tarifs utilisés comme levier de négociation → retrait partiel en avril, impact limité sur les marchés" }
  ],
  policyLecture: "Les tarifs Trump sont le wildcard de la semaine. Le marché traite ces annonces comme du bruit politique (les tarifs ont souvent été annoncés puis reportés), mais cette fois le calendrier est précis (4 mars). L'impact serait significatif : l'auto US dépend à 40% de pièces canadiennes/mexicaines. Les entreprises les plus exposées : GM, Ford, Stellantis, mais aussi les retailers (Walmart, Target) qui importent massivement.",

  earnings: [
    { day: "Mercredi", date: "25/02", timing: "After Close", ticker: "NVDA", company: "NVIDIA", consensus: "EPS $0.89", watchFor: "Guidances Q1, Blackwell ramp, China exposure", risk: "Miss sur les guidances", highlight: true },
    { day: "Jeudi", date: "26/02", timing: "After Close", ticker: "CRM", company: "Salesforce", consensus: "EPS $2.61", watchFor: "Cloud growth, Agentforce adoption", risk: "Ralentissement enterprise spending", highlight: false },
    { day: "Jeudi", date: "26/02", timing: "After Close", ticker: "SNOW", company: "Snowflake", consensus: "EPS $0.18", watchFor: "Product revenue, NRR", risk: "Compression multiples", highlight: false },
    { day: "Mardi", date: "24/02", timing: "Before Open", ticker: "HD", company: "Home Depot", consensus: "EPS $3.02", watchFor: "Same-store sales, housing outlook", risk: "Faiblesse immobilier résidentiel", highlight: false },
    { day: "Mardi", date: "24/02", timing: "Before Open", ticker: "LOW", company: "Lowe's", consensus: "EPS $1.65", watchFor: "DIY vs Pro trends, guidance", risk: "Consommateur prudent", highlight: false }
  ],
  earningsLecture: "NVIDIA domine le calendrier earnings. Le consensus attend un CA de $38.5B (+65% YoY) mais le whisper number est plus proche de $40B. Les guidances Q1 sont plus importantes que le Q4 réalisé — le marché veut savoir si la demande Blackwell tient. Home Depot et Lowe's donneront un signal sur la santé du consommateur et de l'immobilier. Salesforce et Snowflake testeront la thèse 'IA = revenus' dans le software.",

  scenarios: [
    { name: "Bull — NVIDIA Beat + PCE Soft", probability: "30%", description: "NVIDIA bat les attentes (CA > $40B) et le PCE sort à 2.6% ou moins", result: "S&P 500 vers 6 100-6 150, Nasdaq +3-5%, VIX < 14", signal: "NVIDIA +8-12% post-earnings, taux 10 ans < 4.20%" },
    { name: "Base — Mixed Signals", probability: "45%", description: "NVIDIA bat légèrement, PCE à 2.7% (consensus)", result: "S&P 500 flat à 6 000-6 050, rotation continue", signal: "NVIDIA +2-4%, marché digère les données" },
    { name: "Bear — NVIDIA Miss ou PCE Hot", probability: "25%", description: "NVIDIA déçoit sur les guidances ou PCE > 2.9%", result: "S&P 500 vers 5 900-5 950, Nasdaq -3-5%, VIX > 22", signal: "NVIDIA -8-15%, flight-to-safety vers Treasuries et or" }
  ],
  risks: [
    { title: "NVIDIA Guidance Miss", description: "Un ralentissement de la demande Blackwell ou des restrictions chinoises renforcées pourrait déclencher une correction tech de 5-8%." },
    { title: "PCE Inflation Surprise", description: "Un PCE core > 2.9% repousserait les baisses de taux à décembre et pèserait sur les valuations growth." },
    { title: "Escalade Tarifs", description: "Si les tarifs de 25% sont maintenus et que le Canada/Mexique ripostent, l'impact sur les marges corporate serait significatif." },
    { title: "Concentration Mag 7", description: "Les 7 plus grandes capitalisations représentent 32% du S&P 500. Un mouvement coordonné à la baisse aurait un impact systémique." }
  ],
  scenarioDisclaimer: "Ces scénarios sont des hypothèses pédagogiques basées sur les données disponibles au 22/02/2026. Ils ne constituent en aucun cas des prévisions ou des recommandations d'investissement.",
  scenariosLecture: "Le scénario de base (45%) est un marché qui digère des signaux mixtes. Le bull case (30%) nécessite un double catalyseur positif (NVIDIA + PCE). Le bear case (25%) est le plus dangereux car il combinerait un choc micro (NVIDIA) et macro (inflation). La clé : surveiller les futures NVIDIA jeudi matin pour le premier signal, puis le PCE vendredi pour la confirmation.",

  glossary: [
    { term: "PCE Core", definition: "Personal Consumption Expenditures hors alimentation et énergie — indicateur d'inflation préféré de la Fed." },
    { term: "Whisper Number", definition: "Estimation informelle des analystes, souvent plus élevée que le consensus officiel." },
    { term: "Blackwell", definition: "Nouvelle architecture GPU de NVIDIA pour l'IA, successeur de Hopper." },
    { term: "Dot Plot", definition: "Graphique des projections de taux des membres du FOMC — indique les anticipations de la Fed." },
    { term: "Flight-to-Safety", definition: "Mouvement des investisseurs vers les actifs refuges (Treasuries, or, CHF) en période de stress." },
    { term: "Rotation Sectorielle", definition: "Déplacement des flux d'un secteur à un autre — ici, de la tech vers les défensives." }
  ],
  sources: "Sources : Bloomberg, Reuters, CME FedWatch, BLS, BEA, Fed Minutes, NVIDIA IR, Walmart IR, JPMorgan Research, BlackRock Investment Institute. Données au 22/02/2026.",
  disclaimer: "⚠️ WallStreet Market Brief est un document strictement informatif. Il ne constitue en aucun cas un conseil en investissement, une recommandation d'achat ou de vente, ni un signal de trading. Les scénarios présentés sont des hypothèses pédagogiques. Consultez un conseiller financier agréé avant toute décision d'investissement."
};
