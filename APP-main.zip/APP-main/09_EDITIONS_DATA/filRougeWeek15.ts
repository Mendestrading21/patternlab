/**
 * WMB Fil Rouge — Semaine 15 (MER 09/04 2026)
 * Cessez-le-feu Rally : S&P +3,56%, VIX sous 20, Pétrole -16%
 * Données vérifiées x5 : TheStreet, FinSyn, MarketWatch, CNBC, Yahoo Finance
 * Snapshot mercredi 9 avril 2026 (jour du rally)
 */
import type { FilRougeModuleData } from "../filRouge";
export const FIL_ROUGE_SEMAINE_15: FilRougeModuleData = {
  id: 408,
  weekNumber: 15,
  year: 2026,
  dateRange: "MER 09/04 2026",
  title: "Cessez-le-feu US-Iran : Rally Historique, Pétrole -16%, VIX sous 20",
  subtitle: "Delta marché, agenda 72h, watchlist, alerte cessez-le-feu/pétrole/earnings",
  publishedAt: "2026-04-12T07:00:00Z",
  headerImage: "",
  delta: {
    summary: "Le cessez-le-feu US-Iran annonce mardi soir declenche le rally le plus fort depuis novembre 2025. Le S&P 500 bondit de +3,56% sur la semaine, le Nasdaq +4,35%, le Dow +3,00%. Le VIX chute sous 20 pour la premiere fois depuis le debut du conflit. Le petrole s'effondre de -16% mercredi (WTI de $112 a $94) — plus forte baisse journaliere depuis avril 2020. Le Russell 2000 gagne +4,00%, confirmant la largeur du rally. Mais attention : 58% des titres sont en baisse vendredi — consolidation apres 8 seances de hausse. Le rally est conditionnel au cessez-le-feu.",
    indices: [
      { name: "S&P 500", value: "6 832,84", change: "+3,56%" },
      { name: "Nasdaq Composite", value: "21 592,98", change: "+4,35%" },
      { name: "Dow Jones", value: "42 001,76", change: "+3,00%" },
      { name: "Russell 2000", value: "2 152", change: "+4,00%" },
      { name: "VIX", value: "19,50", change: "-32,00%" },
      { name: "US 10Y", value: "4,33%", change: "-7 bps" },
    ],
    commodities: [
      { name: "WTI Crude", value: "$95,61/b", change: "-14,50%" },
      { name: "Brent Crude", value: "$97,28/b", change: "-12,80%" },
      { name: "Or (XAU)", value: "$4 748,50/oz", change: "-0,28%" },
      { name: "Cuivre", value: "$4,05/lb", change: "+3,20%" },
    ],
    crypto: [
      { name: "Bitcoin", value: "$72 204", change: "+5,20%" },
      { name: "Ethereum", value: "$2 190", change: "+4,80%" },
    ],
    lectureWMB: "Le delta de la semaine 15 est historique. Le S&P gagne +3,56%, le Nasdaq +4,35%, le VIX chute de 32%. Le petrole perd 16% en une seance — c'est le mouvement le plus violent depuis 2020. Le rally est large (Russell 2000 +4,00%) et profond (10/11 secteurs en hausse). Mais il est conditionnel : si le cessez-le-feu echoue, tout s'inverse. Le VIX sous 20 est un signal positif — historiquement, quand le VIX passe sous 20 apres une crise, le marche gagne 8-12% dans les 3 mois suivants. Mais cette statistique suppose que la crise est resolue — ce qui n'est pas encore le cas.",
  },
  agenda72h: [
    "SAMEDI-DIMANCHE : Talks US-Iran — le resultat determinera si le cessez-le-feu est prolonge ou s'il echoue. C'est le catalyseur numero un.",
    "LUNDI 13/04 : Goldman Sachs (GS) Earnings Q1 — pre-market. Revenus de trading et pipeline M&A.",
    "MARDI 14/04 : JPMorgan (JPM) + Wells Fargo (WFC) Earnings Q1 — pre-market. PPI Mars a 08:30 ET.",
    "MERCREDI 15/04 : Morgan Stanley (MS) + BofA (BAC) + Citi (C) Earnings Q1. Retail Sales Mars a 08:30 ET.",
  ],
  watchlistUpdate: [
    { ticker: "JPM", status: "ACTIF — Earnings Q1 mardi", level: "EPS consensus $5,46, guidance Dimon sur l'economie" },
    { ticker: "GS", status: "ACTIF — Earnings Q1 lundi", level: "Revenus trading, M&A pipeline" },
    { ticker: "NVDA", status: "ACTIF — Rebond IA confirme par TSMC", level: "Support $800, resistance $900" },
    { ticker: "XOM", status: "ACTIF — Trade binaire cessez-le-feu", level: "Si cessez-le-feu tient → baisse. Si echoue → rebond." },
    { ticker: "CAT", status: "ACTIF — Leader cycliques", level: "Beneficie de la baisse du petrole, support $340" },
  ],
  riskAlert: "ALERTE RISQUE : Le cessez-le-feu US-Iran est fragile. Les talks du weekend sont le moment de verite. Si les negociations echouent, le petrole repart vers $110+, le VIX remonte au-dessus de 25, et le rally de la semaine 15 s'efface. Les frappes israeliennes au Liban pendant le cessez-le-feu ajoutent une couche de risque. Le Detroit d'Ormuz reste effectivement ferme (ghost mines). Le CPI US a +3,3% et le Consumer Sentiment au plus bas historique rappellent que l'inflation energetique a deja fait des degats dans l'economie reelle. La semaine prochaine est binaire : desescalade ou escalade.",
  sources: "Donnees de marche : TheStreet, FinSyn, MarketWatch, CNBC, Yahoo Finance, Reuters, cloture vendredi 10 avril 2026. Commodites : CME Group, ICE. Crypto : CoinDesk. Geopolitique : Reuters, AP.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
  pdfUrl: "",
};
