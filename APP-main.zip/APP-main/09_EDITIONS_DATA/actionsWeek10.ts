/**
 * WMB Module Actions US — Semaine 10 (LUN 02/03 → VEN 06/03 2026)
 * Frappes Iran, Dell +22%, NVIDIA Négatif YTD & Broadcom en Test
 */
import type { ActionsModuleData } from "../actions";

export const ACTIONS_SEMAINE_10: ActionsModuleData = {
  id: 2,
  weekNumber: 10,
  year: 2026,
  dateRange: "LUN 02/03 → VEN 06/03",
  title: "Frappes Iran, Dell +22% & Broadcom en Test — Rotation Défensive Accélérée",
  subtitle: "MODULE ACTIONS US",
  publishedAt: "2026-03-01T08:00:00Z",

  executiveSummary: {
    weekPast: [
      "Dell Technologies (DELL) +21,93% — star de la semaine, guidance AI servers exceptionnelle.",
      "NVIDIA (NVDA) négatif YTD — doutes IA persistants, correction post-earnings prolongée.",
      "Goldman Sachs (GS) -7% — pire performer du Dow, contagion crédit UK.",
      "Paramount Skydance (PSKY) +20,93% — acquisition Warner Bros Discovery ~$110 Mds.",
      "Netflix (NFLX) +14,03% — sorti de la course Warner Bros, recentrage contenu.",
      "Frappes US-Israel sur l'Iran (28 fév) — pétrole +5%, défense en hausse.",
    ],
    weekAhead: [
      "Broadcom (AVGO) mercredi — test décisif pour le narratif IA post-NVIDIA.",
      "CrowdStrike (CRWD) mardi — baromètre cybersécurité post-Anthropic Claude.",
      "Target (TGT) mardi — 1er rapport sous le nouveau CEO Michael Fiddelke.",
      "Costco (COST) jeudi — proxy pour la résilience du consommateur US.",
      "Marvell Technology (MRVL) jeudi — custom silicon IA pour hyperscalers.",
      "Berkshire Hathaway (BRK) samedi — 1er rapport sous Greg Abel (post-Buffett).",
    ],
    lectureWMB: "La semaine passée a confirmé la rotation hors tech vers les défensives et l'énergie. Dell est la preuve que l'IA crée de la valeur réelle (servers, infrastructure), tandis que NVIDIA montre que les valorisations excessives sont corrigées. Les frappes Iran changent la donne : les stocks de défense et d'énergie devraient surperformer cette semaine. Broadcom mercredi est le titre le plus important — il déterminera si le narratif IA est mort ou simplement en pause.",
  },

  signalVsBruit: {
    signal: [
      "Dell +22% sur guidance AI servers → la demande d'infrastructure IA est réelle et accélère.",
      "Goldman Sachs -7% → contagion crédit UK (Market Financial Solutions collapse), risque systémique à surveiller.",
      "Rotation Consumer Staples +2,69%, Utilities +2,67% → flight-to-safety classique, changement de régime possible.",
      "Software ETF IGV -23% YTD → le secteur le plus à risque, compression des multiples en cours.",
      "Frappes Iran → pétrole +5%, stocks défense en hausse, airlines sous pression.",
    ],
    bruit: [
      "Block (XYZ) +17% après annonce de -40% effectifs → restructuration ≠ croissance, prudence.",
      "Ambarella (AMBA) -15% malgré earnings positifs → réaction technique, pas fondamentale.",
      "Zscaler (ZS) -12% sur billings concerns → marché punit la moindre faiblesse dans le software.",
    ],
    lectureWMB: "Le signal dominant est la rotation défensive accélérée par les frappes Iran. Dell confirme que l'IA crée de la valeur dans l'infrastructure (pas seulement les puces). Goldman Sachs -7% est un signal d'alerte sur le crédit privé. Le bruit vient des réactions excessives aux earnings (Ambarella, Zscaler) et des restructurations (Block). Concentrez-vous sur les tendances de fond : énergie, défense, infrastructure IA.",
  },

  topGainersLarge: [
    { rank: 1, ticker: "DELL", company: "Dell Technologies", perf: "+21,93%", catalyst: "Guidance AI servers exceptionnelle, revenus $148.08, infrastructure IA en forte demande" },
    { rank: 2, ticker: "PSKY", company: "Paramount Skydance", perf: "+20,93%", catalyst: "Acquisition Warner Bros Discovery ~$110 Mds, consolidation média" },
    { rank: 3, ticker: "XYZ", company: "Block (ex-Square)", perf: "+16,96%", catalyst: "Restructuration massive (-40% effectifs), marché salue la discipline" },
    { rank: 4, ticker: "NFLX", company: "Netflix", perf: "+14,03%", catalyst: "Sorti de la course Warner Bros, recentrage sur le contenu original" },
    { rank: 5, ticker: "INTU", company: "Intuit", perf: "+3,70%", catalyst: "Résultats solides, TurboTax en saison fiscale" },
  ],
  topGainersLargeLecture: "Dell est la star incontestée de la semaine. La guidance AI servers a prouvé que la demande d'infrastructure IA est réelle et en accélération. Paramount Skydance bénéficie de la méga-acquisition Warner Bros Discovery. Netflix profite de sa sortie de la course Warner pour se recentrer sur son cœur de métier. Block monte sur la restructuration, mais attention : couper 40% des effectifs n'est pas un signe de force.",

  topLosersLarge: [
    { rank: 1, ticker: "AMBA", company: "Ambarella", perf: "-15,12%", catalyst: "Plongeon malgré earnings positifs, marché punit les valorisations élevées" },
    { rank: 2, ticker: "ZS", company: "Zscaler", perf: "-12,27%", catalyst: "Billings concerns malgré beat, compression multiples software" },
    { rank: 3, ticker: "GS", company: "Goldman Sachs", perf: "-7,00%", catalyst: "Pire performer du Dow, contagion crédit UK (Market Financial Solutions)" },
    { rank: 4, ticker: "NVDA", company: "NVIDIA", perf: "-4,17%", catalyst: "Négatif YTD, doutes IA persistants, post-earnings prolongé" },
    { rank: 5, ticker: "AAPL", company: "Apple", perf: "-3,21%", catalyst: "Tarifs Chine, sentiment tech négatif, rotation hors Mag 7" },
  ],
  topLosersLargeLecture: "Ambarella illustre parfaitement le marché actuel : même des earnings positifs ne suffisent plus si la guidance n'est pas exceptionnelle. Zscaler montre que le software est le secteur le plus à risque (IGV -23% YTD). Goldman Sachs -7% est un signal d'alerte sur le crédit. NVIDIA continue sa glissade post-earnings. Apple souffre des tarifs Chine et du sentiment tech négatif.",

  topGainersMidSmall: [
    { rank: 1, ticker: "FSLY", company: "Fastly", perf: "+42,00%", catalyst: "Meilleur performer S&P 500 en février, edge computing en demande" },
    { rank: 2, ticker: "SMCI", company: "Super Micro Computer", perf: "+8,50%", catalyst: "Rebond technique, infrastructure IA, serveurs Dell effect" },
    { rank: 3, ticker: "SOFI", company: "SoFi Technologies", perf: "+5,20%", catalyst: "Fintech en croissance, volumes de trading élevés" },
    { rank: 4, ticker: "PLTR", company: "Palantir", perf: "+3,80%", catalyst: "Contrats défense, bénéficiaire des frappes Iran" },
    { rank: 5, ticker: "RKLB", company: "Rocket Lab", perf: "+4,50%", catalyst: "Contrats espace/défense, sentiment positif" },
  ],
  topGainersMidSmallLecture: "Fastly est le meilleur performer du S&P 500 en février (+42%), porté par la demande d'edge computing. Super Micro rebondit dans le sillage de Dell (infrastructure IA). Palantir et Rocket Lab bénéficient du contexte géopolitique (contrats défense). SoFi profite des volumes de trading élevés en période de volatilité.",

  topLosersMidSmall: [
    { rank: 1, ticker: "EPAM", company: "EPAM Systems", perf: "-35,00%", catalyst: "Pire performer S&P 500 en février, exposition Europe de l'Est" },
    { rank: 2, ticker: "SNAP", company: "Snap Inc.", perf: "-8,50%", catalyst: "Publicité en ralentissement, concurrence TikTok" },
    { rank: 3, ticker: "HOOD", company: "Robinhood", perf: "-6,20%", catalyst: "Fintech sous pression, crypto en baisse" },
    { rank: 4, ticker: "AFRM", company: "Affirm", perf: "-5,80%", catalyst: "BNPL sous pression, crédit consommateur en tension" },
    { rank: 5, ticker: "RIVN", company: "Rivian", perf: "-4,50%", catalyst: "EV sous pression, pétrole en hausse favorise ICE" },
  ],
  topLosersMidSmallLecture: "EPAM Systems est le pire performer du S&P 500 en février (-35%), pénalisé par son exposition à l'Europe de l'Est et les tensions géopolitiques. Snap et Robinhood souffrent de la rotation hors tech/growth. Affirm est sous pression avec les tensions sur le crédit consommateur. Rivian pâtit de la hausse du pétrole (paradoxalement négatif pour les EV à court terme car réduit l'urgence de la transition).",

  sectors: [
    { sector: "Énergie (XLE)", perf: "+3,5%", note: "Grand gagnant — pétrole +5% post-Iran, Exxon, Chevron en hausse", positive: true },
    { sector: "Consumer Staples (XLP)", perf: "+2,69%", note: "Flight-to-safety classique — Costco, Procter & Gamble, Coca-Cola", positive: true },
    { sector: "Utilities (XLU)", perf: "+2,67%", note: "Défensif par excellence — rendements attractifs vs risque", positive: true },
    { sector: "Défense", perf: "+2,0%", note: "Lockheed Martin, Raytheon, Northrop Grumman — bénéficiaires directs Iran", positive: true },
    { sector: "Healthcare (XLV)", perf: "+1,2%", note: "Amgen, UnitedHealth — rotation défensive", positive: true },
    { sector: "Industriels (XLI)", perf: "-0,3%", note: "Mixte — Caterpillar résilient, transports sous pression", positive: false },
    { sector: "Tech (XLK)", perf: "-1,8%", note: "Sous pression — NVIDIA, Apple, AMD en baisse", positive: false },
    { sector: "Software (IGV)", perf: "-4,2%", note: "Pire secteur — -23% YTD, compression multiples massive", positive: false },
    { sector: "Financiers (XLF)", perf: "-2,24%", note: "Goldman -7%, contagion crédit UK, banques régionales sous pression", positive: false },
  ],
  sectorsLecture: "La rotation sectorielle est le signal le plus clair du marché. L'énergie et la défense sont les grands gagnants post-Iran. Les Consumer Staples et Utilities confirment le mode flight-to-safety. La tech et le software sont les perdants — le software (IGV -23% YTD) est en territoire de bear market. Les financières souffrent de la contagion crédit UK. Cette rotation pourrait être structurelle si le conflit Iran s'intensifie.",

  techSemis: {
    overview: "Les semi-conducteurs sont au cœur de la tempête. NVIDIA négatif YTD, mais Dell +22% prouve que l'infrastructure IA crée de la valeur. Broadcom mercredi est le test décisif.",
    highlights: [
      { title: "NVIDIA (NVDA) — Négatif YTD", description: "Le titre phare de l'IA passe en territoire négatif sur l'année. La correction post-earnings se prolonge. Le marché doute des valorisations IA et du capex des hyperscalers." },
      { title: "Dell (DELL) +22% — Star de la Semaine", description: "Guidance AI servers exceptionnelle. Prouve que la demande d'infrastructure IA est réelle au-delà des puces. Revenue $148.08 en clôture." },
      { title: "Broadcom (AVGO) — Test Mercredi", description: "Consensus ~19,2 Mds$ de revenus. Le marché cherche une confirmation que la demande IA est réelle. VMware synergies en focus." },
      { title: "Marvell (MRVL) — Custom Silicon Jeudi", description: "Indicateur clé de la demande de custom silicon pour hyperscalers (Amazon, Google). Carnet de commandes IA en focus." },
    ],
    lectureWMB: "Le narratif semi-conducteurs est en pleine mutation. NVIDIA n'est plus le seul proxy pour l'IA — Dell et Broadcom prennent le relais sur l'infrastructure. Le marché récompense les entreprises qui génèrent des revenus réels (Dell) et punit celles dont les valorisations sont trop élevées (NVIDIA). Broadcom mercredi sera le verdict : si les résultats confirment la demande, le secteur pourrait rebondir. Sinon, la correction s'accélérera.",
  },

  softwareCloud: {
    overview: "Le software est en crise. L'ETF IGV perd 23% YTD — c'est un bear market sectoriel. Zscaler -12% malgré un beat illustre la sévérité du marché.",
    highlights: [
      { title: "Zscaler (ZS) -12% — Billings Concerns", description: "Malgré un beat sur les résultats, le titre plonge sur des inquiétudes de billings. Le marché ne tolère aucune faiblesse dans le software." },
      { title: "CrowdStrike (CRWD) — Test Mardi", description: "Baromètre cybersécurité. ARR et adoption de la plateforme Falcon en focus. Impact de l'IA (Anthropic Claude) sur la demande de cybersécurité." },
      { title: "Okta (OKTA) — Identity Management Mercredi", description: "Croissance identity management, adoption cloud. Concurrence Microsoft Entra en focus." },
    ],
    lectureWMB: "Le software est le secteur le plus dangereux du marché actuellement. Les multiples se compriment brutalement — même les bons résultats ne suffisent plus (Zscaler). CrowdStrike mardi sera le test : si la cybersécurité résiste, c'est un signal positif pour le secteur. Sinon, la purge continuera.",
  },

  healthcare: {
    overview: "Le healthcare bénéficie de la rotation défensive. Amgen, UnitedHealth et les biotech de taille moyenne attirent les flux.",
    highlights: [
      { title: "Amgen (AMGN) +2,33%", description: "Défensif healthcare, pipeline solide, rendement dividende attractif en période de risk-off." },
      { title: "Ascendis Pharma (ASND)", description: "Growth stock healthcare à surveiller — croissance forte, pipeline prometteur." },
    ],
    lectureWMB: "Le healthcare est un refuge naturel en période de crise géopolitique. Les grandes pharma (Amgen, J&J, Pfizer) offrent des rendements de dividendes attractifs et une visibilité sur les revenus. Les biotech de taille moyenne (Ascendis) offrent un potentiel de croissance avec moins de corrélation aux événements macro.",
  },

  financials: {
    overview: "Les financières sont sous pression après le collapse de Market Financial Solutions au UK. Goldman Sachs -7%, banques régionales en baisse.",
    highlights: [
      { title: "Goldman Sachs (GS) -7%", description: "Pire performer du Dow. Contagion crédit UK, exposition au crédit privé. Le marché craint un effet domino." },
      { title: "JPMorgan (JPM)", description: "Relativement résilient grâce à sa diversification. Reste le 'best in class' des banques US." },
      { title: "Block (XYZ) +17%", description: "Restructuration massive (-40% effectifs). Le marché salue la discipline mais attention : couper n'est pas croître." },
    ],
    lectureWMB: "Le collapse de Market Financial Solutions au UK a créé un choc dans le secteur financier. Goldman Sachs est le plus exposé au crédit privé parmi les grandes banques. Le risque de contagion est réel mais pas systémique pour l'instant. JPMorgan reste le choix le plus sûr dans le secteur. Block monte sur la restructuration mais c'est un pari risqué.",
  },

  cyclicals: {
    overview: "Les cycliques sont mixtes. Caterpillar résiste grâce aux infrastructures, mais les transports souffrent du pétrole en hausse.",
    highlights: [
      { title: "Caterpillar (CAT)", description: "Fireside chat CONEXPO jeudi. Infrastructure spending résilient, carnet de commandes solide." },
      { title: "Norwegian Cruise Line (NCLH)", description: "Earnings lundi. Sous pression avec le pétrole en hausse (coûts de carburant)." },
    ],
    lectureWMB: "Les cycliques sont pris en étau entre une économie encore résiliente (ISM Manufacturing > 50) et un pétrole en hausse qui pèse sur les marges. Caterpillar est le meilleur proxy pour l'infrastructure US. Les compagnies aériennes et de croisière sont les plus vulnérables au spike pétrolier.",
  },

  consumption: {
    overview: "La consommation est le champ de bataille de la semaine. Target et Best Buy mardi, Costco jeudi — le pouls du consommateur US.",
    highlights: [
      { title: "Target (TGT) — 1er Rapport Nouveau CEO", description: "Michael Fiddelke prend les rênes. Le marché attend une vision claire pour le turnaround. Guidance 2026 en focus." },
      { title: "Best Buy (BBY) — Électronique & IA", description: "Demande d'électronique grand public, impact de l'IA sur les ventes (PC, accessoires). Tarifs sur les importations tech en risque." },
      { title: "Costco (COST) — Membership Momentum", description: "Proxy pour la résilience du consommateur. Membership growth et comparable sales en focus. Valorisation élevée (~50x PE)." },
    ],
    lectureWMB: "La consommation US est résiliente mais montre des signes de fatigue. Target sous un nouveau CEO est un pari sur le turnaround. Best Buy est sensible aux tarifs sur les importations tech. Costco reste le gold standard de la consommation défensive — si Costco déçoit, c'est un signal très négatif pour l'ensemble du secteur.",
  },

  earningsWinners: [
    { rank: 1, ticker: "DELL", company: "Dell Technologies", detail: "+21,93% — Guidance AI servers exceptionnelle, revenus en forte hausse, infrastructure IA en accélération" },
    { rank: 2, ticker: "PSKY", company: "Paramount Skydance", detail: "+20,93% — Acquisition Warner Bros Discovery ~$110 Mds, consolidation média" },
    { rank: 3, ticker: "XYZ", company: "Block (ex-Square)", detail: "+16,96% — Restructuration -40% effectifs, marché salue la discipline de coûts" },
    { rank: 4, ticker: "NFLX", company: "Netflix", detail: "+14,03% — Sorti de la course Warner Bros, recentrage contenu original" },
    { rank: 5, ticker: "INTU", company: "Intuit", detail: "+3,70% — Résultats solides, saison TurboTax en cours" },
  ],
  earningsWinnersLecture: "Dell est le grand gagnant de la semaine earnings. La guidance AI servers a prouvé que la demande d'infrastructure IA est réelle et en accélération — ce n'est pas seulement NVIDIA. Paramount Skydance bénéficie de la méga-acquisition Warner Bros. Netflix profite de sa sortie de la course pour se recentrer. Block monte sur la restructuration mais c'est un signal mixte.",

  earningsLosers: [
    { rank: 1, ticker: "AMBA", company: "Ambarella", detail: "-15,12% — Plongeon malgré earnings positifs, marché punit les valorisations élevées" },
    { rank: 2, ticker: "ZS", company: "Zscaler", detail: "-12,27% — Billings concerns malgré beat, compression multiples software" },
    { rank: 3, ticker: "GS", company: "Goldman Sachs", detail: "-7,00% — Contagion crédit UK, pire performer du Dow" },
    { rank: 4, ticker: "NVDA", company: "NVIDIA", detail: "-4,17% vendredi — Négatif YTD, doutes IA persistants" },
    { rank: 5, ticker: "AAPL", company: "Apple", detail: "-3,21% — Tarifs Chine, sentiment tech négatif" },
  ],
  earningsLosersLecture: "Ambarella illustre le marché actuel : même des earnings positifs ne protègent plus si la guidance n'est pas exceptionnelle. Zscaler montre la brutalité du software (-23% YTD pour l'ETF IGV). Goldman Sachs est un signal d'alerte sur le crédit privé. NVIDIA continue sa glissade — le titre phare de l'IA est désormais négatif sur l'année.",

  guidanceThemes: [
    { title: "Infrastructure IA > Puces IA", description: "Dell +22% vs NVIDIA -4% : le marché récompense les revenus réels d'infrastructure IA (serveurs, stockage) plutôt que les promesses de puces." },
    { title: "Discipline de Coûts Récompensée", description: "Block +17% après -40% effectifs : le marché préfère la rentabilité à la croissance dans l'environnement actuel." },
    { title: "Software en Purge", description: "Zscaler -12% malgré un beat : les multiples du software se compriment brutalement. Seuls les résultats exceptionnels sont récompensés." },
    { title: "Tarifs — Impact Croissant", description: "Les tarifs de 10% sont entrés en vigueur. Les entreprises importatrices (Apple, Best Buy) commencent à signaler l'impact sur les marges." },
  ],
  guidanceLecture: "Le message du marché est clair : montrez-moi les revenus, pas les promesses. Dell est récompensé pour des revenus IA réels, NVIDIA est puni pour des valorisations trop élevées. Block est récompensé pour la discipline de coûts. Le software est en purge — seuls les résultats exceptionnels survivent. Les tarifs deviennent un thème de plus en plus important dans les guidances.",

  analystMoves: [
    { title: "Broadcom (AVGO) — Consensus relevé", description: "Plusieurs analystes relèvent leurs objectifs avant les résultats de mercredi. Consensus revenus ~19,2 Mds$." },
    { title: "NVIDIA (NVDA) — Objectifs abaissés", description: "Plusieurs analystes réduisent leurs objectifs de cours après la correction post-earnings. Le consensus reste positif mais les convictions baissent." },
    { title: "Dell (DELL) — Upgrades massifs", description: "Vague d'upgrades après les résultats. Plusieurs analystes passent à 'Buy' avec des objectifs relevés à $160-180." },
    { title: "Goldman Sachs (GS) — Downgrades", description: "Plusieurs analystes abaissent leurs recommandations sur l'exposition au crédit privé." },
  ],
  analystLecture: "Les analystes suivent le marché : upgrades massifs sur Dell (infrastructure IA), downgrades sur NVIDIA et Goldman Sachs. Broadcom est le consensus trade de la semaine — attention au risque de déception si les résultats ne sont pas exceptionnels.",

  corporateActions: [
    { title: "Paramount Skydance acquiert Warner Bros Discovery (~$110 Mds)", description: "Méga-acquisition dans les médias. Consolidation du secteur, implications pour Netflix, Disney, Amazon Prime." },
    { title: "Block restructure — -40% effectifs", description: "Restructuration massive chez Block (ex-Square). Le marché salue la discipline mais c'est un signal de stress dans la fintech." },
    { title: "Berkshire Hathaway — Transition Greg Abel", description: "Premier rapport sous le nouveau CEO. $300 Mds de cash — les décisions d'allocation de capital seront scrutées." },
  ],
  corporateLecture: "L'acquisition de Warner Bros Discovery par Paramount Skydance est la plus grosse opération M&A de l'année. La restructuration de Block signale que la fintech entre dans une phase de consolidation. La transition Berkshire vers Greg Abel est un moment historique — les $300 Mds de cash sont un signal sur le timing d'investissement.",

  regulation: [
    { title: "Tarifs Trump — 10% en vigueur, 15% menacés", description: "Les tarifs globaux de 10% sont entrés en vigueur le 25 février. Trump menace de les porter à 15%. Impact direct sur les marges des importateurs (Apple, Best Buy, retailers)." },
    { title: "Deadline nucléaire Iran — 1-6 mars", description: "Trump a donné un deadline du 1-6 mars pour un accord nucléaire avec l'Iran. Si pas d'accord, menace de frappes supplémentaires. Le timing coïncide exactement avec la semaine de trading." },
  ],
  regulationLecture: "Les tarifs et le conflit Iran sont les deux risques réglementaires/politiques majeurs. Les tarifs de 10% commencent à impacter les marges — les entreprises les plus exposées (Apple, retailers) signalent déjà l'impact. Le deadline nucléaire Iran du 1-6 mars crée une incertitude maximale pour toute la semaine.",

  emergingThemes: [
    { number: 1, title: "Infrastructure IA — Le Nouveau Roi", facts: "Dell +22%, Broadcom en test, Marvell en focus. La demande de serveurs IA, de stockage et de custom silicon dépasse les attentes.", hypothesis: "L'infrastructure IA (serveurs, stockage, réseau) pourrait surperformer les puces IA (NVIDIA) en 2026.", counterSignal: "Si Broadcom déçoit mercredi, le narratif infrastructure IA serait remis en question." },
    { number: 2, title: "Crédit Privé — Le Risque Caché", facts: "Market Financial Solutions collapse (UK), Goldman Sachs -7%, Apollo et Jefferies sous pression.", hypothesis: "Le crédit privé pourrait être le prochain domino à tomber — les spreads HY à 330 bps sont encore loin du stress mais la tendance est à la hausse.", counterSignal: "Si les spreads HY restent sous 400 bps, le risque systémique est limité." },
    { number: 3, title: "Défense & Énergie — Les Nouveaux Leaders", facts: "Frappes Iran, pétrole +5%, stocks défense en hausse. Lockheed Martin, Raytheon, Northrop Grumman, Exxon, Chevron.", hypothesis: "La rotation vers l'énergie et la défense pourrait être structurelle si le conflit Iran s'intensifie.", counterSignal: "Une désescalade rapide (accord nucléaire) inverserait la rotation." },
  ],
  emergingThemesLecture: "Trois thèmes émergents dominent : (1) l'infrastructure IA prend le relais de NVIDIA comme moteur du secteur, (2) le crédit privé montre des fissures qui pourraient s'élargir, (3) la défense et l'énergie deviennent les nouveaux leaders sectoriels. Ces thèmes pourraient définir le reste du premier semestre 2026.",

  radarStocks: [
    { rank: 1, ticker: "LMT", company: "Lockheed Martin", activity: "Hausse post-frappes Iran, contrats défense en accélération", catalyst: "Escalade Iran → hausse des budgets défense", risks: "Désescalade rapide inverserait le mouvement" },
    { rank: 2, ticker: "RTX", company: "Raytheon Technologies", activity: "Systèmes de défense antimissile en demande", catalyst: "Frappes Iran, Iron Dome, systèmes de défense", risks: "Même risque de désescalade" },
    { rank: 3, ticker: "XOM", company: "Exxon Mobil", activity: "Pétrole en spike, production record", catalyst: "WTI > $80, marge de raffinage en hausse", risks: "OPEC+ hausse production, désescalade Iran" },
    { rank: 4, ticker: "PANW", company: "Palo Alto Networks", activity: "Cybersécurité en demande post-Iran (cyberattaques)", catalyst: "Risque de cyberattaques iraniennes sur les infrastructures US", risks: "Compression multiples software" },
    { rank: 5, ticker: "GD", company: "General Dynamics", activity: "Contrats défense, sous-marins, véhicules blindés", catalyst: "Budget défense en hausse, tensions géopolitiques", risks: "Même risque de désescalade" },
  ],
  radarLecture: "Le radar cette semaine est dominé par la défense et l'énergie — les bénéficiaires directs des frappes Iran. Lockheed Martin et Raytheon sont les plays les plus directs sur l'escalade. Exxon profite du spike pétrolier. Palo Alto Networks est un play intéressant sur le risque de cyberattaques iraniennes. Ces titres sont des couvertures naturelles contre le risque géopolitique.",

  influentialVoices: [
    { name: "Greg Abel", role: "Nouveau CEO Berkshire Hathaway", idea: "Premier rapport sous sa direction. $300 Mds de cash — les décisions d'allocation de capital donneront le ton.", whyFollowed: "Successeur de Warren Buffett, ses premières décisions seront scrutées par tout le marché." },
    { name: "Jamie Dimon", role: "CEO JPMorgan Chase", idea: "Commentaires sur le crédit privé et l'impact des frappes Iran sur les marchés financiers.", whyFollowed: "Le banquier le plus influent de Wall Street, ses avertissements sont toujours pris au sérieux." },
    { name: "Jensen Huang", role: "CEO NVIDIA", idea: "Silence post-earnings mais le marché attend des clarifications sur la demande IA.", whyFollowed: "NVIDIA négatif YTD — tout commentaire de Huang serait market-moving." },
  ],
  voicesLecture: "Greg Abel est la voix la plus attendue de la semaine. Son premier rapport Berkshire donnera le ton pour la gestion post-Buffett. Jamie Dimon pourrait commenter sur le crédit privé et l'Iran. Jensen Huang reste silencieux mais tout commentaire sur la demande IA serait un catalyseur.",

  watchlist: [
    { ticker: "AVGO", angle: "Earnings mercredi — test décisif IA", watchFor: "Revenus > 19,5 Mds$ = bullish IA. Guidance VMware. Custom silicon." },
    { ticker: "CRWD", angle: "Earnings mardi — baromètre cybersécurité", watchFor: "ARR > attentes = signal positif software. Adoption Falcon." },
    { ticker: "LMT", angle: "Défense post-Iran", watchFor: "Contrats défense, commentaires sur le budget militaire." },
    { ticker: "XOM", angle: "Énergie post-Iran", watchFor: "Production, marge de raffinage, commentaires sur le pétrole." },
    { ticker: "TGT", angle: "Nouveau CEO — turnaround", watchFor: "Guidance 2026, comparable sales, stratégie Fiddelke." },
    { ticker: "COST", angle: "Consommation défensive", watchFor: "Membership growth, comparable sales, pricing power." },
  ],
  watchlistLecture: "La watchlist est structurée autour de trois axes : (1) IA (Broadcom, CrowdStrike) pour tester le narratif tech, (2) Défense/Énergie (Lockheed, Exxon) pour jouer le risque Iran, (3) Consommation (Target, Costco) pour le pouls du consommateur. Broadcom mercredi est le titre le plus important de la semaine.",

  calendar: [
    { day: "Lundi", date: "02/03", events: ["ISM Manufacturing PMI (10:00 ET)", "Réaction marchés frappes Iran", "Norwegian Cruise Line (NCLH) earnings"] },
    { day: "Mardi", date: "03/03", events: ["Target (TGT) — avant ouverture", "Best Buy (BBY) — avant ouverture", "CrowdStrike (CRWD) — après clôture", "Apple Event annoncé"] },
    { day: "Mercredi", date: "04/03", events: ["ADP Employment Change", "Broadcom (AVGO) — après clôture [!]", "Okta (OKTA) — après clôture"] },
    { day: "Jeudi", date: "05/03", events: ["ISM Services PMI", "Jobless Claims", "Costco (COST)", "Marvell Technology (MRVL)"] },
    { day: "Vendredi", date: "06/03", events: ["NFP (Nonfarm Payrolls) [!]", "Unemployment Rate", "Deadline nucléaire Iran"] },
  ],
  calendarLecture: "Le calendrier est chargé et à haut risque. Lundi : réaction Iran + ISM Manufacturing. Mardi : Target/Best Buy + CrowdStrike. Mercredi : Broadcom (événement principal). Jeudi : ISM Services + Costco + Marvell. Vendredi : NFP (événement macro principal) + deadline Iran. Chaque jour peut être un catalyseur majeur.",

  earningsToWatch: [
    { day: "Samedi", date: "01/03", timing: "", ticker: "BRK.B", company: "Berkshire Hathaway", watchFor: "1er rapport Greg Abel, $300 Mds cash, allocations", highlight: true },
    { day: "Lundi", date: "02/03", timing: "", ticker: "NCLH", company: "Norwegian Cruise Line", watchFor: "Demande croisières, impact pétrole sur coûts" },
    { day: "Mardi", date: "03/03", timing: "BMO", ticker: "TGT", company: "Target", watchFor: "Nouveau CEO Fiddelke, guidance 2026" },
    { day: "Mardi", date: "03/03", timing: "BMO", ticker: "BBY", company: "Best Buy", watchFor: "Électronique, impact tarifs tech" },
    { day: "Mardi", date: "03/03", timing: "AMC", ticker: "CRWD", company: "CrowdStrike", watchFor: "ARR, Falcon, cybersécurité IA", highlight: true },
    { day: "Mercredi", date: "04/03", timing: "AMC", ticker: "AVGO", company: "Broadcom", watchFor: "AI semiconductor, VMware, guidance", highlight: true },
    { day: "Mercredi", date: "04/03", timing: "AMC", ticker: "OKTA", company: "Okta", watchFor: "Identity management, concurrence Microsoft" },
    { day: "Jeudi", date: "05/03", timing: "", ticker: "COST", company: "Costco", watchFor: "Membership, comparable sales" },
    { day: "Jeudi", date: "05/03", timing: "", ticker: "MRVL", company: "Marvell Technology", watchFor: "Custom silicon IA, hyperscalers", highlight: true },
  ],
  earningsToWatchLecture: "Broadcom mercredi est l'événement principal — le verdict sur le narratif IA. CrowdStrike mardi teste le software/cybersécurité. Berkshire samedi est historique (1er rapport post-Buffett). Target et Costco donnent le pouls de la consommation. Marvell jeudi est le test du custom silicon IA.",

  scenarios: [
    { name: "Bull — Désescalade + Broadcom Exceptionnel", probability: "~15%", triggers: "Accord nucléaire Iran, Broadcom bat largement, NFP goldilocks 150-180K", signals: "VIX < 18, pétrole < $70, Nasdaq +4-6%", invalidation: "Escalade Iran ou Broadcom déçoit" },
    { name: "Base — Volatilité Sans Direction", probability: "~50%", triggers: "Iran contenu, Broadcom en ligne, NFP proche consensus", signals: "VIX 20-25, pétrole $75-85, S&P -1% à +1%", invalidation: "Événement extrême dans un sens ou l'autre" },
    { name: "Bear — Escalade + Déception IA", probability: "~35%", triggers: "Ormuz menacé, Broadcom déçoit, NFP extrême (>250K ou <100K)", signals: "VIX > 28, pétrole > $85, S&P -3-7%", invalidation: "Désescalade rapide Iran" },
  ],
  risks: [
    { title: "Risque 1 — Escalade Iran / Détroit d'Ormuz", description: "Si le conflit s'intensifie et que le Détroit d'Ormuz est menacé, pétrole > $90-100. Impact direct sur l'inflation, les marges et le sentiment." },
    { title: "Risque 2 — Broadcom Déçoit → Fin du Narratif IA", description: "Si Broadcom ne confirme pas la demande IA, le Nasdaq pourrait corriger de 5-8% supplémentaires. Le software serait le plus touché." },
    { title: "Risque 3 — Contagion Crédit Privé", description: "Si d'autres prêteurs privés révèlent des problèmes après Market Financial Solutions, les financières et les spreads HY pourraient s'élargir rapidement." },
  ],
  scenarioDisclaimer: "Les scénarios présentés sont des hypothèses éducatives basées sur des données publiques. Ils ne constituent pas des prévisions certaines ni des recommandations d'investissement.",

  conclusion: "La Semaine 10 s'annonce comme l'une des plus volatiles de 2026. Les frappes US-Israel sur l'Iran, combinées aux earnings de Broadcom et au NFP, créent un cocktail explosif. La rotation défensive (énergie, Consumer Staples, défense) est le signal le plus clair du marché. L'infrastructure IA (Dell) prend le relais de NVIDIA comme moteur du secteur. Le crédit privé montre des fissures. Prudence maximale — mais les corrections créent des opportunités pour les investisseurs patients et disciplinés.",
  conclusionLecture: "Trois actions à surveiller en priorité cette semaine : (1) Broadcom mercredi — le verdict IA, (2) Lockheed Martin — le proxy défense/Iran, (3) Costco — le proxy consommation. Le pétrole est la variable clé : au-dessus de $85, le scénario bear domine. En dessous de $75, le bull reprend. Le NFP de vendredi sera le deuxième catalyseur majeur. Restez disciplinés, gérez votre risque, et rappelez-vous : les meilleures opportunités naissent dans la volatilité.",

  sources: "Données de marché basées sur la clôture US du 28 février 2026 (CNBC, Nasdaq.com, Reuters, Yahoo Finance, Motley Fool). Données Iran : Reuters, AP, Forbes, Investors.com, Seeking Alpha. Données earnings : Yahoo Finance Earnings Calendar, company filings. Données sectorielles : S&P Global, ETF providers (XLE, XLK, XLF, IGV). Données crédit : Bloomberg, ICE BofA indices.",
  disclaimer: "Ce document est produit à des fins strictement informatives et éducatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente d'actifs financiers, un conseil en investissement, ou une promesse de performance. Les marchés financiers sont par nature imprévisibles. Les frappes sur l'Iran créent une incertitude exceptionnelle — toute décision d'investissement doit être prise avec une prudence accrue. Investir comporte des risques de perte en capital.",
};
