/**
 * WMB Module Actions US — Semaine 11 (LUN 10/03 → VEN 14/03 2026)
 * Énergie Domine, Tech en Correction, Oracle & Adobe en Test — Rotation Défensive Confirmée
 */
import type { ActionsModuleData } from "../actions";

export const ACTIONS_SEMAINE_11: ActionsModuleData = {
  id: 22,
  weekNumber: 11,
  year: 2026,
  dateRange: "LUN 03/03 → VEN 07/03",
  title: "Énergie +8%, Tech -3%, Croisières -20% : Rotation Défensive Totale",
  subtitle: "ACTIONS US",
  publishedAt: "2026-03-08T08:00:00Z",
  headerImage: "https://d2xsxph8kpxj0f.cloudfront.net/310519663135061541/Wf8Nj4yLBCzwrPQSdtP8cC/nyse-trader_0d5d620e.jpg",

  executiveSummary: {
    weekPast: [
      "Énergie +4,82% — le seul secteur en hausse sur la semaine, porté par Chevron (+8,5%), Exxon (+7,2%) et ConocoPhillips (+6,8%) dans le sillage du pétrole au-dessus de $90.",
      "Tech -2,35% — la correction se prolonge pour une troisième semaine consécutive. NVIDIA à -10,2% YTD, Apple passe en négatif YTD pour la première fois de l'année.",
      "Consumer Discretionary -3,45% — pire secteur de la semaine. Les airlines (Delta -7,2%), les croisières (Carnival -8,5%) et les homebuilders sont massacrés par le pétrole cher.",
      "Financières -2,87% — JPMorgan, Goldman et les régionales sous pression sur les craintes de crédit. L'épisode BlackRock (limites de retraits) a secoué le secteur.",
      "Russell 2000 -4,07% — les small caps en chute libre, signal d'alarme sur l'économie domestique. C'est le segment le plus sensible au ralentissement.",
      "META est le seul Magnificent 7 encore positif YTD (+5,2%) — un changement de régime historique pour le groupe qui portait le marché depuis 2023.",
    ],
    weekAhead: [
      "Oracle (ORCL) lundi après clôture — le titre le plus important de la semaine. Le marché veut savoir si l'IA se traduit en revenus cloud réels via OCI.",
      "Adobe (ADBE) jeudi après clôture — test de la monétisation de l'IA créative avec Firefly. ARR Creative Cloud et guidance seront scrutés.",
      "Dollar General (DG) jeudi avant ouverture — le baromètre du consommateur bas de gamme, le segment le plus vulnérable à l'inflation.",
      "Ulta Beauty (ULTA) jeudi après clôture — test de la résilience des dépenses beauté dans un contexte de ralentissement.",
      "CPI mercredi — impact sectoriel majeur : un chiffre chaud renforce l'énergie et les défensives, un chiffre froid relance la tech et la consommation.",
      "Période de blackout Fed — aucun discours, le marché est seul face aux données.",
    ],
    lectureWMB: "La rotation défensive s'accélère à un rythme qu'on n'avait pas vu depuis 2022. L'énergie est le seul secteur en hausse (+4,82%) tandis que tout le reste recule — c'est la signature d'un marché en mode stagflation. La tech perd 2,35% et la correction se prolonge : NVIDIA à -10,2% YTD, Amazon à -15,1% YTD, Tesla à -12,4% YTD. Le consumer discretionary est massacré (-3,45%) car le pétrole cher frappe directement les airlines, les croisières et les homebuilders. Le Russell 2000 (-4,07%) confirme que les small caps souffrent le plus — elles sont les premières à signaler un ralentissement économique réel. La semaine prochaine, Oracle lundi sera le premier test de la demande IA cloud enterprise, suivi d'Adobe jeudi pour l'IA créative. Le CPI mercredi sera le catalyseur sectoriel qui décidera si la rotation défensive s'accélère ou si la tech rebondit.",
  },

  signalVsBruit: {
    signal: [
      "Énergie +4,82% vs Tech -2,35% — cette divergence n'est pas du bruit, c'est un changement de régime sectoriel. L'argent sort de la croissance pour aller vers les actifs réels.",
      "Russell 2000 -4,07% — quand les small caps chutent plus vite que les large caps, c'est un signal macro de ralentissement économique, pas un accident de parcours.",
      "ISM Prices 70,5 — les coûts de production explosent. Ce chiffre va se retrouver dans les marges des entreprises au prochain trimestre. C'est un signal avancé de compression des bénéfices.",
      "META seul Mag 7 positif YTD — pour la première fois depuis 2022, les géants tech ne portent plus le marché. C'est la fin d'une ère.",
    ],
    bruit: [
      "Rebond technique intraday mercredi — les espoirs de désescalade Iran ont duré quelques heures avant d'être effacés. C'est du bruit de trading, pas un retournement.",
      "Rumeurs de baisse de taux d'urgence — aucune base factuelle. La Fed est en blackout et l'inflation accélère. Une baisse d'urgence est le scénario le moins probable.",
      "Comparaisons avec 2008 — prématurées et trompeuses. Les banques sont bien capitalisées, le système financier est plus solide, et nous n'avons pas de crise du crédit immobilier résidentiel.",
    ],
    lectureWMB: "Le signal dominant de la semaine est sans ambiguïté : rotation sectorielle massive de la tech vers l'énergie et les défensives. Ce n'est pas du bruit — c'est un changement de régime qui reflète le passage d'un marché 'growth' à un marché 'value/real assets'. Le Russell 2000 à -4,07% est un signal macro important que les investisseurs en large caps ont tendance à ignorer : les small caps sont les premières à souffrir quand l'économie ralentit, et elles sont souvent un indicateur avancé de 3 à 6 mois. L'ISM Prices à 70,5 est le signal le plus inquiétant pour les marges — les entreprises vont devoir soit absorber la hausse des coûts (compression des marges), soit la répercuter sur les consommateurs (risque de baisse de la demande). Les comparaisons avec 2008 sont du bruit — les fondamentaux bancaires sont radicalement différents.",
  },

  topGainersLarge: [
    { rank: 1, ticker: "CVX", company: "Chevron", perf: "+8.5%", catalyst: "Pétrole au-dessus de $90, production record au Permian, dividende solide de 4,1% — le titre refuge par excellence dans un environnement de choc pétrolier" },
    { rank: 2, ticker: "XOM", company: "Exxon Mobil", perf: "+7.2%", catalyst: "Brent au-dessus de $92, marge de raffinage en forte hausse, programme de rachat d'actions maintenu" },
    { rank: 3, ticker: "COP", company: "ConocoPhillips", perf: "+6.8%", catalyst: "Pure-play E&P avec le levier le plus direct sur le prix du baril — chaque dollar de hausse du WTI ajoute ~$1 milliard de cash-flow annuel" },
    { rank: 4, ticker: "LMT", company: "Lockheed Martin", perf: "+4.5%", catalyst: "Conflit Iran booste les commandes de défense, carnet de commandes record, dividende croissant" },
    { rank: 5, ticker: "RTX", company: "RTX Corp", perf: "+3.8%", catalyst: "Défense + aérospatiale commerciale, carnet de commandes record de $200+ milliards" },
  ],
  topGainersLargeLecture: "Les gagnants de la semaine sont exclusivement dans l'énergie et la défense — les deux secteurs qui bénéficient directement du conflit US-Iran. Chevron (+8,5%) et Exxon (+7,2%) profitent du pétrole au-dessus de $90 avec des marges de raffinage en forte hausse. ConocoPhillips (+6,8%) est le pure-play E&P le plus exposé au prix du baril — son levier opérationnel est maximal. Lockheed Martin (+4,5%) et RTX (+3,8%) bénéficient du 'war trade' avec des commandes de défense en hausse. C'est un palmarès de guerre — et tant que le conflit Iran dure, ces titres resteront les leaders.",

  topLosersLarge: [
    { rank: 1, ticker: "AMZN", company: "Amazon", perf: "-5.2%", catalyst: "Pire performer des Mag 7 à -15,1% YTD — la consommation en berne pèse sur le retail, AWS sous pression concurrentielle face à OCI" },
    { rank: 2, ticker: "TSLA", company: "Tesla", perf: "-4.8%", catalyst: "Paradoxe : le pétrole cher devrait aider les EV, mais les tarifs, l'incertitude politique et la baisse de la demande en Chine dominent" },
    { rank: 3, ticker: "CCL", company: "Carnival", perf: "-8.5%", catalyst: "Le kérosène en flambée détruit le modèle croisière — le carburant représente 15-20% des coûts opérationnels" },
    { rank: 4, ticker: "DAL", company: "Delta Airlines", perf: "-7.2%", catalyst: "Le kérosène représente 25-30% des coûts — chaque hausse de $10/baril coûte ~$1 milliard par an à l'industrie" },
    { rank: 5, ticker: "HD", company: "Home Depot", perf: "-4.1%", catalyst: "Taux élevés (10Y à 4,13%) + ralentissement immobilier = double peine pour le leader du home improvement" },
  ],
  topLosersLargeLecture: "Les perdants de la semaine reflètent parfaitement le scénario de stagflation. Amazon (-5,2%) est le pire performer des Mag 7 à -15,1% YTD — la consommation en berne pèse sur le retail et AWS fait face à la concurrence croissante d'OCI (Oracle). Tesla (-4,8%) vit un paradoxe : le pétrole cher devrait théoriquement favoriser les véhicules électriques, mais les tarifs douaniers, l'incertitude politique et la baisse de la demande en Chine l'emportent. Carnival (-8,5%) et Delta (-7,2%) sont les victimes directes du pétrole cher — le kérosène représente 25-30% des coûts des airlines, et chaque hausse de $10/baril coûte environ $1 milliard par an à l'industrie. Home Depot (-4,1%) souffre du double coup taux élevés + ralentissement immobilier.",

  topGainersMidSmall: [
    { rank: 1, ticker: "FANG", company: "Diamondback Energy", perf: "+9.2%", catalyst: "Pure-play Permian Basin avec les coûts de production les plus bas du secteur — levier maximal sur le WTI" },
    { rank: 2, ticker: "DVN", company: "Devon Energy", perf: "+7.8%", catalyst: "E&P mid-cap avec dividende variable qui augmente automatiquement avec le prix du pétrole" },
    { rank: 3, ticker: "HES", company: "Hess Corp", perf: "+6.5%", catalyst: "Production en hausse au Guyana, levier direct sur le Brent" },
  ],
  topGainersMidSmallLecture: "Les mid-caps énergie surperforment les large-caps grâce à leur levier opérationnel plus élevé sur le prix du pétrole. Diamondback Energy (+9,2%) est le meilleur performer de toute la semaine — un pure-play Permian Basin avec des coûts de production parmi les plus bas du secteur ($35-40/baril), ce qui signifie que chaque dollar au-dessus de $40 est du profit quasi-pur. Devon Energy (+7,8%) bénéficie de son dividende variable qui augmente mécaniquement avec le prix du pétrole — un mécanisme que les investisseurs adorent en période de hausse du baril.",

  topLosersMidSmall: [
    { rank: 1, ticker: "SAVE", company: "Spirit Airlines", perf: "-12.5%", catalyst: "Le modèle ultra-low-cost ne peut pas absorber la hausse du kérosène — les marges déjà razor-thin deviennent négatives" },
    { rank: 2, ticker: "NCLH", company: "Norwegian Cruise", perf: "-9.8%", catalyst: "Pétrole = coût carburant en flambée, craintes de récession sur le tourisme de masse" },
    { rank: 3, ticker: "RH", company: "RH (Restoration Hardware)", perf: "-8.2%", catalyst: "Le luxe immobilier s'effondre — taux élevés + ralentissement du marché haut de gamme" },
  ],
  topLosersMidSmallLecture: "Les mid-caps les plus touchées sont dans le transport et la consommation discrétionnaire — les secteurs les plus vulnérables à la stagflation. Spirit Airlines (-12,5%) est le cas le plus extrême : son modèle ultra-low-cost repose sur des marges razor-thin qui deviennent négatives quand le kérosène flambe. Norwegian Cruise (-9,8%) souffre du même problème avec le carburant maritime. RH (-8,2%) est pénalisé par l'effondrement du marché immobilier haut de gamme — quand les taux sont à 4,13% et que l'économie ralentit, personne ne rénove sa maison à $50 000.",

  sectors: [
    { sector: "Énergie", perf: "+4.82%", note: "Seul secteur en hausse — pétrole au-dessus de $90, conflit Iran, Chevron et Exxon en tête", positive: true },
    { sector: "Biens Conso. Base", perf: "+1.15%", note: "Flight-to-safety — Procter & Gamble, Coca-Cola, Walmart résistent grâce à leur profil défensif", positive: true },
    { sector: "Utilities", perf: "+0.87%", note: "Dividendes élevés et profil non-cyclique attirent les flux en période de stress", positive: true },
    { sector: "Santé", perf: "+0.42%", note: "Pharma résiste (Lilly, Merck), biotech sous pression (risk-off)", positive: true },
    { sector: "Materials", perf: "-0.35%", note: "Aluminium en hausse (+4,19%) mais cuivre en baisse (-3,50%) — signal mixte", positive: false },
    { sector: "Immobilier", perf: "-1.12%", note: "Taux à 4,13% pèsent sur les REITs — le coût du capital augmente", positive: false },
    { sector: "Communication", perf: "-1.45%", note: "META résiste (+5,2% YTD) mais le reste du secteur recule", positive: false },
    { sector: "Industriels", perf: "-2.18%", note: "Défense en hausse mais airlines et transport en chute — forte dispersion intra-sectorielle", positive: false },
    { sector: "Tech", perf: "-2.35%", note: "Correction prolongée — NVIDIA -10% YTD, valorisations sous pression avec les taux en hausse", positive: false },
    { sector: "Financières", perf: "-2.87%", note: "Craintes de crédit, spreads HY en hausse, épisode BlackRock", positive: false },
    { sector: "Conso. Discrétionnaire", perf: "-3.45%", note: "Pire secteur — airlines, croisières, homebuilders massacrés par le pétrole et les taux", positive: false },
  ],
  sectorsLecture: "La carte sectorielle est parfaitement binaire cette semaine : énergie et défensives en hausse, tout le reste en baisse. C'est la signature d'un marché en mode stagflation — l'argent quitte les actifs de croissance pour se réfugier dans les actifs réels et les dividendes. L'énergie (+4,82%) domine de la tête et des épaules, portée par le pétrole au-dessus de $90. Les Consumer Staples (+1,15%), Utilities (+0,87%) et Healthcare (+0,42%) confirment le flight-to-quality classique — les investisseurs veulent des dividendes, de la visibilité et de la résilience. À l'opposé, le Consumer Discretionary (-3,45%) est le grand perdant — les airlines et croisières souffrent directement du pétrole cher, et les homebuilders des taux élevés. La tech (-2,35%) continue sa correction, plombée par des valorisations élevées dans un contexte de taux en hausse. Les financières (-2,87%) reculent sur les craintes de crédit. C'est un marché de stock pickers, pas un marché directionnel — il faut être dans les bons secteurs.",

  techSemis: {
    overview: "Les semi-conducteurs sont en correction prolongée pour la troisième semaine consécutive. Le SOX Index perd environ 3% sur la semaine. NVIDIA -10,2% YTD, AMD -12%, Intel -8%.",
    highlights: [
      { title: "NVIDIA — Correction Prolongée, Support à $110", description: "NVIDIA recule à -10,2% YTD après avoir été la star de 2024-2025. Le titre est directement sensible aux résultats d'Oracle lundi — si la demande IA cloud est forte, NVDA pourrait rebondir. Le support technique se situe à $110, en dessous c'est $100." },
      { title: "AMD — Sous Pression Concurrentielle", description: "AMD perd 12% YTD. La concurrence avec NVIDIA sur les GPU IA (MI300X vs H100/B100) et les craintes de surcapacité pèsent sur le titre. Le marché doute de la capacité d'AMD à gagner des parts de marché significatives." },
      { title: "Broadcom — Résultats Solides, Marché Ingrat", description: "Broadcom a publié des résultats solides la semaine dernière mais le titre n'a pas réussi à maintenir ses gains dans le sell-off général — un signe que même les bonnes nouvelles ne suffisent pas dans ce marché." },
    ],
    lectureWMB: "Les semi-conducteurs sont dans un no man's land. Le narratif IA reste fondamentalement intact — la demande de GPU est forte, les data centers investissent massivement, et les carnets de commandes sont pleins. Mais les valorisations sont sous pression dans un environnement de taux élevés et de stagflation. Oracle lundi sera un test indirect crucial pour tout le secteur : si la demande IA cloud enterprise est forte via OCI, ça validera le cycle d'investissement IA et les semis pourraient rebondir. Si Oracle déçoit, la correction pourrait s'accélérer car le marché commencerait à douter de la monétisation de l'IA au-delà du hardware.",
  },

  softwareCloud: {
    overview: "Le software/cloud est sous pression avec le BVP Cloud Index en baisse d'environ 2,5% sur la semaine. Les multiples se compriment sous l'effet des taux élevés et de la prudence sur les dépenses IT enterprise.",
    highlights: [
      { title: "Oracle (ORCL) — Lundi Après Clôture, Titre de la Semaine", description: "Oracle est le titre le plus important de la semaine. OCI (Oracle Cloud Infrastructure) est le test de la demande IA enterprise — le marché veut savoir si l'IA crée de la valeur au-delà des semi-conducteurs. Consensus : BPA ~$1,70, revenus ~$14,5 Mds. Le titre a déjà perdu 21% YTD, donc les attentes sont basses." },
      { title: "Adobe (ADBE) — Jeudi Après Clôture, Test IA Créative", description: "Adobe testera la monétisation de l'IA créative avec Firefly. L'ARR Creative Cloud et la guidance seront scrutés. Consensus : BPA ~$4,95, revenus ~$5,7 Mds. La question clé : Firefly cannibalise-t-il les abonnements existants ou crée-t-il de la valeur incrémentale ?" },
      { title: "Salesforce — Prudence Enterprise", description: "CRM perd du terrain sur les craintes de ralentissement des dépenses IT enterprise. Les entreprises reportent les projets non-essentiels dans un contexte d'incertitude." },
    ],
    lectureWMB: "Le software/cloud est à un moment charnière. Oracle lundi testera si l'IA crée de la valeur au-delà des semi-conducteurs — c'est la question à $1 trillion que le marché se pose depuis un an. Si OCI montre une croissance forte et un carnet de commandes IA solide, ça validera le cycle d'investissement et tout le secteur pourrait rebondir. Adobe jeudi testera l'autre face de l'IA — la monétisation créative. Si Firefly génère de l'ARR incrémental (pas juste de la cannibalisation), c'est bullish pour tout le SaaS. Si les deux déçoivent, la compression des multiples continuera et le secteur pourrait perdre 5-10% supplémentaires.",
  },

  healthcare: {
    overview: "Healthcare mixte à +0,42% sur la semaine. Les grandes pharma résistent grâce à leur profil défensif, tandis que la biotech souffre du risk-off.",
    highlights: [
      { title: "Eli Lilly — La Résilience GLP-1", description: "LLY résiste mieux que le marché grâce à la demande insatiable pour Mounjaro et Zepbound. Le titre reste un 'must-own' pour les fonds — la thèse GLP-1 est indépendante du cycle économique." },
      { title: "Biotech — Risk-Off Pénalisant", description: "Le XBI (ETF biotech) perd environ 3% sur la semaine. Le risk-off pénalise les biotechs à forte croissance qui dépendent du financement et des valorisations élevées." },
    ],
    lectureWMB: "Le healthcare joue son rôle défensif classique dans un marché en stress. Les grandes pharma (Lilly, Merck, Pfizer, J&J) résistent grâce à leurs dividendes, leur visibilité sur les revenus et leur profil non-cyclique. Eli Lilly reste le titre phare du secteur — la thèse GLP-1 (obésité/diabète) est un méga-trend qui transcende le cycle économique. La biotech souffre en revanche du risk-off — quand les investisseurs fuient le risque, les biotechs à forte volatilité sont les premières vendues. Pas de catalyseur earnings majeur dans le secteur cette semaine.",
  },

  financials: {
    overview: "Financières -2,87% sur la semaine. Les banques sont sous pression sur les craintes de crédit et la hausse des spreads HY. L'épisode BlackRock a secoué le secteur.",
    highlights: [
      { title: "JPMorgan — Dimon Tire la Sonnette d'Alarme", description: "JPM recule sur les craintes de hausse des provisions pour pertes de crédit. Jamie Dimon a qualifié le conflit Iran de 'risque systémique' et JPM a relevé ses prévisions de pétrole à $100-110 en cas d'escalade." },
      { title: "Goldman Sachs — La Volatilité, Amie et Ennemie", description: "GS bénéficie de la volatilité (revenus de trading en hausse) mais souffre de la baisse des IPO et du M&A. Le pipeline de deals est gelé dans l'attente de plus de visibilité." },
      { title: "Régionales — Le Maillon Faible", description: "Les banques régionales (KRE ETF) perdent environ 4% sur les craintes de crédit immobilier commercial. Leur exposition au CRE (commercial real estate) est le risque principal." },
    ],
    lectureWMB: "Les financières sont prises dans un étau. D'un côté, la hausse des taux devrait être positive pour les marges d'intérêt net — c'est le business model de base d'une banque. De l'autre, le ralentissement économique augmente le risque de défauts de crédit, ce qui force les banques à augmenter leurs provisions. Les banques régionales sont le maillon faible — leur exposition à l'immobilier commercial (CRE) est un risque majeur dans un environnement de taux élevés et de ralentissement. Les grandes banques (JPM, GS, MS) résistent mieux grâce à la diversification et aux revenus de trading qui explosent avec la volatilité. L'épisode BlackRock (limites de retraits sur fonds de crédit privé) est un signal d'alarme pour tout le secteur financier.",
  },

  cyclicals: {
    overview: "Industriels -2,18% sur la semaine. Le secteur est divisé : la défense surperforme massivement tandis que les airlines et le transport s'effondrent.",
    highlights: [
      { title: "Défense — Le 'War Trade' en Action", description: "Lockheed Martin (+4,5%), RTX (+3,8%), Northrop Grumman (+3,2%) — le conflit Iran booste les commandes de défense. Le plan européen de 800 milliards EUR ajoute un catalyseur structurel." },
      { title: "Airlines — Kérosène en Flambée", description: "Delta (-7,2%), United (-6,5%), American (-6,8%) — le kérosène en flambée détruit les marges. Le carburant représente 25-30% des coûts des airlines, et chaque hausse de $10/baril coûte ~$1 milliard par an à l'industrie." },
      { title: "Caterpillar — Le Baromètre de l'Économie Réelle", description: "CAT recule de 3% — un signal de ralentissement de l'activité de construction et minière. Quand Caterpillar baisse, c'est que l'économie réelle ralentit." },
    ],
    lectureWMB: "Les industriels illustrent parfaitement la dispersion du marché actuel. La défense surperforme massivement grâce au conflit Iran et au plan de réarmement européen — Lockheed Martin et RTX sont en mode 'war trade'. Mais les airlines et le transport sont en chute libre : Delta, United et American perdent 6-7% chacune car le kérosène en flambée détruit leurs marges. Caterpillar est un baromètre important de l'économie réelle — sa baisse de 3% signale que l'activité de construction et minière ralentit. Les tarifs douaniers ajoutent une couche de pression sur les coûts de production de tout le secteur.",
  },

  consumption: {
    overview: "Consumer Discretionary -3,45% — pire secteur de la semaine. Le pétrole cher + les craintes de récession + les taux élevés forment un cocktail toxique pour la consommation.",
    highlights: [
      { title: "Dollar General (DG) — Jeudi, Baromètre du Consommateur", description: "Test du consommateur bas de gamme — le segment le plus vulnérable à l'inflation. Same-store sales et impact inflation seront scrutés. Consensus BPA ~$1,50. Si DG déçoit, c'est un signal de récession." },
      { title: "Ulta Beauty (ULTA) — Jeudi, Résilience Beauté", description: "Test de la résilience des dépenses beauté dans un contexte de ralentissement. Comparable sales attendus. Consensus BPA ~$8,50. Le 'lipstick effect' (les consommateurs achètent du maquillage en récession) sera testé." },
      { title: "Nike — La Consommation Mondiale en Berne", description: "NKE continue de reculer sur les craintes de ralentissement de la consommation mondiale et la concurrence croissante (On Running, Hoka)." },
    ],
    lectureWMB: "Le consumer discretionary est le grand perdant de la stagflation — et c'est logique. Le pétrole cher réduit le pouvoir d'achat des consommateurs (l'essence est un impôt invisible), les taux élevés pèsent sur le crédit à la consommation, et l'emploi se dégrade (NFP -92K). Dollar General jeudi sera le baromètre le plus important : si le consommateur bas de gamme — celui qui dépense chaque dollar — commence à couper ses dépenses, c'est un signal de récession avancé. Ulta Beauty testera le fameux 'lipstick effect' — l'idée que les consommateurs se tournent vers les petits plaisirs (maquillage, beauté) quand ils ne peuvent plus se permettre les gros achats.",
  },

  earningsWinners: [
    { rank: 1, ticker: "CVX", company: "Chevron", detail: "Pas de publication cette semaine mais +8,5% sur le pétrole au-dessus de $90 — le grand gagnant sectoriel de la semaine." },
    { rank: 2, ticker: "LMT", company: "Lockheed Martin", detail: "+4,5% sur le conflit Iran et les commandes de défense en hausse — le 'war trade' en action." },
    { rank: 3, ticker: "XOM", company: "Exxon Mobil", detail: "+7,2% — marge de raffinage en forte hausse, production record, programme de rachat maintenu." },
  ],
  earningsWinnersLecture: "Les gagnants de la semaine ne sont pas liés aux earnings mais au pétrole et à la géopolitique. Chevron, Exxon et Lockheed Martin dominent grâce au conflit Iran — c'est un palmarès de guerre, pas un palmarès de résultats. Tant que le pétrole reste au-dessus de $90 et que le conflit dure, ces titres resteront les leaders du marché.",

  earningsLosers: [
    { rank: 1, ticker: "CCL", company: "Carnival", detail: "-8,5% — le kérosène en flambée détruit le modèle croisière. Le carburant représente 15-20% des coûts opérationnels." },
    { rank: 2, ticker: "DAL", company: "Delta Airlines", detail: "-7,2% — coûts carburant en hausse de 25-30%, marges sous pression maximale." },
    { rank: 3, ticker: "AMZN", company: "Amazon", detail: "-5,2% sur la semaine, -15,1% YTD — pire performer des Mag 7, consommation en berne et AWS sous pression." },
  ],
  earningsLosersLecture: "Les perdants sont les victimes directes du pétrole cher (Carnival, Delta) et du ralentissement de la consommation (Amazon). Carnival et Delta sont dans une situation critique : leurs marges sont structurellement liées au prix du kérosène, et elles n'ont pas de couverture suffisante pour absorber une hausse de cette ampleur. Amazon souffre d'un double coup : la consommation en berne pèse sur le retail, et AWS fait face à la concurrence croissante d'OCI (Oracle).",

  guidanceThemes: [
    { title: "Impact Tarifs sur les Marges — Le Coût Caché", description: "Les entreprises commencent à mentionner l'impact des tarifs de 10% sur leurs coûts de production. L'ISM Prices à 70,5 confirme que les coûts explosent. Au prochain trimestre, les marges vont se comprimer — la question est de combien." },
    { title: "Prudence sur les Dépenses IT Enterprise", description: "Plusieurs entreprises signalent un ralentissement des dépenses IT enterprise — les projets non-essentiels sont reportés dans l'attente de plus de visibilité. C'est un risque direct pour Oracle et Adobe cette semaine." },
    { title: "Pétrole et Coûts de Transport — L'Impôt Invisible", description: "Les entreprises de transport, airlines et retail signalent une hausse significative des coûts de carburant et de logistique. Walmart et Target ont déjà averti que les prix en rayon augmenteraient." },
  ],
  guidanceLecture: "Les guidances de la saison Q4 dessinent un tableau préoccupant pour les marges au prochain trimestre. Trois thèmes dominent : (1) l'impact des tarifs sur les coûts de production — l'ISM Prices à 70,5 confirme que les entreprises absorbent déjà des hausses massives, (2) la prudence sur les dépenses IT — un risque direct pour Oracle et Adobe cette semaine, et (3) la hausse des coûts de transport liée au pétrole. La question clé pour le Q1 2026 sera : les entreprises peuvent-elles répercuter ces hausses sur les consommateurs sans perdre de volume ?",

  analystMoves: [
    { title: "JPMorgan relève le pétrole à $100-110", description: "JPMorgan relève ses prévisions de pétrole en cas d'escalade Iran. Impact positif sur l'énergie (CVX, XOM, COP), négatif sur les airlines (DAL, UAL) et la consommation (AMZN, TGT)." },
    { title: "Goldman Sachs dégrade le Consumer Discretionary", description: "GS passe le secteur Consumer Discretionary à 'Underweight' sur les craintes de stagflation — la première grande banque à officialiser le trade." },
    { title: "Morgan Stanley maintient 'Overweight' sur la Tech", description: "MS considère la correction tech comme une opportunité d'achat à moyen terme — les fondamentaux IA restent intacts et les valorisations deviennent attractives." },
  ],
  analystLecture: "Les analystes sont profondément divisés, ce qui reflète l'incertitude du marché. JPMorgan et Goldman sont clairement bearish sur la consommation et bullish sur l'énergie — ils jouent le scénario stagflation. Morgan Stanley reste constructif sur la tech à moyen terme, considérant la correction comme une opportunité. Cette divergence entre les grandes banques est un signal que le marché est à un point d'inflexion — le CPI de mercredi tranchera le débat.",

  corporateActions: [
    { title: "Buybacks en Pause — Signal de Prudence", description: "Plusieurs entreprises ont mis en pause leurs programmes de rachat d'actions dans l'attente de plus de visibilité sur l'économie. Quand les CFOs arrêtent de racheter leurs propres actions, c'est qu'ils voient quelque chose d'inquiétant." },
    { title: "Dividendes Énergie en Hausse", description: "Les producteurs de pétrole augmentent leurs dividendes variables grâce à la hausse du baril. Devon Energy et Diamondback Energy ont annoncé des hausses de dividendes cette semaine." },
  ],
  corporateLecture: "Les actions corporate racontent deux histoires différentes. D'un côté, les buybacks sont en pause dans de nombreux secteurs — un signal de prudence des CFOs qui préfèrent garder du cash dans un environnement incertain. De l'autre, les dividendes énergie augmentent mécaniquement avec le prix du pétrole. Cette divergence confirme la rotation des flux vers l'énergie et les actifs réels.",

  regulation: [
    { title: "Tarifs Trump — L'Inflation 'Made in Policy'", description: "Les tarifs de 10% sont en vigueur depuis deux semaines et leur impact commence à se faire sentir. L'ISM Prices à 70,5 reflète en partie l'impact des tarifs sur les coûts de production. C'est une inflation 'made in policy' qui s'ajoute au choc pétrolier." },
    { title: "FTC — Surveillance IA Renforcée", description: "La FTC intensifie sa surveillance des pratiques IA des Big Tech — en particulier sur la collecte de données et les pratiques anticoncurrentielles. Pas d'action immédiate mais un risque réglementaire à moyen terme pour GOOGL, META et MSFT." },
  ],
  regulationLecture: "Les tarifs Trump sont le facteur réglementaire dominant cette semaine. Leur impact se fait sentir dans les coûts de production (ISM Prices 70,5) et sera visible dans les marges au prochain trimestre. C'est une inflation 'made in policy' qui s'ajoute au choc pétrolier — un double coup pour les entreprises. La surveillance FTC sur l'IA est un risque à moyen terme mais pas un catalyseur immédiat.",

  emergingThemes: [
    { number: 1, title: "Stagflation Trade — Long Énergie, Short Tech", facts: "NFP -92K + ISM Prices 70,5 + pétrole au-dessus de $90 = stagflation. L'énergie surperforme de 7+ points la tech sur la semaine.", hypothesis: "Si le CPI confirme l'inflation, le 'stagflation trade' (long énergie/or, short tech/consommation) pourrait durer plusieurs mois — historiquement, ces rotations durent 6 à 12 mois.", counterSignal: "Un CPI sous 2,3% invaliderait le scénario stagflationniste à court terme et déclencherait un short squeeze violent sur la tech." },
    { number: 2, title: "Fin du Mag 7 Leadership — Changement d'Ère", facts: "6 des 7 Magnificent sont négatifs YTD. Seul META résiste. Le marché n'est plus porté par les géants tech — c'est la première fois depuis 2022.", hypothesis: "La concentration du marché diminue — c'est potentiellement sain à long terme (marché plus large) mais douloureux à court terme pour les portefeuilles surpondérés en tech.", counterSignal: "Des résultats Oracle/Adobe exceptionnels pourraient relancer le narratif tech/IA et ramener les flux vers les Mag 7." },
    { number: 3, title: "War Premium Durable — Pétrole Structurellement Plus Haut", facts: "Le conflit US-Iran entre dans sa 2ème semaine. Le pétrole intègre une prime géopolitique estimée à $10-15/baril.", hypothesis: "Si le conflit dure, la prime géopolitique pourrait devenir structurelle — pétrole au-dessus de $85 pendant des mois, avec des implications majeures pour l'inflation et les marges.", counterSignal: "Une désescalade rapide ferait chuter le pétrole de $10-15 en quelques jours — un 'peace dividend' massif pour les marchés." },
  ],
  emergingThemesLecture: "Trois thèmes émergents dominent le marché et pourraient définir les prochaines semaines. Le 'stagflation trade' (long énergie/or, short tech/consommation) est le plus puissant — il reflète un changement de régime fondamental. La fin du leadership des Mag 7 est un événement historique qui force les investisseurs à repenser leur allocation. Et la prime de guerre durable sur le pétrole crée une incertitude structurelle sur l'inflation. Le CPI de mercredi sera le test décisif pour ces trois thèmes.",

  radarStocks: [
    { rank: 1, ticker: "ORCL", company: "Oracle", activity: "Earnings lundi après clôture", catalyst: "OCI cloud growth au-dessus de 30%, carnet de commandes IA, guidance cloud — le titre le plus important de la semaine", risks: "Croissance cloud décevante vs AWS/Azure, guidance prudente sur le macro" },
    { rank: 2, ticker: "ADBE", company: "Adobe", activity: "Earnings jeudi après clôture", catalyst: "Firefly adoption rate, ARR Creative Cloud au-dessus de $14B, guidance positive", risks: "Cannibalisation par outils IA gratuits, ralentissement enterprise" },
    { rank: 3, ticker: "DG", company: "Dollar General", activity: "Earnings jeudi avant ouverture", catalyst: "Same-store sales positifs, baromètre du consommateur bas de gamme", risks: "Marges sous pression (pétrole, transport, vol à l'étalage)" },
    { rank: 4, ticker: "FANG", company: "Diamondback Energy", activity: "Momentum pétrole", catalyst: "Pure-play Permian, levier maximal sur WTI — chaque dollar de hausse = profit quasi-pur", risks: "Désescalade Iran = correction rapide de 10-15%" },
    { rank: 5, ticker: "LMT", company: "Lockheed Martin", activity: "Momentum défense", catalyst: "Conflit Iran + plan défense européen 800 Mds EUR = double catalyseur", risks: "Désescalade = prise de profits, mais le plan européen reste un soutien structurel" },
  ],
  radarLecture: "Le radar de la semaine est dominé par les earnings (Oracle, Adobe, Dollar General) et les trades macro (Diamondback pour l'énergie, Lockheed pour la défense). Oracle lundi est le titre le plus important — il donnera le ton pour toute la semaine et pour tout le secteur tech/IA. Adobe jeudi est le deuxième test majeur. Dollar General est le baromètre du consommateur. Diamondback et Lockheed sont les plays directionnels sur le pétrole et la géopolitique.",

  influentialVoices: [
    { name: "Jamie Dimon", role: "CEO JPMorgan", idea: "Le conflit Iran est un 'risque systémique' pour les marchés. JPM relève ses prévisions pétrole à $100-110 en cas d'escalade. Prudence maximale sur les actions.", whyFollowed: "CEO de la plus grande banque US — quand Dimon parle de risque systémique, le marché écoute." },
    { name: "Larry Fink", role: "CEO BlackRock", idea: "Le marché sous-estime le risque de stagflation. Surpondérer les actifs réels (commodities, or, TIPS). L'épisode des limites de retraits sur les fonds de crédit privé est un signal.", whyFollowed: "Gère plus de $10 trillions d'actifs — ses allocations influencent directement les flux mondiaux." },
    { name: "Cathie Wood", role: "CEO ARK Invest", idea: "La correction tech est une opportunité d'achat générationnelle. L'IA est un cycle de 10 ans, pas de 10 semaines. ARK achète NVDA et TSLA sur la baisse.", whyFollowed: "Voix contrariante influente — ses achats signalent la conviction des bulls tech et attirent les investisseurs retail." },
  ],
  voicesLecture: "Les voix influentes sont profondément divisées cette semaine. D'un côté, Dimon et Fink — les deux plus puissants banquiers de Wall Street — sont bearish et parlent de risque systémique et de stagflation. De l'autre, Cathie Wood est résolument bullish et achète la baisse tech en parlant d'opportunité générationnelle. Cette divergence entre les 'smart money' est le reflet d'un marché à un point d'inflexion — le CPI de mercredi tranchera le débat, au moins à court terme.",

  watchlist: [
    { ticker: "ORCL", angle: "IA Cloud Enterprise", watchFor: "OCI revenue growth au-dessus de 30%, carnet de commandes IA en hausse, guidance cloud positive — si les trois sont au rendez-vous, c'est bullish pour tout le secteur" },
    { ticker: "ADBE", angle: "IA Créative", watchFor: "Firefly adoption rate, ARR Creative Cloud au-dessus de $14B, guidance positive — le test de la monétisation IA créative" },
    { ticker: "DG", angle: "Consommateur Bas de Gamme", watchFor: "Same-store sales positifs, marges brutes stables, guidance non-catastrophique — le baromètre de la récession" },
    { ticker: "XLE", angle: "ETF Énergie", watchFor: "Pétrole au-dessus de $95 = continuation du rally, sous $85 = prise de profits. Le conflit Iran est le driver." },
    { ticker: "TLT", angle: "Obligations Long Terme", watchFor: "CPI chaud = baisse TLT (taux en hausse), CPI froid = rebond TLT (taux en baisse). Le trade le plus binaire de la semaine." },
  ],
  watchlistLecture: "La watchlist est centrée sur les earnings (ORCL, ADBE, DG) et les trades macro (XLE pour l'énergie, TLT pour les obligations). Oracle lundi est le catalyseur principal — il donnera le ton pour la tech et l'IA. Le CPI mercredi déterminera la direction de XLE (énergie) et TLT (obligations). Dollar General jeudi est le baromètre du consommateur. C'est une semaine où chaque jour apporte un catalyseur potentiel — il faut rester vigilant et réactif.",

  calendar: [
    { day: "Lundi", date: "09/03", events: ["Ouverture sous pression (futures en forte baisse, Nikkei -5,24%)"] },
    { day: "Mardi", date: "10/03", events: ["Oracle (ORCL) — apres cloture [!] — TITRE DE LA SEMAINE", "NFIB Small Business Index", "Existing Home Sales"] },
    { day: "Mercredi", date: "11/03", events: ["CPI fevrier [!] — EVENEMENT CLE DE LA SEMAINE", "Core CPI fevrier [!]"] },
    { day: "Jeudi", date: "12/03", events: ["Dollar General (DG) — avant ouverture", "Adobe (ADBE) — apres cloture [!]", "Jobless Claims", "Building Permits"] },
    { day: "Vendredi", date: "13/03", events: ["PCE janvier [!] — retarde par shutdown", "Core PCE janvier [!]", "UMich Consumer Sentiment mars preliminaire [!]", "Durable Goods + JOLTS (retardes)"] },
  ],
  calendarLecture: "La semaine est exceptionnellement chargée en catalyseurs. Lundi : Oracle (test IA cloud). Mercredi : CPI (événement clé, juge de paix sur la stagflation). Jeudi : Adobe, Dollar General, Ulta Beauty (triple test tech/consommation). Vendredi : PCE, UMich, GDP (triple test macro). Chaque jour apporte un catalyseur potentiel — c'est une semaine où il faut être attentif du lundi au vendredi.",

  earningsToWatch: [
    { day: "Lundi", date: "10/03", timing: "Après clôture", ticker: "ORCL", company: "Oracle", watchFor: "OCI growth, carnet IA, cloud revenue — le test de la demande IA enterprise", highlight: true },
    { day: "Jeudi", date: "13/03", timing: "Avant ouverture", ticker: "DG", company: "Dollar General", watchFor: "Same-store sales, impact inflation — le baromètre du consommateur bas de gamme", highlight: false },
    { day: "Jeudi", date: "13/03", timing: "Après clôture", ticker: "ADBE", company: "Adobe", watchFor: "Firefly adoption, ARR Creative Cloud, guidance — le test de l'IA créative", highlight: true },
    { day: "Jeudi", date: "13/03", timing: "Après clôture", ticker: "ULTA", company: "Ulta Beauty", watchFor: "Comparable sales, résilience beauté — le test du 'lipstick effect'", highlight: false },
  ],
  earningsToWatchLecture: "Oracle lundi et Adobe jeudi sont les deux événements earnings majeurs de la semaine. Oracle testera la demande IA cloud enterprise via OCI — c'est le test le plus important pour le narratif IA depuis les résultats de NVIDIA en février. Adobe testera la monétisation de l'IA créative avec Firefly. Dollar General donnera le pouls du consommateur bas de gamme — un indicateur avancé de récession. Ulta Beauty testera le fameux 'lipstick effect'. Quatre publications, quatre angles différents, quatre réponses à des questions clés du marché.",

  scenarios: [
    { name: "Scénario Bull", probability: "~15%", triggers: "CPI ≤ 2,3% YoY. Oracle publie des résultats exceptionnels (OCI growth >35%). Désescalade Iran.", signals: "VIX sous 22, S&P 500 rebond +3-5%, rotation retour vers la tech, short squeeze violent", invalidation: "CPI au-dessus de 2,5% ou escalade Iran" },
    { name: "Scénario Base", probability: "~45%", triggers: "CPI entre 2,3% et 2,5% YoY. Oracle en ligne avec les attentes. Iran contenu sans escalade.", signals: "VIX 25-30, S&P 500 entre -1% et +1%, forte volatilité intraday, range 6 650-6 800", invalidation: "CPI au-dessus de 2,6% ou sous 2,2%" },
    { name: "Scénario Bear", probability: "~40%", triggers: "CPI au-dessus de 2,5% YoY. Oracle déçoit. Escalade Iran (menace Ormuz).", signals: "VIX au-dessus de 32, S&P 500 -3-6%, rotation accélérée vers énergie/défensives, test support 6 400", invalidation: "CPI sous 2,3% et désescalade Iran" },
  ],
  risks: [
    { title: "Risque 1 — CPI Chaud = Stagflation Confirmée", description: "Un CPI au-dessus de 2,5% YoY confirmerait le piège stagflationniste. Impact sectoriel : sell-off tech et consommation, hausse énergie et or. La Fed serait piégée et le 'Fed put' disparaîtrait." },
    { title: "Risque 2 — Oracle Déçoit = Narratif IA Fissuré", description: "Si Oracle déçoit sur la demande IA cloud via OCI, c'est tout le narratif IA qui serait remis en question. Impact : NVDA, MSFT, AMZN en baisse de 3-5%. Le marché commencerait à douter de la monétisation de l'IA." },
    { title: "Risque 3 — Contagion Crédit Small Caps", description: "Le Russell 2000 à -4,07% signale un stress croissant sur les small caps. Si les spreads HY dépassent 400 bps, la contagion crédit pourrait s'accélérer vers les mid-caps et les banques régionales." },
    { title: "Risque 4 — Escalade Iran = Pétrole au-dessus de $100", description: "Si le Détroit d'Ormuz est menacé, le pétrole pourrait dépasser $100 — voire $150 selon le Qatar. Impact : inflation en flèche, marges en chute, récession probable." },
  ],
  scenarioDisclaimer: "Les scénarios présentés sont des hypothèses éducatives basées sur des données publiques disponibles au moment de la rédaction. Ils ne constituent pas des prévisions certaines ni des recommandations d'investissement.",

  conclusion: "La semaine 11 sera dominée par trois catalyseurs majeurs : Oracle lundi (test de la demande IA cloud), CPI mercredi (juge de paix sur la stagflation), et Adobe jeudi (test de la monétisation IA créative). Le risque est nettement asymétrique vers le bas (40% bear vs 15% bull). La rotation défensive (énergie, défensives, or) est le trade dominant depuis trois semaines. Le marché cherche un plancher après trois semaines de baisse consécutives — et le CPI de mercredi décidera s'il le trouve ou s'il continue de glisser.",
  conclusionLecture: "Trois semaines de baisse consécutives, un VIX à 29, un NFP à -92K, un pétrole au-dessus de $90 — le marché est sous pression maximale et cherche désespérément un plancher. La semaine 11 apportera des réponses : le CPI tranchera le débat stagflation, Oracle testera le narratif IA, et Adobe confirmera ou infirmera la monétisation de l'IA créative. Dans cet environnement, la prudence est de mise. Les actifs réels (énergie, or, TIPS) surperforment historiquement en période de stagflation. La diversification sectorielle et géographique n'est plus un luxe — c'est une nécessité. Et rappelons-le : dans un marché aussi incertain, la gestion du risque prime sur la recherche de performance.",

  pdfUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663135061541/Wf8Nj4yLBCzwrPQSdtP8cC/actions-s11_41d4f096.pdf",
  sources: "Données de marché : clôture US du vendredi 7 mars 2026 via Yahoo Finance, CNBC, Reuters et Nasdaq.com. Données sectorielles : S&P Global, FactSet, Seeking Alpha. Données earnings et consensus : Bloomberg, FactSet. Données ISM : Institute for Supply Management. Données NFP : Bureau of Labor Statistics (BLS). Anticipations Fed : CME FedWatch. Prévisions pétrole : JPMorgan Research.",
  disclaimer: "Ce document est produit à des fins strictement informatives et éducatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente d'actifs financiers, un conseil en investissement, ou une promesse de performance. Les marchés financiers sont par nature imprévisibles. L'environnement actuel de stagflation potentielle crée une incertitude exceptionnelle — toute décision d'investissement doit être prise avec une prudence accrue et en consultant un professionnel agréé.",
};
