/**
 * WMB Actions US — Semaine 14 (LUN 24/03 → VEN 28/03 2026)
 * Données vérifiées : CNBC, MarketWatch, SeekingAlpha, MLQ, AIMS FX
 * Clôture vendredi 27 mars 2026
 */
import type { ActionsModuleData } from "../actions";
export const ACTIONS_SEMAINE_14: ActionsModuleData = {
  id: 307,
  weekNumber: 14,
  year: 2026,
  dateRange: "LUN 24/03 → VEN 28/03",
  title: "Mag 7 -$850B, Nasdaq en Correction, Defense en Rallye",
  subtitle: "MODULE ACTIONS US",
  publishedAt: "2026-03-29T07:00:00Z",
  headerImage: "",
  executiveSummary: {
    weekPast: [
      "Les Magnificent 7 perdent $850 milliards de capitalisation en une seule semaine. Microsoft est le pire performer (-23% YTD). Meta est identifiee par CNBC comme l'une des actions les plus survendues du S&P 500.",
      "Le Nasdaq entre en correction officielle : -10,27% depuis son pic du 28 janvier. Le Russell 2000 reste en territoire de correction.",
      "La rotation sectorielle s'accelere : Energy +18% MTD, Defense +22% MTD (RTX +22%, LMT +19%, NOC +17%). Consumer Discretionary -12% MTD.",
      "Le VIX a 31,05 — regime de crise. Les volumes restent eleves, les institutionnels se repositionnent massivement.",
      "Le S&P 500 cloture a 5 580,94 (-1,67%). Le Dow a 41 583,90 (-1,73%). 5eme semaine de baisse consecutive.",
    ],
    weekAhead: [
      "Nike (NKE) mardi — test du consommateur americain sous pression du petrole cher.",
      "Powell parle lundi — tout signal hawkish pourrait amplifier le sell-off.",
      "NFP vendredi 3 avril — le chiffre le plus important du mois pour le marche du travail.",
      "Surveillance des Mag 7 : Meta survendue, NVIDIA en correction, Microsoft en chute libre.",
    ],
    lectureWMB: "La semaine 14 est un tournant pour les actions US. Les Magnificent 7 perdent $850 milliards en 5 jours — l'equivalent du PIB de la Suisse. Le Nasdaq en correction officielle (-10,27%) confirme que le repricing de la tech est structurel, pas technique. La rotation vers l'energie et la defense est la plus rapide depuis 2022. Le paradoxe : les fondamentaux tech restent solides (Micron a prouve la demande IA la semaine precedente), mais le petrole >$100 et le VIX >30 ecrasent toute tentative de rebond.",
  },
  signalVsBruit: {
    signal: [
      "Nasdaq en correction officielle (-10,27%) — repricing structurel des multiples tech",
      "Mag 7 perdent $850B en une semaine — concentration risk se materialise",
      "Rotation Energy/Defense la plus rapide depuis 2022 — changement de regime sectoriel",
      "VIX a 31 — regime de crise confirme",
    ],
    bruit: [
      "Rebonds intraday — techniques et de courte duree dans un VIX >30",
      "Rumeurs de desescalade Iran — non confirmees, le petrole reste >$100",
      "Comparaisons avec 2008 — prematurees, le systeme bancaire est solide",
    ],
    lectureWMB: "Le signal dominant est le repricing des multiples tech. Les Mag 7 perdent $850B mais leurs fondamentaux (demande IA, cloud growth) restent solides. Le marche vend les multiples, pas les fondamentaux — une distinction cruciale. Le bruit inclut les comparaisons avec 2008 qui sont prematurees : le systeme bancaire est solide, les bilans des entreprises sont sains. C'est un choc exogene (petrole/Iran), pas un choc endogene (credit/immobilier).",
  },
  topGainersLarge: [
    { rank: 1, ticker: "RTX", company: "RTX Corp", perf: "+5,20%", catalyst: "+22% MTD — beneficiaire direct du conflit Iran, contrats defense en hausse" },
    { rank: 2, ticker: "LMT", company: "Lockheed Martin", perf: "+4,80%", catalyst: "+19% MTD — commandes militaires en acceleration" },
    { rank: 3, ticker: "NOC", company: "Northrop Grumman", perf: "+4,50%", catalyst: "+17% MTD — defense aerienne et spatiale en demande" },
    { rank: 4, ticker: "XOM", company: "Exxon Mobil", perf: "+3,80%", catalyst: "Petrole >$100 = marges record, dividende solide" },
    { rank: 5, ticker: "CVX", company: "Chevron", perf: "+3,50%", catalyst: "Beneficiaire direct du petrole cher, production US en hausse" },
  ],
  topGainersLargeLecture: "Les gagnants de la semaine sont exclusivement dans la defense et l'energie. RTX (+5,2%), Lockheed Martin (+4,8%) et Northrop Grumman (+4,5%) continuent leur rallye impressionnant — +17% a +22% sur le mois. Exxon (+3,8%) et Chevron (+3,5%) beneficient du petrole au-dessus de $100.",
  topLosersLarge: [
    { rank: 1, ticker: "MSFT", company: "Microsoft", perf: "-3,50%", catalyst: "-23% YTD — pire performer des Mag 7, investissements IA massifs pesent" },
    { rank: 2, ticker: "TSLA", company: "Tesla", perf: "-3,20%", catalyst: "-15% YTD — sentiment negatif, Musk distrait par X/SpaceX" },
    { rank: 3, ticker: "META", company: "Meta Platforms", perf: "-2,80%", catalyst: "Parmi les plus survendues du S&P 500 selon CNBC — potentiel rebond" },
    { rank: 4, ticker: "AMZN", company: "Amazon", perf: "-2,50%", catalyst: "AWS resilient mais consommateur sous pression du petrole" },
    { rank: 5, ticker: "NVDA", company: "NVIDIA", perf: "-2,30%", catalyst: "-14% YTD — correction tech malgre demande IA intacte" },
  ],
  topLosersLargeLecture: "Les Magnificent 7 sont tous en baisse cette semaine. Microsoft est le plus touche (-3,5%, -23% YTD). Meta (-2,8%) est identifiee par CNBC comme survendue — un signal contrarian mais le timing est incertain avec un VIX >30.",
  topGainersMidSmall: [
    { rank: 1, ticker: "FSLR", company: "First Solar", perf: "+6,50%", catalyst: "Rotation vers le solaire — beneficiaire de la crise energetique et des subventions IRA" },
    { rank: 2, ticker: "RIG", company: "Transocean", perf: "+5,80%", catalyst: "Foreur offshore — petrole >$100 = demande de forage en explosion" },
    { rank: 3, ticker: "HAL", company: "Halliburton", perf: "+5,20%", catalyst: "Services petroliers — beneficiaire direct du petrole cher" },
  ],
  topGainersMidSmallLecture: "Les mid-small caps gagnantes sont toutes liees a l'energie. First Solar (+6,5%) beneficie de la rotation vers le renouvelable. Transocean (+5,8%) et Halliburton (+5,2%) profitent du petrole au-dessus de $100.",
  topLosersMidSmall: [
    { rank: 1, ticker: "SNAP", company: "Snap", perf: "-7,80%", catalyst: "Pub en ligne sous pression — budgets marketing reduits" },
    { rank: 2, ticker: "RIVN", company: "Rivian", perf: "-6,50%", catalyst: "EV sous pression — cash burn eleve, financement difficile" },
    { rank: 3, ticker: "SOFI", company: "SoFi Technologies", perf: "-5,90%", catalyst: "Fintech en risk-off — meme dynamique que Klarna" },
  ],
  topLosersMidSmallLecture: "Les mid-small caps perdantes sont les fintechs (SoFi -5,9%), les EV (Rivian -6,5%) et la pub digitale (Snap -7,8%). Le risk-off frappe plus durement les small caps.",
  sectors: [
    { sector: "Energy", perf: "+3,50%", note: "Seul secteur en forte hausse — petrole >$100", positive: true },
    { sector: "Defense/Aerospace", perf: "+2,80%", note: "RTX +22% MTD, LMT +19% MTD", positive: true },
    { sector: "Consumer Defensive", perf: "-0,50%", note: "Defensif mais sous pression du petrole", positive: false },
    { sector: "Healthcare", perf: "-0,90%", note: "Rotation hors defensifs vers energy", positive: false },
    { sector: "Financial Services", perf: "-1,20%", note: "Taux eleves mais credit se tend", positive: false },
    { sector: "Technology", perf: "-2,30%", note: "Correction continue — Nasdaq -10,27% depuis pic", positive: false },
    { sector: "Consumer Cyclical", perf: "-3,50%", note: "-12% MTD — consommateur sous pression", positive: false },
    { sector: "Industrials", perf: "-1,50%", note: "Ralentissement du commerce mondial", positive: false },
    { sector: "Real Estate", perf: "-2,80%", note: "Taux longs a 4,44% — immobilier sous pression", positive: false },
    { sector: "Communication Services", perf: "-3,10%", note: "Pub en ligne en baisse", positive: false },
    { sector: "Basic Materials", perf: "-2,00%", note: "Cuivre en baisse, or volatile", positive: false },
  ],
  sectorsLecture: "La rotation sectorielle est la plus rapide depuis 2022. Energy (+3,5%) et Defense (+2,8%) sont les seuls gagnants. Consumer Cyclical (-3,5%) est le pire secteur — le petrole cher comprime le pouvoir d'achat. La Tech (-2,3%) continue de corriger apres +40% en 2024 et +34% en 2025.",
  techSemis: {
    overview: "Le secteur Tech/Semis est en correction. Le Nasdaq perd 10,27% depuis son pic. NVIDIA -14% YTD malgre une demande IA intacte.",
    highlights: [
      { title: "NVIDIA en correction", description: "-14% YTD — la demande IA reste explosive (Micron l'a confirme S13) mais le multiple se comprime dans un environnement de taux eleves." },
      { title: "Microsoft pire performer Mag 7", description: "-23% YTD — les investissements massifs dans l'IA ($80B+ annonces) pesent sur les marges. Le marche doute du retour sur investissement a court terme." },
      { title: "Broadcom resilient", description: "Broadcom resiste mieux que les autres semis grace a sa diversification (VMware) et son exposition IA." },
    ],
    lectureWMB: "Le secteur Tech/Semis subit un repricing des multiples, pas une deterioration des fondamentaux. La demande IA reste explosive — Micron l'a prouve la semaine precedente avec un EPS de $12,20. Le probleme est le petrole >$100 qui pousse les taux a la hausse (10Y 4,44%), ce qui comprime mecaniquement les multiples de croissance. C'est un choc exogene, pas endogene.",
  },
  softwareCloud: {
    overview: "Le software/cloud souffre de la compression des multiples. Les valorisations elevees de 2024-2025 se normalisent.",
    highlights: [
      { title: "Microsoft Azure", description: "Azure continue de croitre mais le marche se concentre sur les marges — les investissements IA pesent." },
      { title: "Salesforce et ServiceNow", description: "Les entreprises SaaS mid-cap resistent mieux que les mega-caps grace a des valorisations plus raisonnables." },
    ],
    lectureWMB: "Le software/cloud est en phase de normalisation des multiples. Apres des annees de croissance a tout prix, le marche exige desormais de la rentabilite. Les entreprises avec des marges elevees et un free cash flow solide resistent mieux.",
  },
  healthcare: {
    overview: "Le Healthcare recule de 0,9% — defensif mais pas immunise. La rotation vers l'energie detourne les flux.",
    highlights: [
      { title: "Pharma resiliente", description: "Les grandes pharma (JNJ, PFE, LLY) resistent mieux que le marche grace a leurs dividendes et leur caractere defensif." },
      { title: "Biotech sous pression", description: "Les biotechs a forte croissance souffrent de la hausse des taux — les valorisations DCF se compriment." },
    ],
    lectureWMB: "Le Healthcare est un secteur defensif qui resiste mieux que la tech mais qui ne surperforme pas dans cet environnement. La rotation vers l'energie detourne les flux. Les grandes pharma avec dividendes sont les plus resilientes.",
  },
  financials: {
    overview: "Les Financial Services reculent de 1,2%. Les taux eleves soutiennent les marges mais le credit se tend.",
    highlights: [
      { title: "Banques : taux eleves = marges", description: "Les grandes banques (JPM, GS, MS) beneficient des taux eleves mais les spreads HY a 440 bps sont un signal d'alerte." },
      { title: "Assurance en hausse", description: "Les assureurs beneficient des taux eleves pour leurs portefeuilles d'investissement." },
    ],
    lectureWMB: "Les financials sont en position ambigue. Les taux eleves soutiennent les marges d'interet mais le credit se tend (HY a 440 bps). Si le petrole reste >$100, les defauts dans le transport et les airlines pourraient augmenter.",
  },
  cyclicals: {
    overview: "Les cycliques sont les plus penalises. Consumer Discretionary -12% MTD. Le petrole cher comprime le pouvoir d'achat.",
    highlights: [
      { title: "Nike mardi — test du consommateur", description: "Nike est le test direct du consommateur americain. Si Nike guide a la baisse, c'est un signal de recession consommateur." },
      { title: "Auto sous pression", description: "Les constructeurs auto souffrent du petrole cher — couts de production en hausse, demande en baisse." },
    ],
    lectureWMB: "Les cycliques sont le secteur le plus expose au petrole cher. Le consommateur americain est sous pression maximale — essence a $3,96/gallon, consumer sentiment a 53,3. Nike mardi sera le verdict.",
  },
  consumption: {
    overview: "La consommation est sous pression maximale. Consumer sentiment a 53,3, anticipations d'inflation a 3,8%.",
    highlights: [
      { title: "Essence a $3,96/gallon", description: "+32% en 2 semaines. Le petrole cher est une taxe directe sur le consommateur americain." },
      { title: "Retail sous pression", description: "Les retailers discretionnaires souffrent — les consommateurs reduisent les depenses non essentielles." },
    ],
    lectureWMB: "La consommation est le maillon faible de l'economie US. Le petrole >$100 est une taxe directe — chaque hausse de $10 du petrole reduit le pouvoir d'achat de ~$100B/an. Le consumer sentiment a 53,3 est au plus bas de 2026.",
  },
  earningsWinners: [
    { rank: 1, ticker: "RTX", company: "RTX Corp", detail: "+22% MTD — beneficiaire direct du conflit Iran, contrats defense en hausse, +5,2% cette semaine" },
  ],
  earningsWinnersLecture: "Pas de gros earnings cette semaine. RTX est le gagnant par momentum — +22% sur le mois grace au conflit Iran et aux commandes de defense en hausse.",
  earningsLosers: [
    { rank: 1, ticker: "MSFT", company: "Microsoft", detail: "-23% YTD — pire performer Mag 7, investissements IA massifs pesent sur les marges, -3,5% cette semaine" },
  ],
  earningsLosersLecture: "Microsoft est le grand perdant par momentum — -23% YTD, pire performer des Mag 7. Les investissements massifs dans l'IA ($80B+) pesent sur les marges dans un contexte ou le marche exige de la rentabilite.",
  guidanceThemes: [
    { title: "Petrole et couts — Negatif", description: "Le petrole >$100 augmente les couts de transport et d'energie pour Airlines, Transport, Retail. Les guidances a la baisse se multiplient." },
    { title: "Defense et securite — Positif", description: "RTX, LMT, NOC : les budgets militaires augmentent mondialement. Les carnets de commandes sont pleins." },
  ],
  guidanceLecture: "Le theme dominant des guidances est le petrole. Les entreprises exposees aux couts de transport et d'energie guident a la baisse. A l'inverse, la defense guide a la hausse avec des carnets de commandes records.",
  analystMoves: [
    { title: "META — Upgrade CNBC", description: "CNBC identifie Meta comme l'une des actions les plus survendues du S&P 500 — signal contrarian" },
    { title: "XOM — Upgrade Goldman Sachs ($130+)", description: "Goldman releve son objectif sur Exxon — petrole >$100 = marges record" },
  ],
  analystLecture: "Les analystes commencent a identifier des opportunites contrarian. Meta est signalee comme survendue par CNBC. Goldman releve Exxon sur le petrole cher. Le marche est divise entre ceux qui voient une opportunite d'achat et ceux qui anticipent une poursuite du sell-off.",
  corporateActions: [
    { title: "Exxon Mobil — Dividende", description: "Exxon maintient son dividende eleve — le petrole >$100 genere un free cash flow record." },
    { title: "Apple — Buyback", description: "Apple continue ses rachats d'actions malgre la correction — signal de confiance du management." },
  ],
  corporateLecture: "Les corporate actions montrent une divergence. Les petroliers generent du cash record et maintiennent leurs dividendes. Les tech continuent les buybacks — un signal que les managements croient en leurs fondamentaux malgre la correction.",
  regulation: [
    { title: "Gas Tax Holiday", description: "Des parlementaires proposent une suspension de la taxe federale sur l'essence pour soulager le consommateur. Impact potentiel sur les revenus federaux." },
    { title: "Tarifs Chine", description: "Les tarifs sur les exportations tech chinoises restent en place. Impact direct sur Apple et NVIDIA." },
  ],
  regulationLecture: "La regulation est un facteur de plus en plus important. La proposition de gas tax holiday est un signal de panique politique face au petrole cher. Les tarifs Chine restent un frein structurel pour la tech US.",
  emergingThemes: [
    { number: 1, title: "Defense comme secteur de croissance", facts: "RTX +22%, LMT +19%, NOC +17% MTD. Conflit Iran = hausse des budgets militaires mondiaux.", hypothesis: "Si le conflit persiste, la defense devient un secteur de croissance structurel.", counterSignal: "Desescalade Iran = correction rapide de 10-15% sur les defense contractors." },
    { number: 2, title: "Repricing des multiples tech", facts: "Nasdaq -10,27% depuis pic. Mag 7 -$850B en une semaine. Demande IA intacte (Micron confirme).", hypothesis: "Le marche vend les multiples, pas les fondamentaux — normalisation apres 2 ans de +40%/an.", counterSignal: "Si petrole retombe sous $90, rotation retour massive vers la tech." },
  ],
  emergingThemesLecture: "Deux themes emergent : la defense comme nouveau secteur de croissance (un changement structurel si le conflit persiste) et le repricing des multiples tech (une normalisation apres 2 ans de hausse de 40%+/an).",
  radarStocks: [
    { rank: 1, ticker: "META", company: "Meta Platforms", activity: "Survendue — CNBC identifie Meta parmi les plus survendues du S&P 500", catalyst: "Potentiel de rebond technique si VIX retombe sous 25", risks: "VIX >30 rend les rebonds fragiles" },
    { rank: 2, ticker: "NVDA", company: "NVIDIA", activity: "Correction — -14% YTD malgre demande IA intacte", catalyst: "Micron confirme la demande IA, multiple en compression = opportunite potentielle", risks: "Correction tech peut se prolonger si petrole >$100" },
    { rank: 3, ticker: "XOM", company: "Exxon Mobil", activity: "Momentum — petrole >$100, Goldman upgrade", catalyst: "Marges record, dividende solide, continuation si petrole reste eleve", risks: "Desescalade Iran = correction de 10-15%" },
  ],
  radarLecture: "Trois actions sur le radar : Meta (survendue, rebond potentiel), NVIDIA (fondamentaux solides, multiple en compression), Exxon (petrole >$100, Goldman upgrade). ATTENTION : ce ne sont PAS des recommandations — ce sont des situations a surveiller avec des scenarios SI/ALORS/SINON.",
  influentialVoices: [
    { name: "CNBC", role: "Analyse", idea: "Meta est parmi les actions les plus survendues du S&P 500 apres une nouvelle semaine de pertes.", whyFollowed: "Reference pour l'analyse technique et les signaux contrarian" },
    { name: "SeekingAlpha", role: "Strategie", idea: "Le Nasdaq en correction officielle — historiquement, les corrections de 10% sont suivies d'un rebond de 15% dans les 6 mois.", whyFollowed: "Donnees historiques et statistiques de marche" },
    { name: "Goldman Sachs", role: "Macro", idea: "Le petrole au-dessus de $100 ajoute 0,5% a l'inflation US et reduit la croissance du PIB de 0,3%.", whyFollowed: "Quantification de l'impact macro du petrole" },
  ],
  voicesLecture: "Les voix influentes sont divisees. CNBC identifie des opportunites contrarian (Meta survendue). SeekingAlpha rappelle les statistiques historiques (rebond apres correction). Goldman quantifie l'impact du petrole (+0,5% inflation, -0,3% PIB). Le consensus : c'est un moment de prudence, pas de panique.",
  watchlist: [
    { ticker: "META", angle: "Survendue — signal contrarian", watchFor: "SI VIX retombe sous 25 ET pub en ligne resiliente → rebond de 10-15%. SINON, poursuite de la baisse vers -15% YTD. Invalidation : VIX >35 ou miss earnings Q1" },
    { ticker: "NVDA", angle: "Correction — fondamentaux vs multiple", watchFor: "SI demande IA confirmee par earnings Q1 ET petrole retombe sous $95 → rebond vers ATH. SINON, consolidation prolongee. Invalidation : demande IA en baisse ou tarifs Chine renforces" },
    { ticker: "XOM", angle: "Momentum petrole", watchFor: "SI petrole reste >$100 → continuation vers ATH. SI desescalade Iran → correction de 10-15%. Invalidation : petrole sous $85" },
  ],
  watchlistLecture: "La watchlist S14 se concentre sur 3 situations : Meta (contrarian play sur la survente), NVIDIA (fondamentaux vs multiple), Exxon (momentum petrole). Chaque situation est presentee avec des scenarios conditionnels — PAS des recommandations. L'investisseur doit definir ses propres seuils d'entree et de sortie.",
  calendar: [
    { day: "Lundi", date: "30/03", events: ["14:30 UTC — Fed Chair Powell Speech (reaction au petrole et inflation)"] },
    { day: "Mardi", date: "31/03", events: ["After-hours — Nike (NKE) Earnings (test du consommateur americain)"] },
    { day: "Mercredi", date: "01/04", events: ["10:00 ET — ISM Manufacturing PMI (sous 50 = contraction)"] },
    { day: "Vendredi", date: "03/04", events: ["08:30 ET — Nonfarm Payrolls NFP (le chiffre le plus important du mois)"] },
  ],
  calendarLecture: "Quatre catalyseurs majeurs en 5 jours. Powell lundi donne le ton. Nike mardi teste le consommateur. ISM mercredi mesure l'industrie. NFP vendredi tranche le debat stagflation. C'est une semaine decisive.",
  earningsToWatch: [
    { day: "Mardi", date: "31/03", timing: "After", ticker: "NKE", company: "Nike", watchFor: "Test du consommateur americain — impact du petrole cher sur les depenses discretionnaires. Consensus ~$0,75 EPS.", highlight: true },
  ],
  earningsToWatchLecture: "Nike est le seul earnings majeur de la semaine mais c'est un test crucial. Le secteur Consumer Discretionary est a -12% MTD. Si Nike guide a la baisse, c'est un signal que le consommateur craque.",
  scenarios: [
    { name: "Constructif", probability: "10%", triggers: "Desescalade Iran, petrole sous $90, Powell dovish, NFP fort — rallye de soulagement de 5-8%", signals: "VIX sous 22, petrole sous 90$" },
    { name: "Base", probability: "45%", triggers: "Statu quo geopolitique, petrole $95-110, consolidation, NFP en ligne — Range S&P 5 400-5 700", signals: "VIX 25-32, petrole 95-110$" },
    { name: "Negatif", probability: "45%", triggers: "Escalade Iran, petrole >$120, Powell hawkish, NFP faible — S&P sous 5 200, Nasdaq -15%", signals: "VIX >35, petrole >120$" },
  ],
  risks: [
    { title: "Mag 7 concentration = Risque systemique", description: "Les Mag 7 representent 30-35% du S&P 500. Si le sell-off continue, les ETF passifs amplifient la baisse mecaniquement." },
    { title: "Nike miss = Signal de recession consommateur", description: "Un miss de Nike mardi confirmerait que le consommateur americain craque sous le petrole cher." },
    { title: "Powell hawkish = Sell-off amplifie", description: "Si Powell signale lundi que l'inflation est la priorite, le marche pourrait interpreter ca comme 'pas de Fed put'." },
    { title: "NFP faible = Stagflation confirmee", description: "Un NFP sous 150K vendredi confirmerait le ralentissement du marche du travail dans un contexte d'inflation elevee." },
  ],
  scenarioDisclaimer: "Ces scenarios sont des outils de reflexion, pas des predictions. Les probabilites sont subjectives et basees sur les donnees disponibles au 28 mars 2026.",
  conclusion: "La semaine 14 confirme un changement de regime pour les actions US. Le Nasdaq en correction, les Mag 7 a -$850B, la rotation vers Energy/Defense — tout pointe vers un repricing structurel. La semaine prochaine sera decisive : Powell, Nike, ISM, NFP. Quatre catalyseurs en 5 jours qui determineront si le marche stabilise ou accelere a la baisse.",
  conclusionLecture: "Le message cle : le marche vend les multiples, pas les fondamentaux. La demande IA reste intacte, les bilans sont solides, le systeme bancaire est sain. C'est un choc exogene (petrole/Iran), pas endogene (credit/immobilier). Mais tant que le petrole reste >$100 et le VIX >30, les rebonds seront fragiles et de courte duree. La patience est la meilleure strategie dans cet environnement.",
  sources: "Donnees de marche : CNBC, MarketWatch, SeekingAlpha, MLQ.ai, AIMS FX, cloture vendredi 27 mars 2026. Secteurs : Morningstar, S&P Global. Mag 7 : CNBC, SeekingAlpha. Defense : RTX, LMT, NOC reports.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
};
