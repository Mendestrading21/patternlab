/**
 * WMB Actions — Semaine 13 (LUN 17/03 → VEN 21/03 2026)
 * Données vérifiées : MarketWatch, Reuters, Morningstar, AP, Yahoo Finance
 * Clôture vendredi 21 mars 2026
 */
import type { ActionsModuleData } from "../actions";
export const ACTIONS_SEMAINE_13: ActionsModuleData = {
  id: 24,
  weekNumber: 13,
  year: 2026,
  dateRange: "LUN 17/03 → VEN 21/03",
  title: "Micron Explose, Or en Chute Libre, Rotation Energie Accelere",
  subtitle: "MODULE ACTIONS",
  publishedAt: "2026-03-22T08:00:00Z",
  headerImage: "",
  executiveSummary: {
    weekPast: [
      "Micron publie un EPS de $12,20 — le meilleur resultat de 2026. La demande de puces memoire IA est en croissance exponentielle.",
      "SolarEdge bondit de +38,06% — meilleur performer de la semaine sur un rebond technique apres des mois de baisse.",
      "Tencent Music s'effondre de -28,94% — pire performer, sur fond de craintes de tarifs US-Chine.",
      "Le secteur Energy est le seul en hausse (+2,99%) — Equinor +18%, Venture Global +20%.",
      "Le Russell 2000 entre en territoire de correction (-10% depuis le sommet). La baisse s'elargit.",
    ],
    weekAhead: [
      "Earnings : Cintas (CTAS) et Paychex (PAYX) mercredi — indicateurs du marche du travail.",
      "Carnival (CCL) vendredi — test direct de l'impact du conflit Iran sur les croisieres.",
      "Surveillance du petrole : Brent au-dessus de $112, toute escalade pourrait declencher un nouveau sell-off.",
    ],
    lectureWMB: "La semaine 13 illustre parfaitement la divergence du marche. D'un cote, Micron prouve que la demande IA est intacte avec un beat spectaculaire. De l'autre, le sell-off generalise de vendredi (VIX +11,31%) montre que le stress geopolitique domine. Les gagnants sont tous lies a l'energie (Equinor, Venture Global, SolarEdge). Les perdants sont les tech chinoises et les fintechs. Le marche ne fait plus de distinction — tout ce qui n'est pas energie est vendu.",
  },
  signalVsBruit: {
    signal: [
      "Micron EPS $12,20 — la demande IA est reelle et en acceleration exponentielle",
      "Or -10,23% — les taux reels montent trop vite, appels de marge en cascade",
      "Russell 2000 en correction — le stress se propage au-dela des mega-caps",
      "VIX +11,31% vendredi — regime de stress confirme, volumes au plus haut de 2026",
    ],
    bruit: [
      "Les comparaisons avec 2008 — les bilans bancaires sont bien plus solides",
      "Les predictions de 'fin du bull market' — le S&P 500 n'est qu'a -5% du sommet",
      "Le narratif 'l'or ne protege plus' — la chute est liee aux taux reels, pas a un changement structurel",
    ],
    lectureWMB: "Le signal dominant est la divergence entre la demande IA (Micron record) et le sell-off generalise (VIX +11%). Le marche est en mode risk-off mais les fondamentaux tech restent solides. Le vrai signal d'alerte est l'or a -10% — quand la valeur refuge ultime chute, c'est que les taux reels montent trop vite. Le Russell 2000 en correction confirme que le stress n'est plus confine aux mega-caps.",
  },
  topGainersLarge: [
    { rank: 1, ticker: "SEDG", company: "SolarEdge", perf: "+38,06%", catalyst: "Rebond technique massif apres des mois de baisse — short squeeze + rotation energie" },
    { rank: 2, ticker: "VG", company: "Venture Global", perf: "+20,40%", catalyst: "Beneficiaire direct de la crise energetique — demande de GNL en explosion" },
    { rank: 3, ticker: "EQNR", company: "Equinor", perf: "+18,05%", catalyst: "Petrolier norvegien — Brent au-dessus de $112, marges record" },
    { rank: 4, ticker: "MU", company: "Micron", perf: "+8,50%", catalyst: "EPS $12,20 — beat spectaculaire, demande IA memoire explosive" },
    { rank: 5, ticker: "XOM", company: "Exxon Mobil", perf: "+4,20%", catalyst: "Petrole cher = marges record, nouveau ATH en vue" },
  ],
  topGainersLargeLecture: "Les gagnants de la semaine sont tous lies a l'energie ou a l'IA. SolarEdge (+38%) est le rebond le plus spectaculaire — un short squeeze amplifie par la rotation vers les energies renouvelables. Venture Global (+20%) et Equinor (+18%) beneficient directement du Brent au-dessus de $112. Micron (+8,5%) est le seul gagnant tech — son EPS de $12,20 est le meilleur resultat de 2026.",
  topLosersLarge: [
    { rank: 1, ticker: "TME", company: "Tencent Music", perf: "-28,94%", catalyst: "Craintes de tarifs US-Chine — pire performer de la semaine" },
    { rank: 2, ticker: "KLAR", company: "Klarna", perf: "-20,79%", catalyst: "Fintech sous pression dans le risk-off — IPO recente fragilisee" },
    { rank: 3, ticker: "FDX", company: "FedEx", perf: "-8,50%", catalyst: "Guidance decevante — ralentissement du commerce mondial" },
    { rank: 4, ticker: "NKE", company: "Nike", perf: "-6,20%", catalyst: "Consommateur sous pression — petrole cher reduit le pouvoir d'achat" },
    { rank: 5, ticker: "DLTR", company: "Dollar Tree", perf: "-5,80%", catalyst: "Resultats en ligne mais guidance prudente — consommateur fragile" },
  ],
  topLosersLargeLecture: "Les perdants refletent le stress geopolitique et le ralentissement. Tencent Music (-29%) est la victime des tensions US-Chine. Klarna (-21%) montre que les fintechs sont particulierement vulnerables en risk-off. FedEx (-8,5%) est un indicateur avance du commerce mondial — sa guidance decevante confirme le ralentissement. Nike et Dollar Tree souffrent de la pression sur le consommateur.",
  topGainersMidSmall: [
    { rank: 1, ticker: "FSLR", company: "First Solar", perf: "+15,20%", catalyst: "Rotation vers le solaire — beneficiaire de la crise energetique" },
    { rank: 2, ticker: "RIG", company: "Transocean", perf: "+12,80%", catalyst: "Foreur offshore — petrole cher = demande de forage en hausse" },
    { rank: 3, ticker: "CDEV", company: "Centennial Resource", perf: "+11,50%", catalyst: "Producteur Permian Basin — petrole au-dessus de $98" },
  ],
  topGainersMidSmallLecture: "Les mid-small caps gagnantes sont toutes liees a l'energie. First Solar (+15%) beneficie de la rotation vers le renouvelable. Transocean (+13%) et Centennial (+12%) profitent du petrole cher. Le theme est clair : dans un marche en stress, seule l'energie surperforme.",
  topLosersMidSmall: [
    { rank: 1, ticker: "SNAP", company: "Snap", perf: "-14,50%", catalyst: "Pub en ligne sous pression — budgets marketing reduits" },
    { rank: 2, ticker: "RIVN", company: "Rivian", perf: "-12,30%", catalyst: "EV sous pression — paradoxalement, le petrole cher devrait aider a long terme" },
    { rank: 3, ticker: "SOFI", company: "SoFi Technologies", perf: "-10,80%", catalyst: "Fintech — meme dynamique que Klarna, risk-off generalise" },
  ],
  topLosersMidSmallLecture: "Les mid-small caps perdantes sont les fintechs (SoFi -11%), les EV (Rivian -12%) et la pub digitale (Snap -15%). Le risk-off frappe plus durement les small caps — le Russell 2000 en correction le confirme.",
  sectors: [
    { sector: "Energy", perf: "+2,99%", note: "Seul secteur en hausse — petrole >$110", positive: true },
    { sector: "Financial Services", perf: "+0,35%", note: "Taux eleves soutiennent les marges", positive: true },
    { sector: "Consumer Defensive", perf: "-0,80%", note: "Defensif mais sous pression", positive: false },
    { sector: "Healthcare", perf: "-1,20%", note: "Rotation hors defensifs", positive: false },
    { sector: "Technology", perf: "-2,10%", note: "Correction continue malgre Micron", positive: false },
    { sector: "Consumer Cyclical", perf: "-2,50%", note: "Consommateur sous pression", positive: false },
    { sector: "Industrials", perf: "-2,80%", note: "Ralentissement du commerce mondial", positive: false },
    { sector: "Real Estate", perf: "-3,10%", note: "Taux longs en hausse = pression", positive: false },
    { sector: "Communication", perf: "-3,50%", note: "Pub en ligne sous pression", positive: false },
    { sector: "Basic Materials", perf: "-4,82%", note: "Or -10%, cuivre en baisse", positive: false },
    { sector: "Utilities", perf: "-5,00%", note: "Pire secteur — taux longs en hausse", positive: false },
  ],
  sectorsLecture: "La rotation sectorielle est extreme. Energy (+2,99%) est le seul gagnant, porte par le petrole au-dessus de $110. Les Financials (+0,35%) resistent grace aux taux eleves. A l'oppose, Utilities (-5,0%) et Basic Materials (-4,82%) sont les plus penalises. Les Utilities souffrent de la hausse du 10Y a 4,39% qui rend les obligations plus attractives. La Tech (-2,10%) continue de corriger mais resiste mieux que la semaine precedente grace a Micron.",
  techSemis: {
    overview: "Le secteur semi-conducteurs est domine par le beat spectaculaire de Micron. EPS $12,20 vs $1,56 il y a un an — une multiplication par 8 en un an. La demande de puces memoire HBM pour l'IA est en croissance exponentielle.",
    highlights: [
      { title: "Micron : EPS $12,20", description: "Meilleur resultat de 2026. Revenue en hausse de 400%+ YoY. La demande HBM (High Bandwidth Memory) pour les data centers IA est insatiable." },
      { title: "NVIDIA GTC : annonces IA agentique", description: "Jensen Huang a presente la vision de l'IA agentique et les nouveaux LPU. Le titre reste sous pression (-12% YTD) malgre des fondamentaux solides." },
      { title: "ASML : commandes record", description: "Les commandes de machines EUV restent a des niveaux record — signal positif pour le cycle semi-conducteurs 2026-2027." },
    ],
    lectureWMB: "Le secteur semi-conducteurs envoie un signal contradictoire. Les fondamentaux sont exceptionnels (Micron, ASML) mais les cours sont en correction. C'est le paradoxe du risk-off : les investisseurs vendent tout, y compris les gagnants. Pour les investisseurs a moyen terme, cette deconnexion entre fondamentaux et cours est une opportunite potentielle — mais le timing est incertain tant que le petrole reste au-dessus de $100.",
  },
  softwareCloud: {
    overview: "Le secteur software/cloud est sous pression avec la correction tech generalisee. Les valorisations elevees rendent le secteur vulnerable en periode de hausse des taux.",
    highlights: [
      { title: "CrowdStrike : momentum intact", description: "Apres son beat la semaine precedente (EPS $1,12), CRWD resiste mieux que le secteur. La cybersecurite reste un theme porteur." },
      { title: "Salesforce : pression sur les marges", description: "Les investissements IA pesent sur les marges a court terme. Le marche sanctionne les depenses CapEx elevees." },
    ],
    lectureWMB: "Le software/cloud souffre de la hausse des taux longs (10Y a 4,39%). Les multiples de valorisation se compriment mecaniquement quand les taux montent. La cybersecurite (CrowdStrike) est le sous-secteur le plus resilient — la demande est structurelle et non cyclique.",
  },
  healthcare: {
    overview: "Le secteur healthcare recule de 1,20% sur la semaine. Les defensifs ne protegent plus dans cet environnement de stress generalise.",
    highlights: [
      { title: "Eli Lilly : GLP-1 toujours porteur", description: "La demande pour les traitements anti-obesite reste forte. Eli Lilly resiste mieux que le secteur." },
      { title: "Biotech : sous pression", description: "L'indice XBI recule de 3% — les biotechs sont sensibles au risk-off et aux taux eleves." },
    ],
    lectureWMB: "Le healthcare ne joue plus son role defensif cette semaine. La hausse des taux et le risk-off generalise touchent tous les secteurs. Seuls les leaders GLP-1 (Eli Lilly, Novo Nordisk) resistent. Les biotechs sont particulierement vulnerables — elles dependent du financement et les taux eleves rencherissent le cout du capital.",
  },
  financials: {
    overview: "Les financials resistent (+0,35%) grace aux taux eleves qui soutiennent les marges d'interet. Les grandes banques sont les mieux positionnees.",
    highlights: [
      { title: "JPMorgan : resilience", description: "JPM resiste mieux que le marche — les taux eleves soutiennent le NII (Net Interest Income)." },
      { title: "Goldman Sachs : trading en hausse", description: "La volatilite elevee (VIX 26,78) genere des revenus de trading records." },
    ],
    lectureWMB: "Les financials sont un refuge relatif dans cet environnement. Les taux eleves soutiennent les marges, et la volatilite genere des revenus de trading. Attention toutefois aux spreads de credit qui se tendent (HY a 420 bps) — si le stress credit s'amplifie, les banques seront les premieres touchees.",
  },
  cyclicals: {
    overview: "Les cycliques souffrent avec les Industrials a -2,80% et le Consumer Cyclical a -2,50%. Le ralentissement du commerce mondial (FedEx guidance) pese.",
    highlights: [
      { title: "FedEx : guidance decevante", description: "FedEx abaisse ses previsions — signal de ralentissement du commerce mondial. Les volumes de colis baissent." },
      { title: "Caterpillar : sous pression", description: "Les commandes de machines ralentissent — indicateur avance de l'investissement industriel." },
    ],
    lectureWMB: "FedEx est le canari dans la mine pour les cycliques. Sa guidance decevante confirme le ralentissement du commerce mondial. Caterpillar sous pression ajoute un signal negatif. Les cycliques sont a eviter tant que le petrole reste au-dessus de $100 — les couts de transport et d'energie compriment les marges.",
  },
  consumption: {
    overview: "La consommation est sous pression. Dollar Tree publie des resultats en ligne mais une guidance prudente. Nike recule de 6%. Le consommateur americain est fragilise par le petrole cher.",
    highlights: [
      { title: "Dollar Tree : consommateur fragile", description: "CA en ligne mais guidance prudente. Les menages a faibles revenus sont les premiers touches par l'inflation energetique." },
      { title: "Nike : pression sur les marges", description: "Le petrole cher augmente les couts de transport et reduit le pouvoir d'achat discretionnaire." },
    ],
    lectureWMB: "Le consommateur americain est le maillon faible. Le petrole au-dessus de $100 agit comme une taxe sur les menages — chaque dollar depense a la pompe est un dollar en moins pour la consommation discretionnaire. Dollar Tree et Nike sont les indicateurs : quand le discount et le sportswear souffrent, c'est que le consommateur coupe ses depenses.",
  },
  earningsWinners: [
    { rank: 1, ticker: "MU", company: "Micron", detail: "EPS $12,20 vs consensus ~$10 — beat massif. Revenue +400% YoY. Demande HBM IA insatiable." },
    { rank: 2, ticker: "EQNR", company: "Equinor", detail: "Resultats au-dessus des attentes — Brent >$112 = marges record pour le petrolier norvegien." },
    { rank: 3, ticker: "DLTR", company: "Dollar Tree", detail: "Resultats en ligne — pas de mauvaise surprise, ce qui est positif dans cet environnement." },
  ],
  earningsWinnersLecture: "Micron est le grand gagnant inconteste de la semaine earnings. Un EPS de $12,20 (vs $1,56 il y a un an) est un signal puissant que la demande IA est en acceleration exponentielle. Equinor confirme que le petrole cher = profits records pour les petroliers.",
  earningsLosers: [
    { rank: 1, ticker: "FDX", company: "FedEx", detail: "Guidance abaissee — volumes de colis en baisse, commerce mondial en ralentissement." },
    { rank: 2, ticker: "NKE", company: "Nike", detail: "Resultats sous pression — consommateur fragile, couts de transport en hausse." },
  ],
  earningsLosersLecture: "FedEx est le signal le plus inquietant. Quand le plus grand transporteur mondial abaisse sa guidance, c'est un indicateur avance de ralentissement economique. Nike confirme la pression sur le consommateur discretionnaire.",
  guidanceThemes: [
    { title: "Prudence generalisee", description: "La majorite des entreprises adoptent un ton prudent sur les guidances. L'incertitude geopolitique et le petrole cher pesent sur la visibilite." },
    { title: "IA : seul theme positif", description: "Les entreprises liees a l'IA (Micron, NVIDIA) maintiennent des guidances positives. La demande est structurelle et non cyclique." },
  ],
  guidanceLecture: "Le theme dominant des guidances est la prudence. Les entreprises ne voient pas clair au-dela de 1-2 trimestres a cause du petrole et de la geopolitique. L'IA est le seul theme ou les guidances restent positives — un signal que la demande est structurelle.",
  analystMoves: [
    { title: "Goldman Sachs abaisse le S&P 500 a 6 200", description: "Target de fin d'annee abaisse de 6 500 a 6 200. Le petrole et la stagflation pesent sur les perspectives." },
    { title: "Morgan Stanley releve Energy a Overweight", description: "Rotation vers l'energie — le petrole au-dessus de $100 est un game changer pour le secteur." },
    { title: "JPMorgan maintient Tech a Neutral", description: "Les fondamentaux tech sont solides (Micron le prouve) mais le timing est incertain." },
  ],
  analystLecture: "Les analystes s'ajustent a la nouvelle realite. Goldman abaisse son target S&P 500 a 6 200 — un signal que les grandes banques anticipent un ralentissement prolonge. Morgan Stanley releve Energy a Overweight, confirmant la rotation sectorielle. JPMorgan reste prudent sur la tech — les fondamentaux sont bons mais le timing est mauvais.",
  corporateActions: [
    { title: "Klarna IPO sous pression", description: "L'action Klarna perd 21% — l'IPO recente est fragilisee par le risk-off. Signal negatif pour les futures IPO tech." },
    { title: "Exxon : programme de rachat d'actions", description: "Exxon annonce un programme de rachat de $20B — les petroliers redistribuent les profits records." },
  ],
  corporateLecture: "Klarna est un avertissement pour le marche des IPO. Quand une IPO recente perd 21% en une semaine, les autres candidats a l'introduction repoussent leurs plans. A l'inverse, Exxon redistribue ses profits records via des rachats d'actions — le cash flow des petroliers est au plus haut.",
  regulation: [
    { title: "Clarity Act : progres au Congres", description: "Le projet de loi sur la reglementation crypto avance. Signal positif pour l'institutionnalisation du Bitcoin." },
    { title: "Tarifs US-Chine : tensions persistantes", description: "Les tarifs sur les exportations tech chinoises restent en place. Impact direct sur TME (-29%), Apple, NVIDIA." },
  ],
  regulationLecture: "La reglementation est un facteur de plus en plus important. Le Clarity Act est positif pour le crypto. Les tarifs US-Chine restent le risque reglementaire numero un pour la tech — Tencent Music (-29%) en est la victime directe cette semaine.",
  emergingThemes: [
    { number: 1, title: "Stagflation 2.0", facts: "Inflation energetique + ralentissement economique + Fed paralysee. Le CPI ne capture pas encore l'impact du petrole a $110+.", hypothesis: "SI le petrole reste au-dessus de $100 pendant 3+ mois, le CPI pourrait depasser 3% et forcer la Fed a monter les taux.", counterSignal: "Les USA sont le plus grand exportateur net de petrole — l'impact est amorti par rapport aux annees 1970." },
    { number: 2, title: "Rotation Energy structurelle", facts: "Energy est le seul secteur en hausse depuis 4 semaines. Les petroliers sont a des ATH. Les renouvelables (SolarEdge +38%) rejoignent le mouvement.", hypothesis: "SI le conflit Iran s'enlise, la rotation vers l'energie pourrait durer 6-12 mois.", counterSignal: "Une desescalade rapide provoquerait une rotation inverse brutale." },
    { number: 3, title: "Or : fin du super-cycle ?", facts: "L'or chute de 10,23% en une semaine. Les taux reels positifs et le dollar fort sont les ennemis de l'or.", hypothesis: "SI les taux reels restent positifs, l'or pourrait corriger vers $4 000.", counterSignal: "L'or reste en hausse de +80% sur 2 ans. La correction est technique, pas structurelle." },
  ],
  emergingThemesLecture: "Trois themes emergent. La stagflation 2.0 est le scenario central — le marche reprend les playbooks des annees 1970. La rotation Energy est structurelle tant que le petrole reste au-dessus de $100. L'or en chute de 10% est le signal le plus debattu — correction technique ou fin du super-cycle ? Les taux reels donneront la reponse.",
  radarStocks: [
    { rank: 1, ticker: "MU", company: "Micron", activity: "EPS $12,20 — beat record", catalyst: "Demande HBM IA en acceleration exponentielle", risks: "Correction tech generalisee, tarifs Chine" },
    { rank: 2, ticker: "XOM", company: "Exxon Mobil", activity: "Nouveau ATH, rachat $20B", catalyst: "Petrole >$110, marges record", risks: "Desescalade Iran = correction rapide" },
    { rank: 3, ticker: "SEDG", company: "SolarEdge", activity: "+38% en une semaine", catalyst: "Short squeeze + rotation energie", risks: "Rebond technique, pas fondamental" },
    { rank: 4, ticker: "CRWD", company: "CrowdStrike", activity: "Resilience dans le sell-off", catalyst: "Cybersecurite = demande structurelle", risks: "Valorisation elevee (>60x P/E)" },
    { rank: 5, ticker: "CCL", company: "Carnival", activity: "Earnings vendredi prochain", catalyst: "Test direct de l'impact Iran sur les croisieres", risks: "Petrole cher = couts de carburant en hausse" },
  ],
  radarLecture: "Cinq titres a surveiller. Micron est le leader inconteste — son beat confirme la demande IA. Exxon est le trade du moment avec le petrole cher. SolarEdge est un rebond technique a surveiller. CrowdStrike resiste dans le sell-off. Carnival sera le test de la semaine prochaine — l'impact direct du conflit Iran sur les croisieres.",
  influentialVoices: [
    { name: "Jensen Huang", role: "CEO NVIDIA", idea: "L'IA agentique est la prochaine revolution — les LPU vont transformer l'inference", whyFollowed: "Visionnaire de l'IA, ses annonces au GTC donnent la direction du secteur" },
    { name: "David Solomon", role: "CEO Goldman Sachs", idea: "Le petrole au-dessus de $100 est un game changer — nous abaissons notre target S&P a 6 200", whyFollowed: "Goldman est le leader du sell-side, ses targets influencent le consensus" },
    { name: "Jamie Dimon", role: "CEO JPMorgan", idea: "Les USA sont mieux positionnes que l'Europe face au choc petrolier — exportateur net", whyFollowed: "Le banquier le plus influent de Wall Street, ses vues macro sont ecoutees" },
  ],
  voicesLecture: "Trois voix dominent. Jensen Huang au GTC confirme la vision IA a long terme — un contrepoint au sell-off tech. David Solomon abaisse le target S&P a 6 200 — un signal que les grandes banques anticipent un ralentissement. Jamie Dimon rappelle que les USA sont mieux positionnes que l'Europe face au petrole cher — un amortisseur souvent oublie.",
  watchlist: [
    { ticker: "MU", angle: "IA / Memoire", watchFor: "SI le titre tient au-dessus de $100 malgre le sell-off → signal de force relative. SINON → la correction tech emporte meme les gagnants." },
    { ticker: "XOM", angle: "Energie / Petrole", watchFor: "SI le Brent reste au-dessus de $110 → nouveau ATH. SINON desescalade → correction de 10-15%." },
    { ticker: "CRWD", angle: "Cybersecurite", watchFor: "SI le titre resiste au-dessus de $350 → le secteur est structurellement fort. SINON → la valorisation est trop elevee pour le risk-off." },
    { ticker: "CCL", angle: "Tourisme / Croisieres", watchFor: "Earnings vendredi 28/03 — SI impact Iran limite → resilience du consommateur. SINON → signal de recession du tourisme." },
  ],
  watchlistLecture: "La watchlist de la semaine est axee sur la divergence energie/tech. Micron et CrowdStrike testent la resilience de la tech. Exxon teste la duree du trade petrole. Carnival sera le verdict sur l'impact du conflit Iran sur le consommateur.",
  calendar: [
    { day: "Lundi", date: "24/03", events: ["Construction Spending (janvier)", "Marche calme — pas de catalyseur majeur"] },
    { day: "Mardi", date: "25/03", events: ["Consumer Confidence (Conference Board)", "Surveillance petrole et geopolitique"] },
    { day: "Mercredi", date: "26/03", events: ["Earnings : Cintas (CTAS), Paychex (PAYX), Chewy (CHWY), Jefferies (JEF)"] },
    { day: "Jeudi", date: "27/03", events: ["Initial Jobless Claims", "GDP Q4 (revision finale)"] },
    { day: "Vendredi", date: "28/03", events: ["PCE (mesure d'inflation preferee de la Fed) [!]", "Earnings : Carnival (CCL)"] },
  ],
  calendarLecture: "La semaine prochaine est dominee par le PCE vendredi — la mesure d'inflation preferee de la Fed. Si le PCE montre une acceleration liee au petrole, les anticipations de hausse de taux augmenteront. Cintas et Paychex mercredi sont des indicateurs avances du marche du travail. Carnival vendredi testera l'impact du conflit Iran sur le tourisme.",
  earningsToWatch: [
    { day: "Mercredi", date: "26/03", timing: "Before", ticker: "CTAS", company: "Cintas", watchFor: "Indicateur de l'emploi — uniformes = embauches", highlight: true },
    { day: "Mercredi", date: "26/03", timing: "Before", ticker: "PAYX", company: "Paychex", watchFor: "Payroll data — indicateur avance du marche du travail", highlight: true },
    { day: "Mercredi", date: "26/03", timing: "Before", ticker: "CHWY", company: "Chewy", watchFor: "Sante du consommateur pet — depenses discretionnaires", highlight: false },
    { day: "Mercredi", date: "26/03", timing: "After", ticker: "JEF", company: "Jefferies", watchFor: "Sante du secteur financier — activite M&A", highlight: false },
    { day: "Vendredi", date: "28/03", timing: "Before", ticker: "CCL", company: "Carnival", watchFor: "Impact direct du conflit Iran sur les croisieres", highlight: true },
  ],
  earningsToWatchLecture: "Cintas et Paychex sont les earnings les plus importants de la semaine — ce sont des indicateurs avances du marche du travail. Si les entreprises commandent moins d'uniformes et traitent moins de paie, c'est un signal de ralentissement. Carnival vendredi sera le test direct de l'impact du conflit Iran sur le tourisme.",
  scenarios: [
    { name: "Constructif", probability: "10%", triggers: "Cessez-le-feu Iran, petrole sous $90, PCE en ligne", signals: "VIX sous 18, S&P au-dessus de 6 700", invalidation: "Escalade Iran, petrole >$120" },
    { name: "Base", probability: "45%", triggers: "Statu quo geopolitique, petrole $100-115, consolidation", signals: "VIX 22-28, S&P range 6 300-6 600", invalidation: "Desescalade ou escalade majeure" },
    { name: "Negatif", probability: "45%", triggers: "Escalade Iran, petrole >$130, stagflation confirmee", signals: "VIX >30, S&P sous 6 000, 10Y >4,60%", invalidation: "Cessez-le-feu, petrole sous $90" },
  ],
  risks: [
    { title: "Petrole >$130", description: "Escalade au Detroit d'Ormuz → petrole au-dessus de $130 → inflation explosive → recession" },
    { title: "Appels de marge en cascade", description: "La chute de l'or et la hausse des taux pourraient declencher des liquidations forcees" },
    { title: "Transition Fed", description: "Warsh remplace Powell en mai — incertitude sur la direction de la politique monetaire" },
    { title: "Tarifs US-Chine", description: "Escalade des tarifs → impact direct sur Apple, NVIDIA, et toute la supply chain tech" },
  ],
  scenarioDisclaimer: "Ces scenarios sont des outils de reflexion, pas des predictions. Les probabilites sont subjectives et basees sur les donnees disponibles au 21 mars 2026.",
  conclusion: "La semaine 13 confirme que le marche est a un point d'inflexion. L'or en chute libre, le petrole au-dessus de $110, le VIX a 26,78 et le Russell 2000 en correction — tous les signaux pointent vers un stress croissant. Micron est le seul point lumineux, prouvant que la demande IA est intacte. La semaine prochaine, le PCE vendredi et les earnings Carnival seront les catalyseurs a surveiller.",
  conclusionLecture: "Le message de la semaine 13 est clair : le marche est en mode risk-off generalise. Meme les valeurs refuges traditionnelles (or) ne protegent plus. La seule protection est l'energie (petrole cher) et le cash. Pour les investisseurs a moyen terme, la deconnexion entre les fondamentaux tech (Micron record) et les cours (Nasdaq -7,8% YTD) cree des opportunites potentielles — mais le timing est incertain tant que le petrole reste au-dessus de $100.",
  sources: "Donnees de marche : MarketWatch, Reuters, Morningstar, AP, cloture vendredi 21 mars 2026. Earnings : Yahoo Finance, Earnings Whispers. Analystes : Goldman Sachs, Morgan Stanley, JPMorgan.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
};
