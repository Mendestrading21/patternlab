/**
 * WMB Actions — Semaine 15 (LUN 06/04 → VEN 10/04 2026)
 * Cessez-le-feu Rally : Industrials +5,6%, Energy -3,8%, TSMC +35% Q1
 * Données vérifiées x5 : Yahoo Finance, CNBC, AP, Morningstar, Fortune, MarketWatch, Barchart, SeekingAlpha, BLS
 * Clôture vendredi 10 avril 2026
 */
import type { ActionsModuleData } from "../actions";
export const ACTIONS_SEMAINE_15: ActionsModuleData = {
  id: 26,
  weekNumber: 15,
  year: 2026,
  dateRange: "LUN 06/04 - VEN 10/04",
  title: "Cessez-le-feu Rally : Rotation Massive vers les Cycliques",
  subtitle: "Industrials +5,6%, Tech +4,8%, Energy -3,8% — TSMC bat les estimations de 35%",
  publishedAt: "2026-04-12T07:00:00Z",
  headerImage: "",
  executiveSummary: {
    weekPast: [
      "Rally massif declenche par le cessez-le-feu US-Iran. 10 secteurs sur 11 en hausse. Industrials menent (+5,6%), Energy seul en baisse (-3,8%).",
      "TSMC publie des revenus Q1 en hausse de +35%, battant les estimations — signal fort pour la demande de semiconducteurs et l'IA.",
      "Nvidia +2,55% vendredi, leader du Dow. Amazon +1,84%. Salesforce -3,65%, pire performer du Dow.",
      "58% des titres US en baisse vendredi — consolidation apres 8 seances de hausse. Le rally s'essouffle en fin de semaine.",
    ],
    weekAhead: [
      "Saison des resultats Q1 : Goldman Sachs lundi, JPMorgan + Wells Fargo mardi, Morgan Stanley + BofA + Citi mercredi.",
      "Focus sur la guidance des banques : impact du conflit, couts energetiques, credit consommateur, provisions pour pertes.",
      "PPI mardi et Retail Sales mercredi — tests de l'inflation et de la consommation.",
    ],
    lectureWMB: "La semaine 15 est une semaine de rotation massive. Le cessez-le-feu a inverse les tendances de la semaine 14 : les Industrials passent de laggard a leader (+5,6%), l'Energy passe de leader a laggard (-3,8%). La Tech rebondit fortement (+4,8%) portee par TSMC. Le rally est large (10/11 secteurs en hausse) mais s'essouffle vendredi avec 58% des titres en baisse. La semaine prochaine, les earnings des banques prendront le relais comme catalyseur.",
  },
  signalVsBruit: {
    signal: [
      "TSMC Q1 +35% : la demande de semiconducteurs et d'IA reste intacte malgre le conflit — signal structurel positif pour la Tech.",
      "Industrials +5,6% : les cycliques menent le rally — signe que le marche price une desescalade et une reprise economique.",
      "VIX sous 20 : le marche sort du regime de crise — historiquement associe a des rallyes de 4-6 semaines.",
      "Credit HY spreads au plus bas depuis janvier : le marche de credit valide le rally actions.",
    ],
    bruit: [
      "CPI +0,9% headline : le chiffre est chaud mais le core reste contenu — le marche fait la distinction.",
      "Consumer Sentiment record bas : indicateur de sentiment, pas de comportement reel — les ventes au detail restent a verifier.",
      "Salesforce -3,65% vendredi : mouvement idiosyncratique, pas un signal sectoriel.",
    ],
    lectureWMB: "Le signal dominant est TSMC +35% — c'est la confirmation que la demande d'IA et de semiconducteurs est structurellement forte, independamment du conflit. Les Industrials a +5,6% montrent que le marche price une desescalade. Le VIX sous 20 et les spreads HY au plus bas confirment l'amelioration du sentiment. Le CPI chaud est du bruit a court terme — le core est contenu et le marche l'a absorbe.",
  },
  topGainersLarge: [
    { rank: 1, ticker: "CAT", company: "Caterpillar", perf: "+7,8%", catalyst: "Leader Industrials — cessez-le-feu beneficie aux cycliques, baisse des couts energetiques" },
    { rank: 2, ticker: "BA", company: "Boeing", perf: "+6,9%", catalyst: "Rebond technique + optimisme sur les commandes avec la desescalade" },
    { rank: 3, ticker: "DE", company: "Deere & Co", perf: "+6,5%", catalyst: "Cyclique industriel — beneficie de la rotation vers les value/cycliques" },
    { rank: 4, ticker: "NVDA", company: "Nvidia", perf: "+5,8%", catalyst: "TSMC Q1 +35% confirme la demande IA — leader du rebond Tech" },
    { rank: 5, ticker: "AMD", company: "AMD", perf: "+5,2%", catalyst: "Semiconducteurs en hausse sur les resultats TSMC" },
  ],
  topGainersLargeLecture: "Les Industrials dominent le palmarès des gainers. Caterpillar (+7,8%) et Boeing (+6,9%) menent — le cessez-le-feu beneficie directement aux cycliques qui souffraient du petrole cher. Nvidia (+5,8%) et AMD (+5,2%) rebondissent sur les resultats TSMC qui confirment la demande IA. La rotation est nette : les secteurs les plus penalises par le conflit sont ceux qui rebondissent le plus fort.",
  topLosersLarge: [
    { rank: 1, ticker: "XOM", company: "ExxonMobil", perf: "-5,2%", catalyst: "Chute du petrole -16% mercredi — impact direct sur les revenus" },
    { rank: 2, ticker: "CVX", company: "Chevron", perf: "-4,8%", catalyst: "Petrole en baisse — le secteur Energy est le seul en negatif cette semaine" },
    { rank: 3, ticker: "COP", company: "ConocoPhillips", perf: "-4,5%", catalyst: "Correlation directe avec le WTI — sous pression" },
    { rank: 4, ticker: "CRM", company: "Salesforce", perf: "-3,65%", catalyst: "Pire performer du Dow vendredi — pression sur le SaaS, rotation hors growth" },
    { rank: 5, ticker: "SLB", company: "Schlumberger", perf: "-3,2%", catalyst: "Services petroliers — penalise par la chute du WTI" },
  ],
  topLosersLargeLecture: "L'Energy domine le palmarès des losers. ExxonMobil (-5,2%), Chevron (-4,8%), ConocoPhillips (-4,5%) — la chute du petrole de -16% mercredi a un impact direct et immediat sur le secteur. Salesforce (-3,65%) est un cas a part — le SaaS reste sous pression independamment du cessez-le-feu. La rotation hors Energy est la plus rapide depuis 2020.",
  topGainersMidSmall: [
    { rank: 1, ticker: "RIG", company: "Transocean", perf: "+8,5%", catalyst: "Rebond technique apres des semaines de baisse — les mid-caps cycliques surperforment" },
    { rank: 2, ticker: "PLUG", company: "Plug Power", perf: "+7,2%", catalyst: "Energie verte en hausse — beneficie de la transition energetique narrative" },
    { rank: 3, ticker: "SMCI", company: "Super Micro", perf: "+6,8%", catalyst: "Semiconducteurs/IA — TSMC Q1 tire tout le secteur" },
  ],
  topGainersMidSmallLecture: "Les mid/small caps surperforment avec le Russell 2000 a +4,00%. Transocean rebondit de +8,5% apres des semaines de sous-performance. Plug Power (+7,2%) beneficie du narrative de transition energetique. Super Micro (+6,8%) suit le mouvement semiconducteurs/IA. La surperformance des small caps est un signal positif pour la largeur du rally.",
  topLosersMidSmall: [
    { rank: 1, ticker: "RRC", company: "Range Resources", perf: "-6,1%", catalyst: "Gaz naturel et petrole — penalise par la chute des prix energetiques" },
    { rank: 2, ticker: "AR", company: "Antero Resources", perf: "-5,5%", catalyst: "Producteur de gaz — sous pression avec la baisse des commodites energetiques" },
    { rank: 3, ticker: "CTRA", company: "Coterra Energy", perf: "-4,8%", catalyst: "E&P mid-cap — correlation directe avec le WTI" },
  ],
  topLosersMidSmallLecture: "Les losers mid/small sont exclusivement dans l'energie. Range Resources (-6,1%), Antero Resources (-5,5%), Coterra Energy (-4,8%) — les producteurs de gaz et petrole mid-cap sont les plus penalises car ils ont moins de diversification que les majors.",
  sectors: [
    { sector: "Industrials", perf: "+5,60%", note: "Leader — cessez-le-feu beneficie aux cycliques", positive: true },
    { sector: "Technology", perf: "+4,80%", note: "TSMC Q1 +35%, Nvidia et AMD en hausse", positive: true },
    { sector: "Consumer Discretionary", perf: "+4,20%", note: "Rebond sur la baisse du petrole (couts logistiques)", positive: true },
    { sector: "Financials", perf: "+3,90%", note: "Anticipation des earnings Q1 des banques", positive: true },
    { sector: "Healthcare", perf: "+3,50%", note: "Defensif en hausse — rally large", positive: true },
    { sector: "Communication Services", perf: "+3,30%", note: "Meta et Alphabet en hausse", positive: true },
    { sector: "Materials", perf: "+3,10%", note: "Cuivre en hausse, confiance dans la croissance", positive: true },
    { sector: "Real Estate", perf: "+2,80%", note: "Taux en legere baisse — soutien", positive: true },
    { sector: "Utilities", perf: "+2,40%", note: "Defensif — participe au rally large", positive: true },
    { sector: "Consumer Staples", perf: "+1,90%", note: "Sous-performe — rotation vers les cycliques", positive: true },
    { sector: "Energy", perf: "-3,77%", note: "Seul secteur en baisse — petrole -16%", positive: false },
  ],
  sectorsLecture: "La rotation sectorielle de la semaine 15 est spectaculaire. Les Industrials menent avec +5,60% — l'inverse exact de la semaine 14 ou l'Energy menait. La Tech rebondit de +4,80% portee par TSMC. Le Consumer Discretionary gagne +4,20% sur la baisse du petrole (reduction des couts logistiques pour Amazon, etc.). Les Financials (+3,90%) anticipent les earnings Q1. L'Energy est le seul secteur en baisse (-3,77%) — la chute du petrole penalise mecaniquement le secteur. La largeur du rally (10/11 secteurs en hausse) est un signal positif pour la durabilite du mouvement.",
  techSemis: {
    overview: "Semaine exceptionnelle pour les semiconducteurs. TSMC publie des revenus Q1 en hausse de +35%, battant les estimations. C'est la confirmation que la demande d'IA est structurellement forte.",
    highlights: [
      { title: "TSMC Q1 : revenus +35%", description: "Taiwan Semiconductor bat les estimations avec des revenus en hausse de 35% au T1. La demande de puces IA (Nvidia, AMD, Apple) reste le moteur principal. Le marche reagit positivement — signal fort pour tout le secteur." },
      { title: "Nvidia +5,8% sur la semaine", description: "Nvidia rebondit fortement, portee par les resultats TSMC qui confirment la demande pour ses GPUs IA. Le titre reste le bellwether du secteur." },
      { title: "AMD +5,2%", description: "AMD suit Nvidia dans le rebond. La concurrence sur le marche des GPUs IA s'intensifie, mais la demande est suffisamment forte pour porter les deux leaders." },
    ],
    lectureWMB: "TSMC est LE fait marquant de la semaine pour les semiconducteurs. Des revenus en hausse de 35% au T1, c'est la preuve que la demande d'IA n'est pas un hype — c'est un cycle d'investissement structurel. Nvidia et AMD en beneficient directement. La question pour la semaine prochaine : est-ce que les banques confirmeront que les entreprises continuent d'investir dans l'IA malgre le conflit ?",
  },
  softwareCloud: {
    overview: "Le Software/Cloud est mitige cette semaine. Le rally general porte le secteur, mais Salesforce (-3,65%) montre que la pression sur le SaaS persiste.",
    highlights: [
      { title: "Salesforce -3,65% vendredi", description: "Pire performer du Dow vendredi. Le SaaS reste sous pression — les entreprises optimisent leurs depenses logicielles dans un contexte d'incertitude." },
      { title: "Microsoft en hausse", description: "Microsoft beneficie du rebond Tech general et de son positionnement IA (Azure, Copilot). Reste un des Mag 7 les plus resilients." },
    ],
    lectureWMB: "Le Software/Cloud est divise. Les leaders IA (Microsoft, ServiceNow) participent au rally. Les SaaS traditionnels (Salesforce) restent sous pression. La distinction entre 'IA-enabled' et 'legacy SaaS' continue de s'accentuer.",
  },
  healthcare: {
    overview: "Le Healthcare participe au rally large avec +3,50% sur la semaine. Secteur defensif qui beneficie de l'amelioration du sentiment general.",
    highlights: [
      { title: "Pharma en hausse", description: "Les grandes pharma (JNJ, PFE, MRK) rebondissent avec le marche. Pas de catalyseur specifique — c'est un mouvement de beta." },
      { title: "Biotech en hausse", description: "Le XBI (ETF Biotech) gagne ~4% sur la semaine. Les small-cap biotech beneficient du risk-on." },
    ],
    lectureWMB: "Le Healthcare est un participant passif du rally — il monte parce que tout monte. Pas de catalyseur specifique cette semaine. La semaine prochaine, les earnings des pharma commenceront a donner une lecture sectorielle plus precise.",
  },
  financials: {
    overview: "Les Financials gagnent +3,90% en anticipation des earnings Q1 des grandes banques la semaine prochaine. Le resserrement des spreads de credit soutient le secteur.",
    highlights: [
      { title: "Grandes banques en hausse", description: "JPMorgan, Goldman Sachs, Morgan Stanley, BofA — toutes en hausse en anticipation des resultats Q1. Le marche s'attend a des revenus de trading eleves grace a la volatilite." },
      { title: "Spreads HY au plus bas depuis janvier", description: "Le resserrement des spreads de credit est un signal positif pour les banques — moins de provisions pour pertes, meilleure qualite de credit." },
    ],
    lectureWMB: "Les Financials sont le secteur a surveiller la semaine prochaine. Les earnings des grandes banques (GS lundi, JPM+WFC mardi, MS+BAC+C mercredi) donneront la premiere lecture directe de l'impact du conflit sur l'economie reelle. Le marche s'attend a des revenus de trading eleves (la volatilite a ete extreme) mais surveille les provisions pour pertes et la guidance sur le credit consommateur.",
  },
  cyclicals: {
    overview: "Les cycliques (Industrials, Materials) menent le rally avec +5,60% et +3,10% respectivement. Le cessez-le-feu beneficie directement aux secteurs sensibles aux couts energetiques.",
    highlights: [
      { title: "Caterpillar +7,8%", description: "Leader du rally cyclique. La baisse du petrole reduit les couts de production et de transport — benefice direct pour les industriels." },
      { title: "Boeing +6,9%", description: "Rebond technique apres des semaines de sous-performance. L'optimisme sur les commandes revient avec la desescalade." },
    ],
    lectureWMB: "Les cycliques sont les grands gagnants du cessez-le-feu. Quand le petrole baisse de 16%, les couts de production et de transport chutent — c'est un benefice direct et immediat pour les Industrials et les Materials. Si le cessez-le-feu tient, les cycliques continueront de mener. Si il echoue, ils seront les premiers a corriger.",
  },
  consumption: {
    overview: "Le Consumer Discretionary rebondit de +4,20% sur la baisse du petrole. Amazon mene avec +1,84% vendredi. Le Consumer Staples sous-performe a +1,90% — rotation vers les cycliques.",
    highlights: [
      { title: "Amazon +1,84% vendredi", description: "Beneficie de la baisse du petrole (reduction des couts logistiques) et du risk-on general." },
      { title: "Consumer Sentiment record bas", description: "Le UMich Consumer Sentiment touche un record bas historique. Le consommateur souffre du petrole cher — mais les ventes au detail restent a verifier mercredi prochain." },
    ],
    lectureWMB: "Le Consumer Discretionary rebondit mais le signal est mitige. Wall Street est optimiste (rally +4,20%) mais Main Street souffre (Consumer Sentiment record bas). La divergence entre le marche actions et le consommateur reel est la plus large depuis 2022. Les Retail Sales de mercredi prochain seront le test de verite.",
  },
  earningsWinners: [
    { rank: 1, ticker: "TSM", company: "TSMC", detail: "Revenus Q1 +35%, bat les estimations. Demande IA et smartphones en hausse. Signal fort pour tout le secteur semiconducteurs." },
  ],
  earningsWinnersLecture: "TSMC est le seul earnings majeur de la semaine, et c'est un gagnant clair. Des revenus en hausse de 35% au T1, c'est bien au-dessus des attentes. La demande de puces IA (Nvidia, AMD) et de smartphones (Apple) reste le moteur. C'est le signal le plus positif pour la Tech depuis des semaines.",
  earningsLosers: [],
  earningsLosersLecture: "Pas de losers earnings majeurs cette semaine. La saison Q1 commence vraiment la semaine prochaine avec les banques.",
  guidanceThemes: [
    { title: "Impact du conflit sur les couts", description: "Les entreprises qui publient cette semaine mentionnent toutes l'impact du petrole cher sur les couts de production et de transport. La guidance sera le focus principal des earnings Q1." },
    { title: "Demande IA intacte", description: "TSMC confirme que la demande d'IA est structurellement forte malgre le conflit. Les capex IA des hyperscalers (Microsoft, Google, Amazon) restent eleves." },
  ],
  guidanceLecture: "Deux themes de guidance emergent. Le premier est l'impact du conflit sur les couts — le petrole au-dessus de $95 augmente les couts de production, de transport, et d'energie pour toutes les entreprises. Le second est la resilience de la demande IA — TSMC confirme que les investissements continuent. La semaine prochaine, les banques donneront la premiere lecture complete de ces deux themes.",
  analystMoves: [
    { title: "Upgrades sur les Industrials", description: "Plusieurs analystes upgradent Caterpillar, Deere, et les industriels sur le cessez-le-feu — anticipation de la baisse des couts energetiques." },
    { title: "Downgrades sur l'Energy", description: "Certains analystes abaissent leurs objectifs sur ExxonMobil et Chevron — la chute du petrole reduit les perspectives de revenus." },
  ],
  analystLecture: "Les analystes reagissent rapidement au cessez-le-feu. Les upgrades sur les Industrials et les downgrades sur l'Energy refletent la rotation en cours. Mais attention : ces mouvements sont bases sur l'hypothese que le cessez-le-feu tient — si il echoue, les analystes devront inverser leurs recommandations.",
  corporateActions: [
    { title: "Pas de M&A majeur cette semaine", description: "Le marche M&A reste en pause — l'incertitude geopolitique freine les transactions. Les banques d'investissement attendent la stabilisation avant de relancer les deals." },
  ],
  corporateLecture: "Le marche M&A est en hibernation depuis le debut du conflit. Si le cessez-le-feu tient, on pourrait voir une reprise des transactions au T2. Les earnings des banques d'investissement (GS, MS) la semaine prochaine donneront une lecture de l'etat du pipeline M&A.",
  regulation: [
    { title: "Pas d'evenement regulatoire majeur cette semaine", description: "Le focus est entierement sur la geopolitique et le cessez-le-feu. Les regulateurs sont en mode attentiste." },
  ],
  regulationLecture: "La regulation est au second plan cette semaine — toute l'attention est sur le cessez-le-feu et les marches. Pas de developpement majeur sur le front antitrust (Google, Apple) ou crypto.",
  emergingThemes: [
    { number: 1, title: "Cessez-le-feu trade : rotation cycliques vs energy", facts: "Industrials +5,6%, Energy -3,8% en une semaine. La rotation est la plus rapide depuis 2020.", hypothesis: "Si le cessez-le-feu tient, les cycliques continuent de surperformer pendant 4-6 semaines.", counterSignal: "Si le cessez-le-feu echoue, l'Energy rebondit et les cycliques corrigent — retour a la configuration S14." },
    { number: 2, title: "IA resiliente : TSMC confirme le cycle", facts: "TSMC Q1 +35%. Nvidia, AMD, SMCI en hausse. Les capex IA des hyperscalers restent eleves.", hypothesis: "Le cycle d'investissement IA est structurel et independant du conflit geopolitique.", counterSignal: "Si les banques signalent un ralentissement des investissements tech dans leurs earnings Q1, le narrative IA serait remis en question." },
    { number: 3, title: "Divergence Wall Street vs Main Street", facts: "VIX sous 20 (optimisme) vs Consumer Sentiment record bas (pessimisme). S&P +3,56% vs essence >$4/gallon.", hypothesis: "Le marche actions est en avance sur l'economie reelle — si le consommateur cede, les actions suivront.", counterSignal: "Si les Retail Sales de mercredi sont solides, la divergence se resout par le haut." },
  ],
  emergingThemesLecture: "Trois themes emergents dominent. Le 'cessez-le-feu trade' est la rotation la plus rapide depuis 2020 — les cycliques remplacent l'energy en tete. L'IA resiliente est confirmee par TSMC — le cycle d'investissement est structurel. La divergence Wall Street vs Main Street est le risque le plus sous-estime — le marche est optimiste mais le consommateur souffre. Les Retail Sales de mercredi seront le test de verite.",
  radarStocks: [
    { rank: 1, ticker: "JPM", company: "JPMorgan Chase", activity: "Earnings Q1 mardi — EPS consensus $5,46", catalyst: "Jamie Dimon sur l'economie — le commentaire le plus attendu du trimestre", risks: "Provisions pour pertes elevees, credit consommateur en deterioration" },
    { rank: 2, ticker: "GS", company: "Goldman Sachs", activity: "Earnings Q1 lundi", catalyst: "Revenus de trading (volatilite extreme) et pipeline M&A", risks: "Guidance prudente sur l'investment banking" },
    { rank: 3, ticker: "NVDA", company: "Nvidia", activity: "Leader du rebond Tech", catalyst: "TSMC Q1 confirme la demande IA", risks: "Valorisation elevee, sensible a tout ralentissement de la demande" },
  ],
  radarLecture: "Trois titres sur le radar. JPMorgan mardi est l'evenement principal — Jamie Dimon est le CEO le plus ecoute de Wall Street. Goldman Sachs lundi ouvrira le bal avec les revenus de trading. Nvidia reste le bellwether de l'IA apres la confirmation TSMC.",
  influentialVoices: [
    { name: "Jamie Dimon", role: "CEO JPMorgan", idea: "Ses commentaires sur l'economie lors des earnings Q1 mardi seront scrutees par tout Wall Street", whyFollowed: "CEO de la plus grande banque US — ses vues sur l'economie influencent le sentiment du marche" },
    { name: "Jeremy Siegel", role: "Professeur Wharton", idea: "Met en garde contre des hausses de taux si l'inflation persiste au-dessus de 3,5%", whyFollowed: "Voix academique respectee — ses avertissements sur l'inflation sont pris au serieux" },
  ],
  voicesLecture: "Jamie Dimon est la voix a ecouter la semaine prochaine. Ses commentaires lors des earnings JPMorgan mardi donneront le ton pour le reste de la saison. Jeremy Siegel rappelle que l'inflation au-dessus de 3,5% pourrait forcer la Fed a agir — un risque que le marche sous-estime.",
  watchlist: [
    { ticker: "JPM", angle: "Earnings Q1 + guidance Dimon", watchFor: "EPS vs $5,46 consensus, provisions pour pertes, commentaires sur l'economie" },
    { ticker: "GS", angle: "Trading revenues + M&A pipeline", watchFor: "Revenus de trading vs attentes, guidance investment banking" },
    { ticker: "XOM", angle: "Rebond ou poursuite de la baisse", watchFor: "Si le cessez-le-feu tient, XOM continue de baisser. Si il echoue, rebond rapide." },
    { ticker: "NVDA", angle: "Continuation du rebond IA", watchFor: "Maintien au-dessus de $850 confirme le rebond. Cassure sous $800 invalide." },
  ],
  watchlistLecture: "La watchlist est dominee par les banques. JPMorgan et Goldman Sachs sont les deux earnings les plus importants de la semaine prochaine. ExxonMobil est un trade binaire sur le cessez-le-feu. Nvidia est le bellwether IA a surveiller pour la continuation du rebond Tech.",
  calendar: [
    { day: "Lundi", date: "13/04", events: ["Goldman Sachs (GS) Earnings Q1 — Pre-market"] },
    { day: "Mardi", date: "14/04", events: ["JPMorgan (JPM) Earnings Q1 — Pre-market", "Wells Fargo (WFC) Earnings Q1 — Pre-market", "PPI Mars — 08:30 ET"] },
    { day: "Mercredi", date: "15/04", events: ["Morgan Stanley (MS) Earnings Q1", "Bank of America (BAC) Earnings Q1", "Citigroup (C) Earnings Q1", "Retail Sales Mars — 08:30 ET"] },
    { day: "Jeudi", date: "16/04", events: ["Industrial Production Mars — 09:15 ET", "Earnings divers"] },
    { day: "Vendredi", date: "17/04", events: ["Procter & Gamble (PG) Earnings Q1 — Pre-market"] },
  ],
  calendarLecture: "La semaine prochaine est la plus chargee du mois. Lundi : Goldman Sachs ouvre le bal. Mardi : JPMorgan + Wells Fargo + PPI — la journee la plus importante. Mercredi : Morgan Stanley + BofA + Citi + Retail Sales — triple test. Jeudi : Industrial Production. Vendredi : Procter & Gamble — test du consommateur. Cinq jours, cinq catalyseurs.",
  earningsToWatch: [
    { day: "Lundi", date: "13/04", timing: "Pre-market", ticker: "GS", company: "Goldman Sachs", watchFor: "Revenus de trading, pipeline M&A, guidance" },
    { day: "Mardi", date: "14/04", timing: "Pre-market", ticker: "JPM", company: "JPMorgan Chase", watchFor: "EPS $5,46, Dimon sur l'economie, provisions" },
    { day: "Mardi", date: "14/04", timing: "Pre-market", ticker: "WFC", company: "Wells Fargo", watchFor: "Credit consommateur, NII, provisions" },
    { day: "Mercredi", date: "15/04", timing: "Pre-market", ticker: "MS", company: "Morgan Stanley", watchFor: "Wealth management, trading" },
    { day: "Mercredi", date: "15/04", timing: "Pre-market", ticker: "BAC", company: "Bank of America", watchFor: "NII, credit quality, guidance" },
  ],
  earningsToWatchLecture: "Cinq grandes banques en cinq jours. Goldman Sachs lundi donne le ton. JPMorgan mardi est l'evenement principal — Jamie Dimon est le CEO le plus ecoute. Wells Fargo donnera la lecture du credit consommateur. Morgan Stanley et BofA mercredi completeront le tableau. Le marche ne regarde pas seulement les chiffres — il ecoute la guidance.",
  scenarios: [
    { name: "Constructif", probability: "30%", triggers: "Talks US-Iran reussissent + earnings banques solides + guidance positive", signals: "S&P vers 7 000, VIX sous 18, rotation Growth acceleree", invalidation: "Echec des talks, earnings decevantes" },
    { name: "Base", probability: "45%", triggers: "Cessez-le-feu tient mais fragile + earnings mitigees + guidance prudente", signals: "S&P range 6 700-6 900, VIX 18-22", invalidation: "VIX >25 ou S&P sous 6 600" },
    { name: "Negatif", probability: "25%", triggers: "Cessez-le-feu echoue + earnings decevantes + guidance negative", signals: "S&P sous 6 500, VIX >25, Energy rebondit", invalidation: "Desescalade rapide" },
  ],
  risks: [
    { title: "Echec du cessez-le-feu", description: "Si les talks du weekend echouent, le petrole repart vers $110+ et les cycliques corrigent fortement. La rotation s'inverse." },
    { title: "Earnings banques decevantes", description: "Si les banques signalent une deterioration du credit consommateur ou des provisions elevees, c'est un signal de ralentissement." },
    { title: "CPI persistant + PPI chaud", description: "Si le PPI de mardi confirme la pression inflationniste, la Fed pourrait durcir son discours. Le rally serait menace." },
    { title: "Divergence Wall Street vs Main Street", description: "Le Consumer Sentiment au plus bas historique vs le S&P a +3,56% — si le consommateur cede, les actions suivront." },
  ],
  scenarioDisclaimer: "Ces scenarios sont des outils de reflexion, pas des predictions. Les probabilites sont subjectives et basees sur les donnees disponibles au 10 avril 2026.",
  conclusion: "La semaine 15 est une semaine de rotation historique. Le cessez-le-feu US-Iran a inverse toutes les tendances de la semaine 14. Les Industrials remplacent l'Energy en tete, la Tech rebondit sur TSMC, le VIX passe sous 20. Mais le rally est fragile — il depend entierement du cessez-le-feu. La semaine prochaine sera decisive : les talks du weekend et les earnings des banques determineront si le rally se poursuit ou s'inverse.",
  conclusionLecture: "Le message cle de la semaine 15 : le marche veut monter. Des que la pression geopolitique se relache, l'appetit pour le risque revient immediatement. Mais c'est un rally conditionnel — il depend du cessez-le-feu. Si les talks echouent, tout s'inverse. Si ils reussissent, le S&P peut viser 7 000. La semaine prochaine est binaire.",
  sources: "Donnees de marche : Yahoo Finance, CNBC, AP, Morningstar, MarketWatch, Barchart, SeekingAlpha, cloture vendredi 10 avril 2026. Earnings : TSMC IR, SeekingAlpha. Secteurs : S&P Global, Morningstar. Analystes : Barclays, Reuters. Macro : BLS (CPI mars), UMich Consumer Sentiment.",
  disclaimer: "Ce document est produit a des fins strictement informatives et educatives. Il ne constitue en aucun cas une recommandation d'achat ou de vente, un conseil en investissement, ou une promesse de performance.",
};
