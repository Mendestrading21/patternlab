/**
 * libraryIndex — index unifié de toute la Bibliothèque du Trading.
 * Agrège concepts, guides, leçons, figures chartistes et chandeliers en une
 * seule liste cherchable. Chaque enregistrement pointe vers la page de sa
 * collection avec un paramètre `?fiche=<slug>` qui ouvre directement la fiche.
 */
import type { ConceptType } from "@/components/ConceptIllustration";
import { GLOSSARY_CONCEPTS, CONCEPT_CATEGORY_LABELS } from "./glossaryConcepts";
import { TRADING_GUIDES, GUIDE_CATEGORY_LABELS } from "./tradingGuides";
import { ANALYSIS_LESSONS, LEVEL_META } from "./formationAnalyse";
import { CHART_PATTERNS, CATEGORY_LABELS as PATTERN_CATEGORY_LABELS } from "./chartPatterns";
import { CANDLESTICK_PATTERNS, CANDLE_GROUP_LABELS } from "./candlestickPatterns";
import { INDICATORS, FAMILY_LABELS } from "./indicators";
import { MARKET_CRASHES } from "./marketCrashes";

export type LibraryKind = "concept" | "guide" | "lecon" | "figure" | "chandelier" | "indicateur" | "krach";

export type LibraryRecord = {
  kind: LibraryKind;
  kindLabel: string;
  kindColor: string;
  slug: string;
  title: string;
  english: string;
  summary: string;
  /** Catégorie / niveau de la fiche. */
  tag: string;
  tagColor: string;
  /** Lien d'ouverture directe de la fiche. */
  href: string;
  /** Illustration ConceptIllustration (concepts/guides/leçons uniquement). */
  illu?: ConceptType;
  /** Texte concaténé en minuscules pour la recherche. */
  haystack: string;
};

export const KIND_META: Record<LibraryKind, { label: string; color: string }> = {
  concept: { label: "Concept", color: "#344453" },
  guide: { label: "Guide", color: "#2E7D5B" },
  lecon: { label: "Leçon", color: "#C8A962" },
  figure: { label: "Figure", color: "#1a3a50" },
  chandelier: { label: "Chandelier", color: "#B0413E" },
  indicateur: { label: "Indicateur", color: "#7A6A5A" },
  krach: { label: "Krach", color: "#B0413E" },
};

function build(): LibraryRecord[] {
  const out: LibraryRecord[] = [];

  for (const c of GLOSSARY_CONCEPTS) {
    const cat = CONCEPT_CATEGORY_LABELS[c.category];
    out.push({
      kind: "concept",
      kindLabel: KIND_META.concept.label,
      kindColor: KIND_META.concept.color,
      slug: c.slug,
      title: c.term,
      english: c.english,
      summary: c.summary,
      tag: cat.label,
      tagColor: cat.color,
      href: `/glossaire?fiche=${c.slug}`,
      illu: c.illu,
      haystack: `${c.term} ${c.english} ${c.summary} ${cat.label}`.toLowerCase(),
    });
  }

  for (const g of TRADING_GUIDES) {
    const cat = GUIDE_CATEGORY_LABELS[g.category];
    out.push({
      kind: "guide",
      kindLabel: KIND_META.guide.label,
      kindColor: KIND_META.guide.color,
      slug: g.slug,
      title: g.title,
      english: g.english,
      summary: g.summary,
      tag: cat.label,
      tagColor: cat.color,
      href: `/methode?fiche=${g.slug}`,
      illu: g.illu,
      haystack: `${g.title} ${g.english} ${g.summary} ${cat.label}`.toLowerCase(),
    });
  }

  for (const l of ANALYSIS_LESSONS) {
    out.push({
      kind: "lecon",
      kindLabel: KIND_META.lecon.label,
      kindColor: KIND_META.lecon.color,
      slug: l.slug,
      title: l.title,
      english: l.english,
      summary: l.summary,
      tag: l.level,
      tagColor: LEVEL_META[l.level].color,
      href: `/formation-analyse?fiche=${l.slug}`,
      illu: l.illu,
      haystack: `${l.title} ${l.english} ${l.summary} ${l.level}`.toLowerCase(),
    });
  }

  for (const p of CHART_PATTERNS) {
    const cat = PATTERN_CATEGORY_LABELS[p.category];
    out.push({
      kind: "figure",
      kindLabel: KIND_META.figure.label,
      kindColor: KIND_META.figure.color,
      slug: p.slug,
      title: p.name,
      english: p.english,
      summary: p.summary,
      tag: cat.label,
      tagColor: cat.color,
      href: `/figures-chartistes?mode=figures&fiche=${p.slug}`,
      haystack: `${p.name} ${p.english} ${p.summary} ${cat.label}`.toLowerCase(),
    });
  }

  for (const p of CANDLESTICK_PATTERNS) {
    const grp = CANDLE_GROUP_LABELS[p.group];
    out.push({
      kind: "chandelier",
      kindLabel: KIND_META.chandelier.label,
      kindColor: KIND_META.chandelier.color,
      slug: p.slug,
      title: p.name,
      english: p.english,
      summary: p.summary,
      tag: grp.label,
      tagColor: grp.color,
      href: `/figures-chartistes?mode=chandeliers&fiche=${p.slug}`,
      haystack: `${p.name} ${p.english} ${p.summary} ${grp.label}`.toLowerCase(),
    });
  }

  for (const ind of INDICATORS) {
    const fam = FAMILY_LABELS[ind.family];
    out.push({
      kind: "indicateur",
      kindLabel: KIND_META.indicateur.label,
      kindColor: KIND_META.indicateur.color,
      slug: ind.slug,
      title: ind.name,
      english: ind.english,
      summary: ind.summary,
      tag: fam.label,
      tagColor: fam.color,
      href: `/indicateurs-tendance?fiche=${ind.slug}`,
      haystack: `${ind.name} ${ind.english} ${ind.summary} ${fam.label}`.toLowerCase(),
    });
  }

  for (const c of MARKET_CRASHES) {
    out.push({
      kind: "krach",
      kindLabel: KIND_META.krach.label,
      kindColor: KIND_META.krach.color,
      slug: c.slug,
      title: c.name,
      english: c.english,
      summary: c.summary,
      tag: c.year,
      tagColor: "#B0413E",
      href: `/krachs?fiche=${c.slug}`,
      illu: c.illu,
      haystack: `${c.name} ${c.english} ${c.summary} ${c.region} ${c.year}`.toLowerCase(),
    });
  }

  return out;
}

export const LIBRARY_INDEX: LibraryRecord[] = build();

export const LIBRARY_KIND_FILTERS: { id: LibraryKind | "all"; label: string }[] = [
  { id: "all", label: "Tout" },
  { id: "concept", label: "Concepts" },
  { id: "guide", label: "Guides" },
  { id: "lecon", label: "Leçons" },
  { id: "figure", label: "Figures" },
  { id: "chandelier", label: "Chandeliers" },
  { id: "indicateur", label: "Indicateurs" },
  { id: "krach", label: "Krachs" },
];

/** Recherche simple, tolérante : tous les mots de la requête doivent apparaître. */
export function searchLibrary(query: string, kind: LibraryKind | "all" = "all"): LibraryRecord[] {
  const pool = kind === "all" ? LIBRARY_INDEX : LIBRARY_INDEX.filter((r) => r.kind === kind);
  const q = query.trim().toLowerCase();
  if (!q) return pool;
  const terms = q.split(/\s+/).filter(Boolean);
  return pool.filter((r) => terms.every((t) => r.haystack.includes(t)));
}
