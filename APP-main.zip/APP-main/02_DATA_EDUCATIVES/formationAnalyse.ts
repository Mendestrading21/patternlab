/**
 * Formation — Analyse de marché : parcours structuré débutant → avancé.
 * Chaque module : jauges illustratives, exemples concrets, points clés.
 * 100% informatif (voix WMB). Les jauges sont des repères pédagogiques, pas
 * des mesures de marché en temps réel.
 */
import type { ConceptType } from "@/components/ConceptIllustration";

export type Level = "Débutant" | "Intermédiaire" | "Avancé";

export type AnalysisLesson = {
  slug: string;
  n: number;
  title: string;
  english: string;
  level: Level;
  illu: ConceptType;
  summary: string;
  intro: string;
  gauges: { label: string; value: number; verdict: string; scheme: "good-high" | "good-low" | "neutral" }[];
  examples: { title: string; detail: string }[];
  keyPoints: string[];
};

export const LEVEL_META: Record<Level, { color: string }> = {
  Débutant: { color: "#2E7D5B" },
  Intermédiaire: { color: "#C8A962" },
  Avancé: { color: "#B0413E" },
};

export const ANALYSIS_LEVELS: { id: Level | "all"; label: string }[] = [
  { id: "all", label: "Tous" },
  { id: "Débutant", label: "Débutant" },
  { id: "Intermédiaire", label: "Intermédiaire" },
  { id: "Avancé", label: "Avancé" },
];

export const ANALYSIS_LESSONS: AnalysisLesson[] = [
  {
    slug: "prix-tendance-volume",
    n: 1,
    title: "Lire le prix, la tendance et le volume",
    english: "Price, Trend & Volume",
    level: "Débutant",
    illu: "chart-anatomy",
    summary: "La fondation : avant tout indicateur, savoir lire les trois axes d'un graphique.",
    intro:
      "Tout commence par le prix. Avant le moindre indicateur, il faut savoir lire la structure (tendance), l'unité de temps et le volume. C'est la base sur laquelle tout le reste se construit — la maîtriser change déjà tout.",
    gauges: [
      { label: "Difficulté", value: 15, verdict: "Très accessible", scheme: "good-low" },
      { label: "Utilité pour débuter", value: 98, verdict: "Indispensable", scheme: "good-high" },
    ],
    examples: [
      { title: "Tendance haussière", detail: "Le S&P 500 entre 2013 et 2019 : une succession de sommets et de creux de plus en plus hauts. La structure, pas l'avis, définit la tendance." },
      { title: "Volume qui confirme", detail: "Une cassure de résistance accompagnée d'un volume en forte hausse est jugée plus solide qu'une cassure « molle » sans volume." },
      { title: "Échelle de temps", detail: "Un titre peut monter en hebdomadaire et chuter en 5 minutes. On choisit l'unité de temps selon son horizon avant de conclure." },
    ],
    keyPoints: [
      "Le prix d'abord : les indicateurs n'en sont que des dérivés.",
      "Structure = sommets/creux de plus en plus hauts (ou bas).",
      "Le volume mesure la conviction d'un mouvement.",
    ],
  },
  {
    slug: "support-resistance",
    n: 2,
    title: "Support & résistance",
    english: "Support & Resistance",
    level: "Débutant",
    illu: "support-resistance",
    summary: "Les zones où le marché a déjà réagi — les repères les plus utilisés au monde.",
    intro:
      "Un support est une zone où les acheteurs reviennent ; une résistance, une zone où les vendeurs reprennent la main. Ce sont des repères de mémoire collective : plus une zone est testée, plus elle compte — jusqu'à ce qu'elle cède.",
    gauges: [
      { label: "Difficulté", value: 25, verdict: "Accessible", scheme: "good-low" },
      { label: "Fiabilité (avec confluence)", value: 75, verdict: "Bonne", scheme: "good-high" },
    ],
    examples: [
      { title: "Rebond triple", detail: "Un titre qui rebondit trois fois sur 100 CHF : ce niveau devient un support de référence, surveillé par tous." },
      { title: "Inversion de rôle", detail: "Une fois 100 cassé à la baisse, ce support devient souvent une résistance lors du retour du prix (le « pullback »)." },
      { title: "Chiffre rond", detail: "Les niveaux ronds (100, 1000) concentrent les ordres et forment des supports/résistances par auto-réalisation." },
    ],
    keyPoints: [
      "Raisonner en zones, pas en lignes au pixel près.",
      "Support cassé → devient résistance (et inversement).",
      "Attendre la réaction (mèche, volume) avant de conclure.",
    ],
  },
  {
    slug: "tendances-canaux",
    n: 3,
    title: "Tendances & canaux",
    english: "Trends & Channels",
    level: "Débutant",
    illu: "channel",
    summary: "Tracer la direction du marché et l'encadrer proprement entre deux bornes.",
    intro:
      "Une tendance se matérialise par une ligne directrice ; un canal l'encadre par deux droites parallèles. Bien tracés, ce sont des outils simples et fiables — à condition de ne jamais forcer une ligne pour qu'elle « colle ».",
    gauges: [
      { label: "Difficulté", value: 35, verdict: "Modérée", scheme: "good-low" },
      { label: "Utilité", value: 85, verdict: "Élevée", scheme: "good-high" },
    ],
    examples: [
      { title: "Canal haussier", detail: "Le prix rebondit sur la borne basse (achats) et plafonne sur la borne haute (replis), en montant. On va dans le sens du courant." },
      { title: "Validation au 3ᵉ point", detail: "Une droite se trace sur deux points, mais ne devient crédible qu'au troisième contact qui la respecte." },
      { title: "Cassure", detail: "Une sortie nette du canal avec volume signale souvent une accélération ou un changement de tendance." },
    ],
    keyPoints: [
      "Deux points pour tracer, un troisième pour valider.",
      "Acheter/vendre les bords, jamais le milieu.",
      "Un canal n'est valable que tant que le prix le respecte.",
    ],
  },
  {
    slug: "chandeliers-japonais",
    n: 4,
    title: "Les chandeliers japonais",
    english: "Japanese Candlesticks",
    level: "Intermédiaire",
    illu: "bull-bear",
    summary: "Lire le rapport de force séance par séance grâce au corps et aux mèches.",
    intro:
      "Une bougie résume une séance : le corps (ouverture→clôture) dit qui a gagné, les mèches montrent les extrêmes rejetés. Les motifs (marteau, avalement, doji) traduisent des bascules de psychologie — toujours à confirmer.",
    gauges: [
      { label: "Difficulté", value: 45, verdict: "Modérée", scheme: "good-low" },
      { label: "Fiabilité (seul)", value: 40, verdict: "Variable", scheme: "good-high" },
    ],
    examples: [
      { title: "Marteau après baisse", detail: "Petit corps en haut, longue mèche basse : les vendeurs ont échoué, les acheteurs ont repris la main. Possible épuisement vendeur." },
      { title: "Avalement haussier", detail: "Une grande bougie verte englobe la rouge précédente : prise de contrôle nette des acheteurs, un des motifs les plus suivis." },
      { title: "Doji", detail: "Ouverture ≈ clôture : indécision totale. Après une tendance, il peut annoncer une pause ou un retournement." },
    ],
    keyPoints: [
      "Grand corps = conviction ; longues mèches = rejet/indécision.",
      "Un motif se confirme par la bougie suivante et le volume.",
      "L'emplacement (après une tendance) donne tout son sens au motif.",
    ],
  },
  {
    slug: "figures-chartistes",
    n: 5,
    title: "Les figures chartistes",
    english: "Chart Patterns",
    level: "Intermédiaire",
    illu: "trend",
    summary: "Tête-épaules, triangles, drapeaux : des schémas récurrents et ce qu'ils suggèrent.",
    intro:
      "Les figures chartistes sont des formes récurrentes du prix qui traduisent un équilibre puis une bascule. Retournement (tête-épaules, double sommet) ou continuation (drapeaux, triangles) : aucune ne fonctionne à 100%, elles donnent des probabilités.",
    gauges: [
      { label: "Difficulté", value: 50, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Fiabilité (confirmée)", value: 65, verdict: "Correcte", scheme: "good-high" },
    ],
    examples: [
      { title: "Tête-épaules", detail: "Trois sommets, le central plus haut. La cassure de la ligne de cou est la figure de retournement baissier la plus documentée." },
      { title: "Triangle ascendant", detail: "Résistance plate + creux montants : la pression acheteuse s'accumule sous le plafond. Sa cassure est lue dans le sens haussier." },
      { title: "Drapeau", detail: "Forte impulsion (le mât) puis brève consolidation, avant reprise. Figure de continuation très fréquente en tendance." },
    ],
    keyPoints: [
      "Distinguer retournement et continuation.",
      "La cassure (avec volume) valide la figure, pas sa simple forme.",
      "Objectif théorique = hauteur de la figure reportée.",
    ],
  },
  {
    slug: "moyennes-mobiles",
    n: 6,
    title: "Les moyennes mobiles",
    english: "Moving Averages",
    level: "Intermédiaire",
    illu: "trend",
    summary: "Lisser le bruit pour révéler la tendance de fond et ses croisements.",
    intro:
      "Une moyenne mobile lisse les prix pour montrer la direction de fond. Au-dessus = biais haussier, en dessous = baissier. Les croisements (golden cross, death cross) et le rôle de support/résistance dynamique en font un classique indémodable.",
    gauges: [
      { label: "Difficulté", value: 30, verdict: "Accessible", scheme: "good-low" },
      { label: "Popularité", value: 95, verdict: "Universelle", scheme: "good-high" },
    ],
    examples: [
      { title: "Golden cross", detail: "La moyenne 50 jours croise au-dessus de la 200 jours : signal de retournement haussier de moyen terme, très suivi médiatiquement." },
      { title: "Support dynamique", detail: "En forte tendance, le prix rebondit souvent sur sa moyenne mobile, qui agit comme un support qui « monte » avec lui." },
      { title: "EMA vs SMA", detail: "L'EMA réagit plus vite (poids aux prix récents) que la SMA. On choisit selon qu'on veut de la réactivité ou de la stabilité." },
    ],
    keyPoints: [
      "Prix au-dessus / en dessous = biais de tendance.",
      "Croisement court/long = signal de retournement suivi.",
      "Plates et entremêlées = absence de tendance (range).",
    ],
  },
  {
    slug: "momentum",
    n: 7,
    title: "Le momentum (RSI, MACD)",
    english: "Momentum",
    level: "Intermédiaire",
    illu: "momentum",
    summary: "Mesurer la vitesse et la force d'un mouvement — surachat, survente, divergences.",
    intro:
      "Le momentum mesure la vigueur d'un mouvement. Le RSI repère les excès (surachat > 70, survente < 30) ; le MACD suit la dynamique via l'écart de deux moyennes. Outils précieux, mais qui saturent en forte tendance.",
    gauges: [
      { label: "Difficulté", value: 55, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Utilité (en range)", value: 80, verdict: "Élevée", scheme: "good-high" },
    ],
    examples: [
      { title: "RSI en surachat", detail: "Un RSI au-dessus de 70 signale un possible excès — mais en forte tendance, il peut y rester longtemps. Le seuil seul ne suffit pas." },
      { title: "Divergence", detail: "Le prix fait un nouveau sommet, mais le RSI non : cette divergence baissière peut annoncer un essoufflement." },
      { title: "Croisement MACD", detail: "La ligne MACD passe au-dessus de sa ligne de signal et l'histogramme devient positif : bascule de momentum haussier." },
    ],
    keyPoints: [
      "Momentum = vitesse, pas direction absolue.",
      "Les seuils (70/30) sont des repères, pas des signaux automatiques.",
      "Les divergences sont des signaux avancés, à confirmer.",
    ],
  },
  {
    slug: "volatilite",
    n: 8,
    title: "La volatilité (Bollinger, ATR)",
    english: "Volatility",
    level: "Avancé",
    illu: "volatility",
    summary: "Mesurer l'agitation du marché pour dimensionner stops et positions.",
    intro:
      "La volatilité mesure l'amplitude des variations. Les bandes de Bollinger l'illustrent autour d'une moyenne ; l'ATR la chiffre. Elle ne donne aucune direction, mais elle est centrale pour placer ses stops et calibrer ses positions.",
    gauges: [
      { label: "Difficulté", value: 65, verdict: "Avancée", scheme: "good-low" },
      { label: "Utilité (gestion du risque)", value: 90, verdict: "Cruciale", scheme: "good-high" },
    ],
    examples: [
      { title: "Squeeze de Bollinger", detail: "Les bandes se resserrent fortement (faible volatilité) : souvent le calme avant une expansion brutale dans un sens ou l'autre." },
      { title: "ATR et stops", detail: "Un ATR élevé impose des stops plus larges et des positions plus petites pour conserver le même risque en montant." },
      { title: "Marcher la bande", detail: "En forte tendance, le prix peut « longer » la bande supérieure de Bollinger sans se retourner : toucher la bande n'est pas un signal." },
    ],
    keyPoints: [
      "Volatilité = amplitude, jamais direction.",
      "Bandes qui se resserrent = expansion souvent imminente.",
      "L'ATR sert à dimensionner stops et positions.",
    ],
  },
  {
    slug: "confluence-decision",
    n: 9,
    title: "La confluence & la décision",
    english: "Confluence & Decision",
    level: "Avancé",
    illu: "confluence",
    summary: "Assembler les pièces : combiner les signaux pour décider avec méthode.",
    intro:
      "Aucun outil ne suffit seul. La confluence — quand tendance, niveau, momentum et volume convergent — améliore nettement la probabilité. Le module final assemble tout : on attend l'alignement, on définit entrée/stop/objectif, on exécute sans émotion.",
    gauges: [
      { label: "Difficulté", value: 80, verdict: "Avancée", scheme: "good-low" },
      { label: "Impact sur la performance", value: 92, verdict: "Déterminant", scheme: "good-high" },
    ],
    examples: [
      { title: "Triple alignement", detail: "Un support qui coïncide avec un retracement de Fibonacci, une moyenne mobile et un marteau : chaque élément renforce les autres." },
      { title: "Tendance + niveau + déclencheur", detail: "La tendance donne le sens, le niveau donne le lieu, la bougie de retournement donne le moment. Un cadre robuste et simple." },
      { title: "Patience", detail: "Attendre que plusieurs facteurs s'alignent réduit la fréquence des trades mais augmente leur qualité. Mieux vaut peu et bon." },
    ],
    keyPoints: [
      "Un signal isolé est une opinion ; trois qui convergent, un dossier.",
      "Aligner les unités de temps renforce la confluence.",
      "On décide entrée/stop/objectif à froid, jamais dans l'émotion.",
    ],
  },
  {
    slug: "fibonacci-retracements",
    n: 10,
    title: "Fibonacci & retracements",
    english: "Fibonacci Retracements",
    level: "Avancé",
    illu: "fibonacci",
    summary: "Projeter des niveaux probables de correction — un outil de zones, pas de certitudes.",
    intro:
      "Les retracements de Fibonacci projettent des niveaux (38,2%, 50%, 61,8%) sur un mouvement pour repérer où une correction pourrait s'arrêter avant la reprise. C'est un repère probabiliste, utile surtout en confluence avec d'autres signaux.",
    gauges: [
      { label: "Difficulté", value: 60, verdict: "Avancée", scheme: "good-low" },
      { label: "Utilité (en confluence)", value: 70, verdict: "Bonne", scheme: "good-high" },
    ],
    examples: [
      { title: "Le niveau 61,8%", detail: "Le « golden ratio » est le retracement le plus surveillé. Une réaction du prix à ce niveau, confirmée, est très suivie." },
      { title: "Confluence", detail: "Un niveau de Fibonacci qui coïncide avec un support et une moyenne mobile vaut bien plus que le niveau seul." },
      { title: "Extensions pour objectifs", detail: "Au-delà de 100% (138,2%, 161,8%), les extensions servent de repères d'objectif quand la tendance dépasse le sommet précédent." },
    ],
    keyPoints: [
      "Tracer d'un creux à un sommet significatifs, pas sur du bruit.",
      "Fibonacci indique des zones où beaucoup d'acteurs regardent.",
      "Toujours attendre une réaction du prix au niveau.",
    ],
  },
  {
    slug: "volume-flux-ordres",
    n: 11,
    title: "Volume & flux d'ordres",
    english: "Volume & Order Flow",
    level: "Avancé",
    illu: "orderbook",
    summary: "Lire l'intensité derrière les mouvements — qui pousse vraiment, acheteurs ou vendeurs.",
    intro:
      "Le prix dit « quoi », le volume dit « avec quelle conviction ». Carnet d'ordres, profil de volume et flux d'ordres révèlent où se concentre la pression réelle. Des outils avancés, à manier avec recul (le carnet peut tromper).",
    gauges: [
      { label: "Difficulté", value: 75, verdict: "Avancée", scheme: "good-low" },
      { label: "Utilité (confirmation)", value: 82, verdict: "Élevée", scheme: "good-high" },
    ],
    examples: [
      { title: "Cassure avec volume", detail: "Une cassure de résistance accompagnée d'un fort volume est jugée bien plus fiable qu'une cassure « molle » sans volume." },
      { title: "Profil de volume", detail: "Le point de contrôle (niveau le plus échangé) agit souvent comme un aimant et un support/résistance majeur." },
      { title: "Divergence prix/volume", detail: "Un prix qui monte avec un volume décroissant trahit un manque de conviction — un signal d'essoufflement possible." },
    ],
    keyPoints: [
      "Le volume confirme (ou non) la conviction d'un mouvement.",
      "Le carnet d'ordres est instantané… et parfois manipulé.",
      "On combine volume et structure, jamais l'un sans l'autre.",
    ],
  },
  {
    slug: "analyse-multi-echelles",
    n: 12,
    title: "L'analyse multi-échelles",
    english: "Multi-Timeframe Analysis",
    level: "Avancé",
    illu: "channel",
    summary: "Lire plusieurs unités de temps ensemble pour décider dans le sens de la tendance de fond.",
    intro:
      "Un même actif raconte des histoires différentes selon l'échelle de temps. L'analyse multi-échelles consiste à définir la tendance de fond sur une grande unité, puis à affiner l'entrée sur une plus petite — pour aller dans le sens du courant.",
    gauges: [
      { label: "Difficulté", value: 70, verdict: "Avancée", scheme: "good-low" },
      { label: "Impact sur la qualité", value: 85, verdict: "Fort", scheme: "good-high" },
    ],
    examples: [
      { title: "Du général au particulier", detail: "Tendance haussière en hebdomadaire → on cherche des entrées à l'achat en journalier, pas des ventes à contre-courant." },
      { title: "Aligner les signaux", detail: "Un signal en 5 minutes vaut bien plus s'il va dans le sens de la tendance journalière. La confluence existe entre les échelles." },
      { title: "Éviter le bruit", detail: "Trop descendre en unité de temps multiplie le bruit et les faux signaux. On affine, on ne se noie pas." },
    ],
    keyPoints: [
      "Grande échelle = direction ; petite échelle = timing.",
      "On évite de trader contre la tendance de fond.",
      "Trois échelles suffisent (ex. hebdo / journalier / 4h).",
    ],
  },
  {
    slug: "backtest-journal",
    n: 13,
    title: "Backtester & tenir un journal",
    english: "Backtesting & Journaling",
    level: "Avancé",
    illu: "journal",
    summary: "Mesurer et apprendre — transformer l'expérience et les tests en progrès mesurable.",
    intro:
      "Une stratégie ne vaut que si on peut la vérifier et l'améliorer. Le backtest l'éprouve sur le passé, le journal l'éprouve en réel. Ensemble, ils remplacent l'intuition par des données — et révèlent ce qui marche vraiment.",
    gauges: [
      { label: "Difficulté", value: 65, verdict: "Avancée", scheme: "good-low" },
      { label: "Utilité (progression)", value: 95, verdict: "Cruciale", scheme: "good-high" },
    ],
    examples: [
      { title: "Backtest honnête", detail: "Inclure frais, spread et slippage, et tester sur des données hors échantillon : sinon on « sur-optimise » une stratégie qui échoue en réel." },
      { title: "Journal de décisions", detail: "Noter le pourquoi de chaque trade AVANT, puis le résultat : on sépare la qualité de la décision du hasard du résultat." },
      { title: "Métriques qui comptent", detail: "Taux de réussite, ratio gain/perte, drawdown, respect du plan : ce sont elles, pas le solde, qui mesurent les progrès." },
    ],
    keyPoints: [
      "Un backtest sur-optimisé ment ; intégrez frais et hors-échantillon.",
      "Le journal transforme l'expérience en apprentissage.",
      "On améliore ce qu'on mesure — sinon on répète ses erreurs.",
    ],
  },
  {
    slug: "divergences-rsi-macd",
    n: 14,
    title: "Les divergences (RSI / MACD)",
    english: "RSI / MACD Divergences",
    level: "Avancé",
    illu: "momentum",
    summary: "Quand le prix et l'oscillateur se contredisent — un signal avancé d'essoufflement.",
    intro:
      "Une divergence apparaît quand le prix et un oscillateur (RSI, MACD) ne racontent plus la même histoire. Le prix fait un nouveau sommet mais le momentum non : la dynamique s'épuise sous la surface. C'est un signal avancé, précieux mais à confirmer, car une divergence peut durer longtemps avant de payer.",
    gauges: [
      { label: "Difficulté", value: 70, verdict: "Avancée", scheme: "good-low" },
      { label: "Fiabilité (confirmée)", value: 60, verdict: "Correcte", scheme: "good-high" },
      { label: "Anticipation", value: 80, verdict: "Précoce", scheme: "good-high" },
    ],
    examples: [
      { title: "Divergence baissière", detail: "Le prix inscrit un sommet plus haut, mais le RSI un sommet plus bas : les acheteurs poussent encore, avec moins de force. Possible essoufflement." },
      { title: "Divergence haussière", detail: "Le prix fait un creux plus bas mais le MACD un creux plus haut : la pression vendeuse faiblit. Souvent en fin de correction." },
      { title: "Le piège du timing", detail: "Une divergence peut se prolonger sur plusieurs sommets avant le retournement. On attend une confirmation de prix (cassure, bougie) avant d'agir." },
    ],
    keyPoints: [
      "Divergence = désaccord entre le prix et le momentum.",
      "C'est un signal avancé, pas un déclencheur immédiat.",
      "On confirme toujours par une réaction du prix.",
      "Plus fiable aux extrêmes et en confluence avec un niveau.",
    ],
  },
  {
    slug: "bandes-bollinger-compression",
    n: 15,
    title: "Bandes de Bollinger & compression",
    english: "Bollinger Bands & Volatility Squeeze",
    level: "Intermédiaire",
    illu: "volatility",
    summary: "Lire la respiration de la volatilité — quand le calme précède l'expansion.",
    intro:
      "Les bandes de Bollinger encadrent le prix par une moyenne mobile et deux écarts-types. Elles se dilatent quand la volatilité monte et se resserrent quand elle s'apaise. Cette respiration est leur vrai enseignement : une forte compression précède souvent une expansion brutale, sans en donner le sens.",
    gauges: [
      { label: "Difficulté", value: 50, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Utilité (timing de volatilité)", value: 80, verdict: "Élevée", scheme: "good-high" },
      { label: "Indication de direction", value: 20, verdict: "Quasi nulle", scheme: "neutral" },
    ],
    examples: [
      { title: "Le squeeze", detail: "Les bandes se resserrent au plus étroit depuis des mois : faible volatilité. Souvent le calme avant une sortie franche, à la hausse ou à la baisse." },
      { title: "Marcher la bande", detail: "En forte tendance, le prix « longe » la bande supérieure sans se retourner. Toucher la bande n'est donc pas un signal de vente." },
      { title: "Retour à la moyenne", detail: "Hors tendance marquée, le prix oscille autour de la bande centrale : un excès vers une bande extrême tend à revenir vers le milieu." },
    ],
    keyPoints: [
      "Bandes resserrées = volatilité basse, expansion souvent imminente.",
      "Le squeeze indique le timing, jamais la direction.",
      "Toucher une bande n'est pas un signal en soi.",
      "On combine la compression avec la structure pour anticiper le sens.",
    ],
  },
  {
    slug: "ichimoku-lecture-ensemble",
    n: 16,
    title: "Ichimoku : la lecture d'ensemble",
    english: "Ichimoku Cloud",
    level: "Avancé",
    illu: "trend",
    summary: "Un système complet en un coup d'œil — tendance, support, momentum réunis.",
    intro:
      "L'Ichimoku Kinko Hyo regroupe en un seul outil tendance, niveaux et momentum. Son nuage (Kumo) sépare le haussier du baissier ; les lignes Tenkan et Kijun donnent l'élan ; la projection décalée anticipe le futur support. Touffu au début, il offre une lecture d'ensemble une fois apprivoisé.",
    gauges: [
      { label: "Difficulté", value: 78, verdict: "Avancée", scheme: "good-low" },
      { label: "Temps d'apprentissage", value: 75, verdict: "Conséquent", scheme: "good-low" },
      { label: "Richesse de lecture", value: 88, verdict: "Très complète", scheme: "good-high" },
    ],
    examples: [
      { title: "Au-dessus du nuage", detail: "Un prix nettement au-dessus d'un nuage épais et haussier traduit une tendance de fond solide. Le nuage devient un support potentiel." },
      { title: "Croisement Tenkan / Kijun", detail: "La ligne rapide (Tenkan) croise au-dessus de la lente (Kijun) au-dessus du nuage : signal d'élan haussier, l'un des plus suivis du système." },
      { title: "Épaisseur du Kumo", detail: "Un nuage épais offre un support/résistance robuste ; un nuage fin se franchit facilement. L'épaisseur mesure la solidité de la zone." },
    ],
    keyPoints: [
      "Le nuage sépare biais haussier (dessus) et baissier (dessous).",
      "Plus le Kumo est épais, plus la zone est fiable.",
      "On lit l'ensemble des lignes, jamais une seule isolée.",
      "Conçu pour les unités de temps larges et les tendances établies.",
    ],
  },
  {
    slug: "profil-volume-vwap",
    n: 17,
    title: "Profil de volume & VWAP",
    english: "Volume Profile & VWAP",
    level: "Avancé",
    illu: "orderbook",
    summary: "Voir le marché par prix, pas par temps — où le volume s'est réellement échangé.",
    intro:
      "Le profil de volume mesure le volume échangé à chaque niveau de prix, pas dans le temps. Il révèle les zones de forte activité (le point de contrôle) et les vides. Le VWAP, prix moyen pondéré par le volume, sert de référence aux gros intervenants. Ensemble, ils éclairent où se joue vraiment le rapport de force.",
    gauges: [
      { label: "Difficulté", value: 80, verdict: "Avancée", scheme: "good-low" },
      { label: "Utilité (zones clés)", value: 85, verdict: "Élevée", scheme: "good-high" },
      { label: "Usage institutionnel", value: 90, verdict: "Très répandu", scheme: "good-high" },
    ],
    examples: [
      { title: "Point de contrôle (POC)", detail: "Le niveau le plus échangé agit comme un aimant : le prix y revient souvent, et il forme un support/résistance majeur." },
      { title: "Zone de faible volume", detail: "Un « trou » dans le profil se traverse vite : peu d'ordres pour freiner le prix. Ces vides accélèrent souvent les mouvements." },
      { title: "VWAP comme référence", detail: "Beaucoup d'intervenants jugent leur exécution par rapport au VWAP de la séance ; un retour vers lui sert fréquemment de repère d'entrée." },
    ],
    keyPoints: [
      "Le profil de volume raisonne par prix, pas par temps.",
      "Le POC agit comme un aimant et un niveau majeur.",
      "Les zones creuses se franchissent vite, les zones denses freinent.",
      "Le VWAP est une référence d'exécution très suivie.",
    ],
  },
  {
    slug: "theorie-de-dow",
    n: 18,
    title: "La théorie de Dow",
    english: "Dow Theory",
    level: "Intermédiaire",
    illu: "trend",
    summary: "Les principes fondateurs de l'analyse technique moderne — toujours d'actualité.",
    intro:
      "Formulée il y a plus d'un siècle, la théorie de Dow pose les bases de l'analyse technique. Le marché évolue en tendances à trois échelles, le volume doit confirmer le mouvement, et une tendance se poursuit jusqu'à un signal clair de retournement. Des principes simples, qui irriguent encore toute la discipline.",
    gauges: [
      { label: "Difficulté", value: 40, verdict: "Modérée", scheme: "good-low" },
      { label: "Valeur fondatrice", value: 92, verdict: "Essentielle", scheme: "good-high" },
      { label: "Fréquence d'usage (directe)", value: 50, verdict: "Implicite", scheme: "neutral" },
    ],
    examples: [
      { title: "Trois tendances", detail: "Une tendance primaire (mois/années), une secondaire (corrections de semaines) et mineure (jours). On ne confond pas une correction avec un retournement." },
      { title: "Confirmation par le volume", detail: "Pour Dow, le volume doit accompagner la tendance primaire : un mouvement haussier sain s'accompagne d'un volume en expansion." },
      { title: "La tendance persiste", detail: "Une tendance reste en place tant qu'aucun signal net de retournement n'apparaît : pas de sommets/creux plus bas pour casser un mouvement haussier." },
    ],
    keyPoints: [
      "Le marché évolue en tendances à trois degrés.",
      "Le volume doit confirmer la tendance primaire.",
      "Une tendance se poursuit jusqu'à preuve claire du contraire.",
      "Ces principes sous-tendent l'analyse technique moderne.",
    ],
  },
  {
    slug: "correlations-inter-marches",
    n: 19,
    title: "Corrélations inter-marchés",
    english: "Intermarket Correlations",
    level: "Avancé",
    illu: "correlation",
    summary: "Actions, obligations, dollar, or : lire le marché comme un système connecté.",
    intro:
      "Aucun marché ne vit isolé. Actions, obligations, dollar et matières premières s'influencent en permanence. Comprendre ces liens — souvent un actif fort quand l'autre faiblit — situe une classe d'actifs dans un tableau d'ensemble. Attention : les corrélations sont instables et changent selon le régime économique.",
    gauges: [
      { label: "Difficulté", value: 75, verdict: "Avancée", scheme: "good-low" },
      { label: "Vision d'ensemble", value: 88, verdict: "Précieuse", scheme: "good-high" },
      { label: "Stabilité des liens", value: 35, verdict: "Variable", scheme: "neutral" },
    ],
    examples: [
      { title: "Dollar et matières premières", detail: "Cotées en dollars, les matières premières comme l'or tendent à évoluer à l'inverse du billet vert : un dollar fort pèse souvent sur elles." },
      { title: "Actions et obligations", detail: "En période de stress, les capitaux fuient vers les obligations d'État jugées sûres : leurs prix montent quand les actions chutent (fuite vers la qualité)." },
      { title: "Corrélation instable", detail: "Un lien historique peut s'inverser selon le contexte (inflation, politique monétaire). On vérifie la corrélation du moment, pas celle des manuels." },
    ],
    keyPoints: [
      "Les classes d'actifs forment un système connecté.",
      "Le dollar influence largement matières premières et émergents.",
      "Les obligations servent souvent de refuge face aux actions.",
      "Les corrélations sont instables : elles dépendent du régime.",
    ],
  },
  {
    slug: "analyse-top-down",
    n: 20,
    title: "L'analyse top-down (macro → titre)",
    english: "Top-Down Analysis",
    level: "Avancé",
    illu: "rotation",
    summary: "Du contexte global au titre précis — une démarche en entonnoir, méthodique.",
    intro:
      "L'analyse top-down part du plus large pour resserrer progressivement. On évalue d'abord le contexte macro et le cycle, puis on sélectionne les secteurs porteurs, et enfin on choisit les meilleurs titres au sein de ces secteurs. Cette démarche en entonnoir met les probabilités de son côté en allant dans le sens des grands courants.",
    gauges: [
      { label: "Difficulté", value: 72, verdict: "Avancée", scheme: "good-low" },
      { label: "Structuration de la décision", value: 90, verdict: "Forte", scheme: "good-high" },
      { label: "Couverture (macro→titre)", value: 85, verdict: "Complète", scheme: "good-high" },
    ],
    examples: [
      { title: "Niveau macro", detail: "Cycle économique, taux et inflation fixent le décor : ils déterminent les classes d'actifs et les secteurs favorisés ou pénalisés du moment." },
      { title: "Niveau secteur", detail: "Dans un cycle donné, certains secteurs surperforment (rotation sectorielle). On privilégie les secteurs en force relative avant de descendre au titre." },
      { title: "Niveau titre", detail: "Au sein d'un secteur porteur, on retient les leaders les plus solides : aller dans le sens du courant à chaque étape de l'entonnoir." },
    ],
    keyPoints: [
      "Du plus large au plus précis : macro, puis secteur, puis titre.",
      "Le cycle et les taux orientent les secteurs gagnants.",
      "On privilégie la force relative à chaque étage.",
      "L'entonnoir aligne le titre choisi avec les grands courants.",
    ],
  },
{
    slug: "psychologie-sentiment-marche",
    n: 21,
    title: "Psychologie de marché & sentiment",
    english: "Market Psychology & Sentiment",
    level: "Intermédiaire",
    illu: "emotions",
    summary: "Le marché oscille entre peur et avidité : lire le sentiment dominant comme un repère de contexte.",
    intro:
      "Derrière chaque cours se cachent des décisions humaines, donc des émotions collectives. Le marché alterne phases d'euphorie et de panique, et ces extrêmes laissent des traces lisibles. Comprendre le sentiment dominant aide à situer une phase de marché — non à prédire le prochain mouvement. Le sentiment est un contexte, jamais un signal isolé.",
    gauges: [
      { label: "Difficulté", value: 45, verdict: "Modérée", scheme: "good-low" },
      { label: "Utilité comme contexte", value: 80, verdict: "Élevée", scheme: "good-high" },
      { label: "Fiabilité en signal seul", value: 30, verdict: "Faible", scheme: "good-low" },
    ],
    examples: [
      { title: "Euphorie de fin de cycle", detail: "Quand le grand public se passionne pour un actif et que tout le monde semble gagner facilement, l'optimisme extrême marque souvent une phase de marché tardive." },
      { title: "Peur extrême", detail: "Lors d'une panique, les ventes deviennent indiscriminées : la peur prend le pas sur l'analyse. Ces phases d'extrême pessimisme s'observent a posteriori sur les volumes et l'amplitude." },
      { title: "Indices de sentiment", detail: "Des baromètres comme l'indice peur/avidité agrègent plusieurs mesures (volatilité, flux, amplitude) pour situer l'humeur du moment. On les lit comme un thermomètre, pas comme un ordre." },
    ],
    keyPoints: [
      "Le marché traduit des émotions collectives : peur et avidité.",
      "Les extrêmes de sentiment signalent souvent des phases tardives.",
      "Le sentiment est un contexte, jamais un signal isolé.",
      "Un thermomètre se lit, il ne déclenche pas une décision.",
    ],
  },
  {
    slug: "phases-wyckoff",
    n: 22,
    title: "Les phases de Wyckoff",
    english: "Wyckoff Phases",
    level: "Avancé",
    illu: "cycle",
    summary: "Accumulation, hausse, distribution, baisse : lire le cycle laissé par les gros opérateurs.",
    intro:
      "La méthode de Wyckoff décrit le marché comme un cycle en quatre temps : accumulation discrète, phase de hausse, distribution, puis baisse. L'idée centrale est qu'un « opérateur composite » construit puis liquide ses positions par étapes, laissant des traces dans le prix et le volume. C'est un cadre de lecture du contexte, exigeant et toujours probabiliste.",
    gauges: [
      { label: "Difficulté", value: 78, verdict: "Avancée", scheme: "good-low" },
      { label: "Cadre structurant", value: 85, verdict: "Fort", scheme: "good-high" },
      { label: "Part de subjectivité", value: 55, verdict: "Notable", scheme: "neutral" },
    ],
    examples: [
      { title: "Accumulation", detail: "Après une longue baisse, le prix s'aplatit dans une fourchette : les volumes de vente s'épuisent pendant qu'un acheteur patient absorbe l'offre, en silence." },
      { title: "Distribution", detail: "Après une longue hausse, le prix plafonne dans un range : les hausses peinent à tenir et le volume trahit une cession progressive des positions." },
      { title: "Ressort et test", detail: "Une fausse cassure sous le support (le « spring ») suivie d'un retour rapide dans le range est lue par les wyckoffiens comme un piège à vendeurs en fin d'accumulation." },
    ],
    keyPoints: [
      "Quatre phases : accumulation, hausse, distribution, baisse.",
      "Le volume valide ou contredit le mouvement du prix.",
      "Les fausses cassures peuvent piéger la foule en fin de phase.",
      "Cadre exigeant et subjectif : il décrit, il ne garantit rien.",
    ],
  },
  {
    slug: "price-action-pur",
    n: 23,
    title: "Le price action pur",
    english: "Pure Price Action",
    level: "Intermédiaire",
    illu: "chart-anatomy",
    summary: "Lire le marché sans aucun indicateur : prix, structure et bougies seulement.",
    intro:
      "Le price action consiste à décider à partir du seul prix, sans indicateur. On lit la structure (sommets et creux), les zones réactives et le comportement des bougies. L'avantage est la réactivité et la clarté ; l'exigence est une lecture disciplinée, car le prix nu laisse peu de filtres. C'est une approche, pas une recette infaillible.",
    gauges: [
      { label: "Difficulté", value: 60, verdict: "Soutenue", scheme: "good-low" },
      { label: "Réactivité (pas de retard)", value: 90, verdict: "Excellente", scheme: "good-high" },
      { label: "Encombrement du graphique", value: 15, verdict: "Minimal", scheme: "good-low" },
    ],
    examples: [
      { title: "Rejet sur zone", detail: "Une longue mèche qui repousse le prix hors d'une zone clé traduit un déséquilibre immédiat entre acheteurs et vendeurs, sans qu'aucun indicateur ne soit nécessaire." },
      { title: "Structure de marché", detail: "Une suite de sommets plus hauts qui cesse, suivie d'un premier creux plus bas, signale par le prix seul un possible changement de structure." },
      { title: "Compression avant cassure", detail: "Des bougies de plus en plus petites contre un niveau indiquent une perte d'amplitude : l'énergie se comprime avant une sortie, lisible directement sur la bougie." },
    ],
    keyPoints: [
      "Le prix d'abord : aucun indicateur, donc aucun retard.",
      "On lit la structure, les zones et le langage des bougies.",
      "Graphique épuré = lecture plus claire mais plus exigeante.",
      "Une approche réactive, jamais une certitude.",
    ],
  },
  {
    slug: "zones-offre-demande",
    n: 24,
    title: "Zones d'offre & de demande",
    english: "Supply & Demand Zones",
    level: "Intermédiaire",
    illu: "support-resistance",
    summary: "Repérer les zones d'où le prix est parti vivement : déséquilibres entre acheteurs et vendeurs.",
    intro:
      "Une zone de demande est l'origine d'un mouvement haussier vif ; une zone d'offre, l'origine d'une chute nette. L'idée est qu'un déséquilibre d'ordres y subsiste et que le prix peut y réagir lors d'un retour. Ces zones prolongent la logique du support/résistance en insistant sur la base du mouvement, pas seulement sur les contacts.",
    gauges: [
      { label: "Difficulté", value: 50, verdict: "Modérée", scheme: "good-low" },
      { label: "Précision des entrées", value: 78, verdict: "Bonne", scheme: "good-high" },
      { label: "Fiabilité d'une zone seule", value: 45, verdict: "Variable", scheme: "neutral" },
    ],
    examples: [
      { title: "Base avant impulsion", detail: "Une petite zone de consolidation d'où le prix s'envole laisse une « base » : lors d'un retour, les acheteurs absents peuvent y revenir, créant une réaction." },
      { title: "Zone fraîche vs usée", detail: "Une zone non encore retestée est jugée plus « fraîche » : chaque test consomme une partie des ordres en attente et affaiblit la zone au fil du temps." },
      { title: "Offre au sommet", detail: "Le palier d'où part une chute brutale marque une zone d'offre : les vendeurs y avaient déposé des ordres, susceptibles de freiner un futur retour." },
    ],
    keyPoints: [
      "La zone naît de l'origine d'un mouvement vif, pas d'un simple contact.",
      "Une zone fraîche, non retestée, est jugée plus solide.",
      "Chaque test consomme les ordres et use la zone.",
      "Une zone se confirme par la réaction, jamais par avance.",
    ],
  },
  {
    slug: "styles-scalping-swing-position",
    n: 25,
    title: "Styles : scalping, swing, position",
    english: "Trading Styles: Scalping, Swing, Position",
    level: "Intermédiaire",
    illu: "horizon",
    summary: "Du très court terme au long terme : choisir un style cohérent avec son temps et son tempérament.",
    intro:
      "Le scalping vise de très courts mouvements en minutes ; le swing trading suit des vagues de quelques jours à semaines ; le trading de position s'inscrit sur des semaines à mois. Aucun n'est supérieur : chacun impose un rythme, une charge mentale et des contraintes propres. Le bon style est d'abord celui qui colle à son horizon et à son tempérament.",
    gauges: [
      { label: "Difficulté de choix", value: 40, verdict: "Modérée", scheme: "good-low" },
      { label: "Importance de la cohérence", value: 92, verdict: "Capitale", scheme: "good-high" },
      { label: "Charge mentale du scalping", value: 85, verdict: "Très élevée", scheme: "neutral" },
    ],
    examples: [
      { title: "Scalping", detail: "Des dizaines de prises de position courtes dans la journée : exige concentration intense, frais maîtrisés et exécution rapide. Le temps de cerveau disponible est le vrai coût." },
      { title: "Swing", detail: "On suit une vague de plusieurs jours et on laisse respirer la position : moins d'opérations, moins de frais, mais il faut accepter de tenir à travers le bruit quotidien." },
      { title: "Position", detail: "On vise une tendance de fond sur plusieurs mois : peu de décisions, forte patience, et une tolérance aux mouvements adverses temporaires plus large." },
    ],
    keyPoints: [
      "Trois horizons : minutes, jours/semaines, semaines/mois.",
      "Aucun style n'est meilleur : tout dépend de la cohérence.",
      "Le scalping a la charge mentale et le poids des frais les plus lourds.",
      "Choisir selon son temps réel et son tempérament, pas la mode.",
    ],
  },
  {
    slug: "gestion-position-pyramidage-scaling",
    n: 26,
    title: "Gestion avancée : pyramidage & scaling out",
    english: "Pyramiding & Scaling Out",
    level: "Avancé",
    illu: "plan",
    summary: "Renforcer une position gagnante ou alléger par paliers : moduler l'exposition avec méthode.",
    intro:
      "Plutôt que d'entrer et sortir en une seule fois, on peut moduler l'exposition par paliers. Le pyramidage ajoute à une position qui évolue favorablement ; le scaling out allège progressivement pour sécuriser des gains. Bien encadrées, ces techniques affinent la gestion ; mal employées, elles amplifient le risque. Le cadre prime toujours sur l'envie d'en faire plus.",
    gauges: [
      { label: "Difficulté", value: 80, verdict: "Avancée", scheme: "good-low" },
      { label: "Finesse de gestion", value: 82, verdict: "Élevée", scheme: "good-high" },
      { label: "Risque si mal encadré", value: 70, verdict: "Important", scheme: "good-low" },
    ],
    examples: [
      { title: "Pyramidage prudent", detail: "On ajoute à une position en gain en réduisant la taille de chaque renfort et en remontant le stop : le prix de revient évolue mais le risque global reste borné." },
      { title: "Scaling out", detail: "On vend une fraction à un premier objectif, une autre plus loin, et on laisse courir le reste : on capture des gains tout en gardant une exposition au mouvement." },
      { title: "Erreur classique", detail: "Renforcer une position perdante pour « moyenner à la baisse » sans plan transforme une petite perte en perte lourde : c'est l'inverse d'une gestion encadrée." },
    ],
    keyPoints: [
      "Pyramidage = ajouter sur du gagnant, jamais sur du perdant à l'aveugle.",
      "Scaling out = alléger par paliers pour sécuriser des gains.",
      "Réduire la taille des renforts garde le risque global borné.",
      "Le cadre prime sur l'envie d'augmenter l'exposition.",
    ],
  },
  {
    slug: "lire-utiliser-screener",
    n: 27,
    title: "Lire & utiliser un screener",
    english: "Reading & Using a Screener",
    level: "Intermédiaire",
    illu: "rotation",
    summary: "Filtrer des milliers de titres selon des critères objectifs pour bâtir une liste de travail.",
    intro:
      "Un screener filtre l'univers des titres selon des critères mesurables : capitalisation, volume, performance, ratios. Il ne dit jamais quoi faire ; il réduit le bruit pour faire émerger une liste de candidats à analyser. Bien paramétré, c'est un gain de temps majeur ; mal pensé, il produit du bruit ou rate l'essentiel. C'est un entonnoir, pas un oracle.",
    gauges: [
      { label: "Difficulté", value: 35, verdict: "Accessible", scheme: "good-low" },
      { label: "Gain de temps", value: 88, verdict: "Majeur", scheme: "good-high" },
      { label: "Qualité = qualité des critères", value: 90, verdict: "Déterminante", scheme: "good-high" },
    ],
    examples: [
      { title: "Filtre de liquidité", detail: "Exiger un volume quotidien minimal écarte les titres trop peu échangés, où le spread et le risque d'exécution sont élevés. C'est souvent le premier filtre posé." },
      { title: "Force relative", detail: "Filtrer les titres dont la performance dépasse celle de l'indice fait remonter les leaders du moment, base d'une liste de travail orientée force relative." },
      { title: "Filtre trop serré", detail: "Empiler trop de critères peut ne renvoyer que deux ou trois titres et masquer des opportunités : on élargit alors les bornes pour retrouver un univers exploitable." },
    ],
    keyPoints: [
      "Le screener filtre selon des critères objectifs et mesurables.",
      "Il produit une liste de candidats, pas une décision.",
      "La qualité du résultat dépend de la qualité des critères.",
      "Trop de filtres tue l'univers : ajuster les bornes avec mesure.",
    ],
  },
  {
    slug: "systeme-mecanique-simple",
    n: 28,
    title: "Construire un système mécanique simple",
    english: "Building a Simple Mechanical System",
    level: "Avancé",
    illu: "plan",
    summary: "Des règles écrites, testables et répétables : retirer l'émotion de la décision.",
    intro:
      "Un système mécanique transforme une idée en règles précises : conditions d'entrée, de sortie, taille de position et gestion du risque. L'objectif est la répétabilité et la testabilité, pour décider sans émotion. La simplicité est une force : un système clair se teste, se suit et se corrige, là où un système trop complexe devient impossible à valider et fragile.",
    gauges: [
      { label: "Difficulté", value: 75, verdict: "Avancée", scheme: "good-low" },
      { label: "Discipline apportée", value: 90, verdict: "Forte", scheme: "good-high" },
      { label: "Avantage de la simplicité", value: 85, verdict: "Élevé", scheme: "good-high" },
    ],
    examples: [
      { title: "Règles non ambiguës", detail: "« Entrer si A et B sont vrais, sortir si C » se teste et se reproduit à l'identique : deux personnes appliquant le système prennent la même décision." },
      { title: "Risque défini d'avance", detail: "Le système fixe la taille de position et le stop avant l'entrée : le risque par opération est connu, condition de base d'une courbe d'équité maîtrisée." },
      { title: "Sur-optimisation", detail: "Ajouter des règles jusqu'à un passé « parfait » donne un système surajusté qui s'effondre en réel : la robustesse prime sur la performance historique flatteuse." },
    ],
    keyPoints: [
      "Des règles écrites : entrée, sortie, taille, risque.",
      "Répétable et testable = décision sans émotion.",
      "La simplicité se teste et se corrige ; la complexité fragilise.",
      "Méfiance envers la sur-optimisation : viser la robustesse.",
    ],
  },
{
    slug: "lire-profondeur-marche-dom",
    n: 29,
    title: "Lire la profondeur de marché (DOM / Level 2)",
    english: "Reading Market Depth (DOM / Level 2)",
    level: "Avancé",
    illu: "orderbook",
    summary: "Observer les ordres en attente de part et d'autre du prix pour lire l'offre et la demande immédiates.",
    intro:
      "La profondeur de marché, ou carnet d'ordres de niveau 2, affiche les ordres limites en attente à chaque prix, à l'achat comme à la vente. Elle donne une photographie de l'offre et de la demande à l'instant T. C'est un outil de lecture du flux, pas une boule de cristal : le carnet bouge en permanence, des ordres apparaissent et disparaissent, et rien n'oblige une grosse pile à être exécutée. On y lit une pression probable, jamais une certitude.",
    gauges: [
      { label: "Difficulté de lecture", value: 82, verdict: "Avancée", scheme: "good-low" },
      { label: "Finesse sur le court terme", value: 80, verdict: "Élevée", scheme: "good-high" },
      { label: "Fiabilité comme prédiction", value: 30, verdict: "Faible", scheme: "neutral" },
    ],
    examples: [
      { title: "Déséquilibre du carnet", detail: "Une accumulation d'ordres à l'achat nettement supérieure à l'offre vendeuse traduit une pression acheteuse momentanée : repère pédagogique de flux, pas un signal d'entrée." },
      { title: "Mur d'ordres", detail: "Une pile imposante affichée à un prix peut freiner le mouvement, mais elle peut aussi être retirée à la dernière seconde : un mur visible n'est jamais un mur garanti." },
      { title: "Carnet clairsemé", detail: "Peu d'ordres de chaque côté signale un marché peu profond où le prix saute d'un palier à l'autre : la lecture du DOM révèle alors surtout un risque de mouvements brusques." },
    ],
    keyPoints: [
      "Le DOM montre les ordres limites en attente, à l'achat et à la vente.",
      "C'est une photo instantanée du flux, qui change en permanence.",
      "Un mur affiché peut être retiré : aucune pile n'est une certitude.",
      "On y lit une pression probable, jamais une prédiction du prix.",
    ],
  },
  {
    slug: "slippage-qualite-execution",
    n: 30,
    title: "Slippage & qualité d'exécution",
    english: "Slippage & Execution Quality",
    level: "Intermédiaire",
    illu: "spread",
    summary: "Comprendre l'écart entre le prix visé et le prix obtenu, et ce qui dégrade une exécution.",
    intro:
      "Le slippage est l'écart entre le prix attendu et le prix réellement obtenu. Il naît de la liquidité, de la volatilité et du type d'ordre employé. Un ordre au marché privilégie la certitude d'exécution au prix d'un dérapage possible ; un ordre limite protège le prix mais risque la non-exécution. La qualité d'exécution est un coût caché qui s'additionne dans la durée : la mesurer, c'est déjà la maîtriser.",
    gauges: [
      { label: "Impact sur le coût total", value: 78, verdict: "Significatif", scheme: "good-low" },
      { label: "Sensibilité à la liquidité", value: 85, verdict: "Forte", scheme: "neutral" },
      { label: "Maîtrise par le type d'ordre", value: 75, verdict: "Réelle", scheme: "good-high" },
    ],
    examples: [
      { title: "Marché vs limite", detail: "Un ordre au marché s'exécute presque sûrement mais peut déraper sur un titre peu liquide ; un ordre limite verrouille le prix au risque de rester non rempli." },
      { title: "Slippage en news", detail: "Lors d'une annonce, le prix se déplace si vite que l'écart entre clic et exécution s'élargit : la volatilité extrême est un terrain classique de dérapage." },
      { title: "Coût cumulé", detail: "Un faible slippage par opération paraît négligeable, mais multiplié par des centaines d'ordres il ronge la performance : c'est un poste à mesurer, pas à ignorer." },
    ],
    keyPoints: [
      "Le slippage est l'écart entre prix visé et prix obtenu.",
      "Il dépend de la liquidité, de la volatilité et du type d'ordre.",
      "Marché = certitude d'exécution ; limite = protection du prix.",
      "C'est un coût caché qui s'additionne : le mesurer pour le réduire.",
    ],
  },
  {
    slug: "regimes-marche-tendance-retour-moyenne",
    n: 31,
    title: "Régimes de marché : tendance vs retour à la moyenne",
    english: "Market Regimes: Trending vs Mean-Reverting",
    level: "Avancé",
    illu: "cycle",
    summary: "Distinguer les phases où le prix tend de celles où il oscille autour d'une moyenne.",
    intro:
      "Un marché alterne entre des régimes : en tendance, les mouvements se prolongent ; en retour à la moyenne, le prix oscille autour d'un niveau d'équilibre. Une approche taillée pour la tendance se comporte souvent mal en range, et inversement. Reconnaître le régime dominant est un exercice de lecture, pas de prédiction : les régimes changent sans prévenir, et l'enjeu pédagogique est d'éviter d'appliquer le mauvais outil au mauvais contexte.",
    gauges: [
      { label: "Difficulté d'identification", value: 72, verdict: "Élevée", scheme: "good-low" },
      { label: "Importance pour le contexte", value: 88, verdict: "Majeure", scheme: "good-high" },
      { label: "Stabilité d'un régime", value: 40, verdict: "Variable", scheme: "neutral" },
    ],
    examples: [
      { title: "Phase de tendance", detail: "Les sommets et creux montent (ou descendent) régulièrement : une logique de suivi de tendance y trouve un terrain favorable, là où parier sur un retour rapide déçoit." },
      { title: "Phase de range", detail: "Le prix bute sur des bornes hautes et basses et y revient : un raisonnement de retour à la moyenne s'y illustre mieux qu'une poursuite de cassure." },
      { title: "Changement de régime", detail: "Un range qui dure peut casser brutalement et basculer en tendance : appliquer l'outil de l'ancien régime au nouveau est une erreur de contexte classique." },
    ],
    keyPoints: [
      "Deux régimes types : tendance prolongée et oscillation autour d'une moyenne.",
      "Un outil adapté à un régime se comporte mal dans l'autre.",
      "Reconnaître le régime, c'est lire un contexte, pas prédire.",
      "Les régimes changent sans prévenir : rester souple.",
    ],
  },
  {
    slug: "correlation-beta-en-pratique",
    n: 32,
    title: "Corrélation & bêta en pratique",
    english: "Correlation & Beta in Practice",
    level: "Intermédiaire",
    illu: "correlation",
    summary: "Mesurer comment deux actifs bougent ensemble et l'amplitude d'un titre face à son marché.",
    intro:
      "La corrélation décrit dans quelle mesure deux actifs évoluent dans le même sens ; le bêta mesure l'amplitude d'un titre par rapport à son marché de référence. Ces deux repères éclairent le risque réel d'un portefeuille : des positions très corrélées concentrent le risque même si elles paraissent variées. Ce sont des mesures statistiques rétrospectives, instables dans le temps : utiles pour comprendre, dangereuses si on les croit gravées dans le marbre.",
    gauges: [
      { label: "Difficulté", value: 58, verdict: "Moyenne", scheme: "good-low" },
      { label: "Utilité pour le risque global", value: 86, verdict: "Forte", scheme: "good-high" },
      { label: "Stabilité dans le temps", value: 35, verdict: "Faible", scheme: "neutral" },
    ],
    examples: [
      { title: "Diversification illusoire", detail: "Cinq titres du même secteur fortement corrélés bougent presque ensemble : le portefeuille paraît varié mais concentre en réalité un seul risque." },
      { title: "Lecture du bêta", detail: "Un bêta supérieur à 1 indique un titre qui amplifie les mouvements du marché ; inférieur à 1, il les atténue. C'est un repère d'amplitude, pas une garantie." },
      { title: "Corrélation qui saute", detail: "En période de stress, des actifs habituellement décorrélés tombent ensemble : la corrélation calculée en temps calme ne tient plus quand on en aurait le plus besoin." },
    ],
    keyPoints: [
      "Corrélation = sens commun ; bêta = amplitude face au marché.",
      "Des positions corrélées concentrent le risque malgré l'apparence.",
      "Ce sont des mesures rétrospectives et instables.",
      "En crise, les corrélations tendent à converger vers le haut.",
    ],
  },
  {
    slug: "construire-backtest-pas-a-pas",
    n: 33,
    title: "Construire un backtest pas à pas",
    english: "Building a Backtest Step by Step",
    level: "Avancé",
    illu: "journal",
    summary: "Tester une idée sur des données passées avec méthode, en évitant les pièges classiques.",
    intro:
      "Un backtest applique des règles précises à des données historiques pour estimer comment une idée se serait comportée. La démarche se construit par étapes : règles non ambiguës, données propres, prise en compte des frais et du slippage, puis lecture honnête des résultats. Le passé ne se répète jamais à l'identique : un backtest mesure une plausibilité, pas une promesse. Les pièges — biais de survivance, look-ahead, surajustement — peuvent rendre des résultats brillants totalement trompeurs.",
    gauges: [
      { label: "Difficulté", value: 80, verdict: "Avancée", scheme: "good-low" },
      { label: "Valeur de la rigueur", value: 92, verdict: "Capitale", scheme: "good-high" },
      { label: "Risque de biais cachés", value: 78, verdict: "Important", scheme: "good-low" },
    ],
    examples: [
      { title: "Frais et slippage inclus", detail: "Un backtest sans coûts ni dérapage surestime la performance : intégrer frais et slippage rapproche le test de la réalité d'exécution." },
      { title: "Biais de look-ahead", detail: "Utiliser une donnée qui n'était pas encore connue à l'instant testé fausse tout : chaque décision ne doit s'appuyer que sur l'information disponible à ce moment." },
      { title: "Surajustement", detail: "Affiner les règles jusqu'à un passé parfait produit une courbe flatteuse qui s'effondre en réel : viser la robustesse, pas la performance historique maximale." },
    ],
    keyPoints: [
      "Un backtest applique des règles précises à des données passées.",
      "Inclure frais et slippage pour rester réaliste.",
      "Se méfier du look-ahead, du biais de survivance et du surajustement.",
      "Le résultat est une plausibilité, jamais une promesse de futur.",
    ],
  },
  {
    slug: "metriques-journal-esperance-profit-factor",
    n: 34,
    title: "Métriques d'un journal : espérance & profit factor",
    english: "Journal Metrics: Expectancy & Profit Factor",
    level: "Intermédiaire",
    illu: "journal",
    summary: "Lire un journal de trading par les chiffres : ce que rapporte en moyenne une opération.",
    intro:
      "Un journal devient puissant quand on le lit par ses métriques. L'espérance estime le gain (ou la perte) moyen par opération ; le profit factor rapporte la somme des gains à la somme des pertes. Ces chiffres ne disent rien d'un trade isolé : ils décrivent un comportement statistique sur un grand nombre d'opérations. Ce sont des repères pédagogiques de lecture, pas des objectifs à atteindre ni des promesses de résultat.",
    gauges: [
      { label: "Difficulté", value: 50, verdict: "Moyenne", scheme: "good-low" },
      { label: "Utilité pour s'évaluer", value: 90, verdict: "Forte", scheme: "good-high" },
      { label: "Besoin d'un échantillon large", value: 85, verdict: "Élevé", scheme: "neutral" },
    ],
    examples: [
      { title: "Espérance", detail: "Elle combine taux de réussite et rapport gain/perte moyen : un système peut gagner souvent et perdre gros, ou se tromper souvent en gagnant gros. Le chiffre éclaire l'ensemble." },
      { title: "Profit factor", detail: "Un profit factor supérieur à 1 indique que la somme des gains dépasse celle des pertes sur la période ; en dessous, l'inverse. C'est un repère de lecture, pas une cible." },
      { title: "Échantillon trop court", detail: "Calculer ces métriques sur dix opérations ne dit presque rien : la chance domine. Il faut un nombre suffisant de trades pour que les chiffres signifient quelque chose." },
    ],
    keyPoints: [
      "L'espérance = gain ou perte moyen par opération.",
      "Le profit factor = somme des gains sur somme des pertes.",
      "Ces métriques décrivent un comportement, pas un trade isolé.",
      "Elles n'ont de sens que sur un échantillon suffisamment large.",
    ],
  },
  {
    slug: "initiation-value-at-risk-var",
    n: 35,
    title: "Initiation à la value at risk (VaR)",
    english: "Introduction to Value at Risk (VaR)",
    level: "Avancé",
    illu: "drawdown",
    summary: "Estimer une perte potentielle d'un portefeuille à un horizon et un seuil de probabilité donnés.",
    intro:
      "La value at risk estime la perte qu'un portefeuille ne devrait pas dépasser, sur un horizon donné et avec un niveau de confiance choisi. C'est un langage commun pour parler d'ampleur du risque. Mais la VaR a une faiblesse majeure : elle ne dit rien de ce qui se passe au-delà du seuil, dans les scénarios extrêmes. Comprise comme un repère parmi d'autres, elle éclaire ; prise pour une borne infranchissable, elle endort.",
    gauges: [
      { label: "Difficulté", value: 82, verdict: "Avancée", scheme: "good-low" },
      { label: "Utilité comme repère", value: 75, verdict: "Réelle", scheme: "good-high" },
      { label: "Aveuglement aux extrêmes", value: 80, verdict: "Important", scheme: "neutral" },
    ],
    examples: [
      { title: "Lecture d'une VaR", detail: "« Une VaR à 95 % sur un jour » décrit une perte que le portefeuille ne devrait pas dépasser 95 % du temps : c'est une estimation de probabilité, pas un plafond garanti." },
      { title: "Le hic des queues", detail: "La VaR ne dit rien de l'ampleur des 5 % de cas restants : une crise peut produire une perte bien supérieure au chiffre annoncé. Elle ignore les scénarios de queue." },
      { title: "Faux sentiment de sécurité", detail: "Croire qu'une VaR faible signifie « peu de risque » est trompeur : c'est précisément dans les rares cas exclus que surviennent les pertes qui marquent." },
    ],
    keyPoints: [
      "La VaR estime une perte à un horizon et un seuil de probabilité.",
      "C'est une estimation statistique, pas une borne garantie.",
      "Elle ignore l'ampleur des pertes au-delà du seuil.",
      "Un repère utile parmi d'autres, jamais une sécurité absolue.",
    ],
  },
  {
    slug: "sang-froid-sous-pression",
    n: 36,
    title: "Garder son sang-froid sous pression",
    english: "Staying Calm Under Pressure",
    level: "Intermédiaire",
    illu: "emotions",
    summary: "Reconnaître les réactions du stress et s'appuyer sur des routines pour décider à froid.",
    intro:
      "Sous pression, le cerveau bascule en mode réactif : la peur pousse à fuir, l'avidité à forcer, et le besoin de « se refaire » à enchaîner les erreurs. Garder son sang-froid n'est pas une question de volonté brute mais de préparation : un plan écrit, un risque défini d'avance et des routines réduisent la place laissée à l'émotion dans l'instant. Ce module est un repère pédagogique sur le comportement, jamais un conseil d'agir.",
    gauges: [
      { label: "Difficulté de maîtrise", value: 78, verdict: "Élevée", scheme: "good-low" },
      { label: "Poids dans les résultats", value: 90, verdict: "Majeur", scheme: "good-high" },
      { label: "Effet d'un plan préparé", value: 85, verdict: "Fort", scheme: "good-high" },
    ],
    examples: [
      { title: "Le besoin de se refaire", detail: "Après une perte, vouloir la récupérer immédiatement pousse à des décisions impulsives et à un risque accru : reconnaître ce réflexe est la première parade." },
      { title: "Décider à froid", detail: "Un plan rédigé avant l'ouverture transfère la décision d'un moment calme à un moment de tension : on exécute une règle préparée plutôt que de réagir à chaud." },
      { title: "La pause comme outil", detail: "S'imposer une pause après une série de pertes coupe la spirale émotionnelle : s'éloigner de l'écran est souvent la décision la plus disciplinée du moment." },
    ],
    keyPoints: [
      "Le stress fait basculer en mode réactif : peur, avidité, revanche.",
      "Le sang-froid se prépare, il ne s'improvise pas dans l'instant.",
      "Plan écrit et risque défini d'avance réduisent la place de l'émotion.",
      "Une pause assumée vaut mieux qu'une décision à chaud.",
    ],
  },
  {
    slug: "dimensionnement-critere-kelly",
    n: 37,
    title: "Dimensionnement de position & critère de Kelly",
    english: "Position Sizing & the Kelly Criterion",
    level: "Avancé",
    illu: "risk-reward",
    summary: "Comprendre la formule qui relie probabilité de gain et taille optimale d'une position — et pourquoi on la divise.",
    intro:
      "Le critère de Kelly, formulé par le physicien John L. Kelly Jr. chez Bell Labs en 1956, propose une taille de mise « optimale » pour maximiser la croissance d'un capital à long terme, en fonction de l'espérance et du rapport gain/perte. Sur le papier, il maximise la croissance géométrique ; en pratique, il produit des positions si grandes que la moindre erreur d'estimation est ruineuse. C'est pourquoi les praticiens utilisent un « fractional Kelly » (un demi, un quart). Ce module explique la logique, pas une formule à appliquer aveuglément.",
    gauges: [
      { label: "Difficulté", value: 85, verdict: "Avancée", scheme: "good-low" },
      { label: "Rigueur mathématique", value: 88, verdict: "Forte", scheme: "good-high" },
      { label: "Danger en pleine dose", value: 90, verdict: "Élevé", scheme: "neutral" },
    ],
    examples: [
      { title: "La formule de base", detail: "Kelly suggère une fraction f = espérance / gain : plus l'avantage est net et le rapport gain/perte favorable, plus la mise « optimale » est grande. Le résultat est une part du capital, pas un montant fixe." },
      { title: "Pourquoi diviser", detail: "Une estimation de probabilité légèrement trop optimiste fait exploser la mise Kelly et le risque de ruine. Beaucoup de gérants n'utilisent qu'un quart ou un demi-Kelly pour absorber l'incertitude sur leurs propres chiffres." },
      { title: "Le lien avec le drawdown", detail: "Le Kelly plein maximise la croissance mais accepte des reculs de capital brutaux (souvent 50 % et plus). Réduire la fraction lisse fortement la courbe au prix d'un peu de performance théorique." },
    ],
    keyPoints: [
      "Kelly relie espérance et rapport gain/perte à une taille de mise.",
      "Le Kelly plein maximise la croissance mais expose à des drawdowns extrêmes.",
      "Une erreur d'estimation rend le Kelly plein dangereux : on le fractionne.",
      "Un repère théorique sur le risque, jamais une consigne de mise.",
    ],
  },
  {
    slug: "couverture-hedging-portefeuille",
    n: 38,
    title: "La couverture (hedging) d'un portefeuille",
    english: "Hedging a Portfolio",
    level: "Avancé",
    illu: "diversification",
    summary: "Réduire une exposition au risque par une position compensatrice — et le coût que cela implique.",
    intro:
      "Se couvrir, c'est prendre une position destinée à compenser les pertes d'une autre : acheter une protection sur un indice, vendre à terme une devise, détenir un actif décorrélé. Une couverture n'augmente pas le rendement — elle l'ampute en échange d'une réduction du risque, comme une assurance dont on paie la prime. Comprendre ce qu'on couvre, contre quoi et à quel coût est plus utile que n'importe quelle « stratégie miracle ». Ce module est un repère pédagogique, jamais un conseil de se couvrir.",
    gauges: [
      { label: "Difficulté", value: 80, verdict: "Avancée", scheme: "good-low" },
      { label: "Réduction du risque", value: 78, verdict: "Réelle", scheme: "good-high" },
      { label: "Coût / frein au rendement", value: 72, verdict: "Notable", scheme: "neutral" },
    ],
    examples: [
      { title: "L'assurance a un prix", detail: "Acheter une protection (par exemple via des options put sur indice) coûte une prime qui grignote la performance si le risque redouté ne se matérialise pas. C'est le prix de la tranquillité, pas un repas gratuit." },
      { title: "La couverture imparfaite", detail: "Couvrir un portefeuille d'actions par un indice ne neutralise que le risque de marché commun : la part spécifique à chaque titre (le « risque de base ») demeure. Une couverture est rarement parfaite." },
      { title: "Le ruée vers les couvertures en 2020", detail: "En mars 2020, la demande de protection a fait bondir le coût des couvertures (VIX à 82) au pire moment : s'assurer quand l'incendie a déjà commencé coûte cher. Les couvertures se réfléchissent à froid." },
    ],
    keyPoints: [
      "Une couverture compense un risque par une position opposée.",
      "Elle réduit le risque mais ampute le rendement : c'est une assurance.",
      "Le risque de base fait qu'une couverture est rarement parfaite.",
      "Se couvrir après le choc coûte cher : cela se prépare à froid.",
    ],
  },
  {
    slug: "saisonnalite-effets-calendaires",
    n: 39,
    title: "Saisonnalité et effets de calendrier",
    english: "Seasonality and Calendar Effects",
    level: "Intermédiaire",
    illu: "cycle",
    summary: "Examiner les régularités prêtées au calendrier (« Sell in May », effet janvier) avec un œil critique.",
    intro:
      "Certaines régularités de calendrier sont devenues folkloriques : « Sell in May and go away », l'« effet janvier » des petites capitalisations, la faiblesse historique de septembre. Statistiquement, des biais saisonniers ont existé sur longues séries, mais ils sont faibles, instables et largement arbitrés une fois connus. Les confondre avec une règle fiable est une erreur classique. Ce module apprend à regarder ces effets pour ce qu'ils sont : des moyennes historiques bruitées, pas des prophéties.",
    gauges: [
      { label: "Difficulté", value: 55, verdict: "Modérée", scheme: "good-low" },
      { label: "Fiabilité des effets", value: 35, verdict: "Faible", scheme: "good-high" },
      { label: "Risque de surinterprétation", value: 80, verdict: "Élevé", scheme: "neutral" },
    ],
    examples: [
      { title: "« Sell in May »", detail: "L'adage repose sur un rendement historique moyen plus faible de mai à octobre. Mais la moyenne cache une énorme dispersion : de nombreux étés ont été très haussiers. Une moyenne n'est pas une garantie annuelle." },
      { title: "L'effet janvier", detail: "Historiquement, les petites capitalisations surperformaient parfois en janvier (ventes fiscales de décembre puis rachats). L'effet s'est largement érodé à mesure qu'il devenait connu et exploité." },
      { title: "Le piège de l'arbitrage", detail: "Une anomalie de calendrier réelle attire les capitaux qui l'exploitent… jusqu'à la faire disparaître. C'est le sort habituel des régularités trop simples une fois publiées." },
    ],
    keyPoints: [
      "Des biais saisonniers ont existé, mais faibles et instables.",
      "Une moyenne historique n'est pas une prévision pour l'année en cours.",
      "Les anomalies connues tendent à s'éroder une fois exploitées.",
      "À regarder comme un repère statistique, jamais comme une règle.",
    ],
  },
  {
    slug: "risque-evenement-resultats-banques-centrales",
    n: 40,
    title: "Le risque d'événement : résultats & banques centrales",
    english: "Event Risk: Earnings & Central Banks",
    level: "Intermédiaire",
    illu: "volatility",
    summary: "Anticiper les pics de volatilité programmés autour des publications de résultats et des décisions de taux.",
    intro:
      "Certains rendez-vous sont connus à l'avance et concentrent un risque considérable : publications de résultats trimestriels, réunions de banques centrales (Fed, BCE), chiffres d'inflation et d'emploi. Avant ces événements, la volatilité implicite gonfle ; après, elle s'effondre souvent brutalement (le « vol crush »). Comprendre qu'un calendrier économique structure le risque autant qu'un graphique est un réflexe d'analyste. Ce module décrit ces dynamiques, sans jamais suggérer de se positionner pour ou contre un événement.",
    gauges: [
      { label: "Difficulté", value: 60, verdict: "Modérée", scheme: "good-low" },
      { label: "Impact sur la volatilité", value: 88, verdict: "Majeur", scheme: "good-high" },
      { label: "Imprévisibilité de la réaction", value: 82, verdict: "Élevée", scheme: "neutral" },
    ],
    examples: [
      { title: "Le « vol crush » post-résultats", detail: "Avant une publication, l'incertitude gonfle le prix des options ; juste après, l'incertitude levée, la volatilité implicite s'effondre — même si le titre bouge peu. Un piège classique pour qui achète de la volatilité trop cher." },
      { title: "Les jours de Fed", detail: "Les décisions de la Réserve fédérale américaine et le ton du communiqué peuvent provoquer des mouvements brutaux en quelques minutes. Le marché réagit autant aux mots (« hawkish »/« dovish ») qu'aux chiffres." },
      { title: "Le gap de résultats", detail: "Une action peut ouvrir 10 ou 20 % plus haut ou plus bas le lendemain d'une publication, sautant tout niveau technique. Aucun stop intraday ne protège d'un gap d'ouverture." },
    ],
    keyPoints: [
      "Les événements programmés concentrent un risque connu à l'avance.",
      "La volatilité implicite gonfle avant, puis s'effondre après (vol crush).",
      "Un gap d'ouverture peut sauter tous les niveaux techniques.",
      "Le calendrier économique structure le risque autant que le graphique.",
    ],
  },
  {
    slug: "echelle-logarithmique-vs-lineaire",
    n: 41,
    title: "Échelle logarithmique contre échelle linéaire",
    english: "Logarithmic vs Linear Scale",
    level: "Intermédiaire",
    illu: "chart-anatomy",
    summary: "Choisir la bonne échelle verticale pour ne pas déformer la lecture d'une tendance de long terme.",
    intro:
      "Sur une échelle linéaire, un même écart vertical représente toujours le même nombre d'euros ; sur une échelle logarithmique, il représente le même pourcentage. Pour un actif qui a été multiplié par dix sur plusieurs années, l'échelle linéaire écrase tout le passé et exagère le présent, tandis que l'échelle log rend chaque variation en pourcentage comparable. Savoir quelle échelle utiliser — et reconnaître quand un graphique trompeur en abuse — est une compétence de lecture fondamentale, surtout sur le long terme.",
    gauges: [
      { label: "Difficulté", value: 40, verdict: "Accessible", scheme: "good-low" },
      { label: "Importance en long terme", value: 85, verdict: "Forte", scheme: "good-high" },
      { label: "Source d'illusions", value: 70, verdict: "Réelle", scheme: "neutral" },
    ],
    examples: [
      { title: "La bulle qui n'en est pas une", detail: "Sur échelle linéaire, une valeur passée de 1 à 100 dessine une courbe « parabolique » effrayante. La même série en échelle log peut révéler une progression régulière en pourcentage — l'illusion vient de l'échelle, pas du prix." },
      { title: "Les lignes de tendance", detail: "Une droite de tendance tracée sur échelle linéaire et la même sur échelle log ne passent pas par les mêmes points. Sur le long terme, la tendance log (en pourcentage) est souvent la plus pertinente." },
      { title: "Le bon réflexe", detail: "Pour comparer des variations sur des années ou des actifs de prix très différents, l'échelle logarithmique met tout le monde sur un pied d'égalité : ce qui compte alors, c'est le pourcentage, pas l'écart absolu." },
    ],
    keyPoints: [
      "Linéaire = mêmes euros ; logarithmique = mêmes pourcentages.",
      "Sur le long terme, l'échelle log évite d'écraser le passé.",
      "Une « parabole » peut n'être qu'un artefact de l'échelle linéaire.",
      "Choisir l'échelle, c'est déjà décider de ce qu'on veut lire.",
    ],
  },
  {
    slug: "biais-cognitifs-du-trader",
    n: 42,
    title: "Les biais cognitifs du trader",
    english: "The Trader's Cognitive Biases",
    level: "Intermédiaire",
    illu: "fomo",
    summary: "Repérer les pièges mentaux récurrents — ancrage, confirmation, aversion à la perte — qui faussent les décisions.",
    intro:
      "Les travaux de Daniel Kahneman et Amos Tversky, couronnés par le prix Nobel d'économie 2002, ont montré que l'esprit humain juge le risque à travers des raccourcis systématiques. En marché, ces biais ont un coût : on s'ancre sur son prix d'achat, on ne cherche que l'information qui nous conforte (biais de confirmation), on ressent une perte deux fois plus fort qu'un gain équivalent (aversion à la perte). Connaître ces pièges ne les supprime pas, mais permet d'installer des garde-fous. Ce module est un repère comportemental, jamais un conseil d'agir.",
    gauges: [
      { label: "Difficulté de maîtrise", value: 75, verdict: "Élevée", scheme: "good-low" },
      { label: "Poids dans les erreurs", value: 90, verdict: "Majeur", scheme: "good-high" },
      { label: "Effet d'un cadre écrit", value: 80, verdict: "Fort", scheme: "good-high" },
    ],
    examples: [
      { title: "L'ancrage sur le prix d'achat", detail: "« Je vends quand je serai revenu à mon prix d'achat » : le marché ignore votre prix de revient. S'ancrer sur ce chiffre conduit à conserver des positions perdantes bien au-delà du raisonnable." },
      { title: "Le biais de confirmation", detail: "Une fois positionné, on tend à ne lire que les avis qui nous donnent raison et à écarter les signaux contraires. Chercher activement l'argument inverse est une parade délibérée." },
      { title: "L'aversion à la perte", detail: "Kahneman et Tversky ont mesuré qu'une perte fait environ deux fois plus mal qu'un gain de même taille ne fait plaisir. Ce déséquilibre pousse à couper ses gains trop tôt et à laisser courir ses pertes." },
    ],
    keyPoints: [
      "L'esprit juge le risque par raccourcis systématiques (Kahneman & Tversky).",
      "L'ancrage sur le prix d'achat fait conserver les positions perdantes.",
      "Le biais de confirmation filtre l'information à notre avantage.",
      "L'aversion à la perte déséquilibre la gestion des gains et des pertes.",
    ],
  },
  {
    slug: "volatilite-implicite-vix",
    n: 43,
    title: "Lire la volatilité implicite et le VIX",
    english: "Reading Implied Volatility & the VIX",
    level: "Avancé",
    illu: "vol-smile",
    summary: "Comprendre la volatilité attendue par le marché, le « smile » et l'indice de la peur.",
    intro:
      "La volatilité implicite est la volatilité future que le marché « price » dans les options : elle reflète l'incertitude attendue, pas le passé. Synthétisée par le VIX (le fameux « indice de la peur ») depuis 1993, elle gonfle avant les événements à risque et s'effondre une fois l'incertitude levée. Sa structure n'est pas plate : le « smile » montre que les options très en dehors de la monnaie coûtent relativement plus cher, signe que le marché surévalue les extrêmes. Ce module est un repère pédagogique, jamais un conseil de positionnement.",
    gauges: [
      { label: "Difficulté", value: 84, verdict: "Avancée", scheme: "good-low" },
      { label: "Valeur d'information", value: 82, verdict: "Forte", scheme: "good-high" },
      { label: "Risque de mésinterprétation", value: 70, verdict: "Réel", scheme: "neutral" },
    ],
    examples: [
      { title: "Le pic de mars 2020", detail: "Le VIX a culminé à 82,69 le 16 mars 2020, l'un de ses plus hauts historiques, traduisant une incertitude extrême au cœur du choc Covid." },
      { title: "Le « vol crush »", detail: "Après une publication de résultats, la volatilité implicite d'une action s'effondre souvent même si le titre bouge peu : l'incertitude levée, les options perdent leur prime de risque." },
      { title: "Le smile", detail: "Sur la plupart des marchés d'options, les strikes éloignés affichent une volatilité implicite plus élevée que les strikes proches — le marché paie pour se protéger des extrêmes." },
    ],
    keyPoints: [
      "La volatilité implicite est tournée vers l'avenir, pas vers le passé.",
      "Le VIX gonfle avant le risque et s'effondre une fois l'incertitude levée.",
      "Le smile montre que le marché surévalue les mouvements extrêmes.",
      "Un repère sur l'anxiété du marché, jamais un signal d'achat/vente.",
    ],
  },
  {
    slug: "systeme-suivi-de-tendance",
    n: 44,
    title: "Construire un système de suivi de tendance",
    english: "Building a Trend-Following System",
    level: "Avancé",
    illu: "trend",
    summary: "Les briques d'une approche systématique qui gagne peu souvent mais laisse courir ses gains.",
    intro:
      "Le suivi de tendance repose sur une idée contre-intuitive : avoir raison rarement, mais gros. Un tel système accepte de nombreuses petites pertes (faux départs) en échange de quelques tendances longues qui paient tout le reste. Ses briques : une règle d'entrée objective (cassure, croisement), une règle de sortie qui laisse courir, un dimensionnement par la volatilité et une discipline d'exécution sans exception. Les célèbres « Turtle Traders » des années 1980 en sont l'illustration historique. Ce module décrit la logique, jamais un système à appliquer tel quel.",
    gauges: [
      { label: "Difficulté", value: 80, verdict: "Avancée", scheme: "good-low" },
      { label: "Exigence de discipline", value: 92, verdict: "Majeure", scheme: "good-high" },
      { label: "Taux de réussite", value: 40, verdict: "Bas (assumé)", scheme: "neutral" },
    ],
    examples: [
      { title: "Espérance positive, faible réussite", detail: "Beaucoup de systèmes de tendance gagnent moins de 45 % du temps, mais leurs gains moyens dépassent largement leurs pertes moyennes — l'espérance reste positive." },
      { title: "Les Turtles", detail: "En 1983, Richard Dennis a prouvé qu'on pouvait enseigner un système de cassure (canaux de Donchian) à des novices ; le groupe a généré des centaines de millions de dollars." },
      { title: "Le coût psychologique", detail: "Encaisser dix faux signaux d'affilée en attendant la grande tendance est éprouvant : c'est la discipline, plus que la règle, qui fait la différence." },
    ],
    keyPoints: [
      "Le suivi de tendance gagne rarement mais laisse courir ses gains.",
      "Entrée objective, sortie qui laisse courir, taille fondée sur la volatilité.",
      "L'espérance peut être positive malgré un faible taux de réussite.",
      "La discipline d'exécution est le vrai facteur limitant.",
    ],
  },
  {
    slug: "carry-et-portage",
    n: 45,
    title: "Le carry et le portage",
    english: "Carry & the Cost of Holding",
    level: "Avancé",
    illu: "carry",
    summary: "Le rendement (ou le coût) de simplement détenir une position dans le temps.",
    intro:
      "Le carry, ou portage, est ce que rapporte ou coûte une position du seul fait de la conserver, indépendamment des variations de prix : l'écart de taux entre deux devises, le coupon d'une obligation, le coût de financement d'un levier, le report d'un contrat à terme. Une stratégie de carry « collecte » ce rendement, mais elle est trompeuse : elle gagne régulièrement de petites sommes… jusqu'au jour où un retournement brutal efface des années de gains. C'est un repère pédagogique sur une source de rendement souvent sous-estimée, jamais un conseil.",
    gauges: [
      { label: "Difficulté", value: 78, verdict: "Avancée", scheme: "good-low" },
      { label: "Régularité apparente", value: 80, verdict: "Élevée", scheme: "good-high" },
      { label: "Risque de queue caché", value: 88, verdict: "Important", scheme: "neutral" },
    ],
    examples: [
      { title: "Le carry trade de devises", detail: "Emprunter dans une devise à faible taux pour placer dans une devise à taux élevé rapporte l'écart de taux — tant que le change ne se retourne pas violemment." },
      { title: "Contango et portage", detail: "Sur un marché à terme en contango, rouler une position longue coûte à chaque échéance : un portage négatif qui érode la performance même si le sous-jacent ne bouge pas." },
      { title: "« Ramasser des pièces »", detail: "Le carry est parfois décrit comme « ramasser des pièces devant un rouleau compresseur » : de petits gains réguliers, un risque rare mais dévastateur." },
    ],
    keyPoints: [
      "Le carry est le rendement (ou coût) de détenir une position dans le temps.",
      "Il génère des gains réguliers… et un risque de queue brutal.",
      "Écart de taux, coupon, coût de levier, report de terme en sont les sources.",
      "Un rendement séduisant mais à analyser avec son risque caché.",
    ],
  },
  {
    slug: "gestion-multi-actifs",
    n: 46,
    title: "Gérer un portefeuille multi-actifs",
    english: "Managing a Multi-Asset Portfolio",
    level: "Intermédiaire",
    illu: "diversification",
    summary: "Combiner actions, obligations, or et cash pour lisser le parcours, pas seulement viser le rendement.",
    intro:
      "Un portefeuille multi-actifs ne cherche pas seulement le rendement maximal, mais le meilleur rapport entre rendement et secousses. En combinant des actifs qui ne réagissent pas de la même façon (actions, obligations, or, liquidités), on lisse la courbe : quand l'un baisse, un autre amortit. La clé n'est pas le nombre de lignes mais la diversité des comportements. Attention toutefois : en pleine crise, les corrélations tendent à grimper vers 1, et la diversification protège moins au moment où l'on en aurait le plus besoin. Repère pédagogique, jamais une allocation conseillée.",
    gauges: [
      { label: "Difficulté", value: 58, verdict: "Modérée", scheme: "good-low" },
      { label: "Effet de lissage", value: 80, verdict: "Réel", scheme: "good-high" },
      { label: "Faille en crise (corrélations)", value: 75, verdict: "À connaître", scheme: "neutral" },
    ],
    examples: [
      { title: "Le 60/40", detail: "Le portefeuille classique 60 % actions / 40 % obligations a longtemps lissé les parcours… avant de souffrir en 2022, quand actions et obligations ont baissé ensemble." },
      { title: "Corrélations en crise", detail: "En mars 2020, des actifs habituellement décorrélés ont chuté ensemble dans la ruée vers le cash : la diversification a momentanément cessé de protéger." },
      { title: "Diversité, pas quantité", detail: "Détenir vingt actions du même secteur n'est pas diversifier : ce qui compte, c'est la variété des comportements face aux mêmes chocs." },
    ],
    keyPoints: [
      "Le multi-actifs vise le rapport rendement/secousses, pas le rendement seul.",
      "Combiner des actifs aux comportements différents lisse la courbe.",
      "En crise, les corrélations montent et la protection s'affaiblit.",
      "C'est la diversité des réactions qui compte, pas le nombre de lignes.",
    ],
  },
  {
    slug: "reconnaitre-une-bulle",
    n: 47,
    title: "Reconnaître une bulle en formation",
    english: "Spotting a Bubble Forming",
    level: "Intermédiaire",
    illu: "bubble",
    summary: "Les signes récurrents de l'euphorie spéculative — et pourquoi ils ne donnent jamais le « quand ».",
    intro:
      "Les bulles se ressemblent à travers les siècles : accélération parabolique des prix, récit d'un « nouveau paradigme », afflux de novices, levier généralisé et mépris de la valorisation. De la tulipe au XVIIᵉ siècle à la bulle Internet de 2000, les ingrédients sont étonnamment constants. Le problème : reconnaître une bulle ne dit jamais quand elle éclatera — les marchés peuvent rester irrationnels plus longtemps qu'on ne peut rester solvable. Ce module décrit des signaux d'excès à des fins pédagogiques, sans aucune recommandation d'agir.",
    gauges: [
      { label: "Difficulté", value: 55, verdict: "Modérée", scheme: "good-low" },
      { label: "Récurrence des signaux", value: 85, verdict: "Forte", scheme: "good-high" },
      { label: "Capacité à dater l'éclatement", value: 20, verdict: "Quasi nulle", scheme: "neutral" },
    ],
    examples: [
      { title: "Le Nasdaq 2000", detail: "Au sommet de mars 2000, des sociétés sans bénéfices se payaient des centaines de fois leurs ventes ; le Nasdaq a ensuite perdu près de 78 % en deux ans." },
      { title: "La tulipomanie", detail: "Aux Pays-Bas, vers 1637, certains bulbes de tulipe se sont échangés au prix d'une maison avant un effondrement total — l'archétype historique de la bulle." },
      { title: "Le piège du timing", detail: "Beaucoup ont identifié la bulle Internet dès 1998… et ont eu « tort » pendant deux ans de hausse avant l'éclatement. Reconnaître n'est pas dater." },
    ],
    keyPoints: [
      "Les bulles partagent des ingrédients constants : parabole, récit, levier, novices.",
      "Reconnaître une bulle ne dit jamais quand elle éclatera.",
      "« Le marché peut rester irrationnel plus longtemps que vous solvable. »",
      "Des signaux d'excès, à lire sans jamais en faire un signal d'action.",
    ],
  },
  {
    slug: "accumulation-distribution-flux",
    n: 48,
    title: "Accumulation et distribution : lire les flux",
    english: "Accumulation & Distribution",
    level: "Intermédiaire",
    illu: "order-flow",
    summary: "Repérer si les gros intervenants achètent discrètement (accumulation) ou vendent (distribution).",
    intro:
      "Avant les grands mouvements, les prix paraissent souvent calmes alors que, en coulisses, des intervenants importants construisent ou liquident une position. L'accumulation décrit un achat patient et discret, souvent dans un range, qui ne fait pas encore monter le prix ; la distribution est l'inverse, une vente étalée près des sommets. Les outils de flux (position de la clôture dans la fourchette, volume relatif) cherchent à révéler cette pression de fond avant qu'elle ne se voie dans le prix. Ce module est un repère de lecture, jamais un signal.",
    gauges: [
      { label: "Difficulté", value: 62, verdict: "Modérée", scheme: "good-low" },
      { label: "Valeur d'anticipation", value: 72, verdict: "Réelle", scheme: "good-high" },
      { label: "Risque de sur-interprétation", value: 70, verdict: "Présent", scheme: "neutral" },
    ],
    examples: [
      { title: "Accumulation en range", detail: "Un titre stagne des semaines dans une fourchette étroite, mais les clôtures se font régulièrement près du haut sur volume soutenu : un signe possible d'accumulation discrète." },
      { title: "Distribution au sommet", detail: "Après une longue hausse, le prix plafonne tandis que les clôtures glissent vers le bas de la fourchette sur fort volume : un schéma classique de distribution." },
      { title: "La divergence volume/prix", detail: "Un nouveau sommet de prix non accompagné par les indicateurs de flux trahit une participation déclinante — un mouvement sans véritable conviction." },
    ],
    keyPoints: [
      "Accumulation = achat discret et patient ; distribution = vente étalée.",
      "Les flux cherchent à révéler la pression avant qu'elle ne se voie dans le prix.",
      "La position de la clôture et le volume relatif sont des indices clés.",
      "Une lecture probabiliste du rapport de force, jamais une certitude.",
    ],
  },
  {
    slug: "vagues-elliott",
    n: 49,
    title: "La théorie des vagues d'Elliott",
    english: "Elliott Wave Theory",
    level: "Avancé",
    illu: "fibonacci",
    summary: "Une grille de lecture qui voit les tendances en 5 vagues d'avancée puis 3 de correction.",
    intro:
      "Élaborée par Ralph Elliott dans les années 1930, cette théorie postule que les marchés progressent en cycles répétitifs : cinq vagues dans le sens de la tendance (une « impulsion »), suivies de trois vagues de correction. Les proportions entre vagues s'appuient souvent sur les ratios de Fibonacci. C'est un cadre séduisant pour structurer une tendance, mais hautement subjectif : deux analystes comptent souvent les vagues différemment. À utiliser comme grille de lecture probabiliste, jamais comme une prophétie.",
    gauges: [
      { label: "Difficulté", value: 88, verdict: "Très élevée", scheme: "good-low" },
      { label: "Subjectivité", value: 85, verdict: "Forte", scheme: "neutral" },
      { label: "Popularité", value: 65, verdict: "Notable", scheme: "good-high" },
    ],
    examples: [
      { title: "L'impulsion en 5 vagues", detail: "Dans une tendance haussière, Elliott décrit trois vagues de hausse (1, 3, 5) entrecoupées de deux replis (2, 4) — la vague 3 étant souvent la plus longue." },
      { title: "La correction A-B-C", detail: "Après l'impulsion, le marché corrige typiquement en trois temps (A baisse, B rebond, C baisse) avant qu'un nouveau cycle ne puisse commencer." },
      { title: "Le compte contesté", detail: "Sur un même graphique, un analyste voit une vague 4, un autre le début d'une nouvelle tendance : la subjectivité du décompte est la principale limite de la méthode." },
    ],
    keyPoints: [
      "Cinq vagues d'impulsion, puis trois de correction (A-B-C).",
      "Les proportions s'appuient souvent sur Fibonacci.",
      "La vague 3 est rarement la plus courte des trois vagues motrices.",
      "Méthode puissante mais très subjective — un cadre, pas une certitude.",
    ],
  },
  {
    slug: "largeur-de-marche-breadth",
    n: 50,
    title: "La largeur de marché (breadth)",
    english: "Market Breadth",
    level: "Avancé",
    illu: "sentiment",
    summary: "Un indice peut monter porté par quelques géants pendant que la majorité des titres faiblit.",
    intro:
      "La largeur de marché mesure la participation : combien de titres montent réellement derrière un indice ? Des outils comme la ligne avance/déclin, le pourcentage de valeurs au-dessus de leur moyenne mobile, ou le solde nouveaux plus-hauts / plus-bas révèlent la santé interne d'une tendance. Quand un indice progresse mais que la largeur se rétrécit (hausse portée par une poignée de géants), la tendance est dite « étroite » — un signe de fragilité que le seul prix de l'indice ne montre pas.",
    gauges: [
      { label: "Difficulté", value: 72, verdict: "Soutenue", scheme: "good-low" },
      { label: "Valeur d'alerte", value: 84, verdict: "Forte", scheme: "good-high" },
    ],
    examples: [
      { title: "La hausse étroite", detail: "Fin 2021, plusieurs indices tenaient grâce à une poignée de très grandes capitalisations, alors que beaucoup de titres baissaient déjà — une largeur en dégradation." },
      { title: "La ligne avance/déclin", detail: "Elle cumule chaque jour le nombre de titres en hausse moins ceux en baisse. Si l'indice monte mais que cette ligne baisse, la participation s'effrite." },
      { title: "Le balayage sain", detail: "Une tendance où une large majorité de titres et de secteurs montent ensemble est jugée plus robuste qu'une hausse portée par quelques noms." },
    ],
    keyPoints: [
      "La largeur mesure combien de titres participent vraiment à la tendance.",
      "Indice qui monte + largeur qui baisse = tendance fragile (étroite).",
      "Avance/déclin, % au-dessus d'une MM, nouveaux hauts/bas : les mesures clés.",
      "Un signe de santé interne, à confirmer par le prix.",
    ],
  },
  {
    slug: "force-relative-rotation-sectorielle",
    n: 51,
    title: "Force relative et rotation sectorielle",
    english: "Relative Strength & Sector Rotation",
    level: "Intermédiaire",
    illu: "rotation",
    summary: "Comparer un actif à son indice révèle les meneurs et les retardataires du moment.",
    intro:
      "La force relative (à ne pas confondre avec le RSI) compare la performance d'un actif à celle d'une référence : monte-t-il plus vite que son indice, ou traîne-t-il ? Rapportée aux secteurs, elle éclaire la « rotation » : selon la phase du cycle économique, les capitaux passent des valeurs défensives aux cycliques, des grandes aux petites capitalisations, etc. Suivre les meneurs et fuir les retardataires est une logique d'observation — pas une recommandation d'achat.",
    gauges: [
      { label: "Difficulté", value: 58, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Utilité de contexte", value: 80, verdict: "Forte", scheme: "good-high" },
      { label: "Stabilité dans le temps", value: 45, verdict: "Variable", scheme: "neutral" },
    ],
    examples: [
      { title: "Le ratio relatif", detail: "Diviser le cours d'un secteur par celui de l'indice trace une courbe : si elle monte, le secteur surperforme ; si elle baisse, il traîne — indépendamment du sens du marché." },
      { title: "La rotation de cycle", detail: "En sortie de récession, les secteurs cycliques (industrie, consommation discrétionnaire) mènent souvent ; en fin de cycle, les défensifs (santé, services aux collectivités) reprennent l'avantage." },
      { title: "Meneurs et retardataires", detail: "Dans une hausse, les titres qui font de nouveaux plus-hauts avant l'indice montrent une force relative ; ceux qui peinent à suivre signalent une faiblesse interne." },
    ],
    keyPoints: [
      "Force relative = performance comparée à une référence (≠ RSI).",
      "Un ratio croissant = surperformance ; décroissant = sous-performance.",
      "La rotation sectorielle suit, en moyenne, les phases du cycle.",
      "Les meneurs et retardataires se repèrent par comparaison, pas dans l'absolu.",
    ],
  },
  {
    slug: "risque-de-ruine-drawdown",
    n: 52,
    title: "Risque de ruine et gestion du drawdown",
    english: "Risk of Ruin & Drawdown Management",
    level: "Avancé",
    illu: "drawdown",
    summary: "Préserver le capital passe avant tout : une perte profonde devient très dure à effacer.",
    intro:
      "Le drawdown est la baisse depuis un sommet de capital ; le risque de ruine, la probabilité de descendre assez bas pour ne plus pouvoir se refaire. Les deux rappellent une vérité mathématique implacable : les pertes sont asymétriques. Perdre 50 % impose ensuite +100 % pour revenir à l'équilibre ; perdre 90 %, +900 %. Plus on creuse, plus la remontée est hors d'atteinte. D'où la priorité absolue de la préservation du capital — bien avant la recherche de performance.",
    gauges: [
      { label: "Difficulté", value: 76, verdict: "Élevée", scheme: "good-low" },
      { label: "Importance vitale", value: 97, verdict: "Maximale", scheme: "good-high" },
      { label: "Sous-estimation fréquente", value: 78, verdict: "Courante", scheme: "neutral" },
    ],
    examples: [
      { title: "L'asymétrie des pertes", detail: "−10 % se rattrape avec +11 %, mais −50 % exige +100 % et −80 % réclame +400 %. Chaque point de perte supplémentaire rend la remontée disproportionnée." },
      { title: "Le drawdown qui dure", detail: "Après 2000, le Nasdaq a mis une quinzaine d'années à retrouver son sommet : un drawdown profond peut immobiliser un capital pendant une décennie." },
      { title: "La protection par la taille", detail: "Borner le risque par position et plafonner l'exposition globale limite la profondeur des drawdowns — c'est la première ligne de défense contre la ruine." },
    ],
    keyPoints: [
      "Drawdown = baisse depuis un sommet ; risque de ruine = ne plus pouvoir se refaire.",
      "Les pertes sont asymétriques : −50 % exige +100 % pour revenir à l'équilibre.",
      "Un drawdown profond peut immobiliser le capital des années.",
      "Préserver le capital passe avant la performance.",
    ],
  },
  {
    slug: "trading-des-gaps",
    n: 53,
    title: "Le trading des gaps (fenêtres)",
    english: "Trading Gaps",
    level: "Intermédiaire",
    illu: "gap",
    summary: "Comprendre les trous de cotation : rupture, continuation, épuisement et comblement.",
    intro:
      "Un gap (ou fenêtre) est un trou de cotation : le marché ouvre nettement au-dessus ou en dessous de la clôture précédente, laissant une zone sans échange. Il matérialise un déséquilibre soudain entre acheteurs et vendeurs, souvent provoqué par une nouvelle hors séance. Les analystes distinguent plusieurs types — rupture, continuation, épuisement — et observent la tendance des cours à « combler » leurs gaps, c'est-à-dire à revenir les remplir.",
    gauges: [
      { label: "Difficulté", value: 55, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Fréquence sur actions", value: 72, verdict: "Courante", scheme: "neutral" },
      { label: "Fiabilité du type", value: 58, verdict: "Variable", scheme: "good-high" },
    ],
    examples: [
      { title: "Gap de rupture", detail: "À la sortie d'une consolidation, un gap accompagné de volume signale souvent le départ d'un mouvement. L'ancienne borne franchie est ensuite censée servir de support ou de résistance." },
      { title: "Gap d'épuisement", detail: "En fin de tendance, un dernier gap comblé rapidement trahit un emballement à bout de souffle : les derniers entrants se retrouvent piégés." },
      { title: "Le comblement", detail: "Beaucoup de gaps finissent par être comblés. Un gap non comblé qui tient dans le temps est, lui, jugé plus significatif pour la tendance en cours." },
    ],
    keyPoints: [
      "Un gap = trou de cotation, signe d'un déséquilibre soudain.",
      "Rupture (départ), continuation (milieu), épuisement (fin) : le contexte distingue les types.",
      "Le volume aide à séparer un vrai gap de rupture d'un faux signal.",
      "Un gap comblé rapidement affaiblit le signal ; non comblé, il le renforce.",
    ],
  },
  {
    slug: "stops-trailing-atr",
    n: 54,
    title: "Stops et trailing stops avec l'ATR",
    english: "Stops & Trailing Stops with ATR",
    level: "Intermédiaire",
    illu: "trailing-stop",
    summary: "Placer ses stops selon la volatilité réelle plutôt qu'à un pourcentage arbitraire.",
    intro:
      "Un stop placé trop près est touché par le simple bruit du marché ; trop loin, il coûte cher quand il se déclenche. L'ATR (Average True Range) mesure l'amplitude moyenne des séances et permet de calibrer la distance du stop sur la volatilité réelle de l'actif. Le trailing stop, lui, suit le cours à mesure qu'il progresse, sécurisant les gains sans plafonner la hausse.",
    gauges: [
      { label: "Difficulté", value: 50, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Impact sur la survie", value: 90, verdict: "Décisif", scheme: "good-high" },
      { label: "Discipline requise", value: 70, verdict: "Élevée", scheme: "neutral" },
    ],
    examples: [
      { title: "Stop en multiples d'ATR", detail: "Placer le stop à 2 ou 3 ATR sous l'entrée adapte la marge à la volatilité : large sur un actif nerveux, serré sur un actif calme. La même distance en % serait incohérente d'un actif à l'autre." },
      { title: "Le chandelier Chandelier Exit", detail: "Un trailing stop classique suit le plus-haut récent diminué d'un multiple d'ATR : tant que le cours monte, le stop remonte ; il ne redescend jamais." },
      { title: "Le piège du stop trop serré", detail: "Un stop à 1 % sur un actif qui bouge de 3 % par jour sera balayé par le bruit avant que la thèse ait eu le temps de se vérifier." },
    ],
    keyPoints: [
      "L'ATR calibre la distance du stop sur la volatilité réelle, pas sur un % arbitraire.",
      "2-3 ATR est une fourchette répandue, à ajuster selon l'horizon.",
      "Le trailing stop sécurise les gains sans plafonner la hausse.",
      "Un stop ne remonte jamais à l'envers de la position : il ne fait que protéger.",
    ],
  },
  {
    slug: "surapprentissage-backtest",
    n: 55,
    title: "Le surapprentissage : l'ennemi du backtest",
    english: "Overfitting in Backtesting",
    level: "Avancé",
    illu: "journal",
    summary: "Pourquoi une stratégie parfaite sur le passé échoue souvent dans le futur.",
    intro:
      "Le surapprentissage (overfitting) survient quand une stratégie est tellement ajustée aux données passées qu'elle en épouse le bruit plutôt que le signal. Sur le papier, la courbe est magnifique ; en réel, elle s'effondre. Plus on ajoute de paramètres et de filtres optimisés a posteriori, plus le risque grandit. Un bon backtest se juge moins à sa performance qu'à sa robustesse hors échantillon.",
    gauges: [
      { label: "Difficulté", value: 82, verdict: "Avancée", scheme: "good-low" },
      { label: "Danger sous-estimé", value: 88, verdict: "Majeur", scheme: "neutral" },
      { label: "Importance pour systématiser", value: 92, verdict: "Critique", scheme: "good-high" },
    ],
    examples: [
      { title: "La courbe trop belle", detail: "Une stratégie à dix paramètres qui n'a jamais de perte sur l'historique est suspecte : elle a probablement mémorisé le passé au lieu d'en capter la logique." },
      { title: "Le test hors échantillon", detail: "Réserver une partie des données jamais vue par l'optimisation (out-of-sample) permet de vérifier si la stratégie tient hors de son terrain d'entraînement." },
      { title: "La règle de parcimonie", detail: "Moins de paramètres, des valeurs « rondes » et une logique explicable réduisent le risque d'avoir simplement habillé du hasard en méthode." },
    ],
    keyPoints: [
      "Surapprentissage = épouser le bruit du passé, pas le signal.",
      "Plus de paramètres optimisés = plus de risque d'illusion.",
      "Toujours valider hors échantillon (out-of-sample) et, idéalement, en walk-forward.",
      "Une stratégie robuste et simple bat une stratégie parfaite mais fragile.",
    ],
  },
  {
    slug: "chandeliers-alternatifs",
    n: 56,
    title: "Heikin-Ashi & graphiques alternatifs",
    english: "Heikin-Ashi & Alternative Charts",
    level: "Intermédiaire",
    illu: "chart-anatomy",
    summary: "Au-delà des chandeliers classiques : Heikin-Ashi, Renko et leurs usages.",
    intro:
      "Tous les graphiques ne se valent pas selon l'objectif. Les chandeliers Heikin-Ashi lissent les cours pour mieux faire ressortir la tendance, au prix d'un léger retard. Les graphiques Renko, eux, ignorent le temps et ne tracent une brique que lorsque le prix bouge d'un montant fixe, filtrant ainsi le bruit. Ces représentations alternatives ne remplacent pas l'analyse classique : elles offrent un autre angle de lecture.",
    gauges: [
      { label: "Difficulté", value: 48, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Aide à la lisibilité", value: 80, verdict: "Forte", scheme: "good-high" },
      { label: "Risque de retard", value: 60, verdict: "À connaître", scheme: "neutral" },
    ],
    examples: [
      { title: "Heikin-Ashi en tendance", detail: "Une succession de bougies Heikin-Ashi de même couleur, sans mèche opposée, traduit une tendance régulière. Le premier changement de couleur signale un essoufflement potentiel." },
      { title: "Renko et le bruit", detail: "En ne traçant une brique qu'après un mouvement de prix défini, le Renko élimine les oscillations mineures et met la structure de tendance en évidence." },
      { title: "Le retard assumé", detail: "Ces graphiques lissés réagissent plus tard que les cours réels : ils clarifient la tendance mais ne conviennent pas pour une exécution au tick près." },
    ],
    keyPoints: [
      "Heikin-Ashi lisse les cours pour révéler la tendance, avec un léger retard.",
      "Renko ignore le temps et filtre le bruit par briques de prix fixe.",
      "Ces vues alternatives complètent l'analyse classique, sans la remplacer.",
      "Lissage = clarté de tendance mais réactivité moindre.",
    ],
  },
  {
    slug: "cassures-de-range",
    n: 57,
    title: "Le trading des cassures de range",
    english: "Range Breakouts",
    level: "Intermédiaire",
    illu: "support-resistance",
    summary: "Quand le prix sort d'un couloir horizontal : vraie cassure ou faux départ ?",
    intro:
      "Un range est une phase où le prix oscille entre un support et une résistance horizontaux, sans tendance. Tôt ou tard, il en sort — c'est la cassure. Mais toutes les cassures ne se valent pas : certaines lancent une nouvelle tendance, d'autres ne sont que des pièges (faux breakouts). Distinguer les deux suppose d'observer le volume, l'ampleur de la sortie et le comportement du prix après la cassure.",
    gauges: [
      { label: "Difficulté", value: 52, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Fréquence des faux signaux", value: 65, verdict: "Élevée", scheme: "neutral" },
      { label: "Utilité en pratique", value: 88, verdict: "Forte", scheme: "good-high" },
    ],
    examples: [
      { title: "La cassure avec volume", detail: "Une sortie de range accompagnée d'un volume nettement supérieur à la moyenne est jugée plus crédible : elle traduit un afflux réel d'acheteurs ou de vendeurs." },
      { title: "Le retest de l'ancienne borne", detail: "Après une cassure, le prix revient souvent tester l'ancienne résistance devenue support. Un retest qui tient renforce la lecture de cassure valide." },
      { title: "Le faux breakout", detail: "Une sortie sans volume qui réintègre aussitôt le range est un piège classique : les ordres déclenchés au franchissement servent de carburant au mouvement inverse." },
    ],
    keyPoints: [
      "Un range = oscillation entre support et résistance, sans tendance.",
      "Le volume aide à distinguer une vraie cassure d'un faux départ.",
      "L'ancienne résistance franchie devient souvent un support (et inversement).",
      "Attendre une confirmation évite de courir après les pièges.",
    ],
  },
  {
    slug: "pullback-et-retest",
    n: 58,
    title: "Le pullback et le retest",
    english: "Pullback & Retest",
    level: "Intermédiaire",
    illu: "trend",
    summary: "Entrer dans le sens de la tendance lors d'un repli, plutôt qu'en pleine extension.",
    intro:
      "Un pullback est un repli temporaire au sein d'une tendance : le prix souffle avant de repartir dans le sens dominant. Combiné au retest d'un niveau cassé, il offre des points d'entrée souvent plus favorables que la poursuite d'un mouvement déjà étendu — avec un stop logique sous le niveau testé. Encore faut-il distinguer un simple pullback d'un véritable retournement.",
    gauges: [
      { label: "Difficulté", value: 56, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Qualité du rapport risque/gain", value: 86, verdict: "Élevée", scheme: "good-high" },
      { label: "Patience requise", value: 74, verdict: "Forte", scheme: "neutral" },
    ],
    examples: [
      { title: "Le repli vers une moyenne mobile", detail: "Dans une tendance haussière, le prix revient souvent toucher une moyenne mobile suivie (50 ou 200) avant de rebondir : un pullback classique vers un support dynamique." },
      { title: "Le retest d'une cassure", detail: "Après la cassure d'une résistance, le retour sur ce niveau (devenu support) qui tient offre une entrée avec un stop serré juste en dessous." },
      { title: "Pullback ou retournement ?", detail: "Un repli qui efface une part trop importante du mouvement précédent, ou casse la structure de tendance, n'est plus un simple pullback mais le signe d'un possible retournement." },
    ],
    keyPoints: [
      "Le pullback est un repli temporaire dans le sens de la tendance.",
      "Entrer sur repli améliore souvent le rapport risque/gain.",
      "Le retest d'un niveau cassé fournit un stop logique.",
      "Un repli trop profond peut trahir un retournement, pas un pullback.",
    ],
  },
  {
    slug: "faux-signaux-whipsaws",
    n: 59,
    title: "Les faux signaux et whipsaws",
    english: "False Signals & Whipsaws",
    level: "Intermédiaire",
    illu: "volatility",
    summary: "Pourquoi les indicateurs se trompent en range, et comment limiter les dégâts.",
    intro:
      "Un whipsaw est un faux signal : l'indicateur dit d'entrer, le prix part dans l'autre sens, puis se retourne encore. Ces va-et-vient sont fréquents dans les marchés sans tendance, où les croisements de moyennes et les cassures se multiplient sans suite. Aucun outil n'y échappe : la parade tient à la sélection du contexte, à la confirmation et à une gestion stricte du risque.",
    gauges: [
      { label: "Difficulté", value: 60, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Coût pour le débutant", value: 84, verdict: "Élevé", scheme: "neutral" },
      { label: "Importance de la maîtrise", value: 90, verdict: "Décisive", scheme: "good-high" },
    ],
    examples: [
      { title: "Le range qui piège les moyennes", detail: "Dans un marché latéral, deux moyennes mobiles se croisent sans cesse, générant des signaux contradictoires qui s'annulent en frais et en pertes répétées." },
      { title: "Le filtre de tendance", detail: "N'appliquer les signaux de suivi de tendance que lorsqu'un filtre (ADX élevé, pente de moyenne) confirme qu'une tendance existe réduit fortement les whipsaws." },
      { title: "La confirmation multi-outils", detail: "Exiger qu'un signal soit corroboré par un second outil indépendant (volume, momentum) écarte une partie des faux départs, au prix d'une réactivité moindre." },
    ],
    keyPoints: [
      "Le whipsaw = faux signal typique des marchés sans tendance.",
      "Aucun indicateur n'est immunisé : le contexte prime.",
      "Filtrer par un indicateur de force de tendance limite les dégâts.",
      "La confirmation réduit les faux signaux mais ajoute du retard.",
    ],
  },
  {
    slug: "construire-plan-de-trading",
    n: 60,
    title: "Construire son plan de trading",
    english: "Building a Trading Plan",
    level: "Intermédiaire",
    illu: "plan",
    summary: "Le document qui transforme des intuitions éparses en méthode reproductible.",
    intro:
      "Un plan de trading écrit définit à l'avance ce que l'on fait, et surtout ce que l'on ne fait pas. Il précise les marchés suivis, les conditions d'entrée et de sortie, le risque par position, les horaires, et les règles de gestion des émotions. Sans plan, chaque décision se prend à chaud, sous l'influence du marché ; avec un plan, on exécute une méthode et on peut l'évaluer objectivement.",
    gauges: [
      { label: "Difficulté", value: 45, verdict: "Accessible", scheme: "good-low" },
      { label: "Impact sur la régularité", value: 94, verdict: "Décisif", scheme: "good-high" },
      { label: "Discipline d'application", value: 80, verdict: "Élevée", scheme: "neutral" },
    ],
    examples: [
      { title: "Les règles d'entrée et de sortie", detail: "Un plan définit précisément le déclencheur d'entrée, le stop, l'objectif et les conditions de sortie anticipée — pour ne rien décider dans l'urgence." },
      { title: "Le risque par position", detail: "Fixer à l'avance le pourcentage de capital risqué par trade (souvent 0,5 à 2 %) protège le compte des décisions émotionnelles après une perte." },
      { title: "Le bilan régulier", detail: "Un plan se relit et se révise : confronter ses trades au plan, via un journal, permet de séparer les erreurs de méthode des aléas du marché." },
    ],
    keyPoints: [
      "Un plan écrit définit à l'avance entrées, sorties, risque et règles.",
      "Il transforme des décisions émotionnelles en méthode reproductible.",
      "Le risque par position se fixe avant le trade, jamais pendant.",
      "Un plan se relit, se mesure (journal) et se révise dans le temps.",
    ],
  },
  {
    slug: "comprendre-les-indices",
    n: 61,
    title: "Comprendre les indices boursiers",
    english: "Understanding Market Indices",
    level: "Débutant",
    illu: "chart-anatomy",
    summary: "Ce que mesure réellement un indice — et pourquoi sa méthode de calcul change tout.",
    intro:
      "Un indice boursier (S&P 500, CAC 40, SMI…) résume la performance d'un panier d'actions. Mais la façon dont il est construit influe sur ce qu'il reflète : pondéré par la capitalisation, il est dominé par les géants ; pondéré par le prix, par les actions à cours élevé ; équipondéré, il donne autant de poids à chaque société. Comprendre la méthode, c'est savoir ce que l'indice raconte vraiment.",
    gauges: [
      { label: "Difficulté", value: 30, verdict: "Accessible", scheme: "good-low" },
      { label: "Utilité pour situer le marché", value: 90, verdict: "Forte", scheme: "good-high" },
    ],
    examples: [
      { title: "Pondération par capitalisation", detail: "Dans le S&P 500, quelques méga-capitalisations technologiques pèsent une part énorme de l'indice : il peut monter alors que la majorité des actions stagnent." },
      { title: "Pondération par le prix", detail: "Le Dow Jones pondère par le cours, non la taille : une action à cours élevé y pèse plus qu'une grande entreprise au cours modeste, une méthode aujourd'hui jugée datée." },
      { title: "Prix vs rendement total", detail: "Un indice « prix » ignore les dividendes ; sa version « rendement total » les réintègre. Sur le long terme, l'écart entre les deux est considérable." },
    ],
    keyPoints: [
      "Un indice résume un panier d'actions selon une méthode de pondération.",
      "Capitalisation, prix ou équipondéré : la méthode change ce qu'il reflète.",
      "Quelques géants peuvent masquer la santé réelle du marché large.",
      "Indice « prix » et « rendement total » divergent fortement sur la durée.",
    ],
  },
  {
    slug: "obligations-et-taux",
    n: 62,
    title: "Obligations et taux d'intérêt",
    english: "Bonds & Interest Rates",
    level: "Intermédiaire",
    illu: "rates",
    summary: "Pourquoi le prix d'une obligation baisse quand les taux montent — et ce que dit la courbe.",
    intro:
      "Une obligation est un prêt : on prête un capital contre des intérêts (le coupon) et un remboursement à l'échéance. Sa mécanique fondamentale : le prix d'une obligation évolue à l'inverse des taux. Quand les taux montent, les obligations anciennes, moins rémunératrices, perdent de la valeur. La sensibilité à ce mouvement (la duration) et la forme de la courbe des taux sont des repères macro essentiels.",
    gauges: [
      { label: "Difficulté", value: 58, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Importance macro", value: 92, verdict: "Majeure", scheme: "good-high" },
      { label: "Sous-estimation par les débutants", value: 70, verdict: "Fréquente", scheme: "neutral" },
    ],
    examples: [
      { title: "Le balancier prix/taux", detail: "Si les taux passent de 2 % à 4 %, une obligation ancienne à coupon de 2 % devient moins attractive : son prix baisse jusqu'à offrir un rendement comparable au marché." },
      { title: "La duration", detail: "Plus l'échéance est lointaine, plus le prix réagit aux variations de taux. Une obligation à 10 ans souffre bien plus d'une hausse de taux qu'une obligation à 2 ans." },
      { title: "La courbe inversée", detail: "Quand les taux courts dépassent les taux longs, la courbe s'inverse — un signal historiquement scruté car souvent associé à un ralentissement à venir." },
    ],
    keyPoints: [
      "Le prix d'une obligation évolue à l'inverse des taux d'intérêt.",
      "La duration mesure la sensibilité du prix aux variations de taux.",
      "La courbe des taux renseigne sur les anticipations macro.",
      "Une courbe inversée est un signal de prudence historiquement suivi.",
    ],
  },
  {
    slug: "biais-des-donnees-backtest",
    n: 63,
    title: "Les biais des données : survie & look-ahead",
    english: "Data Biases: Survivorship & Look-Ahead",
    level: "Avancé",
    illu: "survivor",
    summary: "Pourquoi des données mal choisies rendent un backtest trompeusement brillant.",
    intro:
      "Un backtest ne vaut que ce que valent ses données. Deux biais classiques le faussent : le biais du survivant, qui ne garde que les sociétés ayant survécu (oubliant les faillites), et le biais de look-ahead, qui utilise sans le vouloir une information indisponible à l'époque. Tous deux gonflent artificiellement les performances passées et font miroiter des stratégies qui échouent en réel.",
    gauges: [
      { label: "Difficulté", value: 80, verdict: "Avancée", scheme: "good-low" },
      { label: "Danger pour le systématique", value: 90, verdict: "Majeur", scheme: "neutral" },
      { label: "Méconnaissance fréquente", value: 82, verdict: "Élevée", scheme: "good-high" },
    ],
    examples: [
      { title: "Le biais du survivant", detail: "Tester une stratégie sur les seules entreprises encore cotées aujourd'hui ignore toutes celles qui ont fait faillite : la performance affichée est artificiellement embellie." },
      { title: "Le biais de look-ahead", detail: "Utiliser un bénéfice annuel dès le 1er janvier alors qu'il n'a été publié qu'en mars revient à « voir le futur » : le backtest devient irréaliste." },
      { title: "Les données ajustées", detail: "Splits, dividendes et changements d'indices doivent être traités avec soin ; des données mal nettoyées créent des signaux qui n'existaient pas à l'époque." },
    ],
    keyPoints: [
      "Le biais du survivant ignore les sociétés disparues et embellit le passé.",
      "Le look-ahead utilise une information indisponible à la date testée.",
      "Ces biais font briller des stratégies qui échouent en réel.",
      "La qualité et la datation des données priment sur la sophistication du modèle.",
    ],
  },
  {
    slug: "lire-un-rapport-de-resultats",
    n: 64,
    title: "Lire un rapport de résultats",
    english: "Reading an Earnings Report",
    level: "Intermédiaire",
    illu: "balance-sheet",
    summary: "Au-delà du cours : ce que disent le chiffre d'affaires, la marge et les prévisions.",
    intro:
      "Même un analyste technique gagne à comprendre les résultats d'entreprise, car ils déclenchent des mouvements majeurs. Un rapport trimestriel donne le chiffre d'affaires, le bénéfice, les marges et, souvent, des prévisions (guidance). Le cours ne réagit pas tant aux chiffres absolus qu'à l'écart avec les attentes — et au ton du discours sur l'avenir.",
    gauges: [
      { label: "Difficulté", value: 54, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Impact sur la volatilité", value: 88, verdict: "Fort", scheme: "good-high" },
      { label: "Pont technique / fondamental", value: 75, verdict: "Utile", scheme: "neutral" },
    ],
    examples: [
      { title: "Battre les attentes", detail: "Une entreprise peut publier un bénéfice en hausse et voir son cours chuter si le marché attendait mieux : c'est l'écart aux prévisions (« surprise ») qui compte." },
      { title: "Le poids de la guidance", detail: "Les prévisions données par la direction pour les trimestres suivants pèsent souvent plus que les chiffres du trimestre écoulé : le marché achète l'avenir." },
      { title: "La volatilité des résultats", detail: "Les publications de résultats provoquent des gaps et des mouvements brutaux : beaucoup de traders évitent de porter une position juste avant l'annonce." },
    ],
    keyPoints: [
      "Le cours réagit à l'écart aux attentes, pas aux chiffres absolus.",
      "La guidance (prévisions) pèse souvent plus que le trimestre écoulé.",
      "Les résultats provoquent gaps et fortes variations.",
      "Comprendre les résultats relie l'analyse fondamentale et technique.",
    ],
  },
  {
    slug: "analyse-fondamentale-bases",
    n: 65,
    title: "Les bases de l'analyse fondamentale",
    english: "Fundamentals Basics",
    level: "Débutant",
    illu: "valuation",
    summary: "Évaluer une entreprise par sa valeur réelle, et non par les seuls mouvements de son cours.",
    intro:
      "Là où l'analyse technique étudie le prix, l'analyse fondamentale étudie l'entreprise : ses bénéfices, sa dette, sa croissance, son secteur. L'idée est d'estimer une valeur « intrinsèque » et de la comparer au cours pour juger si une action est chère ou bon marché. Les deux approches se complètent plus qu'elles ne s'opposent.",
    gauges: [
      { label: "Difficulté", value: 40, verdict: "Accessible", scheme: "good-low" },
      { label: "Utilité long terme", value: 92, verdict: "Majeure", scheme: "good-high" },
    ],
    examples: [
      { title: "Le trio essentiel", detail: "Trois documents résument la santé d'une entreprise : le bilan (ce qu'elle possède et doit), le compte de résultat (ce qu'elle gagne) et les flux de trésorerie (le cash réel généré)." },
      { title: "Prix ≠ valeur", detail: "Une action peut monter sans que l'entreprise n'aille mieux, et inversement. L'analyse fondamentale cherche à savoir ce que vaut vraiment l'affaire derrière le ticker." },
    ],
    keyPoints: [
      "La fondamentale évalue l'entreprise, la technique évalue le prix.",
      "Bilan, compte de résultat et flux de trésorerie sont la base.",
      "On compare valeur estimée et cours pour juger d'une décote ou d'une surcote.",
    ],
  },
  {
    slug: "ratios-de-valorisation",
    n: 66,
    title: "Les ratios de valorisation",
    english: "Valuation Ratios",
    level: "Intermédiaire",
    illu: "per",
    summary: "PER, PBV, EV/EBITDA : les repères pour juger si une action est chère.",
    intro:
      "Les ratios de valorisation rapportent le prix d'une action à une grandeur économique : bénéfice (PER), fonds propres (PBV), ou valeur d'entreprise rapportée à l'EBITDA. Ils permettent de comparer des sociétés entre elles et au regard de leur historique, sans se fier au seul cours absolu.",
    gauges: [
      { label: "Difficulté", value: 55, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Utilité comparative", value: 88, verdict: "Forte", scheme: "good-high" },
    ],
    examples: [
      { title: "Le PER", detail: "Un PER de 15 signifie qu'on paie 15 fois le bénéfice annuel. Élevé, il suppose une forte croissance attendue ; bas, il peut signaler une décote… ou un problème." },
      { title: "Comparer ce qui est comparable", detail: "Un PER ne vaut que face à ceux du même secteur et à l'historique de la société : comparer une techno en hyper-croissance à une banque n'a aucun sens." },
    ],
    keyPoints: [
      "Les ratios rapportent le prix à une grandeur économique.",
      "PER (bénéfices), PBV (fonds propres), EV/EBITDA (valeur d'entreprise).",
      "Un ratio se juge par rapport au secteur et à l'historique, jamais seul.",
    ],
  },
  {
    slug: "lire-un-bilan",
    n: 67,
    title: "Lire un bilan",
    english: "Reading a Balance Sheet",
    level: "Intermédiaire",
    illu: "balance-sheet",
    summary: "Ce qu'une entreprise possède, ce qu'elle doit, et ce qui reste aux actionnaires.",
    intro:
      "Le bilan est une photo du patrimoine d'une entreprise à un instant donné. À gauche, l'actif (ce qu'elle possède) ; à droite, le passif (ce qu'elle doit) et les capitaux propres (ce qui revient aux actionnaires). L'équilibre actif = passif + capitaux propres est la règle d'or de la comptabilité.",
    gauges: [
      { label: "Difficulté", value: 60, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Importance solvabilité", value: 90, verdict: "Majeure", scheme: "good-high" },
    ],
    examples: [
      { title: "La structure financière", detail: "Le rapport entre dette et capitaux propres révèle la solidité : une entreprise surendettée est plus fragile face aux chocs et aux hausses de taux." },
      { title: "La trésorerie", detail: "Le cash au bilan est un coussin de sécurité : il permet de tenir en cas de coup dur et de saisir des opportunités sans dépendre des banques." },
    ],
    keyPoints: [
      "Le bilan est une photo : actif = passif + capitaux propres.",
      "Le rapport dette / fonds propres mesure la solidité.",
      "La trésorerie est un coussin de sécurité et de flexibilité.",
    ],
  },
  {
    slug: "lire-compte-de-resultat",
    n: 68,
    title: "Lire un compte de résultat",
    english: "Reading an Income Statement",
    level: "Intermédiaire",
    illu: "valuation",
    summary: "Du chiffre d'affaires au bénéfice net : où l'argent se crée et se perd.",
    intro:
      "Le compte de résultat retrace l'activité sur une période : il part du chiffre d'affaires et en soustrait les coûts, étage par étage, jusqu'au bénéfice net. Les marges (brute, opérationnelle, nette) révèlent l'efficacité de l'entreprise à transformer ses ventes en profit.",
    gauges: [
      { label: "Difficulté", value: 58, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Lecture de la rentabilité", value: 90, verdict: "Majeure", scheme: "good-high" },
    ],
    examples: [
      { title: "Les marges", detail: "Deux entreprises au même chiffre d'affaires peuvent avoir des bénéfices très différents : c'est la marge qui distingue une activité rentable d'une activité qui tourne à vide." },
      { title: "La croissance rentable", detail: "Une hausse du chiffre d'affaires n'a de valeur que si elle s'accompagne du maintien des marges : croître à perte détruit de la valeur." },
    ],
    keyPoints: [
      "Le compte de résultat va du chiffre d'affaires au bénéfice net.",
      "Les marges mesurent l'efficacité à transformer les ventes en profit.",
      "Croître sans préserver les marges peut détruire de la valeur.",
    ],
  },
  {
    slug: "flux-de-tresorerie",
    n: 69,
    title: "Les flux de trésorerie",
    english: "Cash Flow Statement",
    level: "Intermédiaire",
    illu: "cash-flow",
    summary: "Le cash réel généré par une entreprise — souvent plus parlant que le bénéfice comptable.",
    intro:
      "Le tableau des flux de trésorerie suit l'argent qui entre et sort réellement, réparti en trois flux : exploitation, investissement et financement. Le « free cash flow » (cash d'exploitation moins investissements) est particulièrement scruté : c'est l'argent disponible pour rembourser la dette, verser des dividendes ou racheter des actions.",
    gauges: [
      { label: "Difficulté", value: 64, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Robustesse de l'indicateur", value: 92, verdict: "Élevée", scheme: "good-high" },
    ],
    examples: [
      { title: "Le bénéfice se manipule, le cash moins", detail: "Une entreprise peut afficher un bénéfice comptable tout en brûlant du cash. Le flux de trésorerie est plus difficile à habiller : il révèle la réalité économique." },
      { title: "Le free cash flow", detail: "Une société qui génère un free cash flow solide et croissant peut financer son développement, ses dividendes et ses rachats d'actions sans s'endetter." },
    ],
    keyPoints: [
      "Les flux suivent le cash réel : exploitation, investissement, financement.",
      "Le free cash flow = cash d'exploitation − investissements.",
      "Le cash est plus difficile à maquiller que le bénéfice comptable.",
    ],
  },
  {
    slug: "dividendes-et-rendement",
    n: 70,
    title: "Dividendes & rendement",
    english: "Dividends & Yield",
    level: "Débutant",
    illu: "dividend",
    summary: "La part des bénéfices reversée aux actionnaires, et ce qu'elle dit de l'entreprise.",
    intro:
      "Le dividende est la fraction du bénéfice qu'une société redistribue à ses actionnaires. Le rendement du dividende (dividende / cours) mesure ce revenu rapporté au prix. Une politique de dividende stable et croissante signale souvent une entreprise mûre et confiante — mais un rendement très élevé peut aussi cacher un cours en chute.",
    gauges: [
      { label: "Difficulté", value: 35, verdict: "Accessible", scheme: "good-low" },
      { label: "Attrait pour le revenu", value: 85, verdict: "Fort", scheme: "good-high" },
    ],
    examples: [
      { title: "Le rendement sur coût", detail: "Acheté tôt, un titre dont le dividende croît voit son rendement rapporté au prix d'achat initial grimper année après année — l'effet « rendement sur coût »." },
      { title: "Le piège du rendement élevé", detail: "Un rendement qui bondit parce que le cours s'effondre n'est pas une aubaine : il peut annoncer une coupe du dividende. Mieux vaut un dividende soutenable qu'un rendement spectaculaire." },
    ],
    keyPoints: [
      "Le dividende redistribue une part du bénéfice aux actionnaires.",
      "Rendement = dividende / cours.",
      "Un rendement très élevé peut signaler un risque, pas une opportunité.",
    ],
  },
  {
    slug: "options-bases",
    n: 71,
    title: "Les options : les bases",
    english: "Options Basics",
    level: "Intermédiaire",
    illu: "option-payoff",
    summary: "Le droit d'acheter ou de vendre un actif à un prix fixé — un outil puissant et risqué.",
    intro:
      "Une option donne le droit, non l'obligation, d'acheter (call) ou de vendre (put) un actif à un prix fixé (strike) jusqu'à une échéance, contre le paiement d'une prime. Acheteur et vendeur ont des profils opposés : le premier a une perte limitée et un gain potentiel élevé, le second l'inverse. C'est la brique des stratégies sur dérivés.",
    gauges: [
      { label: "Difficulté", value: 66, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Risque si mal utilisé", value: 85, verdict: "Élevé", scheme: "neutral" },
    ],
    examples: [
      { title: "Call et put", detail: "Acheter un call parie sur la hausse, acheter un put sur la baisse (ou protège un portefeuille). Dans les deux cas, la perte de l'acheteur est limitée à la prime." },
      { title: "La prime", detail: "La prime se compose d'une valeur intrinsèque (gain immédiat) et d'une valeur temps qui s'érode jusqu'à l'échéance : une option peut perdre de la valeur même si le sous-jacent ne bouge pas." },
    ],
    keyPoints: [
      "Une option = droit d'acheter (call) ou vendre (put) à un prix fixé.",
      "L'acheteur a une perte limitée (la prime), le vendeur un risque plus ouvert.",
      "La prime = valeur intrinsèque + valeur temps (qui s'érode).",
    ],
  },
  {
    slug: "strategies-options",
    n: 72,
    title: "Stratégies d'options",
    english: "Options Strategies",
    level: "Avancé",
    illu: "option-payoff",
    summary: "Combiner calls et puts pour façonner un profil de gain sur mesure.",
    intro:
      "Au-delà de l'achat simple, on combine plusieurs options pour construire des profils de gain adaptés à une anticipation : spreads pour réduire le coût, straddles pour jouer la volatilité, covered calls pour générer du revenu. Chaque stratégie a son couple risque/rendement et son scénario idéal.",
    gauges: [
      { label: "Difficulté", value: 82, verdict: "Avancée", scheme: "good-low" },
      { label: "Flexibilité offerte", value: 90, verdict: "Élevée", scheme: "good-high" },
    ],
    examples: [
      { title: "Le spread", detail: "Acheter un call et en vendre un autre plus haut réduit le coût d'entrée, au prix d'un gain plafonné : un pari haussier modéré et maîtrisé." },
      { title: "Le straddle", detail: "Acheter un call et un put au même strike parie sur un fort mouvement, peu importe le sens — utile avant un événement à l'issue incertaine." },
    ],
    keyPoints: [
      "Combiner options = façonner un profil de gain sur mesure.",
      "Spreads (coût réduit), straddles (volatilité), covered calls (revenu).",
      "Chaque stratégie a un scénario idéal et un risque propre.",
    ],
  },
  {
    slug: "les-grecques",
    n: 73,
    title: "Les grecques des options",
    english: "The Greeks",
    level: "Avancé",
    illu: "greeks",
    summary: "Delta, gamma, thêta, véga : les sensibilités qui pilotent le prix d'une option.",
    intro:
      "Les « grecques » mesurent comment la prime d'une option réagit à chaque facteur : le delta (prix du sous-jacent), le gamma (variation du delta), le thêta (temps qui passe), le véga (volatilité) et le rhô (taux). Les maîtriser, c'est comprendre pourquoi une option monte ou baisse, au-delà du seul cours du sous-jacent.",
    gauges: [
      { label: "Difficulté", value: 86, verdict: "Avancée", scheme: "good-low" },
      { label: "Importance pour les options", value: 92, verdict: "Critique", scheme: "good-high" },
    ],
    examples: [
      { title: "Delta & thêta", detail: "Le delta dit combien la prime bouge si le sous-jacent varie d'1 € ; le thêta, combien elle perd chaque jour qui passe. L'acheteur joue le delta contre le thêta." },
      { title: "Le véga avant un événement", detail: "Avant une annonce, la volatilité implicite gonfle la prime via le véga ; après, elle s'effondre (vol crush), pénalisant l'acheteur même si le cours bouge." },
    ],
    keyPoints: [
      "Les grecques mesurent la sensibilité de la prime à chaque facteur.",
      "Delta (prix), gamma (accélération), thêta (temps), véga (volatilité), rhô (taux).",
      "Comprendre les grecques explique les mouvements d'une option.",
    ],
  },
  {
    slug: "smile-de-volatilite",
    n: 74,
    title: "Le smile de volatilité",
    english: "Volatility Smile & Skew",
    level: "Avancé",
    illu: "vol-smile",
    summary: "Pourquoi la volatilité implicite varie selon le prix d'exercice des options.",
    intro:
      "En théorie, toutes les options d'un même actif devraient partager la même volatilité implicite. En pratique, elle varie selon le strike, dessinant un « smile » ou un « skew ». Sur les actions, les puts hors la monnaie affichent souvent une volatilité plus élevée : le marché paie plus cher la protection contre les krachs.",
    gauges: [
      { label: "Difficulté", value: 88, verdict: "Avancée", scheme: "good-low" },
      { label: "Information sur la peur", value: 82, verdict: "Forte", scheme: "good-high" },
    ],
    examples: [
      { title: "Le skew des actions", detail: "Les puts de protection sont relativement plus chers que les calls : c'est la trace de la demande d'assurance contre les baisses, plus craintes que les hausses." },
      { title: "Lire la peur", detail: "Un skew qui s'accentue traduit une demande accrue de protection — un signal de nervosité du marché, au-delà du seul niveau du VIX." },
    ],
    keyPoints: [
      "La volatilité implicite varie selon le strike (smile / skew).",
      "Sur actions, les puts hors la monnaie sont souvent plus « chers ».",
      "Le skew renseigne sur la demande de protection et la peur.",
    ],
  },
  {
    slug: "etf-et-trackers",
    n: 75,
    title: "ETF & trackers",
    english: "ETFs & Index Funds",
    level: "Débutant",
    illu: "etf",
    summary: "Investir dans un panier entier d'actifs en une seule ligne, à faible coût.",
    intro:
      "Un ETF (tracker) est un fonds coté en Bourse qui réplique un indice ou un panier d'actifs. En une seule transaction, on s'expose à des centaines de titres, avec des frais très bas et une grande liquidité. C'est l'outil emblématique de la gestion passive, popularisé pour sa simplicité et son efficacité de long terme.",
    gauges: [
      { label: "Difficulté", value: 32, verdict: "Accessible", scheme: "good-low" },
      { label: "Utilité pour diversifier", value: 93, verdict: "Majeure", scheme: "good-high" },
    ],
    examples: [
      { title: "La diversification instantanée", detail: "Un ETF répliquant un grand indice mondial donne, en une ligne, une exposition à des milliers d'entreprises de dizaines de pays." },
      { title: "Le poids des frais", detail: "Sur 20 ou 30 ans, l'écart de frais entre un ETF (souvent < 0,3 %) et un fonds actif (souvent > 1,5 %) représente une part énorme de la performance finale." },
    ],
    keyPoints: [
      "Un ETF réplique un indice ou un panier, coté en continu.",
      "Diversification immédiate et frais réduits.",
      "Pilier de la gestion passive de long terme.",
    ],
  },
  {
    slug: "types-obligations",
    n: 76,
    title: "Les types d'obligations",
    english: "Types of Bonds",
    level: "Intermédiaire",
    illu: "bond",
    summary: "D'État ou d'entreprise, à taux fixe ou variable, sûres ou à haut rendement.",
    intro:
      "Toutes les obligations ne se valent pas. On distingue les émetteurs (États, entreprises), la qualité de crédit (investment grade vs high yield), le type de coupon (fixe, variable, indexé sur l'inflation) et l'échéance. Chacune de ces dimensions modifie le rendement offert et le risque encouru.",
    gauges: [
      { label: "Difficulté", value: 56, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Utilité allocation", value: 84, verdict: "Forte", scheme: "good-high" },
    ],
    examples: [
      { title: "Investment grade vs high yield", detail: "Une obligation d'État bien notée rapporte peu mais est sûre ; une obligation high yield rapporte plus, en rémunération d'un risque de défaut plus élevé." },
      { title: "Les obligations indexées", detail: "Certaines obligations indexent leur coupon ou leur capital sur l'inflation, protégeant le pouvoir d'achat du créancier en période de hausse des prix." },
    ],
    keyPoints: [
      "Émetteur, qualité de crédit, type de coupon et échéance définissent une obligation.",
      "Investment grade (sûr, peu rémunérateur) vs high yield (risqué, rémunérateur).",
      "Les obligations indexées protègent de l'inflation.",
    ],
  },
  {
    slug: "courbe-des-taux",
    n: 77,
    title: "La courbe des taux",
    english: "The Yield Curve",
    level: "Intermédiaire",
    illu: "yield-curve",
    summary: "Le graphique des taux selon l'échéance — un baromètre scruté de l'économie.",
    intro:
      "La courbe des taux relie les rendements des obligations d'un même émetteur selon leur échéance. Normalement ascendante (les taux longs dépassent les courts), elle peut s'aplatir ou s'inverser. Une inversion — taux courts supérieurs aux taux longs — a historiquement précédé de nombreuses récessions.",
    gauges: [
      { label: "Difficulté", value: 62, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Valeur de signal macro", value: 90, verdict: "Majeure", scheme: "good-high" },
    ],
    examples: [
      { title: "La courbe inversée", detail: "Quand le taux à 2 ans dépasse celui à 10 ans, la courbe s'inverse : un signal historiquement associé à un ralentissement économique à venir." },
      { title: "La pentification", detail: "Une courbe qui se redresse fortement traduit souvent des anticipations de reprise et d'inflation, ou un assouplissement monétaire à venir." },
    ],
    keyPoints: [
      "La courbe relie taux et échéances d'un même émetteur.",
      "Normalement ascendante ; une inversion alerte sur une récession possible.",
      "Sa forme renseigne sur les anticipations de croissance et d'inflation.",
    ],
  },
  {
    slug: "inflation-et-marches",
    n: 78,
    title: "Inflation & marchés",
    english: "Inflation & Markets",
    level: "Intermédiaire",
    illu: "inflation",
    summary: "Comment la hausse des prix érode les rendements et redistribue les cartes.",
    intro:
      "L'inflation est la hausse générale des prix : elle ronge le pouvoir d'achat et la valeur réelle des rendements. Elle pèse sur les obligations à taux fixe et sur les valeurs de croissance, tout en favorisant certains actifs réels (matières premières, immobilier). Comprendre son impact est clé pour situer le régime de marché.",
    gauges: [
      { label: "Difficulté", value: 58, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Impact sur les actifs", value: 92, verdict: "Majeur", scheme: "good-high" },
    ],
    examples: [
      { title: "Le rendement réel", detail: "Un placement à 4 % avec une inflation à 5 % fait perdre du pouvoir d'achat : c'est le rendement réel (net d'inflation), et non nominal, qui compte." },
      { title: "Gagnants et perdants", detail: "L'inflation pénalise les obligations longues à taux fixe, mais peut soutenir les matières premières et les entreprises capables de répercuter la hausse des prix." },
    ],
    keyPoints: [
      "L'inflation érode le pouvoir d'achat et les rendements réels.",
      "Elle pèse sur les obligations à taux fixe et les valeurs de croissance.",
      "Le rendement réel (net d'inflation) prime sur le rendement nominal.",
    ],
  },
  {
    slug: "politique-monetaire",
    n: 79,
    title: "La politique monétaire",
    english: "Monetary Policy",
    level: "Intermédiaire",
    illu: "money-supply",
    summary: "Comment les banques centrales pilotent les taux et la liquidité — et font bouger les marchés.",
    intro:
      "Les banques centrales (Fed, BCE, BNS) ajustent les taux directeurs et la quantité de monnaie pour viser la stabilité des prix et l'emploi. Baisser les taux stimule l'économie et soutient les actifs risqués ; les relever combat l'inflation mais pèse sur les marchés. Leurs décisions sont parmi les plus suivies au monde.",
    gauges: [
      { label: "Difficulté", value: 60, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Influence sur les marchés", value: 95, verdict: "Décisive", scheme: "good-high" },
    ],
    examples: [
      { title: "Taux et valorisations", detail: "Des taux bas rendent les actions plus attractives (rendements obligataires faibles) et gonflent les valorisations ; leur remontée fait l'effet inverse." },
      { title: "QE et QT", detail: "L'assouplissement quantitatif (QE) injecte des liquidités et soutient les actifs ; le resserrement (QT) les retire, agissant comme un frein." },
    ],
    keyPoints: [
      "Les banques centrales pilotent taux directeurs et liquidité.",
      "Taux bas = soutien aux actifs risqués ; taux hauts = frein.",
      "QE injecte des liquidités, QT en retire.",
    ],
  },
  {
    slug: "cycle-economique",
    n: 80,
    title: "Le cycle économique",
    english: "The Economic Cycle",
    level: "Intermédiaire",
    illu: "cycle",
    summary: "Expansion, surchauffe, ralentissement, récession : les saisons de l'économie.",
    intro:
      "L'économie évolue par cycles : expansion, pic, contraction, creux, puis reprise. À chaque phase correspondent des conditions différentes pour les marchés et des secteurs qui surperforment. Situer où l'on se trouve dans le cycle aide à comprendre le contexte, même si le calendrier exact reste imprévisible.",
    gauges: [
      { label: "Difficulté", value: 60, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Utilité pour le contexte", value: 86, verdict: "Forte", scheme: "good-high" },
    ],
    examples: [
      { title: "La rotation sectorielle", detail: "En début de cycle, les valeurs cycliques et financières mènent ; en fin de cycle, les secteurs défensifs (santé, consommation de base) prennent le relais." },
      { title: "Marchés en avance", detail: "Les marchés anticipent : ils baissent souvent avant la récession officielle et rebondissent avant la reprise visible — d'où le décalage avec l'économie réelle." },
    ],
    keyPoints: [
      "L'économie alterne expansion, pic, contraction et creux.",
      "Chaque phase favorise certains secteurs (rotation).",
      "Les marchés anticipent le cycle, avec un temps d'avance.",
    ],
  },
  {
    slug: "indicateurs-economiques",
    n: 81,
    title: "Lire les indicateurs économiques",
    english: "Reading Economic Indicators",
    level: "Intermédiaire",
    illu: "gdp",
    summary: "PIB, emploi, inflation, confiance : les chiffres qui font bouger les marchés.",
    intro:
      "Les statistiques économiques rythment la vie des marchés : PIB, chiffres de l'emploi, inflation (IPC), indices d'activité (PMI), confiance des ménages. On distingue les indicateurs avancés (qui anticipent), coïncidents (qui décrivent le présent) et retardés. Comme pour les résultats d'entreprise, c'est l'écart aux attentes qui fait réagir les cours.",
    gauges: [
      { label: "Difficulté", value: 58, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Impact court terme", value: 84, verdict: "Fort", scheme: "good-high" },
    ],
    examples: [
      { title: "L'écart aux attentes", detail: "Un chiffre de l'emploi meilleur que prévu peut faire monter… ou baisser les marchés, selon qu'il rapproche ou éloigne une baisse de taux. Le contexte prime." },
      { title: "Avancés vs retardés", detail: "Les PMI (avancés) renseignent sur la tendance à venir ; le chômage (retardé) confirme une situation déjà installée. Les mélanger induit en erreur." },
    ],
    keyPoints: [
      "PIB, emploi, inflation, PMI, confiance : les grands repères.",
      "Indicateurs avancés, coïncidents et retardés ont des rôles différents.",
      "C'est l'écart aux attentes qui meut les marchés à court terme.",
    ],
  },
  {
    slug: "marche-des-changes",
    n: 82,
    title: "Le marché des changes (Forex)",
    english: "The Foreign Exchange Market",
    level: "Intermédiaire",
    illu: "fx",
    summary: "Le plus grand marché du monde, où s'échangent les devises 24h/24.",
    intro:
      "Le marché des changes (Forex) est le plus vaste et le plus liquide au monde : on y échange des devises par paires (EUR/USD, USD/CHF…), 24h/24. Les cours dépendent des écarts de taux, de la croissance, de l'inflation et des flux de capitaux. C'est un marché à fort effet de levier, donc particulièrement risqué pour les particuliers.",
    gauges: [
      { label: "Difficulté", value: 64, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Risque du levier", value: 88, verdict: "Élevé", scheme: "neutral" },
    ],
    examples: [
      { title: "Le rôle des taux", detail: "Une devise dont la banque centrale relève les taux tend à s'apprécier, car elle attire les capitaux en quête de rendement (le « carry »)." },
      { title: "Le danger du levier", detail: "Le Forex se pratique avec des leviers élevés : un petit mouvement de change peut effacer toute la mise. La gestion du risque y est vitale." },
    ],
    keyPoints: [
      "Le Forex échange des devises par paires, 24h/24.",
      "Écarts de taux, croissance et flux de capitaux meuvent les cours.",
      "Le fort effet de levier en fait un marché à haut risque.",
    ],
  },
  {
    slug: "matieres-premieres",
    n: 83,
    title: "Les matières premières",
    english: "Commodities",
    level: "Intermédiaire",
    illu: "commodity",
    summary: "Pétrole, métaux, agricoles : une classe d'actifs guidée par l'offre, la demande et la géopolitique.",
    intro:
      "Les matières premières (énergie, métaux, produits agricoles) forment une classe d'actifs à part, sensible aux cycles économiques, à la météo et à la géopolitique. On y investit surtout via des contrats à terme ou des ETF. Leur prix peut être très volatil, et leur détention comporte des spécificités comme le coût de portage.",
    gauges: [
      { label: "Difficulté", value: 62, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Volatilité", value: 84, verdict: "Élevée", scheme: "neutral" },
    ],
    examples: [
      { title: "L'offre et la demande physique", detail: "Un choc d'offre (guerre, sécheresse, décision de l'OPEP) peut faire flamber un cours en quelques jours, indépendamment de toute analyse de marché classique." },
      { title: "Contango et backwardation", detail: "La forme de la courbe des contrats à terme (prix futurs au-dessus ou en dessous du comptant) influence fortement le rendement d'un investissement en matières premières." },
    ],
    keyPoints: [
      "Énergie, métaux, agricoles : guidés par l'offre, la demande et la géopolitique.",
      "Accès surtout via contrats à terme et ETF.",
      "Le coût de portage et la forme de la courbe à terme comptent.",
    ],
  },
  {
    slug: "crypto-actifs-bases",
    n: 84,
    title: "Les crypto-actifs : les bases",
    english: "Crypto Assets Basics",
    level: "Débutant",
    illu: "blockchain",
    summary: "Une classe d'actifs numérique, très volatile, fondée sur la blockchain.",
    intro:
      "Les crypto-actifs (Bitcoin, Ethereum…) sont des actifs numériques échangés sur des registres décentralisés (blockchains). Très volatils, ils ne génèrent pas de flux comme une action ou une obligation : leur valeur repose sur l'offre limitée, l'adoption et la spéculation. Ils comportent des risques spécifiques : plateformes, conservation des clés, régulation mouvante.",
    gauges: [
      { label: "Difficulté", value: 50, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Volatilité & risque", value: 92, verdict: "Très élevés", scheme: "neutral" },
    ],
    examples: [
      { title: "Pas de flux financiers", detail: "Contrairement à une action (bénéfices) ou une obligation (coupons), une crypto ne verse rien : sa valeur dépend uniquement de ce qu'un autre acceptera de payer." },
      { title: "Le risque de contrepartie", detail: "Confier ses cryptos à une plateforme, c'est lui faire crédit : les faillites de FTX et d'autres ont rappelé l'adage « not your keys, not your coins »." },
    ],
    keyPoints: [
      "Actifs numériques sur blockchain, très volatils.",
      "Pas de flux : valeur fondée sur l'offre, l'adoption, la spéculation.",
      "Risques propres : plateformes, conservation des clés, régulation.",
    ],
  },
  {
    slug: "or-valeurs-refuges",
    n: 85,
    title: "L'or & les valeurs refuges",
    english: "Gold & Safe Havens",
    level: "Débutant",
    illu: "commodity",
    summary: "Les actifs vers lesquels les investisseurs se réfugient en période de peur.",
    intro:
      "En temps de crise, les capitaux fuient vers des actifs réputés sûrs : l'or, certaines devises (dollar, franc suisse, yen) et les obligations d'État de qualité. Ces « valeurs refuges » ne rapportent souvent rien, mais préservent le capital quand le reste chute. L'or, en particulier, est vu comme une réserve de valeur millénaire et une protection contre l'inflation.",
    gauges: [
      { label: "Difficulté", value: 38, verdict: "Accessible", scheme: "good-low" },
      { label: "Rôle en crise", value: 86, verdict: "Important", scheme: "good-high" },
    ],
    examples: [
      { title: "L'or en crise", detail: "Lors des grandes paniques, l'or tend à monter ou à mieux résister que les actions : il joue son rôle de réserve de valeur décorrélée." },
      { title: "Le coût du refuge", detail: "Un refuge a un prix : l'or ne verse aucun revenu, et s'y réfugier durablement peut faire manquer la reprise des actifs risqués." },
    ],
    keyPoints: [
      "Or, dollar, franc suisse, yen, obligations sûres : les refuges classiques.",
      "Ils préservent le capital quand le risque chute.",
      "Leur sécurité a un coût : peu ou pas de rendement.",
    ],
  },
  {
    slug: "immobilier-cote-reits",
    n: 86,
    title: "L'immobilier coté (REITs)",
    english: "Listed Real Estate (REITs)",
    level: "Intermédiaire",
    illu: "real-estate",
    summary: "Investir dans la pierre en Bourse, avec liquidité et dividendes réguliers.",
    intro:
      "Les sociétés immobilières cotées (REITs, ou SIIC en France) détiennent et exploitent des biens (bureaux, commerces, logistique) et en distribuent les loyers sous forme de dividendes. Elles permettent d'investir dans l'immobilier sans acheter de bien en direct, avec la liquidité de la Bourse — mais aussi sa volatilité.",
    gauges: [
      { label: "Difficulté", value: 54, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Attrait du rendement", value: 82, verdict: "Fort", scheme: "good-high" },
    ],
    examples: [
      { title: "Le rendement locatif coté", detail: "Une REIT redistribue l'essentiel de ses loyers : elle offre souvent un dividende élevé, à condition que le taux d'occupation et la valeur des actifs tiennent." },
      { title: "La sensibilité aux taux", detail: "L'immobilier coté est sensible aux taux d'intérêt : leur hausse renchérit la dette et pèse sur la valeur des biens, donc sur les REITs." },
    ],
    keyPoints: [
      "Les REITs investissent dans l'immobilier et distribuent les loyers.",
      "Liquidité boursière et dividendes réguliers.",
      "Forte sensibilité aux taux d'intérêt.",
    ],
  },
  {
    slug: "capital-investissement",
    n: 87,
    title: "Le capital-investissement",
    english: "Private Equity",
    level: "Avancé",
    illu: "ipo",
    summary: "Investir dans des entreprises non cotées, sur un horizon long et peu liquide.",
    intro:
      "Le capital-investissement (private equity) finance des entreprises non cotées, du démarrage (capital-risque) au rachat avec effet de levier (LBO). Il vise des rendements élevés sur un horizon long, en échange d'une forte illiquidité : l'argent est immobilisé plusieurs années. Réservé longtemps aux institutionnels, il s'ouvre progressivement aux particuliers.",
    gauges: [
      { label: "Difficulté", value: 80, verdict: "Avancée", scheme: "good-low" },
      { label: "Illiquidité", value: 90, verdict: "Très forte", scheme: "neutral" },
    ],
    examples: [
      { title: "Le LBO", detail: "Un rachat par effet de levier finance l'acquisition d'une entreprise surtout par la dette, remboursée ensuite par les flux de l'entreprise — un pari à haut rendement et haut risque." },
      { title: "La prime d'illiquidité", detail: "Le capital-investissement vise un surcroît de rendement en échange de l'immobilisation longue des fonds : la liquidité a un prix, ici inversé." },
    ],
    keyPoints: [
      "Le private equity finance des entreprises non cotées.",
      "Du capital-risque au LBO, sur un horizon long.",
      "Rendement potentiel élevé contre forte illiquidité.",
    ],
  },
  {
    slug: "gestion-passive-active",
    n: 88,
    title: "Gestion passive vs active",
    english: "Passive vs Active Management",
    level: "Débutant",
    illu: "benchmark",
    summary: "Répliquer le marché à bas coût, ou tenter de le battre — le grand débat.",
    intro:
      "La gestion passive cherche à répliquer un indice (via des ETF), à frais réduits. La gestion active tente de le battre par la sélection de titres, à frais plus élevés. Les études montrent qu'une majorité de fonds actifs sous-performent leur indice sur le long terme, surtout après frais — ce qui a propulsé la gestion passive.",
    gauges: [
      { label: "Difficulté", value: 42, verdict: "Accessible", scheme: "good-low" },
      { label: "Enjeu de frais", value: 90, verdict: "Majeur", scheme: "good-high" },
    ],
    examples: [
      { title: "Le poids des frais", detail: "Battre l'indice est déjà difficile ; le battre après des frais de 1,5 à 2 % l'est encore plus. C'est l'argument central en faveur du passif." },
      { title: "Quand l'actif a du sens", detail: "Sur des marchés moins efficients (petites valeurs, émergents) ou pour des objectifs précis, une gestion active de qualité peut encore apporter de la valeur." },
    ],
    keyPoints: [
      "Passif = répliquer l'indice à bas coût ; actif = tenter de le battre.",
      "La plupart des fonds actifs sous-performent après frais.",
      "Les frais sont le facteur décisif sur le long terme.",
    ],
  },
  {
    slug: "allocation-strategique-tactique",
    n: 89,
    title: "Allocation stratégique & tactique",
    english: "Strategic vs Tactical Allocation",
    level: "Intermédiaire",
    illu: "diversification",
    summary: "Fixer un cap d'allocation de long terme, puis l'ajuster à la marge selon le contexte.",
    intro:
      "L'allocation d'actifs se joue à deux niveaux. L'allocation stratégique fixe la répartition cible de long terme (par exemple 60 % actions / 40 % obligations) selon ses objectifs et son horizon. L'allocation tactique ajuste cette cible à la marge pour profiter de conditions de marché temporaires, sans dénaturer le cap.",
    gauges: [
      { label: "Difficulté", value: 64, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Impact sur la performance", value: 90, verdict: "Décisif", scheme: "good-high" },
    ],
    examples: [
      { title: "Le poids de l'allocation", detail: "Des études célèbres attribuent l'essentiel de la variabilité des rendements à l'allocation d'actifs, bien plus qu'au choix précis des titres." },
      { title: "Les écarts tactiques", detail: "Surpondérer temporairement les actions en début de cycle, ou la prudence en fin de cycle, relève du tactique — à doser pour ne pas trahir la stratégie." },
    ],
    keyPoints: [
      "Stratégique = cap de long terme ; tactique = ajustements à la marge.",
      "L'allocation explique l'essentiel de la variabilité des rendements.",
      "Le tactique se dose sans dénaturer la stratégie.",
    ],
  },
  {
    slug: "rebalancement-portefeuille",
    n: 90,
    title: "Le rééquilibrage de portefeuille",
    english: "Portfolio Rebalancing",
    level: "Intermédiaire",
    illu: "rotation",
    summary: "Ramener périodiquement son portefeuille à son allocation cible — une discipline payante.",
    intro:
      "Avec le temps, les actifs qui montent prennent un poids croissant et déforment l'allocation initiale. Le rééquilibrage consiste à revendre une part de ce qui a gonflé pour renforcer ce qui a baissé, afin de revenir à la cible. C'est une discipline contracyclique qui maîtrise le risque et force, mécaniquement, à « vendre haut, acheter bas ».",
    gauges: [
      { label: "Difficulté", value: 50, verdict: "Accessible", scheme: "good-low" },
      { label: "Effet sur le risque", value: 86, verdict: "Fort", scheme: "good-high" },
    ],
    examples: [
      { title: "La dérive d'allocation", detail: "Un portefeuille 60/40 devenu 75/25 après une forte hausse des actions est bien plus risqué qu'au départ : le rééquilibrage le ramène à son profil voulu." },
      { title: "Discipline, pas prévision", detail: "Le rééquilibrage suit une règle (calendaire ou par seuils) et ne cherche pas à deviner le marché : c'est sa force, il retire l'émotion de la décision." },
    ],
    keyPoints: [
      "Rééquilibrer = revenir à l'allocation cible.",
      "On allège ce qui a gonflé, on renforce ce qui a baissé.",
      "Discipline contracyclique qui maîtrise le risque, sans prévision.",
    ],
  },
  {
    slug: "theorie-moderne-portefeuille",
    n: 91,
    title: "La théorie moderne du portefeuille",
    english: "Modern Portfolio Theory",
    level: "Avancé",
    illu: "efficient-frontier",
    summary: "Comment la diversification optimise le couple risque/rendement (Markowitz).",
    intro:
      "Formalisée par Harry Markowitz, la théorie moderne du portefeuille montre que combiner des actifs peu corrélés réduit le risque global sans sacrifier le rendement. Il existe une « frontière efficiente » : l'ensemble des portefeuilles offrant le meilleur rendement pour un risque donné. La diversification y est qualifiée de « seul repas gratuit » de la finance.",
    gauges: [
      { label: "Difficulté", value: 82, verdict: "Avancée", scheme: "good-low" },
      { label: "Fondement théorique", value: 90, verdict: "Majeur", scheme: "good-high" },
    ],
    examples: [
      { title: "La frontière efficiente", detail: "Pour un niveau de risque accepté, il existe une combinaison d'actifs qui maximise le rendement attendu : viser cette frontière est l'objectif de l'allocation optimale." },
      { title: "Les limites", detail: "La théorie repose sur des corrélations et volatilités passées, qui peuvent changer brutalement — notamment en crise, où tout chute ensemble." },
    ],
    keyPoints: [
      "Combiner des actifs peu corrélés réduit le risque global.",
      "La frontière efficiente : meilleur rendement pour un risque donné.",
      "Limite : les corrélations passées peuvent se rompre en crise.",
    ],
  },
  {
    slug: "mesurer-la-performance",
    n: 92,
    title: "Mesurer la performance",
    english: "Measuring Performance",
    level: "Intermédiaire",
    illu: "benchmark",
    summary: "Comparer son rendement à un indice de référence, et ajuster du risque pris.",
    intro:
      "Une performance brute ne veut rien dire seule : il faut la comparer à un indice de référence (benchmark) et l'ajuster du risque encouru. Battre l'indice de 2 % en prenant deux fois plus de risque n'est pas une réussite. La performance se juge nette de frais, sur la durée, et au regard du risque.",
    gauges: [
      { label: "Difficulté", value: 56, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Honnêteté de l'évaluation", value: 88, verdict: "Forte", scheme: "good-high" },
    ],
    examples: [
      { title: "Le bon benchmark", detail: "Comparer un portefeuille d'actions mondiales à un indice monétaire flatte artificiellement : le benchmark doit refléter le même univers et le même risque." },
      { title: "Net de frais et de temps", detail: "Une belle année peut masquer une médiocre décennie. La performance se juge sur le long terme, nette de tous les frais." },
    ],
    keyPoints: [
      "La performance se compare à un benchmark pertinent.",
      "Elle s'ajuste du risque pris et se juge nette de frais.",
      "Le long terme prime sur une bonne année isolée.",
    ],
  },
  {
    slug: "ratios-risque-rendement",
    n: 93,
    title: "Les ratios risque/rendement",
    english: "Risk-Adjusted Ratios",
    level: "Avancé",
    illu: "risk-reward",
    summary: "Sharpe, Sortino, Calmar : juger un rendement à l'aune du risque qu'il a coûté.",
    intro:
      "Les ratios ajustés du risque rapportent le rendement à une mesure de risque. Le Sharpe utilise la volatilité totale ; le Sortino, la seule volatilité baissière ; le Calmar, la perte maximale (drawdown). Ils permettent de comparer des stratégies non pas sur leur seul gain, mais sur la qualité de ce gain.",
    gauges: [
      { label: "Difficulté", value: 78, verdict: "Avancée", scheme: "good-low" },
      { label: "Utilité comparative", value: 88, verdict: "Forte", scheme: "good-high" },
    ],
    examples: [
      { title: "Sharpe vs Sortino", detail: "Le Sharpe pénalise toute volatilité, y compris les bonnes surprises ; le Sortino ne retient que la volatilité baissière — plus juste pour qui ne craint que les pertes." },
      { title: "Le Calmar", detail: "Le Calmar rapporte le rendement au pire creux subi : il privilégie les stratégies qui gagnent sans infliger de drawdowns insoutenables." },
    ],
    keyPoints: [
      "Ces ratios rapportent le rendement au risque.",
      "Sharpe (volatilité totale), Sortino (baissière), Calmar (drawdown).",
      "Ils jugent la qualité d'un gain, pas seulement son ampleur.",
    ],
  },
  {
    slug: "fiscalite-investisseur",
    n: 94,
    title: "La fiscalité de l'investisseur",
    english: "Investor Taxation",
    level: "Intermédiaire",
    illu: "tax",
    summary: "L'impôt, ce coût souvent oublié qui ampute la performance réelle.",
    intro:
      "Les gains d'investissement (plus-values, dividendes, intérêts) sont imposés, et cet impôt réduit la performance réelle. Les règles varient selon les pays, les enveloppes et la durée de détention. Intégrer la fiscalité — sans en faire une obsession — est essentiel pour juger le rendement net, le seul qui compte vraiment.",
    gauges: [
      { label: "Difficulté", value: 60, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Impact sur le net", value: 86, verdict: "Fort", scheme: "good-high" },
    ],
    examples: [
      { title: "Brut vs net", detail: "Un gain de 10 % taxé à 30 % ne laisse que 7 % net. Raisonner en rendement brut surestime systématiquement la performance réelle." },
      { title: "L'effet de la durée", detail: "Reporter la vente, c'est différer l'impôt et laisser le capital composer plus longtemps : la fiscalité récompense souvent la patience." },
    ],
    keyPoints: [
      "Plus-values, dividendes et intérêts sont imposés.",
      "Le rendement net (après impôt) est le seul qui compte.",
      "Différer l'impôt laisse le capital composer plus longtemps.",
    ],
  },
  {
    slug: "enveloppes-investissement",
    n: 95,
    title: "Les enveloppes d'investissement",
    english: "Investment Wrappers",
    level: "Intermédiaire",
    illu: "retirement",
    summary: "PEA, assurance-vie, compte-titres : le contenant change le rendement net.",
    intro:
      "Au-delà des actifs choisis, l'enveloppe qui les abrite influence fortement la fiscalité et donc le rendement net. En France, le PEA, l'assurance-vie et le compte-titres ordinaire offrent des cadres très différents en matière d'impôt, de plafonds et de souplesse. Choisir la bonne enveloppe est aussi important que choisir les bons placements.",
    gauges: [
      { label: "Difficulté", value: 58, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Effet sur le net", value: 84, verdict: "Fort", scheme: "good-high" },
    ],
    examples: [
      { title: "Le PEA", detail: "Le plan d'épargne en actions offre une fiscalité allégée après quelques années de détention, en contrepartie de contraintes (plafond, univers d'actions éligibles)." },
      { title: "L'assurance-vie", detail: "L'assurance-vie combine souplesse, avantages successoraux et fiscalité dégressive avec le temps — un cadre de long terme privilégié en France." },
    ],
    keyPoints: [
      "L'enveloppe (PEA, assurance-vie, CTO) façonne la fiscalité.",
      "Chaque cadre a ses plafonds, sa souplesse et ses avantages.",
      "Bien choisir l'enveloppe importe autant que les placements.",
    ],
  },
  {
    slug: "investir-a-contre-courant",
    n: 96,
    title: "L'investissement à contre-courant",
    english: "Contrarian Investing",
    level: "Avancé",
    illu: "emotions",
    summary: "Acheter quand les autres paniquent, vendre quand l'euphorie domine.",
    intro:
      "L'investisseur contrarian agit à l'inverse de la foule : il s'intéresse aux actifs délaissés quand le pessimisme est extrême, et se méfie quand l'euphorie est généralisée. L'idée — résumée par l'adage « soyez avide quand les autres ont peur » — est que les excès de sentiment créent des écarts entre prix et valeur. C'est exigeant psychologiquement.",
    gauges: [
      { label: "Difficulté", value: 80, verdict: "Avancée", scheme: "good-low" },
      { label: "Exigence psychologique", value: 92, verdict: "Très forte", scheme: "neutral" },
    ],
    examples: [
      { title: "Les extrêmes de sentiment", detail: "Une peur extrême (indicateurs au plancher, capitulation) a historiquement offert de meilleurs points d'entrée que l'euphorie généralisée." },
      { title: "Le risque du contrarian", detail: "Aller contre la tendance trop tôt peut coûter cher : « le marché peut rester irrationnel plus longtemps que vous solvable ». La patience et la gestion du risque sont vitales." },
    ],
    keyPoints: [
      "Le contrarian agit à l'inverse des excès de la foule.",
      "Les extrêmes de sentiment créent des écarts prix/valeur.",
      "Aller contre la tendance trop tôt est coûteux : prudence.",
    ],
  },
  {
    slug: "investissement-value",
    n: 97,
    title: "L'investissement « value »",
    english: "Value Investing",
    level: "Intermédiaire",
    illu: "margin-of-safety",
    summary: "Acheter des entreprises de qualité en dessous de leur valeur réelle.",
    intro:
      "L'investissement dans la valeur, théorisé par Benjamin Graham et incarné par Warren Buffett, consiste à acheter des entreprises pour moins que leur valeur intrinsèque, créant une « marge de sécurité ». On privilégie les fondamentaux solides et la patience, en pariant que le marché finira par reconnaître la vraie valeur.",
    gauges: [
      { label: "Difficulté", value: 64, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Horizon requis", value: 88, verdict: "Long", scheme: "neutral" },
    ],
    examples: [
      { title: "La marge de sécurité", detail: "Acheter à 60 € une action estimée à 100 € offre un coussin : même si l'estimation est trop optimiste, le risque de perte est réduit." },
      { title: "La patience récompensée", detail: "La valeur peut mettre des années à se révéler. Le value investing suppose de tenir ses positions malgré l'impatience du marché." },
    ],
    keyPoints: [
      "Acheter sous la valeur intrinsèque crée une marge de sécurité.",
      "On privilégie fondamentaux solides et patience.",
      "Le pari : le marché finira par reconnaître la vraie valeur.",
    ],
  },
  {
    slug: "investissement-growth",
    n: 98,
    title: "L'investissement « growth »",
    english: "Growth Investing",
    level: "Intermédiaire",
    illu: "trend",
    summary: "Miser sur des entreprises à forte croissance, quitte à les payer cher.",
    intro:
      "À l'opposé du value, l'investissement de croissance (growth) cible des entreprises dont les revenus et bénéfices croissent vite, en pariant que cette croissance justifiera des valorisations élevées. On accepte de payer un PER important aujourd'hui pour des profits bien plus grands demain. C'est plus volatil et sensible aux taux d'intérêt.",
    gauges: [
      { label: "Difficulté", value: 64, verdict: "Intermédiaire", scheme: "good-low" },
      { label: "Sensibilité aux taux", value: 86, verdict: "Forte", scheme: "neutral" },
    ],
    examples: [
      { title: "Payer la croissance", detail: "Une entreprise dont les bénéfices doublent tous les deux ou trois ans peut justifier un PER élevé — tant que la croissance tient ses promesses." },
      { title: "Le risque de déception", detail: "Une valeur de croissance très chère chute brutalement à la moindre déception : le marché ne pardonne pas un ralentissement quand tout est déjà dans le prix." },
    ],
    keyPoints: [
      "Le growth mise sur une croissance rapide des bénéfices.",
      "On accepte des valorisations élevées pour des profits futurs.",
      "Plus volatil et sensible aux taux ; gare aux déceptions.",
    ],
  },
  {
    slug: "investissement-factoriel",
    n: 99,
    title: "L'investissement factoriel",
    english: "Factor Investing",
    level: "Avancé",
    illu: "factor",
    summary: "Exploiter des « primes » documentées : valeur, taille, momentum, qualité, faible volatilité.",
    intro:
      "L'investissement factoriel (ou smart beta) systématise la sélection d'actions selon des « facteurs » associés historiquement à un surcroît de rendement : value, taille (small caps), momentum, qualité, faible volatilité. Plutôt que de parier sur des titres précis, on s'expose à ces caractéristiques de façon diversifiée et règlementée.",
    gauges: [
      { label: "Difficulté", value: 82, verdict: "Avancée", scheme: "good-low" },
      { label: "Diversification des moteurs", value: 84, verdict: "Forte", scheme: "good-high" },
    ],
    examples: [
      { title: "Les grands facteurs", detail: "Value, taille, momentum, qualité et faible volatilité sont les facteurs les plus documentés par la recherche académique." },
      { title: "Les phases de sous-performance", detail: "Un facteur peut sous-performer pendant des années (le value l'a fait longtemps) : il faut de la discipline pour rester exposé jusqu'au retour de la prime." },
    ],
    keyPoints: [
      "Les facteurs ciblent des primes historiques : value, taille, momentum, qualité, faible volatilité.",
      "On s'expose à des caractéristiques, pas à des titres isolés.",
      "Les facteurs connaissent de longues phases de sous-performance.",
    ],
  },
  {
    slug: "erreurs-du-debutant",
    n: 100,
    title: "Les erreurs classiques du débutant",
    english: "Common Beginner Mistakes",
    level: "Débutant",
    illu: "golden-rules",
    summary: "Les pièges les plus fréquents — et comment les éviter dès le départ.",
    intro:
      "La plupart des débutants commettent les mêmes erreurs : trop de transactions, absence de plan, sur-exposition, poursuite des hausses, refus de couper les pertes. Les connaître à l'avance permet de les éviter. La bonne nouvelle : progresser tient souvent moins à trouver de bons coups qu'à supprimer les erreurs évitables.",
    gauges: [
      { label: "Difficulté", value: 30, verdict: "Accessible", scheme: "good-low" },
      { label: "Valeur préventive", value: 95, verdict: "Maximale", scheme: "good-high" },
    ],
    examples: [
      { title: "Courir après la hausse (FOMO)", detail: "Acheter un actif déjà très monté par peur de manquer le mouvement est l'erreur la plus coûteuse : on entre souvent au plus mauvais moment." },
      { title: "Ne pas couper les pertes", detail: "Garder une position perdante en espérant « revenir à l'équilibre » transforme une petite perte en gouffre. Limiter les pertes est la première règle de survie." },
    ],
    keyPoints: [
      "Surtrading, absence de plan et sur-exposition ruinent les débutants.",
      "La FOMO fait entrer au pire moment ; couper les pertes est vital.",
      "Progresser, c'est d'abord supprimer les erreurs évitables.",
    ],
  },
];
