/**
 * Krachs & crises historiques — données 100% éducatives (voix WMB).
 * On documente ce qui s'est passé, les chiffres clés et la leçon retenue.
 * Aucune prédiction, aucun conseil : l'Histoire éclaire, elle ne se répète pas
 * à l'identique. Illustrations SVG originales.
 */
import type { ConceptType } from "@/components/ConceptIllustration";

export type CrashEra = "avant-1900" | "xxe" | "xxie";

export type MarketCrash = {
  slug: string;
  name: string;
  english: string;
  era: CrashEra;
  year: string;
  region: string;
  illu: ConceptType;
  /** Repère d'ampleur affiché sur la carte, ex. « −89 % ». */
  drawdownLabel: string;
  severity: "Modérée" | "Majeure" | "Sévère";
  summary: string;
  context: string;
  trigger: string;
  magnitude: string;
  unfolding: string;
  aftermath: string;
  lesson: string;
  keyFigures: { label: string; value: string }[];
};

export const CRASH_ERAS: { id: CrashEra | "all"; label: string }[] = [
  { id: "all", label: "Toutes les époques" },
  { id: "avant-1900", label: "Avant 1900" },
  { id: "xxe", label: "XXᵉ siècle" },
  { id: "xxie", label: "XXIᵉ siècle" },
];

export const SEVERITY_META: Record<MarketCrash["severity"], { color: string }> = {
  Modérée: { color: "#C8A962" },
  Majeure: { color: "#D4A853" },
  Sévère: { color: "#B0413E" },
};

export const MARKET_CRASHES: MarketCrash[] = [
  {
    slug: "tulipomanie-1637",
    name: "La Tulipomanie",
    english: "Tulip Mania",
    era: "avant-1900",
    year: "1636-1637",
    region: "Provinces-Unies (Pays-Bas)",
    illu: "bubble",
    drawdownLabel: "≈ −99 %",
    severity: "Majeure",
    summary: "La première bulle spéculative documentée : des bulbes de tulipe au prix d'une maison.",
    context:
      "Dans la Hollande prospère du Siècle d'or, la tulipe — fleur rare importée de l'Empire ottoman — devient un objet de prestige. Un marché de contrats à terme sur les bulbes se développe, attirant artisans et commerçants séduits par des gains rapides.",
    trigger:
      "Au plus fort de la frénésie, début 1637, certains bulbes rares (comme le Semper Augustus) s'échangent contre l'équivalent de plusieurs années de salaire, voire d'une maison à Amsterdam. La spéculation se nourrit d'elle-même.",
    magnitude:
      "En février 1637, lors d'une vente à Haarlem, les acheteurs ne se présentent plus. La confiance s'évapore en quelques jours et les prix s'effondrent de plus de 90 %, certains bulbes ne valant bientôt presque plus rien.",
    unfolding:
      "La panique se propage : chacun veut vendre, personne n'achète. Les contrats à terme deviennent inexécutables et les autorités peinent à trancher les litiges. L'épisode reste limité à un segment de l'économie, sans effondrement général.",
    aftermath:
      "La tulipomanie est devenue le symbole intemporel de la folie spéculative collective, citée à chaque bulle ultérieure. Son ampleur économique réelle est aujourd'hui débattue par les historiens, mais sa portée pédagogique est immense.",
    lesson:
      "Quand le prix d'un actif se détache totalement de tout usage ou revenu, et ne tient que par l'espoir de revendre plus cher à un autre, la chute n'attend qu'un déclencheur. La nature humaine, elle, n'a pas changé depuis 1637.",
    keyFigures: [
      { label: "Année du krach", value: "1637" },
      { label: "Chute des prix", value: "> 90 %" },
      { label: "Statut", value: "1ʳᵉ bulle documentée" },
    ],
  },
  {
    slug: "mers-du-sud-1720",
    name: "La Bulle des Mers du Sud",
    english: "South Sea Bubble",
    era: "avant-1900",
    year: "1720",
    region: "Royaume-Uni",
    illu: "bubble",
    drawdownLabel: "≈ −85 %",
    severity: "Majeure",
    summary: "La spéculation sur une compagnie commerciale qui ruina même Isaac Newton.",
    context:
      "La South Sea Company, créée en 1711, obtient un monopole commercial sur l'Amérique du Sud et propose de reprendre une partie de la dette publique britannique. Une vaste opération de promotion gonfle artificiellement la valeur de son action.",
    trigger:
      "En 1720, l'action passe d'environ 100 à près de 1 000 livres en quelques mois, portée par des promesses de profits coloniaux jamais réalisés et une frénésie de souscriptions, imitée par une multitude de sociétés fantômes.",
    magnitude:
      "À l'été 1720, la bulle éclate : l'action s'effondre de près de 85 % avant la fin de l'année, ruinant des milliers d'investisseurs, dont l'aristocratie et le physicien Isaac Newton.",
    unfolding:
      "La panique entraîne faillites et scandales de corruption impliquant des responsables politiques. Le Parlement enquête ; le « Bubble Act » avait justement été voté pendant la frénésie pour limiter la création de sociétés.",
    aftermath:
      "L'épisode a durablement marqué la finance britannique et inspiré une méfiance envers les sociétés par actions. Newton aurait résumé sa perte par une phrase restée célèbre sur l'impossibilité de calculer la folie des foules.",
    lesson:
      "« Je peux calculer le mouvement des astres, mais pas la folie des hommes » : même le plus grand esprit scientifique de son temps a succombé à la spéculation. L'intelligence ne protège pas de l'emballement collectif.",
    keyFigures: [
      { label: "Sommet de l'action", value: "≈ 1 000 £" },
      { label: "Chute", value: "≈ 85 %" },
      { label: "Victime célèbre", value: "Isaac Newton" },
    ],
  },
  {
    slug: "krach-1929",
    name: "Le Krach de 1929",
    english: "The Wall Street Crash of 1929",
    era: "xxe",
    year: "1929-1932",
    region: "États-Unis (mondial)",
    illu: "drawdown",
    drawdownLabel: "−89 %",
    severity: "Sévère",
    summary: "L'effondrement qui ouvrit la Grande Dépression : le Dow Jones perdit près de 90 %.",
    context:
      "Les « Années folles » voient une euphorie boursière alimentée par l'achat à crédit (sur marge) : de nombreux particuliers spéculent avec de l'argent emprunté, parfois en n'apportant que 10 % de la valeur des titres.",
    trigger:
      "La bulle se retourne fin octobre 1929 : le Jeudi noir (24 octobre) puis le Mardi noir (29 octobre) voient des ventes massives et des appels de marge en cascade qui forcent les spéculateurs à liquider.",
    magnitude:
      "Du sommet de septembre 1929 au creux de juillet 1932, le Dow Jones perd environ 89 % de sa valeur. Il ne retrouvera son niveau de 1929 qu'en 1954, soit un quart de siècle plus tard.",
    unfolding:
      "Le krach se double d'une crise bancaire : des milliers de banques font faillite, la masse monétaire se contracte et la déflation s'installe. Le chômage américain dépasse 25 % au plus fort de la Grande Dépression.",
    aftermath:
      "La crise a refondé la régulation financière américaine : création de la SEC (1934), séparation banque de dépôt / banque d'investissement (Glass-Steagall), garantie des dépôts. Un avant et un après.",
    lesson:
      "L'effet de levier généralisé transforme une correction en effondrement : quand tout le monde emprunte pour spéculer, les appels de marge créent des ventes forcées qui s'auto-entretiennent. Le krach a façonné la finance moderne.",
    keyFigures: [
      { label: "Chute du Dow", value: "−89 %" },
      { label: "Retour au niveau de 1929", value: "1954" },
      { label: "Chômage US (pic)", value: "> 25 %" },
    ],
  },
  {
    slug: "lundi-noir-1987",
    name: "Le Lundi Noir",
    english: "Black Monday 1987",
    era: "xxe",
    year: "1987",
    region: "Mondial",
    illu: "drawdown",
    drawdownLabel: "−22,6 % (1 séance)",
    severity: "Sévère",
    summary: "La pire séance de l'histoire du Dow Jones : −22,6 % en une seule journée.",
    context:
      "Après une forte hausse, les marchés sont tendus. Une innovation se répand : l'« assurance de portefeuille », un système automatisé censé protéger en vendant des contrats à terme quand le marché baisse — au risque d'amplifier les chutes.",
    trigger:
      "Le 19 octobre 1987, une baisse initiale déclenche en cascade les ventes programmées de l'assurance de portefeuille. Les ordres automatiques alimentent la chute, qui alimente de nouveaux ordres : une boucle infernale.",
    magnitude:
      "En une seule séance, le Dow Jones perd 22,6 % — la plus forte baisse journalière de son histoire en pourcentage, bien pire qu'aucune séance de 1929. La chute est mondiale et quasi instantanée.",
    unfolding:
      "Contrairement à 1929, la Réserve fédérale, sous Alan Greenspan, injecte immédiatement des liquidités et rassure le système. Les marchés se stabilisent et l'économie réelle est peu touchée.",
    aftermath:
      "L'épisode a donné naissance aux « coupe-circuits » (circuit breakers) qui suspendent automatiquement les cotations en cas de chute brutale, pour casser les boucles de ventes automatiques. Une leçon sur les risques de l'automatisation.",
    lesson:
      "Des systèmes automatiques conçus pour protéger chaque acteur peuvent, additionnés, déstabiliser le marché entier. La réaction rapide d'une banque centrale peut éviter qu'un krach boursier ne contamine l'économie réelle.",
    keyFigures: [
      { label: "Chute du Dow (1 jour)", value: "−22,6 %" },
      { label: "Date", value: "19 oct. 1987" },
      { label: "Conséquence", value: "Coupe-circuits" },
    ],
  },
  {
    slug: "crise-asiatique-1997",
    name: "La Crise Asiatique",
    english: "Asian Financial Crisis",
    era: "xxe",
    year: "1997-1998",
    region: "Asie du Sud-Est",
    illu: "exchange-rate",
    drawdownLabel: "Devises en chute libre",
    severity: "Majeure",
    summary: "L'effondrement des devises asiatiques par effet de contagion, parti de la Thaïlande.",
    context:
      "Plusieurs économies asiatiques (« Tigres ») connaissent une croissance rapide financée par des capitaux étrangers et une dette en dollars, tout en maintenant un taux de change fixe face au dollar — un équilibre fragile.",
    trigger:
      "En juillet 1997, la Thaïlande, à court de réserves, doit abandonner l'ancrage du baht au dollar. La devise s'effondre, révélant l'ampleur des dettes en dollars devenues impayables.",
    magnitude:
      "La contagion gagne l'Indonésie, la Corée du Sud, la Malaisie : les devises perdent jusqu'à 80 % de leur valeur, les Bourses s'effondrent et plusieurs pays doivent faire appel au FMI.",
    unfolding:
      "Faillites en chaîne, fuite des capitaux et récessions sévères s'enchaînent. Le FMI impose des plans d'aide assortis de conditions d'austérité très débattues. La crise se propage jusqu'à la Russie en 1998.",
    aftermath:
      "Les pays touchés ont depuis accumulé d'énormes réserves de change pour ne plus jamais dépendre du FMI. La crise a illustré les dangers d'une dette en devise étrangère couplée à un change fixe.",
    lesson:
      "S'endetter dans une devise qu'on ne contrôle pas est un piège : si le change se retourne, la dette explose en monnaie locale. Les capitaux étrangers qui entrent vite peuvent ressortir encore plus vite.",
    keyFigures: [
      { label: "Déclencheur", value: "Baht thaïlandais" },
      { label: "Chute des devises", value: "jusqu'à −80 %" },
      { label: "Recours", value: "FMI" },
    ],
  },
  {
    slug: "ltcm-1998",
    name: "La Chute de LTCM",
    english: "Long-Term Capital Management",
    era: "xxe",
    year: "1998",
    region: "États-Unis (mondial)",
    illu: "margin-call",
    drawdownLabel: "−4,6 Md$ en pertes",
    severity: "Majeure",
    summary: "Un fonds dirigé par des prix Nobel, terrassé par un levier démesuré et le défaut russe.",
    context:
      "Long-Term Capital Management, fondé en 1994, réunit des traders d'élite et deux futurs prix Nobel d'économie. Ses stratégies d'arbitrage, jugées quasi sans risque, sont démultipliées par un levier dépassant 25 fois ses fonds propres.",
    trigger:
      "En août 1998, la Russie fait défaut sur sa dette. Les marchés paniquent et les corrélations que LTCM croyait stables se brisent toutes en même temps : ses positions perdent simultanément.",
    magnitude:
      "Le fonds perd environ 4,6 milliards de dollars en quelques mois. Vu son levier et ses innombrables contreparties, sa faillite menace de déstabiliser tout le système financier mondial.",
    unfolding:
      "La Réserve fédérale de New York organise, en septembre 1998, un sauvetage privé d'environ 3,6 milliards de dollars réunissant quatorze grandes banques, pour liquider les positions de façon ordonnée.",
    aftermath:
      "LTCM est devenu le cas d'école du risque systémique et des dangers de l'excès de confiance dans les modèles. Il préfigure, dix ans avant, les mécanismes de la crise de 2008.",
    lesson:
      "Un modèle brillant ne vaut que tant que ses hypothèses tiennent : en crise, les corrélations convergent vers 1 et la diversification s'évapore. Le levier transforme une erreur d'hypothèse en faillite.",
    keyFigures: [
      { label: "Levier", value: "> 25×" },
      { label: "Pertes", value: "≈ 4,6 Md$" },
      { label: "Sauvetage", value: "≈ 3,6 Md$" },
    ],
  },
  {
    slug: "bulle-internet-2000",
    name: "La Bulle Internet",
    english: "Dot-com Bubble",
    era: "xxie",
    year: "2000-2002",
    region: "Mondial",
    illu: "bubble",
    drawdownLabel: "−78 % (Nasdaq)",
    severity: "Sévère",
    summary: "L'euphorie des « point-com » : des valorisations folles pour des sociétés sans bénéfices.",
    context:
      "À la fin des années 1990, l'essor d'Internet déclenche une ruée vers les actions technologiques. Des sociétés sans chiffre d'affaires significatif s'introduisent en Bourse et voient leur cours s'envoler sur la seule promesse du « nouveau paradigme ».",
    trigger:
      "Le Nasdaq culmine à plus de 5 048 points le 10 mars 2000. La hausse des taux et la prise de conscience que beaucoup de ces sociétés ne seront jamais rentables retournent le marché.",
    magnitude:
      "De mars 2000 à octobre 2002, le Nasdaq perd environ 78 % de sa valeur. Des centaines de « point-com » disparaissent ; même des survivants comme Cisco ou Amazon chutent de plus de 80 %.",
    unfolding:
      "L'éclatement détruit des milliers de milliards de dollars de capitalisation et de nombreuses fortunes papier. Les rescapés (Amazon, eBay…) deviendront des géants, mais après des années de traversée du désert.",
    aftermath:
      "Le Nasdaq ne retrouvera son sommet de 2000 qu'en 2015, quinze ans plus tard. La bulle a rappelé qu'une technologie peut être révolutionnaire et les actions associées néanmoins largement surévaluées.",
    lesson:
      "Avoir raison sur la tendance (Internet a tout changé) ne suffit pas si le prix payé est déraisonnable. Une grande histoire ne justifie jamais n'importe quelle valorisation.",
    keyFigures: [
      { label: "Sommet du Nasdaq", value: "5 048 (mars 2000)" },
      { label: "Chute", value: "−78 %" },
      { label: "Retour au sommet", value: "2015" },
    ],
  },
  {
    slug: "crise-2008",
    name: "La Crise des Subprimes",
    english: "Global Financial Crisis",
    era: "xxie",
    year: "2007-2009",
    region: "Mondial",
    illu: "credit-spread",
    drawdownLabel: "−57 % (S&P 500)",
    severity: "Sévère",
    summary: "La crise des crédits immobiliers américains qui a failli emporter le système financier mondial.",
    context:
      "Dans les années 2000, les banques américaines accordent massivement des crédits immobiliers à risque (subprimes), puis les transforment en produits complexes notés AAA et revendus dans le monde entier. Le levier du système bancaire atteint des sommets.",
    trigger:
      "La hausse des défauts sur les subprimes, à partir de 2007, fait s'effondrer la valeur de ces produits. Le 15 septembre 2008, la faillite de la banque Lehman Brothers — 600 milliards de dollars d'actifs — gèle le système.",
    magnitude:
      "Du sommet d'octobre 2007 au creux de mars 2009, le S&P 500 perd environ 57 %. La défiance entre banques paralyse le crédit ; plusieurs institutions majeures font faillite ou sont sauvées en urgence.",
    unfolding:
      "Les États et banques centrales déploient des plans de sauvetage massifs et inventent le « quantitative easing ». La récession mondiale qui suit est la plus grave depuis 1929 ; le chômage bondit.",
    aftermath:
      "La crise a engendré une refonte réglementaire profonde (Bâle III, exigences de fonds propres renforcées, stress tests). Elle a aussi installé durablement les taux bas et les bilans gonflés des banques centrales.",
    lesson:
      "Un risque dispersé dans tout le système n'est pas un risque éliminé : la titrisation a propagé les subprimes au monde entier. Le risque de contrepartie et l'opacité transforment un problème sectoriel en crise systémique.",
    keyFigures: [
      { label: "Chute du S&P 500", value: "−57 %" },
      { label: "Faillite déclencheuse", value: "Lehman (sept. 2008)" },
      { label: "Réponse", value: "QE + plans de sauvetage" },
    ],
  },
  {
    slug: "flash-crash-2010",
    name: "Le Flash Crash",
    english: "2010 Flash Crash",
    era: "xxie",
    year: "2010",
    region: "États-Unis",
    illu: "latency",
    drawdownLabel: "≈ −9 % en minutes",
    severity: "Modérée",
    summary: "Une chute de près de 1 000 points du Dow en quelques minutes, puis un rebond presque total.",
    context:
      "Les marchés américains sont désormais dominés par le trading haute fréquence (HFT) : des algorithmes échangent en millionièmes de seconde, assurant l'essentiel de la liquidité affichée.",
    trigger:
      "Le 6 mai 2010, dans un marché déjà nerveux, un gros ordre de vente automatisé déclenche un retrait massif et soudain de la liquidité des algorithmes, qui cessent presque tous de coter en même temps.",
    magnitude:
      "En quelques minutes, le Dow Jones plonge d'environ 1 000 points (près de 9 %), certaines actions s'échangeant à des prix absurdes (quelques centimes), avant de récupérer l'essentiel de la perte dans la demi-heure.",
    unfolding:
      "L'épisode révèle la fragilité d'une liquidité fournie par des machines qui peuvent toutes disparaître au même instant. Une longue enquête pointe la combinaison d'un gros ordre et de comportements algorithmiques.",
    aftermath:
      "Les régulateurs ont renforcé les coupe-circuits au niveau de chaque action et encadré davantage le HFT. Le flash crash reste le symbole des risques de la microstructure moderne.",
    lesson:
      "La liquidité affichée par les machines est réelle… jusqu'à ce qu'elle ne le soit plus. Une profondeur de marché abondante peut s'évaporer en un instant quand les algorithmes se retirent tous ensemble.",
    keyFigures: [
      { label: "Chute intraday", value: "≈ −9 %" },
      { label: "Durée", value: "Quelques minutes" },
      { label: "Date", value: "6 mai 2010" },
    ],
  },
  {
    slug: "crise-dette-euro-2011",
    name: "La Crise de la Dette en Zone Euro",
    english: "European Debt Crisis",
    era: "xxie",
    year: "2010-2012",
    region: "Zone euro",
    illu: "credit-spread",
    drawdownLabel: "Spreads explosifs",
    severity: "Majeure",
    summary: "La crainte d'un éclatement de l'euro, des taux grecs hors de contrôle au « whatever it takes ».",
    context:
      "Après 2008, plusieurs États de la zone euro (Grèce, Irlande, Portugal, Espagne, Italie) voient leurs finances publiques se dégrader. Les marchés s'inquiètent de leur capacité à rembourser, dans une union monétaire sans budget commun.",
    trigger:
      "Fin 2009, la révélation de l'ampleur réelle du déficit grec déclenche une défiance qui se propage. Les taux d'emprunt des pays fragiles s'envolent, alimentant un cercle vicieux entre dette et défiance.",
    magnitude:
      "Les taux grecs à 10 ans dépassent 30 %, l'écart (spread) avec l'Allemagne explose, et la survie même de la monnaie unique est mise en doute. La Grèce subit une restructuration de sa dette en 2012.",
    unfolding:
      "Plans de sauvetage, austérité et tensions politiques s'enchaînent. Le tournant survient en juillet 2012 quand Mario Draghi, président de la BCE, déclare qu'elle fera « tout ce qu'il faut » (whatever it takes) pour préserver l'euro.",
    aftermath:
      "Cette phrase, suivie de la création de dispositifs de soutien, calme durablement les marchés. La crise a conduit à un renforcement de la gouvernance budgétaire européenne et à l'union bancaire.",
    lesson:
      "Dans une union monétaire, la crédibilité de la banque centrale peut compter autant que les chiffres : trois mots de Draghi ont fait ce que des mois de plans n'avaient pas réussi. La confiance se décrète parfois.",
    keyFigures: [
      { label: "Taux grec 10 ans (pic)", value: "> 30 %" },
      { label: "Tournant", value: "« Whatever it takes » (2012)" },
      { label: "Conséquence", value: "Union bancaire" },
    ],
  },
  {
    slug: "krach-petrolier-2014",
    name: "Le Krach Pétrolier",
    english: "2014-2016 Oil Crash",
    era: "xxie",
    year: "2014-2016",
    region: "Mondial",
    illu: "commodity",
    drawdownLabel: "−75 % (Brent)",
    severity: "Majeure",
    summary: "L'effondrement du prix du pétrole, de plus de 110 $ à moins de 30 $ le baril.",
    context:
      "L'essor du pétrole de schiste américain fait bondir l'offre mondiale, tandis que la demande ralentit, notamment en Chine. Le marché passe progressivement d'une situation tendue à une surabondance.",
    trigger:
      "Fin 2014, l'OPEP, menée par l'Arabie saoudite, choisit de ne pas réduire sa production pour préserver ses parts de marché, accélérant la chute des prix déjà entamée.",
    magnitude:
      "Le baril de Brent passe d'environ 115 dollars (juin 2014) à moins de 30 dollars (janvier 2016), soit une chute d'environ 75 %. Les pays et entreprises dépendants du pétrole sont durement frappés.",
    unfolding:
      "Vagues de faillites dans le schiste américain, récessions chez les pays exportateurs, tensions sur les devises émergentes. Le marché finit par se rééquilibrer avec des accords de réduction de production.",
    aftermath:
      "L'épisode a montré le pouvoir de l'offre américaine de schiste, devenue un acteur d'ajustement majeur, et la difficulté de l'OPEP à contrôler seule les prix dans ce nouveau paysage.",
    lesson:
      "Le prix d'une matière première peut s'effondrer non par baisse de la demande, mais par excès d'offre : une rupture technologique (le schiste) peut redéfinir tout un marché. Les certitudes sur les matières premières sont fragiles.",
    keyFigures: [
      { label: "Brent (juin 2014)", value: "≈ 115 $" },
      { label: "Brent (janv. 2016)", value: "< 30 $" },
      { label: "Chute", value: "≈ −75 %" },
    ],
  },
  {
    slug: "krach-covid-2020",
    name: "Le Krach du Covid",
    english: "COVID-19 Crash",
    era: "xxie",
    year: "2020",
    region: "Mondial",
    illu: "drawdown",
    drawdownLabel: "−34 % en 33 jours",
    severity: "Sévère",
    summary: "Le marché baissier le plus rapide de l'histoire, suivi d'un rebond tout aussi spectaculaire.",
    context:
      "Début 2020, les marchés sont au plus haut quand l'épidémie de Covid-19 se transforme en pandémie mondiale. La perspective de confinements généralisés fait craindre un arrêt brutal de l'économie.",
    trigger:
      "À partir du 20 février 2020, la propagation du virus et les annonces de confinement déclenchent une vente panique mondiale. Le 9 mars, puis les jours suivants, plusieurs coupe-circuits sont déclenchés à Wall Street.",
    magnitude:
      "Le S&P 500 chute d'environ 34 % en seulement 33 jours — le passage en marché baissier le plus rapide de l'histoire. L'indice de volatilité VIX culmine à 82,69 le 16 mars 2020, près de son record.",
    unfolding:
      "Les banques centrales et les États réagissent avec une vitesse et une ampleur inédites : baisses de taux, achats d'actifs massifs, plans de soutien budgétaire colossaux. Le rebond s'amorce dès le creux du 23 mars.",
    aftermath:
      "Porté par les liquidités et la reprise, le marché efface ses pertes en quelques mois et atteint de nouveaux sommets dès la fin 2020. Le krach Covid restera l'exemple du retournement en « V » le plus brutal.",
    lesson:
      "Un choc exogène peut provoquer une chute verticale… et une réponse monétaire massive un rebond tout aussi violent. Vendre dans la panique du 23 mars aurait fait manquer l'un des plus forts rebonds de l'histoire.",
    keyFigures: [
      { label: "Chute du S&P 500", value: "−34 % (33 jours)" },
      { label: "Pic du VIX", value: "82,69 (16 mars)" },
      { label: "Creux", value: "23 mars 2020" },
    ],
  },
  {
    slug: "petrole-negatif-2020",
    name: "Le Pétrole en Territoire Négatif",
    english: "Negative Oil Prices",
    era: "xxie",
    year: "2020",
    region: "États-Unis",
    illu: "commodity",
    drawdownLabel: "−37 $ le baril",
    severity: "Modérée",
    summary: "Pour la première fois, un contrat pétrolier s'échange à prix négatif : on paie pour livrer.",
    context:
      "Au printemps 2020, les confinements effondrent la demande de pétrole tandis que la production continue. Les capacités de stockage, notamment à Cushing (Oklahoma), se remplissent jusqu'à saturation.",
    trigger:
      "Le 20 avril 2020, à la veille de l'échéance du contrat à terme WTI de mai, les détenteurs n'ont nulle part où stocker le pétrole physique qu'ils devraient recevoir. Ils sont prêts à payer pour s'en débarrasser.",
    magnitude:
      "Le contrat WTI de mai clôture à environ −37 dollars le baril : un prix négatif inédit dans l'histoire. Détenir le contrat à l'échéance signifiait devoir payer pour faire enlever le pétrole.",
    unfolding:
      "Le phénomène, limité à un contrat à terme spécifique au moment de son expiration, se normalise rapidement. Mais il piège des investisseurs ayant parié sur un rebond via des produits indexés sur ce contrat.",
    aftermath:
      "L'épisode a rappelé la mécanique très concrète des contrats à terme : à l'échéance, il y a une livraison physique réelle, avec ses contraintes de stockage. Plusieurs produits financiers ont dû revoir leur fonctionnement.",
    lesson:
      "Un contrat à terme n'est pas un pari abstrait sur un prix : à l'échéance, il implique une livraison bien réelle. Acheter « le pétrole » via un contrat de court terme expose à des mécaniques de stockage souvent ignorées.",
    keyFigures: [
      { label: "Cours WTI (20 avr. 2020)", value: "≈ −37 $" },
      { label: "Cause", value: "Stockage saturé" },
      { label: "Statut", value: "1ʳᵉ fois en territoire négatif" },
    ],
  },
  {
    slug: "marche-baissier-2022",
    name: "Le Marché Baissier de 2022",
    english: "2022 Bear Market",
    era: "xxie",
    year: "2022",
    region: "Mondial",
    illu: "inflation",
    drawdownLabel: "−25 % (S&P 500)",
    severity: "Majeure",
    summary: "Le retour brutal de l'inflation et la hausse des taux ont fait chuter actions et obligations ensemble.",
    context:
      "Après une décennie de taux bas et les plans de relance post-Covid, l'inflation ressurgit en 2021-2022, amplifiée par les ruptures d'approvisionnement et la flambée de l'énergie liée à la guerre en Ukraine.",
    trigger:
      "Pour juguler une inflation dépassant 9 % aux États-Unis, la Réserve fédérale relève ses taux au rythme le plus rapide depuis des décennies. La fin de l'argent bon marché dégonfle les actifs valorisés sur des taux nuls.",
    magnitude:
      "En 2022, le S&P 500 recule d'environ 25 % et le Nasdaq d'environ 33 %. Fait rare, les obligations baissent en même temps que les actions, mettant en difficulté le portefeuille classique 60/40.",
    unfolding:
      "Les valeurs technologiques et spéculatives, les plus sensibles aux taux, sont les plus durement touchées. Les actifs sans revenu portés par l'euphorie de 2021 corrigent violemment.",
    aftermath:
      "L'année 2022 a rappelé que la diversification actions/obligations protège moins quand c'est la hausse des taux qui fait tout baisser. Elle a clos l'ère des taux nuls qui avait suivi 2008.",
    lesson:
      "Le taux d'intérêt est la gravité des marchés : quand il monte, presque tous les actifs pèsent plus lourd. Une diversification fondée sur des corrélations passées peut échouer quand le régime monétaire change.",
    keyFigures: [
      { label: "Inflation US (pic)", value: "≈ 9 %" },
      { label: "Chute du S&P 500", value: "≈ −25 %" },
      { label: "Particularité", value: "Actions ET obligations en baisse" },
    ],
  },
  {
    slug: "crises-bancaires-2023",
    name: "Les Crises Bancaires de 2023",
    english: "2023 Banking Turmoil",
    era: "xxie",
    year: "2023",
    region: "États-Unis / Suisse",
    illu: "margin-call",
    drawdownLabel: "Faillites éclair",
    severity: "Majeure",
    summary: "La faillite express de la Silicon Valley Bank et la chute de Credit Suisse, à l'ère des réseaux sociaux.",
    context:
      "La remontée rapide des taux en 2022-2023 fait perdre de la valeur aux obligations détenues par les banques. Certaines, comme la Silicon Valley Bank (SVB), y sont très exposées avec une base de déposants peu diversifiée.",
    trigger:
      "En mars 2023, l'annonce de pertes par SVB déclenche, via les réseaux sociaux et les applications bancaires, une fuite des dépôts d'une rapidité inédite : des dizaines de milliards de dollars retirés en quelques heures.",
    magnitude:
      "SVB s'effondre le 10 mars 2023, devenant l'une des plus grandes faillites bancaires américaines. La défiance se propage ; en Europe, Credit Suisse, déjà fragilisé, doit être racheté en urgence par UBS.",
    unfolding:
      "Les autorités américaines garantissent les dépôts au-delà des plafonds habituels pour enrayer la panique. Les banques centrales ouvrent des lignes de liquidité d'urgence. La contagion généralisée est évitée.",
    aftermath:
      "L'épisode a montré qu'à l'ère numérique, une panique bancaire (« bank run ») peut se produire en heures, et non en jours. Il a relancé le débat sur la gestion du risque de taux et la garantie des dépôts.",
    lesson:
      "À l'ère des smartphones et des réseaux sociaux, la confiance peut s'évaporer en quelques heures : un bank run moderne est fulgurant. Même une banque solvable sur le papier peut tomber si tous les déposants partent en même temps.",
    keyFigures: [
      { label: "Faillite de SVB", value: "10 mars 2023" },
      { label: "Rachat de Credit Suisse", value: "par UBS" },
      { label: "Nouveauté", value: "Bank run en heures" },
    ],
  },
  {
    slug: "bulle-mississippi-1720",
    name: "La bulle du Mississippi",
    english: "Mississippi Bubble",
    era: "avant-1900",
    year: "1719-1720",
    region: "France",
    illu: "bubble",
    drawdownLabel: "Effondrement total",
    severity: "Sévère",
    summary: "L'expérience de John Law : papier-monnaie, monopole colonial et première grande bulle française.",
    context:
      "Après les guerres de Louis XIV, la France croule sous les dettes. L'Écossais John Law convainc le Régent de lui confier une banque émettant du papier-monnaie, puis la Compagnie du Mississippi, dotée du monopole du commerce avec la Louisiane.",
    trigger:
      "Law fusionne sa banque et sa compagnie, et imprime de la monnaie pour soutenir le cours de l'action. La spéculation s'emballe : le titre est multiplié par plus de vingt en quelques mois, créant les premiers « millionnaires » (le mot naît alors).",
    magnitude:
      "Quand des actionnaires veulent convertir leurs gains en or, la supercherie se révèle : il y a bien plus de papier que de métal. La confiance s'effondre en 1720, l'action s'écroule et le papier-monnaie devient sans valeur.",
    unfolding:
      "La banqueroute ruine d'innombrables épargnants et désorganise les finances du royaume. John Law, adulé hier, fuit la France. L'épisode se déroule presque en parallèle de la bulle des Mers du Sud en Angleterre.",
    aftermath:
      "La France gardera pendant plus d'un siècle une méfiance durable envers les banques et le papier-monnaie. L'épisode est l'un des cas d'école de la création monétaire incontrôlée au service de la spéculation.",
    lesson:
      "Imprimer de la monnaie pour soutenir le prix d'un actif ne crée pas de richesse réelle : cela gonfle une bulle que la première demande de conversion en valeur tangible suffit à crever.",
    keyFigures: [
      { label: "Promoteur", value: "John Law" },
      { label: "Hausse de l'action", value: "× 20+" },
      { label: "Néologisme", value: "« millionnaire »" },
    ],
  },
  {
    slug: "panique-1907",
    name: "La panique de 1907",
    english: "Panic of 1907",
    era: "xxe",
    year: "1907",
    region: "États-Unis",
    illu: "margin-call",
    drawdownLabel: "≈ −50 %",
    severity: "Sévère",
    summary: "La crise qui, faute de banque centrale, fut endiguée par un seul homme — et donna naissance à la Fed.",
    context:
      "Au début du XXᵉ siècle, les États-Unis n'ont pas de banque centrale. Le système financier repose sur des « trusts » peu régulés et une liquidité fragile, vulnérable aux ruées des déposants.",
    trigger:
      "En octobre 1907, une tentative ratée de manipuler le cours du cuivre (United Copper) ruine ses instigateurs et jette la suspicion sur les banques qui les avaient financés, notamment la Knickerbocker Trust, qui fait faillite.",
    magnitude:
      "La panique se propage : les déposants se ruent aux guichets, la Bourse de New York s'effondre (l'indice perd près de la moitié de sa valeur depuis son sommet de 1906) et le crédit se fige.",
    unfolding:
      "En l'absence de prêteur en dernier ressort, le financier J. P. Morgan réunit les grands banquiers et engage des capitaux pour sauver les institutions viables. Son action coordonnée enraye la panique.",
    aftermath:
      "Le choc de dépendre d'un seul homme pousse le pays à créer un véritable prêteur en dernier ressort : la Réserve fédérale (Federal Reserve) voit le jour en 1913.",
    lesson:
      "Sans prêteur en dernier ressort, une crise de confiance peut figer tout le système. La panique de 1907 montre pourquoi les banques centrales modernes existent — et le prix d'en être dépourvu.",
    keyFigures: [
      { label: "Sauveur improvisé", value: "J. P. Morgan" },
      { label: "Conséquence", value: "Création de la Fed (1913)" },
      { label: "Chute des actions", value: "≈ −50 %" },
    ],
  },
  {
    slug: "bear-market-1973-1974",
    name: "Le marché baissier de 1973-1974",
    english: "1973-1974 Bear Market",
    era: "xxe",
    year: "1973-1974",
    region: "États-Unis / Royaume-Uni",
    illu: "inflation",
    drawdownLabel: "≈ −48 %",
    severity: "Sévère",
    summary: "Choc pétrolier et stagflation : la rare combinaison d'une économie en panne et d'une inflation galopante.",
    context:
      "Au début des années 1970, la fin du système de Bretton Woods (1971) et des tensions inflationnistes fragilisent déjà les marchés, portés depuis des années par les valeurs vedettes du « Nifty Fifty ».",
    trigger:
      "En octobre 1973, l'embargo pétrolier décidé par les pays de l'OPEP fait quadrupler le prix du baril. Le coût de l'énergie explose, étranglant des économies occidentales dépendantes du pétrole bon marché.",
    magnitude:
      "Le S&P 500 perd environ 48 % entre janvier 1973 et octobre 1974. La Bourse de Londres souffre encore davantage. Le tout dans un contexte de stagflation : croissance en berne ET inflation élevée.",
    unfolding:
      "La stagflation déroute les responsables : relancer l'économie nourrit l'inflation, la combattre aggrave la récession. Les marchés mettront des années à retrouver durablement leurs niveaux d'avant-crise.",
    aftermath:
      "L'épisode a discrédité l'idée qu'inflation et chômage ne pouvaient coexister, et inauguré une décennie de lutte contre l'inflation qui culminera avec les taux très élevés du début des années 1980.",
    lesson:
      "Un choc venu de l'économie réelle (ici l'énergie) peut frapper les marchés plus durablement qu'un krach purement financier. La stagflation rappelle qu'inflation et récession peuvent, hélas, aller de pair.",
    keyFigures: [
      { label: "Chute S&P 500", value: "≈ −48 %" },
      { label: "Déclencheur", value: "Embargo OPEP 1973" },
      { label: "Phénomène", value: "Stagflation" },
    ],
  },
  {
    slug: "tequila-1994",
    name: "La crise « Tequila » mexicaine",
    english: "Mexican Peso Crisis",
    era: "xxe",
    year: "1994-1995",
    region: "Mexique",
    illu: "exchange-rate",
    drawdownLabel: "Peso ≈ −50 %",
    severity: "Majeure",
    summary: "Une dévaluation mal gérée provoque une fuite des capitaux et la première crise des marchés émergents médiatisée.",
    context:
      "Au début des années 1990, le Mexique attire des capitaux étrangers et maintient son peso dans une fourchette face au dollar. Mais le pays accumule des déficits et une dette de court terme indexée sur le dollar (les « tesobonos »).",
    trigger:
      "En décembre 1994, face à la pression, les autorités dévaluent brutalement le peso. La perte de confiance est immédiate : les capitaux fuient et la dévaluation devient incontrôlée.",
    magnitude:
      "Le peso perd environ la moitié de sa valeur en quelques semaines. Les taux d'intérêt s'envolent, l'économie mexicaine plonge en récession et le pays risque le défaut sur sa dette en dollars.",
    unfolding:
      "Les États-Unis et le FMI montent un plan de soutien d'environ 50 milliards de dollars pour éviter le défaut. L'onde de choc se propage à d'autres marchés émergents — l'« effet tequila ».",
    aftermath:
      "La crise a illustré la vulnérabilité des pays qui financent des déficits avec de la dette de court terme en devise étrangère, un schéma que l'on retrouvera en Asie en 1997.",
    lesson:
      "S'endetter à court terme dans une monnaie qu'on ne contrôle pas est un piège : à la moindre perte de confiance, la dévaluation et la fuite des capitaux se renforcent mutuellement.",
    keyFigures: [
      { label: "Chute du peso", value: "≈ −50 %" },
      { label: "Plan de soutien", value: "≈ 50 Mds $" },
      { label: "Surnom", value: "Effet tequila" },
    ],
  },
  {
    slug: "defaut-russe-1998",
    name: "Le défaut russe de 1998",
    english: "1998 Russian Financial Crisis",
    era: "xxe",
    year: "1998",
    region: "Russie",
    illu: "margin-call",
    drawdownLabel: "Rouble ≈ −70 %",
    severity: "Majeure",
    summary: "Quand un État fait défaut sur sa propre dette et dévalue, ébranlant la finance mondiale.",
    context:
      "Dans la Russie post-soviétique des années 1990, l'État finance ses déficits par des obligations de court terme à très hauts rendements (les « GKO »). La chute des prix des matières premières et la contagion de la crise asiatique fragilisent ses finances.",
    trigger:
      "Le 17 août 1998, le gouvernement russe annonce un défaut sur sa dette intérieure et laisse le rouble se dévaluer, prenant les marchés de court.",
    magnitude:
      "Le rouble perd environ 70 % de sa valeur, l'inflation s'envole et le système bancaire russe est dévasté. Les investisseurs étrangers subissent de lourdes pertes.",
    unfolding:
      "La fuite vers la sécurité provoque des secousses mondiales et précipite la chute du fonds spéculatif LTCM, dont les paris s'effondrent — au point de nécessiter un sauvetage coordonné par la Fed.",
    aftermath:
      "L'épisode a rappelé que la dette « souveraine » n'est jamais totalement sans risque, et que des marchés lointains peuvent transmettre un choc au cœur du système financier mondial.",
    lesson:
      "Un défaut souverain reste possible, même sur la dette en monnaie nationale. Et dans un monde interconnecté, une crise régionale peut, par effet de levier et de contagion, menacer la stabilité globale.",
    keyFigures: [
      { label: "Date du défaut", value: "17 août 1998" },
      { label: "Chute du rouble", value: "≈ −70 %" },
      { label: "Onde de choc", value: "Chute de LTCM" },
    ],
  },
  {
    slug: "bulle-japonaise-1989",
    name: "La bulle japonaise",
    english: "Japanese Asset Price Bubble",
    era: "xxe",
    year: "1989-1990",
    region: "Japon",
    illu: "bubble",
    drawdownLabel: "≈ −80 %",
    severity: "Sévère",
    summary: "L'éclatement d'une bulle immobilière et boursière géante qui ouvrit des « décennies perdues ».",
    context:
      "Dans les années 1980, le Japon connaît une croissance fulgurante. L'argent facile et l'euphorie gonflent une double bulle, boursière et immobilière, d'une ampleur inédite — on disait que le terrain du Palais impérial valait plus que toute la Californie.",
    trigger:
      "Fin 1989, l'indice Nikkei culmine à près de 38 957 points. Pour calmer la surchauffe, la Banque du Japon relève ses taux : la bulle commence à se dégonfler dès le début de 1990.",
    magnitude:
      "Le Nikkei perd environ la moitié de sa valeur en un an, puis s'enfonce sur la durée — jusqu'à environ −80 % du sommet. Les prix de l'immobilier s'effondrent eux aussi pendant des années.",
    unfolding:
      "Les banques, plombées par des créances douteuses, réduisent le crédit. L'économie s'enlise dans la déflation et la stagnation, malgré des taux très bas et des plans de relance répétés.",
    aftermath:
      "On parle de « décennie perdue », puis de décennies perdues : le Nikkei ne retrouvera son sommet de 1989 que plus de trente ans plus tard. Le Japon est devenu le cas d'école de la déflation durable.",
    lesson:
      "Quand une bulle alimentée par le crédit éclate, les dégâts peuvent durer des décennies, pas des mois. Des taux bas ne suffisent pas toujours à relancer une économie prise dans la déflation.",
    keyFigures: [
      { label: "Sommet du Nikkei", value: "≈ 38 957 (1989)" },
      { label: "Baisse totale", value: "≈ −80 %" },
      { label: "Conséquence", value: "Décennies perdues" },
    ],
  },
  {
    slug: "krach-crypto-2022",
    name: "Le krach crypto de 2022",
    english: "2022 Crypto Crash",
    era: "xxie",
    year: "2022",
    region: "Mondial",
    illu: "blockchain",
    drawdownLabel: "Bitcoin ≈ −77 %",
    severity: "Sévère",
    summary: "L'effondrement de Terra/Luna puis la faillite de FTX font fondre des centaines de milliards.",
    context:
      "Après l'envolée de 2020-2021, l'écosystème crypto est gonflé par l'effet de levier, des rendements promis insoutenables et des acteurs centralisés peu régulés. La remontée des taux met fin à l'argent facile.",
    trigger:
      "En mai 2022, le « stablecoin » algorithmique TerraUSD perd son ancrage au dollar et s'effondre, entraînant son jeton Luna : environ 40 milliards de dollars partent en fumée en quelques jours.",
    magnitude:
      "La contagion frappe prêteurs et fonds surexposés (Celsius, Three Arrows Capital). En novembre, la plateforme FTX, longtemps présentée comme solide, fait faillite dans un scandale de fonds clients détournés. Le bitcoin chute d'environ 77 % par rapport à son sommet de 2021.",
    unfolding:
      "Une cascade de faillites en chaîne révèle l'opacité et les conflits d'intérêts du secteur. La confiance s'effondre, les retraits se multiplient, et de nombreux particuliers perdent leurs avoirs.",
    aftermath:
      "L'épisode a accéléré les appels à la régulation des crypto-actifs et rappelé la différence entre une technologie (la blockchain) et les acteurs spéculatifs qui s'y greffent.",
    lesson:
      "Un rendement « garanti » anormalement élevé et un acteur opaque sont des signaux d'alerte classiques. La promesse de décentralisation ne protège pas des intermédiaires centralisés mal gérés.",
    keyFigures: [
      { label: "Terra/Luna", value: "≈ 40 Mds $ effacés" },
      { label: "Faillite", value: "FTX (nov. 2022)" },
      { label: "Chute du bitcoin", value: "≈ −77 %" },
    ],
  },
  {
    slug: "gamestop-2021",
    name: "La frénésie GameStop",
    english: "GameStop Short Squeeze",
    era: "xxie",
    year: "2021",
    region: "États-Unis",
    illu: "short-squeeze",
    drawdownLabel: "GME × 20+",
    severity: "Modérée",
    summary: "Des particuliers coordonnés sur les réseaux infligent des pertes massives à des fonds vendeurs à découvert.",
    context:
      "Début 2021, l'action du distributeur de jeux vidéo GameStop est massivement vendue à découvert par des hedge funds qui parient sur sa chute. Sur le forum Reddit « WallStreetBets », des particuliers repèrent cette fragilité.",
    trigger:
      "Une vague d'achats coordonnés de petits porteurs fait grimper le titre. Les vendeurs à découvert, forcés de racheter pour limiter leurs pertes, alimentent eux-mêmes la flambée : c'est un « short squeeze ».",
    magnitude:
      "L'action passe d'une vingtaine de dollars à près de 483 $ en séance fin janvier 2021. Des fonds comme Melvin Capital subissent des pertes colossales. D'autres titres très vendus à découvert flambent à leur tour.",
    unfolding:
      "Au plus fort de l'épisode, des courtiers comme Robinhood restreignent l'achat de ces titres, provoquant une vive polémique sur l'équité des marchés. La volatilité devient extrême.",
    aftermath:
      "La saga a illustré le pouvoir nouveau des particuliers coordonnés via les réseaux sociaux, et déclenché des auditions au Congrès américain sur le fonctionnement des marchés et des courtiers.",
    lesson:
      "Une position vendeuse à découvert a un risque de perte théoriquement illimité. Un positionnement trop visible et trop massif peut se retourner violemment quand la foule décide de l'attaquer.",
    keyFigures: [
      { label: "Sommet de GME", value: "≈ 483 $ (intraday)" },
      { label: "Catalyseur", value: "Reddit WallStreetBets" },
      { label: "Mécanisme", value: "Short squeeze" },
    ],
  },
  {
    slug: "railway-mania-1840s",
    name: "La folie des chemins de fer",
    english: "Railway Mania",
    era: "avant-1900",
    year: "1845-1847",
    region: "Royaume-Uni",
    illu: "bubble",
    drawdownLabel: "≈ −85 %",
    severity: "Sévère",
    summary: "La première grande bulle industrielle : l'Angleterre victorienne se rue sur les actions ferroviaires.",
    context:
      "Au milieu des années 1840, le chemin de fer incarne le progrès. Le Parlement britannique autorise des centaines de nouvelles lignes ; la presse vante des rendements mirobolants et des milliers d'épargnants ordinaires investissent leurs économies dans les compagnies ferroviaires.",
    trigger:
      "Beaucoup d'actions s'achètent en ne versant qu'un acompte, le solde étant appelé plus tard. Quand les compagnies réclament le reste des fonds et que la Banque d'Angleterre relève ses taux en 1845-1846, les investisseurs ne peuvent plus suivre.",
    magnitude:
      "Les cours ferroviaires s'effondrent de plus de 80 % par rapport à leur sommet. Une grande partie des lignes promises ne sera jamais construite ; d'innombrables familles de la classe moyenne sont ruinées.",
    unfolding:
      "Les appels de fonds non honorés provoquent faillites et fusions. Paradoxalement, le réseau réellement bâti durant la bulle deviendra l'épine dorsale du rail britannique — la richesse détruite côté actionnaires a laissé une infrastructure durable.",
    aftermath:
      "La Railway Mania est citée comme l'archétype de la bulle technologique : une innovation réelle, des attentes démesurées, du levier, puis l'effondrement. Le schéma se répétera avec l'électricité, l'automobile, puis Internet.",
    lesson:
      "Une technologie peut être révolutionnaire ET ruiner ses premiers investisseurs : la valeur d'usage à long terme ne garantit pas le prix payé à court terme. Le levier (acheter à crédit) transforme l'enthousiasme en catastrophe.",
    keyFigures: [
      { label: "Apogée", value: "1845-1846" },
      { label: "Chute des actions", value: "≈ −85 %" },
      { label: "Héritage", value: "Le réseau ferré britannique" },
    ],
  },
  {
    slug: "panique-1873",
    name: "La panique de 1873",
    english: "Panic of 1873",
    era: "avant-1900",
    year: "1873",
    region: "États-Unis / Europe",
    illu: "credit-spread",
    drawdownLabel: "Dépression longue",
    severity: "Sévère",
    summary: "Une crise bancaire transatlantique qui ouvre la « Longue Dépression » de plus de vingt ans.",
    context:
      "Après la guerre de Sécession, les États-Unis et l'Europe connaissent un boom du chemin de fer financé à crédit. Les banques d'affaires prêtent massivement à des compagnies dont beaucoup ne seront jamais rentables.",
    trigger:
      "En septembre 1873, la prestigieuse banque américaine Jay Cooke & Company, surexposée au financement ferroviaire, fait faillite. La nouvelle déclenche une panique : la Bourse de New York ferme dix jours, du jamais-vu.",
    magnitude:
      "Des dizaines de banques et des centaines d'entreprises s'effondrent. S'ensuit une période de croissance faible, de chômage et de déflation que l'on appellera longtemps la « Grande Dépression », jusqu'à ce que celle de 1929 lui ravisse le nom.",
    unfolding:
      "La crise se propage de part et d'autre de l'Atlantique. Le débat monétaire (or contre argent) s'enflamme aux États-Unis. La reprise est lente et heurtée, étalée sur le reste de la décennie et au-delà.",
    aftermath:
      "La « Longue Dépression » (souvent datée 1873-1896) a montré qu'une crise financière pouvait déboucher non sur un krach bref, mais sur des années de croissance molle et de déflation — un précédent étudié lors de chaque crise majeure ultérieure.",
    lesson:
      "Le surinvestissement à crédit dans une technologie en vogue (ici le rail) crée des capacités qui ne trouvent pas preneur. La purge qui suit peut durer des années, bien au-delà du krach initial.",
    keyFigures: [
      { label: "Déclencheur", value: "Faillite Jay Cooke" },
      { label: "Fait marquant", value: "NYSE fermée 10 jours" },
      { label: "Conséquence", value: "Longue Dépression" },
    ],
  },
  {
    slug: "recession-volcker-1980",
    name: "Le choc Volcker",
    english: "Volcker Shock & 1980-82 Recession",
    era: "xxe",
    year: "1980-1982",
    region: "États-Unis",
    illu: "inflation",
    drawdownLabel: "Taux jusqu'à ~20 %",
    severity: "Majeure",
    summary: "Pour tuer l'inflation, la Fed monte ses taux à près de 20 % — au prix d'une récession brutale.",
    context:
      "À la fin des années 1970, l'inflation américaine dépasse les 13 %, érodant l'épargne et déstabilisant l'économie. Le nouveau président de la Réserve fédérale, Paul Volcker, fait de sa défaite une priorité absolue.",
    trigger:
      "À partir de 1979-1980, Volcker relève les taux directeurs à des niveaux extrêmes — le taux des Fed Funds approche les 20 %. L'argent devient brutalement cher pour les entreprises comme pour les ménages.",
    magnitude:
      "L'économie plonge dans une double récession (1980, puis 1981-1982), le chômage dépasse 10 %, et les secteurs endettés (immobilier, agriculture, industrie) souffrent durement. Mais l'inflation, elle, est cassée : elle retombe sous 4 % en 1983.",
    unfolding:
      "La rigueur de Volcker est d'abord très impopulaire. Une fois l'inflation maîtrisée, la baisse des taux ouvre toutefois l'un des plus longs marchés haussiers de l'histoire des actions et des obligations.",
    aftermath:
      "Le « choc Volcker » est devenu la référence de la crédibilité d'une banque centrale : accepter une récession douloureuse pour ancrer durablement les anticipations d'inflation. Il a inspiré les banquiers centraux face à l'inflation de 2022.",
    lesson:
      "Combattre une inflation installée a un coût économique réel et immédiat. Mais la laisser filer coûte souvent plus cher encore : la crédibilité d'une banque centrale se paie d'avance, en récession assumée.",
    keyFigures: [
      { label: "Taux directeur", value: "≈ 20 %" },
      { label: "Inflation matée", value: "13 % → < 4 %" },
      { label: "Chômage", value: "> 10 %" },
    ],
  },
  {
    slug: "kennedy-slide-1962",
    name: "Le « Kennedy Slide » de 1962",
    english: "Kennedy Slide / Flash Crash of 1962",
    era: "xxe",
    year: "1962",
    region: "États-Unis",
    illu: "drawdown",
    drawdownLabel: "≈ −27 %",
    severity: "Modérée",
    summary: "Une chute rapide et mal expliquée du marché américain, en pleine prospérité d'après-guerre.",
    context:
      "Au début des années 1960, Wall Street sort d'une longue hausse portée par le boom d'après-guerre. Les valorisations sont tendues et l'optimisme généralisé, sans catalyseur de crise évident à l'horizon.",
    trigger:
      "Au printemps 1962, sans choc unique clairement identifié, le marché se met à chuter. Les tensions entre l'administration Kennedy et l'industrie sidérurgique (sur les prix de l'acier) sont souvent citées comme l'un des éléments de défiance.",
    magnitude:
      "Le S&P 500 perd environ 27 % entre la fin 1961 et juin 1962. La séance du 28 mai 1962 (« Blue Monday ») est l'une des plus violentes depuis 1929, avant un rebond marqué.",
    unfolding:
      "Le marché se redresse dès la seconde moitié de 1962 et retrouve ses niveaux l'année suivante. L'épisode, rapide et sans crise économique profonde, reste l'exemple d'une correction « de valorisation » plus que de fondamentaux.",
    aftermath:
      "Le Kennedy Slide a alimenté la réflexion sur la psychologie des marchés et a parfois été comparé, des décennies plus tard, au flash crash de 2010 : une chute brutale sans cause unique claire, suivie d'un rebond.",
    lesson:
      "Un marché peut chuter fortement sans récession ni catalyseur évident, simplement parce que les prix s'étaient trop éloignés de la réalité. Toutes les baisses ne « racontent » pas une crise économique.",
    keyFigures: [
      { label: "Chute du S&P 500", value: "≈ −27 %" },
      { label: "Séance noire", value: "28 mai 1962" },
      { label: "Récupération", value: "≈ 1 an" },
    ],
  },
  {
    slug: "mercredi-noir-1992",
    name: "Le Mercredi noir (livre sterling)",
    english: "Black Wednesday",
    era: "xxe",
    year: "1992",
    region: "Royaume-Uni",
    illu: "exchange-rate",
    drawdownLabel: "Sortie du SME",
    severity: "Majeure",
    summary: "La livre est éjectée du système monétaire européen — et un spéculateur entre dans la légende.",
    context:
      "Au début des années 1990, le Royaume-Uni participe au mécanisme de change européen (SME), qui oblige à maintenir la livre dans une fourchette face au mark allemand. Mais l'économie britannique est faible et les taux allemands élevés : la parité devient intenable.",
    trigger:
      "Des spéculateurs, dont le fonds de George Soros, parient massivement contre la livre, jugée surévaluée. Le 16 septembre 1992, la pression devient irrésistible.",
    magnitude:
      "Malgré des hausses de taux d'urgence (jusqu'à 15 % annoncés dans la journée) et des achats massifs de livres, le gouvernement britannique capitule et sort la livre du SME. La devise chute fortement face au mark et au dollar.",
    unfolding:
      "George Soros aurait gagné environ un milliard de dollars sur l'opération, devenant « l'homme qui a fait sauter la Banque d'Angleterre ». Paradoxalement, la sortie du SME, en redonnant de la souplesse monétaire, a favorisé la reprise britannique.",
    aftermath:
      "Le Mercredi noir a montré qu'aucun gouvernement ne peut indéfiniment défendre une parité de change que les fondamentaux ne justifient pas, face à des capitaux mondiaux mobiles et déterminés.",
    lesson:
      "Vouloir tenir un taux de change « par décret » contre la réalité économique est un combat perdu d'avance si les marchés s'y opposent : les réserves d'une banque centrale ne sont jamais infinies.",
    keyFigures: [
      { label: "Date", value: "16 septembre 1992" },
      { label: "Gain de Soros", value: "≈ 1 Md $" },
      { label: "Issue", value: "Livre hors du SME" },
    ],
  },
  {
    slug: "crise-argentine-2001",
    name: "La crise argentine de 2001",
    english: "Argentine Great Depression",
    era: "xxie",
    year: "2001-2002",
    region: "Argentine",
    illu: "margin-call",
    drawdownLabel: "Défaut record",
    severity: "Sévère",
    summary: "Défaut souverain géant, gel des comptes (« corralito ») et fin de la parité peso-dollar.",
    context:
      "Dans les années 1990, l'Argentine arrime sa monnaie au dollar (un peso = un dollar). Cette rigidité, conjuguée à une dette croissante et à une récession prolongée, devient insoutenable à la fin de la décennie.",
    trigger:
      "Fin 2001, face à la fuite des capitaux, le gouvernement gèle les retraits bancaires (le « corralito ») pour éviter l'effondrement des banques. La colère populaire explose en émeutes.",
    magnitude:
      "Le pays fait défaut sur environ 100 milliards de dollars de dette — l'un des plus gros défauts souverains de l'histoire. La parité peso-dollar est abandonnée ; le peso perd les trois quarts de sa valeur et la pauvreté explose.",
    unfolding:
      "L'Argentine traverse une crise politique majeure (plusieurs présidents en quelques jours). La restructuration de la dette s'étalera sur des années et donnera lieu à de longues batailles juridiques avec certains créanciers.",
    aftermath:
      "La crise argentine est devenue le cas d'école du défaut souverain moderne et des dangers d'un ancrage de change rigide combiné à une dette en devise étrangère.",
    lesson:
      "Geler l'épargne des citoyens pour sauver les banques détruit la confiance pour une génération. Un ancrage de change rigide sans discipline budgétaire finit par casser — brutalement.",
    keyFigures: [
      { label: "Dette en défaut", value: "≈ 100 Mds $" },
      { label: "Mesure choc", value: "« Corralito »" },
      { label: "Peso", value: "≈ −75 %" },
    ],
  },
  {
    slug: "krach-chinois-2015",
    name: "Le krach boursier chinois de 2015",
    english: "2015 Chinese Stock Market Crash",
    era: "xxie",
    year: "2015",
    region: "Chine",
    illu: "bubble",
    drawdownLabel: "≈ −43 %",
    severity: "Majeure",
    summary: "Une bulle gonflée par les petits porteurs et le crédit éclate sur les bourses de Shanghai et Shenzhen.",
    context:
      "En 2014-2015, les bourses chinoises s'envolent, portées par des millions de nouveaux investisseurs particuliers et un recours massif au crédit (« margin trading »). En un an, l'indice de Shanghai plus que double.",
    trigger:
      "À la mi-juin 2015, la dynamique se retourne. Les appels de marge contraignent les particuliers endettés à vendre, déclenchant une cascade de ventes forcées.",
    magnitude:
      "L'indice composite de Shanghai chute d'environ 43 % en quelques mois. Pour enrayer la panique, les autorités suspendent la cotation de centaines de sociétés et multiplient les mesures de soutien.",
    unfolding:
      "Le gouvernement intervient massivement (achats d'actions par des fonds d'État, restrictions sur les ventes), au prix de doutes sur la liberté du marché. Les secousses se propagent brièvement aux marchés mondiaux à l'été 2015.",
    aftermath:
      "Le krach a illustré les risques d'un marché dominé par des particuliers à fort levier, et le dilemme des autorités tiraillées entre laisser le marché s'ajuster et intervenir pour éviter la panique sociale.",
    lesson:
      "Quand une hausse est portée par l'endettement des particuliers, la baisse s'auto-alimente par les appels de marge. Et soutenir artificiellement un marché a un coût : celui de la confiance dans la formation libre des prix.",
    keyFigures: [
      { label: "Chute (Shanghai)", value: "≈ −43 %" },
      { label: "Moteur", value: "Margin trading" },
      { label: "Réaction", value: "Intervention de l'État" },
    ],
  },
  {
    slug: "crise-gilts-2022",
    name: "La crise des gilts de 2022",
    english: "2022 UK Gilt Crisis",
    era: "xxie",
    year: "2022",
    region: "Royaume-Uni",
    illu: "credit-spread",
    drawdownLabel: "Taux longs en flèche",
    severity: "Majeure",
    summary: "Un budget mal accueilli fait flamber les taux et menace les fonds de pension britanniques.",
    context:
      "À l'automne 2022, dans un contexte d'inflation et de hausse des taux, le nouveau gouvernement britannique annonce un « mini-budget » de baisses d'impôts massives non financées, sans évaluation indépendante.",
    trigger:
      "Les marchés sanctionnent immédiatement : la livre s'effondre et les taux des obligations d'État (gilts) bondissent à une vitesse inédite. Or de nombreux fonds de pension utilisaient des stratégies à effet de levier (LDI) adossées à ces taux.",
    magnitude:
      "La hausse brutale des taux déclenche des appels de marge en chaîne sur ces fonds, qui doivent vendre des gilts en urgence — ce qui fait encore monter les taux. Une spirale auto-entretenue menace la stabilité financière.",
    unfolding:
      "La Banque d'Angleterre intervient en urgence en rachetant des gilts pour casser la spirale. Le mini-budget est largement abandonné et la Première ministre démissionne après quelques semaines — l'un des mandats les plus courts de l'histoire britannique.",
    aftermath:
      "L'épisode a révélé un risque caché de levier au cœur des fonds de pension et rappelé qu'un gouvernement perd vite la main quand il heurte frontalement la crédibilité budgétaire.",
    lesson:
      "Les marchés obligataires peuvent discipliner un État en quelques jours. Et le levier dissimulé dans des acteurs réputés prudents (ici les fonds de pension) peut transformer une hausse de taux en risque systémique.",
    keyFigures: [
      { label: "Déclencheur", value: "« Mini-budget »" },
      { label: "Risque révélé", value: "Fonds de pension (LDI)" },
      { label: "Réponse", value: "Rachats d'urgence (BoE)" },
    ],
  },
  {
    slug: "panique-1819",
    name: "La panique de 1819",
    english: "Panic of 1819",
    era: "avant-1900",
    year: "1819",
    region: "États-Unis",
    illu: "margin-call",
    drawdownLabel: "1re crise US",
    severity: "Majeure",
    summary: "La première crise financière d'ampleur des États-Unis, après une bulle foncière d'après-guerre.",
    context:
      "Après la guerre de 1812, les États-Unis connaissent un boom : crédit facile, spéculation sur les terres de l'Ouest et flambée des prix du coton dopent l'économie. La jeune Second Bank of the United States alimente l'expansion du crédit.",
    trigger:
      "En 1818-1819, la banque centrale resserre brutalement le crédit pour défendre ses réserves d'or. La chute des prix du coton sur les marchés mondiaux fait le reste : la bulle foncière éclate.",
    magnitude:
      "Faillites bancaires en chaîne, effondrement des prix des terres, chômage de masse dans les villes et saisies agricoles. C'est le premier grand cycle d'expansion-récession de l'histoire américaine.",
    unfolding:
      "Sans filet social ni outils de politique économique, la détresse est profonde et durable. La crise nourrit une méfiance populaire tenace envers les banques et le papier-monnaie.",
    aftermath:
      "La panique de 1819 a façonné le débat politique américain sur le rôle des banques pendant des décennies, jusqu'à la disparition de la Second Bank sous Andrew Jackson.",
    lesson:
      "Un boom nourri par le crédit facile et la spéculation foncière se retourne dès que le crédit se resserre. Le schéma — euphorie, levier, resserrement, krach — est déjà là en 1819.",
    keyFigures: [
      { label: "Bulle", value: "Terres de l'Ouest" },
      { label: "Déclencheur", value: "Resserrement du crédit" },
      { label: "Première", value: "1re crise US majeure" },
    ],
  },
  {
    slug: "panique-1837",
    name: "La panique de 1837",
    english: "Panic of 1837",
    era: "avant-1900",
    year: "1837",
    region: "États-Unis",
    illu: "bubble",
    drawdownLabel: "Dépression ~6 ans",
    severity: "Sévère",
    summary: "L'éclatement d'une bulle spéculative sur les terres, suivi d'une longue dépression.",
    context:
      "Dans les années 1830, la spéculation foncière s'emballe aux États-Unis, financée par une multitude de banques émettant librement leur propre papier-monnaie. La fièvre de l'Ouest attire tous les capitaux.",
    trigger:
      "En 1836, le président Jackson impose le « Specie Circular » : les terres publiques ne peuvent plus être payées qu'en or ou argent. La demande de métal assèche les banques et fait s'effondrer la confiance dans le papier.",
    magnitude:
      "Des centaines de banques font faillite, le crédit disparaît et les prix s'effondrent. S'ensuit l'une des plus longues dépressions américaines du XIXᵉ siècle, qui dure jusqu'au début des années 1840.",
    unfolding:
      "Le chômage explose, des États font défaut sur leur dette, et la déflation s'installe durablement. L'absence de banque centrale prive le pays de tout amortisseur.",
    aftermath:
      "La crise a renforcé la défiance envers le papier-monnaie non adossé et alimenté de longs débats monétaires qui marqueront tout le siècle américain.",
    lesson:
      "Quand une bulle repose sur une monnaie créée librement et sans contrepartie solide, exiger soudain du concret (ici de l'or) suffit à tout faire s'écrouler.",
    keyFigures: [
      { label: "Bulle", value: "Spéculation foncière" },
      { label: "Déclencheur", value: "« Specie Circular »" },
      { label: "Conséquence", value: "Dépression prolongée" },
    ],
  },
  {
    slug: "recession-1937",
    name: "La rechute de 1937-1938",
    english: "Recession of 1937-38",
    era: "xxe",
    year: "1937-1938",
    region: "États-Unis",
    illu: "drawdown",
    drawdownLabel: "≈ −50 %",
    severity: "Majeure",
    summary: "En pleine reprise post-1929, un resserrement prématuré replonge l'économie dans la crise.",
    context:
      "Après les creux de la Grande Dépression, l'économie américaine se redresse nettement entre 1933 et 1937. Jugeant la reprise acquise, les autorités décident de réduire les soutiens budgétaires et monétaires.",
    trigger:
      "En 1936-1937, la Fed relève les réserves obligatoires des banques et l'État réduit ses dépenses, tandis que de nouvelles cotisations sociales pèsent sur les revenus. Le retrait des soutiens est trop brutal.",
    magnitude:
      "La production industrielle rechute fortement, le chômage repart à la hausse et la Bourse perd environ la moitié de sa valeur entre 1937 et 1938 — une rechute brutale au cœur de la reprise.",
    unfolding:
      "Le choc oblige à rétablir les soutiens. L'épisode reste l'exemple type du resserrement prématuré qui casse une reprise encore fragile.",
    aftermath:
      "La rechute de 1937 est devenue une référence pour les banquiers centraux : elle a inspiré la prudence après 2008 et lors de la sortie des soutiens post-Covid.",
    lesson:
      "Retirer les soutiens trop tôt, avant que la reprise ne soit solide, peut replonger l'économie dans la crise. Le calendrier de la « normalisation » est aussi important que la normalisation elle-même.",
    keyFigures: [
      { label: "Erreur", value: "Resserrement prématuré" },
      { label: "Chute des actions", value: "≈ −50 %" },
      { label: "Leçon", value: "Sortir des soutiens trop tôt" },
    ],
  },
  {
    slug: "savings-and-loan",
    name: "La crise des Savings & Loan",
    english: "Savings and Loan Crisis",
    era: "xxe",
    year: "1986-1995",
    region: "États-Unis",
    illu: "margin-call",
    drawdownLabel: "~1 000 faillites",
    severity: "Majeure",
    summary: "La faillite en série de caisses d'épargne américaines, à la suite de la déréglementation et de la hausse des taux.",
    context:
      "Les « Savings & Loan » (caisses d'épargne-logement) américaines empruntaient à court terme pour prêter à long terme à taux fixe. La flambée des taux du début des années 1980 a rendu ce modèle intenable.",
    trigger:
      "Une déréglementation mal encadrée autorise ces caisses à investir dans des actifs bien plus risqués (immobilier commercial, junk bonds) pour tenter de se refaire — souvent au pire moment.",
    magnitude:
      "Près d'un millier de caisses font faillite entre la fin des années 1980 et le début des années 1990. Le sauvetage coûte au contribuable américain plus de 100 milliards de dollars.",
    unfolding:
      "Une agence publique est créée pour liquider les actifs des caisses en faillite. De nombreux scandales de fraude éclatent, marquant durablement la réglementation bancaire.",
    aftermath:
      "La crise a illustré les dangers d'une déréglementation sans supervision renforcée et le risque pour le contribuable de garantir des acteurs incités à prendre trop de risques.",
    lesson:
      "Emprunter court pour prêter long à taux fixe est une bombe à retardement quand les taux montent. Déréglementer sans renforcer la surveillance revient à inviter l'aléa moral.",
    keyFigures: [
      { label: "Faillites", value: "≈ 1 000 caisses" },
      { label: "Coût public", value: "> 100 Mds $" },
      { label: "Cause", value: "Taux + déréglementation" },
    ],
  },
  {
    slug: "crise-nordique-1991",
    name: "La crise bancaire nordique",
    english: "Nordic Banking Crisis",
    era: "xxe",
    year: "1990-1993",
    region: "Suède / Finlande / Norvège",
    illu: "credit-spread",
    drawdownLabel: "Nationalisations",
    severity: "Majeure",
    summary: "Une bulle du crédit et de l'immobilier éclate en Scandinavie — et inspire un modèle de sauvetage bancaire.",
    context:
      "À la fin des années 1980, la dérégulation financière en Suède, Finlande et Norvège déclenche un boom du crédit et une flambée de l'immobilier. Les banques prêtent massivement, portées par l'euphorie.",
    trigger:
      "Au tournant des années 1990, la hausse des taux et le retournement de l'immobilier font exploser les créances douteuses. En Finlande, l'effondrement du commerce avec l'URSS aggrave le choc.",
    magnitude:
      "Plusieurs grandes banques deviennent insolvables. Les États interviennent massivement : la Suède nationalise temporairement des banques, isole les actifs toxiques dans des « bad banks » et recapitalise le système.",
    unfolding:
      "La gestion suédoise — transparence sur les pertes, prise de participation de l'État, mise à contribution des actionnaires — deviendra une référence internationale.",
    aftermath:
      "Le « modèle suédois » de résolution bancaire a été abondamment cité lors de la crise de 2008 comme exemple de sauvetage efficace protégeant le contribuable.",
    lesson:
      "Face à une crise bancaire, reconnaître vite les pertes, recapitaliser et faire payer d'abord les actionnaires limite le coût final. Cacher la poussière sous le tapis coûte plus cher.",
    keyFigures: [
      { label: "Pays", value: "Suède, Finlande, Norvège" },
      { label: "Réponse", value: "« Bad banks » + nationalisation" },
      { label: "Héritage", value: "Modèle suédois (2008)" },
    ],
  },
  {
    slug: "crise-grecque-2010",
    name: "La crise de la dette grecque",
    english: "Greek Debt Crisis",
    era: "xxie",
    year: "2010-2018",
    region: "Grèce / Zone euro",
    illu: "credit-spread",
    drawdownLabel: "PIB ≈ −25 %",
    severity: "Sévère",
    summary: "La quasi-faillite d'un État de la zone euro, sauvé au prix d'une austérité historique.",
    context:
      "Après son entrée dans l'euro, la Grèce a accumulé une dette publique massive, en partie masquée par une comptabilité défaillante. La crise de 2008 met à nu cette fragilité.",
    trigger:
      "Fin 2009, le pays révèle un déficit bien supérieur aux chiffres officiels. Les taux exigés sur la dette grecque s'envolent, la rendant impossible à refinancer sur les marchés.",
    magnitude:
      "Trois plans de sauvetage de l'UE et du FMI s'enchaînent, assortis d'une austérité drastique. Le PIB grec chute d'environ un quart, le chômage dépasse 25 %, et une restructuration impose de lourdes pertes aux créanciers privés.",
    unfolding:
      "La crise menace la cohésion de la zone euro (le « Grexit » est évoqué) jusqu'à l'engagement de la BCE, en 2012, de faire « tout ce qu'il faudra » pour préserver l'euro.",
    aftermath:
      "L'épisode a révélé les failles d'une union monétaire sans union budgétaire, et le coût social extrême d'un ajustement mené à marche forcée.",
    lesson:
      "Partager une monnaie sans partager une discipline budgétaire crée une fragilité durable. Et la confiance des marchés dans la dette d'un État peut s'évaporer très vite quand les chiffres se révèlent faux.",
    keyFigures: [
      { label: "Chute du PIB", value: "≈ −25 %" },
      { label: "Plans de sauvetage", value: "3 (UE/FMI)" },
      { label: "Tournant", value: "« Whatever it takes » (2012)" },
    ],
  },
  {
    slug: "lire-turque-2018",
    name: "La crise de la lire turque",
    english: "Turkish Currency Crisis",
    era: "xxie",
    year: "2018-2021",
    region: "Turquie",
    illu: "exchange-rate",
    drawdownLabel: "Lire ≈ −80 %",
    severity: "Majeure",
    summary: "Une monnaie en chute libre, sur fond de dette en devises et de politique monétaire à contre-courant.",
    context:
      "Dans les années 2010, la Turquie connaît une forte croissance, financée en grande partie par de la dette en devises étrangères des entreprises. L'inflation grimpe et la confiance dans la politique monétaire s'effrite.",
    trigger:
      "À partir de 2018, des tensions diplomatiques, une inflation galopante et le refus de relever suffisamment les taux (jugés contraires à la croissance) provoquent une fuite des capitaux.",
    magnitude:
      "La lire perd l'essentiel de sa valeur face au dollar sur plusieurs années (de l'ordre de −80 % au plus fort), tandis que l'inflation s'envole bien au-delà de 50 % puis 80 %.",
    unfolding:
      "La dette en devises devient écrasante pour les entreprises turques. Des mesures non conventionnelles tentent de soutenir la lire, avec un succès limité tant que les taux restent jugés trop bas.",
    aftermath:
      "La crise illustre ce qui se produit quand une banque centrale perd son indépendance perçue : marchés et citoyens cessent de croire à la maîtrise de l'inflation.",
    lesson:
      "Lutter contre l'inflation en refusant de monter les taux va à rebours de la logique économique : la monnaie en paie le prix. La crédibilité monétaire, une fois perdue, est très coûteuse à reconstruire.",
    keyFigures: [
      { label: "Chute de la lire", value: "≈ −80 %" },
      { label: "Inflation", value: "> 80 % (pic)" },
      { label: "Cause", value: "Crédibilité monétaire" },
    ],
  },
  {
    slug: "immobilier-chinois-2021",
    name: "La crise immobilière chinoise",
    english: "China Property Crisis (Evergrande)",
    era: "xxie",
    year: "2021-2023",
    region: "Chine",
    illu: "bubble",
    drawdownLabel: "Défauts massifs",
    severity: "Sévère",
    summary: "Le retournement d'un secteur immobilier surendetté, symbolisé par la chute du géant Evergrande.",
    context:
      "Pendant deux décennies, l'immobilier a porté la croissance chinoise, représentant une part énorme du PIB. Les promoteurs se sont massivement endettés pour construire, souvent en pré-vendant des logements non encore bâtis.",
    trigger:
      "En 2020-2021, Pékin impose des limites d'endettement aux promoteurs (les « trois lignes rouges »). Privé de financement facile, le géant Evergrande, croulant sous plus de 300 milliards de dollars de dettes, fait défaut.",
    magnitude:
      "La défiance gagne tout le secteur : ventes en chute, chantiers à l'arrêt, autres promoteurs en défaut, acheteurs ne recevant pas leur logement. L'immobilier, moteur de l'économie, devient un frein.",
    unfolding:
      "Les autorités cherchent à éviter une contagion financière tout en dégonflant la bulle, dans un délicat exercice d'équilibre. La confiance des ménages, très exposés à la pierre, est durablement entamée.",
    aftermath:
      "La crise a remis en cause le modèle de croissance chinois fondé sur l'immobilier à crédit et illustré le risque d'une dépendance excessive d'une économie à un seul secteur.",
    lesson:
      "Quand un secteur surendetté pèse une part démesurée d'une économie, son retournement devient un risque systémique. Pré-vendre et construire à crédit n'est tenable que tant que les prix montent.",
    keyFigures: [
      { label: "Symbole", value: "Evergrande" },
      { label: "Dette", value: "> 300 Mds $" },
      { label: "Déclencheur", value: "« Trois lignes rouges »" },
    ],
  },
  {
    slug: "panique-1857",
    name: "La Panique de 1857",
    english: "Panic of 1857",
    era: "avant-1900",
    year: "1857",
    region: "États-Unis / Europe",
    illu: "credit-spread",
    drawdownLabel: "Première crise mondiale",
    severity: "Majeure",
    summary: "Souvent décrite comme la première crise financière véritablement mondiale, propagée par le télégraphe et le rail.",
    context:
      "Au milieu du XIXᵉ siècle, l'essor du chemin de fer et des terres de l'Ouest américain alimente une spéculation effrénée, financée par un crédit bancaire abondant. L'Europe et les États-Unis sont désormais reliés par le télégraphe et le commerce maritime, tissant une interdépendance financière inédite.",
    trigger:
      "En août 1857, la faillite de l'Ohio Life Insurance and Trust Company, exposée à la spéculation ferroviaire, déclenche une vague de défiance. La nouvelle se propage en quelques heures grâce au télégraphe, accélérant la panique.",
    magnitude:
      "Les retraits bancaires se multiplient, le crédit se gèle, des centaines de banques suspendent leurs paiements. Les cours des actions ferroviaires s'effondrent et le chômage urbain explose dans le Nord-Est américain.",
    unfolding:
      "La crise traverse l'Atlantique : banques britanniques et établissements de Hambourg vacillent à leur tour. Le naufrage du SS Central America, emportant une cargaison d'or destinée à renflouer les banques de New York, aggrave la pénurie de liquidités.",
    aftermath:
      "L'activité repart dès 1859, mais la crise a creusé les tensions entre un Nord industriel fragilisé et un Sud cotonnier relativement épargné, alimentant le contexte qui mènera à la guerre de Sécession.",
    lesson:
      "Dès que les marchés s'interconnectent — hier par le télégraphe, aujourd'hui par le numérique —, une faillite locale peut se transformer en panique globale en un temps record. La vitesse de l'information est aussi celle de la contagion.",
    keyFigures: [
      { label: "Année", value: "1857" },
      { label: "Étincelle", value: "Ohio Life" },
      { label: "Vecteur", value: "Télégraphe" },
    ],
  },
  {
    slug: "panique-1893",
    name: "La Panique de 1893",
    english: "Panic of 1893",
    era: "avant-1900",
    year: "1893-1897",
    region: "États-Unis",
    illu: "drawdown",
    drawdownLabel: "≈ 18 % de chômage",
    severity: "Sévère",
    summary: "La plus grave dépression américaine avant 1929, née d'une surextension ferroviaire et d'une crise monétaire.",
    context:
      "Dans les années 1880-1890, les chemins de fer américains se construisent à un rythme insoutenable, largement à crédit. Le débat sur l'étalon (or contre argent) fragilise par ailleurs la confiance dans la monnaie et les réserves d'or du Trésor.",
    trigger:
      "Début 1893, la faillite de la Philadelphia and Reading Railroad, puis celle de la National Cordage Company, déclenche la panique. Les investisseurs étrangers rapatrient leur or, vidant les réserves américaines.",
    magnitude:
      "Environ 500 banques et 15 000 entreprises font faillite. Des centaines de compagnies ferroviaires sont placées sous administration. Le chômage grimpe vers 18 %, provoquant misère et troubles sociaux à travers le pays.",
    unfolding:
      "La dépression s'installe durablement. Le financier J. P. Morgan organise en 1895 un syndicat privé pour reconstituer les réserves d'or du Trésor — un sauvetage qui préfigure le rôle de prêteur en dernier ressort, encore absent à l'époque.",
    aftermath:
      "La crise marque la fin de l'âge d'or ferroviaire et nourrit le débat monétaire qui culminera avec l'élection de 1896. Elle illustre l'absence de banque centrale, lacune qui mènera plus tard à la création de la Fed.",
    lesson:
      "Une expansion financée par une dette massive dans un seul secteur prépare une chute brutale. Sans prêteur en dernier ressort, une panique bancaire peut dégénérer en dépression prolongée.",
    keyFigures: [
      { label: "Banques en faillite", value: "≈ 500" },
      { label: "Chômage", value: "≈ 18 %" },
      { label: "Sauveur", value: "J. P. Morgan" },
    ],
  },
  {
    slug: "credit-anstalt-1931",
    name: "La faillite de la Credit-Anstalt",
    english: "Creditanstalt Collapse",
    era: "xxe",
    year: "1931",
    region: "Autriche / Europe",
    illu: "credit-spread",
    drawdownLabel: "Contagion bancaire",
    severity: "Sévère",
    summary: "L'effondrement de la première banque autrichienne qui a fait basculer la Grande Dépression sur l'Europe.",
    context:
      "Après le krach de 1929, l'économie mondiale est déjà fragilisée. En Europe centrale, la Credit-Anstalt — plus grande banque d'Autriche, contrôlant une large part de l'industrie du pays — porte des actifs détériorés hérités de la guerre et de l'hyperinflation des années 1920.",
    trigger:
      "En mai 1931, la Credit-Anstalt révèle des pertes colossales qui dépassent son capital. La nouvelle déclenche une ruée des déposants et une fuite des capitaux étrangers hors d'Autriche.",
    magnitude:
      "La panique se propage à l'Allemagne, dont le système bancaire s'effondre à son tour à l'été 1931, puis fait pression sur la livre sterling. En septembre, le Royaume-Uni abandonne l'étalon-or, brisant l'ossature monétaire de l'époque.",
    unfolding:
      "Les tentatives de sauvetage international se heurtent aux tensions politiques liées aux réparations de guerre. La contraction du crédit aggrave la dépression et, en Allemagne, le chômage de masse nourrit la montée des extrêmes.",
    aftermath:
      "La crise de la Credit-Anstalt est considérée comme le moment où la Grande Dépression est devenue véritablement mondiale et a basculé en catastrophe européenne, avec des conséquences politiques majeures dans les années 1930.",
    lesson:
      "Une banque trop grande et trop centrale pour un pays fait peser un risque systémique. Quand la finance est internationale mais la coopération politique défaillante, une faillite locale peut embraser un continent.",
    keyFigures: [
      { label: "Pays", value: "Autriche" },
      { label: "Année", value: "1931" },
      { label: "Conséquence", value: "Fin de l'étalon-or (R.-U.)" },
    ],
  },
  {
    slug: "hyperinflation-weimar-1923",
    name: "L'hyperinflation de Weimar",
    english: "Weimar Hyperinflation",
    era: "xxe",
    year: "1921-1923",
    region: "Allemagne",
    illu: "inflation",
    drawdownLabel: "Monnaie anéantie",
    severity: "Sévère",
    summary: "L'épisode emblématique où une monnaie a perdu toute valeur, jusqu'à brûler des billets pour se chauffer.",
    context:
      "Après la Première Guerre mondiale, la jeune République de Weimar croule sous les réparations imposées par le traité de Versailles, exigées en or ou en devises. Pour financer ses dépenses et ses dettes, l'État recourt massivement à la planche à billets.",
    trigger:
      "L'occupation de la Ruhr par la France et la Belgique en janvier 1923, en réponse à des défauts de paiement, provoque une grève générale soutenue par l'État — financée, là encore, par l'émission monétaire. La confiance dans le mark s'effondre.",
    magnitude:
      "Les prix doublent parfois en quelques heures. Fin 1923, un dollar vaut plus de 4 000 milliards de marks. Les billets se transportent en brouette, et il devient moins coûteux de les brûler que d'acheter du combustible.",
    unfolding:
      "L'épargne des classes moyennes est anéantie, tandis que les débiteurs voient leurs dettes s'évaporer. Fin 1923, une réforme monétaire instaure le Rentenmark, adossé à des garanties foncières, qui stabilise enfin les prix.",
    aftermath:
      "Le traumatisme de l'hyperinflation a durablement façonné la culture monétaire allemande, expliquant l'attachement ultérieur à la rigueur et à l'indépendance de la banque centrale. Ses séquelles sociales ont aussi nourri l'instabilité politique des années 1930.",
    lesson:
      "Une monnaie ne vaut que par la confiance qu'elle inspire. Lorsqu'un État finance ses déficits par une création monétaire sans limite, la valeur de la monnaie peut s'effondrer jusqu'à l'absurde — et avec elle, l'épargne de toute une société.",
    keyFigures: [
      { label: "Pic", value: "Fin 1923" },
      { label: "1 dollar", value: "> 4 000 Mds de marks" },
      { label: "Sortie de crise", value: "Rentenmark" },
    ],
  },
  {
    slug: "choc-nixon-1971",
    name: "Le choc Nixon",
    english: "Nixon Shock",
    era: "xxe",
    year: "1971",
    region: "International",
    illu: "exchange-rate",
    drawdownLabel: "Fin de l'or-dollar",
    severity: "Majeure",
    summary: "La fin de la convertibilité du dollar en or, qui a fait basculer le monde dans les changes flottants.",
    context:
      "Depuis les accords de Bretton Woods (1944), le dollar est convertible en or à 35 $ l'once, et les autres monnaies sont arrimées au dollar. Mais dans les années 1960, les déficits américains (guerre du Vietnam, dépenses sociales) gonflent la masse de dollars en circulation bien au-delà des réserves d'or.",
    trigger:
      "Face à la défiance et aux demandes croissantes de conversion des dollars en or par les pays étrangers, le président Richard Nixon suspend unilatéralement la convertibilité le 15 août 1971.",
    magnitude:
      "Le système de changes fixes de Bretton Woods s'effondre en moins de deux ans. Après une tentative de réajustement (accords du Smithsonian), les grandes monnaies passent en changes flottants à partir de 1973.",
    unfolding:
      "La fin de l'ancrage à l'or libère la création monétaire et coïncide avec une décennie de forte inflation, aggravée par les chocs pétroliers. Le marché des changes devient l'un des plus vastes au monde, avec une volatilité nouvelle entre devises.",
    aftermath:
      "Le choc Nixon a inauguré l'ère monétaire actuelle, celle des monnaies fiduciaires sans contrepartie métallique et des taux de change déterminés par les marchés. Il reste un tournant majeur de l'histoire financière.",
    lesson:
      "Un ancrage monétaire ne tient que tant qu'il est crédible. Quand les engagements dépassent les réserves qui les garantissent, le régime finit par céder — et redessine durablement le paysage financier mondial.",
    keyFigures: [
      { label: "Date", value: "15 août 1971" },
      { label: "Parité abandonnée", value: "35 $/once" },
      { label: "Conséquence", value: "Changes flottants" },
    ],
  },
  {
    slug: "crise-rouble-2014",
    name: "La crise du rouble russe",
    english: "Russian Rouble Crisis",
    era: "xxie",
    year: "2014-2015",
    region: "Russie",
    illu: "exchange-rate",
    drawdownLabel: "Rouble ≈ −50 %",
    severity: "Majeure",
    summary: "L'effondrement de la monnaie russe sous le double choc de la chute du pétrole et des sanctions.",
    context:
      "L'économie russe dépend lourdement de ses exportations d'hydrocarbures, qui alimentent les recettes de l'État et soutiennent le rouble. En 2014, le pays fait face à des sanctions occidentales à la suite de l'annexion de la Crimée.",
    trigger:
      "La chute brutale du prix du pétrole à partir de l'été 2014, combinée aux sanctions qui coupent l'accès aux marchés financiers occidentaux, déclenche une fuite des capitaux et une pression intense sur le rouble.",
    magnitude:
      "Le rouble perd près de la moitié de sa valeur face au dollar en quelques mois. Dans la nuit du 15 au 16 décembre 2014, la banque centrale relève son taux directeur de 10,5 % à 17 % pour tenter d'enrayer la panique.",
    unfolding:
      "L'inflation s'envole, le pouvoir d'achat recule et la récession s'installe. La banque centrale laisse finalement le rouble flotter librement et puise dans ses réserves de change pour amortir le choc.",
    aftermath:
      "La Russie a peu à peu stabilisé sa monnaie au prix d'une récession et d'une inflation élevée, tout en cherchant à réduire sa dépendance aux financements occidentaux. La crise a illustré la vulnérabilité d'une économie mono-exportatrice.",
    lesson:
      "Une monnaie adossée à une seule ressource est à la merci de son cours mondial. Quand un choc de prix s'ajoute à un choc géopolitique, la défense d'une devise peut exiger des taux d'intérêt brutaux, au prix de l'économie réelle.",
    keyFigures: [
      { label: "Chute du rouble", value: "≈ −50 %" },
      { label: "Taux directeur", value: "10,5 % → 17 %" },
      { label: "Double choc", value: "Pétrole + sanctions" },
    ],
  },
  {
    slug: "panique-1792",
    name: "La Panique de 1792",
    english: "Panic of 1792",
    era: "avant-1900",
    year: "1792",
    region: "États-Unis",
    illu: "margin-call",
    drawdownLabel: "1ʳᵉ crise américaine",
    severity: "Modérée",
    summary: "La toute première crise financière des États-Unis, jugulée par une intervention décisive d'Alexander Hamilton.",
    context:
      "Au lendemain de l'indépendance, le jeune système financier américain s'organise autour de la nouvelle Bank of the United States et d'un marché obligataire naissant. La spéculation sur les titres bancaires et la dette fédérale s'emballe, menée par des financiers à l'effet de levier élevé.",
    trigger:
      "Le spéculateur William Duer et ses associés, lourdement endettés, tentent d'accaparer le marché de la dette. Quand leur montage s'effondre au début de 1792, une vague de défauts et de ventes forcées s'enclenche.",
    magnitude:
      "Les prix des titres chutent brutalement en quelques semaines. Le crédit se contracte et la confiance dans le tout nouvel édifice financier vacille, menaçant de l'étouffer dans l'œuf.",
    unfolding:
      "Le secrétaire au Trésor Alexander Hamilton réagit vite : il organise des achats de titres publics et fournit des liquidités aux banques via les banques privées, posant les bases d'une action de stabilisation par l'État — un précédent fondateur.",
    aftermath:
      "La crise débouche l'année suivante sur l'accord de Buttonwood (1792), à l'origine de ce qui deviendra le New York Stock Exchange. L'intervention de Hamilton est étudiée comme l'une des premières opérations de prêteur en dernier ressort.",
    lesson:
      "Dès l'origine, les marchés ont connu l'excès de levier et la spéculation concertée. Et dès l'origine, une intervention rapide et crédible des autorités a pu éviter qu'une panique locale ne ruine la confiance dans tout un système.",
    keyFigures: [
      { label: "Année", value: "1792" },
      { label: "Protagoniste", value: "William Duer" },
      { label: "Héritage", value: "Accord de Buttonwood" },
    ],
  },
  {
    slug: "crise-barings-1890",
    name: "La crise Baring",
    english: "Baring Crisis",
    era: "avant-1900",
    year: "1890",
    region: "Royaume-Uni / Argentine",
    illu: "credit-spread",
    drawdownLabel: "Quasi-faillite",
    severity: "Majeure",
    summary: "La quasi-faillite d'une grande banque londonienne sur ses engagements argentins, contenue par un sauvetage coordonné.",
    context:
      "À la fin du XIXᵉ siècle, la banque d'affaires britannique Baring Brothers, l'une des plus prestigieuses au monde, finance massivement le développement de l'Argentine via des émissions d'emprunts et d'actions.",
    trigger:
      "En 1890, l'Argentine traverse une grave crise économique et politique et se révèle incapable d'honorer ses dettes. Baring, fortement exposée à des titres argentins devenus invendables, se retrouve au bord de l'insolvabilité.",
    magnitude:
      "La menace de faillite d'une institution aussi centrale fait craindre une panique générale sur la place de Londres, cœur de la finance mondiale de l'époque.",
    unfolding:
      "La Banque d'Angleterre, sous la houlette de son gouverneur William Lidderdale, organise un fonds de garantie alimenté par les autres grandes banques pour absorber les pertes de Baring et éviter une faillite désordonnée. La maison est restructurée.",
    aftermath:
      "Le sauvetage est resté un cas d'école de gestion coordonnée du risque systémique. Il a renforcé le rôle de la Banque d'Angleterre comme garante de la stabilité, tout en illustrant les dangers d'une surexposition à un seul pays émergent.",
    lesson:
      "Même les institutions les plus prestigieuses peuvent être mises à genoux par une concentration excessive du risque. La coordination entre acteurs financiers, sous l'égide d'une banque centrale, peut désamorcer une crise avant qu'elle ne se propage.",
    keyFigures: [
      { label: "Banque", value: "Baring Brothers" },
      { label: "Exposition", value: "Argentine" },
      { label: "Sauveur", value: "Banque d'Angleterre" },
    ],
  },
  {
    slug: "nifty-fifty-1973",
    name: "Les « Nifty Fifty »",
    english: "Nifty Fifty Bust",
    era: "xxe",
    year: "1972-1974",
    region: "États-Unis",
    illu: "bubble",
    drawdownLabel: "Valorisations dégonflées",
    severity: "Majeure",
    summary: "L'éclatement de la mode des « valeurs qu'on n'a qu'à acheter et garder », payées à n'importe quel prix.",
    context:
      "Au début des années 1970, une cinquantaine de grandes valeurs américaines de qualité — Coca-Cola, IBM, Xerox, Polaroid… — sont surnommées les « Nifty Fifty ». Réputées indéboulonnables, elles sont présentées comme des « one-decision stocks » : on les achète et on ne s'en sépare jamais.",
    trigger:
      "L'engouement pousse leurs valorisations à des multiples extrêmes, parfois plus de 50 fois les bénéfices. Le marché baissier de 1973-1974, aggravé par le choc pétrolier et l'inflation, met fin à l'euphorie.",
    magnitude:
      "Beaucoup de ces titres « incontournables » perdent la moitié ou plus de leur valeur. Leur prime de qualité, jugée éternelle, se dégonfle violemment lorsque les taux montent et que la croissance déçoit.",
    unfolding:
      "Les investisseurs découvrent qu'une excellente entreprise peut rester un mauvais investissement si on la paie trop cher. La correction ramène les multiples vers des niveaux plus raisonnables au fil de la décennie.",
    aftermath:
      "L'épisode est devenu un cas d'école sur le prix payé : la qualité d'une société ne protège pas d'une surévaluation. Il a nourri la pensée de l'investissement « value » et la prudence face aux récits de « valeurs intouchables ».",
    lesson:
      "Une grande entreprise et un bon investissement ne sont pas synonymes : tout dépend du prix payé. Quand un récit transforme des actions en certitudes « qu'on garde à vie », la valorisation finit par rappeler ses droits.",
    keyFigures: [
      { label: "Surnom", value: "One-decision stocks" },
      { label: "Multiples", value: "> 50× les bénéfices" },
      { label: "Éclatement", value: "1973-1974" },
    ],
  },
  {
    slug: "crise-dette-latino-1982",
    name: "La crise de la dette latino-américaine",
    english: "Latin American Debt Crisis",
    era: "xxe",
    year: "1982",
    region: "Amérique latine",
    illu: "credit-spread",
    drawdownLabel: "« Décennie perdue »",
    severity: "Sévère",
    summary: "Le défaut en chaîne des pays latino-américains, point de départ d'une « décennie perdue ».",
    context:
      "Dans les années 1970, les pétrodollars recyclés par les banques occidentales financent un endettement massif des pays d'Amérique latine, en dollars et à taux variable. Mexique, Brésil et Argentine accumulent des dettes considérables.",
    trigger:
      "La forte hausse des taux américains, sous l'impulsion de Paul Volcker pour casser l'inflation, fait exploser le coût de cette dette. En août 1982, le Mexique annonce qu'il ne peut plus honorer ses échéances.",
    magnitude:
      "Le défaut mexicain entraîne une vague de crises de la dette à travers le continent. Les grandes banques américaines, fortement exposées, sont menacées ; la croissance latino-américaine s'effondre.",
    unfolding:
      "Des plans de rééchelonnement se succèdent, puis le plan Brady (1989) convertit une partie des dettes en obligations négociables, soulageant enfin les pays débiteurs. L'ajustement impose une décennie d'austérité.",
    aftermath:
      "Les années 1980 restent la « décennie perdue » de l'Amérique latine, marquée par la stagnation et l'inflation. La crise a transformé la gestion de la dette souveraine et le rôle du FMI.",
    lesson:
      "S'endetter en devise étrangère et à taux variable transfère un risque majeur à l'emprunteur : un resserrement monétaire décidé ailleurs peut rendre la dette insoutenable du jour au lendemain.",
    keyFigures: [
      { label: "Déclencheur", value: "Défaut du Mexique" },
      { label: "Année", value: "1982" },
      { label: "Sortie", value: "Plan Brady (1989)" },
    ],
  },
  {
    slug: "hyperinflation-zimbabwe-2008",
    name: "L'hyperinflation du Zimbabwe",
    english: "Zimbabwe Hyperinflation",
    era: "xxie",
    year: "2007-2009",
    region: "Zimbabwe",
    illu: "inflation",
    drawdownLabel: "Monnaie abandonnée",
    severity: "Sévère",
    summary: "L'une des pires hyperinflations de l'Histoire, jusqu'au billet de 100 000 milliards de dollars zimbabwéens.",
    context:
      "Dans les années 2000, le Zimbabwe s'enfonce dans la crise économique après une réforme agraire désorganisée qui effondre la production. Privé de recettes, l'État finance ses dépenses par une émission monétaire débridée.",
    trigger:
      "L'effondrement de la production et la défiance généralisée envers la monnaie alimentent une spirale inflationniste incontrôlable, qui s'emballe à partir de 2007.",
    magnitude:
      "L'inflation atteint des niveaux astronomiques — chiffrés en milliards de pour cent en 2008. La banque centrale émet des coupures délirantes, jusqu'au billet de 100 000 milliards de dollars zimbabwéens.",
    unfolding:
      "La population se réfugie dans les devises étrangères et le troc. Début 2009, le pays renonce de fait à sa monnaie et adopte le dollar américain et le rand sud-africain pour rétablir un semblant de stabilité.",
    aftermath:
      "L'épisode est devenu un cas d'école contemporain d'hyperinflation, rappelant les leçons de Weimar : une monnaie sans confiance ni discipline d'émission peut perdre toute valeur, paralysant l'économie réelle.",
    lesson:
      "Imprimer de la monnaie pour combler un effondrement de la production ne crée pas de richesse : cela détruit la valeur de la monnaie. La confiance, une fois perdue, ne se décrète pas — elle se reconstruit par la discipline.",
    keyFigures: [
      { label: "Pic d'inflation", value: "2008" },
      { label: "Coupure record", value: "100 000 Mds Z$" },
      { label: "Sortie", value: "Dollarisation (2009)" },
    ],
  },
  {
    slug: "bulle-immobiliere-espagnole-2008",
    name: "La bulle immobilière espagnole",
    english: "Spanish Property Bubble",
    era: "xxie",
    year: "2008-2014",
    region: "Espagne",
    illu: "bubble",
    drawdownLabel: "Chômage ≈ 26 %",
    severity: "Sévère",
    summary: "L'éclatement d'une bulle immobilière géante qui a précipité l'Espagne dans une crise bancaire et sociale.",
    context:
      "Après l'adoption de l'euro, l'Espagne bénéficie de taux d'intérêt bas qui alimentent un boom immobilier sans précédent. La construction devient un moteur central de l'économie, financée par un crédit abondant distribué notamment par les caisses d'épargne régionales (cajas).",
    trigger:
      "La crise financière mondiale de 2008 stoppe net l'accès au crédit. La demande de logements s'effondre alors que l'offre, surabondante, continue d'affluer : les prix se retournent brutalement.",
    magnitude:
      "Des centaines de milliers de logements restent invendus, les promoteurs font faillite et les cajas, gorgées de créances immobilières douteuses, vacillent. Le chômage grimpe jusqu'à environ 26 %, et au-delà de 50 % chez les jeunes.",
    unfolding:
      "En 2012, l'Espagne sollicite une aide européenne de plusieurs dizaines de milliards d'euros pour recapitaliser son système bancaire. Une structure de défaisance (la « bad bank » Sareb) absorbe les actifs toxiques.",
    aftermath:
      "L'économie espagnole met des années à se redresser, au prix d'une austérité sévère et d'une restructuration profonde du secteur bancaire. La crise illustre les dangers d'une croissance trop dépendante de la pierre et du crédit facile.",
    lesson:
      "Des taux durablement bas peuvent gonfler une bulle sectorielle qui semble enrichir tout le monde — jusqu'au retournement. Quand l'économie et les banques reposent sur un seul moteur surendetté, sa chute devient systémique.",
    keyFigures: [
      { label: "Chômage", value: "≈ 26 %" },
      { label: "Sauvetage bancaire", value: "Aide UE (2012)" },
      { label: "Défaisance", value: "Sareb" },
    ],
  },
  {
    slug: "overend-gurney-1866",
    name: "La crise Overend Gurney",
    english: "Overend, Gurney & Co. Crisis",
    era: "avant-1900",
    year: "1866",
    region: "Royaume-Uni",
    illu: "credit-spread",
    drawdownLabel: "Panique bancaire",
    severity: "Majeure",
    summary: "La faillite d'une grande banque d'escompte londonienne, à l'origine du « Black Friday » de 1866.",
    context:
      "Overend, Gurney & Co. était l'une des plus importantes banques d'escompte de Londres, surnommée « la banque des banquiers ». Dans les années 1860, elle s'écarte de son métier prudent pour investir dans des actifs risqués et illiquides, accumulant les pertes.",
    trigger:
      "Transformée en société par actions, la banque ne parvient pas à se redresser. Le 10 mai 1866 — le « Black Friday » —, elle suspend ses paiements, incapable d'honorer ses engagements.",
    magnitude:
      "La nouvelle déclenche une panique bancaire générale à Londres. Les taux d'intérêt s'envolent, de nombreuses entreprises et banques font faillite dans la foulée.",
    unfolding:
      "La Banque d'Angleterre prête massivement pour enrayer la panique, mais refuse de sauver Overend Gurney elle-même. Cet épisode nourrira la doctrine de Walter Bagehot dans « Lombard Street » (1873) : en cas de panique, prêter sans compter, à taux élevé, contre de bonnes garanties.",
    aftermath:
      "La crise a façonné la théorie moderne du prêteur en dernier ressort. Elle reste un cas d'étude majeur sur le rôle d'une banque centrale face à une panique systémique.",
    lesson:
      "Quand une institution réputée sûre s'écarte de son métier pour courir le rendement, elle met en péril tout le système. La règle de Bagehot — prêter librement en cas de panique — est née de cet échec.",
    keyFigures: [
      { label: "Date", value: "« Black Friday » 1866" },
      { label: "Surnom", value: "Banque des banquiers" },
      { label: "Héritage", value: "Doctrine de Bagehot" },
    ],
  },
  {
    slug: "vendredi-noir-1869",
    name: "Le Vendredi Noir de 1869",
    english: "Black Friday (Gold Corner)",
    era: "avant-1900",
    year: "1869",
    region: "États-Unis",
    illu: "commodity",
    drawdownLabel: "Manipulation de l'or",
    severity: "Modérée",
    summary: "La tentative de Jay Gould et James Fisk d'accaparer le marché de l'or, qui s'effondre le 24 septembre 1869.",
    context:
      "Après la guerre de Sécession, les financiers Jay Gould et James Fisk conçoivent un plan pour accaparer (corner) le marché de l'or à New York, en pariant que le gouvernement s'abstiendrait d'en vendre.",
    trigger:
      "Le duo achète massivement de l'or et en fait monter le cours, comptant sur l'inaction du Trésor. Mais le 24 septembre 1869 — le « Vendredi Noir » —, le gouvernement de Grant décide de vendre 4 millions de dollars d'or.",
    magnitude:
      "Le cours de l'or s'effondre en quelques minutes. La panique se propage à la Bourse de New York, ruinant de nombreux spéculateurs entraînés dans la manœuvre.",
    unfolding:
      "Les marchés financiers américains sont secoués, et l'affaire éclabousse l'entourage du président Grant. Gould, prévenu à temps, limite ses pertes ; beaucoup d'autres sont ruinés.",
    aftermath:
      "Le scandale est resté l'archétype de la manipulation de marché par accaparement. Il a contribué à la prise de conscience du besoin de régulation des marchés.",
    lesson:
      "Tenter d'accaparer un marché revient à parier que personne de plus puissant n'interviendra. Quand l'État ou un acteur majeur entre en jeu, le château de cartes spéculatif s'écroule d'un coup.",
    keyFigures: [
      { label: "Date", value: "24 sept. 1869" },
      { label: "Protagonistes", value: "Gould & Fisk" },
      { label: "Cible", value: "Marché de l'or" },
    ],
  },
  {
    slug: "bulle-floride-1926",
    name: "La bulle foncière de Floride",
    english: "Florida Land Boom",
    era: "xxe",
    year: "1920-1926",
    region: "États-Unis",
    illu: "bubble",
    drawdownLabel: "Effondrement foncier",
    severity: "Majeure",
    summary: "La folie spéculative sur les terrains de Floride dans les années 1920, dégonflée avant même le krach de 1929.",
    context:
      "Dans les Années folles, la Floride devient l'eldorado immobilier des États-Unis. Le climat, l'essor de l'automobile et une publicité agressive attirent une vague d'acheteurs ; les terrains s'échangent sur plan, souvent revendus plusieurs fois avant d'être bâtis.",
    trigger:
      "Les prix s'envolent sur la seule promesse de revente. À partir de 1925, l'afflux d'acheteurs se tarit, les terrains restent invendus et les premiers défauts apparaissent.",
    magnitude:
      "Deux ouragans dévastateurs en 1926, dont celui de Miami, achèvent de briser la confiance. Les prix s'effondrent et d'innombrables fortunes de papier s'évaporent.",
    unfolding:
      "Les banques locales, exposées au foncier, vacillent. La région entre en récession bien avant le reste du pays, préfigurant les excès qui mèneront au krach de 1929.",
    aftermath:
      "La bulle floridienne est devenue l'un des exemples les plus cités de spéculation foncière collective, où l'on achète non pour bâtir mais pour revendre plus cher.",
    lesson:
      "Quand un actif s'échange uniquement sur l'espoir de le revendre à un acheteur plus optimiste, sa valeur ne tient qu'à l'afflux de nouveaux entrants. Le jour où ils manquent, il n'y a plus de prix.",
    keyFigures: [
      { label: "Apogée", value: "1925" },
      { label: "Coup de grâce", value: "Ouragans 1926" },
      { label: "Nature", value: "Revente sur plan" },
    ],
  },
  {
    slug: "hyperinflation-hongrie-1946",
    name: "L'hyperinflation hongroise",
    english: "Hungarian Pengő Hyperinflation",
    era: "xxe",
    year: "1945-1946",
    region: "Hongrie",
    illu: "inflation",
    drawdownLabel: "Pire de l'Histoire",
    severity: "Sévère",
    summary: "La plus violente hyperinflation jamais enregistrée : les prix doublaient toutes les quinze heures.",
    context:
      "Au lendemain de la Seconde Guerre mondiale, la Hongrie est dévastée, son économie détruite et l'État privé de recettes. Pour financer la reconstruction et les réparations, le gouvernement recourt à une émission monétaire sans limite du pengő.",
    trigger:
      "L'effondrement de la production combiné à la planche à billets déclenche une spirale inflationniste qui s'emballe au-delà de tout précédent connu, début 1946.",
    magnitude:
      "Les prix doublent environ toutes les quinze heures. L'État émet des coupures aux montants inimaginables, jusqu'au billet de cent trillions de pengő, et crée une unité spéciale pour les impôts.",
    unfolding:
      "La monnaie devient inutilisable ; les transactions se font en nature ou en devises. En août 1946, une réforme introduit une nouvelle monnaie, le forint, adossée à des règles strictes, qui rétablit la stabilité.",
    aftermath:
      "L'épisode hongrois reste, à ce jour, le record absolu d'hyperinflation. Il illustre jusqu'où peut aller la destruction d'une monnaie quand l'émission n'a plus aucune limite.",
    lesson:
      "Il n'existe pas de plancher à la valeur d'une monnaie que l'on imprime sans frein. La discipline d'émission n'est pas une option technique : c'est la condition même de l'existence d'une monnaie.",
    keyFigures: [
      { label: "Rythme", value: "Prix ×2 / ~15 h" },
      { label: "Coupure", value: "100 trillions de pengő" },
      { label: "Sortie", value: "Le forint (1946)" },
    ],
  },
  {
    slug: "northern-rock-2007",
    name: "La ruée sur Northern Rock",
    english: "Northern Rock Bank Run",
    era: "xxie",
    year: "2007",
    region: "Royaume-Uni",
    illu: "margin-call",
    drawdownLabel: "1ʳᵉ ruée en 150 ans",
    severity: "Majeure",
    summary: "La première ruée bancaire britannique depuis 150 ans, signe avant-coureur de la crise de 2008.",
    context:
      "Northern Rock, banque hypothécaire britannique, finançait ses prêts immobiliers non par les dépôts de ses clients mais en empruntant massivement sur les marchés monétaires de court terme — un modèle très dépendant de la liquidité.",
    trigger:
      "Quand le marché interbancaire se gèle à l'été 2007, sous l'effet de la crise des subprimes américaines, Northern Rock se retrouve incapable de se refinancer et sollicite un soutien d'urgence de la Banque d'Angleterre.",
    magnitude:
      "L'annonce du sauvetage, en septembre 2007, provoque la panique des déposants : des files d'attente se forment devant les agences, première ruée bancaire au Royaume-Uni depuis le XIXᵉ siècle.",
    unfolding:
      "Le gouvernement garantit les dépôts pour stopper la panique, puis nationalise la banque en février 2008. L'épisode révèle au grand jour la fragilité d'un financement de marché à court terme.",
    aftermath:
      "Northern Rock est devenu le symbole annonciateur de la crise financière de 2008. Il a conduit à renforcer les règles de liquidité et les garanties de dépôts au Royaume-Uni.",
    lesson:
      "Une banque qui finance des prêts longs par des emprunts courts vit sur un fil : si le marché se ferme, même une banque solvable peut s'effondrer faute de liquidité. La confiance des déposants, elle, ne se regagne pas facilement.",
    keyFigures: [
      { label: "Année", value: "2007" },
      { label: "Fait marquant", value: "Ruée bancaire" },
      { label: "Issue", value: "Nationalisation (2008)" },
    ],
  },
  {
    slug: "faillite-islande-2008",
    name: "L'effondrement bancaire islandais",
    english: "Icelandic Banking Collapse",
    era: "xxie",
    year: "2008",
    region: "Islande",
    illu: "credit-spread",
    drawdownLabel: "Système bancaire entier",
    severity: "Sévère",
    summary: "La faillite simultanée des trois grandes banques d'un pays dont les actifs pesaient près de dix fois le PIB.",
    context:
      "Dans les années 2000, les trois principales banques islandaises (Kaupthing, Landsbanki, Glitnir) se développent à l'international à un rythme effréné, finançant leur expansion par la dette. Leurs actifs cumulés atteignent près de dix fois le PIB du pays.",
    trigger:
      "La crise financière mondiale de 2008 coupe l'accès au financement. Surdimensionnées par rapport à leur économie, les trois banques s'effondrent en quelques jours en octobre 2008.",
    magnitude:
      "L'État, incapable de sauver des banques aussi disproportionnées, les laisse faire faillite. La couronne islandaise s'effondre, l'inflation explose et le pays plonge dans une récession sévère.",
    unfolding:
      "L'Islande nationalise les banques, instaure un contrôle des capitaux et obtient l'aide du FMI. Fait notable, le pays choisit de ne pas renflouer intégralement les créanciers étrangers, et poursuit certains banquiers en justice.",
    aftermath:
      "Au prix d'années difficiles, l'Islande se redresse plus vite que prévu. Sa gestion — laisser tomber les banques plutôt que socialiser toutes les pertes — reste un cas d'étude débattu.",
    lesson:
      "Un secteur bancaire démesuré par rapport à son économie devient impossible à sauver : l'État n'en a tout simplement pas les moyens. La taille du système financier au regard du PIB est un risque en soi.",
    keyFigures: [
      { label: "Actifs / PIB", value: "≈ 10×" },
      { label: "Banques tombées", value: "3 en quelques jours" },
      { label: "Année", value: "2008" },
    ],
  },
  {
    slug: "bulle-poseidon-1970",
    name: "La bulle Poseidon",
    english: "Poseidon Bubble",
    era: "xxe",
    year: "1969-1970",
    region: "Australie",
    illu: "commodity",
    drawdownLabel: "Action ×280 puis chute",
    severity: "Majeure",
    summary: "Une frénésie spéculative sur les valeurs minières australiennes, déclenchée par une découverte de nickel.",
    context:
      "À la fin des années 1960, le prix du nickel s'envole sur fond de guerre du Vietnam. En septembre 1969, la petite société australienne Poseidon NL annonce une découverte de nickel prometteuse, déclenchant une ruée sur les valeurs minières.",
    trigger:
      "L'action Poseidon passe d'environ 1 dollar australien à plus de 280 en quelques mois, portée par la spéculation et des rumeurs invérifiables. Des dizaines de sociétés minières sans actifs réels suivent le mouvement.",
    magnitude:
      "Quand la qualité du gisement se révèle décevante et que le cours du nickel reflue, la bulle éclate. Poseidon et la myriade de valeurs minières spéculatives s'effondrent, ruinant de nombreux particuliers.",
    unfolding:
      "Le marché minier australien met des années à se remettre de cet excès. L'épisode pousse à renforcer la régulation des marchés et l'information des investisseurs.",
    aftermath:
      "La bulle Poseidon est restée l'exemple type de l'emballement minier : une vraie découverte sert d'étincelle à une spéculation qui se détache totalement des fondamentaux.",
    lesson:
      "Une nouvelle bien réelle peut servir de prétexte à une spéculation déraisonnable. Quand une foule extrapole une découverte en certitude de richesse, le cours grimpe bien au-delà de toute valeur démontrée.",
    keyFigures: [
      { label: "Action", value: "≈ 1 → 280 $A" },
      { label: "Métal", value: "Nickel" },
      { label: "Apogée", value: "1970" },
    ],
  },
  {
    slug: "scandale-enron-2001",
    name: "L'effondrement d'Enron",
    english: "Enron Scandal",
    era: "xxie",
    year: "2001",
    region: "États-Unis",
    illu: "credit-spread",
    drawdownLabel: "≈ 90 Mds $ effacés",
    severity: "Majeure",
    summary: "La faillite d'un géant de l'énergie maquillant ses pertes, devenue le symbole de la fraude comptable.",
    context:
      "Enron, fleuron de l'énergie américaine, était présenté comme une entreprise innovante et l'une des plus admirées des États-Unis. En réalité, elle dissimulait des dettes colossales dans des entités hors bilan et gonflait artificiellement ses bénéfices.",
    trigger:
      "En 2001, des analystes et journalistes commencent à douter de comptes opaques. La révélation de pertes massives cachées et de pratiques comptables frauduleuses fait s'effondrer la confiance.",
    magnitude:
      "L'action passe de plus de 90 dollars à quelques centimes. Enron fait faillite en décembre 2001 — l'une des plus grandes de l'histoire américaine à l'époque — emportant l'épargne retraite de milliers de salariés.",
    unfolding:
      "Le cabinet d'audit Arthur Andersen, complice, est anéanti par le scandale. L'affaire révèle des défaillances majeures de gouvernance, d'audit et de régulation.",
    aftermath:
      "Le scandale a donné naissance à la loi Sarbanes-Oxley (2002), qui a profondément renforcé les obligations comptables et la responsabilité des dirigeants aux États-Unis.",
    lesson:
      "Des comptes opaques et trop beaux pour être vrais doivent alerter. Quand une entreprise dissimule sa dette hors bilan et que ses dirigeants vendent pendant que les salariés gardent, la confiance affichée peut masquer un vide.",
    keyFigures: [
      { label: "Action", value: "≈ 90 $ → centimes" },
      { label: "Auditeur", value: "Arthur Andersen" },
      { label: "Héritage", value: "Loi Sarbanes-Oxley" },
    ],
  },
  {
    slug: "crise-chypriote-2013",
    name: "La crise chypriote",
    english: "Cypriot Banking Crisis",
    era: "xxie",
    year: "2013",
    region: "Chypre",
    illu: "credit-spread",
    drawdownLabel: "Ponction des dépôts",
    severity: "Majeure",
    summary: "Le sauvetage bancaire qui a, pour la première fois, ponctionné directement les gros déposants (bail-in).",
    context:
      "Le secteur bancaire chypriote, surdimensionné et fortement exposé à la dette grecque, est dévasté par la restructuration de cette dernière en 2012. Les deux principales banques de l'île se retrouvent en grande difficulté.",
    trigger:
      "En mars 2013, Chypre sollicite l'aide de l'Union européenne et du FMI. En échange, les créanciers exigent une contribution interne : pour la première fois dans la zone euro, les dépôts non garantis (au-delà de 100 000 €) sont ponctionnés.",
    magnitude:
      "Les banques ferment plusieurs jours, des contrôles de capitaux sont instaurés, et les gros déposants subissent des pertes importantes. La confiance dans la garantie implicite des dépôts est ébranlée.",
    unfolding:
      "Le « bail-in » chypriote marque un tournant : désormais, ce sont d'abord les actionnaires, créanciers et gros déposants — et non plus seulement les contribuables — qui absorbent les pertes bancaires.",
    aftermath:
      "Le précédent chypriote a inspiré le mécanisme européen de résolution bancaire, consacrant le principe du renflouement interne avant tout recours à l'argent public.",
    lesson:
      "Un dépôt bancaire n'est pas un coffre-fort : au-delà des montants garantis, il constitue une créance sur une banque. Quand celle-ci fait faillite, même les déposants peuvent être appelés à contribuer.",
    keyFigures: [
      { label: "Seuil garanti", value: "100 000 €" },
      { label: "Nouveauté", value: "Bail-in des dépôts" },
      { label: "Année", value: "2013" },
    ],
  },
  {
    slug: "archegos-2021",
    name: "L'implosion d'Archegos",
    english: "Archegos Collapse",
    era: "xxie",
    year: "2021",
    region: "États-Unis",
    illu: "margin-call",
    drawdownLabel: "≈ 10 Mds $ de pertes",
    severity: "Modérée",
    summary: "L'effondrement éclair d'un family office surendetté, par appels de marge en cascade.",
    context:
      "Archegos Capital, le family office de Bill Hwang, avait bâti des positions colossales sur quelques actions via des produits dérivés (total return swaps), avec un effet de levier extrême et discret, réparti entre plusieurs banques qui ignoraient l'exposition totale.",
    trigger:
      "Fin mars 2021, la baisse de quelques-unes de ses valeurs phares déclenche des appels de marge qu'Archegos ne peut honorer. Les banques liquident en urgence ses positions.",
    magnitude:
      "La vente forcée de dizaines de milliards de dollars d'actions fait chuter brutalement plusieurs titres. Archegos s'effondre en quelques jours, infligeant environ 10 milliards de dollars de pertes à ses banques, dont Credit Suisse et Nomura.",
    unfolding:
      "L'épisode révèle l'ampleur du risque caché par les dérivés et le levier d'un acteur non régulé comme les fonds bancaires classiques. Plusieurs banques revoient leur gestion du risque de contrepartie.",
    aftermath:
      "Archegos est devenu un cas d'école sur le levier invisible et la concentration : un seul acteur, démultiplié par les dérivés, peut faire vaciller plusieurs grandes banques.",
    lesson:
      "Le levier dissimulé par les produits dérivés rend le risque invisible jusqu'à ce qu'il se matérialise d'un coup. Une position concentrée et surdimensionnée peut s'effondrer en quelques séances une fois les appels de marge enclenchés.",
    keyFigures: [
      { label: "Pertes banques", value: "≈ 10 Mds $" },
      { label: "Structure", value: "Family office" },
      { label: "Mécanisme", value: "Levier via swaps" },
    ],
  },
  {
    slug: "terra-luna-2022",
    name: "L'effondrement de Terra-Luna",
    english: "Terra-Luna Collapse",
    era: "xxie",
    year: "2022",
    region: "Marchés crypto",
    illu: "blockchain",
    drawdownLabel: "≈ 40 Mds $ anéantis",
    severity: "Sévère",
    summary: "La faillite d'un « stablecoin algorithmique » qui a perdu son ancrage en quelques jours.",
    context:
      "Le projet Terra reposait sur un stablecoin algorithmique, l'UST, censé valoir toujours 1 dollar grâce à un mécanisme d'arbitrage avec un jeton associé, le LUNA. Un protocole promettait par ailleurs des rendements très élevés sur l'UST, attirant des milliards.",
    trigger:
      "En mai 2022, dans un marché crypto déjà fragilisé, l'UST perd son ancrage à 1 dollar. Le mécanisme censé le rétablir s'emballe en sens inverse : pour défendre l'UST, le système crée des quantités massives de LUNA.",
    magnitude:
      "La spirale est fatale : l'UST s'effondre bien sous 1 dollar et le LUNA, hyperdilué, perd la quasi-totalité de sa valeur en quelques jours. Près de 40 milliards de dollars de capitalisation s'évaporent.",
    unfolding:
      "Le choc se propage à tout l'écosystème crypto, entraînant la faillite de fonds et de prêteurs surexposés (effet domino), et accélère le marché baissier crypto de 2022.",
    aftermath:
      "Terra-Luna est devenu le symbole de la fragilité des stablecoins algorithmiques non adossés à des réserves réelles, et a relancé le débat sur leur régulation.",
    lesson:
      "Un actif « stable » qui ne tient que par un mécanisme automatique et la confiance des participants peut s'effondrer en spirale dès que cette confiance vacille. Un rendement anormalement élevé signale un risque, pas un cadeau.",
    keyFigures: [
      { label: "Capitalisation perdue", value: "≈ 40 Mds $" },
      { label: "Mécanisme", value: "Stablecoin algorithmique" },
      { label: "Année", value: "2022" },
    ],
  },
  {
    slug: "crise-sri-lanka-2022",
    name: "La crise sri-lankaise",
    english: "Sri Lankan Default",
    era: "xxie",
    year: "2022",
    region: "Sri Lanka",
    illu: "exchange-rate",
    drawdownLabel: "1er défaut du pays",
    severity: "Sévère",
    summary: "Le premier défaut souverain de l'histoire du Sri Lanka, sur fond de pénuries et de crise politique.",
    context:
      "Le Sri Lanka avait accumulé une dette extérieure importante tout en dépendant fortement des importations et du tourisme. La pandémie, des baisses d'impôts mal calibrées et une chute des réserves de change fragilisent gravement le pays.",
    trigger:
      "Début 2022, les réserves de devises s'épuisent. Le pays ne peut plus payer ses importations essentielles — carburant, médicaments, nourriture — ni honorer sa dette extérieure.",
    magnitude:
      "En mai 2022, le Sri Lanka fait défaut sur sa dette pour la première fois de son histoire. La roupie s'effondre, l'inflation explose, et de graves pénuries provoquent des coupures de courant et des files d'attente.",
    unfolding:
      "La colère populaire débouche sur une crise politique majeure et la fuite du président. Le pays négocie un plan de soutien avec le FMI et une restructuration de sa dette.",
    aftermath:
      "La crise sri-lankaise illustre la vulnérabilité d'une économie dépendante des importations et de la dette en devises face à un choc extérieur, avec des conséquences sociales et politiques dramatiques.",
    lesson:
      "Quand un pays dépend de devises étrangères pour ses besoins vitaux et son service de la dette, l'épuisement des réserves de change peut tout faire basculer — de l'économie à la stabilité politique.",
    keyFigures: [
      { label: "Événement", value: "1er défaut souverain" },
      { label: "Année", value: "2022" },
      { label: "Cause", value: "Réserves de change épuisées" },
    ],
  },
  {
    slug: "panique-1825",
    name: "La Panique de 1825",
    english: "Panic of 1825",
    era: "avant-1900",
    year: "1825",
    region: "Royaume-Uni / Amérique latine",
    illu: "bubble",
    drawdownLabel: "≈ 70 banques tombées",
    severity: "Majeure",
    summary: "La première crise des marchés émergents : une bulle sur les emprunts latino-américains, parfois imaginaires.",
    context:
      "Au début des années 1820, l'indépendance des nations d'Amérique latine ouvre un engouement à Londres pour leurs emprunts et leurs mines. La spéculation atteint un sommet absurde avec les obligations du Poyais, un pays… qui n'existait pas, inventé par l'escroc Gregor MacGregor.",
    trigger:
      "En 1825, la Banque d'Angleterre relève ses taux et l'or afflue à l'étranger. La confiance dans les emprunts exotiques s'effondre, déclenchant une ruée bancaire.",
    magnitude:
      "Quelque soixante-dix banques font faillite en Angleterre, et la Banque d'Angleterre frôle elle-même la rupture de paiements. C'est l'une des premières paniques financières d'ampleur de l'ère industrielle.",
    unfolding:
      "La Banque d'Angleterre, en prêtant en urgence, parvient à enrayer la chute — une intervention qui préfigure son futur rôle de prêteur en dernier ressort.",
    aftermath:
      "La panique de 1825 reste l'archétype de la bulle sur les marchés émergents et de l'escroquerie spéculative, illustrée par l'affaire du Poyais.",
    lesson:
      "L'attrait du lointain et de l'inconnu nourrit les bulles : quand l'enthousiasme remplace la vérification, on peut prêter à un pays qui n'existe pas. Le scepticisme est la première protection de l'investisseur.",
    keyFigures: [
      { label: "Banques tombées", value: "≈ 70" },
      { label: "Escroquerie", value: "Emprunt du Poyais" },
      { label: "Année", value: "1825" },
    ],
  },
  {
    slug: "silver-thursday-1980",
    name: "Le Jeudi de l'Argent (Hunt)",
    english: "Silver Thursday",
    era: "xxe",
    year: "1980",
    region: "États-Unis",
    illu: "commodity",
    drawdownLabel: "Argent −50 % en un jour",
    severity: "Majeure",
    summary: "L'effondrement du cours de l'argent après la tentative des frères Hunt d'accaparer le marché.",
    context:
      "À la fin des années 1970, les frères Hunt, héritiers d'une fortune pétrolière, accumulent des quantités colossales d'argent métal et de contrats à terme, espérant en accaparer le marché. Le cours passe d'environ 6 à près de 50 dollars l'once.",
    trigger:
      "Les autorités et les Bourses relèvent les exigences de marge et limitent les positions spéculatives. Privés de financement, les Hunt ne peuvent plus tenir leurs positions à effet de levier.",
    magnitude:
      "Le 27 mars 1980, le « Silver Thursday », le cours de l'argent s'effondre de moitié en une journée. Les Hunt subissent des appels de marge gigantesques et frôlent l'entraînement de leurs courtiers dans leur chute.",
    unfolding:
      "Un prêt bancaire de sauvetage évite une crise systémique. Les Hunt sont ruinés et, plus tard, condamnés pour manipulation de marché.",
    aftermath:
      "L'épisode est resté l'exemple emblématique d'un « corner » raté sur une matière première, et de la façon dont le levier transforme une conviction en catastrophe.",
    lesson:
      "Vouloir accaparer un marché avec un levier massif, c'est devenir prisonnier de ses propres positions : il suffit d'un changement de règles ou d'un appel de marge pour que tout s'effondre.",
    keyFigures: [
      { label: "Argent", value: "≈ 6 → 50 $/once → ×0,5" },
      { label: "Protagonistes", value: "Frères Hunt" },
      { label: "Date", value: "27 mars 1980" },
    ],
  },
  {
    slug: "second-choc-petrolier-1979",
    name: "Le second choc pétrolier",
    english: "1979 Oil Shock",
    era: "xxe",
    year: "1979-1980",
    region: "International",
    illu: "commodity",
    drawdownLabel: "Pétrole ×2 + stagflation",
    severity: "Majeure",
    summary: "Le doublement du prix du pétrole après la révolution iranienne, qui prolonge la stagflation des années 1970.",
    context:
      "Après le premier choc de 1973, l'économie mondiale reste dépendante du pétrole. En 1979, la révolution iranienne désorganise la production d'un grand exportateur, ravivant la peur de la pénurie.",
    trigger:
      "La chute du Shah et les troubles en Iran, puis la guerre Iran-Irak, réduisent l'offre. Le prix du baril double quasiment en un an.",
    magnitude:
      "L'inflation repart de plus belle dans les pays importateurs, la croissance cale : c'est l'apogée de la « stagflation ». Pour la briser, la Fed de Paul Volcker pousse ses taux à des niveaux extrêmes.",
    unfolding:
      "La récession Volcker du début des années 1980 finit par casser l'inflation, mais au prix d'un chômage élevé. Les économies développées accélèrent leurs efforts d'efficacité énergétique.",
    aftermath:
      "Le second choc pétrolier a confirmé le rôle central de l'énergie dans les cycles macro et accéléré la diversification des sources d'approvisionnement.",
    lesson:
      "Une économie dépendante d'une ressource importée est à la merci de la géopolitique. Un choc d'offre peut nourrir une inflation tenace, que seuls des taux douloureux parviennent parfois à juguler.",
    keyFigures: [
      { label: "Déclencheur", value: "Révolution iranienne" },
      { label: "Pétrole", value: "≈ ×2 en un an" },
      { label: "Conséquence", value: "Stagflation aggravée" },
    ],
  },
  {
    slug: "crise-turque-2001",
    name: "La crise bancaire turque de 2001",
    english: "Turkish Banking Crisis 2001",
    era: "xxie",
    year: "2001",
    region: "Turquie",
    illu: "exchange-rate",
    drawdownLabel: "Lire ≈ −50 %",
    severity: "Sévère",
    summary: "L'effondrement de la lire et du système bancaire turc, sur fond de dette publique et de fragilité bancaire.",
    context:
      "À la fin des années 1990, la Turquie cumule une inflation élevée, une dette publique lourde et des banques fragiles, dont beaucoup financent l'État. Un programme de stabilisation arrimant la lire est mis en place, mais reste vulnérable.",
    trigger:
      "Début 2001, une crise politique et la perte de confiance déclenchent une fuite massive des capitaux. Le régime de change ancré ne tient pas.",
    magnitude:
      "La lire est laissée flotter et s'effondre de moitié ; les taux courts explosent. De nombreuses banques font faillite et sont reprises ou recapitalisées par l'État.",
    unfolding:
      "Sous l'égide du FMI, la Turquie restructure profondément son secteur bancaire et assainit ses finances publiques, jetant les bases d'une décennie de croissance plus stable.",
    aftermath:
      "La crise de 2001 a façonné le système bancaire turc moderne et reste un cas d'étude sur les dangers d'un ancrage de change adossé à des banques fragiles.",
    lesson:
      "Un taux de change fixe ne tient que si les banques et les finances publiques sont solides. Quand l'État dépend de banques fragiles qui dépendent de lui, le risque devient circulaire et explosif.",
    keyFigures: [
      { label: "Lire", value: "≈ −50 %" },
      { label: "Année", value: "2001" },
      { label: "Issue", value: "Réforme bancaire (FMI)" },
    ],
  },
  {
    slug: "scandale-worldcom-2002",
    name: "L'effondrement de WorldCom",
    english: "WorldCom Scandal",
    era: "xxie",
    year: "2002",
    region: "États-Unis",
    illu: "credit-spread",
    drawdownLabel: "≈ 107 Mds $ d'actifs",
    severity: "Majeure",
    summary: "La plus grande faillite américaine de l'époque, née d'une fraude comptable de plusieurs milliards.",
    context:
      "WorldCom, géant des télécoms né d'une vague d'acquisitions, voyait sa rentabilité s'éroder avec l'éclatement de la bulle Internet. Pour masquer la dégradation, sa direction maquille ses comptes.",
    trigger:
      "En 2002, un audit interne révèle que l'entreprise a comptabilisé des milliards de dépenses courantes en investissements, gonflant artificiellement ses bénéfices.",
    magnitude:
      "La fraude, chiffrée à plus de 11 milliards de dollars, précipite WorldCom dans la faillite — alors la plus grande de l'histoire des États-Unis, avec environ 107 milliards d'actifs.",
    unfolding:
      "Le scandale, survenu juste après Enron, achève d'ébranler la confiance dans les comptes des entreprises et accélère l'adoption de la loi Sarbanes-Oxley.",
    aftermath:
      "WorldCom est devenu, avec Enron, le symbole des dérives comptables du début des années 2000 et du besoin de contrôles renforcés.",
    lesson:
      "Une croissance bâtie sur les acquisitions et la dette peut masquer une rentabilité en berne — jusqu'à la tentation de la fraude. Des comptes incompréhensibles sont un signal d'alerte, pas un détail technique.",
    keyFigures: [
      { label: "Fraude", value: "> 11 Mds $" },
      { label: "Actifs", value: "≈ 107 Mds $" },
      { label: "Année", value: "2002" },
    ],
  },
  {
    slug: "faillite-ftx-2022",
    name: "L'effondrement de FTX",
    english: "FTX Collapse",
    era: "xxie",
    year: "2022",
    region: "Marchés crypto",
    illu: "blockchain",
    drawdownLabel: "≈ 8 Mds $ manquants",
    severity: "Sévère",
    summary: "La chute éclair d'une des plus grandes plateformes crypto, sur fond de détournement de fonds clients.",
    context:
      "FTX, dirigée par Sam Bankman-Fried, était l'une des plus grandes plateformes d'échange de cryptomonnaies, valorisée des dizaines de milliards. Elle était liée à un fonds, Alameda Research, du même fondateur.",
    trigger:
      "En novembre 2022, des révélations sur les liens entre FTX et Alameda déclenchent une vague de retraits. La plateforme se révèle incapable d'honorer les demandes : les fonds des clients avaient été utilisés ailleurs.",
    magnitude:
      "FTX s'effondre en quelques jours, avec un trou estimé à plusieurs milliards de dollars. La contagion frappe tout l'écosystème crypto, déjà fragilisé par l'année 2022.",
    unfolding:
      "FTX fait faillite, son fondateur est arrêté puis condamné pour fraude. L'affaire relance le débat sur la régulation et la conservation des actifs des clients.",
    aftermath:
      "FTX est devenu le symbole des risques de contrepartie dans la crypto : confier ses actifs à une plateforme non régulée, c'est s'exposer à sa défaillance ou à sa malhonnêteté.",
    lesson:
      "« Not your keys, not your coins » : déposer ses actifs sur une plateforme, c'est lui faire crédit. Sans séparation stricte et contrôlée des fonds clients, la confiance peut s'évaporer en un week-end.",
    keyFigures: [
      { label: "Trou estimé", value: "≈ 8 Mds $" },
      { label: "Dirigeant", value: "Condamné pour fraude" },
      { label: "Année", value: "2022" },
    ],
  },
  {
    slug: "silicon-valley-bank-2023",
    name: "La chute de Silicon Valley Bank",
    english: "Silicon Valley Bank Collapse",
    era: "xxie",
    year: "2023",
    region: "États-Unis",
    illu: "margin-call",
    drawdownLabel: "Ruée numérique",
    severity: "Majeure",
    summary: "La faillite éclair d'une grande banque américaine, première ruée bancaire de l'ère numérique.",
    context:
      "Silicon Valley Bank (SVB), banque des start-up technologiques, avait massivement placé les dépôts de ses clients en obligations d'État à long terme. La forte remontée des taux en 2022-2023 a fait chuter la valeur de ce portefeuille.",
    trigger:
      "En mars 2023, SVB annonce une perte sur la vente d'obligations et un besoin de capital. La nouvelle se propage instantanément sur les réseaux et messageries : les clients retirent des dizaines de milliards en quelques heures.",
    magnitude:
      "La ruée, amplifiée par la rapidité des virements numériques, vide la banque en deux jours. SVB est fermée par les autorités — l'une des plus grandes faillites bancaires américaines.",
    unfolding:
      "Les autorités garantissent les dépôts pour éviter la contagion, mais la panique gagne d'autres banques régionales et, en Europe, précipite la chute de Credit Suisse.",
    aftermath:
      "SVB a montré qu'une ruée bancaire peut désormais se produire en quelques heures, à l'ère des applications et des réseaux sociaux. Elle a relancé le débat sur la gestion du risque de taux des banques.",
    lesson:
      "Placer des dépôts à vue dans des obligations longues expose une banque à un risque de taux mortel si les clients retirent. À l'ère numérique, la confiance peut s'effondrer plus vite que jamais.",
    keyFigures: [
      { label: "Vitesse", value: "Ruée en ~2 jours" },
      { label: "Cause", value: "Risque de taux" },
      { label: "Contagion", value: "Credit Suisse" },
    ],
  },
];
