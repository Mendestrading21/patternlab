/**
 * Bibliothèque des figures chartistes — données 100% éducatives (voix WMB).
 * Aucune recommandation : on décrit ce que les analystes observent, jamais
 * « achetez / vendez ». Les niveaux entrée/stop/objectif sont la lecture
 * pédagogique classique du schéma, pas un signal.
 */
import type { ChartSpec } from "@/components/PatternChart";

export type PatternCategory =
  | "retournement-haussier"
  | "retournement-baissier"
  | "continuation-haussiere"
  | "continuation-baissiere"
  | "bilateral";

export type Reliability = "Élevée" | "Moyenne" | "Variable";

export type ChartPattern = {
  slug: string;
  name: string;
  english: string;
  category: PatternCategory;
  /** Sens généralement associé à la figure. */
  bias: "Haussier" | "Baissier" | "Neutre";
  reliability: Reliability;
  /** Résumé court affiché sur la carte. */
  summary: string;
  /** Description longue. */
  description: string;
  /** Lecture pédagogique : ce que les analystes repèrent. */
  reading: { signal: string; entry: string; stop: string; target: string };
  /** Cadre conditionnel WMB. */
  scenario: { si: string; alors: string; sinon: string };
  spec: ChartSpec;
};

export const CATEGORY_LABELS: Record<PatternCategory, { label: string; color: string }> = {
  "retournement-haussier": { label: "Retournement haussier", color: "#2E7D5B" },
  "retournement-baissier": { label: "Retournement baissier", color: "#B0413E" },
  "continuation-haussiere": { label: "Continuation haussière", color: "#2E7D5B" },
  "continuation-baissiere": { label: "Continuation baissière", color: "#B0413E" },
  bilateral: { label: "Bilatéral", color: "#C8A962" },
};

export const CHART_PATTERNS: ChartPattern[] = [
  // ─────────────── RETOURNEMENT HAUSSIER ───────────────
  {
    slug: "double-creux",
    name: "Double Creux",
    english: "Double Bottom",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Élevée",
    summary: "Deux creux au même niveau en forme de « W » : signe d'épuisement vendeur.",
    description:
      "Le double creux se forme après une tendance baissière, lorsque le prix teste deux fois un même plancher sans parvenir à le casser. Le sommet intermédiaire entre les deux creux définit la « ligne de cou ». La figure traduit un essoufflement des vendeurs et un retour progressif des acheteurs.",
    reading: {
      signal: "Confirmation à la clôture au-dessus de la ligne de cou, idéalement avec un volume en hausse.",
      entry: "Au franchissement de la ligne de cou.",
      stop: "Sous le plus bas des deux creux.",
      target: "Hauteur de la figure (cou − creux) reportée au-dessus du cou.",
    },
    scenario: {
      si: "Le prix clôture franchement au-dessus de la ligne de cou avec du volume",
      alors: "la figure est considérée comme validée et l'objectif théorique est la hauteur du W reportée",
      sinon: "tant que le cou n'est pas cassé, la figure reste un simple range et peut échouer.",
    },
    spec: {
      bias: "bull",
      closes: [78, 70, 60, 50, 42, 40, 48, 56, 60, 54, 46, 41, 44, 54, 64, 74],
      lines: [{ x1: 0.33, y1: 60, x2: 0.86, y2: 60, dash: true }],
      levels: [
        { y: 60, kind: "entry" },
        { y: 40, kind: "stop" },
        { y: 80, kind: "target" },
      ],
    },
  },
  {
    slug: "tete-epaules-inversee",
    name: "Tête-Épaules Inversée",
    english: "Inverse Head & Shoulders",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Élevée",
    summary: "Trois creux — le central plus bas — annonçant un retournement à la hausse.",
    description:
      "Version inversée de la tête-épaules. Trois creux se succèdent : deux épaules de part et d'autre d'une tête plus profonde. La ligne de cou relie les deux sommets intermédiaires. C'est l'une des figures de retournement les plus suivies par les analystes techniques.",
    reading: {
      signal: "Cassure de la ligne de cou après la formation de l'épaule droite.",
      entry: "Au franchissement de la ligne de cou.",
      stop: "Sous l'épaule droite.",
      target: "Distance tête → cou reportée au-dessus du cou.",
    },
    scenario: {
      si: "L'épaule droite se forme plus haut que la tête puis le cou est cassé",
      alors: "le retournement haussier est considéré comme confirmé",
      sinon: "une cassure sans volume ou un retour sous le cou invalide souvent la lecture.",
    },
    spec: {
      bias: "bull",
      closes: [70, 60, 52, 58, 50, 38, 30, 40, 52, 46, 40, 48, 58, 62, 70, 78],
      lines: [{ x1: 0.18, y1: 58, x2: 0.8, y2: 58, dash: true }],
      levels: [
        { y: 58, kind: "entry" },
        { y: 30, kind: "stop" },
        { y: 84, kind: "target" },
      ],
    },
  },
  {
    slug: "biseau-descendant",
    name: "Biseau Descendant",
    english: "Falling Wedge",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Canal incliné à la baisse qui se resserre : souvent un retournement haussier.",
    description:
      "Le biseau descendant est délimité par deux droites baissières convergentes. Les sommets et les creux baissent, mais les vendeurs perdent de la vigueur (les bornes se resserrent). Le franchissement de la borne haute est généralement interprété comme un signal de retournement haussier.",
    reading: {
      signal: "Cassure de la oblique haute du biseau.",
      entry: "À la sortie par le haut du biseau.",
      stop: "Sous le dernier creux du biseau.",
      target: "Vers le point de départ du biseau.",
    },
    scenario: {
      si: "Le prix sort par la borne haute du biseau qui se resserre",
      alors: "un mouvement haussier de retour vers le haut du biseau est anticipé",
      sinon: "une continuation sous la borne basse annule la lecture haussière.",
    },
    spec: {
      bias: "bull",
      closes: [80, 72, 76, 66, 70, 60, 64, 56, 60, 54, 57, 62, 70, 76, 82, 86],
      lines: [
        { x1: 0, y1: 82, x2: 0.7, y2: 60, dash: false },
        { x1: 0, y1: 70, x2: 0.7, y2: 52, dash: false },
      ],
      levels: [
        { y: 64, kind: "entry" },
        { y: 52, kind: "stop" },
        { y: 84, kind: "target" },
      ],
    },
  },
  {
    slug: "tasse-avec-anse",
    name: "Tasse avec Anse",
    english: "Cup & Handle",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Un arrondi en forme de tasse suivi d'une petite consolidation (l'anse).",
    description:
      "Popularisée par William O'Neil, la tasse avec anse combine un fond arrondi (la tasse) et une brève respiration baissière (l'anse) avant la reprise. C'est une figure de continuation/retournement haussière qui exige de la patience : la tasse peut se former sur plusieurs semaines.",
    reading: {
      signal: "Cassure de la résistance (bord de la tasse) après l'anse.",
      entry: "À la sortie de l'anse, au-dessus du bord de la tasse.",
      stop: "Sous le point bas de l'anse.",
      target: "Profondeur de la tasse reportée au-dessus du bord.",
    },
    scenario: {
      si: "Le prix casse le bord de la tasse après une anse peu profonde",
      alors: "la profondeur de la tasse donne l'objectif théorique",
      sinon: "une anse trop profonde (qui efface la moitié de la tasse) fragilise la figure.",
    },
    spec: {
      bias: "bull",
      closes: [72, 66, 56, 48, 44, 44, 48, 56, 64, 70, 71, 66, 63, 68, 74, 80],
      lines: [{ x1: 0, y1: 72, x2: 0.95, y2: 72, dash: true }],
      levels: [
        { y: 72, kind: "entry" },
        { y: 62, kind: "stop" },
        { y: 84, kind: "target" },
      ],
    },
  },
  {
    slug: "arrondi-de-fond",
    name: "Arrondi de Fond",
    english: "Rounding Bottom",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Un creux en forme de « U » : transition lente et régulière vers la hausse.",
    description:
      "L'arrondi de fond traduit un changement progressif du rapport de force, sans cassure brutale. Le prix décélère sa baisse, forme un plancher arrondi, puis accélère doucement à la hausse. Figure lente, souvent jugée fiable car elle reflète une vraie évolution du sentiment.",
    reading: {
      signal: "Retour au-dessus du niveau de départ de l'arrondi.",
      entry: "Au franchissement de la résistance horizontale.",
      stop: "Sous le creux de l'arrondi.",
      target: "Profondeur de l'arrondi reportée au-dessus.",
    },
    scenario: {
      si: "Le prix remonte au-dessus de la résistance qui plafonnait l'arrondi",
      alors: "la dynamique haussière progressive est considérée comme confirmée",
      sinon: "un échec sous la résistance prolonge la phase de transition.",
    },
    spec: {
      bias: "bull",
      closes: [74, 66, 58, 50, 44, 40, 39, 41, 46, 52, 60, 66, 72, 74, 78, 82],
      lines: [{ x1: 0, y1: 74, x2: 0.86, y2: 74, dash: true }],
      levels: [
        { y: 74, kind: "entry" },
        { y: 39, kind: "stop" },
        { y: 88, kind: "target" },
      ],
    },
  },

  // ─────────────── RETOURNEMENT BAISSIER ───────────────
  {
    slug: "double-sommet",
    name: "Double Sommet",
    english: "Double Top",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Élevée",
    summary: "Deux sommets au même niveau en forme de « M » : essoufflement acheteur.",
    description:
      "Image miroir du double creux. Le prix échoue deux fois à franchir une même résistance, dessinant un « M ». Le creux intermédiaire définit la ligne de cou. La figure signale que les acheteurs ne parviennent plus à imposer de nouveaux sommets.",
    reading: {
      signal: "Clôture sous la ligne de cou, idéalement avec volume.",
      entry: "À la cassure de la ligne de cou par le bas.",
      stop: "Au-dessus du plus haut des deux sommets.",
      target: "Hauteur de la figure reportée sous le cou.",
    },
    scenario: {
      si: "Le prix casse la ligne de cou sous le creux intermédiaire",
      alors: "la figure de retournement baissier est considérée comme validée",
      sinon: "tant que le cou tient, le double sommet reste un range non confirmé.",
    },
    spec: {
      bias: "bear",
      closes: [30, 40, 50, 58, 60, 52, 46, 52, 58, 60, 54, 48, 44, 38, 32, 26],
      lines: [{ x1: 0.33, y1: 46, x2: 0.86, y2: 46, dash: true }],
      levels: [
        { y: 46, kind: "entry" },
        { y: 62, kind: "stop" },
        { y: 28, kind: "target" },
      ],
    },
  },
  {
    slug: "tete-epaules",
    name: "Tête-Épaules",
    english: "Head & Shoulders",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Élevée",
    summary: "Trois sommets — le central plus haut — figure de retournement la plus connue.",
    description:
      "La tête-épaules est la figure de retournement baissier de référence. Deux épaules encadrent une tête plus haute ; la ligne de cou relie les deux creux intermédiaires. Sa cassure est souvent suivie avec attention car la figure est très documentée.",
    reading: {
      signal: "Cassure de la ligne de cou après l'épaule droite.",
      entry: "À la cassure de la ligne de cou.",
      stop: "Au-dessus de l'épaule droite.",
      target: "Distance tête → cou reportée sous le cou.",
    },
    scenario: {
      si: "L'épaule droite se forme plus bas que la tête puis le cou casse",
      alors: "le retournement baissier est considéré comme confirmé",
      sinon: "un faux signal (retour au-dessus du cou) est fréquent sans volume.",
    },
    spec: {
      bias: "bear",
      closes: [30, 40, 48, 42, 50, 62, 70, 60, 48, 54, 60, 52, 42, 38, 30, 24],
      lines: [{ x1: 0.18, y1: 42, x2: 0.8, y2: 42, dash: true }],
      levels: [
        { y: 42, kind: "entry" },
        { y: 70, kind: "stop" },
        { y: 16, kind: "target" },
      ],
    },
  },
  {
    slug: "biseau-ascendant",
    name: "Biseau Ascendant",
    english: "Rising Wedge",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Canal incliné à la hausse qui se resserre : souvent un essoufflement.",
    description:
      "Le biseau ascendant est formé de deux droites haussières convergentes. Les prix montent, mais de moins en moins fort : la hausse perd de l'élan. La cassure de la borne basse est généralement interprétée comme un signal de retournement baissier.",
    reading: {
      signal: "Cassure de la oblique basse du biseau.",
      entry: "À la sortie par le bas du biseau.",
      stop: "Au-dessus du dernier sommet du biseau.",
      target: "Vers le point de départ du biseau.",
    },
    scenario: {
      si: "Le prix sort par la borne basse du biseau qui se resserre",
      alors: "un repli vers la base du biseau est anticipé",
      sinon: "une poursuite au-dessus de la borne haute annule la lecture baissière.",
    },
    spec: {
      bias: "bear",
      closes: [20, 28, 24, 34, 30, 40, 36, 44, 40, 46, 43, 38, 30, 24, 18, 14],
      lines: [
        { x1: 0, y1: 20, x2: 0.7, y2: 44, dash: false },
        { x1: 0, y1: 30, x2: 0.7, y2: 50, dash: false },
      ],
      levels: [
        { y: 40, kind: "entry" },
        { y: 50, kind: "stop" },
        { y: 18, kind: "target" },
      ],
    },
  },
  {
    slug: "arrondi-de-sommet",
    name: "Arrondi de Sommet",
    english: "Rounding Top",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Un sommet en forme de dôme : retournement baissier lent et régulier.",
    description:
      "Image miroir de l'arrondi de fond. Le prix décélère sa hausse, forme un dôme, puis glisse progressivement à la baisse. Figure lente qui reflète une érosion graduelle de la demande plutôt qu'un choc brutal.",
    reading: {
      signal: "Retour sous le niveau de départ du dôme.",
      entry: "À la cassure du support horizontal.",
      stop: "Au-dessus du sommet du dôme.",
      target: "Hauteur du dôme reportée sous le support.",
    },
    scenario: {
      si: "Le prix repasse sous le support qui soutenait le dôme",
      alors: "la dynamique baissière progressive est considérée comme confirmée",
      sinon: "un rebond sur le support prolonge la phase de distribution.",
    },
    spec: {
      bias: "bear",
      closes: [26, 34, 42, 50, 56, 60, 61, 59, 54, 48, 40, 34, 28, 26, 22, 18],
      lines: [{ x1: 0, y1: 26, x2: 0.86, y2: 26, dash: true }],
      levels: [
        { y: 26, kind: "entry" },
        { y: 61, kind: "stop" },
        { y: 12, kind: "target" },
      ],
    },
  },

  // ─────────────── CONTINUATION HAUSSIÈRE ───────────────
  {
    slug: "drapeau-haussier",
    name: "Drapeau Haussier",
    english: "Bull Flag",
    category: "continuation-haussiere",
    bias: "Haussier",
    reliability: "Élevée",
    summary: "Forte hausse (le mât) puis brève consolidation oblique : pause avant suite.",
    description:
      "Le drapeau haussier suit une impulsion verticale (le « mât »). Le prix consolide ensuite dans un petit canal légèrement incliné à la baisse, le temps de digérer les gains, avant de reprendre dans le sens du mât. Figure de continuation très courante en tendance.",
    reading: {
      signal: "Cassure de la borne haute du drapeau.",
      entry: "À la sortie par le haut du canal de consolidation.",
      stop: "Sous la borne basse du drapeau.",
      target: "Hauteur du mât reportée depuis la cassure.",
    },
    scenario: {
      si: "Le prix sort par le haut du drapeau après une forte impulsion",
      alors: "la hauteur du mât donne l'objectif de continuation théorique",
      sinon: "une consolidation qui efface tout le mât invalide la figure.",
    },
    spec: {
      bias: "bull",
      closes: [30, 36, 46, 58, 68, 66, 62, 64, 60, 62, 58, 64, 72, 80, 86, 90],
      lines: [
        { x1: 0.3, y1: 70, x2: 0.66, y2: 62, dash: false },
        { x1: 0.3, y1: 62, x2: 0.66, y2: 54, dash: false },
      ],
      levels: [
        { y: 66, kind: "entry" },
        { y: 56, kind: "stop" },
        { y: 90, kind: "target" },
      ],
    },
  },
  {
    slug: "fanion-haussier",
    name: "Fanion Haussier",
    english: "Bull Pennant",
    category: "continuation-haussiere",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Comme le drapeau, mais la consolidation forme un petit triangle qui se resserre.",
    description:
      "Le fanion haussier ressemble au drapeau, mais la consolidation prend la forme d'un petit triangle symétrique qui se contracte. Il suit une impulsion forte et traduit une pause d'équilibre avant la reprise dans le sens de la tendance.",
    reading: {
      signal: "Cassure de la pointe du fanion par le haut.",
      entry: "À la sortie haussière du triangle de consolidation.",
      stop: "Sous le bas du fanion.",
      target: "Hauteur du mât reportée depuis la cassure.",
    },
    scenario: {
      si: "Le prix sort du fanion par le haut après une impulsion verticale",
      alors: "la continuation vise la projection de la hauteur du mât",
      sinon: "une sortie par le bas remet en cause la dynamique haussière.",
    },
    spec: {
      bias: "bull",
      closes: [28, 34, 44, 56, 66, 62, 58, 61, 59, 60, 60, 63, 70, 78, 84, 88],
      lines: [
        { x1: 0.3, y1: 70, x2: 0.66, y2: 61, dash: false },
        { x1: 0.3, y1: 54, x2: 0.66, y2: 59, dash: false },
      ],
      levels: [
        { y: 64, kind: "entry" },
        { y: 54, kind: "stop" },
        { y: 88, kind: "target" },
      ],
    },
  },
  {
    slug: "triangle-ascendant",
    name: "Triangle Ascendant",
    english: "Ascending Triangle",
    category: "continuation-haussiere",
    bias: "Haussier",
    reliability: "Élevée",
    summary: "Résistance plate + creux montants : pression acheteuse qui s'accumule.",
    description:
      "Le triangle ascendant combine une résistance horizontale et une oblique de creux ascendants. Les acheteurs reviennent de plus en plus tôt tandis que la résistance tient : la pression s'accumule sous le plafond. Sa cassure est généralement interprétée dans le sens haussier.",
    reading: {
      signal: "Cassure de la résistance horizontale.",
      entry: "Au franchissement du plafond.",
      stop: "Sous la dernière oblique de creux.",
      target: "Hauteur de la base du triangle reportée au-dessus.",
    },
    scenario: {
      si: "Le prix franchit la résistance horizontale après des creux montants",
      alors: "la hauteur du triangle donne l'objectif théorique",
      sinon: "une cassure de l'oblique basse remet en cause la lecture haussière.",
    },
    spec: {
      bias: "bull",
      closes: [40, 50, 60, 50, 60, 54, 60, 56, 60, 58, 60, 62, 68, 74, 80, 84],
      lines: [
        { x1: 0.12, y1: 60, x2: 0.72, y2: 60, dash: false },
        { x1: 0.12, y1: 40, x2: 0.72, y2: 58, dash: false },
      ],
      levels: [
        { y: 60, kind: "entry" },
        { y: 50, kind: "stop" },
        { y: 80, kind: "target" },
      ],
    },
  },
  {
    slug: "rectangle-haussier",
    name: "Rectangle Haussier",
    english: "Bullish Rectangle",
    category: "continuation-haussiere",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Consolidation horizontale en tendance haussière entre support et résistance.",
    description:
      "Le rectangle haussier est une pause horizontale au sein d'une tendance haussière : le prix oscille entre un support et une résistance parallèles. La sortie se fait le plus souvent dans le sens de la tendance préexistante, soit vers le haut.",
    reading: {
      signal: "Cassure de la résistance supérieure.",
      entry: "Au franchissement du haut du rectangle.",
      stop: "Sous le support du rectangle.",
      target: "Hauteur du rectangle reportée au-dessus.",
    },
    scenario: {
      si: "Le prix sort du rectangle par le haut après une tendance haussière",
      alors: "la hauteur du rectangle donne l'objectif de continuation",
      sinon: "une cassure du support inverse la lecture.",
    },
    spec: {
      bias: "bull",
      closes: [34, 42, 52, 62, 60, 50, 60, 50, 60, 51, 60, 52, 62, 70, 78, 84],
      lines: [
        { x1: 0.22, y1: 61, x2: 0.7, y2: 61, dash: false },
        { x1: 0.22, y1: 49, x2: 0.7, y2: 49, dash: false },
      ],
      levels: [
        { y: 61, kind: "entry" },
        { y: 49, kind: "stop" },
        { y: 80, kind: "target" },
      ],
    },
  },

  // ─────────────── CONTINUATION BAISSIÈRE ───────────────
  {
    slug: "drapeau-baissier",
    name: "Drapeau Baissier",
    english: "Bear Flag",
    category: "continuation-baissiere",
    bias: "Baissier",
    reliability: "Élevée",
    summary: "Forte baisse (le mât) puis rebond oblique bref : pause avant la suite baissière.",
    description:
      "Miroir du drapeau haussier. Après une chute verticale (le mât), le prix rebondit dans un petit canal légèrement haussier, le temps de souffler, avant de reprendre sa baisse. Figure de continuation baissière fréquente en marché vendeur.",
    reading: {
      signal: "Cassure de la borne basse du drapeau.",
      entry: "À la sortie par le bas du canal de rebond.",
      stop: "Au-dessus de la borne haute du drapeau.",
      target: "Hauteur du mât reportée depuis la cassure.",
    },
    scenario: {
      si: "Le prix sort par le bas du drapeau après une forte chute",
      alors: "la hauteur du mât donne l'objectif baissier théorique",
      sinon: "un rebond qui efface tout le mât invalide la figure.",
    },
    spec: {
      bias: "bear",
      closes: [70, 64, 54, 42, 32, 34, 38, 36, 40, 38, 42, 36, 28, 20, 14, 10],
      lines: [
        { x1: 0.3, y1: 30, x2: 0.66, y2: 38, dash: false },
        { x1: 0.3, y1: 38, x2: 0.66, y2: 46, dash: false },
      ],
      levels: [
        { y: 34, kind: "entry" },
        { y: 44, kind: "stop" },
        { y: 10, kind: "target" },
      ],
    },
  },
  {
    slug: "triangle-descendant",
    name: "Triangle Descendant",
    english: "Descending Triangle",
    category: "continuation-baissiere",
    bias: "Baissier",
    reliability: "Élevée",
    summary: "Support plat + sommets descendants : pression vendeuse qui s'accumule.",
    description:
      "Le triangle descendant combine un support horizontal et une oblique de sommets descendants. Les vendeurs reviennent de plus en plus tôt tandis que le support tient : la pression s'accumule au-dessus du plancher. Sa cassure est généralement lue dans le sens baissier.",
    reading: {
      signal: "Cassure du support horizontal.",
      entry: "À la rupture du plancher.",
      stop: "Au-dessus de la dernière oblique de sommets.",
      target: "Hauteur de la base du triangle reportée sous le support.",
    },
    scenario: {
      si: "Le prix casse le support horizontal après des sommets descendants",
      alors: "la hauteur du triangle donne l'objectif baissier",
      sinon: "une cassure de l'oblique haute remet en cause la lecture baissière.",
    },
    spec: {
      bias: "bear",
      closes: [60, 50, 40, 50, 40, 46, 40, 44, 40, 42, 40, 38, 32, 26, 20, 16],
      lines: [
        { x1: 0.12, y1: 40, x2: 0.72, y2: 40, dash: false },
        { x1: 0.12, y1: 60, x2: 0.72, y2: 42, dash: false },
      ],
      levels: [
        { y: 40, kind: "entry" },
        { y: 50, kind: "stop" },
        { y: 20, kind: "target" },
      ],
    },
  },
  {
    slug: "rectangle-baissier",
    name: "Rectangle Baissier",
    english: "Bearish Rectangle",
    category: "continuation-baissiere",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Consolidation horizontale en tendance baissière entre support et résistance.",
    description:
      "Le rectangle baissier est une respiration horizontale dans une tendance baissière : le prix oscille entre support et résistance parallèles. La sortie se fait le plus souvent dans le sens de la tendance, soit vers le bas.",
    reading: {
      signal: "Cassure du support inférieur.",
      entry: "À la rupture du bas du rectangle.",
      stop: "Au-dessus de la résistance du rectangle.",
      target: "Hauteur du rectangle reportée sous le support.",
    },
    scenario: {
      si: "Le prix sort du rectangle par le bas après une tendance baissière",
      alors: "la hauteur du rectangle donne l'objectif de continuation",
      sinon: "une cassure de la résistance inverse la lecture.",
    },
    spec: {
      bias: "bear",
      closes: [66, 58, 48, 38, 40, 50, 40, 50, 40, 49, 40, 48, 38, 30, 22, 16],
      lines: [
        { x1: 0.22, y1: 50, x2: 0.7, y2: 50, dash: false },
        { x1: 0.22, y1: 39, x2: 0.7, y2: 39, dash: false },
      ],
      levels: [
        { y: 39, kind: "entry" },
        { y: 50, kind: "stop" },
        { y: 18, kind: "target" },
      ],
    },
  },

  // ─────────────── BILATÉRAL ───────────────
  {
    slug: "triangle-symetrique",
    name: "Triangle Symétrique",
    english: "Symmetrical Triangle",
    category: "bilateral",
    bias: "Neutre",
    reliability: "Variable",
    summary: "Sommets descendants et creux montants qui convergent : sortie dans les deux sens.",
    description:
      "Le triangle symétrique se forme quand sommets et creux convergent vers une pointe : l'indécision se réduit. Contrairement aux triangles ascendant/descendant, il n'a pas de biais directionnel marqué — la cassure peut se faire des deux côtés. C'est la direction de la sortie qui donne le sens.",
    reading: {
      signal: "Cassure d'une des deux obliques, dans le sens de la sortie.",
      entry: "Au franchissement de la borne cassée.",
      stop: "De l'autre côté du triangle (oblique opposée).",
      target: "Hauteur de la base du triangle reportée depuis la cassure.",
    },
    scenario: {
      si: "Le prix casse l'une des deux obliques convergentes",
      alors: "le mouvement se développe généralement dans le sens de la cassure, sur la hauteur de la base",
      sinon: "tant que le prix reste dans le triangle, la figure n'envoie aucun signal directionnel.",
    },
    spec: {
      bias: "bull",
      closes: [40, 60, 46, 56, 48, 54, 50, 53, 51, 52, 52, 56, 62, 70, 76, 82],
      lines: [
        { x1: 0.05, y1: 60, x2: 0.68, y2: 53, dash: false },
        { x1: 0.05, y1: 40, x2: 0.68, y2: 51, dash: false },
      ],
      levels: [
        { y: 56, kind: "entry" },
        { y: 46, kind: "stop" },
        { y: 78, kind: "target" },
      ],
    },
  },

  // ─────────────── AJOUTS ───────────────
  {
    slug: "triple-creux",
    name: "Triple Creux",
    english: "Triple Bottom",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Élevée",
    summary: "Trois creux au même niveau : support qui tient trois fois, signe d'épuisement vendeur.",
    description:
      "Le triple creux prolonge la logique du double creux : le prix teste trois fois un même plancher sans le casser. Plus le support est testé sans céder, plus il est considéré comme solide. La ligne de cou relie les sommets intermédiaires et sa cassure valide la figure.",
    reading: {
      signal: "Cassure de la ligne de cou après le troisième creux.",
      entry: "Au franchissement de la ligne de cou.",
      stop: "Sous le niveau des trois creux.",
      target: "Hauteur de la figure reportée au-dessus du cou.",
    },
    scenario: {
      si: "Le prix franchit la ligne de cou après avoir tenu trois fois le même plancher",
      alors: "le retournement haussier est jugé d'autant plus crédible que le support a résisté",
      sinon: "une quatrième baisse qui casse le plancher annule la figure.",
    },
    spec: {
      bias: "bull",
      closes: [78, 68, 58, 49, 47, 53, 58, 53, 47, 53, 58, 52, 48, 56, 66, 76],
      lines: [{ x1: 0.18, y1: 58, x2: 0.86, y2: 58, dash: true }],
      levels: [
        { y: 58, kind: "entry" },
        { y: 47, kind: "stop" },
        { y: 70, kind: "target" },
      ],
    },
  },
  {
    slug: "triple-sommet",
    name: "Triple Sommet",
    english: "Triple Top",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Élevée",
    summary: "Trois sommets au même niveau : résistance qui plafonne trois fois.",
    description:
      "Image miroir du triple creux. Le prix bute trois fois sur une même résistance sans la franchir, signe d'un essoufflement acheteur marqué. La cassure de la ligne de cou (reliant les creux intermédiaires) valide le retournement baissier.",
    reading: {
      signal: "Cassure de la ligne de cou après le troisième sommet.",
      entry: "À la cassure de la ligne de cou par le bas.",
      stop: "Au-dessus du niveau des trois sommets.",
      target: "Hauteur de la figure reportée sous le cou.",
    },
    scenario: {
      si: "Le prix casse la ligne de cou après avoir échoué trois fois sur la même résistance",
      alors: "le retournement baissier gagne en crédibilité",
      sinon: "un franchissement de la résistance au quatrième essai invalide la figure.",
    },
    spec: {
      bias: "bear",
      closes: [22, 32, 42, 51, 53, 47, 42, 47, 53, 47, 42, 48, 52, 44, 34, 24],
      lines: [{ x1: 0.18, y1: 42, x2: 0.86, y2: 42, dash: true }],
      levels: [
        { y: 42, kind: "entry" },
        { y: 53, kind: "stop" },
        { y: 30, kind: "target" },
      ],
    },
  },
  {
    slug: "elargissement",
    name: "Élargissement",
    english: "Broadening Formation",
    category: "bilateral",
    bias: "Neutre",
    reliability: "Variable",
    summary: "Sommets plus hauts et creux plus bas : volatilité qui s'amplifie (mégaphone).",
    description:
      "L'élargissement, ou mégaphone, est l'inverse du triangle : les bornes divergent au lieu de converger. Sommets de plus en plus hauts et creux de plus en plus bas traduisent une volatilité croissante et une indécision agitée. Figure délicate à trader, souvent annonciatrice de phases instables.",
    reading: {
      signal: "Cassure nette de l'une des deux bornes divergentes.",
      entry: "À la sortie franche du mégaphone.",
      stop: "De l'autre côté de la dernière oscillation.",
      target: "Variable : la figure manque de projection fiable.",
    },
    scenario: {
      si: "Le prix sort enfin du mégaphone après des oscillations de plus en plus larges",
      alors: "un mouvement directionnel peut s'amorcer dans le sens de la cassure",
      sinon: "tant que les bornes s'écartent, la volatilité reste le principal risque.",
    },
    spec: {
      bias: "bear",
      closes: [50, 56, 46, 60, 42, 64, 38, 66, 36, 62, 40, 52, 44, 34, 28, 22],
      lines: [
        { x1: 0.02, y1: 54, x2: 0.5, y2: 67, dash: false },
        { x1: 0.02, y1: 47, x2: 0.5, y2: 35, dash: false },
      ],
      levels: [
        { y: 38, kind: "entry" },
        { y: 66, kind: "stop" },
        { y: 22, kind: "target" },
      ],
    },
  },
  {
    slug: "diamant",
    name: "Diamant",
    english: "Diamond Top",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Élargissement puis resserrement en losange, au sommet d'une hausse : retournement.",
    description:
      "Le diamant combine une phase d'élargissement (mégaphone) suivie d'une phase de resserrement (triangle), dessinant un losange. Au sommet d'une hausse, il signale une distribution agitée puis une perte de momentum. Figure rare mais réputée pour annoncer des retournements.",
    reading: {
      signal: "Cassure de la borne basse du diamant.",
      entry: "À la sortie par le bas du losange.",
      stop: "Au-dessus du sommet du diamant.",
      target: "Hauteur maximale du diamant reportée sous la cassure.",
    },
    scenario: {
      si: "Le prix sort par le bas du losange après une hausse",
      alors: "le retournement baissier est considéré comme amorcé",
      sinon: "une sortie par le haut peut au contraire prolonger la hausse.",
    },
    spec: {
      bias: "bear",
      closes: [30, 42, 36, 52, 34, 58, 40, 54, 44, 50, 47, 42, 36, 30, 24, 20],
      lines: [
        { x1: 0.02, y1: 44, x2: 0.32, y2: 58, dash: false },
        { x1: 0.02, y1: 44, x2: 0.32, y2: 34, dash: false },
        { x1: 0.32, y1: 58, x2: 0.64, y2: 47, dash: false },
        { x1: 0.32, y1: 34, x2: 0.64, y2: 47, dash: false },
      ],
      levels: [
        { y: 42, kind: "entry" },
        { y: 58, kind: "stop" },
        { y: 24, kind: "target" },
      ],
    },
  },
  {
    slug: "fanion-baissier",
    name: "Fanion Baissier",
    english: "Bear Pennant",
    category: "continuation-baissiere",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Forte chute (le mât) puis petit triangle de consolidation : pause avant la suite baissière.",
    description:
      "Le fanion baissier suit une chute verticale (le « mât »). Le prix consolide ensuite dans un petit triangle symétrique qui se contracte, le temps d'un rebond technique, avant de repartir à la baisse dans le sens du mât. C'est le pendant baissier du fanion haussier.",
    reading: {
      signal: "Cassure de la pointe du fanion par le bas.",
      entry: "À la sortie baissière du triangle de consolidation.",
      stop: "Au-dessus du haut du fanion.",
      target: "Hauteur du mât reportée sous la cassure.",
    },
    scenario: {
      si: "Le prix sort du fanion par le bas après une impulsion baissière",
      alors: "la continuation vise la projection de la hauteur du mât",
      sinon: "une sortie par le haut remet en cause la dynamique baissière.",
    },
    spec: {
      bias: "bear",
      closes: [72, 66, 56, 44, 34, 38, 42, 39, 41, 40, 40, 37, 30, 22, 16, 12],
      lines: [
        { x1: 0.3, y1: 30, x2: 0.66, y2: 39, dash: false },
        { x1: 0.3, y1: 46, x2: 0.66, y2: 41, dash: false },
      ],
      levels: [
        { y: 36, kind: "entry" },
        { y: 46, kind: "stop" },
        { y: 12, kind: "target" },
      ],
    },
  },
  {
    slug: "canal-haussier",
    name: "Canal Haussier",
    english: "Ascending Channel",
    category: "continuation-haussiere",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Le prix progresse entre deux droites parallèles inclinées vers le haut : tendance ordonnée.",
    description:
      "Le canal haussier se dessine lorsque le prix oscille entre deux obliques parallèles montantes : une ligne de support (bas) et une ligne de résistance (haut). Il traduit une tendance haussière ordonnée. Tant que le prix respecte le canal, la tendance est considérée comme intacte ; une sortie franche signale une accélération ou un essoufflement.",
    reading: {
      signal: "Respect répété des deux bornes ; la cassure d'une borne change la lecture.",
      entry: "Lecture classique : rebonds sur la borne basse du canal.",
      stop: "Sous la borne basse du canal.",
      target: "La borne haute du canal, ou la projection de sa largeur en cas de cassure.",
    },
    scenario: {
      si: "Le prix rebondit sur la borne basse du canal montant",
      alors: "la tendance haussière ordonnée est considérée comme intacte",
      sinon: "une cassure de la borne basse signale un essoufflement de la tendance.",
    },
    spec: {
      bias: "bull",
      closes: [24, 30, 28, 36, 33, 42, 38, 48, 45, 54, 50, 60, 57, 66, 63, 72],
      lines: [
        { x1: 0.02, y1: 22, x2: 0.98, y2: 70, dash: false },
        { x1: 0.02, y1: 34, x2: 0.98, y2: 82, dash: false },
      ],
      levels: [
        { y: 50, kind: "entry" },
        { y: 40, kind: "stop" },
        { y: 72, kind: "target" },
      ],
    },
  },
  {
    slug: "canal-baissier",
    name: "Canal Baissier",
    english: "Descending Channel",
    category: "continuation-baissiere",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Le prix recule entre deux droites parallèles inclinées vers le bas : tendance baissière ordonnée.",
    description:
      "Le canal baissier est le miroir du canal haussier : le prix glisse entre deux obliques parallèles descendantes. Chaque rebond bute sur la borne haute (résistance), chaque repli trouve la borne basse (support). Tant que le canal tient, la tendance baissière est jugée en place ; sa cassure par le haut peut amorcer un retournement.",
    reading: {
      signal: "Respect répété des deux bornes descendantes.",
      entry: "Lecture classique : rejets sous la borne haute du canal.",
      stop: "Au-dessus de la borne haute du canal.",
      target: "La borne basse du canal, ou la projection de sa largeur en cas de cassure.",
    },
    scenario: {
      si: "Le prix est repoussé sous la borne haute du canal descendant",
      alors: "la tendance baissière ordonnée est considérée comme intacte",
      sinon: "une cassure de la borne haute peut amorcer un retournement haussier.",
    },
    spec: {
      bias: "bear",
      closes: [78, 70, 73, 64, 67, 58, 61, 52, 55, 46, 49, 40, 43, 34, 37, 28],
      lines: [
        { x1: 0.02, y1: 80, x2: 0.98, y2: 30, dash: false },
        { x1: 0.02, y1: 68, x2: 0.98, y2: 18, dash: false },
      ],
      levels: [
        { y: 55, kind: "entry" },
        { y: 65, kind: "stop" },
        { y: 28, kind: "target" },
      ],
    },
  },
  {
    slug: "v-creux",
    name: "Creux en V",
    english: "V-Bottom (Spike Bottom)",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Variable",
    summary: "Chute brutale suivie d'un rebond tout aussi vif, en forme de V : retournement express.",
    description:
      "Le creux en V se forme lorsqu'une chute violente s'inverse sans phase de construction : le prix plonge puis rebondit immédiatement avec la même vigueur, dessinant un V. Souvent déclenché par une capitulation puis un choc de nouvelles, il est spectaculaire mais difficile à anticiper — d'où sa fiabilité variable.",
    reading: {
      signal: "Rebond vertical depuis le point bas, sans retest du plancher.",
      entry: "Difficile à saisir : l'absence de consolidation laisse peu de point d'appui.",
      stop: "Sous le pic bas du V.",
      target: "Souvent un retour vers la zone d'avant la chute.",
    },
    scenario: {
      si: "Le prix rebondit verticalement après une capitulation, sans retest",
      alors: "un retournement en V s'est matérialisé (mouvement rapide et puissant)",
      sinon: "un retour tester le point bas transforme la figure en double creux plus lisible.",
    },
    spec: {
      bias: "bull",
      closes: [76, 66, 54, 40, 26, 18, 30, 44, 56, 66, 74, 80, 84, 86, 88, 90],
      lines: [
        { x1: 0.02, y1: 78, x2: 0.34, y2: 18, dash: true },
        { x1: 0.34, y1: 18, x2: 0.98, y2: 90, dash: true },
      ],
      levels: [
        { y: 44, kind: "entry" },
        { y: 18, kind: "stop" },
        { y: 88, kind: "target" },
      ],
    },
  },
  {
    slug: "v-sommet",
    name: "Sommet en V",
    english: "V-Top (Spike Top)",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Variable",
    summary: "Montée parabolique suivie d'une chute aussi brutale, en V inversé : retournement express.",
    description:
      "Le sommet en V (ou pic) est le miroir du creux en V : une hausse parabolique s'achève par un renversement immédiat et violent, sans phase de distribution. Typique des excès d'euphorie (squeeze, blow-off top), il marque un sommet net mais imprévisible, ce qui explique sa fiabilité variable.",
    reading: {
      signal: "Chute verticale depuis le point haut, sans retest du sommet.",
      entry: "Difficile à saisir : pas de consolidation pour s'appuyer.",
      stop: "Au-dessus du pic haut du V inversé.",
      target: "Souvent un retour vers la zone d'avant la montée parabolique.",
    },
    scenario: {
      si: "Le prix chute verticalement après un excès parabolique, sans retest",
      alors: "un retournement en V inversé s'est matérialisé",
      sinon: "un retour tester le sommet transforme la figure en double sommet plus lisible.",
    },
    spec: {
      bias: "bear",
      closes: [24, 34, 46, 60, 74, 82, 70, 56, 44, 34, 26, 20, 16, 14, 12, 10],
      lines: [
        { x1: 0.02, y1: 22, x2: 0.34, y2: 82, dash: true },
        { x1: 0.34, y1: 82, x2: 0.98, y2: 10, dash: true },
      ],
      levels: [
        { y: 56, kind: "entry" },
        { y: 82, kind: "stop" },
        { y: 12, kind: "target" },
      ],
    },
  },
  {
    slug: "ile-retournement-haussier",
    name: "Île de Retournement Haussière",
    english: "Bullish Island Reversal",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Élevée",
    summary: "Un groupe de séances isolé par deux gaps : la baisse s'épuise et le marché bascule.",
    description:
      "L'île de retournement haussière apparaît au creux d'une baisse : un gap baissier (épuisement) isole un petit groupe de séances, puis un gap haussier dans l'autre sens « détache » ce groupe du reste du graphique, comme une île. Les deux fenêtres encadrent un plancher où la pression vendeuse s'est épuisée. Figure rare mais réputée fiable.",
    reading: {
      signal: "Deux gaps de sens opposés isolant un petit groupe de chandelles au plus bas.",
      entry: "Au comblement haussier du second gap.",
      stop: "Sous le plus bas de l'île.",
      target: "Projection de l'ampleur de la baisse précédente.",
    },
    scenario: {
      si: "Un gap haussier vient refermer la zone après un gap baissier d'épuisement",
      alors: "l'île isolée signale un retournement haussier réputé fiable",
      sinon: "sans le second gap, il ne s'agit que d'un simple plancher à confirmer.",
    },
    spec: {
      bias: "bull",
      closes: [70, 60, 48, 36, 22, 24, 21, 23, 38, 50, 62, 70, 76, 82, 86, 90],
      lines: [
        { x1: 0.28, y1: 36, x2: 0.28, y2: 24, dash: true },
        { x1: 0.5, y1: 23, x2: 0.5, y2: 38, dash: true },
      ],
      levels: [
        { y: 44, kind: "entry" },
        { y: 21, kind: "stop" },
        { y: 88, kind: "target" },
      ],
    },
  },
  {
    slug: "ile-retournement-baissier",
    name: "Île de Retournement Baissière",
    english: "Bearish Island Reversal",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Élevée",
    summary: "Un groupe de séances isolé par deux gaps au sommet : la hausse s'épuise et le marché bascule.",
    description:
      "L'île de retournement baissière se forme au sommet d'une hausse : un gap haussier d'épuisement isole un groupe de séances en hauteur, puis un gap baissier « détache » ce groupe vers le bas, formant une île au plafond. Les deux fenêtres encadrent un sommet où l'euphorie s'est tarie. C'est le miroir de l'île haussière.",
    reading: {
      signal: "Deux gaps de sens opposés isolant un petit groupe de chandelles au plus haut.",
      entry: "Au comblement baissier du second gap.",
      stop: "Au-dessus du plus haut de l'île.",
      target: "Projection de l'ampleur de la hausse précédente.",
    },
    scenario: {
      si: "Un gap baissier vient refermer la zone après un gap haussier d'épuisement",
      alors: "l'île isolée signale un retournement baissier réputé fiable",
      sinon: "sans le second gap, il ne s'agit que d'un simple sommet à confirmer.",
    },
    spec: {
      bias: "bear",
      closes: [30, 40, 52, 64, 78, 76, 79, 77, 62, 50, 38, 30, 24, 18, 14, 10],
      lines: [
        { x1: 0.28, y1: 64, x2: 0.28, y2: 76, dash: true },
        { x1: 0.5, y1: 77, x2: 0.5, y2: 62, dash: true },
      ],
      levels: [
        { y: 56, kind: "entry" },
        { y: 79, kind: "stop" },
        { y: 12, kind: "target" },
      ],
    },
  },
  {
    slug: "fenetre-haussiere",
    name: "Fenêtre Haussière (Gap)",
    english: "Bullish Breakaway Gap",
    category: "continuation-haussiere",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Un saut de prix qui laisse un « trou » dans le graphique : cassure soutenue par l'enthousiasme.",
    description:
      "La fenêtre (ou gap) haussière est un saut de cotation : le prix ouvre nettement au-dessus de la clôture précédente, laissant une zone vide. Un gap de cassure (breakaway) qui survient à la sortie d'une consolidation, avec du volume, traduit un afflux d'acheteurs. Tant que la fenêtre n'est pas comblée, elle agit comme un support et confirme la dynamique.",
    reading: {
      signal: "Gap haussier à la sortie d'une zone de congestion, idéalement sur volume élevé.",
      entry: "Lecture classique : sur repli vers le haut de la fenêtre non comblée.",
      stop: "Sous la fenêtre (si elle est comblée, le signal est affaibli).",
      target: "Projection de la zone de congestion précédente au-dessus du gap.",
    },
    scenario: {
      si: "Le prix laisse une fenêtre haussière à la sortie d'une consolidation, sur volume",
      alors: "la fenêtre agit comme support et confirme la cassure tant qu'elle n'est pas comblée",
      sinon: "un gap rapidement comblé (exhaustion gap) peut au contraire marquer un excès.",
    },
    spec: {
      bias: "bull",
      closes: [34, 38, 36, 39, 37, 38, 50, 54, 52, 58, 62, 68, 72, 78, 84, 90],
      lines: [
        { x1: 0.32, y1: 38, x2: 0.32, y2: 50, dash: true },
        { x1: 0.02, y1: 38, x2: 0.32, y2: 38, dash: false },
      ],
      levels: [
        { y: 50, kind: "entry" },
        { y: 38, kind: "stop" },
        { y: 88, kind: "target" },
      ],
    },
  },
  {
    slug: "bump-and-run",
    name: "Bump and Run (creux)",
    english: "Bump and Run Reversal Bottom",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Une baisse excessive (la « bosse ») qui revient au-dessus de sa ligne de tendance : excès corrigé.",
    description:
      "Le « Bump and Run » de creux décrit une phase de baisse qui s'accélère anormalement (la « bosse », souvent une vente panique) en s'écartant fortement d'une ligne de tendance modérée. Quand le prix repasse au-dessus de cette ligne (le « run »), l'excès est considéré comme corrigé et un retournement haussier s'amorce. C'est l'application visuelle du retour à la moyenne.",
    reading: {
      signal: "Cassure haussière de la ligne de tendance après une bosse de survente.",
      entry: "Au franchissement de la ligne de tendance par le haut.",
      stop: "Sous le creux de la bosse.",
      target: "Retour vers la zone d'avant l'accélération baissière.",
    },
    scenario: {
      si: "Le prix repasse au-dessus de sa ligne de tendance après une bosse de survente",
      alors: "l'excès baissier est jugé corrigé, un retournement haussier s'amorce",
      sinon: "tant que le prix reste sous la ligne, la bosse peut encore s'étendre.",
    },
    spec: {
      bias: "bull",
      closes: [56, 52, 48, 44, 38, 30, 22, 18, 24, 34, 44, 52, 58, 64, 70, 76],
      lines: [
        { x1: 0.02, y1: 58, x2: 0.98, y2: 40, dash: false },
      ],
      levels: [
        { y: 44, kind: "entry" },
        { y: 18, kind: "stop" },
        { y: 74, kind: "target" },
      ],
    },
  },
  {
    slug: "soucoupe-de-sommet",
    name: "Soucoupe de Sommet",
    english: "Rounding Top (Saucer Top)",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Un sommet arrondi et lent en forme de dôme : la hausse cède la place à la baisse sans à-coup.",
    description:
      "La soucoupe (ou arrondi) de sommet décrit un retournement progressif : la hausse s'essouffle doucement, le prix plafonne en dessinant un dôme régulier, puis amorce une baisse tout aussi graduelle. L'absence de pic marqué traduit un lent transfert du contrôle des acheteurs vers les vendeurs. Figure patiente, fréquente sur les grands horizons.",
    reading: {
      signal: "Courbe en dôme régulière, sans sommet pointu, puis pente descendante.",
      entry: "À la cassure du support qui soutenait la base du dôme.",
      stop: "Au-dessus du point haut du dôme.",
      target: "Profondeur du dôme reportée sous le support cassé.",
    },
    scenario: {
      si: "Le prix dessine un dôme régulier puis casse le support de sa base",
      alors: "un retournement baissier graduel est considéré comme en place",
      sinon: "tant que le support tient, le dôme peut n'être qu'une longue consolidation.",
    },
    spec: {
      bias: "bear",
      closes: [40, 50, 60, 70, 78, 82, 83, 82, 78, 72, 64, 56, 48, 42, 36, 30],
      lines: [
        { x1: 0.02, y1: 40, x2: 0.98, y2: 40, dash: true },
      ],
      levels: [
        { y: 42, kind: "entry" },
        { y: 83, kind: "stop" },
        { y: 22, kind: "target" },
      ],
    },
  },
  {
    slug: "mouvement-mesure-haussier",
    name: "Mouvement Mesuré Haussier",
    english: "Measured Move Up",
    category: "continuation-haussiere",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Une première jambe de hausse, une consolidation, puis une seconde jambe d'amplitude comparable.",
    description:
      "Le mouvement mesuré haussier décompose une tendance en deux jambes de hausse séparées par une phase de correction. L'idée centrale : la seconde jambe tend à reproduire approximativement l'amplitude de la première. C'est une grille de lecture pour projeter un objectif, fondée sur la symétrie observée des mouvements.",
    reading: {
      signal: "Reprise de la hausse après la consolidation, dans le prolongement de la première jambe.",
      entry: "À la sortie haussière de la phase de correction intermédiaire.",
      stop: "Sous le creux de la consolidation.",
      target: "Amplitude de la première jambe reportée depuis le bas de la consolidation.",
    },
    scenario: {
      si: "La seconde jambe démarre et reproduit l'amplitude de la première",
      alors: "l'objectif théorique se situe à une hausse équivalente à la première jambe",
      sinon: "une seconde jambe avortée traduit un essoufflement de la tendance.",
    },
    spec: {
      bias: "bull",
      closes: [22, 30, 26, 40, 52, 50, 44, 48, 46, 50, 58, 70, 66, 80, 90],
      lines: [
        { x1: 0.3, y1: 56, x2: 0.6, y2: 44, dash: true },
      ],
      levels: [
        { y: 50, kind: "entry" },
        { y: 42, kind: "stop" },
        { y: 90, kind: "target" },
      ],
    },
  },
  {
    slug: "mouvement-mesure-baissier",
    name: "Mouvement Mesuré Baissier",
    english: "Measured Move Down",
    category: "continuation-baissiere",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Une première jambe de baisse, un rebond de consolidation, puis une seconde jambe comparable.",
    description:
      "Le mouvement mesuré baissier est le miroir du haussier : une première jambe de baisse, un rebond intermédiaire, puis une seconde jambe de baisse d'amplitude voisine de la première. La symétrie sert à projeter un objectif sous le rebond. C'est une lecture probabiliste, pas une garantie de parcours.",
    reading: {
      signal: "Reprise de la baisse après le rebond, dans le prolongement de la première jambe.",
      entry: "À la sortie baissière de la phase de rebond intermédiaire.",
      stop: "Au-dessus du sommet du rebond.",
      target: "Amplitude de la première jambe reportée depuis le haut du rebond.",
    },
    scenario: {
      si: "La seconde jambe démarre et reproduit l'amplitude de la première",
      alors: "l'objectif théorique se situe à une baisse équivalente à la première jambe",
      sinon: "un rebond qui efface la première jambe invalide la lecture baissière.",
    },
    spec: {
      bias: "bear",
      closes: [88, 80, 84, 70, 58, 60, 66, 62, 64, 60, 52, 40, 44, 30, 20],
      lines: [
        { x1: 0.3, y1: 54, x2: 0.6, y2: 66, dash: true },
      ],
      levels: [
        { y: 60, kind: "entry" },
        { y: 68, kind: "stop" },
        { y: 20, kind: "target" },
      ],
    },
  },
  {
    slug: "tuyaux-bas",
    name: "Tuyaux en Bas",
    english: "Pipe Bottom",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Deux creux profonds, étroits et adjacents en forme de tuyaux : retournement brutal de bas.",
    description:
      "Le motif des tuyaux en bas (« pipe bottom ») se compose de deux longues mèches basses adjacentes, profondes et parallèles, séparées par très peu d'écart. Survenant après une baisse, il traduit deux tests rapprochés et violents d'un plancher, immédiatement rejetés. Plus net sur graphique hebdomadaire, il signale un retournement haussier souvent vif.",
    reading: {
      signal: "Deux creux étroits et profonds côte à côte, suivis d'un rebond.",
      entry: "Au dépassement du sommet qui sépare ou coiffe les deux tuyaux.",
      stop: "Sous le plus bas des tuyaux.",
      target: "Projection de l'ampleur de la baisse précédente.",
    },
    scenario: {
      si: "Le prix dépasse le sommet coiffant les deux tuyaux après le double test du plancher",
      alors: "un retournement haussier souvent rapide est signalé",
      sinon: "un nouveau plus bas sous les tuyaux invalide la figure.",
    },
    spec: {
      bias: "bull",
      closes: [72, 64, 54, 44, 30, 56, 50, 32, 54, 64, 72, 78, 84, 88, 90],
      lines: [
        { x1: 0.02, y1: 58, x2: 0.98, y2: 58, dash: true },
      ],
      levels: [
        { y: 58, kind: "entry" },
        { y: 28, kind: "stop" },
        { y: 88, kind: "target" },
      ],
    },
  },
  {
    slug: "tuyaux-haut",
    name: "Tuyaux en Haut",
    english: "Pipe Top",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Deux sommets hauts, étroits et adjacents en forme de tuyaux : retournement brutal de sommet.",
    description:
      "Le motif des tuyaux en haut (« pipe top ») est le miroir du tuyaux en bas : deux longues mèches hautes adjacentes et parallèles, au sommet d'une hausse, traduisant deux tests rapprochés d'un plafond aussitôt rejetés. C'est un signal de retournement baissier, plus lisible sur les grandes unités de temps.",
    reading: {
      signal: "Deux sommets étroits et hauts côte à côte, suivis d'un repli.",
      entry: "À la cassure du creux qui sépare ou soutient les deux tuyaux.",
      stop: "Au-dessus du plus haut des tuyaux.",
      target: "Projection de l'ampleur de la hausse précédente.",
    },
    scenario: {
      si: "Le prix casse le creux soutenant les deux tuyaux après le double test du plafond",
      alors: "un retournement baissier souvent rapide est signalé",
      sinon: "un nouveau plus haut au-dessus des tuyaux invalide la figure.",
    },
    spec: {
      bias: "bear",
      closes: [28, 36, 46, 56, 70, 44, 50, 68, 46, 36, 28, 22, 16, 12, 10],
      lines: [
        { x1: 0.02, y1: 42, x2: 0.98, y2: 42, dash: true },
      ],
      levels: [
        { y: 42, kind: "entry" },
        { y: 72, kind: "stop" },
        { y: 12, kind: "target" },
      ],
    },
  },
  {
    slug: "tete-epaules-complexe",
    name: "Tête-Épaules Complexe",
    english: "Complex Head & Shoulders",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Une tête-épaules avec plusieurs épaules de chaque côté : un sommet de distribution élargi.",
    description:
      "La tête-épaules complexe est une variante où l'on compte plusieurs épaules de part et d'autre de la tête, souvent à des niveaux symétriques. Elle traduit une phase de distribution plus longue et plus élaborée qu'une tête-épaules classique. Sa ligne de cou peut relier plusieurs creux ; sa rupture reste l'élément décisif.",
    reading: {
      signal: "Cassure de la ligne de cou après une succession d'épaules de part et d'autre de la tête.",
      entry: "Au franchissement baissier de la ligne de cou.",
      stop: "Au-dessus de la dernière épaule droite.",
      target: "Hauteur tête-cou reportée sous la cassure.",
    },
    scenario: {
      si: "Le prix casse la ligne de cou après une distribution à épaules multiples",
      alors: "un retournement baissier élargi est considéré comme amorcé",
      sinon: "tant que la ligne de cou tient, la distribution peut se prolonger.",
    },
    spec: {
      bias: "bear",
      closes: [40, 52, 48, 56, 50, 70, 88, 70, 52, 60, 54, 62, 50, 40, 26],
      lines: [
        { x1: 0.02, y1: 50, x2: 0.98, y2: 50, dash: false },
      ],
      levels: [
        { y: 50, kind: "entry" },
        { y: 64, kind: "stop" },
        { y: 26, kind: "target" },
      ],
    },
  },
  {
    slug: "biseau-elargissant-descendant",
    name: "Biseau Élargissant Descendant",
    english: "Descending Broadening Wedge",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Variable",
    summary: "Deux droites descendantes qui s'écartent : volatilité croissante, souvent résolue à la hausse.",
    description:
      "Le biseau élargissant descendant combine deux caractéristiques : une pente globalement baissière et des bornes qui s'écartent (amplitude croissante). Cette nervosité grandissante au sein d'une baisse se résout le plus souvent par une sortie haussière, ce qui en fait une figure majoritairement classée comme retournement haussier — mais sa variabilité impose la prudence.",
    reading: {
      signal: "Sortie par le haut de la borne supérieure descendante, après élargissement.",
      entry: "À la cassure haussière de la borne haute.",
      stop: "Sous le dernier creux du biseau.",
      target: "Projection de la hauteur maximale du biseau au-dessus de la cassure.",
    },
    scenario: {
      si: "Le prix sort par le haut du biseau élargissant après plusieurs oscillations croissantes",
      alors: "un retournement haussier est généralement privilégié",
      sinon: "une sortie par le bas prolonge la dynamique baissière.",
    },
    spec: {
      bias: "bull",
      closes: [70, 58, 76, 50, 80, 44, 84, 40, 88, 38, 66, 78, 86, 90, 92],
      lines: [
        { x1: 0.02, y1: 72, x2: 0.7, y2: 86, dash: false },
        { x1: 0.02, y1: 60, x2: 0.7, y2: 30, dash: false },
      ],
      levels: [
        { y: 80, kind: "entry" },
        { y: 38, kind: "stop" },
        { y: 92, kind: "target" },
      ],
    },
  },
  {
    slug: "rebond-chat-mort",
    name: "Rebond du chat mort",
    english: "Dead Cat Bounce",
    category: "continuation-baissiere",
    bias: "Baissier",
    reliability: "Variable",
    summary: "Un rebond technique de courte durée au milieu d'une chute… avant la reprise de la baisse.",
    description:
      "Le « rebond du chat mort » décrit une reprise temporaire et trompeuse des prix après une forte baisse, suivie d'une rechute vers de nouveaux plus-bas. L'expression imagée (« même un chat mort rebondit s'il tombe de assez haut ») souligne qu'un rebond n'est pas toujours un retournement : il peut n'être qu'une pause technique dans une tendance baissière intacte.",
    reading: {
      signal: "Un rebond qui échoue sous une résistance/ancienne zone de support, puis casse le plus-bas précédent.",
      entry: "Lecture après l'échec du rebond et la reprise de la baisse.",
      stop: "Au-dessus du sommet du rebond.",
      target: "Reprise de la tendance baissière, vers les plus-bas précédents et au-delà.",
    },
    scenario: {
      si: "Le rebond s'essouffle sous une résistance et le prix casse à nouveau son plus-bas",
      alors: "la baisse de fond est considérée comme reprise (le rebond n'était que technique)",
      sinon: "un franchissement net de la résistance peut invalider le scénario baissier.",
    },
    spec: {
      bias: "bear",
      closes: [88, 80, 68, 56, 46, 40, 50, 56, 52, 44, 36, 30, 24, 20, 16],
      lines: [{ x1: 0.3, y1: 56, x2: 0.95, y2: 56, dash: true }],
      levels: [
        { y: 56, kind: "entry" },
        { y: 58, kind: "stop" },
        { y: 18, kind: "target" },
      ],
    },
  },
  {
    slug: "elargissement-ascendant",
    name: "Élargissement ascendant",
    english: "Ascending Broadening Formation",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Variable",
    summary: "Des oscillations de plus en plus larges, bornées par deux droites divergentes montantes.",
    description:
      "L'élargissement ascendant (ou « mégaphone » incliné vers le haut) se caractérise par des sommets de plus en plus hauts ET des creux de plus en plus hauts, mais avec une amplitude croissante : les deux droites de tendance divergent vers le haut. Cette instabilité grandissante traduit une nervosité du marché et précède souvent un retournement baissier.",
    reading: {
      signal: "Cassure de la droite inférieure (support montant) après plusieurs oscillations élargies.",
      entry: "À la rupture de la borne basse de la figure.",
      stop: "Au-dessus du dernier sommet de la figure.",
      target: "Amplitude de la figure reportée sous la cassure.",
    },
    scenario: {
      si: "Le prix casse la droite inférieure de l'élargissement par le bas",
      alors: "un retournement baissier est généralement privilégié",
      sinon: "tant que les bornes tiennent, la figure reste instable et peut piéger dans les deux sens.",
    },
    spec: {
      bias: "bear",
      closes: [50, 60, 44, 68, 38, 76, 32, 84, 28, 60, 44, 34, 26, 22, 18],
      lines: [
        { x1: 0.04, y1: 60, x2: 0.62, y2: 90, dash: false },
        { x1: 0.04, y1: 46, x2: 0.62, y2: 24, dash: false },
      ],
      levels: [
        { y: 40, kind: "entry" },
        { y: 86, kind: "stop" },
        { y: 18, kind: "target" },
      ],
    },
  },
  {
    slug: "cornes-au-creux",
    name: "Cornes au creux",
    english: "Horn Bottom",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Deux creux marqués séparés par un rebond, dessinant deux « cornes » — base de retournement.",
    description:
      "Les cornes au creux se forment après une baisse : deux creux profonds, séparés par une seule période de rebond, dessinent deux pointes vers le bas (les « cornes »). Cette double piqûre, suivie d'un redressement, traduit l'échec répété des vendeurs à enfoncer durablement le plancher.",
    reading: {
      signal: "Sortie au-dessus du sommet intermédiaire séparant les deux creux.",
      entry: "Au franchissement de ce sommet de référence.",
      stop: "Sous le plus bas des deux cornes.",
      target: "Hauteur de la figure reportée au-dessus du point de cassure.",
    },
    scenario: {
      si: "Le prix dépasse le sommet séparant les deux creux après la seconde corne",
      alors: "un retournement haussier est généralement privilégié",
      sinon: "un nouveau plus-bas sous les cornes invalide la base.",
    },
    spec: {
      bias: "bull",
      closes: [72, 60, 46, 34, 50, 36, 48, 58, 66, 72, 76, 80, 82, 84, 86],
      lines: [{ x1: 0.06, y1: 50, x2: 0.95, y2: 50, dash: true }],
      levels: [
        { y: 50, kind: "entry" },
        { y: 32, kind: "stop" },
        { y: 70, kind: "target" },
      ],
    },
  },
  {
    slug: "cornes-au-sommet",
    name: "Cornes au sommet",
    english: "Horn Top",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Deux sommets pointus séparés par un repli, dessinant deux « cornes » — sommet de retournement.",
    description:
      "Miroir des cornes au creux : après une hausse, deux sommets pointus séparés par une seule période de repli dessinent deux pointes vers le haut. L'échec répété des acheteurs à prolonger la hausse au-delà de ce plafond annonce souvent un retournement baissier.",
    reading: {
      signal: "Cassure sous le creux intermédiaire séparant les deux sommets.",
      entry: "À la rupture de ce creux de référence.",
      stop: "Au-dessus du plus haut des deux cornes.",
      target: "Hauteur de la figure reportée sous le point de cassure.",
    },
    scenario: {
      si: "Le prix casse sous le creux séparant les deux sommets après la seconde corne",
      alors: "un retournement baissier est généralement privilégié",
      sinon: "un nouveau plus-haut au-dessus des cornes invalide le sommet.",
    },
    spec: {
      bias: "bear",
      closes: [40, 52, 66, 78, 62, 76, 64, 54, 46, 40, 36, 32, 28, 26, 24],
      lines: [{ x1: 0.06, y1: 62, x2: 0.95, y2: 62, dash: true }],
      levels: [
        { y: 62, kind: "entry" },
        { y: 80, kind: "stop" },
        { y: 42, kind: "target" },
      ],
    },
  },
  {
    slug: "fenetre-baissiere",
    name: "Fenêtre Baissière",
    english: "Bearish Window (Gap Down)",
    category: "continuation-baissiere",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Un trou de cotation vers le bas qui prolonge la baisse et fait office de résistance.",
    description:
      "La fenêtre baissière est un écart (gap) laissé par le marché lorsqu'une séance ouvre nettement sous la clôture précédente. Ce vide de cotation marque une accélération de la pression vendeuse. Tant qu'il n'est pas comblé, il agit comme une résistance : les tentatives de rebond butent souvent sur le bas de la fenêtre.",
    reading: {
      signal: "Apparition d'un gap baissier dans une tendance déjà orientée à la baisse.",
      entry: "À la reprise de la baisse sous la fenêtre, après un éventuel rebond avorté.",
      stop: "Au-dessus du haut de la fenêtre (gap comblé).",
      target: "Prolongement de la tendance baissière, hauteur du mouvement précédent reportée.",
    },
    scenario: {
      si: "Le prix rebondit jusqu'au bas de la fenêtre puis rechute sans la combler",
      alors: "la fenêtre joue son rôle de résistance et la baisse est susceptible de se poursuivre",
      sinon: "un comblement complet du gap affaiblit le signal baissier.",
    },
    spec: {
      bias: "bear",
      closes: [74, 68, 63, 58, 54, 52, 40, 36, 33, 30, 27, 23],
      lines: [{ x1: 0, y1: 52, x2: 1, y2: 52, dash: true }],
      levels: [
        { y: 40, kind: "entry" },
        { y: 54, kind: "stop" },
        { y: 24, kind: "target" },
      ],
    },
  },
  {
    slug: "gap-de-rupture",
    name: "Gap de Rupture",
    english: "Breakaway Gap",
    category: "continuation-haussiere",
    bias: "Haussier",
    reliability: "Élevée",
    summary: "Un saut de cotation qui fait sortir le prix d'une consolidation : départ de tendance.",
    description:
      "Le gap de rupture apparaît lorsque le prix franchit, par un trou de cotation, la borne d'une zone de congestion (range, triangle). Il signale un déséquilibre net entre acheteurs et vendeurs au moment de la cassure. Accompagné de volume, il marque souvent le début d'un mouvement directionnel soutenu, et l'ancienne résistance devient support.",
    reading: {
      signal: "Gap franchissant la résistance d'une consolidation, idéalement avec un fort volume.",
      entry: "Après la confirmation de la cassure, sur un éventuel retour vers l'ancienne borne.",
      stop: "Sous la zone de congestion (si le gap est comblé).",
      target: "Hauteur de la consolidation reportée au-dessus de la cassure.",
    },
    scenario: {
      si: "Le gap franchit la résistance avec volume et n'est pas comblé",
      alors: "le départ d'une tendance haussière est généralement privilégié",
      sinon: "un comblement rapide du gap suggère un faux signal (fakeout).",
    },
    spec: {
      bias: "bull",
      closes: [40, 44, 41, 45, 42, 44, 58, 62, 60, 66, 70, 76],
      lines: [{ x1: 0, y1: 45, x2: 1, y2: 45, dash: true }],
      levels: [
        { y: 58, kind: "entry" },
        { y: 42, kind: "stop" },
        { y: 80, kind: "target" },
      ],
    },
  },
  {
    slug: "gap-d-epuisement",
    name: "Gap d'Épuisement",
    english: "Exhaustion Gap",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Un dernier saut de cotation en fin de tendance, signe d'un emballement à bout de souffle.",
    description:
      "Le gap d'épuisement survient en toute fin de tendance haussière, comme un ultime sursaut d'euphorie. Contrairement au gap de rupture, il n'est pas suivi d'une poursuite : le marché s'essouffle aussitôt et se retourne. Son comblement rapide est un signal d'alerte fort, suggérant que les derniers acheteurs ont été pris au piège.",
    reading: {
      signal: "Gap haussier après une tendance déjà mûre, suivi d'un arrêt net de la hausse.",
      entry: "Au retour du prix sous le bas du gap (comblement).",
      stop: "Au-dessus du plus-haut formé par le gap.",
      target: "Retour vers la base de la tendance précédente.",
    },
    scenario: {
      si: "Le gap est comblé rapidement et le prix repasse sous son point de départ",
      alors: "un épuisement de la tendance et un retournement baissier sont privilégiés",
      sinon: "une poursuite de la hausse au-dessus du gap requalifie celui-ci en gap de continuation.",
    },
    spec: {
      bias: "bear",
      closes: [40, 48, 54, 60, 66, 70, 82, 78, 70, 62, 54, 46],
      lines: [{ x1: 0.5, y1: 70, x2: 1, y2: 70, dash: true }],
      levels: [
        { y: 70, kind: "entry" },
        { y: 84, kind: "stop" },
        { y: 48, kind: "target" },
      ],
    },
  },
  {
    slug: "drapeau-serre",
    name: "Drapeau Serré",
    english: "High and Tight Flag",
    category: "continuation-haussiere",
    bias: "Haussier",
    reliability: "Élevée",
    summary: "Une hausse verticale suivie d'une consolidation minime : l'une des figures les plus puissantes.",
    description:
      "Le drapeau serré (« high and tight flag ») se forme après une envolée quasi verticale du prix (le mât), souvent +50 % à +100 % en quelques séances. La consolidation qui suit est très courte et peu profonde : le marché digère à peine ses gains avant de repartir. Sa rareté et sa fiabilité en font une figure de continuation particulièrement recherchée.",
    reading: {
      signal: "Repli faible (souvent < 20 %) après une hausse explosive, sur faible volume.",
      entry: "À la cassure du sommet du petit drapeau.",
      stop: "Sous le point bas de la consolidation.",
      target: "Hauteur du mât reportée à partir de la cassure.",
    },
    scenario: {
      si: "Le prix casse le haut du drapeau après une consolidation brève et peu profonde",
      alors: "la poursuite de la hausse explosive est généralement privilégiée",
      sinon: "un repli profond (> 25 %) dénature la figure et fragilise le signal.",
    },
    spec: {
      bias: "bull",
      closes: [30, 38, 48, 60, 72, 80, 76, 78, 75, 77, 84, 92],
      lines: [{ x1: 0.5, y1: 81, x2: 0.83, y2: 78, dash: true }],
      levels: [
        { y: 81, kind: "entry" },
        { y: 73, kind: "stop" },
        { y: 98, kind: "target" },
      ],
    },
  },
  {
    slug: "trois-poussees",
    name: "Trois Poussées",
    english: "Three Drives",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Trois sommets successifs de plus en plus hauts, signe d'un achat qui s'épuise.",
    description:
      "La figure des trois poussées se compose de trois sommets ascendants séparés de deux replis, formant une montée en escalier souvent symétrique. Chaque poussée demande plus d'efforts pour un gain décroissant : c'est le signe d'un déséquilibre acheteur qui se vide. La rupture du support relie les creux intermédiaires marque le retournement.",
    reading: {
      signal: "Trois sommets successifs plus hauts, avec un momentum déclinant à chaque poussée.",
      entry: "À la cassure de la ligne de support reliant les creux.",
      stop: "Au-dessus du troisième et dernier sommet.",
      target: "Retour vers la base de la première poussée.",
    },
    scenario: {
      si: "La troisième poussée échoue à prolonger franchement la hausse puis le support cède",
      alors: "un essoufflement acheteur et un retournement baissier sont privilégiés",
      sinon: "une quatrième poussée vigoureuse invalide le schéma d'épuisement.",
    },
    spec: {
      bias: "bear",
      closes: [42, 58, 50, 66, 56, 76, 68, 58, 50, 44, 38],
      lines: [{ x1: 0.1, y1: 50, x2: 0.5, y2: 56, dash: true }],
      levels: [
        { y: 56, kind: "entry" },
        { y: 78, kind: "stop" },
        { y: 40, kind: "target" },
      ],
    },
  },
  {
    slug: "scallop-ascendant",
    name: "Scallop Ascendant",
    english: "Ascending Scallop",
    category: "continuation-haussiere",
    bias: "Haussier",
    reliability: "Variable",
    summary: "Une cuvette arrondie en forme de « J » qui se referme plus haut qu'elle n'a commencé.",
    description:
      "Le scallop ascendant ressemble à une lettre « J » : le prix décline doucement, forme un creux arrondi, puis remonte au-delà de son point de départ. Ces cuvettes s'enchaînent souvent en escalier dans une tendance haussière de fond, chaque scallop débutant plus haut que le précédent. La forme arrondie traduit une transition graduelle du contrôle vers les acheteurs.",
    reading: {
      signal: "Creux arrondi suivi d'une remontée dépassant le sommet de gauche de la cuvette.",
      entry: "Au franchissement du sommet gauche du scallop.",
      stop: "Sous le point bas de la cuvette.",
      target: "Profondeur de la cuvette reportée au-dessus de la cassure.",
    },
    scenario: {
      si: "Le prix remonte au-dessus du bord gauche de la cuvette dans une tendance haussière",
      alors: "la poursuite de la hausse par enchaînement de scallops est privilégiée",
      sinon: "un repli sous le creux de la cuvette annule la dynamique haussière.",
    },
    spec: {
      bias: "bull",
      closes: [50, 46, 43, 42, 44, 48, 54, 62, 70, 66, 72, 80],
      lines: [{ x1: 0, y1: 50, x2: 0.6, y2: 50, dash: true }],
      levels: [
        { y: 54, kind: "entry" },
        { y: 42, kind: "stop" },
        { y: 82, kind: "target" },
      ],
    },
  },
  {
    slug: "scallop-descendant",
    name: "Scallop Descendant",
    english: "Descending Scallop",
    category: "continuation-baissiere",
    bias: "Baissier",
    reliability: "Variable",
    summary: "Une bosse arrondie en « J » inversé qui se referme plus bas qu'elle n'a commencé.",
    description:
      "Miroir du scallop ascendant, le scallop descendant dessine un dôme arrondi : le prix monte doucement, s'arrondit au sommet, puis rechute au-delà de son point de départ. Ces dômes s'enchaînent souvent en escalier dans une tendance baissière de fond, chacun débutant plus bas que le précédent. L'arrondi traduit un transfert progressif du contrôle vers les vendeurs.",
    reading: {
      signal: "Dôme arrondi suivi d'une rechute sous le creux de gauche de la bosse.",
      entry: "À la cassure du creux gauche du scallop.",
      stop: "Au-dessus du sommet de la bosse.",
      target: "Hauteur de la bosse reportée sous la cassure.",
    },
    scenario: {
      si: "Le prix rechute sous le bord gauche de la bosse dans une tendance baissière",
      alors: "la poursuite de la baisse par enchaînement de scallops est privilégiée",
      sinon: "un retour au-dessus du sommet de la bosse annule la dynamique baissière.",
    },
    spec: {
      bias: "bear",
      closes: [50, 54, 57, 58, 56, 52, 46, 38, 30, 34, 28, 20],
      lines: [{ x1: 0, y1: 50, x2: 0.6, y2: 50, dash: true }],
      levels: [
        { y: 46, kind: "entry" },
        { y: 58, kind: "stop" },
        { y: 22, kind: "target" },
      ],
    },
  },
  {
    slug: "vagues-de-wolfe",
    name: "Vagues de Wolfe",
    english: "Wolfe Waves",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Variable",
    summary: "Cinq vagues en biseau dont la dernière, en excès, projette une cible de retournement.",
    description:
      "Les vagues de Wolfe, formalisées par Bill Wolfe, sont un schéma de cinq pivots formant un biseau. La cinquième vague dépasse légèrement la ligne reliant les vagues 1 et 3 (un excès), point à partir duquel un retournement est attendu vers la « ligne EPA » reliant les vagues 1 et 4, qui sert de cible. C'est une figure géométrique exigeante, où la symétrie des vagues compte autant que leur emplacement.",
    reading: {
      signal: "Excès de la vague 5 au-delà de la ligne des vagues 1-3, puis amorce de retournement.",
      entry: "Au retournement après l'excès de la vague 5.",
      stop: "Au-delà du point extrême de la vague 5.",
      target: "La ligne reliant les vagues 1 et 4 (ligne EPA).",
    },
    scenario: {
      si: "La vague 5 fait un excès puis le prix se retourne vers la ligne 1-4",
      alors: "le scénario de Wolfe vise un retour jusqu'à la ligne EPA",
      sinon: "une poursuite du mouvement au-delà de la vague 5 invalide la figure.",
    },
    spec: {
      bias: "bull",
      closes: [72, 48, 64, 40, 56, 34, 50, 64, 76],
      lines: [{ x1: 0, y1: 72, x2: 0.62, y2: 34, dash: true }],
      levels: [
        { y: 50, kind: "entry" },
        { y: 34, kind: "stop" },
        { y: 80, kind: "target" },
      ],
    },
  },
  {
    slug: "ab-cd",
    name: "Figure AB=CD",
    english: "AB=CD Pattern",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Variable",
    summary: "Deux segments de prix symétriques : la jambe CD reproduit l'ampleur de la jambe AB.",
    description:
      "L'AB=CD est la brique de base de l'analyse harmonique. Le prix dessine un zigzag où la dernière jambe (CD) reproduit, en ampleur et souvent en durée, la première jambe (AB), avec un repli intermédiaire (BC). Le point D, où CD égale AB, devient une zone de retournement potentielle, renforcée lorsque les proportions respectent des ratios de Fibonacci.",
    reading: {
      signal: "Achèvement de la jambe CD au niveau où elle égale AB (point D).",
      entry: "À l'amorce du retournement au point D.",
      stop: "Au-delà du point D.",
      target: "Retour vers la zone du point C, voire au-delà.",
    },
    scenario: {
      si: "La jambe CD atteint l'ampleur de la jambe AB et le prix se retourne au point D",
      alors: "une zone de retournement harmonique est identifiée au point D",
      sinon: "un dépassement net du point D sans réaction invalide la symétrie.",
    },
    spec: {
      bias: "bull",
      closes: [76, 62, 50, 44, 52, 60, 50, 40, 30, 42, 56, 68],
      lines: [{ x1: 0, y1: 76, x2: 0.72, y2: 30, dash: true }],
      levels: [
        { y: 42, kind: "entry" },
        { y: 30, kind: "stop" },
        { y: 64, kind: "target" },
      ],
    },
  },
  {
    slug: "gartley",
    name: "Gartley harmonique",
    english: "Gartley Pattern",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Variable",
    summary: "Une figure en cinq points (XABCD) gouvernée par des ratios de Fibonacci.",
    description:
      "Le Gartley, décrit par H. M. Gartley en 1935 et précisé par les ratios de Fibonacci, est la figure harmonique de référence. Cinq points (X, A, B, C, D) s'enchaînent : B retrace environ 61,8 % de XA, et D se situe vers 78,6 % de XA, formant une zone de retournement potentielle (PRZ). Sa force tient à la convergence de plusieurs ratios au point D.",
    reading: {
      signal: "Achèvement du point D dans la zone de retournement (≈ 78,6 % de XA).",
      entry: "À la réaction du prix au point D.",
      stop: "Sous le point X.",
      target: "Retour vers les points C puis A.",
    },
    scenario: {
      si: "Le point D se forme dans la zone harmonique et le prix y réagit",
      alors: "un retournement haussier est anticipé depuis la zone de retournement",
      sinon: "une cassure sous le point X invalide le Gartley.",
    },
    spec: {
      bias: "bull",
      closes: [30, 48, 62, 70, 58, 46, 54, 62, 50, 42, 54, 66, 78],
      lines: [{ x1: 0, y1: 30, x2: 0.69, y2: 42, dash: true }],
      levels: [
        { y: 54, kind: "entry" },
        { y: 42, kind: "stop" },
        { y: 78, kind: "target" },
      ],
    },
  },
  {
    slug: "piege-haussier",
    name: "Piège Haussier (Bull Trap)",
    english: "Bull Trap",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Une fausse cassure haussière qui piège les acheteurs avant un retournement à la baisse.",
    description:
      "Le piège haussier survient lorsque le prix franchit une résistance, attirant les acheteurs convaincus d'une cassure, puis se retourne aussitôt sous le niveau franchi. Les acheteurs entrés sur la cassure se retrouvent piégés et leur capitulation alimente la baisse. C'est l'un des pièges les plus coûteux pour qui poursuit les cassures sans confirmation.",
    reading: {
      signal: "Cassure de résistance non confirmée, suivie d'un retour rapide sous le niveau.",
      entry: "Au retour du prix sous l'ancienne résistance.",
      stop: "Au-dessus du plus-haut de la fausse cassure.",
      target: "Retour vers le bas de la zone de consolidation précédente.",
    },
    scenario: {
      si: "Le prix repasse sous la résistance juste après l'avoir « cassée »",
      alors: "un piège haussier est identifié et un retournement baissier privilégié",
      sinon: "une clôture qui tient au-dessus de la résistance valide au contraire la cassure.",
    },
    spec: {
      bias: "bear",
      closes: [60, 64, 62, 66, 63, 68, 74, 70, 62, 54, 46, 40],
      lines: [{ x1: 0, y1: 66, x2: 1, y2: 66, dash: true }],
      levels: [
        { y: 62, kind: "entry" },
        { y: 74, kind: "stop" },
        { y: 44, kind: "target" },
      ],
    },
  },
  {
    slug: "piege-baissier",
    name: "Piège Baissier (Bear Trap)",
    english: "Bear Trap",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Une fausse cassure baissière qui piège les vendeurs avant un rebond.",
    description:
      "Miroir du piège haussier, le piège baissier se produit quand le prix casse un support, attirant les vendeurs, puis remonte aussitôt au-dessus du niveau. Les vendeurs entrés sur la cassure baissière sont pris à contre-pied, et leurs rachats alimentent le rebond. La fausse cassure agit comme un ressort.",
    reading: {
      signal: "Cassure de support non confirmée, suivie d'un retour rapide au-dessus du niveau.",
      entry: "Au retour du prix au-dessus de l'ancien support.",
      stop: "Sous le plus-bas de la fausse cassure.",
      target: "Retour vers le haut de la zone de consolidation précédente.",
    },
    scenario: {
      si: "Le prix repasse au-dessus du support juste après l'avoir « cassé »",
      alors: "un piège baissier est identifié et un rebond haussier privilégié",
      sinon: "une clôture qui tient sous le support valide au contraire la cassure baissière.",
    },
    spec: {
      bias: "bull",
      closes: [50, 46, 48, 44, 46, 40, 34, 40, 48, 56, 64, 70],
      lines: [{ x1: 0, y1: 44, x2: 1, y2: 44, dash: true }],
      levels: [
        { y: 48, kind: "entry" },
        { y: 34, kind: "stop" },
        { y: 68, kind: "target" },
      ],
    },
  },
  {
    slug: "papillon",
    name: "Papillon harmonique",
    english: "Butterfly Pattern",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Variable",
    summary: "Une figure harmonique en cinq points dont le point D prolonge la jambe XA au-delà de son origine.",
    description:
      "Le papillon, décrit par Bryce Gilmore et Larry Pesavento, est une figure harmonique où le point D s'étend au-delà du point X (vers 127 % à 161,8 % de XA). Cette extension projette une zone de retournement plus lointaine que le Gartley, là où le mouvement est jugé étiré. La convergence des ratios de Fibonacci au point D définit la zone à surveiller.",
    reading: {
      signal: "Achèvement du point D au-delà de X (≈ 127-161,8 % de XA).",
      entry: "À la réaction du prix dans la zone de retournement.",
      stop: "Au-delà du point D.",
      target: "Retour vers les points B puis A.",
    },
    scenario: {
      si: "Le point D se forme dans la zone d'extension et le prix y réagit",
      alors: "un retournement haussier est anticipé depuis cette zone étirée",
      sinon: "une poursuite du mouvement au-delà de D invalide le papillon.",
    },
    spec: {
      bias: "bull",
      closes: [40, 54, 66, 56, 50, 58, 44, 30, 42, 56, 68],
      lines: [{ x1: 0, y1: 40, x2: 0.7, y2: 30, dash: true }],
      levels: [
        { y: 42, kind: "entry" },
        { y: 30, kind: "stop" },
        { y: 64, kind: "target" },
      ],
    },
  },
  {
    slug: "crabe",
    name: "Crabe harmonique",
    english: "Crab Pattern",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Variable",
    summary: "La figure harmonique la plus extrême : le point D s'étend jusqu'à 161,8 % de la jambe XA.",
    description:
      "Le crabe, identifié par Scott Carney, se distingue par l'extension très prononcée de son point D (jusqu'à 161,8 % de XA), la plus profonde des figures harmoniques classiques. Cette projection lointaine vise des retournements après un mouvement particulièrement étiré, offrant un stop serré relativement à l'objectif.",
    reading: {
      signal: "Achèvement du point D à une extension extrême de XA (≈ 161,8 %).",
      entry: "À la réaction du prix dans la zone de retournement profonde.",
      stop: "Juste au-delà du point D.",
      target: "Retour progressif vers les points C, B puis A.",
    },
    scenario: {
      si: "Le prix atteint la zone d'extension extrême du crabe puis se retourne",
      alors: "un retournement haussier est anticipé avec un stop serré",
      sinon: "un dépassement net de la zone invalide la figure.",
    },
    spec: {
      bias: "bull",
      closes: [45, 60, 72, 58, 52, 62, 46, 26, 40, 56, 70],
      lines: [{ x1: 0, y1: 45, x2: 0.64, y2: 26, dash: true }],
      levels: [
        { y: 40, kind: "entry" },
        { y: 26, kind: "stop" },
        { y: 66, kind: "target" },
      ],
    },
  },
  {
    slug: "trois-vallees-ascendantes",
    name: "Trois Vallées Ascendantes",
    english: "Three Rising Valleys",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Trois creux successifs de plus en plus hauts : les acheteurs reprennent progressivement la main.",
    description:
      "La figure des trois vallées ascendantes se compose de trois creux successifs, chacun plus haut que le précédent, séparés de rebonds. Cette série de planchers relevés trahit une demande croissante : à chaque repli, les acheteurs interviennent plus tôt. La cassure de la résistance qui coiffe la figure confirme le retournement ou la poursuite haussière.",
    reading: {
      signal: "Trois creux ascendants, puis cassure de la résistance supérieure.",
      entry: "Au franchissement de la résistance qui plafonne les rebonds.",
      stop: "Sous le dernier creux.",
      target: "Hauteur de la figure reportée au-dessus de la cassure.",
    },
    scenario: {
      si: "Le prix casse la résistance après trois creux de plus en plus hauts",
      alors: "la dynamique haussière est généralement confirmée",
      sinon: "un creux plus bas que le précédent rompt la série ascendante.",
    },
    spec: {
      bias: "bull",
      closes: [60, 50, 44, 52, 58, 48, 56, 64, 54, 62, 72, 80],
      lines: [{ x1: 0.16, y1: 44, x2: 0.72, y2: 54, dash: true }],
      levels: [
        { y: 64, kind: "entry" },
        { y: 44, kind: "stop" },
        { y: 84, kind: "target" },
      ],
    },
  },
  {
    slug: "trois-sommets-descendants",
    name: "Trois Sommets Descendants",
    english: "Three Falling Peaks",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Trois sommets successifs de plus en plus bas : les vendeurs reprennent progressivement la main.",
    description:
      "Miroir des trois vallées ascendantes, cette figure aligne trois sommets successifs, chacun plus bas que le précédent, séparés de replis. Ces plafonds abaissés traduisent une offre croissante : à chaque rebond, les vendeurs interviennent plus tôt. La cassure du support qui soutient la figure confirme le retournement baissier.",
    reading: {
      signal: "Trois sommets descendants, puis cassure du support inférieur.",
      entry: "À la cassure du support qui soutient les replis.",
      stop: "Au-dessus du dernier sommet.",
      target: "Hauteur de la figure reportée sous la cassure.",
    },
    scenario: {
      si: "Le prix casse le support après trois sommets de plus en plus bas",
      alors: "la dynamique baissière est généralement confirmée",
      sinon: "un sommet plus haut que le précédent rompt la série descendante.",
    },
    spec: {
      bias: "bear",
      closes: [40, 50, 56, 48, 42, 52, 44, 36, 46, 38, 28, 20],
      lines: [{ x1: 0.16, y1: 56, x2: 0.72, y2: 46, dash: true }],
      levels: [
        { y: 36, kind: "entry" },
        { y: 56, kind: "stop" },
        { y: 18, kind: "target" },
      ],
    },
  },
  {
    slug: "tasse-sans-anse",
    name: "Tasse sans Anse",
    english: "Cup without Handle",
    category: "continuation-haussiere",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Une cuvette arrondie en « U » dont la sortie se fait directement, sans phase de repli.",
    description:
      "Variante de la tasse avec anse, la tasse sans anse dessine un fond arrondi en « U » suivi d'une cassure directe de la résistance, sans la petite consolidation latérale (l'anse) qui précède habituellement. L'arrondi traduit une transition progressive du contrôle vers les acheteurs ; l'absence d'anse rend la cassure plus immédiate, parfois moins fiable.",
    reading: {
      signal: "Fond arrondi en U puis cassure du bord de la tasse, sans anse préalable.",
      entry: "Au franchissement du bord de la tasse (résistance).",
      stop: "Sous la partie basse de la cuvette.",
      target: "Profondeur de la tasse reportée au-dessus de la cassure.",
    },
    scenario: {
      si: "Le prix franchit le bord de la tasse après un fond arrondi régulier",
      alors: "la continuation haussière est généralement privilégiée",
      sinon: "un échec au niveau du bord renvoie le prix dans la cuvette.",
    },
    spec: {
      bias: "bull",
      closes: [62, 54, 46, 40, 38, 40, 46, 54, 62, 68, 74],
      lines: [{ x1: 0, y1: 62, x2: 0.8, y2: 62, dash: true }],
      levels: [
        { y: 64, kind: "entry" },
        { y: 40, kind: "stop" },
        { y: 84, kind: "target" },
      ],
    },
  },
  {
    slug: "quasimodo",
    name: "Quasimodo (Over & Under)",
    english: "Quasimodo Pattern",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Variable",
    summary: "Un faux nouveau sommet suivi de la cassure du creux précédent : un retournement de structure.",
    description:
      "Le Quasimodo (ou « Over-and-Under »), popularisé par l'analyse moderne du price-action, se reconnaît à une structure proche de la tête-épaules : le prix forme un nouveau plus-haut (la « tête »), puis casse le creux qui précédait ce sommet, brisant la séquence de hauts et de bas ascendants. Cette rupture de structure signale un possible changement de mains.",
    reading: {
      signal: "Nouveau plus-haut puis cassure du creux précédant ce sommet.",
      entry: "Souvent au retour du prix vers le niveau de l'épaule gauche.",
      stop: "Au-dessus du plus-haut (la tête).",
      target: "Prolongement de la baisse sous la zone de cassure.",
    },
    scenario: {
      si: "Le prix casse le dernier creux après avoir fait un nouveau plus-haut",
      alors: "une rupture de structure baissière est identifiée",
      sinon: "un maintien au-dessus du creux préserve la tendance haussière.",
    },
    spec: {
      bias: "bear",
      closes: [40, 54, 48, 62, 46, 50, 42, 34, 28],
      lines: [{ x1: 0.18, y1: 48, x2: 0.95, y2: 48, dash: true }],
      levels: [
        { y: 46, kind: "entry" },
        { y: 62, kind: "stop" },
        { y: 28, kind: "target" },
      ],
    },
  },
  {
    slug: "chauve-souris",
    name: "Chauve-souris harmonique",
    english: "Bat Pattern",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Variable",
    summary: "Une figure harmonique XABCD dont le point D se forme vers 88,6 % de la jambe XA.",
    description:
      "La chauve-souris, décrite par Scott Carney, est une figure harmonique proche du Gartley mais dont le point D est plus profond (vers 88,6 % de XA), au plus près du point X. Cette zone de retournement serrée permet un stop court relativement à l'objectif.",
    reading: {
      signal: "Achèvement du point D vers 88,6 % de XA, dans la zone de retournement.",
      entry: "À la réaction du prix au point D.",
      stop: "Juste sous le point X.",
      target: "Retour vers les points B puis A.",
    },
    scenario: {
      si: "Le point D se forme à ~88,6 % de XA et le prix y réagit",
      alors: "un retournement haussier est anticipé avec un risque serré",
      sinon: "une cassure nette sous X invalide la chauve-souris.",
    },
    spec: {
      bias: "bull",
      closes: [40, 56, 48, 52, 44, 50, 38, 44, 58, 70],
      lines: [{ x1: 0, y1: 40, x2: 0.66, y2: 38, dash: true }],
      levels: [
        { y: 44, kind: "entry" },
        { y: 38, kind: "stop" },
        { y: 60, kind: "target" },
      ],
    },
  },
  {
    slug: "requin",
    name: "Requin harmonique",
    english: "Shark Pattern",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Variable",
    summary: "Une figure harmonique en cinq points (0-X-A-B-C) reposant sur une extension prononcée.",
    description:
      "Le requin, identifié par Scott Carney, est une figure harmonique plus récente, notée en points 0-X-A-B-C. Sa dernière jambe forme une extension marquée vers une zone de retournement potentielle, souvent suivie d'un mouvement rapide. Elle est jugée agressive et de plus court terme que le Gartley.",
    reading: {
      signal: "Achèvement du point C dans la zone d'extension du requin.",
      entry: "À la réaction du prix au point C.",
      stop: "Au-delà du point C.",
      target: "Retour partiel vers la zone B.",
    },
    scenario: {
      si: "Le prix atteint la zone de retournement du requin et réagit",
      alors: "un rebond de court terme est généralement visé",
      sinon: "un dépassement franc de la zone invalide la figure.",
    },
    spec: {
      bias: "bull",
      closes: [50, 62, 46, 68, 40, 52, 64, 74],
      lines: [{ x1: 0, y1: 50, x2: 0.57, y2: 40, dash: true }],
      levels: [
        { y: 52, kind: "entry" },
        { y: 40, kind: "stop" },
        { y: 70, kind: "target" },
      ],
    },
  },
  {
    slug: "cypher",
    name: "Cypher harmonique",
    english: "Cypher Pattern",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Variable",
    summary: "Une figure harmonique où le point C dépasse A avant un retournement au point D.",
    description:
      "Le cypher est une figure harmonique distinctive : son point C dépasse le point A (au-delà de 100 % de XA), avant que le point D ne se forme par un retracement de la jambe XC. Sa géométrie particulière en fait une figure prisée des adeptes du trading harmonique.",
    reading: {
      signal: "Achèvement du point D par retracement de XC, dans la zone de retournement.",
      entry: "À la réaction du prix au point D.",
      stop: "Sous le point X.",
      target: "Retour vers les points C puis A.",
    },
    scenario: {
      si: "Le point D se forme par retracement de XC et le prix y réagit",
      alors: "un retournement haussier est anticipé",
      sinon: "une cassure sous X invalide le cypher.",
    },
    spec: {
      bias: "bull",
      closes: [44, 60, 50, 66, 42, 54, 66, 76],
      lines: [{ x1: 0, y1: 44, x2: 0.57, y2: 42, dash: true }],
      levels: [
        { y: 54, kind: "entry" },
        { y: 42, kind: "stop" },
        { y: 72, kind: "target" },
      ],
    },
  },
  {
    slug: "trois-indiens",
    name: "Trois Indiens",
    english: "Three Indians",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Trois sommets successifs alignés et de plus en plus hauts, signe d'un achat qui s'épuise.",
    description:
      "La figure des trois Indiens se compose de trois sommets ascendants régulièrement espacés, souvent alignés sur une même droite de tendance. Comme les trois poussées, elle traduit une montée en escalier de plus en plus laborieuse, jusqu'au retournement.",
    reading: {
      signal: "Trois sommets ascendants alignés, puis cassure de la ligne de support.",
      entry: "À la cassure du support reliant les creux.",
      stop: "Au-dessus du troisième sommet.",
      target: "Retour vers la base de la figure.",
    },
    scenario: {
      si: "Le support cède après trois sommets alignés et ascendants",
      alors: "un retournement baissier est généralement privilégié",
      sinon: "un quatrième sommet plus haut relance la hausse.",
    },
    spec: {
      bias: "bear",
      closes: [40, 54, 48, 62, 56, 70, 60, 50, 42, 36],
      lines: [{ x1: 0.05, y1: 54, x2: 0.5, y2: 70, dash: true }],
      levels: [
        { y: 56, kind: "entry" },
        { y: 72, kind: "stop" },
        { y: 38, kind: "target" },
      ],
    },
  },
  {
    slug: "crochet-de-retournement",
    name: "Crochet de Retournement",
    english: "Hook Reversal",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Variable",
    summary: "Le prix enfonce un plus-bas récent puis se retourne et clôture nettement plus haut.",
    description:
      "Le crochet de retournement (hook reversal) se forme quand le cours casse brièvement un plus-bas récent — déclenchant les ventes — puis se retourne avec vigueur pour clôturer au-dessus. Ce faux franchissement, suivi d'un net rebond, dessine un « crochet » caractéristique d'un excès vendeur épuisé.",
    reading: {
      signal: "Cassure d'un plus-bas suivie d'un retournement et d'une clôture nettement plus haute.",
      entry: "À la confirmation du retournement, au-dessus du plus-bas cassé.",
      stop: "Sous le point bas du crochet.",
      target: "Retour vers le haut de la zone de congestion précédente.",
    },
    scenario: {
      si: "Le prix réintègre la zone après avoir enfoncé le plus-bas",
      alors: "un retournement haussier sur excès vendeur est privilégié",
      sinon: "une poursuite de la baisse sous le crochet invalide la figure.",
    },
    spec: {
      bias: "bull",
      closes: [60, 54, 48, 42, 38, 46, 54, 62, 70],
      lines: [{ x1: 0, y1: 42, x2: 1, y2: 42, dash: true }],
      levels: [
        { y: 46, kind: "entry" },
        { y: 38, kind: "stop" },
        { y: 68, kind: "target" },
      ],
    },
  },
  {
    slug: "barre-englobante",
    name: "Barre Englobante (Outside Bar)",
    english: "Outside Bar",
    category: "bilateral",
    bias: "Neutre",
    reliability: "Variable",
    summary: "Une séance dont l'amplitude englobe entièrement la précédente : un sursaut de volatilité.",
    description:
      "La barre englobante (outside bar) est une séance dont le plus-haut dépasse celui de la veille et le plus-bas enfonce celui de la veille : elle « englobe » toute la barre précédente. Elle traduit un regain de volatilité et une lutte acheteurs/vendeurs ; le sens de la clôture et la cassure de ses bornes donnent la direction.",
    reading: {
      signal: "Une barre dont l'amplitude englobe la précédente, puis cassure d'une de ses bornes.",
      entry: "À la cassure du plus-haut (haussier) ou du plus-bas (baissier) de la barre englobante.",
      stop: "De l'autre côté de la barre englobante.",
      target: "Amplitude de la barre reportée dans le sens de la cassure.",
    },
    scenario: {
      si: "Le prix casse le plus-haut de la barre englobante",
      alors: "une accélération haussière est généralement privilégiée",
      sinon: "une cassure du plus-bas oriente au contraire à la baisse.",
    },
    spec: {
      bias: "bull",
      closes: [50, 52, 48, 40, 60, 58, 64, 72],
      lines: [{ x1: 0, y1: 60, x2: 1, y2: 60, dash: true }, { x1: 0, y1: 40, x2: 1, y2: 40, dash: true }],
      levels: [
        { y: 60, kind: "entry" },
        { y: 40, kind: "stop" },
        { y: 78, kind: "target" },
      ],
    },
  },
  {
    slug: "barre-interieure",
    name: "Barre Intérieure (Inside Bar)",
    english: "Inside Bar",
    category: "bilateral",
    bias: "Neutre",
    reliability: "Variable",
    summary: "Une séance entièrement contenue dans la précédente : une pause avant cassure.",
    description:
      "La barre intérieure (inside bar) est une séance dont le plus-haut et le plus-bas tiennent à l'intérieur de la barre précédente. Elle signale une contraction de la volatilité et une indécision, souvent suivie d'une cassure dans un sens ou dans l'autre. C'est un repère de compression très suivi en price-action.",
    reading: {
      signal: "Une barre contenue dans la précédente, puis cassure de la borne de la barre mère.",
      entry: "À la cassure du plus-haut (ou du plus-bas) de la barre englobante précédente.",
      stop: "De l'autre côté de la barre intérieure.",
      target: "Amplitude de la barre mère reportée dans le sens de la cassure.",
    },
    scenario: {
      si: "Le prix casse le plus-haut de la barre mère après l'inside bar",
      alors: "une reprise haussière est généralement privilégiée",
      sinon: "une cassure par le bas oriente la sortie à la baisse.",
    },
    spec: {
      bias: "bull",
      closes: [40, 64, 52, 54, 50, 53, 51, 66, 74],
      lines: [{ x1: 0, y1: 64, x2: 1, y2: 64, dash: true }, { x1: 0, y1: 40, x2: 1, y2: 40, dash: true }],
      levels: [
        { y: 64, kind: "entry" },
        { y: 48, kind: "stop" },
        { y: 82, kind: "target" },
      ],
    },
  },
  {
    slug: "retournement-cle",
    name: "Retournement Clé (Key Reversal)",
    english: "Key Reversal",
    category: "retournement-baissier",
    bias: "Baissier",
    reliability: "Moyenne",
    summary: "Un nouveau plus-haut suivi d'une clôture sous celle de la veille : un retournement net.",
    description:
      "Le retournement clé (key reversal) se forme en haut de tendance : le cours marque un nouveau plus-haut en séance, puis se retourne pour clôturer sous la clôture précédente. Cet échec après un sommet trahit un basculement du rapport de force des acheteurs vers les vendeurs.",
    reading: {
      signal: "Nouveau plus-haut puis clôture sous la clôture de la veille.",
      entry: "À la confirmation, sous le plus-bas de la séance de retournement.",
      stop: "Au-dessus du nouveau plus-haut.",
      target: "Retour vers la base de la tendance haussière précédente.",
    },
    scenario: {
      si: "Le cours échoue à un nouveau plus-haut et clôture nettement plus bas",
      alors: "un retournement baissier est généralement privilégié",
      sinon: "une reprise au-dessus du plus-haut annule le signal.",
    },
    spec: {
      bias: "bear",
      closes: [50, 58, 66, 74, 78, 64, 56, 48, 40],
      lines: [{ x1: 0, y1: 74, x2: 1, y2: 74, dash: true }],
      levels: [
        { y: 64, kind: "entry" },
        { y: 80, kind: "stop" },
        { y: 44, kind: "target" },
      ],
    },
  },
  {
    slug: "catapulte",
    name: "Catapulte",
    english: "Catapult",
    category: "continuation-haussiere",
    bias: "Haussier",
    reliability: "Moyenne",
    summary: "Une cassure, un repli de confirmation sur l'ancienne résistance, puis une accélération.",
    description:
      "La catapulte décrit une séquence en deux temps : le prix casse une résistance, revient la tester par le haut (l'ancienne résistance devenue support tient), puis « catapulte » dans une forte poursuite haussière. C'est un schéma de continuation où le retest réussi sert de tremplin.",
    reading: {
      signal: "Cassure d'une résistance, retest réussi par le haut, puis accélération.",
      entry: "Au rebond sur l'ancienne résistance devenue support.",
      stop: "Sous le niveau de retest.",
      target: "Hauteur de la base reportée au-dessus de la cassure.",
    },
    scenario: {
      si: "Le retest de l'ancienne résistance tient et le prix repart à la hausse",
      alors: "une accélération haussière est généralement privilégiée",
      sinon: "un retour sous l'ancienne résistance invalide la catapulte.",
    },
    spec: {
      bias: "bull",
      closes: [40, 44, 42, 46, 58, 54, 50, 52, 64, 76, 84],
      lines: [{ x1: 0, y1: 48, x2: 1, y2: 48, dash: true }],
      levels: [
        { y: 58, kind: "entry" },
        { y: 48, kind: "stop" },
        { y: 86, kind: "target" },
      ],
    },
  },
  {
    slug: "diamant-de-creux",
    name: "Diamant de Creux",
    english: "Diamond Bottom",
    category: "retournement-haussier",
    bias: "Haussier",
    reliability: "Variable",
    summary: "Un élargissement puis un resserrement en bas de tendance, dessinant un losange.",
    description:
      "Le diamant de creux se forme en fin de tendance baissière : la volatilité s'élargit d'abord (sommets plus hauts, creux plus bas), puis se resserre, dessinant une forme de losange. La cassure de la borne supérieure du diamant signale un retournement haussier potentiel.",
    reading: {
      signal: "Élargissement puis resserrement en losange, suivi d'une cassure haussière.",
      entry: "À la cassure de la borne supérieure du diamant.",
      stop: "Sous le point bas du diamant.",
      target: "Hauteur maximale du losange reportée au-dessus de la cassure.",
    },
    scenario: {
      si: "Le prix casse la borne supérieure du diamant en bas de tendance",
      alors: "un retournement haussier est généralement privilégié",
      sinon: "une cassure par le bas prolonge au contraire la baisse.",
    },
    spec: {
      bias: "bull",
      closes: [60, 50, 56, 44, 52, 38, 46, 40, 50, 60, 72],
      lines: [{ x1: 0.3, y1: 38, x2: 0.7, y2: 46, dash: true }],
      levels: [
        { y: 52, kind: "entry" },
        { y: 38, kind: "stop" },
        { y: 72, kind: "target" },
      ],
    },
  },
];

export const PATTERN_CATEGORIES: { id: PatternCategory | "all"; label: string }[] = [
  { id: "all", label: "Toutes" },
  { id: "retournement-haussier", label: "Retournement haussier" },
  { id: "retournement-baissier", label: "Retournement baissier" },
  { id: "continuation-haussiere", label: "Continuation haussière" },
  { id: "continuation-baissiere", label: "Continuation baissière" },
  { id: "bilateral", label: "Bilatéral" },
];
