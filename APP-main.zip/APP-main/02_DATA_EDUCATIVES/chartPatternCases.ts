/**
 * Cas réels & repères pour chaque figure chartiste — 100% informatif (voix WMB).
 * On illustre la figure par un épisode de marché documenté ou son histoire ;
 * jamais une recommandation. Les figures ne « garantissent » rien : on décrit
 * ce que les analystes ont observé a posteriori.
 */

export type PatternCase = {
  title: string;
  detail: string;
};

export const PATTERN_CASES: Record<string, PatternCase> = {
  "double-creux": {
    title: "Les indices au plus bas de mars 2009",
    detail:
      "Après la chute de la crise financière, plusieurs indices ont dessiné des structures en double creux au premier trimestre 2009 avant le rebond historique entamé le 9 mars. La logique de la figure : les vendeurs testent deux fois un plancher sans le casser, signe que la pression baissière s'épuise. La confirmation ne vient qu'à la cassure de la ligne de cou — jamais sur le simple second creux.",
  },
  "tete-epaules-inversee": {
    title: "Une figure de retournement de référence",
    detail:
      "La tête-épaules inversée est l'une des figures de retournement les plus étudiées depuis les travaux de Richard Schabacker et Robert Edwards & John Magee (« Technical Analysis of Stock Trends », 1948), l'ouvrage fondateur de l'analyse chartiste. Sa symétrie — deux épaules encadrant un creux plus profond — traduit un transfert progressif du contrôle des vendeurs vers les acheteurs.",
  },
  "biseau-descendant": {
    title: "Le piège des apparences",
    detail:
      "Le biseau descendant illustre une subtilité chartiste : une figure dont la pente pointe vers le bas peut être… haussière. Le prix baisse, mais de moins en moins vite (les bornes convergent), signe que les vendeurs s'essoufflent. La cassure se fait le plus souvent par le haut. C'est l'inverse visuel du biseau ascendant, lui réputé baissier.",
  },
  "tasse-avec-anse": {
    title: "William O'Neil et la méthode CANSLIM",
    detail:
      "La tasse avec anse (« cup and handle ») a été popularisée par William O'Neil, fondateur d'Investor's Business Daily, dans son livre « How to Make Money in Stocks » (1988). C'est une pièce maîtresse de sa méthode CANSLIM. La « tasse » est une longue consolidation arrondie ; l'« anse », un léger repli final avant la cassure des sommets.",
  },
  "arrondi-de-fond": {
    title: "La patience des grands planchers",
    detail:
      "L'arrondi de fond (« rounding bottom » ou soucoupe) décrit un retournement lent, sans pic marqué : le contrôle passe graduellement des vendeurs aux acheteurs. C'est une figure de long terme, souvent visible sur des graphiques hebdomadaires d'actions sortant d'années de désintérêt. Sa lenteur même est un gage de solidité quand le support cède enfin.",
  },
  "double-sommet": {
    title: "Le « M » des sommets de marché",
    detail:
      "Le double sommet, en forme de « M », s'observe quand un actif bute deux fois sur un même plafond sans le franchir — signe que les acheteurs n'ont plus la force de pousser plus haut. De nombreux sommets de valeurs technologiques en 2000 et en 2021 ont laissé de telles structures avant des corrections marquées. La confirmation exige la cassure du creux intermédiaire.",
  },
  "tete-epaules": {
    title: "La plus célèbre des figures de retournement",
    detail:
      "La tête-épaules (« head and shoulders ») est sans doute la figure de retournement la plus connue du grand public. Décrite dès la première moitié du XXᵉ siècle, elle se compose de trois sommets, celui du milieu (la tête) dépassant les deux autres (les épaules). La rupture de la ligne de cou, idéalement sur volume, est l'élément que les analystes attendent — pas le simple dessin.",
  },
  "biseau-ascendant": {
    title: "Quand la hausse devient fragile",
    detail:
      "Le biseau ascendant (« rising wedge ») est l'exemple type d'une figure dont l'apparence trompe : le prix monte, mais les bornes convergent et la pente s'essouffle, trahissant un achat de moins en moins vigoureux. Réputé baissier, il apparaît souvent en fin de tendance haussière ou comme rebond technique au sein d'une baisse plus large.",
  },
  "arrondi-de-sommet": {
    title: "Le dôme de la distribution",
    detail:
      "L'arrondi de sommet (« rounding top ») est le miroir de l'arrondi de fond : la hausse s'essouffle doucement, le prix plafonne en dôme, puis glisse. L'absence de pic net traduit une distribution patiente plutôt qu'un retournement brutal. Comme tous les sommets arrondis, il demande de la confirmation (cassure du support de base) avant d'être validé.",
  },
  "drapeau-haussier": {
    title: "La pause dans une impulsion",
    detail:
      "Le drapeau haussier (« bull flag ») est l'une des figures de continuation les plus fréquentes en tendance forte : après une impulsion verticale (le « mât »), le marché digère ses gains dans un petit canal incliné avant de repartir. On l'observe sur tous les horizons, des graphiques 5 minutes des actions « momentum » aux hebdomadaires d'indices en tendance.",
  },
  "fanion-haussier": {
    title: "Le cousin triangulaire du drapeau",
    detail:
      "Le fanion haussier (« bull pennant ») ressemble au drapeau, mais sa consolidation se contracte en petit triangle symétrique. La compression traduit un équilibre temporaire entre acheteurs et vendeurs, juste avant la reprise dans le sens du mât. Comme le drapeau, sa fiabilité dépend de la vigueur de l'impulsion qui le précède.",
  },
  "triangle-ascendant": {
    title: "La pression sous le plafond",
    detail:
      "Le triangle ascendant combine une résistance horizontale et des creux de plus en plus hauts : les acheteurs reviennent toujours plus tôt tandis que le plafond tient. Cette accumulation de pression sous la résistance est interprétée, le plus souvent, comme un biais de continuation haussière — confirmé seulement à la cassure du plafond.",
  },
  "rectangle-haussier": {
    title: "Le range avant la reprise",
    detail:
      "Le rectangle haussier est une consolidation horizontale entre un support et une résistance parallèles, au sein d'une tendance haussière. Acheteurs et vendeurs s'équilibrent un temps, jusqu'à ce que la borne haute cède. La hauteur du rectangle sert classiquement de projection d'objectif au-dessus de la cassure.",
  },
  "drapeau-baissier": {
    title: "Le pendant baissier du drapeau",
    detail:
      "Le drapeau baissier suit une chute verticale (le mât) par une brève consolidation légèrement inclinée à la hausse — un rebond technique qui essouffle avant la reprise de la baisse. On l'observe fréquemment lors des marchés baissiers prolongés, où chaque rebond de soulagement précède une nouvelle jambe de baisse.",
  },
  "triangle-descendant": {
    title: "Le support qui finit par céder",
    detail:
      "Le triangle descendant associe un support horizontal et des sommets de plus en plus bas : les vendeurs reviennent toujours plus tôt tandis que le plancher tient encore. Cette érosion est généralement lue comme un biais de continuation baissière, confirmé à la rupture du support — souvent accompagnée d'une accélération.",
  },
  "rectangle-baissier": {
    title: "La consolidation dans la baisse",
    detail:
      "Le rectangle baissier est une pause horizontale au sein d'une tendance baissière : le prix oscille entre support et résistance parallèles avant que le support ne lâche. Comme son équivalent haussier, sa hauteur fournit une projection d'objectif sous la cassure — une lecture, jamais une garantie.",
  },
  "triangle-symetrique": {
    title: "La compression sans biais",
    detail:
      "Le triangle symétrique voit sommets décroissants et creux croissants converger : la volatilité se comprime, sans biais directionnel a priori. C'est une figure « bilatérale » — la sortie peut se faire d'un côté comme de l'autre, le plus souvent dans le sens de la tendance qui précède. La compression annonce le mouvement, pas son sens.",
  },
  "triple-creux": {
    title: "Trois tests, un plancher solide",
    detail:
      "Le triple creux pousse la logique du double creux plus loin : le marché teste trois fois un même plancher sans le casser. Chaque test absorbe un peu plus de pression vendeuse. Plus rare que le double creux, il est réputé d'autant plus solide quand il aboutit, mais demande la même confirmation : la cassure de la résistance qui coiffe les creux.",
  },
  "triple-sommet": {
    title: "Trois échecs sous le plafond",
    detail:
      "Le triple sommet est l'image inverse : trois tentatives infructueuses de franchir un même plafond. L'incapacité répétée à progresser trahit un essoufflement des acheteurs. La figure n'est validée qu'à la cassure du support reliant les creux — avant cela, ce n'est qu'un range sous résistance.",
  },
  elargissement: {
    title: "Le mégaphone de l'instabilité",
    detail:
      "L'élargissement (« broadening formation » ou mégaphone) dessine des sommets plus hauts et des creux plus bas : la volatilité augmente au lieu de se comprimer. Cette structure traduit une nervosité croissante et une indécision marquée, souvent observée près de sommets de marché agités. C'est une des figures les plus difficiles à exploiter.",
  },
  diamant: {
    title: "Élargissement puis resserrement",
    detail:
      "Le diamant combine une phase d'élargissement (mégaphone) suivie d'un resserrement (triangle), dessinant un losange. Rare, il apparaît surtout au sommet de hausses agitées et est réputé annoncer un retournement. Sa complexité le rend difficile à identifier en temps réel — il est souvent plus net a posteriori.",
  },
  "fanion-baissier": {
    title: "La respiration avant la rechute",
    detail:
      "Le fanion baissier reproduit le schéma du fanion haussier en miroir : après une chute verticale, un petit triangle de consolidation se forme, le temps d'un rebond, avant la reprise de la baisse. On le rencontre dans les phases de capitulation, où chaque pause est suivie d'une nouvelle jambe descendante.",
  },
  "canal-haussier": {
    title: "La tendance bien rangée",
    detail:
      "Le canal haussier (« ascending channel ») décrit une tendance haussière disciplinée, où le prix rebondit régulièrement entre deux obliques parallèles. De longues phases de marchés porteurs ont évolué dans de tels canaux pendant des mois. La rupture de la borne basse est généralement le premier signe d'essoufflement de la tendance.",
  },
  "canal-baissier": {
    title: "La glissade ordonnée",
    detail:
      "Le canal baissier (« descending channel ») est la version baissière : chaque rebond bute sous la borne haute, chaque repli trouve la borne basse. Beaucoup de marchés baissiers prolongés ont glissé dans de tels canaux. Une cassure franche de la borne haute, surtout sur volume, est suivie comme un possible signal de retournement.",
  },
  "v-creux": {
    title: "Le rebond éclair de décembre 2018",
    detail:
      "Fin décembre 2018, après une chute brutale de fin d'année, les indices américains ont rebondi presque verticalement à partir du 26 décembre, dessinant un creux en V sans phase de construction. Ces retournements express, souvent déclenchés par une capitulation suivie d'un choc de nouvelles, sont spectaculaires mais très difficiles à anticiper — d'où leur fiabilité jugée variable.",
  },
  "v-sommet": {
    title: "Les sommets paraboliques",
    detail:
      "Le sommet en V couronne les excès d'euphorie : une hausse parabolique s'achève par un renversement immédiat, sans distribution. Plusieurs valeurs très spéculatives en 2021 ont formé de tels pics avant de s'effondrer aussi vite qu'elles étaient montées. L'absence de signe avant-coureur rend la figure aussi marquante qu'imprévisible.",
  },
  "ile-retournement-haussier": {
    title: "Une île isolée par deux gaps",
    detail:
      "L'île de retournement haussière est rare mais réputée fiable : un gap baissier d'épuisement, puis un gap haussier en sens inverse, « détachent » un petit groupe de séances du reste du graphique, comme une île au plus bas. Les deux fenêtres encadrent un plancher où la pression vendeuse s'est tarie. La présence des deux gaps est l'élément distinctif.",
  },
  "ile-retournement-baissier": {
    title: "L'île au plafond",
    detail:
      "Miroir de la précédente, l'île de retournement baissière se forme au sommet : un gap haussier d'épuisement isole un groupe de séances en hauteur, qu'un gap baissier détache ensuite vers le bas. Les deux fenêtres délimitent un sommet où l'euphorie s'est épuisée. Sa rareté en fait une figure recherchée par les analystes attentifs aux gaps.",
  },
  "fenetre-haussiere": {
    title: "Le gap qui sert de support",
    detail:
      "La fenêtre (gap) haussière de cassure (« breakaway gap ») survient à la sortie d'une consolidation, sur volume élevé : le prix « saute » et laisse une zone vide. Tant qu'elle n'est pas comblée, cette fenêtre agit comme un support et valide la dynamique. Les analystes distinguent ce gap de cassure du gap d'épuisement, qui marque au contraire un excès en fin de mouvement.",
  },
  "bump-and-run": {
    title: "L'excès qui se corrige",
    detail:
      "Le « Bump and Run Reversal » a été formalisé par Thomas Bulkowski, auteur de l'« Encyclopedia of Chart Patterns » (2000), une référence statistique sur les figures. La version de creux décrit une baisse qui s'accélère anormalement (la « bosse », souvent une vente panique) avant de repasser au-dessus de sa ligne de tendance — l'illustration visuelle d'un retour à la moyenne après un excès.",
  },
  "soucoupe-de-sommet": {
    title: "Le dôme patient",
    detail:
      "La soucoupe de sommet (« rounding top ») retourne la tendance sans à-coup : la hausse s'essouffle, le prix plafonne en dôme régulier, puis amorce une baisse graduelle. On la rencontre surtout sur les grands horizons (hebdomadaire, mensuel), où le lent transfert du contrôle des acheteurs vers les vendeurs prend des semaines à se dessiner.",
  },
  "mouvement-mesure-haussier": {
    title: "La symétrie des deux jambes",
    detail:
      "Le mouvement mesuré repose sur une régularité empirique étudiée notamment par Thomas Bulkowski dans son « Encyclopedia of Chart Patterns » : une tendance avance souvent par jambes d'amplitude voisine, séparées par des consolidations. La projection n'est jamais exacte, mais la symétrie offre un objectif de travail plus rigoureux qu'une cible arbitraire — à confirmer par le contexte.",
  },
  "mouvement-mesure-baissier": {
    title: "Le miroir baissier",
    detail:
      "Beaucoup de marchés baissiers prolongés se sont déroulés en jambes successives entrecoupées de rebonds de soulagement, chaque jambe reproduisant grossièrement l'ampleur de la précédente. Le mouvement mesuré baissier formalise cette observation pour projeter un objectif sous le rebond, tout en rappelant qu'une projection reste une hypothèse, pas une certitude.",
  },
  "tuyaux-bas": {
    title: "Les tuyaux de Bulkowski",
    detail:
      "Le motif des « tuyaux » a été décrit et statistiquement étudié par Thomas Bulkowski, qui l'a identifié comme l'un des retournements les plus fiables sur graphique hebdomadaire. Deux longues mèches basses adjacentes traduisent une capitulation aussitôt rejetée. Sa lisibilité dépend fortement de l'unité de temps : il est bien plus net en hebdomadaire qu'en intraday.",
  },
  "tuyaux-haut": {
    title: "Le sommet en deux pics",
    detail:
      "Miroir du tuyaux en bas, le tuyaux en haut marque un sommet par deux longues mèches hautes adjacentes : deux tentatives rapprochées de pousser plus haut, immédiatement rejetées. Comme son équivalent de creux, il a été popularisé par les travaux statistiques de Thomas Bulkowski et se lit surtout sur les grandes unités de temps.",
  },
  "tete-epaules-complexe": {
    title: "Une distribution élaborée",
    detail:
      "La tête-épaules complexe traduit une phase de distribution plus longue qu'une tête-épaules simple : les gros intervenants écoulent leurs positions sur plusieurs vagues, créant des épaules multiples. Décrite dès les travaux fondateurs d'Edwards & Magee, elle reste gouvernée par la même règle : c'est la rupture de la ligne de cou, pas le dessin, qui fait foi.",
  },
  "biseau-elargissant-descendant": {
    title: "La nervosité avant le rebond",
    detail:
      "Le biseau élargissant descendant combine baisse et volatilité croissante — une configuration nerveuse souvent observée en fin de correction. Les études statistiques de Thomas Bulkowski le classent majoritairement comme un retournement haussier, mais avec une fiabilité variable : son amplitude croissante en fait l'une des figures les plus difficiles à exploiter sereinement.",
  },
  "rebond-chat-mort": {
    title: "Le piège des rebonds de 2008",
    detail:
      "Durant la chute de 2008-2009, le marché américain a connu plusieurs rebonds vigoureux de 10 à 20 % qui se sont tous essoufflés avant de nouveaux plus-bas — autant de « rebonds du chat mort ». L'expression, popularisée par les salles de marché, rappelle qu'une reprise spectaculaire après une chute violente n'est pas forcément un retournement : tant que la tendance de fond n'est pas brisée, le rebond peut n'être qu'une respiration technique.",
  },
  "elargissement-ascendant": {
    title: "Le mégaphone, signe de nervosité",
    detail:
      "L'élargissement ascendant traduit un marché dont l'amplitude grandit au lieu de se calmer : chaque sommet et chaque creux sont plus extrêmes que les précédents. Cette « volatilité qui s'emballe » est souvent observée près des fins de tendance euphoriques, quand l'accord entre acheteurs et vendeurs se délite. Thomas Bulkowski en a recensé plusieurs variantes ; toutes partagent une fiabilité variable et une difficulté d'exploitation réputée élevée.",
  },
  "cornes-au-creux": {
    title: "Une variante codifiée par Bulkowski",
    detail:
      "Les figures en « cornes » (Horn) ont été formalisées par l'analyste Thomas Bulkowski à partir d'observations statistiques sur des milliers de graphiques hebdomadaires. Les cornes au creux sont deux piqûres baissières séparées par une seule semaine de répit : l'échec répété à enfoncer le plancher signale, a posteriori, une base de retournement. Comme toute figure, elle ne se valide qu'à la cassure du niveau de référence.",
  },
  "cornes-au-sommet": {
    title: "Le miroir baissier des cornes",
    detail:
      "Les cornes au sommet sont la version inversée : deux pointes haussières séparées par un seul repli, observées en fin de hausse. Comme leur pendant haussier, elles font partie des figures hebdomadaires étudiées par Thomas Bulkowski. Leur logique est intuitive : à deux reprises, les acheteurs échouent à prolonger durablement la hausse au-delà d'un plafond, ce qui précède souvent un retournement — à confirmer par la cassure du creux intermédiaire.",
  },
  "fenetre-baissiere": {
    title: "Les gaps de la théorie des chandeliers japonais",
    detail:
      "La « fenêtre » (mado) est le terme japonais pour un gap dans l'analyse en chandeliers, popularisée en Occident par Steve Nison. La tradition veut qu'« un cours retourne combler ses fenêtres » : un gap baissier non comblé agit comme une résistance lors des rebonds. La logique reste descriptive — le vide de cotation matérialise un déséquilibre vendeur soudain — et ne garantit jamais la poursuite de la baisse.",
  },
  "gap-de-rupture": {
    title: "La classification des gaps d'Edwards & Magee",
    detail:
      "L'ouvrage fondateur « Technical Analysis of Stock Trends » (Edwards & Magee, 1948) distingue trois gaps : de rupture (breakaway), de continuation (runaway) et d'épuisement (exhaustion). Le gap de rupture marque la sortie d'une congestion et, lorsqu'il s'accompagne de volume, signale souvent le début d'un mouvement. L'ancienne résistance franchie est ensuite censée jouer le rôle de support — un principe d'observation, pas une certitude.",
  },
  "gap-d-epuisement": {
    title: "Le dernier souffle d'une tendance",
    detail:
      "Le gap d'épuisement, troisième catégorie d'Edwards & Magee, se distingue par son comblement rapide : là où le gap de rupture ouvre un mouvement, celui d'épuisement le referme. Les analystes le lisent comme l'ultime accélération d'un marché à bout de souffle, où les derniers acheteurs entrent au plus mauvais moment. Seul le comblement du gap valide a posteriori cette lecture de retournement.",
  },
  "drapeau-serre": {
    title: "La figure rare de Thomas Bulkowski",
    detail:
      "Dans ses études statistiques (« Encyclopedia of Chart Patterns »), Thomas Bulkowski classe le « high and tight flag » parmi les figures de continuation les plus performantes — mais aussi les plus rares. Le critère est strict : une hausse d'environ 90 % ou plus en deux mois, suivie d'une consolidation brève et peu profonde. Sa rareté impose la prudence : la plupart des « drapeaux serrés » supposés n'en respectent pas les conditions.",
  },
  "trois-poussees": {
    title: "Une figure harmonique d'épuisement",
    detail:
      "La figure des trois poussées (« three drives ») appartient au répertoire de l'analyse harmonique, où chaque poussée est censée respecter des proportions de Fibonacci. Au-delà des ratios, l'idée pédagogique est universelle : trois sommets ascendants au momentum déclinant trahissent un achat qui demande toujours plus d'efforts pour des gains décroissants — un signe classique d'essoufflement, à confirmer par la cassure du support.",
  },
  "scallop-ascendant": {
    title: "Les cuvettes en escalier de Bulkowski",
    detail:
      "Thomas Bulkowski a catalogué les « scallops » (ascendants et descendants) comme des cuvettes arrondies en forme de J qui s'enchaînent souvent dans une tendance de fond. Le scallop ascendant débute plus haut à chaque cycle, traduisant une reprise graduelle du contrôle par les acheteurs. La forme arrondie, sans cassure nette, en fait une figure de fiabilité variable : elle décrit une dynamique plus qu'elle ne déclenche un signal précis.",
  },
  "scallop-descendant": {
    title: "Le miroir baissier du scallop",
    detail:
      "Le scallop descendant complète la paire répertoriée par Thomas Bulkowski : un dôme arrondi en J inversé qui se referme plus bas qu'il n'a commencé. Dans une tendance baissière de fond, ces bosses s'enchaînent en escalier vers le bas. Comme son pendant haussier, il décrit une transition graduelle du rapport de force — ici vers les vendeurs — plutôt qu'un signal tranché, d'où sa fiabilité jugée variable.",
  },
  "vagues-de-wolfe": {
    title: "La géométrie de Bill Wolfe",
    detail:
      "Les vagues de Wolfe ont été popularisées par le trader Bill Wolfe, qui y voyait l'expression d'un « équilibre naturel » des marchés en cinq pivots. La figure projette une cible via la ligne reliant les vagues 1 et 4. Très exigeante sur la symétrie et l'emplacement des pivots, elle illustre l'approche géométrique de l'analyse technique — séduisante sur le papier, mais sujette à interprétation, d'où une fiabilité variable.",
  },
  "ab-cd": {
    title: "La brique de l'analyse harmonique",
    detail:
      "L'AB=CD descend des travaux de H. M. Gartley (1935) et a été affiné par Larry Pesavento puis Scott Carney avec les ratios de Fibonacci. C'est le motif élémentaire dont dérivent les figures harmoniques plus complexes. Son principe — la jambe CD reproduit l'ampleur de la jambe AB — en fait un repère de symétrie. Comme toute figure harmonique, sa lecture reste probabiliste et gagne à être confirmée par d'autres signaux.",
  },
  "gartley": {
    title: "La figure de 1935 codifiée par Fibonacci",
    detail:
      "Décrite par H. M. Gartley dans « Profits in the Stock Market » (1935), la figure dite « Gartley 222 » (du numéro de la page) a été précisée plus tard par l'ajout de ratios de Fibonacci stricts (B à 61,8 % de XA, D à 78,6 %). Elle reste la référence des figures harmoniques. Sa force vient de la convergence de plusieurs ratios au point D, mais son identification exige de la rigueur et reste sujette à interprétation.",
  },
  "piege-haussier": {
    title: "Le coût des fausses cassures",
    detail:
      "Le « bull trap » est l'un des pièges les plus documentés de l'analyse technique : une cassure de résistance qui échoue et se retourne. Les fausses cassures sont fréquentes près des niveaux très suivis, où l'afflux d'ordres au franchissement crée un pic vite résorbé. La leçon classique, déjà soulignée par Edwards & Magee, est d'attendre une confirmation (clôture, volume, retest) plutôt que de poursuivre une cassure à l'aveugle.",
  },
  "piege-baissier": {
    title: "Le ressort des cassures avortées",
    detail:
      "Le « bear trap » est le symétrique du piège haussier : une cassure de support qui ne tient pas et se retourne à la hausse. Richard Wyckoff décrivait déjà ce type de « spring » — un faux franchissement destiné, dans sa lecture, à déclencher les stops avant le vrai mouvement. Sans prêter d'intention au marché, la leçon est la même : une cassure non confirmée peut se transformer en piège, et la prudence prime sur la précipitation.",
  },
  "papillon": {
    title: "L'extension harmonique de Gilmore et Pesavento",
    detail:
      "Le papillon a été développé par Bryce Gilmore et popularisé par Larry Pesavento dans ses travaux sur les ratios de Fibonacci appliqués aux marchés. Sa particularité — un point D qui dépasse l'origine X — vise les retournements après un mouvement étiré. Comme toutes les figures harmoniques, c'est un cadre probabiliste : la convergence des ratios désigne une zone à surveiller, jamais une certitude.",
  },
  "crabe": {
    title: "La découverte de Scott Carney",
    detail:
      "Le crabe a été identifié par Scott Carney, figure de référence de l'analyse harmonique et auteur de « Harmonic Trading ». Il le considérait comme l'une de ses découvertes les plus précises, grâce à l'extension extrême du point D (161,8 % de XA) qui permet un stop serré relativement à l'objectif. Sa profondeur en fait une figure spectaculaire mais exigeante, à manier avec confirmation.",
  },
  "trois-vallees-ascendantes": {
    title: "La logique des planchers relevés",
    detail:
      "Les trois vallées ascendantes traduisent une idée simple et robuste de l'analyse technique : une succession de creux de plus en plus hauts signale une demande qui se renforce. Thomas Bulkowski a recensé ce type de structures parmi les configurations de retournement. La force du signal tient moins à la figure elle-même qu'à ce qu'elle révèle — des acheteurs qui interviennent toujours plus tôt.",
  },
  "trois-sommets-descendants": {
    title: "Le miroir baissier des planchers relevés",
    detail:
      "Symétriques des trois vallées ascendantes, les trois sommets descendants montrent une offre croissante : à chaque rebond, les vendeurs reprennent la main plus tôt, abaissant les plafonds. C'est la traduction visuelle d'un rapport de force qui bascule. Comme son pendant haussier, la figure ne vaut que confirmée par la cassure du support qui la soutient.",
  },
  "tasse-sans-anse": {
    title: "La variante directe de William O'Neil",
    detail:
      "La tasse avec anse a été codifiée par William O'Neil dans sa méthode CANSLIM ; la version sans anse en est la variante où la cassure intervient directement, sans la petite consolidation latérale. Plus immédiate, elle est aussi parfois jugée un peu moins fiable, faute du « test » que constitue l'anse. La forme arrondie du fond reste l'élément clé : elle traduit une accumulation patiente.",
  },
  "quasimodo": {
    title: "La rupture de structure du price-action moderne",
    detail:
      "Le Quasimodo (« QM » ou « Over-and-Under ») est un motif popularisé par les communautés modernes de price-action et de smart money. Au-delà du nom, il décrit une idée classique : un nouveau plus-haut suivi de la cassure du creux précédent rompt la séquence de hauts et de bas ascendants — une « rupture de structure ». C'est une lecture du changement de mains, à confirmer comme toute figure par le contexte global.",
  },
  "chauve-souris": {
    title: "L'harmonique précise de Scott Carney",
    detail:
      "La chauve-souris a été formalisée par Scott Carney, qui l'a intégrée à son cadre du « Harmonic Trading » avec des ratios de Fibonacci stricts (point D à 88,6 % de XA). Sa zone de retournement serrée séduit ceux qui recherchent un risque maîtrisé. Comme toute figure harmonique, elle décrit une probabilité géométrique, jamais une certitude.",
  },
  "requin": {
    title: "Une figure harmonique récente",
    detail:
      "Le requin fait partie des figures harmoniques plus récentes ajoutées par Scott Carney. Notée en points 0-X-A-B-C, elle se distingue par une extension agressive et un horizon plus court. Sa réputation de réactivité s'accompagne d'une exigence : sans confirmation, ces géométries restent sujettes à interprétation.",
  },
  "cypher": {
    title: "La géométrie atypique du cypher",
    detail:
      "Le cypher se distingue des autres harmoniques par son point C qui dépasse le point A, suivi d'un point D obtenu par retracement de la jambe XC. Cette construction particulière en fait une figure appréciée des praticiens du trading harmonique, qui y voient un signal de retournement précis — toujours à valider par le contexte de marché.",
  },
  "trois-indiens": {
    title: "Trois sommets, un même essoufflement",
    detail:
      "La figure des trois Indiens partage la logique des trois poussées : une montée en escalier où chaque sommet demande plus d'efforts. Alignés sur une droite, ces trois pics traduisent un achat qui se vide progressivement. Comme toujours, c'est la cassure du support — et non le simple comptage des sommets — qui confirme le retournement.",
  },
  "crochet-de-retournement": {
    title: "Le faux franchissement qui piège les vendeurs",
    detail:
      "Le crochet de retournement repose sur une mécanique classique : un plus-bas est brièvement enfoncé, déclenchant les stops et les ventes, avant un retournement vigoureux. Ce « spring » à la Wyckoff illustre comment un excès vendeur, une fois purgé, peut précéder un net rebond — d'où l'importance d'attendre la clôture qui confirme le crochet.",
  },
  "barre-englobante": {
    title: "Le sursaut de volatilité de la price-action",
    detail:
      "La barre englobante (outside bar) est un classique de l'analyse en price-action : une séance qui dépasse à la fois le haut et le bas de la précédente traduit une bataille intense entre acheteurs et vendeurs. Le sens de la clôture et la cassure de ses bornes orientent la lecture — la figure seule ne préjuge pas de la direction.",
  },
  "barre-interieure": {
    title: "La compression qui précède la cassure",
    detail:
      "La barre intérieure (inside bar) est l'un des motifs les plus suivis en price-action : une séance contenue dans la précédente signale une contraction de la volatilité, souvent annonciatrice d'une cassure. Très utilisée comme déclencheur d'entrée, elle gagne en fiabilité lorsqu'elle apparaît à un niveau clé (support, résistance).",
  },
  "retournement-cle": {
    title: "Le sommet qui se referme d'un coup",
    detail:
      "Le retournement clé (key reversal) est un signal de retournement classique des manuels d'analyse technique : un nouveau plus-haut suivi d'une clôture sous la veille marque un basculement net du rapport de force. Sa force tient à l'échec spectaculaire au sommet, mais il demande confirmation — un seul jour ne fait pas toujours une tendance.",
  },
  "catapulte": {
    title: "Le retest qui sert de tremplin",
    detail:
      "La catapulte illustre un principe fondateur de l'analyse technique : une résistance franchie devient un support. Le retest réussi de l'ancienne borne, avant l'accélération, est souvent considéré comme l'une des entrées les plus fiables — car il confirme que la cassure n'était pas un faux signal.",
  },
  "diamant-de-creux": {
    title: "Le losange rare des fins de baisse",
    detail:
      "Le diamant de creux est une figure peu fréquente, recensée notamment par Thomas Bulkowski, qui combine une phase d'élargissement (volatilité croissante) puis de resserrement, dessinant un losange. Sa rareté et sa complexité de tracé la rendent difficile à exploiter ; sa cassure haussière, en bas de tendance, reste le signal déterminant.",
  },
};

export function getPatternCase(slug: string): PatternCase | undefined {
  return PATTERN_CASES[slug];
}
