/**
 * Cas réels & repères historiques pour chaque indicateur — 100% informatif (voix WMB).
 * Objectif : ancrer chaque indicateur dans un fait concret (origine, créateur,
 * épisode de marché marquant). Aucune recommandation : on illustre, on n'oriente pas.
 */

export type IndicatorCase = {
  /** Titre court de l'encadré. */
  title: string;
  /** Cas réel développé (origine, créateur, épisode daté). */
  detail: string;
};

export const INDICATOR_CASES: Record<string, IndicatorCase> = {
  "moyennes-mobiles": {
    title: "Le « golden cross » de 2023",
    detail:
      "Fin janvier 2023, la moyenne mobile à 50 jours du S&P 500 est repassée au-dessus de sa moyenne à 200 jours — un « golden cross » très commenté dans la presse financière. L'inverse, le « death cross », s'était produit en mars 2022 avant une année de baisse. Ces croisements sont des photographies retardées de la tendance, pas des signaux avancés : ils confirment ce qui s'est déjà produit.",
  },
  ichimoku: {
    title: "Un journaliste japonais, 30 ans de travail",
    detail:
      "L'Ichimoku Kinko Hyo (« graphique d'équilibre en un coup d'œil ») a été conçu par Goichi Hosoda, journaliste financier japonais, qui a passé près de trois décennies à le calibrer avec une équipe d'assistants avant de le publier en 1969. C'est l'un des rares systèmes complets pensés dès l'origine pour donner tendance, momentum et supports d'un seul regard.",
  },
  adx: {
    title: "Wilder et le livre fondateur de 1978",
    detail:
      "L'ADX a été présenté par J. Welles Wilder dans « New Concepts in Technical Trading Systems » (1978), le même ouvrage qui a introduit le RSI, l'ATR et le Parabolic SAR. Wilder était ingénieur en mécanique avant de devenir analyste : son approche systématique a façonné l'analyse technique moderne. L'ADX reste la référence pour distinguer un marché en tendance d'un marché en range.",
  },
  supertrend: {
    title: "Un indicateur né de l'ATR",
    detail:
      "Le SuperTrend s'appuie entièrement sur l'Average True Range (volatilité) pour placer sa ligne de suivi. Popularisé dans les années 2000, il illustre une idée clé : un stop suiveur doit respirer au rythme de la volatilité. En période agitée (l'ATR gonfle), la ligne s'éloigne du prix pour éviter d'être touchée par le bruit ; en marché calme, elle se resserre.",
  },
  rsi: {
    title: "Le RSI au sommet du Nasdaq (mars 2000)",
    detail:
      "Au plus fort de la bulle Internet, en mars 2000, le Nasdaq affichait des niveaux de RSI hebdomadaire durablement au-dessus de 70 (surachat), tandis que le momentum réel s'essoufflait — une divergence classique. Le RSI a été créé par J. Welles Wilder en 1978. Leçon récurrente : en tendance puissante, un actif peut rester « suracheté » très longtemps ; le seuil de 70 seul ne suffit jamais.",
  },
  macd: {
    title: "Gerald Appel, fin des années 1970",
    detail:
      "Le MACD a été mis au point par Gerald Appel, gérant et auteur américain, à la fin des années 1970. Son génie : superposer deux moyennes mobiles (12 et 26 périodes) et leur écart pour visualiser à la fois la tendance et son accélération. L'histogramme, ajouté plus tard par Thomas Aspray (1986), a rendu les changements de momentum lisibles d'un coup d'œil.",
  },
  stochastique: {
    title: "George Lane et la fourchette des prix",
    detail:
      "L'oscillateur stochastique a été développé par George Lane dans les années 1950. Son intuition : lors d'une hausse, les clôtures tendent à se faire près du plus haut de la séance ; lors d'une baisse, près du plus bas. L'indicateur mesure exactement cette position de la clôture dans la fourchette récente — d'où sa sensibilité aux excès de court terme.",
  },
  bollinger: {
    title: "John Bollinger et le « squeeze »",
    detail:
      "John Bollinger a conçu ses bandes dans les années 1980 en remplaçant la largeur fixe des enveloppes par deux écarts-types, donc une largeur qui respire avec la volatilité. Son observation la plus citée — le « squeeze » : quand les bandes se resserrent à l'extrême (volatilité comprimée), une expansion suit souvent. Le resserrement ne dit jamais le sens de la sortie, seulement qu'un mouvement se prépare.",
  },
  atr: {
    title: "L'ATR pendant le krach COVID (mars 2020)",
    detail:
      "En mars 2020, l'effondrement lié au COVID a fait exploser l'ATR de la plupart des actifs : le S&P 500 enchaînait des séances à ±9 %, et le VIX a culminé à 82,69 le 16 mars — un record. L'ATR, créé par Wilder en 1978, ne dit rien de la direction, mais ce pic signalait qu'il fallait des stops bien plus larges et des positions bien plus petites pour un même risque.",
  },
  obv: {
    title: "Joseph Granville, 1963",
    detail:
      "L'On-Balance Volume a été popularisé par Joseph Granville dans son livre de 1963. Son principe : « le volume précède le prix ». En cumulant le volume des séances haussières et en retranchant celui des baissières, l'OBV cherche à révéler si les gros intervenants accumulent ou distribuent avant que le prix ne bouge franchement.",
  },
  vwap: {
    title: "Le repère d'exécution des institutionnels",
    detail:
      "Le VWAP est né du besoin des gérants institutionnels de mesurer la qualité de leur exécution : acheter en dessous du prix moyen pondéré par le volume de la journée, c'est « battre le marché » sur la séance. C'est devenu un benchmark standard du trading algorithmique, utilisé chaque jour par les desks pour découper de gros ordres sans déformer le marché.",
  },
  "williams-r": {
    title: "Larry Williams, champion de trading",
    detail:
      "Le %R porte le nom de Larry Williams, trader américain resté célèbre pour avoir transformé 10 000 $ en plus d'un million lors du championnat Robbins World Cup de trading en 1987. Son oscillateur est un proche cousin du stochastique, inversé sur une échelle de −100 à 0, pensé pour repérer rapidement les excès de court terme.",
  },
  cci: {
    title: "Donald Lambert, 1980",
    detail:
      "Le Commodity Channel Index a été présenté par Donald Lambert dans le magazine « Commodities » en 1980. Conçu à l'origine pour les matières premières (d'où son nom), il mesure l'écart du prix à sa moyenne en unités de déviation. Il s'est depuis généralisé à tous les marchés : actions, indices, devises. Au-delà de ±100, le mouvement est jugé puissant ou excessif.",
  },
  roc: {
    title: "La vitesse pure, sans habillage",
    detail:
      "Le Rate of Change est l'un des plus anciens et des plus simples oscillateurs de momentum : la variation du prix en pourcentage sur N séances. Sa lecture la plus instructive est la divergence — quand un indice fait de nouveaux sommets mais que son ROC s'affaiblit, la hausse perd de la vitesse, un signe d'essoufflement souvent observé avant les grands retournements.",
  },
  keltner: {
    title: "Chester Keltner (1960), revisité par Linda Raschke",
    detail:
      "Les canaux portent le nom de Chester Keltner, qui les a décrits en 1960. La version moderne, fondée sur l'ATR plutôt que sur l'amplitude des séances, a été popularisée par la trader Linda Bradford Raschke. Différence clé avec Bollinger : la largeur dépend de la volatilité réelle (ATR), ce qui rend une sortie de bande plus parlante comme accélération de tendance.",
  },
  "awesome-oscillator": {
    title: "Bill Williams et la « théorie du chaos »",
    detail:
      "L'Awesome Oscillator fait partie de la boîte à outils de Bill Williams, trader américain qui a tenté d'appliquer la théorie du chaos aux marchés dans les années 1990. Il compare une moyenne de 5 et une de 34 périodes calculées sur le point médian des bougies. Sa lecture en barres colorées (croissantes/décroissantes) en a fait un classique des plateformes modernes.",
  },
  trix: {
    title: "Jack Hutson, début des années 1980",
    detail:
      "Le TRIX a été développé par Jack Hutson, fondateur du magazine « Technical Analysis of Stocks & Commodities », au début des années 1980. Son triple lissage exponentiel a un but précis : éliminer les cycles plus courts que la période choisie, pour ne garder que le momentum de fond et réduire le nombre de faux signaux dans le bruit quotidien.",
  },
  donchian: {
    title: "Donchian et l'expérience des « Turtles » (1983)",
    detail:
      "Richard Donchian, surnommé le « père du suivi de tendance », a formalisé ses canaux dès les années 1950. Trois décennies plus tard, en 1983, Richard Dennis et William Eckhardt ont parié qu'ils pouvaient enseigner le trading à des novices : leurs « Turtle Traders » utilisaient des cassures de canaux de Donchian (20 et 55 jours). L'expérience a généré des centaines de millions de dollars et est devenue une légende du trading systématique.",
  },
  "enveloppes-mm": {
    title: "L'ancêtre des bandes de volatilité",
    detail:
      "Les enveloppes de moyennes mobiles, à largeur fixe en pourcentage, précèdent historiquement les bandes de Bollinger et les canaux de Keltner. C'est en cherchant à rendre cette largeur adaptative que John Bollinger a eu l'idée d'utiliser l'écart-type dans les années 1980. Les enveloppes restent appréciées pour leur simplicité sur des actifs au comportement régulier.",
  },
  dema: {
    title: "Patrick Mulloy, 1994",
    detail:
      "La Double Exponential Moving Average a été présentée par Patrick Mulloy dans un article de « Technical Analysis of Stocks & Commodities » en 1994. Son objectif explicite : combattre le retard (« lag ») inhérent à toute moyenne mobile. La formule (2·EMA − EMA de l'EMA) colle davantage au prix, au prix de quelques signaux supplémentaires en marché agité.",
  },
  aroon: {
    title: "Tushar Chande, 1995",
    detail:
      "L'Aroon (« lumière de l'aube » en sanskrit) a été créé par Tushar Chande en 1995. L'idée est originale : au lieu de mesurer le prix, il mesure le temps écoulé depuis le dernier plus haut et le dernier plus bas. L'indicateur cherche ainsi à détecter la naissance d'une tendance plus tôt que les oscillateurs classiques fondés sur les variations de prix.",
  },
  "parabolic-sar": {
    title: "Le « Stop and Reverse » de Wilder (1978)",
    detail:
      "Le Parabolic SAR (Stop And Reverse) est une autre invention de J. Welles Wilder (1978). Son principe : les points se rapprochent du prix en accélérant tant que la tendance dure (le facteur d'accélération augmente à chaque nouvel extrême), puis basculent de l'autre côté au retournement. C'est un stop suiveur visuel, redoutable en tendance forte mais générateur de faux signaux en marché plat.",
  },
  momentum: {
    title: "La brique de base de tous les oscillateurs",
    detail:
      "Le Momentum, simple différence entre le prix actuel et celui d'il y a N séances, est le socle conceptuel dont dérivent le ROC, le MACD et la plupart des oscillateurs. Sa lecture par divergence est universelle : lors du sommet du Nasdaq en 2000 comme avant bien d'autres retournements, le prix montait encore alors que le momentum, lui, avait déjà commencé à fléchir.",
  },
  ppo: {
    title: "Le MACD rendu comparable",
    detail:
      "Le Percentage Price Oscillator résout une limite du MACD : exprimé en valeur absolue, un MACD de 2 ne signifie pas la même chose sur une action à 20 € que sur une à 2 000 €. En ramenant l'écart des moyennes en pourcentage, le PPO permet de comparer le momentum entre actifs de prix très différents — utile pour classer un panier de valeurs.",
  },
  "volatilite-historique": {
    title: "Du prix des options au « VIX »",
    detail:
      "La volatilité historique (écart-type des rendements) est la mesure de risque qui sous-tend le modèle de Black-Scholes (1973), récompensé par le prix Nobel d'économie 1997. Sa cousine implicite, dérivée du prix des options, est synthétisée par le VIX du CBOE depuis 1993 — le fameux « indice de la peur » qui a atteint 82,69 en mars 2020 et 80,86 lors de la crise de 2008.",
  },
  "bollinger-bandwidth": {
    title: "Mesurer le « squeeze » de Bollinger",
    detail:
      "Le Bandwidth est l'outil que John Bollinger a ajouté pour quantifier précisément le « squeeze » : il ramène l'écartement des bandes en pourcentage de la moyenne. Quand le Bandwidth touche un plus bas de plusieurs mois, la volatilité est comprimée à l'extrême — une situation observée avant de nombreuses cassures, sans que la direction soit jamais garantie à l'avance.",
  },
  "percent-b": {
    title: "Le complément quantitatif des bandes",
    detail:
      "Le %B, également proposé par John Bollinger, transforme une lecture visuelle (« le prix touche-t-il la bande ? ») en chiffre exploitable : 1 au contact de la bande haute, 0 sur la bande basse. Il rend programmables des stratégies fondées sur Bollinger et facilite la détection de divergences, quand le prix fait un nouveau sommet mais que le %B, lui, reste en retrait.",
  },
  mfi: {
    title: "Quong et Soudack : le RSI du volume",
    detail:
      "Le Money Flow Index a été développé par Gene Quong et Avrum Soudack. On le surnomme le « RSI pondéré par le volume » : il applique la logique du RSI (échelle 0-100, seuils 80/20) mais en intégrant les volumes échangés. Une divergence MFI/prix est jugée plus robuste qu'une divergence RSI, car elle tient compte de l'argent réellement engagé derrière le mouvement.",
  },
  "oscillateur-volume": {
    title: "La participation, juge de paix des cassures",
    detail:
      "L'oscillateur de volume formalise une règle ancienne de l'analyse technique : une cassure de prix n'est crédible que si le volume l'accompagne. En comparant une moyenne courte et une moyenne longue des volumes, il met en évidence les accélérations de participation. Une sortie de figure sur volume déclinant (oscillateur négatif) est, à l'inverse, classiquement considérée comme suspecte.",
  },
  cmo: {
    title: "Tushar Chande, 1994",
    detail:
      "Le Chande Momentum Oscillator a été présenté par Tushar Chande, ingénieur et auteur, dans son livre « The New Technical Trader » (1994), coécrit avec Stanley Kroll. Son idée : améliorer le RSI en supprimant le lissage, pour un oscillateur plus pur et plus réactif. Chande est aussi l'inventeur de l'Aroon et de l'indice de variabilité, signe d'une approche très quantitative du momentum.",
  },
  coppock: {
    title: "Edwin Coppock et Barron's (1962)",
    detail:
      "La courbe a été conçue par l'économiste Edwin Coppock, qui l'a publiée dans le magazine Barron's en 1962. Détail célèbre : Coppock aurait demandé à des évêques combien de temps il fallait pour se remettre d'un deuil — environ 11 à 14 mois — et s'en est inspiré pour les périodes de son indicateur, assimilant les creux de marché à un deuil collectif à surmonter.",
  },
  dpo: {
    title: "Isoler le cycle, retirer la tendance",
    detail:
      "Le Detrended Price Oscillator répond à un besoin précis de l'analyse cyclique : étudier la durée des cycles sans être gêné par la tendance de fond. En comparant le prix à une moyenne mobile décalée dans le passé, il « aplatit » la tendance pour ne laisser apparaître que les oscillations. C'est un outil d'étude des cycles davantage qu'un générateur de signaux.",
  },
  kst: {
    title: "Martin Pring, le « Know Sure Thing »",
    detail:
      "Le KST a été développé par Martin Pring, auteur de référence en analyse technique (« Technical Analysis Explained »). Son principe : aucun taux de variation isolé n'est fiable, alors il en combine quatre, de périodes différentes, chacun lissé et pondéré selon son importance. Le nom, mi-sérieux, traduit l'ambition d'un signal de momentum plus robuste que ses composants pris séparément.",
  },
  "force-index": {
    title: "Alexander Elder, 1993",
    detail:
      "Le Force Index figure dans « Trading for a Living » (1993) d'Alexander Elder, psychiatre devenu trader. Sa logique en trois ingrédients : le sens du mouvement (hausse ou baisse), son ampleur (de combien) et le volume (avec quelle participation). Elder recommandait de le lisser pour distinguer la pression de fond du bruit quotidien.",
  },
  cmf: {
    title: "Marc Chaikin et la position de clôture",
    detail:
      "Le Chaikin Money Flow porte le nom de Marc Chaikin, analyste américain également à l'origine de l'oscillateur de Chaikin. Son intuition : la position de la clôture dans la fourchette du jour révèle qui domine. Une clôture près du plus haut, sur fort volume, traduit de l'accumulation ; près du plus bas, de la distribution. Le CMF cumule cette information sur plusieurs séances.",
  },
  vortex: {
    title: "Botes & Siepman, 2010",
    detail:
      "L'indicateur Vortex est relativement récent : il a été présenté par Etienne Botes et Douglas Siepman dans la revue « Technical Analysis of Stocks & Commodities » en 2010. Inspirés des mouvements en tourbillon observés dans la nature par Viktor Schauberger, ils ont construit deux lignes (VI+ et VI−) capturant les mouvements haussiers et baissiers ; leur croisement signale les changements de tendance.",
  },
  "mass-index": {
    title: "Donald Dorsey, 1992",
    detail:
      "Le Mass Index a été conçu par Donald Dorsey et publié dans « Technical Analysis of Stocks & Commodities » en 1992. Son originalité : il ignore totalement la direction du prix pour ne suivre que l'élargissement de l'amplitude des séances. Dorsey a observé qu'un gonflement marqué de l'amplitude (le « reversal bulge ») précédait souvent les retournements, indépendamment du sens du marché.",
  },
  tema: {
    title: "Patrick Mulloy contre le retard, 1994",
    detail:
      "La TEMA (et sa cousine la DEMA) a été présentée par Patrick Mulloy dans « Technical Analysis of Stocks & Commodities » en 1994, dans un article intitulé « Smoothing Data with Faster Moving Averages ». Son obsession : réduire le retard inhérent à toute moyenne mobile sans réintroduire de bruit. Le triple lissage astucieux de la TEMA en a fait un classique pour les opérateurs qui veulent coller à la tendance sans subir le délai d'une EMA simple.",
  },
  "hull-ma": {
    title: "Alan Hull, 2005",
    detail:
      "La moyenne de Hull a été mise au point par l'Australien Alan Hull en 2005. Son idée : combiner plusieurs moyennes pondérées pour obtenir une courbe à la fois rapide ET lisse — deux qualités habituellement contradictoires. La HMA est devenue populaire car elle « tourne » nettement aux retournements, ce qui aide l'œil à repérer les bascules de tendance, tout en restant suffisamment propre pour ne pas multiplier les faux signaux.",
  },
  "ultimate-oscillator": {
    title: "Larry Williams, 1976",
    detail:
      "L'Ultimate Oscillator a été créé par Larry Williams et présenté en 1976. Williams voulait corriger un défaut des oscillateurs classiques : leur dépendance à une seule période, source de fausses divergences. Sa solution : combiner trois horizons (court, moyen, long) en une seule courbe pondérée. Larry Williams reste célèbre pour avoir, lors d'un championnat de trading en 1987, transformé 10 000 $ en plus d'un million — un exploit autant qu'un avertissement sur le risque pris.",
  },
  "stochastic-rsi": {
    title: "Chande & Kroll, 1994",
    detail:
      "Le Stochastic RSI a été introduit par Tushar Chande et Stanley Kroll dans leur livre « The New Technical Trader » (1994). Leur constat : le RSI passe parfois de longues périodes sans atteindre ses zones extrêmes de 30 ou 70. En lui appliquant la formule du stochastique, ils ont créé un indicateur bien plus sensible, qui sature plus souvent — au prix d'une nervosité accrue qui exige de filtrer par la tendance de fond.",
  },
  "fisher-transform": {
    title: "John Ehlers et le traitement du signal",
    detail:
      "La transformée de Fisher a été popularisée en analyse technique par John Ehlers, ingénieur en traitement du signal passé par l'aérospatiale, dans les années 2000. Son idée, empruntée aux mathématiques : les prix ne suivent pas une loi normale, mais on peut les y ramener par une transformation. Le résultat fait ressortir les retournements avec une netteté que peu d'oscillateurs atteignent — une belle illustration de l'apport des sciences de l'ingénieur à la finance de marché.",
  },
  rvi: {
    title: "John Ehlers encore, années 2000",
    detail:
      "Le Relative Vigor Index a été formalisé par John Ehlers au début des années 2000. Il repose sur une intuition de bon sens, vérifiée empiriquement : dans une tendance haussière, les marchés tendent à clôturer plus haut qu'ils n'ont ouvert, et inversement en tendance baissière. Le RVI quantifie cette « vigueur » et la lisse — une manière élégante de mesurer qui, des acheteurs ou des vendeurs, finit les séances en position de force.",
  },
  "accumulation-distribution": {
    title: "Marc Chaikin et la lecture du volume",
    detail:
      "La ligne d'Accumulation/Distribution a été développée par Marc Chaikin, analyste américain de Wall Street, dans les années 1970-80. Son principe : le volume seul ne suffit pas, il faut le pondérer par la position de la clôture dans la fourchette du jour. Une clôture près du plus-haut sur fort volume = accumulation ; près du plus-bas = distribution. C'est l'un des premiers outils à avoir tenté de « lire » les intentions des gros intervenants à travers le volume.",
  },
  "chaikin-oscillator": {
    title: "La dérivée du flux, signée Chaikin",
    detail:
      "L'oscillateur de Chaikin, également de Marc Chaikin, applique à sa ligne d'Accumulation/Distribution la logique du MACD : la différence entre une moyenne courte et une moyenne longue. On obtient ainsi non plus le niveau du flux d'argent, mais son accélération. Chaikin, qui a passé des décennies à Wall Street avant de fonder sa propre société d'analyse, cherchait à repérer les changements de flux avant qu'ils ne deviennent visibles sur le prix.",
  },
  "choppiness-index": {
    title: "E. W. Dreiss et la théorie du chaos",
    detail:
      "L'indice de Choppiness a été conçu par le trader australien E. W. Dreiss, qui s'est inspiré de concepts issus de la théorie du chaos et de la géométrie fractale. Plutôt que de prédire une direction, Dreiss voulait répondre à une question préalable, souvent négligée : le marché est-il seulement en train de suivre une tendance, ou se contente-t-il de zigzaguer ? Cette distinction conditionne le choix même des outils à employer ensuite.",
  },
  "elder-ray": {
    title: "Alexander Elder, « Trading for a Living » (1993)",
    detail:
      "L'Elder-Ray a été présenté par le Dr Alexander Elder, psychiatre devenu trader, dans son best-seller « Trading for a Living » (1993). Le nom évoque les rayons X : l'outil cherche à « voir sous la surface » du marché la force respective des acheteurs (Bull Power) et des vendeurs (Bear Power) autour d'une moyenne. Formé à la psychologie, Elder a beaucoup insisté sur le fait que les marchés sont avant tout mus par des émotions humaines mesurables.",
  },
  "pivot-points": {
    title: "Des parquets aux écrans",
    detail:
      "Les points pivots viennent des traders « à la criée » qui, avant l'informatique, calculaient chaque matin à la main quelques niveaux clés à partir des plus-haut, plus-bas et clôture de la veille. Simples et objectifs, ils restent très utilisés en intraday : comme beaucoup d'opérateurs regardent les mêmes niveaux, ceux-ci deviennent des zones où le prix réagit souvent — une prophétie en partie autoréalisatrice.",
  },
  "alligator": {
    title: "Bill Williams et la psychologie du marché",
    detail:
      "L'Alligator a été conçu par Bill Williams, pionnier de l'analyse intégrant le chaos et la psychologie de marché, dans les années 1990. Sa métaphore animale est volontaire : l'alligator « dort » quand les trois moyennes s'entremêlent (marché sans tendance, où il faut patienter) et « se réveille » pour « manger » quand elles s'écartent (tendance installée). Une façon imagée de rappeler que l'essentiel du temps, le marché ne tend pas.",
  },
  "regression-lineaire": {
    title: "La statistique au service du graphique",
    detail:
      "La droite de régression linéaire applique la méthode des moindres carrés — un outil statistique du XIXᵉ siècle — au prix : elle trace la droite qui passe « au plus près » de tous les points. Sa pente résume la tendance de fond sans le bruit des oscillations, et les écarts du prix à cette droite servent de base aux canaux de régression et aux mesures de retour à la moyenne.",
  },
  "ease-of-movement": {
    title: "Richard Arms, l'homme du volume",
    detail:
      "L'Ease of Movement a été développé par Richard Arms, analyste célèbre pour ses travaux liant prix et volume (on lui doit aussi l'« Arms Index »). Son idée : un prix qui monte sur faible volume bouge « facilement », signe de santé ; un prix qui exige un volume énorme pour avancer rencontre de la résistance. L'EOM cherche à capter cette facilité de déplacement.",
  },
  "balance-of-power": {
    title: "Igor Livshin, 2001",
    detail:
      "Le Balance of Power a été présenté par Igor Livshin dans « Technical Analysis of Stocks & Commodities » en 2001. Sa logique est limpide : en rapportant l'écart clôture-ouverture à l'amplitude de la séance, il mesure qui, des acheteurs ou des vendeurs, a réellement tenu les rênes — indépendamment de la taille du mouvement.",
  },
  "accelerator-oscillator": {
    title: "Bill Williams, la dérivée du momentum",
    detail:
      "L'Accelerator Oscillator est un autre outil de Bill Williams, pensé comme complément de son Awesome Oscillator. L'intuition : avant qu'un prix ne change de direction, c'est sa vitesse qui ralentit d'abord. En mesurant l'accélération (et non le niveau) du momentum, l'AC vise à repérer les essoufflements un cran plus tôt — à confirmer, car la précocité a un prix : davantage de faux signaux.",
  },
  "tsi": {
    title: "William Blau, 1991",
    detail:
      "Le True Strength Index a été présenté par William Blau dans « Technical Analysis of Stocks & Commodities » en 1991. Son idée : appliquer un double lissage au momentum pour conserver l'information de tendance tout en gommant le bruit qui rend les oscillateurs classiques si nerveux. Le résultat est une courbe lisible qui oscille autour de zéro, prisée pour les croisements et les divergences.",
  },
  "klinger-oscillator": {
    title: "Stephen Klinger",
    detail:
      "L'oscillateur de Klinger, conçu par Stephen Klinger, cherche à concilier deux objectifs souvent opposés : être assez sensible pour capter les retournements de court terme, tout en restant fidèle aux tendances de fond du flux d'argent. Il y parvient en pondérant le volume par le sens du mouvement, puis en comparant deux moyennes de ce « volume orienté ».",
  },
  "disparity-index": {
    title: "Une mesure née de l'analyse japonaise",
    detail:
      "L'indice de disparité, popularisé notamment par les analystes japonais, répond à une question simple : de combien de pour cent le prix s'écarte-t-il de sa moyenne mobile ? Cette normalisation en pourcentage permet de comparer l'« étirement » d'un cours dans le temps et d'un actif à l'autre, et d'objectiver les notions de surachat et de survente.",
  },
  "qstick": {
    title: "Tushar Chande",
    detail:
      "Le Qstick a été créé par Tushar Chande, également à l'origine du CMO et co-auteur du Stochastic RSI. Son principe est d'une grande simplicité : moyenner l'écart entre clôture et ouverture sur plusieurs séances pour quantifier la « couleur dominante » des bougies. Au-dessus de zéro, les vertes l'emportent ; en dessous, les rouges — une lecture directe du rapport de force.",
  },
  "pretty-good-oscillator": {
    title: "Mark Johnson",
    detail:
      "Le Pretty Good Oscillator a été développé par Mark Johnson. Son originalité tient à la normalisation par l'ATR : plutôt que de mesurer l'écart du prix à sa moyenne en valeur absolue, il l'exprime en « nombre d'ATR ». Un mouvement devient ainsi comparable quelle que soit la volatilité de l'actif, ce qui aide à repérer les déplacements vraiment exceptionnels.",
  },
};

export function getIndicatorCase(slug: string): IndicatorCase | undefined {
  return INDICATOR_CASES[slug];
}
