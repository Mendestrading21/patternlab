/**
 * Bibliothèque d'indicateurs techniques — données 100% éducatives (voix WMB).
 * Les courbes sont calculées à partir d'une série de prix de démonstration,
 * pour des schémas réalistes. On décrit ce que l'indicateur mesure et comment
 * il se lit — jamais un signal d'achat/vente.
 */
import type { IndicatorSpec } from "@/components/IndicatorChart";

export type IndicatorFamily = "tendance" | "momentum" | "volatilite" | "volume";

export type Indicator = {
  slug: string;
  name: string;
  english: string;
  family: IndicatorFamily;
  summary: string;
  measures: string;
  reading: string;
  scenario: { si: string; alors: string; sinon: string };
  spec: IndicatorSpec;
};

export const FAMILY_LABELS: Record<IndicatorFamily, { label: string; color: string }> = {
  tendance: { label: "Tendance", color: "#344453" },
  momentum: { label: "Momentum", color: "#2E7D5B" },
  volatilite: { label: "Volatilité", color: "#D4A853" },
  volume: { label: "Volume", color: "#7A6A5A" },
};

export const INDICATOR_FAMILIES: { id: IndicatorFamily | "all"; label: string }[] = [
  { id: "all", label: "Tous" },
  { id: "tendance", label: "Tendance" },
  { id: "momentum", label: "Momentum" },
  { id: "volatilite", label: "Volatilité" },
  { id: "volume", label: "Volume" },
];

// ─── Série de prix de démonstration + helpers de calcul ───
// Série volontairement « réaliste » : tendance haussière avec replis, pour
// que les bougies générées alternent vert/rouge comme un vrai graphique.
function mulberry32Local(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
// Génère une série de prix DIFFÉRENTE pour chaque indicateur (via seed) :
// niveau de départ, tendance, volatilité, amplitude et phase tous variables —
// ainsi aucun schéma de bougies n'est identique à un autre.
function genSeries(seed: number): number[] {
  const rand = mulberry32Local((seed * 1009 + 7) >>> 0);
  const n = 28;
  const start = 34 + Math.floor(rand() * 34);
  const drift = (rand() - 0.42) * 1.7;
  const vol = 1 + rand() * 3.2;
  const amp = 3 + rand() * 11;
  const period = 4 + rand() * 9;
  const phase = rand() * 6.283;
  const out: number[] = [];
  let v = start;
  for (let i = 0; i < n; i++) {
    v += drift + (rand() - 0.5) * vol * 2;
    const cyc = Math.sin((i / period) * Math.PI * 2 + phase) * amp * 0.25;
    out.push(Math.round(Math.max(9, v + cyc) * 10) / 10);
  }
  return out;
}

function makeBundle(seed: number) {
  const PRICE = genSeries(seed);

const sma = (a: number[], n: number) =>
  a.map((_, i) => {
    const s = a.slice(Math.max(0, i - n + 1), i + 1);
    return s.reduce((x, y) => x + y, 0) / s.length;
  });
const ema = (a: number[], n: number) => {
  const k = 2 / (n + 1);
  const o: number[] = [];
  a.forEach((v, i) => o.push(i === 0 ? v : v * k + o[i - 1] * (1 - k)));
  return o;
};
const stdev = (a: number[], n: number) =>
  a.map((_, i) => {
    const s = a.slice(Math.max(0, i - n + 1), i + 1);
    const m = s.reduce((x, y) => x + y, 0) / s.length;
    return Math.sqrt(s.reduce((x, y) => x + (y - m) ** 2, 0) / s.length);
  });
const rsi = (a: number[], n: number) => {
  const out: number[] = [];
  let g = 0;
  let l = 0;
  a.forEach((v, i) => {
    if (i === 0) {
      out.push(50);
      return;
    }
    const d = v - a[i - 1];
    g = (g * (n - 1) + Math.max(0, d)) / n;
    l = (l * (n - 1) + Math.max(0, -d)) / n;
    const rs = l === 0 ? 100 : g / l;
    out.push(100 - 100 / (1 + rs));
  });
  return out;
};
const stoch = (a: number[], n: number) =>
  a.map((_, i) => {
    const s = a.slice(Math.max(0, i - n + 1), i + 1);
    const lo = Math.min(...s);
    const hi = Math.max(...s);
    return hi === lo ? 50 : ((a[i] - lo) / (hi - lo)) * 100;
  });
const atr = (a: number[], n: number) => sma(a.map((v, i) => (i === 0 ? 0 : Math.abs(v - a[i - 1]))), n);

// dérivés réutilisés
const ema4 = ema(PRICE, 4);
const ema9 = ema(PRICE, 9);
const macd = ema4.map((v, i) => v - ema9[i]);
const macdSignal = ema(macd, 4);
const macdHist = macd.map((v, i) => v - macdSignal[i]);
const sma5 = sma(PRICE, 5);
const std5 = stdev(PRICE, 5);
const atr3 = atr(PRICE, 3);
const mom = sma(PRICE.map((v, i) => (i === 0 ? 0 : Math.abs(v - PRICE[i - 1]))), 4);
const obv: number[] = [0];
for (let i = 1; i < PRICE.length; i++) obv.push(obv[i - 1] + (PRICE[i] > PRICE[i - 1] ? 1 : PRICE[i] < PRICE[i - 1] ? -1 : 0) * (2 + (i % 3)));
const vwap = PRICE.map((_, i) => {
  const s = PRICE.slice(0, i + 1);
  return s.reduce((x, y) => x + y, 0) / s.length;
});
const williams = stoch(PRICE, 7).map((v) => v - 100);
const cci = PRICE.map((_, i) => {
  const s = PRICE.slice(Math.max(0, i - 7 + 1), i + 1);
  const m = s.reduce((a, b) => a + b, 0) / s.length;
  const md = s.reduce((a, b) => a + Math.abs(b - m), 0) / s.length;
  return md === 0 ? 0 : Math.max(-200, Math.min(200, (PRICE[i] - m) / (0.015 * md)));
});
const roc = PRICE.map((_, i) => (i < 4 ? 0 : (PRICE[i] / PRICE[i - 4] - 1) * 100));
const keltMid = ema(PRICE, 5);
const keltUpper = keltMid.map((v, i) => v + atr3[i] * 1.6);
const keltLower = keltMid.map((v, i) => v - atr3[i] * 1.6);
const ao = sma(PRICE, 3).map((v, i) => v - sma(PRICE, 8)[i]);
const trixEma = ema(ema(ema(PRICE, 3), 3), 3);
const trix = trixEma.map((v, i) => (i === 0 ? 0 : (v / trixEma[i - 1] - 1) * 100));

// ─── Dérivés supplémentaires pour les nouveaux indicateurs ───
// Volume synthétique (réaliste : plus de volume sur les fortes variations).
const VOL = PRICE.map((v, i) => (i === 0 ? 10 : 8 + Math.abs(v - PRICE[i - 1]) * 2 + (i % 4)));
// Donchian : plus haut / plus bas mobiles sur 5.
const rollMax = (a: number[], n: number) => a.map((_, i) => Math.max(...a.slice(Math.max(0, i - n + 1), i + 1)));
const rollMin = (a: number[], n: number) => a.map((_, i) => Math.min(...a.slice(Math.max(0, i - n + 1), i + 1)));
const donUpper = rollMax(PRICE, 5);
const donLower = rollMin(PRICE, 5);
const donMid = donUpper.map((v, i) => (v + donLower[i]) / 2);
// Enveloppes de moyenne mobile (±4,5 %).
const envMid = sma(PRICE, 5);
const envUp = envMid.map((v) => v * 1.045);
const envLo = envMid.map((v) => v * 0.955);
// DEMA = 2·EMA − EMA(EMA).
const ema5d = ema(PRICE, 5);
const dema = ema5d.map((v, i) => 2 * v - ema(ema5d, 5)[i]);
// Aroon (oscillateur) sur 6 : positionne le plus récent haut/bas dans la fenêtre.
const aroonOsc = PRICE.map((_, i) => {
  const n = 6;
  const s = PRICE.slice(Math.max(0, i - n + 1), i + 1);
  const hiIdx = s.lastIndexOf(Math.max(...s));
  const loIdx = s.lastIndexOf(Math.min(...s));
  const up = (hiIdx / (s.length - 1 || 1)) * 100;
  const dn = (loIdx / (s.length - 1 || 1)) * 100;
  return up - dn;
});
// Écart-type « plein » (volatilité absolue) sur 5.
const stdFull = stdev(PRICE, 5);
// Largeur de bande de Bollinger (Bandwidth) en %.
const bbw = sma5.map((v, i) => (v === 0 ? 0 : (4 * std5[i] / v) * 100));
// %B : position du prix dans les bandes de Bollinger (0 = bande basse, 1 = bande haute).
const bbUp = sma5.map((v, i) => v + 2 * std5[i]);
const bbLo = sma5.map((v, i) => v - 2 * std5[i]);
const pctB = PRICE.map((v, i) => {
  const w = bbUp[i] - bbLo[i];
  return w === 0 ? 0.5 : (v - bbLo[i]) / w;
});
// Money Flow Index (n=6) avec volume synthétique.
const mfi = PRICE.map((_, i) => {
  const n = 6;
  let pos = 0;
  let neg = 0;
  for (let j = Math.max(1, i - n + 1); j <= i; j++) {
    const raw = PRICE[j] * VOL[j];
    if (PRICE[j] > PRICE[j - 1]) pos += raw;
    else if (PRICE[j] < PRICE[j - 1]) neg += raw;
  }
  if (neg === 0) return 100;
  const mr = pos / neg;
  return 100 - 100 / (1 + mr);
});
// Oscillateur de volume : SMA courte − SMA longue du volume.
const volOsc = sma(VOL, 3).map((v, i) => v - sma(VOL, 6)[i]);
// Momentum brut (prix − prix il y a 4 séances).
const momRaw = PRICE.map((v, i) => (i < 4 ? 0 : v - PRICE[i - 4]));
// PPO (Percentage Price Oscillator) : MACD en pourcentage, plus comparable.
const ppo = ema4.map((v, i) => (ema9[i] === 0 ? 0 : ((v - ema9[i]) / ema9[i]) * 100));
const ppoSignal = ema(ppo, 4);
const ppoHist = ppo.map((v, i) => v - ppoSignal[i]);
// Parabolic SAR (version simplifiée pédagogique) : points de suivi sous/au-dessus du prix.
const psar = (() => {
  const out: number[] = [PRICE[0] - 2];
  let up = true;
  let af = 0.02;
  let ep = PRICE[0];
  let sar = PRICE[0] - 2;
  for (let i = 1; i < PRICE.length; i++) {
    sar = sar + af * (ep - sar);
    if (up) {
      if (PRICE[i] > ep) { ep = PRICE[i]; af = Math.min(0.2, af + 0.02); }
      if (PRICE[i] < sar) { up = false; sar = ep; ep = PRICE[i]; af = 0.02; }
    } else {
      if (PRICE[i] < ep) { ep = PRICE[i]; af = Math.min(0.2, af + 0.02); }
      if (PRICE[i] > sar) { up = true; sar = ep; ep = PRICE[i]; af = 0.02; }
    }
    out.push(sar);
  }
  return out;
})();

// ─── Dérivés pour 8 indicateurs supplémentaires ───
const HIGH = PRICE.map((v, i) => v + 0.9 + (i % 3) * 0.5);
const LOW = PRICE.map((v, i) => v - 0.9 - ((i + 1) % 3) * 0.5);
const rocN = (n: number) => PRICE.map((v, i) => (i < n ? 0 : (v / PRICE[i - n] - 1) * 100));
const rollSum = (a: number[], n: number) => a.map((_, i) => a.slice(Math.max(0, i - n + 1), i + 1).reduce((x, y) => x + y, 0));
// Chande Momentum Oscillator (n=7)
const cmo = PRICE.map((_, i) => {
  const n = 7;
  let up = 0;
  let dn = 0;
  for (let j = Math.max(1, i - n + 1); j <= i; j++) {
    const d = PRICE[j] - PRICE[j - 1];
    if (d > 0) up += d;
    else dn += -d;
  }
  const s = up + dn;
  return s === 0 ? 0 : ((up - dn) / s) * 100;
});
// Coppock (somme de deux ROC, lissée)
const coppock = ema(rocN(6).map((v, i) => v + rocN(4)[i]), 6);
// DPO — Detrended Price Oscillator (décalage 3)
const dpo = PRICE.map((v, i) => v - sma5[Math.max(0, i - 3)]);
// KST — Know Sure Thing (somme pondérée de ROC lissés) + signal
const kst = ema(rocN(4), 3).map((v, i) => v + 2 * ema(rocN(6), 3)[i] + 3 * ema(rocN(8), 4)[i]);
const kstSignal = ema(kst, 4);
// Force Index (variation × volume, lissée)
const forceIndex = ema(PRICE.map((v, i) => (i === 0 ? 0 : (v - PRICE[i - 1]) * VOL[i])), 4);
// Chaikin Money Flow (n=6)
const cmf = PRICE.map((_, i) => {
  const n = 6;
  let mfv = 0;
  let vol = 0;
  for (let j = Math.max(0, i - n + 1); j <= i; j++) {
    const range = HIGH[j] - LOW[j];
    const mult = range === 0 ? 0 : ((PRICE[j] - LOW[j]) - (HIGH[j] - PRICE[j])) / range;
    mfv += mult * VOL[j];
    vol += VOL[j];
  }
  return vol === 0 ? 0 : mfv / vol;
});
// Vortex (n=5) : différence VI+ − VI−
const trArr = PRICE.map((_, i) => (i === 0 ? HIGH[i] - LOW[i] : Math.max(HIGH[i] - LOW[i], Math.abs(HIGH[i] - PRICE[i - 1]), Math.abs(LOW[i] - PRICE[i - 1]))));
const vmPlus = PRICE.map((_, i) => (i === 0 ? 0 : Math.abs(HIGH[i] - LOW[i - 1])));
const vmMinus = PRICE.map((_, i) => (i === 0 ? 0 : Math.abs(LOW[i] - HIGH[i - 1])));
const trSum5 = rollSum(trArr, 5);
const vortexDiff = rollSum(vmPlus, 5).map((v, i) => (trSum5[i] === 0 ? 0 : (v - rollSum(vmMinus, 5)[i]) / trSum5[i]));
// Mass Index
const hlRange = HIGH.map((v, i) => v - LOW[i]);
const hlEma1 = ema(hlRange, 3);
const hlEma2 = ema(hlEma1, 3);
const massIndex = rollSum(hlEma1.map((v, i) => (hlEma2[i] === 0 ? 1 : v / hlEma2[i])), 5);

// ─── Dérivés pour 11 indicateurs supplémentaires ───
// Moyenne mobile pondérée linéairement (WMA) : poids croissants vers le présent.
const wma = (a: number[], n: number) =>
  a.map((_, i) => {
    const s = a.slice(Math.max(0, i - n + 1), i + 1);
    let num = 0;
    let den = 0;
    s.forEach((v, k) => { const w = k + 1; num += v * w; den += w; });
    return den === 0 ? a[i] : num / den;
  });
// Hull Moving Average (HMA) : WMA(2·WMA(n/2) − WMA(n), √n) — très réactive, peu de retard.
const hmaHalf = wma(PRICE, 3);
const hmaFull = wma(PRICE, 6);
const hmaRaw = hmaHalf.map((v, i) => 2 * v - hmaFull[i]);
const hma = wma(hmaRaw, 3);
// TEMA : 3·EMA − 3·EMA(EMA) + EMA(EMA(EMA)) — triple lissage, retard réduit.
const temaE1 = ema(PRICE, 5);
const temaE2 = ema(temaE1, 5);
const temaE3 = ema(temaE2, 5);
const tema = temaE1.map((v, i) => 3 * v - 3 * temaE2[i] + temaE3[i]);
// ADX (force de tendance, n=5) via mouvement directionnel +DI / −DI.
const plusDM = PRICE.map((_, i) => {
  if (i === 0) return 0;
  const up = HIGH[i] - HIGH[i - 1];
  const dn = LOW[i - 1] - LOW[i];
  return up > dn && up > 0 ? up : 0;
});
const minusDM = PRICE.map((_, i) => {
  if (i === 0) return 0;
  const up = HIGH[i] - HIGH[i - 1];
  const dn = LOW[i - 1] - LOW[i];
  return dn > up && dn > 0 ? dn : 0;
});
const trSumAdx = rollSum(trArr, 5);
const diPlus = rollSum(plusDM, 5).map((v, i) => (trSumAdx[i] === 0 ? 0 : (100 * v) / trSumAdx[i]));
const diMinus = rollSum(minusDM, 5).map((v, i) => (trSumAdx[i] === 0 ? 0 : (100 * v) / trSumAdx[i]));
const dx = diPlus.map((v, i) => { const s = v + diMinus[i]; return s === 0 ? 0 : (100 * Math.abs(v - diMinus[i])) / s; });
const adx = ema(dx, 5);
// Ultimate Oscillator (Larry Williams) : pression acheteuse sur 3 horizons (3/5/7), 0–100.
const bpUO = PRICE.map((_, i) => (i === 0 ? 0 : PRICE[i] - Math.min(LOW[i], PRICE[i - 1])));
const trUO = PRICE.map((_, i) => (i === 0 ? HIGH[i] - LOW[i] : Math.max(HIGH[i], PRICE[i - 1]) - Math.min(LOW[i], PRICE[i - 1])));
const avgUO = (np: number) => rollSum(bpUO, np).map((v, i) => { const t = rollSum(trUO, np)[i]; return t === 0 ? 0 : v / t; });
const uo = avgUO(3).map((a3, i) => ((4 * a3 + 2 * avgUO(5)[i] + avgUO(7)[i]) / 7) * 100);
// Stochastic RSI (n=5 sur un RSI 7) : 0–100, plus nerveux que le RSI.
const rsi7 = rsi(PRICE, 7);
const stochRsi = rsi7.map((_, i) => {
  const s = rsi7.slice(Math.max(0, i - 5 + 1), i + 1);
  const lo = Math.min(...s);
  const hi = Math.max(...s);
  return hi === lo ? 50 : ((rsi7[i] - lo) / (hi - lo)) * 100;
});
// Fisher Transform : « gaussianise » le prix pour des extrêmes plus nets.
const fisher = (() => {
  const out: number[] = [];
  let val = 0;
  let fish = 0;
  PRICE.forEach((_, i) => {
    const s = PRICE.slice(Math.max(0, i - 5 + 1), i + 1);
    const hi = Math.max(...s);
    const lo = Math.min(...s);
    const raw = hi === lo ? 0 : 2 * ((PRICE[i] - lo) / (hi - lo)) - 1;
    val = Math.max(-0.999, Math.min(0.999, 0.33 * raw + 0.67 * val));
    fish = 0.5 * Math.log((1 + val) / (1 - val)) + 0.5 * fish;
    out.push(fish);
  });
  return out;
})();
// Relative Vigor Index (RVI) : vigueur d'une séance (clôture vs ouverture, ici approximée).
const coRvi = PRICE.map((v, i) => v - (i > 0 ? PRICE[i - 1] : v));
const rvi = rollSum(coRvi, 4).map((v, i) => { const hl = rollSum(hlRange, 4)[i]; return hl === 0 ? 0 : v / hl; });
// Ligne d'Accumulation/Distribution (ADL) : flux cumulé volume × position dans la séance.
const adl = (() => {
  const o: number[] = [];
  let cum = 0;
  PRICE.forEach((_, i) => {
    const r = HIGH[i] - LOW[i];
    const m = r === 0 ? 0 : ((PRICE[i] - LOW[i]) - (HIGH[i] - PRICE[i])) / r;
    cum += m * VOL[i];
    o.push(cum);
  });
  return o;
})();
// Oscillateur de Chaikin : EMA(ADL,3) − EMA(ADL,10), accélération du flux.
const chaikinOsc = ema(adl, 3).map((v, i) => v - ema(adl, 10)[i]);
// Indice de Choppiness : marché en range (haut) vs en tendance (bas), 0–100.
const chop = PRICE.map((_, i) => {
  const n = 6;
  if (i < n - 1) return 50;
  let trsum = 0;
  for (let j = i - n + 1; j <= i; j++) trsum += trArr[j];
  const hh = Math.max(...HIGH.slice(i - n + 1, i + 1));
  const ll = Math.min(...LOW.slice(i - n + 1, i + 1));
  const rng = hh - ll;
  return rng <= 0 ? 50 : (100 * Math.log10(trsum / rng)) / Math.log10(n);
});
// Elder-Ray : Bull Power (haut − EMA) et Bear Power (bas − EMA), force des camps.
const elderEma = ema(PRICE, 8);
const bullPower = HIGH.map((v, i) => v - elderEma[i]);
const bearPower = LOW.map((v, i) => v - elderEma[i]);
  // ─── Dérivés pour 6 indicateurs supplémentaires ───
  // Pivot points classiques (niveaux horizontaux à partir de l'amplitude de la série)
  const pivP = (Math.max(...HIGH) + Math.min(...LOW) + PRICE[PRICE.length - 1]) / 3;
  const pivotMid = PRICE.map(() => pivP);
  const pivotR1 = PRICE.map(() => 2 * pivP - Math.min(...LOW));
  const pivotS1 = PRICE.map(() => 2 * pivP - Math.max(...HIGH));
  // Alligator de Williams (SMMA approximées par SMA) : mâchoire / dents / lèvres
  const alliJaw = sma(PRICE, 8);
  const alliTeeth = sma(PRICE, 5);
  const alliLips = sma(PRICE, 3);
  // Droite de régression linéaire (moindres carrés) sur PRICE
  const linreg = (() => {
    const n2 = PRICE.length;
    let sx = 0, sy = 0, sxy = 0, sxx = 0;
    PRICE.forEach((y, i) => { sx += i; sy += y; sxy += i * y; sxx += i * i; });
    const slope = (n2 * sxy - sx * sy) / (n2 * sxx - sx * sx || 1);
    const intercept = (sy - slope * sx) / n2;
    return PRICE.map((_, i) => intercept + slope * i);
  })();
  // Ease of Movement (EOM), lissé
  const eom = sma(PRICE.map((_, i) => {
    if (i === 0) return 0;
    const dm = (HIGH[i] + LOW[i]) / 2 - (HIGH[i - 1] + LOW[i - 1]) / 2;
    const range = HIGH[i] - LOW[i];
    const boxRatio = range === 0 ? 0 : (VOL[i] / 10) / range;
    return boxRatio === 0 ? 0 : dm / boxRatio;
  }), 4);
  // Balance of Power (BOP), lissé (ouverture ≈ clôture précédente)
  const bop = ema(PRICE.map((v, i) => { const r = HIGH[i] - LOW[i]; return r === 0 ? 0 : (v - (i > 0 ? PRICE[i - 1] : v)) / r; }), 4);
  // Accelerator Oscillator (AC) = AO − SMA(AO,5)
  const accel = ao.map((v, i) => v - sma(ao, 5)[i]);
  // ─── Dérivés pour 5 indicateurs de niche ───
  // True Strength Index (TSI) : momentum doublement lissé
  const tsiMom = PRICE.map((v, i) => (i === 0 ? 0 : v - PRICE[i - 1]));
  const tsiNum = ema(ema(tsiMom, 8), 4);
  const tsiDen = ema(ema(tsiMom.map((v) => Math.abs(v)), 8), 4);
  const tsi = tsiNum.map((v, i) => (tsiDen[i] === 0 ? 0 : (100 * v) / tsiDen[i]));
  // Klinger Volume Oscillator (version simplifiée)
  const klingerVF = PRICE.map((v, i) => (i > 0 && v > PRICE[i - 1] ? 1 : -1) * VOL[i]);
  const klinger = ema(klingerVF, 5).map((v, i) => v - ema(klingerVF, 13)[i]);
  // Disparity Index : écart en % du prix à sa moyenne mobile
  const disparity = PRICE.map((v, i) => (sma5[i] === 0 ? 0 : ((v - sma5[i]) / sma5[i]) * 100));
  // Qstick : moyenne de (clôture − ouverture), ouverture ≈ clôture précédente
  const qstick = ema(PRICE.map((v, i) => v - (i > 0 ? PRICE[i - 1] : v)), 5);
  // Pretty Good Oscillator : écart prix/SMA rapporté à l'ATR lissé
  const atrEma = ema(atr3, 5);
  const pgo = PRICE.map((v, i) => (atrEma[i] === 0 ? 0 : (v - sma5[i]) / atrEma[i]));
  // ─── Dérivés pour 5 indicateurs supplémentaires ───
  // Z-Score du prix : écart au cours moyen, exprimé en nombre d'écarts-types (fenêtre 20)
  const sma20 = sma(PRICE, 20);
  const std20 = stdev(PRICE, 20);
  const zscore = PRICE.map((v, i) => (std20[i] === 0 ? 0 : (v - sma20[i]) / std20[i]));
  // Vertical Horizontal Filter (VHF) : amplitude nette / somme des variations absolues (tendance vs range)
  const vhfHH = rollMax(HIGH, 14);
  const vhfLL = rollMin(LOW, 14);
  const vhf = PRICE.map((_, i) => {
    if (i < 14) return 0.4;
    let denom = 0;
    for (let k = i - 13; k <= i; k++) denom += Math.abs(PRICE[k] - PRICE[k - 1]);
    return denom === 0 ? 0 : Math.abs(vhfHH[i] - vhfLL[i]) / denom;
  });
  // Gator Oscillator : écartement des mâchoires de l'Alligator (lignes serrées = sommeil)
  const gatorSpread = alliJaw.map((v, i) => { const a = [v, alliTeeth[i], alliLips[i]]; return Math.max(...a) - Math.min(...a); });
  // Schaff Trend Cycle (STC) : double stochastique du MACD, lissé (cycle 0-100)
  const stcStoch = (arr: number[], n: number) => { const mx = rollMax(arr, n), mn = rollMin(arr, n); return arr.map((v, i) => (mx[i] - mn[i] === 0 ? 50 : (100 * (v - mn[i])) / (mx[i] - mn[i]))); };
  const stc = ema(stcStoch(ema(stcStoch(macd, 10), 3), 10), 3);
  // Canal de régression : droite des moindres carrés ± 2 écarts-types
  const regHi = linreg.map((v, i) => v + 2 * stdFull[i]);
  const regLo = linreg.map((v, i) => v - 2 * stdFull[i]);
  // ─── Dérivés pour 5 indicateurs supplémentaires (lot 2) ───
  // KAMA : moyenne adaptative de Kaufman (lissage piloté par l'efficience du marché)
  const kama = (() => {
    const erP = 10, fast = 2 / (2 + 1), slow = 2 / (30 + 1);
    const out = [PRICE[0]];
    for (let i = 1; i < PRICE.length; i++) {
      const start = Math.max(0, i - erP);
      const change = Math.abs(PRICE[i] - PRICE[start]);
      let vol = 0;
      for (let k = start + 1; k <= i; k++) vol += Math.abs(PRICE[k] - PRICE[k - 1]);
      const er = vol === 0 ? 0 : change / vol;
      const sc = (er * (fast - slow) + slow) ** 2;
      out.push(out[i - 1] + sc * (PRICE[i] - out[i - 1]));
    }
    return out;
  })();
  // GMMA : groupes de moyennes courtes (3/5/8) et longues (10/13/16)
  const gmmaShortA = ema(PRICE, 3), gmmaShortB = ema(PRICE, 8), gmmaLongA = ema(PRICE, 10), gmmaLongB = ema(PRICE, 16);
  // APO : oscillateur de prix absolu (EMA rapide − EMA lente, en valeur)
  const apo = ema(PRICE, 6).map((v, i) => v - ema(PRICE, 13)[i]);
  // DeMarker : pression acheteuse/vendeuse via les nouveaux plus-hauts/plus-bas
  const deMax = PRICE.map((_, i) => (i > 0 ? Math.max(0, HIGH[i] - HIGH[i - 1]) : 0));
  const deMin = PRICE.map((_, i) => (i > 0 ? Math.max(0, LOW[i - 1] - LOW[i]) : 0));
  const deMaxS = sma(deMax, 14), deMinS = sma(deMin, 14);
  const demarker = deMaxS.map((v, i) => (v + deMinS[i] === 0 ? 0.5 : v / (v + deMinS[i])));
  // RMI : Relative Momentum Index (RSI calculé sur un momentum de 4 périodes)
  const rmiMom = PRICE.map((v, i) => (i >= 4 ? v - PRICE[i - 4] : 0));
  const rmiUp = sma(rmiMom.map((v) => Math.max(0, v)), 14);
  const rmiDn = sma(rmiMom.map((v) => Math.max(0, -v)), 14);
  const rmi = rmiUp.map((v, i) => (v + rmiDn[i] === 0 ? 50 : (100 * v) / (v + rmiDn[i])));
  // ─── Dérivés pour 5 indicateurs supplémentaires (lot 3) ───
  // SMI : Stochastic Momentum Index (stochastique doublement lissé, −100..100)
  const smiHH = rollMax(HIGH, 10), smiLL = rollMin(LOW, 10);
  const smiRel = PRICE.map((v, i) => v - (smiHH[i] + smiLL[i]) / 2);
  const smiRange = smiHH.map((h, i) => h - smiLL[i]);
  const smiNum = ema(ema(smiRel, 3), 3);
  const smiDen = ema(ema(smiRange, 3), 3);
  const smi = smiNum.map((v, i) => (smiDen[i] === 0 ? 0 : (100 * v) / (smiDen[i] / 2)));
  // WaveTrend : oscillateur de canal autour d'une moyenne du cours typique
  const hlc3 = PRICE.map((v, i) => (HIGH[i] + LOW[i] + v) / 3);
  const wtEsa = ema(hlc3, 10);
  const wtD = ema(hlc3.map((v, i) => Math.abs(v - wtEsa[i])), 10);
  const wtCi = hlc3.map((v, i) => (wtD[i] === 0 ? 0 : (v - wtEsa[i]) / (0.015 * wtD[i])));
  const waveTrend = ema(wtCi, 11);
  // McGinley Dynamic : moyenne adaptative qui se cale sur la vitesse du marché
  const mcginley = (() => {
    const N = 10;
    const out = [PRICE[0]];
    for (let i = 1; i < PRICE.length; i++) {
      const prev = out[i - 1] || PRICE[i];
      const ratio = prev === 0 ? 1 : PRICE[i] / prev;
      out.push(prev + (PRICE[i] - prev) / (N * ratio ** 4 || 1));
    }
    return out;
  })();
  // Center of Gravity (Ehlers) : oscillateur centré sur le barycentre des prix
  const cogN = 10;
  const cog = PRICE.map((_, i) => {
    if (i < cogN - 1) return 0;
    let nume = 0, den = 0;
    for (let k = 0; k < cogN; k++) { const px = PRICE[i - k]; nume += (k + 1) * px; den += px; }
    return den === 0 ? 0 : -nume / den + (cogN + 1) / 2;
  });
  // VIDYA : EMA dont la réactivité est pilotée par le CMO (momentum)
  const vidya = (() => {
    const scV = 2 / (9 + 1);
    const out = [PRICE[0]];
    for (let i = 1; i < PRICE.length; i++) {
      const k = scV * Math.min(1, Math.abs(cmo[i] || 0) / 100);
      out.push(out[i - 1] + k * (PRICE[i] - out[i - 1]));
    }
    return out;
  })();
  // ─── Dérivés pour 5 indicateurs supplémentaires (lot 4) ───
  // Connors RSI : moyenne de RSI(3), RSI(2) de la série de séances, et rang centile du ROC
  const crsiA = rsi(PRICE, 3);
  const streak = (() => {
    const s = [0];
    for (let i = 1; i < PRICE.length; i++) {
      if (PRICE[i] > PRICE[i - 1]) s.push(s[i - 1] > 0 ? s[i - 1] + 1 : 1);
      else if (PRICE[i] < PRICE[i - 1]) s.push(s[i - 1] < 0 ? s[i - 1] - 1 : -1);
      else s.push(0);
    }
    return s;
  })();
  const crsiB = rsi(streak, 2);
  const roc1 = PRICE.map((v, i) => (i > 0 ? (PRICE[i - 1] === 0 ? 0 : ((v - PRICE[i - 1]) / PRICE[i - 1]) * 100) : 0));
  const crsiC = roc1.map((v, i) => {
    const start = Math.max(0, i - 19);
    let cnt = 0, tot = 0;
    for (let k = start; k < i; k++) { tot++; if (roc1[k] < v) cnt++; }
    return tot === 0 ? 50 : (cnt / tot) * 100;
  });
  const connorsRsi = crsiA.map((v, i) => (v + crsiB[i] + crsiC[i]) / 3);
  // Chande Kroll Stop : niveaux de stop dérivés de l'ATR et des extrêmes récents
  const atrCk = atr(PRICE, 10);
  const ckFhs = rollMax(HIGH, 10).map((h, i) => h - atrCk[i]);
  const ckFls = rollMin(LOW, 10).map((l, i) => l + atrCk[i]);
  const ckStopShort = rollMax(ckFhs, 9);
  const ckStopLong = rollMin(ckFls, 9);
  // NVI : Negative Volume Index (évolue les jours de volume en baisse)
  const nvi = (() => {
    const out = [1000];
    for (let i = 1; i < PRICE.length; i++) {
      if (VOL[i] < VOL[i - 1]) out.push(out[i - 1] * (1 + (PRICE[i - 1] === 0 ? 0 : (PRICE[i] - PRICE[i - 1]) / PRICE[i - 1])));
      else out.push(out[i - 1]);
    }
    return out;
  })();
  // Relative Volatility Index (Dorsey) : RSI appliqué à l'écart-type au lieu du prix
  const rvolStd = stdev(PRICE, 10);
  const rvolUp = ema(PRICE.map((v, i) => (i > 0 && v > PRICE[i - 1] ? rvolStd[i] : 0)), 14);
  const rvolDn = ema(PRICE.map((v, i) => (i > 0 && v < PRICE[i - 1] ? rvolStd[i] : 0)), 14);
  const relVolIndex = rvolUp.map((v, i) => (v + rvolDn[i] === 0 ? 50 : (100 * v) / (v + rvolDn[i])));
  // Chaikin Volatility : variation en % de l'amplitude haut-bas lissée
  const hlSpreadEma = ema(HIGH.map((h, i) => h - LOW[i]), 10);
  const chaikinVol = hlSpreadEma.map((v, i) => (i >= 10 && hlSpreadEma[i - 10] !== 0 ? ((v - hlSpreadEma[i - 10]) / hlSpreadEma[i - 10]) * 100 : 0));
  // ─── Dérivés pour 22 indicateurs supplémentaires (lot 5) ───
  const lag5 = 4;
  const zlema = ema(PRICE.map((v, i) => v + (v - PRICE[Math.max(0, i - lag5)])), 9);
  const tma = sma(sma(PRICE, 5), 5);
  const wildersMa = (() => { const n = 14; const out = [PRICE[0]]; for (let i = 1; i < PRICE.length; i++) out.push((out[i - 1] * (n - 1) + PRICE[i]) / n); return out; })();
  const superSmoother = (() => { const p = 10, a = Math.exp(-1.414 * Math.PI / p), b = 2 * a * Math.cos(1.414 * Math.PI / p); const c3 = -a * a, c2 = b, c1 = 1 - c2 - c3; const out = [PRICE[0], PRICE.length > 1 ? PRICE[1] : PRICE[0]]; for (let i = 2; i < PRICE.length; i++) out.push(c1 * (PRICE[i] + PRICE[i - 1]) / 2 + c2 * out[i - 1] + c3 * out[i - 2]); return out; })();
  const medianPriceLine = sma(HIGH.map((h, i) => (h + LOW[i]) / 2), 5);
  const lsma = PRICE.map((_, i) => { const n = Math.min(10, i + 1), s = i - n + 1; let sx = 0, sy = 0, sxy = 0, sxx = 0; for (let k = 0; k < n; k++) { const y = PRICE[s + k]; sx += k; sy += y; sxy += k * y; sxx += k * k; } const slope = (n * sxy - sx * sy) / (n * sxx - sx * sx || 1); const intercept = (sy - slope * sx) / n; return intercept + slope * (n - 1); });
  const t3 = (() => { const n = 5, vf = 0.7; const e1 = ema(PRICE, n), e2 = ema(e1, n), e3 = ema(e2, n), e4 = ema(e3, n), e5 = ema(e4, n), e6 = ema(e5, n); const c1 = -(vf ** 3), c2 = 3 * vf ** 2 + 3 * vf ** 3, c3 = -6 * vf ** 2 - 3 * vf - 3 * vf ** 3, c4 = 1 + 3 * vf + vf ** 3 + 3 * vf ** 2; return PRICE.map((_, i) => c1 * e6[i] + c2 * e5[i] + c3 * e4[i] + c4 * e3[i]); })();
  const efficiencyRatio = PRICE.map((v, i) => { const n = 10, s = Math.max(0, i - n); let vol = 0; for (let k = s + 1; k <= i; k++) vol += Math.abs(PRICE[k] - PRICE[k - 1]); const change = Math.abs(v - PRICE[s]); return vol === 0 ? 0 : change / vol; });
  const tiiSma = sma(PRICE, 20);
  const tiiDev = PRICE.map((v, i) => v - tiiSma[i]);
  const trendIntensity = PRICE.map((_, i) => { const n = 10, s = Math.max(0, i - n + 1); let up = 0, dn = 0; for (let k = s; k <= i; k++) { if (tiiDev[k] > 0) up += tiiDev[k]; else dn += -tiiDev[k]; } return up + dn === 0 ? 50 : (100 * up) / (up + dn); });
  const atr14 = atr(PRICE, 14);
  const rwi = PRICE.map((_, i) => { const n = 14; if (i < n) return 0; const denom = (atr14[i] || 1) * Math.sqrt(n); if (denom === 0) return 0; return Math.max((HIGH[i] - LOW[i - n]) / denom, (HIGH[i - n] - LOW[i]) / denom); });
  const cfo = PRICE.map((v, i) => (v === 0 ? 0 : ((v - lsma[i]) / v) * 100));
  const gapo = PRICE.map((_, i) => { const n = 10; if (i < n) return 0; const hh = Math.max(...HIGH.slice(i - n + 1, i + 1)), ll = Math.min(...LOW.slice(i - n + 1, i + 1)); const range = hh - ll; return range <= 0 ? 0 : Math.log(range) / Math.log(n); });
  const imi = PRICE.map((_, i) => { const n = 14, s = Math.max(1, i - n + 1); let g = 0, l = 0; for (let k = s; k <= i; k++) { const diff = PRICE[k] - PRICE[k - 1]; if (diff > 0) g += diff; else l += -diff; } return g + l === 0 ? 50 : (100 * g) / (g + l); });
  const rbArr = [sma(PRICE, 2)]; for (let r = 1; r < 10; r++) rbArr.push(sma(rbArr[r - 1], 2));
  const rainbowAvg = PRICE.map((_, i) => rbArr.reduce((acc, arr) => acc + arr[i], 0) / rbArr.length);
  const rainbowOsc = PRICE.map((v, i) => { const n = 10, s = Math.max(0, i - n + 1); const hh = Math.max(...PRICE.slice(s, i + 1)), ll = Math.min(...PRICE.slice(s, i + 1)); const range = hh - ll; return range === 0 ? 0 : (100 * (v - rainbowAvg[i])) / range; });
  const laguerreRsi = (() => { const g = 0.5; let L0 = 0, L1 = 0, L2 = 0, L3 = 0; const out: number[] = []; for (let i = 0; i < PRICE.length; i++) { const p = PRICE[i], L0p = L0, L1p = L1, L2p = L2, L3p = L3; L0 = (1 - g) * p + g * L0p; L1 = -g * L0 + L0p + g * L1p; L2 = -g * L1 + L1p + g * L2p; L3 = -g * L2 + L2p + g * L3p; let cu = 0, cd = 0; if (L0 >= L1) cu += L0 - L1; else cd += L1 - L0; if (L1 >= L2) cu += L1 - L2; else cd += L2 - L1; if (L2 >= L3) cu += L2 - L3; else cd += L3 - L2; out.push(cu + cd === 0 ? 0 : cu / (cu + cd)); } return out; })();
  const pvt = (() => { const out = [0]; for (let i = 1; i < PRICE.length; i++) { const prev = PRICE[i - 1], chg = prev === 0 ? 0 : (PRICE[i] - prev) / prev; out.push(out[i - 1] + chg * VOL[i]); } return out; })();
  const twiggs = (() => { const n = 14; const adv = PRICE.map((v, i) => { const trh = Math.max(HIGH[i], i > 0 ? PRICE[i - 1] : HIGH[i]), trl = Math.min(LOW[i], i > 0 ? PRICE[i - 1] : LOW[i]); const range = trh - trl; return range === 0 ? 0 : ((2 * v - trl - trh) / range) * VOL[i]; }); const adS = ema(adv, n), volS = ema(VOL, n); return adS.map((v, i) => (volS[i] === 0 ? 0 : v / volS[i])); })();
  const williamsAd = (() => { const out = [0]; for (let i = 1; i < PRICE.length; i++) { const c = PRICE[i], pc = PRICE[i - 1]; let move = 0; if (c > pc) move = c - Math.min(LOW[i], pc); else if (c < pc) move = c - Math.max(HIGH[i], pc); out.push(out[i - 1] + move); } return out; })();
  const ulcer = PRICE.map((_, i) => { const n = 14, s = Math.max(0, i - n + 1); let sumsq = 0, cnt = 0; for (let k = s; k <= i; k++) { const hh = Math.max(...PRICE.slice(s, k + 1)); const dd = hh === 0 ? 0 : ((PRICE[k] - hh) / hh) * 100; sumsq += dd * dd; cnt++; } return cnt === 0 ? 0 : Math.sqrt(sumsq / cnt); });
  const pviArr = (() => { const out = [1000]; for (let i = 1; i < PRICE.length; i++) { if (VOL[i] > VOL[i - 1]) out.push(out[i - 1] * (1 + (PRICE[i - 1] === 0 ? 0 : (PRICE[i] - PRICE[i - 1]) / PRICE[i - 1]))); else out.push(out[i - 1]); } return out; })();
  const vwmaFn = (arr: number[], n: number) => arr.map((_, i) => { const s = Math.max(0, i - n + 1); let pv = 0, vv = 0; for (let k = s; k <= i; k++) { pv += arr[k] * VOL[k]; vv += VOL[k]; } return vv === 0 ? arr[i] : pv / vv; });
  const vwmaSlow = vwmaFn(PRICE, 13);
  const vwmacd = vwmaFn(PRICE, 6).map((v, i) => v - vwmaSlow[i]);
  const eiEma = ema(PRICE, 13);
  const elderImpulse = PRICE.map((v, i) => { const emaUp = i > 0 && eiEma[i] > eiEma[i - 1]; const histUp = i > 0 && macdHist[i] > macdHist[i - 1]; const val = Math.abs(v - eiEma[i]) + 1; if (emaUp && histUp) return val; if (!emaUp && !histUp) return -val; return 0; });
  return { zlema, tma, wildersMa, superSmoother, medianPriceLine, lsma, t3, efficiencyRatio, trendIntensity, rwi, cfo, gapo, imi, rainbowOsc, laguerreRsi, pvt, twiggs, williamsAd, ulcer, pviArr, vwmacd, elderImpulse, connorsRsi, ckStopShort, ckStopLong, nvi, relVolIndex, chaikinVol, smi, waveTrend, mcginley, cog, vidya, kama, gmmaShortA, gmmaShortB, gmmaLongA, gmmaLongB, apo, demarker, rmi, PRICE, HIGH, LOW, VOL, sma, ema, stdev, rsi, stoch, atr, rollMax, rollMin, rollSum, wma, rocN, avgUO, ema4, ema9, macd, macdSignal, macdHist, sma5, std5, atr3, mom, obv, vwap, williams, cci, roc, keltMid, keltUpper, keltLower, ao, trixEma, trix, donUpper, donLower, donMid, envMid, envUp, envLo, ema5d, dema, aroonOsc, stdFull, bbw, bbUp, bbLo, pctB, mfi, volOsc, momRaw, ppo, ppoSignal, ppoHist, psar, cmo, coppock, dpo, kst, kstSignal, forceIndex, cmf, trArr, vmPlus, vmMinus, trSum5, vortexDiff, hlRange, hlEma1, hlEma2, massIndex, hmaHalf, hmaFull, hmaRaw, hma, temaE1, temaE2, temaE3, tema, plusDM, minusDM, trSumAdx, diPlus, diMinus, dx, adx, bpUO, trUO, uo, rsi7, stochRsi, fisher, coRvi, rvi, adl, chaikinOsc, chop, elderEma, bullPower, bearPower, pivotMid, pivotR1, pivotS1, alliJaw, alliTeeth, alliLips, linreg, eom, bop, accel, tsi, klinger, disparity, qstick, pgo, zscore, vhf, gatorSpread, stc, regHi, regLo };
}

function buildIndicators(B: ReturnType<typeof makeBundle>): Indicator[] {
  const { PRICE, HIGH, LOW, VOL, sma, ema, stdev, rsi, stoch, atr, rollMax, rollMin, rollSum, wma, rocN, avgUO, ema4, ema9, macd, macdSignal, macdHist, sma5, std5, atr3, mom, obv, vwap, williams, cci, roc, keltMid, keltUpper, keltLower, ao, trixEma, trix, donUpper, donLower, donMid, envMid, envUp, envLo, ema5d, dema, aroonOsc, stdFull, bbw, bbUp, bbLo, pctB, mfi, volOsc, momRaw, ppo, ppoSignal, ppoHist, psar, cmo, coppock, dpo, kst, kstSignal, forceIndex, cmf, trArr, vmPlus, vmMinus, trSum5, vortexDiff, hlRange, hlEma1, hlEma2, massIndex, hmaHalf, hmaFull, hmaRaw, hma, temaE1, temaE2, temaE3, tema, plusDM, minusDM, trSumAdx, diPlus, diMinus, dx, adx, bpUO, trUO, uo, rsi7, stochRsi, fisher, coRvi, rvi, adl, chaikinOsc, chop, elderEma, bullPower, bearPower, pivotMid, pivotR1, pivotS1, alliJaw, alliTeeth, alliLips, linreg, eom, bop, accel, tsi, klinger, disparity, qstick, pgo, zscore, vhf, gatorSpread, stc, regHi, regLo, kama, gmmaShortA, gmmaShortB, gmmaLongA, gmmaLongB, apo, demarker, rmi, smi, waveTrend, mcginley, cog, vidya, connorsRsi, ckStopShort, ckStopLong, nvi, relVolIndex, chaikinVol, zlema, tma, wildersMa, superSmoother, medianPriceLine, lsma, t3, efficiencyRatio, trendIntensity, rwi, cfo, gapo, imi, rainbowOsc, laguerreRsi, pvt, twiggs, williamsAd, ulcer, pviArr, vwmacd, elderImpulse } = B;
  void (HIGH || LOW || VOL || sma || ema || stdev || rsi || stoch || atr || rollMax || rollMin || rollSum || wma || rocN || avgUO || trixEma || ema5d || trArr || vmPlus || vmMinus || trSum5 || hlRange || hlEma1 || hlEma2 || hmaHalf || hmaFull || hmaRaw || temaE1 || temaE2 || temaE3 || plusDM || minusDM || trSumAdx || diPlus || diMinus || dx || bpUO || trUO || coRvi || mom || macdSignal || ppoSignal || bbUp || bbLo || alliJaw || alliTeeth || alliLips);
  return [
  // ─────────────── TENDANCE ───────────────
  {
    slug: "moyennes-mobiles",
    name: "Moyennes Mobiles",
    english: "Moving Averages (SMA/EMA)",
    family: "tendance",
    summary: "La moyenne du prix sur N périodes : lisse le bruit et révèle la tendance de fond.",
    measures: "La direction et la pente de la tendance, en moyennant les prix récents (SMA = simple, EMA = exponentielle, plus réactive).",
    reading: "Prix au-dessus de la moyenne = biais haussier ; en dessous = baissier. Le croisement d'une moyenne courte au-dessus d'une longue (golden cross) est suivi de près.",
    scenario: {
      si: "La moyenne courte croise au-dessus de la moyenne longue, prix au-dessus des deux",
      alors: "la tendance est généralement considérée comme haussière",
      sinon: "des moyennes plates et entremêlées signalent une absence de tendance (range).",
    },
    spec: {
      price: PRICE,
      overlays: [
        { values: ema4, color: "#D4A853" },
        { values: ema9, color: "#2E7D5B", dash: true },
      ],
    },
  },
  {
    slug: "ichimoku",
    name: "Ichimoku (nuage)",
    english: "Ichimoku Kinko Hyo",
    family: "tendance",
    summary: "Un système complet : lignes de conversion/base et un « nuage » de support/résistance.",
    measures: "La tendance, le momentum et les zones de support/résistance d'un seul coup d'œil, via plusieurs moyennes décalées et le nuage (kumo).",
    reading: "Prix au-dessus du nuage = tendance haussière ; sous le nuage = baissière ; dans le nuage = indécision. L'épaisseur du nuage indique la force du support/résistance.",
    scenario: {
      si: "Le prix sort par le haut du nuage avec un nuage épais sous lui",
      alors: "la tendance haussière est considérée comme soutenue",
      sinon: "un prix qui évolue dans le nuage traduit une zone d'incertitude à éviter.",
    },
    spec: {
      price: PRICE,
      band: { upper: sma(PRICE, 5).map((v) => v + 3.5), lower: sma(PRICE, 9).map((v) => v - 3.5), color: "#2E7D5B" },
      overlays: [
        { values: sma(PRICE, 3), color: "#D4A853" },
        { values: sma(PRICE, 7), color: "#344453", dash: true },
      ],
    },
  },
  {
    slug: "adx",
    name: "ADX",
    english: "Average Directional Index",
    family: "tendance",
    summary: "Mesure la FORCE d'une tendance (pas sa direction), de 0 à 100.",
    measures: "L'intensité de la tendance en cours, quelle que soit son sens. Sous 20 : pas de tendance. 20-40 : tendance modérée. Au-dessus de 40 : tendance forte.",
    reading: "Un ADX qui monte = la tendance se renforce (haussière ou baissière). Un ADX qui retombe sous 20 = la tendance s'essouffle et le marché entre en range.",
    scenario: {
      si: "L'ADX franchit 25 et continue de monter",
      alors: "la tendance en place est jugée suffisamment forte pour être suivie",
      sinon: "un ADX sous 20 invite à se méfier des signaux de tendance (faux départs fréquents).",
    },
    spec: {
      price: PRICE,
      oscillator: { values: adx, range: [0, Math.max(...adx) + 8], refs: [{ y: 25, color: "#D4A853" }], color: "#344453" },
    },
  },
  {
    slug: "supertrend",
    name: "SuperTrend",
    english: "SuperTrend",
    family: "tendance",
    summary: "Une ligne de suivi de tendance basée sur la volatilité (ATR) qui se place sous/au-dessus du prix.",
    measures: "La direction de la tendance et un niveau de stop dynamique : la ligne suit le prix à distance de quelques ATR.",
    reading: "Ligne sous le prix = tendance haussière ; au-dessus = baissière. Le basculement de la ligne d'un côté à l'autre marque un changement de tendance.",
    scenario: {
      si: "La ligne SuperTrend passe sous le prix et le prix s'en éloigne",
      alors: "la tendance haussière est considérée comme active",
      sinon: "des basculements fréquents de la ligne signalent un marché sans direction (faux signaux).",
    },
    spec: {
      price: PRICE,
      overlays: [{ values: PRICE.map((v, i) => v - atr3[i] * 2 - 1), color: "#2E7D5B" }],
    },
  },

  // ─────────────── MOMENTUM ───────────────
  {
    slug: "rsi",
    name: "RSI",
    english: "Relative Strength Index",
    family: "momentum",
    summary: "Oscillateur 0-100 qui mesure la vitesse et l'ampleur des variations de prix.",
    measures: "Si un actif est suracheté (au-dessus de 70) ou survendu (sous 30), en comparant l'ampleur des hausses et des baisses récentes.",
    reading: "Au-dessus de 70 = surachat possible ; sous 30 = survente possible. Une divergence (prix qui monte, RSI qui baisse) peut annoncer un retournement.",
    scenario: {
      si: "Le RSI repasse sous 70 après l'avoir dépassé, en pleine hausse",
      alors: "un essoufflement de la hausse est possible (sans certitude)",
      sinon: "en forte tendance, le RSI peut rester suracheté longtemps — le seuil seul ne suffit pas.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: rsi(PRICE, 7), range: [0, 100], refs: [{ y: 70, color: "#B0413E" }, { y: 30, color: "#2E7D5B" }], color: "#344453" },
    },
  },
  {
    slug: "macd",
    name: "MACD",
    english: "Moving Average Convergence Divergence",
    family: "momentum",
    summary: "L'écart entre deux moyennes mobiles : momentum et changements de tendance.",
    measures: "La dynamique de la tendance via la différence de deux EMA, une ligne de signal et un histogramme (écart entre les deux).",
    reading: "Histogramme au-dessus de zéro et croissant = momentum haussier. Le croisement de la ligne MACD au-dessus de sa ligne de signal est très suivi.",
    scenario: {
      si: "La ligne MACD croise au-dessus de sa ligne de signal et l'histogramme passe positif",
      alors: "le momentum est considéré comme haussier",
      sinon: "des croisements répétés autour de zéro traduisent un marché sans direction.",
    },
    spec: {
      price: PRICE,
      histogram: { values: macdHist, color: "#344453" },
      signal: { values: macd, color: "#D4A853" },
    },
  },
  {
    slug: "stochastique",
    name: "Stochastique",
    english: "Stochastic Oscillator",
    family: "momentum",
    summary: "Situe la clôture dans la fourchette récente (0-100) : surachat / survente.",
    measures: "Où se situe le prix de clôture par rapport à son range des N dernières périodes — utile pour repérer les excès.",
    reading: "Au-dessus de 80 = surachat ; sous 20 = survente. Le croisement des lignes %K et %D donne des signaux, surtout dans un range.",
    scenario: {
      si: "Le stochastique repasse sous 80 après un excès, dans un range",
      alors: "un retour vers le bas de la fourchette devient envisageable",
      sinon: "en tendance forte, le stochastique sature et donne de faux signaux.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: stoch(PRICE, 6), range: [0, 100], refs: [{ y: 80, color: "#B0413E" }, { y: 20, color: "#2E7D5B" }], color: "#344453" },
    },
  },

  // ─────────────── VOLATILITÉ ───────────────
  {
    slug: "bollinger",
    name: "Bandes de Bollinger",
    english: "Bollinger Bands",
    family: "volatilite",
    summary: "Une moyenne mobile encadrée de deux bandes à ±2 écarts-types : la volatilité en image.",
    measures: "La volatilité (largeur des bandes) et les niveaux relativement extrêmes du prix (proche de la bande haute ou basse).",
    reading: "Bandes qui s'écartent = volatilité en hausse ; qui se resserrent (squeeze) = calme avant un mouvement. Toucher une bande n'est pas un signal en soi.",
    scenario: {
      si: "Les bandes se resserrent fortement (squeeze) puis le prix sort d'un côté",
      alors: "une expansion de volatilité s'amorce souvent dans le sens de la sortie",
      sinon: "en tendance, le prix peut « marcher » le long d'une bande sans retournement.",
    },
    spec: {
      price: PRICE,
      band: { upper: sma5.map((v, i) => v + 2 * std5[i]), lower: sma5.map((v, i) => v - 2 * std5[i]), color: "#D4A853" },
      overlays: [{ values: sma5, color: "#344453", dash: true }],
    },
  },
  {
    slug: "atr",
    name: "ATR",
    english: "Average True Range",
    family: "volatilite",
    summary: "L'amplitude moyenne des séances : une jauge de volatilité absolue.",
    measures: "La volatilité moyenne (taille des bougies) sur N périodes. Ne donne aucune direction — seulement l'agitation du marché.",
    reading: "Un ATR élevé = grandes variations (utile pour dimensionner stops et positions). Un ATR qui monte signale une nervosité croissante.",
    scenario: {
      si: "L'ATR grimpe nettement",
      alors: "les stops doivent être plus larges et les positions plus petites pour le même risque",
      sinon: "un ATR très bas (marché calme) précède parfois une expansion brutale de volatilité.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: atr(PRICE, 3), range: [0, Math.max(...atr(PRICE, 3)) + 1], color: "#D4A853" },
    },
  },

  // ─────────────── VOLUME ───────────────
  {
    slug: "obv",
    name: "OBV",
    english: "On-Balance Volume",
    family: "volume",
    summary: "Cumule le volume des hausses et soustrait celui des baisses : la pression sous-jacente.",
    measures: "L'accumulation ou la distribution : si le volume soutient le mouvement de prix. Confirme ou non la tendance.",
    reading: "OBV qui monte avec le prix = tendance saine. Une divergence (prix qui monte, OBV qui baisse) trahit un mouvement sans conviction.",
    scenario: {
      si: "Le prix fait un nouveau sommet mais l'OBV ne suit pas (divergence)",
      alors: "la hausse manque de soutien et peut s'essouffler",
      sinon: "OBV et prix qui montent ensemble confirment la solidité de la tendance.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: obv, range: [Math.min(...obv) - 1, Math.max(...obv) + 1], color: "#7A6A5A" },
    },
  },
  {
    slug: "vwap",
    name: "VWAP",
    english: "Volume Weighted Average Price",
    family: "volume",
    summary: "Le prix moyen pondéré par le volume : la référence des institutionnels en intraday.",
    measures: "Le prix moyen réellement traité sur la séance, pondéré par les volumes — un benchmark d'exécution.",
    reading: "Prix au-dessus du VWAP = acheteurs en contrôle (biais haussier intraday) ; en dessous = vendeurs. Sert de support/résistance dynamique.",
    scenario: {
      si: "Le prix se maintient au-dessus du VWAP toute la séance",
      alors: "le biais intraday est considéré comme haussier",
      sinon: "des allers-retours autour du VWAP traduisent une séance sans direction.",
    },
    spec: {
      price: PRICE,
      overlays: [{ values: vwap, color: "#2E7D5B" }],
    },
  },
  {
    slug: "williams-r",
    name: "Williams %R",
    english: "Williams Percent Range",
    family: "momentum",
    summary: "Oscillateur −100 à 0 qui situe la clôture dans la fourchette récente : surachat / survente.",
    measures: "À quel point le prix de clôture est proche du plus haut (proche de 0 = fort) ou du plus bas (proche de −100 = faible) des N dernières périodes.",
    reading: "Au-dessus de −20 = surachat possible ; sous −80 = survente possible. Proche du stochastique, il est apprécié pour repérer les retournements de court terme.",
    scenario: {
      si: "Le Williams %R sort de la zone de survente (remonte au-dessus de −80)",
      alors: "un rebond de court terme devient envisageable",
      sinon: "en forte tendance, l'indicateur peut rester collé aux extrêmes sans retournement.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: williams, range: [-100, 0], refs: [{ y: -20, color: "#B0413E" }, { y: -80, color: "#2E7D5B" }], color: "#344453" },
    },
  },
  {
    slug: "cci",
    name: "CCI",
    english: "Commodity Channel Index",
    family: "momentum",
    summary: "Mesure l'écart du prix à sa moyenne : repère les excès au-delà de ±100.",
    measures: "De combien le prix s'écarte de sa moyenne récente, en unités de déviation. Au-delà de +100 ou −100, le mouvement est considéré comme puissant ou excessif.",
    reading: "Au-dessus de +100 = forte dynamique haussière (ou surachat) ; sous −100 = baissière (ou survente). Malgré son nom, il s'applique à tous les marchés.",
    scenario: {
      si: "Le CCI franchit +100 et s'y maintient",
      alors: "une dynamique haussière soutenue est en cours",
      sinon: "des allers-retours autour de zéro traduisent un marché sans direction.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: cci, range: [-200, 200], refs: [{ y: 100, color: "#B0413E" }, { y: -100, color: "#2E7D5B" }], color: "#344453" },
    },
  },
  {
    slug: "roc",
    name: "ROC",
    english: "Rate of Change",
    family: "momentum",
    summary: "La variation du prix en pourcentage sur N périodes : la vitesse pure du mouvement.",
    measures: "La vitesse de variation du prix par rapport à il y a N séances. Positif = hausse, négatif = baisse ; plus la valeur est grande, plus le mouvement est rapide.",
    reading: "Un ROC qui s'éloigne de zéro signale un momentum fort. Une divergence (prix qui monte, ROC qui faiblit) peut annoncer un essoufflement.",
    scenario: {
      si: "Le ROC repasse au-dessus de zéro après une phase négative",
      alors: "le momentum bascule du côté haussier",
      sinon: "un ROC qui oscille autour de zéro confirme l'absence de tendance.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: roc, range: [Math.min(...roc) - 2, Math.max(...roc) + 2], refs: [{ y: 0, color: "#8A6E18" }], color: "#344453" },
    },
  },
  {
    slug: "keltner",
    name: "Canaux de Keltner",
    english: "Keltner Channels",
    family: "volatilite",
    summary: "Des bandes autour d'une moyenne, basées sur la volatilité réelle (ATR).",
    measures: "La volatilité et les niveaux relativement extrêmes, comme Bollinger, mais avec une largeur fondée sur l'ATR plutôt que l'écart-type.",
    reading: "Bandes qui s'écartent = volatilité en hausse. Une sortie franche d'une bande signale souvent une accélération de la tendance plutôt qu'un retournement.",
    scenario: {
      si: "Le prix casse la bande supérieure et s'y maintient",
      alors: "une accélération haussière est généralement en cours",
      sinon: "un prix qui revient au centre du canal traduit un retour au calme.",
    },
    spec: {
      price: PRICE,
      band: { upper: keltUpper, lower: keltLower, color: "#D4A853" },
      overlays: [{ values: keltMid, color: "#344453", dash: true }],
    },
  },
  {
    slug: "awesome-oscillator",
    name: "Awesome Oscillator",
    english: "Awesome Oscillator",
    family: "momentum",
    summary: "Histogramme mesurant le momentum comme l'écart entre une moyenne courte et une moyenne longue.",
    measures: "La force du momentum, via la différence entre une moyenne mobile rapide et une lente. Barres au-dessus de zéro = momentum haussier, en dessous = baissier.",
    reading: "Le passage de l'histogramme au-dessus/sous zéro signale un basculement de momentum. La couleur des barres (croissantes/décroissantes) affine la lecture.",
    scenario: {
      si: "L'histogramme repasse au-dessus de zéro avec des barres croissantes",
      alors: "le momentum bascule du côté haussier",
      sinon: "des barres qui s'effritent près de zéro traduisent un momentum qui s'essouffle.",
    },
    spec: {
      price: PRICE,
      histogram: { values: ao, color: "#344453" },
    },
  },
  {
    slug: "trix",
    name: "TRIX",
    english: "Triple Exponential Average",
    family: "momentum",
    summary: "Oscillateur lissé trois fois qui filtre le bruit pour ne garder que le momentum de fond.",
    measures: "La variation d'une moyenne mobile exponentielle triplement lissée. Le triple lissage élimine les petites secousses pour révéler la tendance profonde du momentum.",
    reading: "TRIX au-dessus de zéro = momentum haussier ; en dessous = baissier. Son croisement de la ligne zéro (ou de sa ligne de signal) est suivi comme signal.",
    scenario: {
      si: "Le TRIX franchit la ligne zéro vers le haut",
      alors: "un momentum haussier de fond est considéré comme en place",
      sinon: "des oscillations serrées autour de zéro signalent un marché sans tendance claire.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: trix, range: [Math.min(...trix) - 0.5, Math.max(...trix) + 0.5], refs: [{ y: 0, color: "#8A6E18" }], color: "#344453" },
    },
  },
  {
    slug: "donchian",
    name: "Canaux de Donchian",
    english: "Donchian Channels",
    family: "tendance",
    summary: "Le plus haut et le plus bas des N dernières séances : le canal de référence des suiveurs de tendance.",
    measures: "Les extrêmes récents du prix : la bande haute est le plus haut sur N périodes, la bande basse le plus bas. C'est l'outil historique de la stratégie « Turtle Traders ».",
    reading: "Un prix qui touche la bande haute marque un plus haut de période (force) ; toucher la bande basse marque un plus bas (faiblesse). La ligne médiane sert de niveau de bascule.",
    scenario: {
      si: "Le prix casse la bande haute du canal (nouveau plus haut sur N séances)",
      alors: "une cassure haussière est signalée — base des stratégies de suivi de tendance",
      sinon: "un prix qui oscille entre les deux bandes traduit un range sans cassure.",
    },
    spec: {
      price: PRICE,
      band: { upper: donUpper, lower: donLower, color: "#344453" },
      overlays: [{ values: donMid, color: "#D4A853", dash: true }],
    },
  },
  {
    slug: "enveloppes-mm",
    name: "Enveloppes de moyennes mobiles",
    english: "Moving Average Envelopes",
    family: "tendance",
    summary: "Une moyenne mobile entourée de deux bandes à un pourcentage fixe : repère les écarts excessifs.",
    measures: "L'éloignement du prix par rapport à sa moyenne, via deux bandes placées à ±X % de celle-ci. Contrairement à Bollinger, la largeur est fixe (en %), pas liée à la volatilité.",
    reading: "Prix proche de la bande haute = tendu à la hausse ; proche de la bande basse = tendu à la baisse. En range, les bandes encadrent les oscillations autour de la moyenne.",
    scenario: {
      si: "Le prix s'écarte jusqu'à la bande supérieure puis revient vers la moyenne",
      alors: "un retour à la moyenne (mean reversion) s'est matérialisé",
      sinon: "en tendance forte, le prix peut longer la bande sans revenir au centre.",
    },
    spec: {
      price: PRICE,
      band: { upper: envUp, lower: envLo, color: "#2E7D5B" },
      overlays: [{ values: envMid, color: "#344453", dash: true }],
    },
  },
  {
    slug: "dema",
    name: "DEMA",
    english: "Double Exponential Moving Average",
    family: "tendance",
    summary: "Une moyenne exponentielle « accélérée » qui réduit le retard des moyennes classiques.",
    measures: "La tendance avec moins de décalage : DEMA = 2·EMA − EMA(EMA). Le double traitement compense le retard naturel d'une moyenne mobile.",
    reading: "DEMA colle davantage au prix qu'une EMA simple : elle tourne plus tôt aux retournements, au prix de quelques signaux supplémentaires en marché agité.",
    scenario: {
      si: "Le prix passe nettement au-dessus de la DEMA qui s'oriente à la hausse",
      alors: "un biais haussier réactif est confirmé plus tôt qu'avec une moyenne classique",
      sinon: "en range, sa réactivité accrue génère davantage de faux croisements.",
    },
    spec: {
      price: PRICE,
      overlays: [
        { values: dema, color: "#D4A853" },
        { values: ema9, color: "#7A6A5A", dash: true },
      ],
    },
  },
  {
    slug: "aroon",
    name: "Aroon",
    english: "Aroon Oscillator",
    family: "tendance",
    summary: "Mesure depuis combien de temps le dernier plus haut/plus bas est survenu : détecte le début et la fin des tendances.",
    measures: "La fraîcheur des extrêmes : Aroon Up suit le temps écoulé depuis le dernier plus haut, Aroon Down depuis le dernier plus bas. L'oscillateur est leur différence (−100 à +100).",
    reading: "Au-dessus de zéro = les plus hauts sont plus récents (tendance haussière) ; sous zéro = les plus bas dominent (tendance baissière). Proche de zéro = pas de tendance.",
    scenario: {
      si: "L'oscillateur Aroon franchit zéro vers le haut",
      alors: "une nouvelle tendance haussière commence à s'installer",
      sinon: "des valeurs collées à zéro signalent une absence de tendance (consolidation).",
    },
    spec: {
      price: PRICE,
      oscillator: { values: aroonOsc, range: [-100, 100], refs: [{ y: 0, color: "#8A6E18" }], color: "#344453" },
    },
  },
  {
    slug: "parabolic-sar",
    name: "Parabolic SAR",
    english: "Parabolic Stop and Reverse",
    family: "tendance",
    summary: "Des points qui suivent le prix et basculent de côté au retournement : un stop suiveur visuel.",
    measures: "La direction de la tendance et un niveau de stop dynamique : les points se rapprochent du prix au fil de la tendance (accélération) et basculent quand elle s'inverse.",
    reading: "Points sous le prix = tendance haussière ; points au-dessus = baissière. Le passage des points de l'autre côté du prix signale un retournement (et un stop touché).",
    scenario: {
      si: "Les points SAR passent sous le prix et s'en écartent progressivement",
      alors: "la tendance haussière est active et le stop suiveur remonte avec le prix",
      sinon: "en marché sans direction, les points basculent sans cesse (faux signaux).",
    },
    spec: {
      price: PRICE,
      overlays: [{ values: psar, color: "#B0413E", dash: true }],
    },
  },
  {
    slug: "momentum",
    name: "Momentum",
    english: "Momentum",
    family: "momentum",
    summary: "La différence brute entre le prix actuel et celui d'il y a N séances : la vitesse du mouvement.",
    measures: "La force et le sens du mouvement en valeur absolue (prix actuel − prix il y a N périodes). Positif = hausse, négatif = baisse ; l'éloignement de zéro mesure la vigueur.",
    reading: "Un momentum qui s'éloigne de zéro = mouvement qui accélère. Un momentum qui revient vers zéro alors que le prix monte encore trahit un essoufflement (divergence).",
    scenario: {
      si: "Le momentum repasse au-dessus de zéro après une phase négative",
      alors: "la dynamique bascule du côté haussier",
      sinon: "un momentum qui faiblit pendant que le prix monte annonce un possible ralentissement.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: momRaw, range: [Math.min(...momRaw) - 2, Math.max(...momRaw) + 2], refs: [{ y: 0, color: "#8A6E18" }], color: "#344453" },
    },
  },
  {
    slug: "ppo",
    name: "PPO",
    english: "Percentage Price Oscillator",
    family: "momentum",
    summary: "Le MACD exprimé en pourcentage : un momentum comparable entre actifs de prix différents.",
    measures: "L'écart entre deux EMA exprimé en % de l'EMA longue, avec une ligne de signal et un histogramme. Le format en % le rend comparable d'un actif à l'autre, contrairement au MACD.",
    reading: "Histogramme au-dessus de zéro et croissant = momentum haussier. Le croisement de la ligne PPO au-dessus de sa ligne de signal est lu comme le MACD, mais normalisé.",
    scenario: {
      si: "La ligne PPO croise au-dessus de sa ligne de signal et l'histogramme passe positif",
      alors: "le momentum est considéré comme haussier, sur une base comparable à d'autres actifs",
      sinon: "des croisements répétés autour de zéro traduisent un marché sans direction.",
    },
    spec: {
      price: PRICE,
      histogram: { values: ppoHist, color: "#344453" },
      signal: { values: ppo, color: "#D4A853" },
    },
  },
  {
    slug: "volatilite-historique",
    name: "Volatilité historique",
    english: "Historical Volatility (Std Dev)",
    family: "volatilite",
    summary: "L'écart-type du prix sur N séances : la dispersion réelle, fondement de la mesure du risque.",
    measures: "La dispersion du prix autour de sa moyenne (écart-type). C'est la brique de base du risque : plus l'écart-type est grand, plus les variations sont amples et imprévisibles.",
    reading: "Un écart-type qui grimpe = marché de plus en plus dispersé (risque accru). Un écart-type très bas signale un calme qui précède parfois une expansion brutale.",
    scenario: {
      si: "L'écart-type augmente fortement",
      alors: "le risque par position s'accroît : il faut réduire la taille et élargir les stops",
      sinon: "une volatilité écrasée (très basse) appelle la prudence : les ressorts sont tendus.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: stdFull, range: [0, Math.max(...stdFull) + 1], color: "#D4A853" },
    },
  },
  {
    slug: "bollinger-bandwidth",
    name: "Bollinger Bandwidth",
    english: "Bollinger Bandwidth",
    family: "volatilite",
    summary: "La largeur des bandes de Bollinger en pourcentage : repère les compressions de volatilité (squeeze).",
    measures: "L'écartement des bandes de Bollinger ramené en % de la moyenne. Un minimum de largeur (squeeze) signale une volatilité comprimée, souvent suivie d'une expansion.",
    reading: "Bandwidth qui s'effondre = compression (squeeze) : le marché se calme avant un possible mouvement. Bandwidth qui explose = expansion de volatilité en cours.",
    scenario: {
      si: "Le Bandwidth tombe à un plus bas (squeeze prononcé) puis remonte",
      alors: "une expansion de volatilité s'amorce, sans présumer du sens de la sortie",
      sinon: "un Bandwidth déjà très élevé traduit un marché agité, plus proche d'un sommet de volatilité.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: bbw, range: [0, Math.max(...bbw) + 2], color: "#D4A853" },
    },
  },
  {
    slug: "percent-b",
    name: "%B (Bollinger)",
    english: "Bollinger %B",
    family: "volatilite",
    summary: "Situe le prix à l'intérieur des bandes de Bollinger : 0 = bande basse, 1 = bande haute.",
    measures: "La position relative du prix dans ses bandes de Bollinger. À 1, le prix touche la bande haute ; à 0, la bande basse ; à 0,5, il est sur la moyenne. Au-delà de 1 ou sous 0 : hors des bandes.",
    reading: "%B au-dessus de 1 = prix au-dessus de la bande haute (excès) ; sous 0 = sous la bande basse. Les divergences entre %B et le prix sont suivies comme signaux de retournement.",
    scenario: {
      si: "Le %B repasse sous 1 après être sorti au-dessus de la bande haute",
      alors: "l'excès haussier se résorbe, un retour dans les bandes s'opère",
      sinon: "en tendance, le %B peut rester collé au-dessus de 0,8 sans retournement.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: pctB, range: [-0.2, 1.2], refs: [{ y: 1, color: "#B0413E" }, { y: 0, color: "#2E7D5B" }], color: "#344453" },
    },
  },
  {
    slug: "mfi",
    name: "MFI",
    english: "Money Flow Index",
    family: "volume",
    summary: "Un RSI pondéré par le volume : mesure la pression acheteuse/vendeuse en intégrant les échanges.",
    measures: "Le flux d'argent entrant et sortant : comme le RSI (0-100), mais pondéré par le volume. Au-dessus de 80 = surachat avec volume ; sous 20 = survente.",
    reading: "MFI élevé = forte pression acheteuse soutenue par le volume ; MFI bas = pression vendeuse. Une divergence MFI/prix trahit un mouvement non confirmé par les volumes.",
    scenario: {
      si: "Le prix monte mais le MFI baisse (divergence baissière)",
      alors: "la hausse n'est pas soutenue par les flux : elle peut s'essouffler",
      sinon: "MFI et prix qui montent ensemble confirment une pression acheteuse réelle.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: mfi, range: [0, 100], refs: [{ y: 80, color: "#B0413E" }, { y: 20, color: "#2E7D5B" }], color: "#7A6A5A" },
    },
  },
  {
    slug: "oscillateur-volume",
    name: "Oscillateur de volume",
    english: "Volume Oscillator",
    family: "volume",
    summary: "L'écart entre une moyenne courte et une moyenne longue du volume : l'accélération de la participation.",
    measures: "Si le volume s'accélère ou ralentit, via la différence entre une moyenne rapide et une moyenne lente des volumes. Positif = volume au-dessus de sa moyenne longue.",
    reading: "Oscillateur positif et croissant = participation en hausse, qui valide le mouvement de prix. Négatif = volume qui s'essouffle, mouvement à surveiller.",
    scenario: {
      si: "Une cassure de prix s'accompagne d'un oscillateur de volume nettement positif",
      alors: "la participation confirme le mouvement, qui gagne en crédibilité",
      sinon: "une cassure sur volume déclinant (oscillateur négatif) est plus suspecte.",
    },
    spec: {
      price: PRICE,
      histogram: { values: volOsc, color: "#7A6A5A" },
    },
  },
  {
    slug: "cmo",
    name: "CMO",
    english: "Chande Momentum Oscillator",
    family: "momentum",
    summary: "Variante du RSI (−100 à +100) qui mesure le momentum net sans lisser les variations.",
    measures: "L'élan net du prix : la différence entre la somme des hausses et des baisses, rapportée à leur total. Contrairement au RSI, il n'applique pas de lissage, ce qui le rend plus réactif.",
    reading: "Au-dessus de +50 = momentum haussier prononcé (surachat possible) ; sous −50 = momentum baissier (survente). Le passage de zéro marque un basculement d'élan.",
    scenario: {
      si: "Le CMO franchit +50 et s'y maintient",
      alors: "un fort élan haussier est en cours, à surveiller pour un excès",
      sinon: "des oscillations serrées autour de zéro traduisent un marché sans direction.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: cmo, range: [-100, 100], refs: [{ y: 50, color: "#B0413E" }, { y: -50, color: "#2E7D5B" }], color: "#344453" },
    },
  },
  {
    slug: "coppock",
    name: "Courbe de Coppock",
    english: "Coppock Curve",
    family: "momentum",
    summary: "Indicateur de long terme conçu pour repérer les grands creux de marché.",
    measures: "Le momentum de fond, via une moyenne lissée de la somme de deux taux de variation. Pensé à l'origine pour les indices sur données mensuelles.",
    reading: "Le retournement à la hausse de la courbe sous zéro est l'élément historiquement suivi comme signal de plancher de long terme. Au-dessus de zéro = tendance de fond haussière.",
    scenario: {
      si: "La courbe de Coppock se retourne à la hausse alors qu'elle est sous zéro",
      alors: "un plancher de long terme est, historiquement, considéré comme possible",
      sinon: "une courbe qui plonge encore traduit un momentum de fond toujours négatif.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: coppock, range: [Math.min(...coppock) - 2, Math.max(...coppock) + 2], refs: [{ y: 0, color: "#8A6E18" }], color: "#344453" },
    },
  },
  {
    slug: "dpo",
    name: "DPO",
    english: "Detrended Price Oscillator",
    family: "momentum",
    summary: "Retire la tendance pour isoler les cycles de court terme du prix.",
    measures: "L'écart entre le prix et une moyenne mobile décalée dans le passé. En neutralisant la tendance, il met en évidence la longueur et l'amplitude des cycles.",
    reading: "Les sommets et creux du DPO aident à estimer la périodicité des cycles. Au-dessus de zéro = prix au-dessus de sa moyenne décalée ; en dessous = en dessous.",
    scenario: {
      si: "Le DPO dessine des sommets régulièrement espacés",
      alors: "une périodicité de cycle se dégage, utile pour situer la phase en cours",
      sinon: "un DPO erratique signale l'absence de cycle court exploitable.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: dpo, range: [Math.min(...dpo) - 1, Math.max(...dpo) + 1], refs: [{ y: 0, color: "#8A6E18" }], color: "#344453" },
    },
  },
  {
    slug: "kst",
    name: "KST",
    english: "Know Sure Thing",
    family: "momentum",
    summary: "Oscillateur qui combine quatre taux de variation lissés pour un momentum plus robuste.",
    measures: "Le momentum global, en additionnant quatre ROC de périodes différentes, chacun lissé et pondéré. L'agrégation vise à réduire les faux signaux d'un ROC isolé.",
    reading: "Le croisement du KST au-dessus de sa ligne de signal, ou de la ligne zéro, est suivi comme un changement de momentum. Plus le KST est haut, plus l'élan haussier est large.",
    scenario: {
      si: "Le KST croise au-dessus de sa ligne de signal sous zéro",
      alors: "un redressement du momentum de fond est signalé",
      sinon: "des croisements répétés près de zéro traduisent un marché hésitant.",
    },
    spec: {
      price: PRICE,
      histogram: { values: kst.map((v, i) => v - kstSignal[i]), color: "#344453" },
      signal: { values: kst, color: "#D4A853" },
    },
  },
  {
    slug: "force-index",
    name: "Force Index",
    english: "Force Index",
    family: "volume",
    summary: "Combine sens, ampleur du mouvement et volume en une seule mesure de pression.",
    measures: "La force derrière un mouvement : la variation de prix multipliée par le volume, puis lissée. Un grand mouvement sur fort volume produit une force élevée.",
    reading: "Force positive et croissante = pression acheteuse soutenue par le volume ; négative = pression vendeuse. Le passage de zéro marque un basculement de la pression dominante.",
    scenario: {
      si: "Le Force Index repasse nettement au-dessus de zéro avec le prix",
      alors: "la pression acheteuse est confirmée par le volume",
      sinon: "une hausse de prix sur Force Index déclinant trahit un mouvement peu soutenu.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: forceIndex, range: [Math.min(...forceIndex) - 2, Math.max(...forceIndex) + 2], refs: [{ y: 0, color: "#8A6E18" }], color: "#7A6A5A" },
    },
  },
  {
    slug: "cmf",
    name: "Chaikin Money Flow",
    english: "Chaikin Money Flow",
    family: "volume",
    summary: "Mesure si l'argent entre (accumulation) ou sort (distribution) sur N périodes.",
    measures: "Le flux d'argent net : la position de la clôture dans la fourchette, pondérée par le volume, cumulée sur N périodes. Positif = accumulation, négatif = distribution.",
    reading: "Au-dessus de zéro (souvent +0,05) = pression acheteuse dominante ; sous zéro (−0,05) = vendeuse. Une divergence CMF/prix trahit un mouvement non soutenu par les flux.",
    scenario: {
      si: "Le CMF se maintient au-dessus de zéro pendant que le prix monte",
      alors: "l'accumulation confirme la hausse",
      sinon: "un prix qui monte avec un CMF négatif signale une distribution masquée.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: cmf, range: [-0.6, 0.6], refs: [{ y: 0.05, color: "#2E7D5B" }, { y: -0.05, color: "#B0413E" }], color: "#7A6A5A" },
    },
  },
  {
    slug: "vortex",
    name: "Vortex",
    english: "Vortex Indicator",
    family: "tendance",
    summary: "Deux mouvements opposés (VI+ et VI−) dont l'écart révèle la direction de la tendance.",
    measures: "La force directionnelle, via le rapport entre les mouvements haussiers et baissiers récents. Ici, l'écart VI+ − VI− : positif = tendance haussière, négatif = baissière.",
    reading: "Un écart qui passe au-dessus de zéro (VI+ dépasse VI−) signale une tendance haussière naissante ; sous zéro, une tendance baissière. L'éloignement de zéro mesure la force.",
    scenario: {
      si: "L'écart du Vortex franchit zéro vers le haut",
      alors: "une tendance haussière est considérée comme amorcée",
      sinon: "un écart qui oscille autour de zéro traduit l'absence de tendance nette.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: vortexDiff, range: [Math.min(...vortexDiff) - 0.1, Math.max(...vortexDiff) + 0.1], refs: [{ y: 0, color: "#8A6E18" }], color: "#344453" },
    },
  },
  {
    slug: "mass-index",
    name: "Mass Index",
    english: "Mass Index",
    family: "volatilite",
    summary: "Détecte les retournements via l'élargissement de l'amplitude des séances (sans direction).",
    measures: "L'expansion et la contraction de la fourchette haut-bas, via un rapport de moyennes lissées cumulé. Une « bosse » du Mass Index signale un élargissement notable de l'amplitude.",
    reading: "Le franchissement d'un seuil élevé puis le repli (le « reversal bulge ») est lu comme l'annonce d'un possible retournement — quel qu'en soit le sens, à confirmer par la tendance.",
    scenario: {
      si: "Le Mass Index forme une bosse au-dessus de son seuil puis retombe",
      alors: "un retournement de tendance devient possible (sens à confirmer ailleurs)",
      sinon: "un Mass Index bas et stable traduit une amplitude contenue, sans alerte.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: massIndex, range: [Math.min(...massIndex) - 0.5, Math.max(...massIndex) + 0.5], refs: [{ y: Math.max(...massIndex) - 0.3, color: "#D4A853" }], color: "#D4A853" },
    },
  },
  {
    slug: "tema",
    name: "TEMA",
    english: "Triple Exponential Moving Average",
    family: "tendance",
    summary: "Une moyenne mobile à très faible retard : elle colle au prix sans tout le délai d'une EMA simple.",
    measures: "La tendance, en corrigeant le retard d'une EMA par un triple lissage (3·EMA − 3·EMA² + EMA³). Le résultat suit le prix de plus près dans les retournements.",
    reading: "Pente montante et prix au-dessus = biais haussier ; la TEMA réagit plus vite qu'une moyenne classique, au prix de quelques faux mouvements supplémentaires.",
    scenario: {
      si: "Le prix repasse durablement au-dessus d'une TEMA orientée à la hausse",
      alors: "le biais de tendance est jugé haussier, avec peu de retard",
      sinon: "une TEMA plate qui croise sans cesse le prix traduit l'absence de tendance.",
    },
    spec: {
      price: PRICE,
      overlays: [{ values: tema, color: "#2E7D5B" }],
    },
  },
  {
    slug: "hull-ma",
    name: "Moyenne de Hull (HMA)",
    english: "Hull Moving Average",
    family: "tendance",
    summary: "Conçue pour être à la fois rapide et lisse : elle réduit le retard tout en gardant une courbe nette.",
    measures: "La tendance via une combinaison de moyennes pondérées (WMA) qui annule l'essentiel du retard. La couleur/pente de la HMA résume le sens dominant.",
    reading: "Un changement de pente de la HMA est lu comme un signe de bascule de tendance plus précoce qu'avec une moyenne classique — à confirmer, car la réactivité augmente le bruit.",
    scenario: {
      si: "La HMA s'oriente nettement vers le haut et le prix la respecte en support",
      alors: "la tendance de court terme est considérée comme haussière",
      sinon: "une HMA qui ondule à plat signale un marché indécis.",
    },
    spec: {
      price: PRICE,
      overlays: [{ values: hma, color: "#D4A853" }],
    },
  },
  {
    slug: "ultimate-oscillator",
    name: "Ultimate Oscillator",
    english: "Ultimate Oscillator",
    family: "momentum",
    summary: "Combine trois horizons de temps pour un momentum moins sujet aux faux signaux.",
    measures: "La pression acheteuse rapportée à l'amplitude, sur trois fenêtres (courte, moyenne, longue) pondérées. Objectif : éviter les divergences trompeuses des oscillateurs mono-période.",
    reading: "Au-dessus de 70 : zone de surchauffe ; sous 30 : zone de survente. Les divergences entre l'oscillateur et le prix sont particulièrement surveillées.",
    scenario: {
      si: "Le prix fait un plus-bas mais l'Ultimate Oscillator remonte (divergence haussière) sous 30",
      alors: "un essoufflement de la baisse est possible",
      sinon: "un oscillateur calé au milieu (autour de 50) traduit un momentum neutre.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: uo, range: [0, 100], refs: [{ y: 70, color: "#B0413E" }, { y: 30, color: "#2E7D5B" }], color: "#2E7D5B" },
    },
  },
  {
    slug: "stochastic-rsi",
    name: "Stochastic RSI",
    english: "Stochastic RSI",
    family: "momentum",
    summary: "Applique la formule du stochastique au RSI : un momentum plus sensible, qui sature plus vite.",
    measures: "La position du RSI à l'intérieur de sa propre fourchette récente. Il détecte les extrêmes de momentum plus tôt et plus souvent qu'un RSI brut.",
    reading: "Au-dessus de 80 : RSI proche de son haut récent (surchauffe) ; sous 20 : proche de son bas (survente). Très réactif, donc à filtrer par la tendance.",
    scenario: {
      si: "Le Stochastic RSI ressort de la zone < 20 en tournant vers le haut",
      alors: "un rebond de momentum de court terme est possible",
      sinon: "des allers-retours rapides 0↔100 sans suite trahissent un marché nerveux.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: stochRsi, range: [0, 100], refs: [{ y: 80, color: "#B0413E" }, { y: 20, color: "#2E7D5B" }], color: "#2E7D5B" },
    },
  },
  {
    slug: "fisher-transform",
    name: "Transformée de Fisher",
    english: "Fisher Transform",
    family: "momentum",
    summary: "Transforme le prix pour faire ressortir des retournements nets là où le prix les noie.",
    measures: "Une version « gaussianisée » de la position du prix : la transformation accentue les extrêmes, rendant les pics et creux de momentum très visibles.",
    reading: "Des pics marqués suivis d'un retournement de la courbe sont lus comme des signaux d'épuisement. Plus tranchée que le RSI, elle se prête bien au repérage de bascule.",
    scenario: {
      si: "La transformée de Fisher atteint un extrême puis se retourne franchement",
      alors: "un changement de momentum est signalé (à confirmer par la tendance)",
      sinon: "une courbe qui oscille mollement autour de zéro indique un momentum atone.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: fisher, range: [Math.min(...fisher) - 0.3, Math.max(...fisher) + 0.3], refs: [{ y: 0, color: "#8A6E18" }], color: "#344453" },
    },
  },
  {
    slug: "rvi",
    name: "Relative Vigor Index",
    english: "Relative Vigor Index (RVI)",
    family: "momentum",
    summary: "Part d'une idée simple : en tendance haussière, on clôture plus haut qu'on ouvre.",
    measures: "La « vigueur » des séances : l'écart clôture-ouverture rapporté à l'amplitude haut-bas, lissé. Positif quand les clôtures dominent, négatif sinon.",
    reading: "RVI au-dessus de zéro = vigueur acheteuse ; en dessous = vigueur vendeuse. Les croisements avec sa ligne de signal et les divergences sont scrutés.",
    scenario: {
      si: "Le RVI repasse au-dessus de zéro avec une pente positive",
      alors: "la vigueur acheteuse reprend le dessus",
      sinon: "un RVI collé à zéro traduit un équilibre acheteurs/vendeurs.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: rvi, range: [Math.min(...rvi) - 0.1, Math.max(...rvi) + 0.1], refs: [{ y: 0, color: "#8A6E18" }], color: "#2E7D5B" },
    },
  },
  {
    slug: "accumulation-distribution",
    name: "Accumulation / Distribution",
    english: "Accumulation/Distribution Line (ADL)",
    family: "volume",
    summary: "Suit l'argent qui entre (accumulation) ou sort (distribution) en pondérant le volume par la séance.",
    measures: "Un flux cumulé : chaque séance ajoute (ou retranche) du volume selon la position de la clôture dans la fourchette du jour. Une ligne qui monte = accumulation.",
    reading: "Si le prix monte mais que l'ADL stagne ou baisse, la hausse manque de soutien (divergence) ; si l'ADL accompagne le prix, le mouvement est jugé sain.",
    scenario: {
      si: "Le prix progresse et l'ADL monte de concert",
      alors: "la hausse est considérée comme soutenue par les flux",
      sinon: "un prix qui grimpe sans l'ADL signale une participation insuffisante.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: adl, range: [Math.min(...adl) - 5, Math.max(...adl) + 5], color: "#7A6A5A" },
    },
  },
  {
    slug: "chaikin-oscillator",
    name: "Oscillateur de Chaikin",
    english: "Chaikin Oscillator",
    family: "volume",
    summary: "Mesure l'accélération du flux d'argent : la dérivée de la ligne d'accumulation/distribution.",
    measures: "La différence entre une EMA courte et une EMA longue de l'ADL. Positif quand l'accumulation s'accélère, négatif quand la distribution prend le dessus.",
    reading: "Le passage au-dessus de zéro traduit une reprise du flux acheteur ; sous zéro, un flux vendeur. Utile pour anticiper les essoufflements de l'ADL.",
    scenario: {
      si: "L'oscillateur de Chaikin franchit zéro vers le haut",
      alors: "le flux d'argent s'oriente à l'achat",
      sinon: "un oscillateur sous zéro indique une pression distributrice.",
    },
    spec: {
      price: PRICE,
      histogram: { values: chaikinOsc, color: "#7A6A5A" },
    },
  },
  {
    slug: "choppiness-index",
    name: "Indice de Choppiness",
    english: "Choppiness Index",
    family: "volatilite",
    summary: "Répond à une seule question : le marché est-il en tendance ou en range ?",
    measures: "Le degré de « hachage » du marché, en comparant la distance réellement parcourue à l'amplitude totale. Élevé = marché latéral ; bas = marché directionnel.",
    reading: "Au-dessus de ~61 : marché en range (les cassures échouent souvent) ; sous ~38 : marché en tendance (les suivis de tendance fonctionnent mieux). Il ne donne pas de sens.",
    scenario: {
      si: "L'indice retombe sous 38 après une zone haute",
      alors: "une phase de tendance s'installe (sens à déterminer ailleurs)",
      sinon: "un indice durablement au-dessus de 61 confirme un marché sans direction.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: chop, range: [0, 100], refs: [{ y: 61.8, color: "#B0413E" }, { y: 38.2, color: "#2E7D5B" }], color: "#D4A853" },
    },
  },
  {
    slug: "elder-ray",
    name: "Elder-Ray (Bull/Bear Power)",
    english: "Elder-Ray Index",
    family: "momentum",
    summary: "Sépare la force des acheteurs (Bull Power) de celle des vendeurs (Bear Power) autour d'une EMA.",
    measures: "Bull Power = plus-haut − EMA ; Bear Power = plus-bas − EMA. L'un mesure jusqu'où les acheteurs poussent au-dessus de la moyenne, l'autre jusqu'où les vendeurs enfoncent en dessous.",
    reading: "En tendance haussière, on guette un Bear Power négatif qui remonte (les vendeurs faiblissent) ; les barres au-dessus/sous zéro montrent quel camp domine séance après séance.",
    scenario: {
      si: "La tendance est haussière et le Bear Power, négatif, remonte vers zéro",
      alors: "l'affaiblissement des vendeurs est interprété comme favorable aux acheteurs",
      sinon: "des barres qui basculent sans cesse de part et d'autre de zéro traduisent un bras de fer indécis.",
    },
    spec: {
      price: PRICE,
      overlays: [{ values: elderEma, color: "#344453", dash: true }],
      histogram: { values: bullPower, color: "#2E7D5B" },
      signal: { values: bearPower, color: "#B0413E" },
    },
  },
  {
    slug: "pivot-points",
    name: "Points pivots",
    english: "Pivot Points",
    family: "tendance",
    summary: "Des niveaux de support et de résistance calculés à partir de la séance précédente.",
    measures: "Des repères de prix objectifs : le pivot central (moyenne haut-bas-clôture) et ses supports/résistances dérivés (S1, R1…). Très utilisés en intraday comme cadres de décision.",
    reading: "Au-dessus du pivot, le biais de séance est plutôt acheteur ; en dessous, plutôt vendeur. R1 et S1 servent de zones où le prix réagit souvent.",
    scenario: {
      si: "Le prix évolue au-dessus du pivot et bute sur R1",
      alors: "R1 est lu comme une résistance de séance à surveiller",
      sinon: "un prix sous le pivot oriente la lecture vers les supports S1/S2.",
    },
    spec: {
      price: PRICE,
      overlays: [
        { values: pivotMid, color: "#344453", dash: true },
        { values: pivotR1, color: "#B0413E" },
        { values: pivotS1, color: "#2E7D5B" },
      ],
    },
  },
  {
    slug: "alligator",
    name: "Alligator de Williams",
    english: "Williams Alligator",
    family: "tendance",
    summary: "Trois moyennes mobiles imbriquées qui « dorment » en range et « mangent » en tendance.",
    measures: "L'état de la tendance via trois moyennes lissées (mâchoire, dents, lèvres). Entrelacées, elles signalent un marché sans direction ; écartées et ordonnées, une tendance en cours.",
    reading: "Quand les trois lignes s'ouvrent et s'alignent, l'« alligator » se réveille : la tendance se développe. Quand elles s'entremêlent, il « dort » : mieux vaut s'abstenir.",
    scenario: {
      si: "Les trois moyennes s'écartent et s'ordonnent dans le même sens",
      alors: "une tendance est considérée comme installée",
      sinon: "des lignes entremêlées traduisent un range où les signaux sont peu fiables.",
    },
    spec: {
      price: PRICE,
      overlays: [
        { values: alliJaw, color: "#344453" },
        { values: alliTeeth, color: "#C8A962", dash: true },
        { values: alliLips, color: "#2E7D5B" },
      ],
    },
  },
  {
    slug: "regression-lineaire",
    name: "Droite de régression linéaire",
    english: "Linear Regression Line",
    family: "tendance",
    summary: "La droite des moindres carrés qui résume la tendance « moyenne » des prix.",
    measures: "La direction de fond, en traçant la droite qui minimise l'écart aux prix sur la période. Sa pente donne le sens et la vigueur de la tendance, sans le bruit des oscillations.",
    reading: "Pente ascendante = tendance haussière de fond ; les écarts du prix à la droite mesurent à quel point il s'éloigne de sa trajectoire moyenne.",
    scenario: {
      si: "Le prix s'éloigne fortement au-dessus de sa droite de régression",
      alors: "un retour vers la moyenne (la droite) devient statistiquement plus probable",
      sinon: "un prix collé à une droite plate traduit l'absence de tendance nette.",
    },
    spec: {
      price: PRICE,
      overlays: [{ values: linreg, color: "#C8A962" }],
    },
  },
  {
    slug: "ease-of-movement",
    name: "Ease of Movement",
    english: "Ease of Movement (EOM)",
    family: "volume",
    summary: "Mesure la « facilité » avec laquelle le prix bouge, en reliant variation et volume.",
    measures: "Le rapport entre le déplacement du prix et le volume nécessaire pour l'obtenir. Une valeur élevée signale un prix qui monte facilement (peu de volume requis), une valeur basse l'inverse.",
    reading: "EOM au-dessus de zéro : le prix monte sans effort de volume (sain) ; en dessous : il baisse facilement. Les divergences avec le prix sont surveillées.",
    scenario: {
      si: "Le prix progresse et l'EOM reste nettement positif",
      alors: "la hausse est jugée « facile », peu coûteuse en volume",
      sinon: "une hausse de prix avec un EOM qui retombe trahit un effort de volume croissant.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: eom, range: [Math.min(...eom) - 0.5, Math.max(...eom) + 0.5], refs: [{ y: 0, color: "#8A6E18" }], color: "#7A6A5A" },
    },
  },
  {
    slug: "balance-of-power",
    name: "Balance of Power",
    english: "Balance of Power (BOP)",
    family: "momentum",
    summary: "Qui, des acheteurs ou des vendeurs, a contrôlé la séance — rapporté à son amplitude.",
    measures: "La domination relative des acheteurs ou des vendeurs : l'écart entre clôture et ouverture, rapporté à l'amplitude haut-bas. Positif quand les acheteurs ferment au-dessus, négatif sinon.",
    reading: "BOP positif et croissant = pression acheteuse qui s'installe ; négatif = pression vendeuse. Les barres au-dessus/sous zéro montrent le camp dominant séance après séance.",
    scenario: {
      si: "Le Balance of Power repasse durablement au-dessus de zéro",
      alors: "les acheteurs sont considérés comme ayant repris le contrôle",
      sinon: "des barres qui oscillent autour de zéro traduisent un équilibre des forces.",
    },
    spec: {
      price: PRICE,
      histogram: { values: bop, color: "#2E7D5B" },
    },
  },
  {
    slug: "accelerator-oscillator",
    name: "Accelerator Oscillator",
    english: "Accelerator Oscillator (AC)",
    family: "momentum",
    summary: "Mesure l'accélération du momentum, souvent avant même le retournement du prix.",
    measures: "La dérivée du momentum : l'écart entre l'Awesome Oscillator et sa propre moyenne. Il capte si l'élan s'accélère ou ralentit, en avance sur le prix lui-même.",
    reading: "Des barres qui repassent au-dessus de zéro signalent une accélération haussière ; en dessous, une accélération baissière. La couleur des barres (montée/descente) précise la dynamique.",
    scenario: {
      si: "L'Accelerator enchaîne des barres croissantes au-dessus de zéro",
      alors: "le momentum haussier est jugé en accélération",
      sinon: "des barres décroissantes signalent un essoufflement, même si le prix monte encore.",
    },
    spec: {
      price: PRICE,
      histogram: { values: accel, color: "#344453" },
    },
  },
  {
    slug: "tsi",
    name: "True Strength Index",
    english: "True Strength Index (TSI)",
    family: "momentum",
    summary: "Un momentum doublement lissé : la nervosité du RSI en moins, la tendance du momentum en plus.",
    measures: "La force et la direction du momentum, via un double lissage exponentiel de la variation de prix. Le résultat oscille autour de zéro, avec beaucoup moins de bruit qu'un oscillateur simple.",
    reading: "Au-dessus de zéro : momentum haussier ; en dessous : baissier. Les croisements de zéro et les divergences avec le prix sont les éléments les plus suivis.",
    scenario: {
      si: "Le TSI repasse au-dessus de zéro après une phase négative",
      alors: "un regain de momentum haussier est signalé",
      sinon: "un TSI scotché sous zéro confirme la domination vendeuse.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: tsi, range: [Math.min(...tsi) - 5, Math.max(...tsi) + 5], refs: [{ y: 0, color: "#8A6E18" }], color: "#2E7D5B" },
    },
  },
  {
    slug: "klinger-oscillator",
    name: "Oscillateur de Klinger",
    english: "Klinger Volume Oscillator",
    family: "volume",
    summary: "Relie le volume au sens du mouvement pour anticiper les retournements de flux.",
    measures: "La différence entre une moyenne courte et une moyenne longue d'un « volume orienté » (positif les jours de hausse, négatif les jours de baisse). Il vise les retournements de tendance via le volume.",
    reading: "Le passage au-dessus de zéro traduit une reprise du flux acheteur ; sous zéro, un flux vendeur. Les divergences avec le prix sont particulièrement scrutées.",
    scenario: {
      si: "L'oscillateur de Klinger franchit zéro vers le haut alors que le prix se stabilise",
      alors: "un possible retournement haussier soutenu par le volume est signalé",
      sinon: "un Klinger durablement négatif accompagne une pression vendeuse.",
    },
    spec: {
      price: PRICE,
      histogram: { values: klinger, color: "#7A6A5A" },
    },
  },
  {
    slug: "disparity-index",
    name: "Indice de disparité",
    english: "Disparity Index",
    family: "momentum",
    summary: "Mesure, en pourcentage, à quel point le prix s'éloigne de sa moyenne mobile.",
    measures: "L'écart relatif entre le cours et sa moyenne mobile, exprimé en %. Positif quand le prix est au-dessus de sa moyenne, négatif en dessous — une jauge d'extension.",
    reading: "Des valeurs très positives signalent un prix « tendu » au-dessus de sa moyenne (risque de repli) ; très négatives, un prix survendu. Le retour vers zéro traduit un retour à la moyenne.",
    scenario: {
      si: "L'indice de disparité atteint un extrême positif rarement vu",
      alors: "un essoufflement ou un retour vers la moyenne devient plus probable",
      sinon: "un indice proche de zéro indique un prix collé à sa moyenne (pas d'excès).",
    },
    spec: {
      price: PRICE,
      oscillator: { values: disparity, range: [Math.min(...disparity) - 2, Math.max(...disparity) + 2], refs: [{ y: 0, color: "#8A6E18" }], color: "#344453" },
    },
  },
  {
    slug: "qstick",
    name: "Qstick",
    english: "Qstick Indicator",
    family: "momentum",
    summary: "Moyenne la couleur des bougies : qui, des acheteurs ou des vendeurs, ferme le plus souvent en tête ?",
    measures: "La moyenne lissée de l'écart clôture-ouverture sur N séances. Positif quand les clôtures dominent les ouvertures (bougies vertes majoritaires), négatif sinon.",
    reading: "Qstick au-dessus de zéro = série de clôtures haussières (pression acheteuse) ; en dessous = pression vendeuse. Les croisements de zéro signalent un changement de dominance.",
    scenario: {
      si: "Le Qstick passe au-dessus de zéro",
      alors: "les séances haussières prennent le dessus (biais acheteur)",
      sinon: "un Qstick négatif traduit une majorité de clôtures baissières.",
    },
    spec: {
      price: PRICE,
      histogram: { values: qstick, color: "#2E7D5B" },
    },
  },
  {
    slug: "pretty-good-oscillator",
    name: "Pretty Good Oscillator",
    english: "Pretty Good Oscillator (PGO)",
    family: "momentum",
    summary: "Situe l'écart du prix à sa moyenne en nombre d'ATR : une mesure d'extension normalisée par la volatilité.",
    measures: "La distance entre le cours et sa moyenne mobile, rapportée à l'ATR (volatilité). Le résultat s'exprime en « nombre d'ATR » d'écart, ce qui le rend comparable d'un actif à l'autre.",
    reading: "Des valeurs élevées (souvent ±3) signalent un mouvement inhabituellement ample par rapport à la volatilité récente — un excès potentiel, à la hausse comme à la baisse.",
    scenario: {
      si: "Le PGO dépasse +3 (mouvement très ample au regard de la volatilité)",
      alors: "le mouvement est jugé exceptionnel et potentiellement étiré",
      sinon: "un PGO proche de zéro traduit un prix sans excès face à sa volatilité.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: pgo, range: [Math.min(...pgo) - 1, Math.max(...pgo) + 1], refs: [{ y: 0, color: "#8A6E18" }], color: "#D4A853" },
    },
  },
  {
    slug: "z-score",
    name: "Z-Score du prix",
    english: "Price Z-Score",
    family: "momentum",
    summary: "Mesure à quel point le cours s'écarte de sa moyenne, en nombre d'écarts-types.",
    measures: "L'éloignement du prix par rapport à sa moyenne mobile, normalisé par la volatilité. Un Z-Score de +2 signifie que le cours est à deux écarts-types au-dessus de sa moyenne récente — statistiquement rare.",
    reading: "Des valeurs au-delà de ±2 signalent une extension inhabituelle, souvent suivie d'un retour vers la moyenne. Autour de 0, le prix évolue dans sa zone « normale ».",
    scenario: {
      si: "Le Z-Score dépasse +2 puis se retourne à la baisse",
      alors: "le cours est jugé statistiquement étiré et un retour vers la moyenne devient probable",
      sinon: "un Z-Score proche de 0 traduit un prix sans excès par rapport à son historique récent.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: zscore, range: [Math.min(-2.5, Math.min(...zscore) - 0.3), Math.max(2.5, Math.max(...zscore) + 0.3)], refs: [{ y: 2, color: "#B0413E" }, { y: 0, color: "#8A6E18" }, { y: -2, color: "#2E7D5B" }], color: "#344453" },
    },
  },
  {
    slug: "vhf",
    name: "Filtre Vertical Horizontal",
    english: "Vertical Horizontal Filter (VHF)",
    family: "tendance",
    summary: "Distingue les phases de tendance des phases de range, sur une échelle de 0 à 1.",
    measures: "Le rapport entre l'amplitude nette du mouvement (du plus haut au plus bas) et la somme des variations quotidiennes. Une tendance franche couvre beaucoup de distance avec peu de zigzags ; un range fait beaucoup de zigzags pour peu de distance nette.",
    reading: "Un VHF élevé et croissant = marché en tendance (privilégier les outils de suivi de tendance). Un VHF bas = marché sans direction (les oscillateurs de range deviennent plus pertinents).",
    scenario: {
      si: "Le VHF monte nettement au-dessus de 0,35",
      alors: "le marché est considéré comme directionnel et les stratégies de tendance plus adaptées",
      sinon: "un VHF bas et plat signale un range où les signaux de tendance se révèlent peu fiables.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: vhf, range: [0, Math.max(0.6, Math.max(...vhf) + 0.05)], refs: [{ y: 0.35, color: "#8A6E18" }], color: "#2E7D5B" },
    },
  },
  {
    slug: "gator-oscillator",
    name: "Gator Oscillator",
    english: "Gator Oscillator",
    family: "tendance",
    summary: "Visualise l'écartement des trois mâchoires de l'Alligator : l'appétit de la tendance.",
    measures: "L'écart entre les trois moyennes mobiles décalées de l'Alligator (mâchoire, dents, lèvres). Quand elles se resserrent, l'« alligator dort » (range) ; quand elles s'écartent, il « se réveille et chasse » (tendance).",
    reading: "Des barres qui grandissent = les moyennes divergent, la tendance prend de la force. Des barres qui rétrécissent vers zéro = les moyennes convergent, le marché s'endort.",
    scenario: {
      si: "Les barres du Gator s'allongent franchement après une phase de sommeil",
      alors: "une nouvelle tendance est considérée comme en train de s'installer",
      sinon: "des barres minces et plates signalent un alligator endormi — mieux vaut patienter.",
    },
    spec: {
      price: PRICE,
      histogram: { values: gatorSpread, color: "#2E7D5B" },
    },
  },
  {
    slug: "schaff-trend-cycle",
    name: "Schaff Trend Cycle",
    english: "Schaff Trend Cycle (STC)",
    family: "momentum",
    summary: "Un MACD passé au filtre stochastique : un oscillateur de cycle plus réactif, borné 0-100.",
    measures: "Le cycle de la tendance, en appliquant deux fois une normalisation stochastique au MACD. Le résultat oscille entre 0 et 100 et tourne plus tôt que le MACD classique, au prix de quelques faux signaux supplémentaires.",
    reading: "Une sortie au-dessus de 25 par le bas suggère un cycle haussier qui démarre ; un passage sous 75 par le haut, un cycle baissier. Les zones extrêmes (>75, <25) indiquent un momentum déjà bien engagé.",
    scenario: {
      si: "Le STC remonte et franchit 25 par le bas",
      alors: "le début d'un cycle haussier est signalé plus tôt qu'avec un MACD",
      sinon: "un STC qui retombe sous 75 traduit un essoufflement du cycle haussier.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: stc, range: [0, 100], refs: [{ y: 75, color: "#B0413E" }, { y: 25, color: "#2E7D5B" }], color: "#D4A853" },
    },
  },
  {
    slug: "regression-channel",
    name: "Canal de régression",
    english: "Linear Regression Channel",
    family: "tendance",
    summary: "La droite des moindres carrés encadrée d'un couloir à ±2 écarts-types.",
    measures: "La tendance « centrale » du prix (droite de régression linéaire) et le couloir statistique dans lequel le cours évolue. Les bords à deux écarts-types contiennent l'essentiel des cours autour de la droite.",
    reading: "Le prix oscille autour de la droite : toucher le bord supérieur signale une extension haute, le bord inférieur une extension basse. La pente de la droite donne la direction de fond.",
    scenario: {
      si: "Le cours atteint le bord inférieur du canal dans une droite ascendante",
      alors: "un retour vers la droite centrale est statistiquement favorisé",
      sinon: "une sortie nette et durable du canal peut annoncer un changement de régime.",
    },
    spec: {
      price: PRICE,
      band: { upper: regHi, lower: regLo, color: "#344453" },
      overlays: [{ values: linreg, color: "#D4A853" }],
    },
  },
  {
    slug: "kama",
    name: "KAMA (moyenne adaptative)",
    english: "Kaufman's Adaptive Moving Average",
    family: "tendance",
    summary: "Une moyenne mobile qui accélère en tendance et ralentit dans le bruit.",
    measures: "La tendance, en ajustant automatiquement son lissage à « l'efficience » du marché : quand le prix avance droit, la KAMA colle au cours ; quand il zigzague, elle s'aplatit pour filtrer le bruit.",
    reading: "Une KAMA qui monte et s'écarte du prix = tendance nette ; une KAMA plate = marché sans direction. Sa réactivité variable limite les faux signaux des moyennes classiques en range.",
    scenario: {
      si: "Le prix franchit la KAMA alors qu'elle commence à s'incliner",
      alors: "un changement de tendance est jugé plus crédible qu'avec une moyenne fixe",
      sinon: "une KAMA horizontale signale un range où ses croisements sont peu fiables.",
    },
    spec: {
      price: PRICE,
      overlays: [{ values: kama, color: "#D4A853" }],
    },
  },
  {
    slug: "gmma",
    name: "GMMA (moyennes de Guppy)",
    english: "Guppy Multiple Moving Average",
    family: "tendance",
    summary: "Deux faisceaux de moyennes — court terme et long terme — pour lire l'accord des horizons.",
    measures: "L'alignement entre les traders de court terme (moyennes rapides) et les investisseurs de long terme (moyennes lentes). L'écartement et l'ordre des deux groupes révèlent la santé de la tendance.",
    reading: "Groupe court au-dessus du groupe long, les deux bien écartés = tendance haussière saine. Quand les faisceaux se compriment et s'entremêlent, la tendance faiblit et un retournement peut s'amorcer.",
    scenario: {
      si: "Le faisceau court repasse au-dessus du faisceau long après l'avoir touché",
      alors: "la reprise de la tendance haussière est généralement privilégiée",
      sinon: "des faisceaux emmêlés traduisent une indécision entre court et long terme.",
    },
    spec: {
      price: PRICE,
      overlays: [
        { values: gmmaShortA, color: "#2E7D5B" },
        { values: gmmaShortB, color: "#2E7D5B", dash: true },
        { values: gmmaLongA, color: "#B0413E" },
        { values: gmmaLongB, color: "#B0413E", dash: true },
      ],
    },
  },
  {
    slug: "apo",
    name: "Oscillateur de prix absolu",
    english: "Absolute Price Oscillator (APO)",
    family: "momentum",
    summary: "L'écart, en valeur absolue, entre une moyenne rapide et une moyenne lente.",
    measures: "Le momentum, comme le MACD, mais exprimé directement dans l'unité du prix (et non en pourcentage comme le PPO). Positif quand la moyenne courte est au-dessus de la longue, négatif sinon.",
    reading: "Un APO qui franchit zéro vers le haut signale un momentum devenu haussier ; vers le bas, baissier. L'amplitude de l'oscillateur reflète la vigueur de l'écart entre les deux moyennes.",
    scenario: {
      si: "L'APO repasse au-dessus de zéro après une phase négative",
      alors: "un regain de momentum haussier est généralement identifié",
      sinon: "un APO qui reste sous zéro confirme la domination des vendeurs.",
    },
    spec: {
      price: PRICE,
      histogram: { values: apo, color: "#344453" },
    },
  },
  {
    slug: "demarker",
    name: "DeMarker",
    english: "DeMarker (DeM)",
    family: "momentum",
    summary: "Compare l'ampleur des nouveaux plus-hauts à celle des nouveaux plus-bas, entre 0 et 1.",
    measures: "L'épuisement de la demande ou de l'offre, en rapportant les hausses des sommets aux baisses des creux. Au-dessus de 0,7 : zone de surachat potentiel ; sous 0,3 : survente potentielle.",
    reading: "Une sortie au-dessus de 0,7 signale un marché peut-être suracheté et vulnérable à un repli ; sous 0,3, un marché survendu susceptible de rebondir. Les retournements depuis ces zones sont surveillés.",
    scenario: {
      si: "Le DeMarker retombe sous 0,7 après l'avoir dépassé",
      alors: "un essoufflement de la hausse et un repli possible sont signalés",
      sinon: "un DeMarker dans la zone médiane n'indique aucun excès particulier.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: demarker, range: [0, 1], refs: [{ y: 0.7, color: "#B0413E" }, { y: 0.3, color: "#2E7D5B" }], color: "#C8A962" },
    },
  },
  {
    slug: "rmi",
    name: "Relative Momentum Index",
    english: "Relative Momentum Index (RMI)",
    family: "momentum",
    summary: "Un RSI calculé sur un momentum décalé : des signaux plus lisses et moins nerveux.",
    measures: "La force du momentum, comme le RSI, mais en comparant le prix à celui de plusieurs séances auparavant (et non à la veille). Le résultat est plus lissé et reste plus longtemps dans les zones extrêmes en tendance forte.",
    reading: "Au-dessus de 70 = momentum haussier marqué (surachat possible) ; sous 30 = momentum baissier (survente possible). En tendance puissante, le RMI peut camper en zone extrême sans se retourner.",
    scenario: {
      si: "Le RMI revient sous 70 après une longue tendance haussière",
      alors: "un affaiblissement du momentum est signalé, à confirmer par le prix",
      sinon: "un RMI stable autour de 50 traduit l'absence de momentum dominant.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: rmi, range: [0, 100], refs: [{ y: 70, color: "#B0413E" }, { y: 30, color: "#2E7D5B" }], color: "#344453" },
    },
  },
  {
    slug: "smi",
    name: "Stochastic Momentum Index",
    english: "Stochastic Momentum Index (SMI)",
    family: "momentum",
    summary: "Un stochastique raffiné, centré sur zéro et doublement lissé, de −100 à +100.",
    measures: "La position du cours par rapport au milieu de sa fourchette récente, et non par rapport à son plus-bas comme le stochastique classique. Doublement lissé, il offre des signaux plus nets et moins erratiques.",
    reading: "Au-dessus de +40, le cours évolue dans le haut de sa fourchette (surachat possible) ; sous −40, dans le bas (survente possible). Le passage de zéro marque un basculement du momentum.",
    scenario: {
      si: "Le SMI franchit +40 puis se retourne à la baisse",
      alors: "un excès haussier et un repli possible sont signalés",
      sinon: "un SMI proche de zéro traduit un cours au milieu de sa fourchette, sans excès.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: smi, range: [Math.min(-60, Math.min(...smi) - 5), Math.max(60, Math.max(...smi) + 5)], refs: [{ y: 40, color: "#B0413E" }, { y: 0, color: "#8A6E18" }, { y: -40, color: "#2E7D5B" }], color: "#344453" },
    },
  },
  {
    slug: "wave-trend",
    name: "WaveTrend",
    english: "WaveTrend Oscillator",
    family: "momentum",
    summary: "Un oscillateur de canal qui mesure l'écart du cours typique à sa moyenne lissée.",
    measures: "L'éloignement du cours typique (moyenne haut/bas/clôture) par rapport à sa moyenne, normalisé par sa dispersion. Le résultat met en évidence les vagues de surachat et de survente.",
    reading: "Des sommets en zone haute suivis d'un retournement signalent un excès acheteur ; des creux en zone basse, un excès vendeur. Les retournements depuis les extrêmes sont particulièrement suivis.",
    scenario: {
      si: "Le WaveTrend forme un sommet en zone haute puis se retourne",
      alors: "un essoufflement de la hausse et un repli possible sont signalés",
      sinon: "un WaveTrend autour de zéro traduit un marché sans excès directionnel.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: waveTrend, range: [Math.min(-70, Math.min(...waveTrend) - 5), Math.max(70, Math.max(...waveTrend) + 5)], refs: [{ y: 53, color: "#B0413E" }, { y: 0, color: "#8A6E18" }, { y: -53, color: "#2E7D5B" }], color: "#2E7D5B" },
    },
  },
  {
    slug: "mcginley-dynamic",
    name: "McGinley Dynamic",
    english: "McGinley Dynamic",
    family: "tendance",
    summary: "Une moyenne mobile auto-ajustée, conçue pour mieux coller au prix que l'EMA.",
    measures: "La tendance, via une moyenne qui accélère quand le marché chute et ralentit quand il monte, grâce à un facteur d'ajustement lié à l'écart entre le cours et la moyenne. Elle vise à réduire le décalage et les faux croisements.",
    reading: "Prix au-dessus de la McGinley = biais haussier ; en dessous = baissier. Sa courbe épouse le cours de plus près qu'une moyenne classique, limitant les écarts brutaux lors des accélérations.",
    scenario: {
      si: "Le prix franchit la McGinley Dynamic et s'en écarte durablement",
      alors: "un changement de tendance est jugé crédible, avec moins de faux signaux qu'une EMA",
      sinon: "une McGinley plate et collée au prix traduit un marché sans tendance.",
    },
    spec: {
      price: PRICE,
      overlays: [{ values: mcginley, color: "#D4A853" }],
    },
  },
  {
    slug: "center-of-gravity",
    name: "Centre de Gravité (Ehlers)",
    english: "Ehlers Center of Gravity",
    family: "momentum",
    summary: "Un oscillateur quasi sans retard, fondé sur le barycentre pondéré des derniers prix.",
    measures: "Le « centre de gravité » des cours récents : une moyenne pondérée qui se comporte comme un oscillateur centré. Conçu par John Ehlers, il vise à détecter les retournements avec un retard minimal.",
    reading: "Les sommets et creux de l'oscillateur signalent des points de retournement potentiels du cours. Sa quasi-absence de retard en fait un outil de timing, au prix d'une sensibilité accrue au bruit.",
    scenario: {
      si: "Le centre de gravité forme un creux marqué puis remonte",
      alors: "un point bas potentiel du cours est signalé de façon précoce",
      sinon: "des oscillations désordonnées traduisent un marché bruité où le signal est moins fiable.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: cog, range: [Math.min(...cog) - 0.5, Math.max(...cog) + 0.5], refs: [{ y: 0, color: "#8A6E18" }], color: "#344453" },
    },
  },
  {
    slug: "vidya",
    name: "VIDYA",
    english: "Variable Index Dynamic Average",
    family: "tendance",
    summary: "Une moyenne dont la vitesse d'adaptation est pilotée par le momentum (CMO).",
    measures: "La tendance, via une EMA dont le coefficient de lissage varie avec la force du momentum mesurée par le CMO : la moyenne devient réactive quand le marché bouge fort, et lente quand il stagne.",
    reading: "Prix au-dessus de la VIDYA = biais haussier ; en dessous = baissier. Sa réactivité variable la rend plus collante en tendance et plus stable en range que l'EMA classique.",
    scenario: {
      si: "Le prix franchit la VIDYA alors que le momentum s'intensifie",
      alors: "un changement de tendance réactif est signalé",
      sinon: "une VIDYA plate, dans un momentum faible, indique un marché sans direction.",
    },
    spec: {
      price: PRICE,
      overlays: [{ values: vidya, color: "#2E7D5B" }],
    },
  },
  {
    slug: "connors-rsi",
    name: "Connors RSI",
    english: "Connors RSI (CRSI)",
    family: "momentum",
    summary: "Un RSI composite combinant momentum, durée des séries et rang du rendement.",
    measures: "La sur-extension à court terme, en moyennant trois éléments : un RSI court du prix, un RSI de la durée des séries de hausses/baisses, et le rang centile du dernier rendement. Le résultat, très réactif, vise le trading de retour à la moyenne.",
    reading: "Sous 10, le marché est jugé très survendu (rebond possible) ; au-dessus de 90, très suracheté (repli possible). Ses seuils sont plus extrêmes que ceux du RSI classique.",
    scenario: {
      si: "Le Connors RSI plonge sous 10 puis se redresse",
      alors: "un rebond de court terme est statistiquement favorisé",
      sinon: "un Connors RSI au-dessus de 90 signale au contraire un excès haussier.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: connorsRsi, range: [0, 100], refs: [{ y: 90, color: "#B0413E" }, { y: 10, color: "#2E7D5B" }], color: "#344453" },
    },
  },
  {
    slug: "chande-kroll-stop",
    name: "Chande Kroll Stop",
    english: "Chande Kroll Stop",
    family: "volatilite",
    summary: "Un couloir de stops suiveurs dérivé de l'ATR et des extrêmes récents.",
    measures: "Des niveaux de sortie adaptatifs : la borne haute sert de stop pour les positions vendeuses, la borne basse pour les positions acheteuses. L'écart au prix s'ajuste à la volatilité (ATR), de sorte que le stop respire avec le marché.",
    reading: "Tant que le cours reste au-dessus de la borne basse, la tendance haussière est jugée intacte ; un passage sous cette borne signale une sortie. Le couloir matérialise la marge de bruit tolérée.",
    scenario: {
      si: "Le cours clôture sous la borne basse du Chande Kroll Stop",
      alors: "une sortie de position acheteuse est généralement envisagée",
      sinon: "tant que le prix reste au-dessus, la tendance est considérée comme préservée.",
    },
    spec: {
      price: PRICE,
      band: { upper: ckStopShort, lower: ckStopLong, color: "#B0413E" },
    },
  },
  {
    slug: "nvi",
    name: "Negative Volume Index",
    english: "Negative Volume Index (NVI)",
    family: "volume",
    summary: "Suit le prix uniquement les jours où le volume baisse — la trace de « l'argent malin ».",
    measures: "L'évolution cumulée du cours lors des seules séances à volume décroissant. L'idée, due à Paul Dysart et Norman Fosback, est que les investisseurs avisés agissent les jours calmes, quand le volume reflue, plutôt que dans la foule.",
    reading: "Un NVI orienté à la hausse suggère que « l'argent malin » accumule discrètement ; un NVI qui décline, qu'il se retire. On le compare souvent à sa propre moyenne pour juger de la tendance de fond.",
    scenario: {
      si: "Le NVI progresse régulièrement au-dessus de sa moyenne",
      alors: "une accumulation discrète des investisseurs avisés est suggérée",
      sinon: "un NVI qui s'effrite traduit un désengagement lors des séances calmes.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: nvi, range: [Math.min(...nvi) * 0.999, Math.max(...nvi) * 1.001], refs: [{ y: 1000, color: "#8A6E18" }], color: "#2E7D5B" },
    },
  },
  {
    slug: "relative-volatility-index",
    name: "Relative Volatility Index",
    english: "Relative Volatility Index (RVI)",
    family: "volatilite",
    summary: "Un RSI appliqué non au prix, mais à l'écart-type : la direction de la volatilité.",
    measures: "Le sens dans lequel évolue la volatilité, en appliquant la logique du RSI à l'écart-type plutôt qu'au cours. Conçu par Donald Dorsey, il sert souvent de filtre de confirmation aux signaux directionnels.",
    reading: "Au-dessus de 50, la volatilité accompagne plutôt les hausses ; en dessous, plutôt les baisses. Au-delà de 70 ou sous 30, le mouvement de volatilité est jugé marqué. Il confirme un signal de prix plutôt qu'il n'en génère seul.",
    scenario: {
      si: "Le RVI de Dorsey dépasse 50 en accompagnement d'une cassure haussière",
      alors: "le signal de hausse est considéré comme mieux confirmé",
      sinon: "un RVI sous 50 nuance un signal haussier en suggérant une volatilité orientée à la baisse.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: relVolIndex, range: [0, 100], refs: [{ y: 70, color: "#B0413E" }, { y: 50, color: "#8A6E18" }, { y: 30, color: "#2E7D5B" }], color: "#C8A962" },
    },
  },
  {
    slug: "chaikin-volatility",
    name: "Volatilité de Chaikin",
    english: "Chaikin Volatility",
    family: "volatilite",
    summary: "Mesure l'accélération ou la décélération de l'amplitude des séances.",
    measures: "La variation, en pourcentage, de l'amplitude haut-bas lissée sur une période donnée. Une valeur positive signale une volatilité qui s'étend ; négative, une volatilité qui se contracte.",
    reading: "Des pics élevés accompagnent souvent les sommets de marché (panique, amplitude maximale), tandis qu'une volatilité basse et déclinante caractérise les phases calmes ou les fonds prolongés.",
    scenario: {
      si: "La volatilité de Chaikin grimpe brutalement après une longue phase calme",
      alors: "une expansion de l'amplitude est signalée, souvent près des extrêmes de marché",
      sinon: "une volatilité de Chaikin basse et stable traduit un marché apaisé.",
    },
    spec: {
      price: PRICE,
      oscillator: { values: chaikinVol, range: [Math.min(...chaikinVol) - 5, Math.max(...chaikinVol) + 5], refs: [{ y: 0, color: "#8A6E18" }], color: "#344453" },
    },
  },
  {
    slug: "zlema", name: "ZLEMA (EMA sans retard)", english: "Zero-Lag EMA", family: "tendance",
    summary: "Une moyenne exponentielle corrigée pour réduire son retard sur le prix.",
    measures: "La tendance, comme l'EMA, mais en compensant le décalage temporel : on ajoute au prix l'écart avec sa valeur passée avant de lisser, ce qui rapproche la courbe du cours en temps réel.",
    reading: "Prix au-dessus de la ZLEMA = biais haussier ; en dessous = baissier. Sa réactivité accrue détecte les retournements plus tôt qu'une EMA, au prix de quelques faux signaux supplémentaires.",
    scenario: { si: "Le prix franchit la ZLEMA qui s'incline dans le même sens", alors: "un changement de tendance est signalé plus tôt qu'avec une EMA classique", sinon: "une ZLEMA plate traduit un marché sans direction." },
    spec: { price: PRICE, overlays: [{ values: zlema, color: "#D4A853" }] },
  },
  {
    slug: "tma", name: "Moyenne Triangulaire", english: "Triangular Moving Average", family: "tendance",
    summary: "Une moyenne doublement lissée qui pondère davantage le centre de la fenêtre.",
    measures: "La tendance de fond, en appliquant deux moyennes simples successives : le résultat est très lisse et accorde le plus de poids aux prix du milieu de la période, filtrant fortement le bruit.",
    reading: "Sa grande douceur en fait un excellent révélateur de tendance de fond, mais au prix d'un retard marqué : elle confirme plus qu'elle n'anticipe.",
    scenario: { si: "La moyenne triangulaire s'incline nettement et le prix s'en écarte", alors: "une tendance de fond est confirmée", sinon: "une TMA horizontale signale l'absence de tendance." },
    spec: { price: PRICE, overlays: [{ values: tma, color: "#2E7D5B" }] },
  },
  {
    slug: "wilders-ma", name: "Moyenne de Wilder (RMA)", english: "Wilder's Smoothing (RMA)", family: "tendance",
    summary: "Le lissage doux de Welles Wilder, au cœur du RSI, de l'ADX et de l'ATR.",
    measures: "La tendance, via une moyenne « modifiée » plus lente qu'une EMA de même période. C'est la brique de lissage que Wilder a utilisée pour construire ses indicateurs (RSI, ATR, ADX).",
    reading: "Plus lente et plus stable qu'une EMA classique, la moyenne de Wilder réagit avec retenue : elle privilégie la robustesse du signal à la rapidité.",
    scenario: { si: "Le prix franchit durablement la moyenne de Wilder", alors: "un changement de tendance robuste est suggéré", sinon: "des allers-retours autour d'elle traduisent un range." },
    spec: { price: PRICE, overlays: [{ values: wildersMa, color: "#344453" }] },
  },
  {
    slug: "super-smoother", name: "Super Smoother (Ehlers)", english: "Ehlers Super Smoother", family: "tendance",
    summary: "Un filtre conçu par John Ehlers pour lisser le prix en limitant le retard et le bruit.",
    measures: "La tendance « propre » : ce filtre à deux pôles, issu du traitement du signal, élimine les hautes fréquences (le bruit) tout en préservant mieux le mouvement de fond qu'une moyenne classique.",
    reading: "La courbe, très lisse, met en évidence la direction sans les soubresauts d'une moyenne courte. Les changements de pente signalent les retournements de tendance.",
    scenario: { si: "Le super smoother change de pente après une phase directionnelle", alors: "un essoufflement ou un retournement de tendance est signalé", sinon: "une pente régulière confirme la tendance en place." },
    spec: { price: PRICE, overlays: [{ values: superSmoother, color: "#D4A853" }] },
  },
  {
    slug: "median-price", name: "Prix Médian", english: "Median Price", family: "tendance",
    summary: "La moyenne du plus-haut et du plus-bas, lissée : un cours de référence robuste.",
    measures: "Le « centre » de chaque séance, calculé comme la moyenne du plus-haut et du plus-bas, puis lissé. Ce prix de référence ignore l'ouverture et la clôture, jugées plus bruitées.",
    reading: "La ligne du prix médian sert de référence de tendance et de support/résistance dynamique : un prix qui s'en écarte durablement signale une direction.",
    scenario: { si: "Le cours évolue nettement au-dessus de la ligne du prix médian", alors: "un biais haussier est retenu", sinon: "des oscillations autour d'elle traduisent l'équilibre." },
    spec: { price: PRICE, overlays: [{ values: medianPriceLine, color: "#8A6E18" }] },
  },
  {
    slug: "lsma", name: "Moyenne des Moindres Carrés", english: "Least Squares Moving Average", family: "tendance",
    summary: "Le point final d'une régression linéaire glissante : une moyenne qui « anticipe ».",
    measures: "La tendance, via l'extrémité d'une droite de régression recalculée à chaque pas sur les N dernières séances. Elle colle de près au prix et réagit vite, en projetant la pente locale.",
    reading: "Sa réactivité en fait un bon détecteur de retournement : un croisement du prix et de la LSMA, ou un changement de pente, est suivi de près.",
    scenario: { si: "La LSMA s'incline à la hausse et le prix la franchit", alors: "un retournement haussier précoce est signalé", sinon: "une LSMA plate dénote un marché sans tendance." },
    spec: { price: PRICE, overlays: [{ values: lsma, color: "#2E7D5B" }] },
  },
  {
    slug: "t3-tillson", name: "T3 (Tillson)", english: "Tillson T3 Moving Average", family: "tendance",
    summary: "Une moyenne très lisse et réactive de Tim Tillson, combinant plusieurs EMA.",
    measures: "La tendance, via une combinaison pondérée de six moyennes exponentielles avec un facteur de volume : le résultat est à la fois lisse (peu de bruit) et réactif (peu de retard).",
    reading: "La T3 épouse le prix de près tout en restant lisse : sa pente donne la direction, et son croisement avec le cours sert de signal de tendance.",
    scenario: { si: "Le prix franchit la T3 alors qu'elle s'incline", alors: "un changement de tendance est suggéré, plus net qu'avec une EMA", sinon: "une T3 horizontale traduit l'absence de tendance." },
    spec: { price: PRICE, overlays: [{ values: t3, color: "#D4A853" }] },
  },
  {
    slug: "efficiency-ratio", name: "Ratio d'Efficience (Kaufman)", english: "Kaufman Efficiency Ratio", family: "tendance",
    summary: "Mesure si le marché avance en ligne droite ou zigzague, de 0 à 1.",
    measures: "« L'efficience » du mouvement : le déplacement net du prix rapporté à la distance totale parcourue. Proche de 1, le marché avance droit (tendance) ; proche de 0, il fait du surplace en zigzag (range).",
    reading: "Un ratio élevé indique une tendance nette, propice au suivi de tendance ; un ratio bas signale un marché bruité où les oscillateurs de range sont plus adaptés.",
    scenario: { si: "Le ratio d'efficience monte nettement au-dessus de 0,5", alors: "le marché est jugé directionnel", sinon: "un ratio bas traduit un range où les signaux de tendance déçoivent." },
    spec: { price: PRICE, oscillator: { values: efficiencyRatio, range: [0, 1], refs: [{ y: 0.5, color: "#8A6E18" }], color: "#2E7D5B" } },
  },
  {
    slug: "trend-intensity-index", name: "Indice d'Intensité de Tendance", english: "Trend Intensity Index", family: "tendance",
    summary: "Mesure la force d'une tendance via la dominance des écarts à la moyenne, de 0 à 100.",
    measures: "L'intensité de la tendance, en comparant la somme des écarts positifs et négatifs du prix à sa moyenne. Au-dessus de 50, les écarts haussiers dominent ; en dessous, les baissiers.",
    reading: "Un TII élevé (>80) traduit une tendance haussière forte ; bas (<20), une tendance baissière marquée ; autour de 50, l'absence de tendance.",
    scenario: { si: "Le TII franchit 80", alors: "une tendance haussière de forte intensité est confirmée", sinon: "un TII proche de 50 signale un marché sans direction." },
    spec: { price: PRICE, oscillator: { values: trendIntensity, range: [0, 100], refs: [{ y: 80, color: "#2E7D5B" }, { y: 50, color: "#8A6E18" }, { y: 20, color: "#B0413E" }], color: "#344453" } },
  },
  {
    slug: "random-walk-index", name: "Random Walk Index", english: "Random Walk Index", family: "tendance",
    summary: "Évalue si le mouvement du prix dépasse ce qu'une simple marche aléatoire produirait.",
    measures: "L'écart entre le déplacement réel du prix et celui attendu d'une marche aléatoire (bruit), normalisé par la volatilité. Plus le RWI est élevé, plus le mouvement est « trop ordonné » pour être du hasard — donc une vraie tendance.",
    reading: "Un RWI nettement supérieur à 1 signale une tendance réelle ; proche de 1 ou en dessous, le marché se comporte comme du bruit aléatoire.",
    scenario: { si: "Le RWI dépasse franchement 1", alors: "une tendance authentique, au-delà du hasard, est identifiée", sinon: "un RWI proche de 1 suggère un marché sans direction exploitable." },
    spec: { price: PRICE, oscillator: { values: rwi, range: [0, Math.max(3, Math.max(...rwi) + 0.3)], refs: [{ y: 1, color: "#8A6E18" }], color: "#2E7D5B" } },
  },
  {
    slug: "chande-forecast-oscillator", name: "Oscillateur de Prévision (Chande)", english: "Chande Forecast Oscillator", family: "momentum",
    summary: "Mesure l'écart, en %, entre le cours et sa droite de régression.",
    measures: "La distance du prix à sa tendance statistique (régression glissante), exprimée en pourcentage du cours. Positif, le prix est au-dessus de sa droite ; négatif, en dessous.",
    reading: "Des valeurs très positives signalent un prix tendu au-dessus de sa tendance (excès haussier possible) ; très négatives, un excès baissier. Le passage de zéro marque un basculement.",
    scenario: { si: "L'oscillateur repasse au-dessus de zéro", alors: "le prix repasse au-dessus de sa tendance, biais haussier", sinon: "des valeurs négatives confirment un prix sous sa droite de régression." },
    spec: { price: PRICE, oscillator: { values: cfo, range: [Math.min(...cfo) - 2, Math.max(...cfo) + 2], refs: [{ y: 0, color: "#8A6E18" }], color: "#344453" } },
  },
  {
    slug: "gapo", name: "Indice de Range (GAPO)", english: "Gopalakrishnan Range Index", family: "volatilite",
    summary: "Quantifie l'amplitude du range récent sur une échelle logarithmique.",
    measures: "L'étendue de la fourchette de prix sur N périodes, ramenée à une échelle logarithmique. Il croît quand le marché s'étire (forte amplitude) et décroît quand il se contracte.",
    reading: "Un GAPO élevé accompagne les phases de forte amplitude (souvent tendancielles ou volatiles) ; un GAPO bas signale une compression, parfois annonciatrice d'une cassure.",
    scenario: { si: "Le GAPO monte fortement après une phase de compression", alors: "une expansion de l'amplitude est signalée", sinon: "un GAPO bas traduit un marché resserré et calme." },
    spec: { price: PRICE, oscillator: { values: gapo, range: [Math.min(...gapo) - 0.1, Math.max(...gapo) + 0.1], refs: [], color: "#C8A962" } },
  },
  {
    slug: "intraday-momentum-index", name: "Intraday Momentum Index", english: "Intraday Momentum Index (IMI)", family: "momentum",
    summary: "Un RSI fondé sur la relation ouverture/clôture plutôt que clôture/clôture.",
    measures: "Le momentum à la manière du RSI, mais en comparant la clôture à l'ouverture de chaque séance : il distingue les journées « acheteuses » (clôture > ouverture) des « vendeuses ». Borné de 0 à 100.",
    reading: "Au-dessus de 70, surachat possible ; sous 30, survente possible. L'IMI complète le RSI en intégrant la dynamique intra-séance.",
    scenario: { si: "L'IMI revient sous 70 après l'avoir dépassé", alors: "un essoufflement de la pression acheteuse est signalé", sinon: "un IMI autour de 50 traduit un équilibre intra-séance." },
    spec: { price: PRICE, oscillator: { values: imi, range: [0, 100], refs: [{ y: 70, color: "#B0413E" }, { y: 30, color: "#2E7D5B" }], color: "#344453" } },
  },
  {
    slug: "rainbow-oscillator", name: "Oscillateur Arc-en-ciel", english: "Rainbow Oscillator", family: "momentum",
    summary: "Mesure l'écart du prix à un faisceau de moyennes récursives, rapporté au range.",
    measures: "La distance du cours à la moyenne d'un « arc-en-ciel » de moyennes successivement lissées, normalisée par l'amplitude récente. Il met en évidence les écarts extrêmes du prix par rapport à son centre lissé.",
    reading: "Des valeurs élevées signalent un prix très au-dessus de son faisceau (excès haussier) ; des valeurs basses, un excès baissier. Les retours vers zéro accompagnent les consolidations.",
    scenario: { si: "L'oscillateur atteint un extrême haut puis se retourne", alors: "un excès haussier susceptible de se corriger est signalé", sinon: "des valeurs proches de zéro traduisent un prix proche de son centre lissé." },
    spec: { price: PRICE, oscillator: { values: rainbowOsc, range: [Math.min(-100, Math.min(...rainbowOsc) - 5), Math.max(100, Math.max(...rainbowOsc) + 5)], refs: [{ y: 0, color: "#8A6E18" }], color: "#2E7D5B" } },
  },
  {
    slug: "laguerre-rsi", name: "RSI de Laguerre", english: "Laguerre RSI", family: "momentum",
    summary: "Un RSI lissé par un filtre de Laguerre, très réactif, borné de 0 à 1.",
    measures: "Le momentum, via un filtre de Laguerre (John Ehlers) qui produit des signaux très nets avec peu de données. Il oscille entre 0 et 1 et reste souvent collé aux extrêmes en tendance forte.",
    reading: "Proche de 1 = forte pression acheteuse ; proche de 0 = forte pression vendeuse. Les sorties des zones extrêmes (sous 0,2 / au-dessus de 0,8) servent de signaux.",
    scenario: { si: "Le RSI de Laguerre quitte la zone basse (<0,2) vers le haut", alors: "un regain de pression acheteuse est signalé", sinon: "un maintien sous 0,2 confirme la domination vendeuse." },
    spec: { price: PRICE, oscillator: { values: laguerreRsi, range: [0, 1], refs: [{ y: 0.8, color: "#B0413E" }, { y: 0.2, color: "#2E7D5B" }], color: "#D4A853" } },
  },
  {
    slug: "price-volume-trend", name: "Price Volume Trend", english: "Price Volume Trend (PVT)", family: "volume",
    summary: "Un OBV affiné qui pondère le volume par l'ampleur de la variation du prix.",
    measures: "La pression acheteuse/vendeuse cumulée, en ajoutant chaque jour une fraction du volume proportionnelle à la variation en pourcentage du prix. Plus fin que l'OBV, qui ne regarde que le signe.",
    reading: "Un PVT qui monte avec le prix confirme la tendance ; une divergence (prix qui monte, PVT qui stagne ou baisse) avertit d'un essoufflement du flux acheteur.",
    scenario: { si: "Le PVT confirme la hausse du prix en montant de concert", alors: "la tendance haussière est jugée soutenue par le volume", sinon: "une divergence PVT/prix signale un possible essoufflement." },
    spec: { price: PRICE, oscillator: { values: pvt, range: [Math.min(...pvt) * 1.05 - 1, Math.max(...pvt) * 1.05 + 1], refs: [], color: "#2E7D5B" } },
  },
  {
    slug: "twiggs-money-flow", name: "Twiggs Money Flow", english: "Twiggs Money Flow", family: "volume",
    summary: "Une mesure de flux monétaire lissée, plus robuste que le Chaikin Money Flow.",
    measures: "La pression d'accumulation ou de distribution, via un flux monétaire pondéré par le volume et lissé exponentiellement. Positif, les acheteurs dominent ; négatif, les vendeurs.",
    reading: "Au-dessus de zéro, accumulation (flux acheteur) ; en dessous, distribution. Les divergences avec le prix sont scrutées comme signaux de retournement.",
    scenario: { si: "Le Twiggs Money Flow repasse au-dessus de zéro", alors: "un retour de la pression acheteuse est signalé", sinon: "un flux durablement négatif traduit une distribution." },
    spec: { price: PRICE, oscillator: { values: twiggs, range: [Math.min(-0.4, Math.min(...twiggs) - 0.05), Math.max(0.4, Math.max(...twiggs) + 0.05)], refs: [{ y: 0, color: "#8A6E18" }], color: "#344453" } },
  },
  {
    slug: "williams-ad", name: "Williams A/D", english: "Williams Accumulation/Distribution", family: "volume",
    summary: "Un cumul d'accumulation/distribution selon la clôture par rapport à la veille.",
    measures: "La pression acheteuse/vendeuse cumulée, en ajoutant la hausse (depuis le plus-bas) les jours de progression et en retranchant la baisse (depuis le plus-haut) les jours de recul. Distinct de la ligne A/D classique.",
    reading: "Une ligne qui monte avec le prix confirme l'accumulation ; une divergence (prix haussier, Williams A/D baissier) avertit d'une distribution sous-jacente.",
    scenario: { si: "Le Williams A/D monte de concert avec le prix", alors: "l'accumulation confirme la tendance haussière", sinon: "une divergence baissière signale une distribution discrète." },
    spec: { price: PRICE, oscillator: { values: williamsAd, range: [Math.min(...williamsAd) - 2, Math.max(...williamsAd) + 2], refs: [], color: "#2E7D5B" } },
  },
  {
    slug: "ulcer-index", name: "Ulcer Index", english: "Ulcer Index", family: "volatilite",
    summary: "Mesure le risque par la profondeur et la durée des baisses depuis les sommets.",
    measures: "« L'inconfort » d'un actif, via la moyenne quadratique des reculs depuis les plus-hauts récents. Contrairement à l'écart-type, il ne pénalise que la baisse — la seule qui « donne des ulcères ».",
    reading: "Un Ulcer Index élevé signale des drawdowns profonds et persistants (actif stressant) ; bas, une progression sans creux marqués. Utile pour comparer le risque réel ressenti de deux actifs.",
    scenario: { si: "L'Ulcer Index grimpe fortement", alors: "l'actif traverse une phase de baisses profondes et prolongées", sinon: "un Ulcer Index bas traduit une progression sereine." },
    spec: { price: PRICE, oscillator: { values: ulcer, range: [0, Math.max(5, Math.max(...ulcer) + 1)], refs: [], color: "#B0413E" } },
  },
  {
    slug: "pvi", name: "Positive Volume Index", english: "Positive Volume Index (PVI)", family: "volume",
    summary: "Suit le prix les seuls jours de volume en hausse — l'action de « la foule ».",
    measures: "L'évolution cumulée du cours lors des séances à volume croissant. Complément du NVI, il reflète le comportement de la foule, supposée active les jours de fort volume.",
    reading: "Un PVI orienté à la hausse suggère que la foule participe à la tendance ; comparé à sa moyenne, il aide à juger si le mouvement est porté par le grand nombre.",
    scenario: { si: "Le PVI progresse au-dessus de sa moyenne", alors: "la foule accompagne la tendance haussière", sinon: "un PVI qui faiblit traduit un désengagement les jours actifs." },
    spec: { price: PRICE, oscillator: { values: pviArr, range: [Math.min(...pviArr) * 0.999, Math.max(...pviArr) * 1.001], refs: [{ y: 1000, color: "#8A6E18" }], color: "#C8A962" } },
  },
  {
    slug: "volume-weighted-macd", name: "MACD pondéré par le volume", english: "Volume-Weighted MACD", family: "volume",
    summary: "Un MACD calculé sur des moyennes pondérées par le volume.",
    measures: "Le momentum, comme le MACD, mais en remplaçant les EMA par des moyennes pondérées par le volume : les séances à fort volume pèsent davantage, donnant un signal plus proche de la « vraie » dynamique des échanges.",
    reading: "Au-dessus de zéro, momentum haussier porté par le volume ; en dessous, baissier. Il filtre les mouvements de faible volume mieux qu'un MACD classique.",
    scenario: { si: "Le VWMACD repasse au-dessus de zéro avec du volume", alors: "un momentum haussier crédible est signalé", sinon: "un VWMACD sous zéro confirme la pression vendeuse." },
    spec: { price: PRICE, histogram: { values: vwmacd, color: "#344453" } },
  },
  {
    slug: "elder-impulse", name: "Système Impulsion (Elder)", english: "Elder Impulse System", family: "momentum",
    summary: "Combine tendance (EMA) et momentum (MACD) pour qualifier chaque séance.",
    measures: "La conjonction de la tendance et du momentum : une séance est « verte » (haussière) quand l'EMA et l'histogramme MACD montent ensemble, « rouge » quand ils baissent ensemble, neutre sinon. Le système d'Alexander Elder.",
    reading: "Des barres positives signalent un alignement haussier (tendance + momentum) ; négatives, un alignement baissier ; nulles, une absence de consensus. On agit dans le sens des barres colorées.",
    scenario: { si: "Les barres deviennent positives (EMA et MACD haussiers)", alors: "un feu vert haussier est donné par le système d'Elder", sinon: "des barres nulles invitent à la prudence faute d'alignement." },
    spec: { price: PRICE, histogram: { values: elderImpulse, color: "#2E7D5B" } },
  },
  ];
}

// Chaque indicateur reçoit sa PROPRE série (seed = index) : les schémas diffèrent tous.
export const INDICATORS: Indicator[] = (() => {
  const count = buildIndicators(makeBundle(1)).length;
  return Array.from({ length: count }, (_, i) => buildIndicators(makeBundle(i + 1))[i]);
})();
