/**
 * WMB_MODULE_SCHEMA_v1 — Universal JSON structure for all 5 modules
 * Each module is a flat array of "blocks" rendered by the editorial renderer.
 * The 8-act narrative structure is enforced by act_number on each block.
 *
 * Module codes: MOD_USA | MOD_ACTIONS | MOD_WORLD | MOD_CH | MOD_ECO_CH
 */

export const MODULE_CODES = ["MOD_USA", "MOD_ACTIONS", "MOD_WORLD", "MOD_CH", "MOD_ECO_CH"] as const;
export type ModuleCode = (typeof MODULE_CODES)[number];

export const MODULE_LABELS: Record<ModuleCode, string> = {
  MOD_USA: "Revue USA",
  MOD_ACTIONS: "Actions USA",
  MOD_WORLD: "Revue Monde",
  MOD_CH: "Revue Suisse",
  MOD_ECO_CH: "Économie Suisse",
};

export const MODULE_COLORS: Record<ModuleCode, string> = {
  MOD_USA: "#3B5998",
  MOD_ACTIONS: "#2E7D5B",
  MOD_WORLD: "#C8A962",
  MOD_CH: "#B0413E",
  MOD_ECO_CH: "#E07A3A",
};

/** 8-act narrative structure */
export const ACT_TITLES: Record<number, string> = {
  1: "Ouverture — Résumé exécutif",
  2: "Le pouls des marchés",
  3: "Thème dominant",
  4: "Macro & politique monétaire",
  5: "Secteurs & actions",
  6: "Risques & scénarios",
  7: "Semaine à venir",
  8: "Clôture — Synthèse",
};

/** A single content block in the module */
export interface ModuleBlock {
  /** Component type key matching EDITORIAL_COMPONENT_MAP */
  type: string;
  /** Act number (1-8) for narrative structure */
  act_number: number;
  /** Component-specific data payload */
  data: Record<string, any>;
}

/** Module metadata (stored alongside blocks) */
export interface ModuleMeta {
  schema_version: "WMB_MODULE_SCHEMA_v1";
  module_code: ModuleCode;
  module_label: string;
  week_number: number;
  year: number;
  date_range: string;
  title: string;
  subtitle?: string;
  thesis?: string;
  reading_time_minutes: number;
  author: string;
  tags?: string[];
  sources: string;
  disclaimer: string;
  cover_image_url?: string;
}

/** Complete module document */
export interface WMBModuleDocument {
  meta: ModuleMeta;
  blocks: ModuleBlock[];
}

/** Validate a module document structure */
export function validateModuleDocument(doc: any): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!doc || typeof doc !== "object") {
    return { valid: false, errors: ["Document must be an object"] };
  }

  // Meta validation
  if (!doc.meta || typeof doc.meta !== "object") {
    errors.push("Missing 'meta' object");
  } else {
    if (doc.meta.schema_version !== "WMB_MODULE_SCHEMA_v1") {
      errors.push(`Invalid schema_version: expected "WMB_MODULE_SCHEMA_v1", got "${doc.meta.schema_version}"`);
    }
    if (!MODULE_CODES.includes(doc.meta.module_code)) {
      errors.push(`Invalid module_code: "${doc.meta.module_code}". Expected one of: ${MODULE_CODES.join(", ")}`);
    }
    const requiredMeta = ["week_number", "year", "date_range", "title", "reading_time_minutes", "author", "sources", "disclaimer"];
    for (const field of requiredMeta) {
      if (doc.meta[field] === undefined || doc.meta[field] === null || doc.meta[field] === "") {
        errors.push(`Missing required meta field: "${field}"`);
      }
    }
  }

  // Blocks validation
  if (!Array.isArray(doc.blocks)) {
    errors.push("Missing 'blocks' array");
  } else {
    if (doc.blocks.length === 0) {
      errors.push("blocks array is empty");
    }
    for (let i = 0; i < doc.blocks.length; i++) {
      const block = doc.blocks[i];
      if (!block.type || typeof block.type !== "string") {
        errors.push(`Block ${i}: missing 'type' string`);
      }
      if (!block.act_number || block.act_number < 1 || block.act_number > 8) {
        errors.push(`Block ${i}: act_number must be 1-8, got ${block.act_number}`);
      }
      if (!block.data || typeof block.data !== "object") {
        errors.push(`Block ${i}: missing 'data' object`);
      }
    }

    // Check act coverage
    const acts = new Set(doc.blocks.map((b: any) => b.act_number).filter((n: any) => typeof n === "number"));
    if (acts.size < 3) {
      errors.push(`Only ${acts.size} acts covered. A module should have at least 3 acts.`);
    }
  }

  return { valid: errors.length === 0, errors };
}

/** Default disclaimer text */
export const DEFAULT_DISCLAIMER = "WallStreet Market Brief est un contenu strictement informatif. Il ne constitue en aucun cas un conseil en investissement, une recommandation d'achat ou de vente, ni un signal de trading. Les informations présentées sont basées sur des sources publiques considérées comme fiables, mais leur exactitude ne peut être garantie. Toute décision d'investissement relève de la seule responsabilité du lecteur. Les performances passées ne préjugent pas des performances futures.";

/** Default sources text */
export const DEFAULT_SOURCES = "Bloomberg, Reuters, CNBC, Federal Reserve, Bureau of Labor Statistics, CME FedWatch, Yahoo Finance, TradingView, FactSet, S&P Global.";
