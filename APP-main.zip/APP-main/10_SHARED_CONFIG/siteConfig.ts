/**
 * ═══════════════════════════════════════════════════════════════
 * WMB — SOURCE DE VÉRITÉ CENTRALISÉE
 * ═══════════════════════════════════════════════════════════════
 *
 * RÈGLE ABSOLUE : Aucun chiffre marketing, prix, nombre de modules,
 * leçons, cours, indicateurs, termes du glossaire, etc. ne doit être
 * dupliqué manuellement dans les composants.
 *
 * Toutes les pages DOIVENT importer depuis ce fichier.
 *
 * STRUCTURE TARIFAIRE : 2 plans uniquement
 *   1. Découverte — Gratuit
 *   2. Premium — 49 CHF/mois ou 490 CHF/an
 * ═══════════════════════════════════════════════════════════════
 */

// ─── PRICING ─────────────────────────────────────────────────
export const PRICING = {
  currency: "CHF",
  plans: {
    free: {
      name: "Découverte",
      slug: "decouverte",
      price: 0,
      priceLabel: "Gratuit",
      interval: null,
      tagline: "Commencez à comprendre les marchés",
      features: [
        "Thème du Mois (dernier numéro)",
        "Glossaire (50 premiers termes)",
        "Quiz d'orientation (5 questions)",
        "Aperçu de la formation (Module 1)",
        "5 indicateurs techniques",
      ],
      notIncluded: [
        "Newsletters hebdomadaires (5 modules)",
        "Formation complète (7 modules, 437+ leçons)",
        "Glossaire complet (1 111+ termes)",
        "54 indicateurs techniques",
        "Thématiques sectorielles (15+)",
        "Outils premium (Watchlists, Screener, Simulateur)",
        "Archives complètes",
        "Support prioritaire",
      ],
    },
    premium: {
      name: "Premium",
      slug: "premium",
      price: 49,
      priceLabel: "49 CHF/mois",
      priceAnnual: 490,
      priceAnnualLabel: "490 CHF/an",
      savingsAnnual: "~2 mois offerts",
      interval: "month" as const,
      tagline: "L'expérience WMB complète",
      recommended: true,
      features: [
        "5 modules (2 hebdo + 3 mensuels)",
        "Formation complète (7 modules, 62 cours, 437+ leçons)",
        "Glossaire complet (1 111+ termes)",
        "54 indicateurs techniques décryptés",
        "15+ thématiques sectorielles",
        "Quiz interactifs (174+ questions)",
        "Outils premium : Watchlists, Screener, Simulateur",
        "Badges de progression",
        "Notes personnelles",
        "Archives complètes",
        "Support prioritaire",
        "Accès prioritaire aux nouvelles fonctionnalités",
      ],
      notIncluded: [],
    },
  },
} as const;

// ─── NEWSLETTER / MODULES ────────────────────────────────────
export const NEWSLETTER = {
  /** Nombre de modules newsletter */
  moduleCount: 5,
  /** Résumé fréquence */
  frequencySummary: "2 hebdomadaires + 3 mensuels",
  /** Liste des modules newsletter */
  modules: [
    {
      id: "marche-us",
      name: "Weekly Brief USA",
      shortName: "Marché US",
      frequency: "Hebdomadaire (dimanche)",
      readTime: "15-20 min",
      format: "Deck PDF 20-25 slides",
      description: "Tendance, chiffres clés, catalyseurs, risques des marchés US.",
      tag: "premium",
    },
    {
      id: "actions-us",
      name: "Module Actions US",
      shortName: "Actions US",
      frequency: "Hebdomadaire (dimanche)",
      readTime: "10-15 min",
      format: "Deck PDF 15-20 slides",
      description: "Analyse des actions US de la semaine : watchlist, scénarios, niveaux clés.",
      tag: "premium",
    },
    {
      id: "revue-monde",
      name: "Revue Monde",
      shortName: "Monde",
      frequency: "Mensuelle",
      readTime: "10-15 min",
      format: "Deck PDF 15-20 slides",
      description: "Tour d'horizon des marchés mondiaux : Europe, Asie, émergents.",
      tag: "premium",
    },
    {
      id: "revue-suisse",
      name: "Revue Suisse",
      shortName: "Suisse",
      frequency: "Mensuelle",
      readTime: "10-12 min",
      format: "Deck PDF 12-15 slides",
      description: "Focus SMI, SPI, actions suisses, BNS, franc suisse.",
      tag: "premium",
    },
    {
      id: "theme-mois",
      name: "Thème du Mois",
      shortName: "Thème du Mois",
      frequency: "Mensuelle",
      readTime: "20-25 min",
      format: "Deck PDF 25-30 slides",
      description: "Dossier thématique approfondi : secteur, tendance macro, ou concept clé.",
      tag: "gratuit (dernier numéro)",
    },
  ],
  /** Jour d'envoi */
  sendDay: "Dimanche",
} as const;

// ─── FORMATION / ACADÉMIE ────────────────────────────────────
export const ACADEMY = {
  /** Nombre total de modules de formation */
  moduleCount: 7,
  /** Nombre total de cours */
  courseCount: 62,
  /** Nombre total de leçons */
  lessonCount: 437,
  /** Label affiché */
  lessonLabel: "437+",
  /** Durée estimée totale */
  totalDuration: "80+ heures",
  /** Durée recommandée par jour */
  dailyPace: "30 minutes/jour",
  /** Durée estimée pour terminer */
  completionTime: "3-4 mois",
  /** Liste des modules */
  modules: [
    { number: 1, name: "Les Fondamentaux de la Bourse", courses: 8, lessons: 58, level: "Débutant" },
    { number: 2, name: "Véhicules d'Investissement", courses: 9, lessons: 63, level: "Débutant-Intermédiaire" },
    { number: 3, name: "Analyses Technique & Fondamentale", courses: 10, lessons: 72, level: "Intermédiaire" },
    { number: 4, name: "Indices & Indicateurs Mondiaux", courses: 9, lessons: 65, level: "Intermédiaire" },
    { number: 5, name: "Les Options", courses: 10, lessons: 68, level: "Avancé" },
    { number: 6, name: "Histoire & Culture Financière", courses: 8, lessons: 55, level: "Tous niveaux" },
    { number: 7, name: "Investissement Pratique", courses: 8, lessons: 56, level: "Intermédiaire-Avancé" },
  ],
} as const;

// ─── GLOSSAIRE ───────────────────────────────────────────────
export const GLOSSARY = {
  /** Nombre total de termes */
  termCount: 1111,
  /** Label affiché */
  termLabel: "1 111+",
  /** Nombre de catégories */
  categoryCount: 6,
  /** Catégories */
  categories: ["Marché", "Analyse", "Instruments", "Risque", "Ordres", "Indicateurs"],
  /** Niveaux */
  levels: ["Débutant", "Intermédiaire", "Avancé"],
  /** Termes gratuits */
  freeTermLimit: 50,
} as const;

// ─── INDICATEURS TECHNIQUES ──────────────────────────────────
export const INDICATORS = {
  /** Encyclopédie premium d'indicateurs (= INDICATORS dans client/src/pages/IndicateursTendance.tsx).
   *  NB : la bibliothèque GRATUITE en graphes (client/src/data/indicators.ts) en compte 100, comptés
   *  dynamiquement sur la page publique. Ce bloc décrit l'offre premium (pricing + dashboard). */
  count: 54,
  /** Label affiché */
  countLabel: "54",
  /** Nombre de familles/catégories */
  familyCount: 8,
  /** Familles */
  families: ["Tendance", "Momentum", "Volatilité", "Volume", "Patterns", "Structure", "Institutionnel", "Synthèse"],
  /** Indicateurs gratuits */
  freeLimit: 5,
} as const;

// ─── THÉMATIQUES ─────────────────────────────────────────────
export const THEMES = {
  /** Nombre total de thématiques publiées */
  count: 15,
  /** Label affiché */
  countLabel: "15+",
  /** Nombre de secteurs couverts */
  sectorCount: 7,
  /** Secteurs */
  sectors: ["Technologie & IA", "Énergie", "Santé & Biotech", "Finance", "Crypto & Blockchain", "Défense & Aérospatiale", "Consommation"],
} as const;

// ─── QUIZ ────────────────────────────────────────────────────
export const QUIZ = {
  /** Nombre de thèmes de quiz */
  themeCount: 5,
  /** Thèmes */
  themes: ["Marchés", "Indicateurs", "Glossaire", "Formation", "ETFs"],
  /** Nombre total de questions */
  totalQuestions: 174,
  /** Label affiché */
  totalLabel: "174+",
  /** Questions par session */
  questionsPerSession: 30,
  /** Questions gratuites */
  freeLimit: 5,
  /** Score minimum pour badge */
  badgeThreshold: 70,
} as const;

// ─── CRÉDIBILITÉ / PREUVE ────────────────────────────────────
export const CREDIBILITY = {
  /** Numéro de la dernière édition publiée (mettre à jour chaque semaine) */
  lastEditionNumber: 15,
  /** Semaine calendaire de la dernière édition */
  lastEditionWeek: "S15",
  /** Date de lancement de WMB */
  launchDate: "Janvier 2025",
  /** Nombre d'éditions publiées depuis le lancement */
  totalEditions: 15,
  /** Label affiché */
  totalEditionsLabel: "15 éditions publiées",
  /** Fréquence de publication */
  publishFrequency: "Chaque semaine",
  /** Régularité */
  streak: "15 dimanches consécutifs sans interruption",
  /** Engagements éditoriaux */
  commitments: [
    "Aucun conseil en investissement",
    "Aucun signal d'achat ou de vente",
    "Aucun objectif de prix",
    "Disclaimer visible dans chaque édition",
    "Sources citées et traçables",
    "Scénarios conditionnels SI/ALORS/SINON",
  ],
} as const;

// ─── SITE GÉNÉRAL ────────────────────────────────────────────
export const SITE = {
  name: "WallStreet Market Brief",
  shortName: "WMB",
  tagline: "Les marchés US, résumés en 20 minutes.",
  description: "Newsletter hebdomadaire + plateforme éducative pour comprendre les marchés financiers américains.",
  url: "https://wallstreetmarketbrief.ch",
  email: "contact@wallstreetmarketbrief.ch",
  timezone: "Europe/Zurich",
  language: "fr",
  /** Couleurs de marque */
  colors: {
    primary: "#344453",
    accent: "#D4A853",
    success: "#2E7D5B",
    danger: "#B0413E",
    background: "#F4F5F5",
    dark: "#1E1E1E",
  },
} as const;

// ─── LABELS HARMONISÉS ──────────────────────────────────────
export const LABELS = {
  /** CTA principaux */
  cta: {
    subscribe: "Commencer gratuitement",
    subscribePremium: `Passer Premium — ${49} CHF/mois`,
    viewPlans: "Voir les offres",
    viewSample: "Lire un extrait gratuit",
    comparePlans: "Comparer Découverte vs Premium",
    startAcademy: "Commencer la formation",
    exploreThemes: "Explorer les thématiques",
    tryQuiz: "Tester mes connaissances",
  },
  /** Noms de sections */
  sections: {
    newsletter: "Newsletter",
    academy: "Académie WMB",
    glossary: "Glossaire",
    indicators: "Indicateurs Techniques",
    themes: "Thématiques",
    quiz: "Quiz",
    archives: "Archives",
    dashboard: "Espace Membre",
    pricing: "Tarifs",
  },
} as const;
