export const COOKIE_NAME = "app_session_id";
// Session duration: 7 days (reduced from 1 year for security)
export const SESSION_MAX_AGE_MS = 1000 * 60 * 60 * 24 * 7;
// Keep ONE_YEAR_MS for backward compat but prefer SESSION_MAX_AGE_MS
export const ONE_YEAR_MS = SESSION_MAX_AGE_MS;
export const AXIOS_TIMEOUT_MS = 30_000;
export const UNAUTHED_ERR_MSG = 'Please login (10001)';
export const NOT_ADMIN_ERR_MSG = 'You do not have required permission (10002)';

// Security constants
export const PASSWORD_RESET_EXPIRY_MS = 15 * 60 * 1000; // 15 minutes (reduced from 1 hour)
export const INACTIVITY_TIMEOUT_MS = 30 * 60 * 1000; // 30 minutes frontend auto-logout
export const MAX_LOGIN_ATTEMPTS = 5;
export const LOCKOUT_DURATION_MS = 15 * 60 * 1000; // 15 minutes
export const IP_BAN_THRESHOLD = 20; // Auto-ban after 20 blocked requests in 1 hour
export const IP_BAN_DURATION_MS = 60 * 60 * 1000; // 1 hour ban
