/**
 * WMB Academy Router — Courses, Scripts, Strategies
 * Public endpoints for browsing, protected for purchases & progress
 */
import { z } from "zod";
import { router, publicProcedure, protectedProcedure } from "../_core/trpc";
import { getDb } from "../db";
import {
  courses,
  courseLessons,
  userCourseProgress,
  courseNotes,
  userFormationState,
  quizQuestions,
  quizResults,
  userBadges,
  tvScripts,
  strategies,
  userPurchases,
  users,
  glossaryTerms,
} from "../../drizzle/schema";
import { eq, and, asc, desc, like, sql } from "drizzle-orm";
import { getStripe } from "../stripe/client";
import { ENV } from "../_core/env";

export const academyRouter = router({
  /* ═══════════════════════════════════════════════════════════
   * COURSES
   * ═══════════════════════════════════════════════════════════ */

  /** List all courses grouped by module */
  listCourses: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    const result = await db
      .select()
      .from(courses)
      .orderBy(asc(courses.sortOrder));
    return result;
  }),

  /** Get a single course by slug */
  getCourse: publicProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return null;
      const result = await db
        .select()
        .from(courses)
        .where(eq(courses.slug, input.slug))
        .limit(1);
      return result[0] || null;
    }),

  /** Get lessons for a course */
  getCourseLessons: publicProcedure
    .input(z.object({ courseId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db
        .select()
        .from(courseLessons)
        .where(eq(courseLessons.courseId, input.courseId))
        .orderBy(asc(courseLessons.sortOrder));
    }),

  /** Get a single lesson by course slug + lesson slug */
  getLessonBySlug: publicProcedure
    .input(z.object({ courseSlug: z.string(), lessonSlug: z.string() }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) return null;
      // First get the course
      const course = await db
        .select()
        .from(courses)
        .where(eq(courses.slug, input.courseSlug))
        .limit(1);
      if (!course[0]) return null;
      // Then get the lesson
      const lesson = await db
        .select()
        .from(courseLessons)
        .where(
          and(
            eq(courseLessons.courseId, course[0].id),
            eq(courseLessons.slug, input.lessonSlug)
          )
        )
        .limit(1);
      if (!lesson[0]) return null;

      const isFreeLesson = course[0].isFree === 1 || lesson[0].isFreePreview === 1;
      if (isFreeLesson) {
        return { course: course[0], lesson: lesson[0] };
      }

      let userHasAccess = false;
      if (ctx.user) {
        const isOwner = ctx.user.openId === ENV.ownerOpenId || ctx.user.role === 'admin';
        if (isOwner) {
          userHasAccess = true;
        } else {
          const dbUser = await db
            .select({ subscriptionActive: users.subscriptionActive, subscriptionPlan: users.subscriptionPlan })
            .from(users)
            .where(eq(users.id, ctx.user.id))
            .limit(1);
          if (dbUser[0]?.subscriptionActive === 1 && dbUser[0]?.subscriptionPlan) {
            userHasAccess = true;
          }
        }
      }

      if (userHasAccess) {
        return { course: course[0], lesson: lesson[0] };
      }

      const fullContent = lesson[0].content || "";
      const teaser = fullContent.split("\n").slice(0, 6).join("\n") + "\n\n---\n\n*Contenu réservé aux abonnés Premium.*";
      return {
        course: course[0],
        lesson: { ...lesson[0], content: teaser, isGated: true },
      };
    }),

  /** Get all user progress (all courses) */
  getAllProgress: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    return db
      .select()
      .from(userCourseProgress)
      .where(eq(userCourseProgress.userId, ctx.user.id));
  }),

  /** Get user's progress for a course */
  getCourseProgress: protectedProcedure
    .input(z.object({ courseId: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db
        .select()
        .from(userCourseProgress)
        .where(
          and(
            eq(userCourseProgress.userId, ctx.user.id),
            eq(userCourseProgress.courseId, input.courseId)
          )
        );
    }),

  /** Mark a lesson as completed */
  completeLesson: protectedProcedure
    .input(z.object({ courseId: z.number(), lessonId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Check if already completed
      const existing = await db
        .select()
        .from(userCourseProgress)
        .where(
          and(
            eq(userCourseProgress.userId, ctx.user.id),
            eq(userCourseProgress.courseId, input.courseId),
            eq(userCourseProgress.lessonId, input.lessonId)
          )
        )
        .limit(1);

      if (existing.length > 0) return { success: true, alreadyCompleted: true };

      await db.insert(userCourseProgress).values({
        userId: ctx.user.id,
        courseId: input.courseId,
        lessonId: input.lessonId,
      });

      return { success: true, alreadyCompleted: false };
    }),

  /** Uncomplete a lesson (toggle off) */
  uncompleteLesson: protectedProcedure
    .input(z.object({ courseId: z.number(), lessonId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db
        .delete(userCourseProgress)
        .where(
          and(
            eq(userCourseProgress.userId, ctx.user.id),
            eq(userCourseProgress.courseId, input.courseId),
            eq(userCourseProgress.lessonId, input.lessonId)
          )
        );

      return { success: true };
    }),

  /* ═══════════════════════════════════════════════════════════
   * TRADINGVIEW SCRIPTS
   * ═══════════════════════════════════════════════════════════ */

  /** List all active scripts */
  listScripts: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    const result = await db
      .select()
      .from(tvScripts)
      .where(eq(tvScripts.isActive, 1))
      .orderBy(asc(tvScripts.sortOrder));
    return result.map((s) => ({
      ...s,
      features: s.features ? JSON.parse(s.features) : [],
      screenshots: s.screenshots ? JSON.parse(s.screenshots) : [],
    }));
  }),

  /** Get a single script by slug */
  getScript: publicProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return null;
      const result = await db
        .select()
        .from(tvScripts)
        .where(eq(tvScripts.slug, input.slug))
        .limit(1);
      if (!result[0]) return null;
      return {
        ...result[0],
        features: result[0].features ? JSON.parse(result[0].features) : [],
        screenshots: result[0].screenshots
          ? JSON.parse(result[0].screenshots)
          : [],
      };
    }),

  /** Create a Stripe checkout session for a one-time script purchase */
  buyScript: protectedProcedure
    .input(z.object({ scriptId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const script = await db
        .select()
        .from(tvScripts)
        .where(eq(tvScripts.id, input.scriptId))
        .limit(1);

      if (!script[0]) throw new Error("Script not found");

      // Check if already purchased
      const existing = await db
        .select()
        .from(userPurchases)
        .where(
          and(
            eq(userPurchases.userId, ctx.user.id),
            eq(userPurchases.itemType, "script"),
            eq(userPurchases.itemId, input.scriptId),
            eq(userPurchases.status, "completed")
          )
        )
        .limit(1);

      if (existing.length > 0) {
        throw new Error("Vous possédez déjà ce script");
      }

      const stripe = getStripe();
      const origin = ctx.req.headers.origin || "http://localhost:3000";

      // Ensure Stripe customer exists
      let stripeCustomerId: string | undefined;
      const dbUser = await db
        .select()
        .from(users)
        .where(eq(users.id, ctx.user.id))
        .limit(1);

      if (dbUser[0]?.stripeCustomerId) {
        try {
          await stripe.customers.retrieve(dbUser[0].stripeCustomerId);
          stripeCustomerId = dbUser[0].stripeCustomerId;
        } catch {
          stripeCustomerId = undefined;
        }
      }

      if (!stripeCustomerId) {
        const customer = await stripe.customers.create({
          email: ctx.user.email || undefined,
          name: ctx.user.name || undefined,
          metadata: { user_id: ctx.user.id.toString() },
        });
        stripeCustomerId = customer.id;
        await db
          .update(users)
          .set({ stripeCustomerId: customer.id })
          .where(eq(users.id, ctx.user.id));
      }

      // Find or create a Stripe price for this script
      let stripePriceId = script[0].stripePriceId;

      if (!stripePriceId) {
        // Create a one-time Stripe product + price
        const product = await stripe.products.create({
          name: `Script TradingView — ${script[0].name}`,
          description: script[0].tagline || script[0].name,
          metadata: { app: "wmb", type: "script", scriptId: script[0].id.toString() },
        });

        const price = await stripe.prices.create({
          product: product.id,
          unit_amount: script[0].priceCents,
          currency: "chf",
          metadata: { app: "wmb", type: "script", scriptId: script[0].id.toString() },
        });

        stripePriceId = price.id;

        // Save the price ID for future use
        await db
          .update(tvScripts)
          .set({ stripePriceId: price.id })
          .where(eq(tvScripts.id, script[0].id));
      }

      const session = await stripe.checkout.sessions.create({
        customer: stripeCustomerId,
        client_reference_id: ctx.user.id.toString(),
        mode: "payment",
        allow_promotion_codes: true,
        line_items: [{ price: stripePriceId, quantity: 1 }],
        success_url: `${origin}/scripts?purchased=${script[0].slug}&success=true`,
        cancel_url: `${origin}/scripts?canceled=true`,
        metadata: {
          user_id: ctx.user.id.toString(),
          item_type: "script",
          item_id: script[0].id.toString(),
          item_name: script[0].name,
        },
      });

      // Create pending purchase record
      await db.insert(userPurchases).values({
        userId: ctx.user.id,
        itemType: "script",
        itemId: script[0].id,
        stripeSessionId: session.id,
        amountCents: script[0].priceCents,
        currency: "chf",
        status: "pending",
      });

      return { url: session.url };
    }),

  /** Check if user owns a specific script */
  checkScriptOwnership: protectedProcedure
    .input(z.object({ scriptId: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) return { owned: false };

      // Owner/admin bypass
      const isOwner =
        ctx.user.openId === ENV.ownerOpenId || ctx.user.role === "admin";
      if (isOwner) return { owned: true };

      const purchase = await db
        .select()
        .from(userPurchases)
        .where(
          and(
            eq(userPurchases.userId, ctx.user.id),
            eq(userPurchases.itemType, "script"),
            eq(userPurchases.itemId, input.scriptId),
            eq(userPurchases.status, "completed")
          )
        )
        .limit(1);

      return { owned: purchase.length > 0 };
    }),

  /** Get all user purchases */
  getUserPurchases: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    return db
      .select()
      .from(userPurchases)
      .where(
        and(
          eq(userPurchases.userId, ctx.user.id),
          eq(userPurchases.status, "completed")
        )
      )
      .orderBy(desc(userPurchases.createdAt));
  }),

  /* ═══════════════════════════════════════════════════════════
   * STRATEGIES
   * ═══════════════════════════════════════════════════════════ */

  /** List all active strategies */
  listStrategies: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    return db
      .select({
        id: strategies.id,
        slug: strategies.slug,
        name: strategies.name,
        tagline: strategies.tagline,
        category: strategies.category,
        difficulty: strategies.difficulty,
        timeframe: strategies.timeframe,
        riskLevel: strategies.riskLevel,
        previewContent: strategies.previewContent,
        accentColor: strategies.accentColor,
        includedInPremium: strategies.includedInPremium,
        priceCents: strategies.priceCents,
        sortOrder: strategies.sortOrder,
      })
      .from(strategies)
      .where(eq(strategies.isActive, 1))
      .orderBy(asc(strategies.sortOrder));
  }),

  /** Get a single strategy by slug (full content for premium users) */
  getStrategy: protectedProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) return null;

      const result = await db
        .select()
        .from(strategies)
        .where(eq(strategies.slug, input.slug))
        .limit(1);

      if (!result[0]) return null;

      const isOwner =
        ctx.user.openId === ENV.ownerOpenId || ctx.user.role === "admin";

      // Check if user has premium subscription
      let userHasAccess = isOwner;
      if (!isOwner && ctx.user) {
        const dbUser = await db
          .select({ subscriptionActive: users.subscriptionActive, subscriptionPlan: users.subscriptionPlan })
          .from(users)
          .where(eq(users.id, ctx.user.id))
          .limit(1);
        if (dbUser[0]?.subscriptionActive === 1 && dbUser[0]?.subscriptionPlan) {
          userHasAccess = true;
        }
      }

      if (!userHasAccess) {
        return {
          ...result[0],
          content: null,
          hasAccess: false,
        };
      }

      return {
        ...result[0],
        hasAccess: true,
      };
    }),

  /* ═══════════════════════════════════════════════════════════
   * GLOSSARY
   * ═══════════════════════════════════════════════════════════ */

  /** List all glossary terms */
  listGlossaryTerms: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    const result = await db
      .select()
      .from(glossaryTerms)
      .orderBy(asc(glossaryTerms.term));
    return result;
  }),

  /** Search glossary terms */
  searchGlossary: publicProcedure
    .input(z.object({ query: z.string().min(1) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      const result = await db
        .select()
        .from(glossaryTerms)
        .where(like(glossaryTerms.term, `%${input.query}%`))
        .orderBy(asc(glossaryTerms.term));
      return result;
    }),

  /* ═══════════════════════════════════════════════════════════
   * COURSE NOTES — Personal notes per lesson
   * ═══════════════════════════════════════════════════════════ */

  /** Get note for a specific lesson */
  getLessonNote: protectedProcedure
    .input(z.object({ lessonId: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) return null;
      const result = await db
        .select()
        .from(courseNotes)
        .where(
          and(
            eq(courseNotes.userId, ctx.user.id),
            eq(courseNotes.lessonId, input.lessonId)
          )
        )
        .limit(1);
      return result[0] || null;
    }),

  /** Get all notes for a course */
  getCourseNotes: protectedProcedure
    .input(z.object({ courseId: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db
        .select()
        .from(courseNotes)
        .where(
          and(
            eq(courseNotes.userId, ctx.user.id),
            eq(courseNotes.courseId, input.courseId)
          )
        )
        .orderBy(desc(courseNotes.updatedAt));
    }),

  /** Get all user notes across all courses */
  getAllNotes: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    return db
      .select()
      .from(courseNotes)
      .where(eq(courseNotes.userId, ctx.user.id))
      .orderBy(desc(courseNotes.updatedAt));
  }),

  /** Save or update a note for a lesson */
  saveNote: protectedProcedure
    .input(
      z.object({
        courseId: z.number(),
        lessonId: z.number(),
        content: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Check if note already exists
      const existing = await db
        .select()
        .from(courseNotes)
        .where(
          and(
            eq(courseNotes.userId, ctx.user.id),
            eq(courseNotes.lessonId, input.lessonId)
          )
        )
        .limit(1);

      if (existing.length > 0) {
        await db
          .update(courseNotes)
          .set({ content: input.content })
          .where(eq(courseNotes.id, existing[0].id));
        return { success: true, id: existing[0].id };
      } else {
        const result = await db.insert(courseNotes).values({
          userId: ctx.user.id,
          courseId: input.courseId,
          lessonId: input.lessonId,
          content: input.content,
        });
        return { success: true, id: result[0].insertId };
      }
    }),

  /** Delete a note */
  deleteNote: protectedProcedure
    .input(z.object({ noteId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      await db
        .delete(courseNotes)
        .where(
          and(
            eq(courseNotes.id, input.noteId),
            eq(courseNotes.userId, ctx.user.id)
          )
        );
      return { success: true };
    }),

  /* ═══════════════════════════════════════════════════════════
   * FORMATION STATE — A-Z Learning Path
   * ═══════════════════════════════════════════════════════════ */

  /** Get user's formation state (current position in A-Z path) */
  getFormationState: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return null;
    const result = await db
      .select()
      .from(userFormationState)
      .where(eq(userFormationState.userId, ctx.user.id))
      .limit(1);
    return result[0] || null;
  }),

  /** Start or update the formation journey */
  updateFormationState: protectedProcedure
    .input(
      z.object({
        currentCourseId: z.number().optional(),
        currentLessonId: z.number().optional(),
        addTimeSpent: z.number().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const existing = await db
        .select()
        .from(userFormationState)
        .where(eq(userFormationState.userId, ctx.user.id))
        .limit(1);

      if (existing.length > 0) {
        const updates: Record<string, any> = {};
        if (input.currentCourseId !== undefined) updates.currentCourseId = input.currentCourseId;
        if (input.currentLessonId !== undefined) updates.currentLessonId = input.currentLessonId;
        if (input.addTimeSpent) {
          updates.totalTimeSpent = sql`${userFormationState.totalTimeSpent} + ${input.addTimeSpent}`;
        }
        // Only update if there are actual values to set (Drizzle throws "No values to set" on empty object)
        if (Object.keys(updates).length > 0) {
          await db
            .update(userFormationState)
            .set(updates)
            .where(eq(userFormationState.id, existing[0].id));
        }
        return { success: true, id: existing[0].id };
      } else {
        const result = await db.insert(userFormationState).values({
          userId: ctx.user.id,
          currentCourseId: input.currentCourseId || null,
          currentLessonId: input.currentLessonId || null,
          totalTimeSpent: input.addTimeSpent || 0,
        });
        return { success: true, id: result[0].insertId };
      }
    }),

  /** Get the recommended next lesson in the A-Z path */
  getNextLesson: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return null;

    // Get all completed lessons
    const completed = await db
      .select()
      .from(userCourseProgress)
      .where(eq(userCourseProgress.userId, ctx.user.id));
    const completedLessonIds = new Set(completed.map((p) => p.lessonId));

    // Get all courses ordered by sortOrder
    const allCourses = await db
      .select()
      .from(courses)
      .orderBy(asc(courses.sortOrder));

    // For each course, find the first uncompleted lesson
    for (const course of allCourses) {
      const lessons = await db
        .select()
        .from(courseLessons)
        .where(eq(courseLessons.courseId, course.id))
        .orderBy(asc(courseLessons.sortOrder));

      for (const lesson of lessons) {
        if (!completedLessonIds.has(lesson.id)) {
          return { course, lesson };
        }
      }
    }

    // All lessons completed!
    return { course: null, lesson: null, allCompleted: true };
  }),

  /** Get formation statistics (total progress, time, etc.) */
  getFormationStats: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return { completedLessons: 0, totalLessons: 0, totalCourses: 0, completedCourses: 0, totalTimeSpent: 0, streak: 0 };

    // Total lessons and courses
    const allCourses = await db.select().from(courses).orderBy(asc(courses.sortOrder));
    const totalLessons = allCourses.reduce((sum, c) => sum + c.lessonCount, 0);

    // Completed lessons
    const completed = await db
      .select()
      .from(userCourseProgress)
      .where(eq(userCourseProgress.userId, ctx.user.id));
    const completedLessonIds = new Set(completed.map((p) => p.lessonId));

    // Count fully completed courses
    let completedCourses = 0;
    for (const course of allCourses) {
      const lessons = await db
        .select({ id: courseLessons.id })
        .from(courseLessons)
        .where(eq(courseLessons.courseId, course.id));
      if (lessons.length > 0 && lessons.every((l) => completedLessonIds.has(l.id))) {
        completedCourses++;
      }
    }

    // Formation state for time
    const state = await db
      .select()
      .from(userFormationState)
      .where(eq(userFormationState.userId, ctx.user.id))
      .limit(1);

    return {
      completedLessons: completedLessonIds.size,
      totalLessons,
      totalCourses: allCourses.length,
      completedCourses,
      totalTimeSpent: state[0]?.totalTimeSpent || 0,
      percentComplete: totalLessons > 0 ? Math.round((completedLessonIds.size / totalLessons) * 100) : 0,
    };
  }),

  /* ═══════════════════════════════════════════════════════════
   * QUIZ DE FIN DE MODULE
   * ═══════════════════════════════════════════════════════════ */

  /** Get quiz questions for a module category */
  getQuiz: protectedProcedure
    .input(z.object({ category: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      const questions = await db
        .select()
        .from(quizQuestions)
        .where(eq(quizQuestions.category, input.category))
        .orderBy(asc(quizQuestions.sortOrder));
      return questions.map((q) => ({
        id: q.id,
        question: q.question,
        options: JSON.parse(q.options) as string[],
        explanation: q.explanation,
        difficulty: q.difficulty,
        sortOrder: q.sortOrder,
      }));
    }),

  /** Submit quiz answers and get results */
  submitQuiz: protectedProcedure
    .input(z.object({
      category: z.string(),
      answers: z.array(z.object({
        questionId: z.number(),
        selectedAnswer: z.number(),
      })),
      timeSpentSeconds: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Get all questions for this quiz
      const questions = await db
        .select()
        .from(quizQuestions)
        .where(eq(quizQuestions.category, input.category));

      const questionMap = new Map(questions.map((q) => [q.id, q]));
      let correctCount = 0;
      const details: { questionId: number; correct: boolean; correctIndex: number; selectedAnswer: number; explanation: string | null }[] = [];

      for (const answer of input.answers) {
        const q = questionMap.get(answer.questionId);
        if (!q) continue;
        const isCorrect = answer.selectedAnswer === q.correctIndex;
        if (isCorrect) correctCount++;
        details.push({
          questionId: answer.questionId,
          correct: isCorrect,
          correctIndex: q.correctIndex,
          selectedAnswer: answer.selectedAnswer,
          explanation: q.explanation,
        });
      }

      const totalQuestions = input.answers.length;
      const percentage = totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0;
      const passed = percentage >= 70; // 70% pour valider

      // Save result
      await db.insert(quizResults).values({
        userId: ctx.user.id,
        category: input.category,
        score: correctCount,
        totalQuestions,
        percentage,
        passed: passed ? 1 : 0,
        timeTaken: input.timeSpentSeconds || 0,
        answers: JSON.stringify(input.answers),
      });

      return {
        percentage,
        totalQuestions,
        correctAnswers: correctCount,
        passed,
        details,
      };
    }),

  /** Get quiz history for a user (best results per category) */
  getQuizHistory: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    const results = await db
      .select()
      .from(quizResults)
      .where(eq(quizResults.userId, ctx.user.id))
      .orderBy(desc(quizResults.completedAt));
    return results;
  }),

  /** Get best quiz result for a specific category */
  getBestQuizResult: protectedProcedure
    .input(z.object({ category: z.string() }))
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) return null;
      const results = await db
        .select()
        .from(quizResults)
        .where(and(
          eq(quizResults.userId, ctx.user.id),
          eq(quizResults.category, input.category)
        ))
        .orderBy(desc(quizResults.score))
        .limit(1);
      return results[0] || null;
    }),

  /* ═══════════════════════════════════════════════════════════
   * EXPORT NOTES PDF
   * ═══════════════════════════════════════════════════════════ */

  /** Get all notes for a user with course/lesson details (for PDF export) */
  getAllNotesForExport: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    const notes = await db
      .select({
        id: courseNotes.id,
        content: courseNotes.content,
        updatedAt: courseNotes.updatedAt,
        lessonId: courseNotes.lessonId,
        courseId: courseNotes.courseId,
        lessonTitle: courseLessons.title,
        lessonSlug: courseLessons.slug,
        courseTitle: courses.title,
        courseSlug: courses.slug,
        courseCategory: courses.category,
      })
      .from(courseNotes)
      .innerJoin(courseLessons, eq(courseNotes.lessonId, courseLessons.id))
      .innerJoin(courses, eq(courseNotes.courseId, courses.id))
      .where(eq(courseNotes.userId, ctx.user.id))
      .orderBy(asc(courses.sortOrder), asc(courseLessons.sortOrder));
     return notes;
  }),

  /* ═══════════════════════════════════════════════════════════
   * BADGES
   * ═══════════════════════════════════════════════════════════ */

  /** Get all badges for the current user */
  getUserBadges: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    return db
      .select()
      .from(userBadges)
      .where(eq(userBadges.userId, ctx.user.id))
      .orderBy(asc(userBadges.earnedAt));
  }),

  /** Get badge progress: which modules are completed via quiz */
  getBadgeProgress: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return { badges: [], progress: [], hasMaster: false };

    const ALL_CATEGORIES = ["fondamentaux", "vehicules", "analyses", "indices", "histoire", "options"];

    // Get user's badges
    const badges = await db
      .select()
      .from(userBadges)
      .where(eq(userBadges.userId, ctx.user.id))
      .orderBy(asc(userBadges.earnedAt));

    // Get best quiz result per category
    const quizBests = await db
      .select({
        category: quizResults.category,
        bestScore: sql<number>`MAX(${quizResults.percentage})`,
        passed: sql<number>`MAX(${quizResults.passed})`,
        attempts: sql<number>`COUNT(*)`,
      })
      .from(quizResults)
      .where(eq(quizResults.userId, ctx.user.id))
      .groupBy(quizResults.category);

    // Get course completion per category
    const courseStats = await db
      .select({
        category: courses.category,
        totalLessons: sql<number>`COUNT(DISTINCT ${courseLessons.id})`,
        completedLessons: sql<number>`COUNT(DISTINCT ${userCourseProgress.lessonId})`,
      })
      .from(courses)
      .innerJoin(courseLessons, eq(courses.id, courseLessons.courseId))
      .leftJoin(
        userCourseProgress,
        and(
          eq(courseLessons.id, userCourseProgress.lessonId),
          eq(userCourseProgress.userId, ctx.user.id)
        )
      )
      .groupBy(courses.category);

    const progress = ALL_CATEGORIES.map((cat) => {
      const quiz = quizBests.find((q) => q.category === cat);
      const stats = courseStats.find((s) => s.category === cat);
      const badge = badges.find((b) => b.category === cat);
      return {
        category: cat,
        bestScore: quiz?.bestScore ?? 0,
        passed: (quiz?.passed ?? 0) > 0,
        attempts: quiz?.attempts ?? 0,
        totalLessons: stats?.totalLessons ?? 0,
        completedLessons: stats?.completedLessons ?? 0,
        hasBadge: !!badge,
        badgeEarnedAt: badge?.earnedAt ?? null,
      };
    });

    const hasMaster = badges.some((b) => b.badgeType === "master");

    return { badges, progress, hasMaster };
  }),

  /** Check and award badge after a quiz is passed */
  checkAndAwardBadge: protectedProcedure
    .input(z.object({ category: z.string(), quizResultId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return { awarded: false, badgeType: null, isNew: false };

      const { category, quizResultId } = input;

      // Check if quiz was actually passed
      const [quizResult] = await db
        .select()
        .from(quizResults)
        .where(
          and(
            eq(quizResults.id, quizResultId),
            eq(quizResults.userId, ctx.user.id),
            eq(quizResults.passed, 1)
          )
        )
        .limit(1);

      if (!quizResult) return { awarded: false, badgeType: null, isNew: false };

      const badgeType = `module_${category}`;

      // Check if badge already exists
      const [existing] = await db
        .select()
        .from(userBadges)
        .where(
          and(
            eq(userBadges.userId, ctx.user.id),
            eq(userBadges.badgeType, badgeType)
          )
        )
        .limit(1);

      if (existing) return { awarded: true, badgeType, isNew: false };

      // Award the module badge
      await db.insert(userBadges).values({
        userId: ctx.user.id,
        badgeType,
        category,
        quizScore: quizResult.percentage,
        quizResultId,
      });

      // Check if all 6 module badges are now earned → award master badge
      const ALL_CATEGORIES = ["fondamentaux", "vehicules", "analyses", "indices", "histoire", "options"];
      const allBadges = await db
        .select()
        .from(userBadges)
        .where(eq(userBadges.userId, ctx.user.id));

      const moduleBadges = allBadges.filter((b) => b.badgeType.startsWith("module_"));
      const earnedCategories = new Set(moduleBadges.map((b) => b.category));
      const allModulesCompleted = ALL_CATEGORIES.every((c) => earnedCategories.has(c));

      let masterAwarded = false;
      if (allModulesCompleted) {
        const [existingMaster] = await db
          .select()
          .from(userBadges)
          .where(
            and(
              eq(userBadges.userId, ctx.user.id),
              eq(userBadges.badgeType, "master")
            )
          )
          .limit(1);

        if (!existingMaster) {
          await db.insert(userBadges).values({
            userId: ctx.user.id,
            badgeType: "master",
            category: null,
            quizScore: Math.round(
              moduleBadges.reduce((sum, b) => sum + (b.quizScore ?? 0), 0) / moduleBadges.length
            ),
            quizResultId: null,
          });
          masterAwarded = true;
        }
      }

      return { awarded: true, badgeType, isNew: true, masterAwarded };
    }),
});
