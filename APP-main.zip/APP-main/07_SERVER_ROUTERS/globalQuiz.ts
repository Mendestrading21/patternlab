/**
 * Global Quiz Router — standalone quiz page with 30 questions per theme
 * Features:
 * - Random question selection (30 per session)
 * - Mixed mode (all themes) + category selection
 * - 5 free questions, paywall at question 6
 * - Score + skill level at the end
 * - Quiz history tracking
 */
import { z } from "zod";
import { publicProcedure, protectedProcedure, subscriberProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { globalQuizQuestions, globalQuizResults } from "../../drizzle/schema";
import { eq, sql, desc, and } from "drizzle-orm";

const THEMES = ["marches", "indicateurs", "glossaire", "formation", "etfs"] as const;
const FREE_QUESTION_LIMIT = 5;
const QUESTIONS_PER_SESSION = 30;

/** Shuffle options and adjust correctIndex so correct answer position is randomized */
function shuffleOptions(options: string[], correctIndex: number): { shuffledOptions: string[]; newCorrectIndex: number } {
  const correctAnswer = options[correctIndex];
  // Fisher-Yates shuffle
  const shuffled = [...options];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  const newCorrectIndex = shuffled.indexOf(correctAnswer);
  return { shuffledOptions: shuffled, newCorrectIndex };
}

/** Calculate skill level from score percentage */
function getSkillLevel(percentage: number): string {
  if (percentage >= 90) return "expert";
  if (percentage >= 70) return "avance";
  if (percentage >= 50) return "intermediaire";
  return "debutant";
}

/** Get French label for skill level */
function getSkillLevelLabel(level: string): string {
  const labels: Record<string, string> = {
    expert: "Expert",
    avance: "Avancé",
    intermediaire: "Intermédiaire",
    debutant: "Débutant",
  };
  return labels[level] || "Débutant";
}

export const globalQuizRouter = router({
  /** Get available themes with question counts — public */
  getThemes: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    const result = await db
      .select({
        theme: globalQuizQuestions.theme,
        count: sql<number>`count(*)`,
      })
      .from(globalQuizQuestions)
      .groupBy(globalQuizQuestions.theme);

    const themeLabels: Record<string, string> = {
      marches: "Marchés",
      indicateurs: "Indicateurs",
      glossaire: "Glossaire",
      formation: "Formation",
      etfs: "ETFs",
    };

    const themeIcons: Record<string, string> = {
      marches: "TrendingUp",
      indicateurs: "BarChart3",
      glossaire: "BookOpen",
      formation: "GraduationCap",
      etfs: "PieChart",
    };

    const themeColors: Record<string, string> = {
      marches: "#344453",
      indicateurs: "#2E7D5B",
      glossaire: "#D4A853",
      formation: "#1B6B93",
      etfs: "#8B3A62",
    };

    return result.map((r) => ({
      theme: r.theme,
      label: themeLabels[r.theme] || r.theme,
      icon: themeIcons[r.theme] || "HelpCircle",
      color: themeColors[r.theme] || "#344453",
      count: Number(r.count),
    }));
  }),

  /** Start a quiz session — returns first 5 questions (free) + session metadata */
  startQuiz: publicProcedure
    .input(
      z.object({
        theme: z.enum(["marches", "indicateurs", "glossaire", "formation", "etfs", "mixte"]),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) return { sessionTheme: input.theme, totalQuestions: 0, freeLimit: FREE_QUESTION_LIMIT, questionIds: [], freeQuestions: [] };
      let questions;

      if (input.theme === "mixte") {
        // Mixed mode: 6 questions per theme, randomly selected
        const allQuestions = [];
        for (const theme of THEMES) {
          const themeQuestions = await db
            .select()
            .from(globalQuizQuestions)
            .where(eq(globalQuizQuestions.theme, theme as string))
            .orderBy(sql`RAND()`)
            .limit(6);
          allQuestions.push(...themeQuestions);
        }
        // Shuffle the combined questions
        questions = allQuestions.sort(() => Math.random() - 0.5).slice(0, QUESTIONS_PER_SESSION);
      } else {
        // Single theme: 30 random questions
        questions = await db
          .select()
          .from(globalQuizQuestions)
          .where(eq(globalQuizQuestions.theme, input.theme))
          .orderBy(sql`RAND()`)
          .limit(QUESTIONS_PER_SESSION);
      }

      // Return all question IDs but only first 5 questions' full data
      const questionIds = questions.map((q) => q.id);
      const freeQuestions = questions.slice(0, FREE_QUESTION_LIMIT).map((q: any) => {
        const parsedOptions = JSON.parse(q.options);
        const { shuffledOptions, newCorrectIndex } = shuffleOptions(parsedOptions, q.correctIndex);
        return {
          id: q.id,
          theme: q.theme,
          question: q.question,
          options: shuffledOptions,
          shuffledCorrectIndex: newCorrectIndex,
          difficulty: q.difficulty,
        };
      });

      return {
        sessionTheme: input.theme,
        totalQuestions: questions.length,
        freeLimit: FREE_QUESTION_LIMIT,
        questionIds,
        freeQuestions,
      };
    }),

  /** Get premium questions (6-30) — requires Academy or Pro subscription */
  getPremiumQuestions: subscriberProcedure
    .input(
      z.object({
        questionIds: z.array(z.number()),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      // Get questions 6-30 (skip first 5 which were already sent as free)
      const premiumIds = input.questionIds.slice(FREE_QUESTION_LIMIT);

      if (premiumIds.length === 0) return [];

      const questions = await db
        .select()
        .from(globalQuizQuestions)
        .where(sql`${globalQuizQuestions.id} IN (${sql.join(premiumIds.map(id => sql`${id}`), sql`, `)})`);

      // Sort by the order in questionIds
      const idOrder = new Map(premiumIds.map((id, idx) => [id, idx]));
      questions.sort((a: typeof globalQuizQuestions.$inferSelect, b: typeof globalQuizQuestions.$inferSelect) => (idOrder.get(a.id) ?? 0) - (idOrder.get(b.id) ?? 0));

      return questions.map((q: typeof globalQuizQuestions.$inferSelect) => {
        const parsedOptions = JSON.parse(q.options);
        const { shuffledOptions, newCorrectIndex } = shuffleOptions(parsedOptions, q.correctIndex);
        return {
          id: q.id,
          theme: q.theme,
          question: q.question,
          options: shuffledOptions,
          shuffledCorrectIndex: newCorrectIndex,
          difficulty: q.difficulty,
        };
      });
    }),

  /** Check answer — public for first 5, subscriber for rest */
  checkAnswer: publicProcedure
    .input(
      z.object({
        questionId: z.number(),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return null;
      const [question] = await db
        .select()
        .from(globalQuizQuestions)
        .where(eq(globalQuizQuestions.id, input.questionId))
        .limit(1);

      if (!question) return null;

      return {
        correctIndex: question.correctIndex,
        explanation: question.explanation,
      };
    }),

  /** Submit quiz results — requires auth */
  submitResult: protectedProcedure
    .input(
      z.object({
        theme: z.string(),
        score: z.number(),
        totalQuestions: z.number(),
        timeTaken: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error('Database unavailable');
      const percentage = (input.score / input.totalQuestions) * 100;
      const skillLevel = getSkillLevel(percentage);

      await db.insert(globalQuizResults).values({
        userId: ctx.user.id,
        theme: input.theme,
        score: input.score,
        totalQuestions: input.totalQuestions,
        skillLevel,
        timeTaken: input.timeTaken ?? null,
      });

      return {
        score: input.score,
        totalQuestions: input.totalQuestions,
        percentage: Math.round(percentage),
        skillLevel,
        skillLevelLabel: getSkillLevelLabel(skillLevel),
      };
    }),

  /** Get quiz history for current user */
  getHistory: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    const results = await db
      .select()
      .from(globalQuizResults)
      .where(eq(globalQuizResults.userId, ctx.user.id))
      .orderBy(desc(globalQuizResults.completedAt))
      .limit(20);

    const themeLabels: Record<string, string> = {
      marches: "Marchés",
      indicateurs: "Indicateurs",
      glossaire: "Glossaire",
      formation: "Formation",
      etfs: "ETFs",
      mixte: "Mixte",
    };

    return results.map((r: any) => ({
      ...r,
      themeLabel: themeLabels[r.theme] || r.theme,
      percentage: Math.round((r.score / r.totalQuestions) * 100),
      skillLevelLabel: getSkillLevelLabel(r.skillLevel),
    }));
  }),

  /** Get best score per theme for current user */
  getBestScores: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    const results = await db
      .select({
        theme: globalQuizResults.theme,
        bestScore: sql<number>`MAX(score)`,
        totalQuestions: sql<number>`MAX(totalQuestions)`,
        bestSkillLevel: sql<string>`(SELECT skillLevel FROM globalQuizResults g2 WHERE g2.userId = ${ctx.user.id} AND g2.theme = globalQuizResults.theme ORDER BY score DESC LIMIT 1)`,
        attempts: sql<number>`COUNT(*)`,
      })
      .from(globalQuizResults)
      .where(eq(globalQuizResults.userId, ctx.user.id))
      .groupBy(globalQuizResults.theme);

    return results.map((r: any) => ({
      theme: r.theme,
      bestScore: Number(r.bestScore),
      totalQuestions: Number(r.totalQuestions),
      bestPercentage: Math.round((Number(r.bestScore) / Number(r.totalQuestions)) * 100),
      bestSkillLevel: r.bestSkillLevel,
      bestSkillLevelLabel: getSkillLevelLabel(r.bestSkillLevel),
      attempts: Number(r.attempts),
    }));
  }),
});
