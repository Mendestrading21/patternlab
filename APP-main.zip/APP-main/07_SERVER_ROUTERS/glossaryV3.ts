/**
 * Glossaire v3 Router — Quiz, Flashcards, Paths, Progress
 * Free users: 20 terms max, no flashcards/quiz/paths
 * Subscribers: full access
 */
import { z } from "zod";
import { publicProcedure, protectedProcedure, subscriberProcedure } from "../_core/trpc";
import { router } from "../_core/trpc";
import { getDb } from "../db";
import {
  glossaryTerms,
  glossaryQuizQuestions,
  glossaryPaths,
  userGlossaryProgress,
  userGlossaryQuizScores,
} from "../../drizzle/schema";
import { eq, and, sql, inArray, like, desc } from "drizzle-orm";

/** Free users see at most 20 terms */
const FREE_GLOSSARY_LIMIT = 20;

export const glossaryV3Router = router({
  /** Get all terms with optional filters — free users capped at 20 */
  terms: publicProcedure
    .input(
      z.object({
        category: z.string().optional(),
        level: z.string().optional(),
        search: z.string().optional(),
        limit: z.number().optional().default(50),
        offset: z.number().optional().default(0),
      }).optional()
    )
    .query(async ({ input, ctx }) => {
      const db = await getDb();
      if (!db) return { terms: [], total: 0, limited: false };
      const category = input?.category;
      const level = input?.level;
      const search = input?.search;
      let limit = input?.limit ?? 50;
      let offset = input?.offset ?? 0;

      // Check if user is a subscriber
      const isSubscriber = ctx.user && (ctx.user.subscriptionActive === 1 || ctx.user.role === 'admin');

      const conditions: any[] = [];
      if (category) conditions.push(eq(glossaryTerms.category, category));
      if (level) conditions.push(eq(glossaryTerms.level, level));
      if (search) conditions.push(like(glossaryTerms.term, `%${search}%`));

      const where = conditions.length > 0 ? and(...conditions) : undefined;

      // Get total count (always show real total so user knows how much content exists)
      const [countResult] = await db.select({ count: sql<number>`count(*)` }).from(glossaryTerms).where(where);
      const total = Number(countResult?.count || 0);

      // For free users: cap at FREE_GLOSSARY_LIMIT terms, no pagination beyond that
      let limited = false;
      if (!isSubscriber) {
        if (offset >= FREE_GLOSSARY_LIMIT) {
          return { terms: [], total, limited: true };
        }
        limit = Math.min(limit, FREE_GLOSSARY_LIMIT - offset);
        limited = total > FREE_GLOSSARY_LIMIT;
      }

      const terms = await db.select().from(glossaryTerms).where(where).limit(limit).offset(offset).orderBy(glossaryTerms.term);
      return { terms, total, limited };
    }),

  /** Get a single term by slug — public (individual term lookup is fine) */
  termBySlug: publicProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return null;
      const [term] = await db.select().from(glossaryTerms).where(eq(glossaryTerms.slug, input.slug)).limit(1);
      return term || null;
    }),

  /** Get categories with counts — public (metadata) */
  categories: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    const result = await db
      .select({ category: glossaryTerms.category, count: sql<number>`count(*)` })
      .from(glossaryTerms)
      .groupBy(glossaryTerms.category)
      .orderBy(desc(sql`count(*)`));
    return result.map((r) => ({ category: r.category, count: Number(r.count) }));
  }),

  /** Get random flashcards — SUBSCRIBERS ONLY */
  flashcards: subscriberProcedure
    .input(
      z.object({
        count: z.number().default(10),
        category: z.string().optional(),
        level: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      const conditions: any[] = [];
      if (input.category) conditions.push(eq(glossaryTerms.category, input.category));
      if (input.level) conditions.push(eq(glossaryTerms.level, input.level));
      const where = conditions.length > 0 ? and(...conditions) : undefined;
      const terms = await db
        .select()
        .from(glossaryTerms)
        .where(where)
        .orderBy(sql`RAND()`)
        .limit(input.count);
      return terms;
    }),

  /** Get quiz questions — SUBSCRIBERS ONLY */
  quizQuestions: subscriberProcedure
    .input(
      z.object({
        count: z.number().default(10),
        difficulty: z.string().optional(),
        questionType: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      const conditions: any[] = [];
      if (input.difficulty) conditions.push(eq(glossaryQuizQuestions.difficulty, input.difficulty));
      if (input.questionType) conditions.push(eq(glossaryQuizQuestions.questionType, input.questionType));
      const where = conditions.length > 0 ? and(...conditions) : undefined;
      const questions = await db
        .select()
        .from(glossaryQuizQuestions)
        .where(where)
        .orderBy(sql`RAND()`)
        .limit(input.count);
      return questions;
    }),

  /** Get all learning paths — SUBSCRIBERS ONLY */
  paths: subscriberProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(glossaryPaths).orderBy(glossaryPaths.sortOrder);
  }),

  /** Get a single path with its terms — SUBSCRIBERS ONLY */
  pathBySlug: subscriberProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return null;
      const [path] = await db.select().from(glossaryPaths).where(eq(glossaryPaths.slug, input.slug)).limit(1);
      if (!path) return null;
      const termIds: number[] = JSON.parse(path.termIds);
      let pathTerms: any[] = [];
      if (termIds.length > 0) {
        pathTerms = await db.select().from(glossaryTerms).where(inArray(glossaryTerms.id, termIds));
        // Sort by the order in termIds
        pathTerms.sort((a, b) => termIds.indexOf(a.id) - termIds.indexOf(b.id));
      }
      return { ...path, terms: pathTerms };
    }),

  /** Get user progress (flashcard mastery) — SUBSCRIBERS ONLY */
  userProgress: subscriberProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return { known: 0, review: 0, unseen: 0, total: 0, items: [] };
    const items = await db
      .select()
      .from(userGlossaryProgress)
      .where(eq(userGlossaryProgress.userId, ctx.user.id));
    const known = items.filter((i) => i.status === "known").length;
    const review = items.filter((i) => i.status === "review").length;
    const [totalResult] = await db.select({ count: sql<number>`count(*)` }).from(glossaryTerms);
    const total = Number(totalResult?.count || 0);
    return { known, review, unseen: total - known - review, total, items };
  }),

  /** Update flashcard progress — SUBSCRIBERS ONLY */
  updateProgress: subscriberProcedure
    .input(
      z.object({
        termId: z.number(),
        status: z.enum(["known", "review", "unseen"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return false;
      const existing = await db
        .select()
        .from(userGlossaryProgress)
        .where(and(eq(userGlossaryProgress.userId, ctx.user.id), eq(userGlossaryProgress.termId, input.termId)))
        .limit(1);
      if (existing.length > 0) {
        await db
          .update(userGlossaryProgress)
          .set({
            status: input.status,
            reviewCount: sql`${userGlossaryProgress.reviewCount} + 1`,
            lastReviewedAt: new Date(),
          })
          .where(eq(userGlossaryProgress.id, existing[0].id));
      } else {
        await db.insert(userGlossaryProgress).values({
          userId: ctx.user.id,
          termId: input.termId,
          status: input.status,
          reviewCount: 1,
          lastReviewedAt: new Date(),
        });
      }
      return true;
    }),

  /** Save quiz score — SUBSCRIBERS ONLY */
  saveQuizScore: subscriberProcedure
    .input(
      z.object({
        quizType: z.string().default("general"),
        pathId: z.number().optional(),
        totalQuestions: z.number(),
        correctAnswers: z.number(),
        score: z.number(),
        difficulty: z.string().default("debutant"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return false;
      await db.insert(userGlossaryQuizScores).values({
        userId: ctx.user.id,
        quizType: input.quizType,
        pathId: input.pathId || null,
        totalQuestions: input.totalQuestions,
        correctAnswers: input.correctAnswers,
        score: input.score,
        difficulty: input.difficulty,
      });
      return true;
    }),

  /** Get user quiz history — SUBSCRIBERS ONLY */
  quizHistory: subscriberProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    return db
      .select()
      .from(userGlossaryQuizScores)
      .where(eq(userGlossaryQuizScores.userId, ctx.user.id))
      .orderBy(desc(userGlossaryQuizScores.completedAt))
      .limit(20);
  }),

  /** Get glossary stats — public (metadata for marketing) */
  stats: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return { totalTerms: 0, categories: 0, paths: 0, questions: 0 };
    const [[termsCount], [catsCount], [pathsCount], [questionsCount]] = await Promise.all([
      db.select({ count: sql<number>`count(*)` }).from(glossaryTerms),
      db.select({ count: sql<number>`count(distinct ${glossaryTerms.category})` }).from(glossaryTerms),
      db.select({ count: sql<number>`count(*)` }).from(glossaryPaths),
      db.select({ count: sql<number>`count(*)` }).from(glossaryQuizQuestions),
    ]);
    return {
      totalTerms: Number(termsCount?.count || 0),
      categories: Number(catsCount?.count || 0),
      paths: Number(pathsCount?.count || 0),
      questions: Number(questionsCount?.count || 0),
    };
  }),
});
