import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, json, decimal, bigint, tinyint, index } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Supports: Manus OAuth, Email+Password, Google OAuth.
 * Extended with Stripe subscription fields for WMB.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),

  /** Auth provider: manus | email | google */
  authProvider: varchar("authProvider", { length: 32 }).default("manus"),
  /** Bcrypt-hashed password (only for email auth) */
  passwordHash: text("passwordHash"),
  /** Whether the email has been verified */
  emailVerified: int("emailVerified").default(0).notNull(),
  /** Token for email verification */
  emailVerificationToken: varchar("emailVerificationToken", { length: 128 }),
  /** Token for password reset */
  passwordResetToken: varchar("passwordResetToken", { length: 128 }),
  /** Expiry for password reset token */
  passwordResetExpires: timestamp("passwordResetExpires"),
  /** Google OAuth sub (unique Google user ID) */
  googleId: varchar("googleId", { length: 128 }),

  /** Stripe customer ID — linked on first checkout */
  stripeCustomerId: varchar("stripeCustomerId", { length: 128 }),
  /** Active Stripe subscription ID */
  stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 128 }),
  /** Subscription plan key: monthly | annual */
  subscriptionPlan: varchar("subscriptionPlan", { length: 32 }),
  /** Whether the subscription is currently active (1 = active, 0 = inactive) */
  subscriptionActive: int("subscriptionActive").default(0).notNull(),
  /** Whether user has opted out of newsletter emails (1 = unsubscribed, 0 = subscribed) */
  newsletterOptOut: int("newsletterOptOut").default(0).notNull(),
  /** Secure token for one-click unsubscribe from email */
  unsubscribeToken: varchar("unsubscribeToken", { length: 128 }),
  /** TOTP secret for 2FA (encrypted, only for admin accounts) */
  totpSecret: text("totpSecret"),
  /** Whether 2FA is enabled (1 = enabled, 0 = disabled) */
  totpEnabled: int("totpEnabled").default(0).notNull(),
  /** Email notification preferences — JSON string of preferences */
  notifPrefs: text("notifPrefs"),
  /** Onboarding email sequence step (0=none sent, 1=welcome, 2=guide, 3=premium push) */
  onboardingStep: int("onboardingStep").default(0).notNull(),
  /** When the last onboarding email was sent */
  onboardingLastSent: timestamp("onboardingLastSent"),
  /** Number of complete onboarding loops (cycles of 7 emails completed) */
  onboardingLoopCount: int("onboardingLoopCount").default(0).notNull(),
  /** Conversion status for CRM tracking: cold | warm | hot | converted */
  conversionStatus: varchar("conversionStatus", { length: 32 }).default("cold"),
  /** Admin note — internal note visible only to admin */
  adminNote: text("adminNote"),
  /** Unique referral code for this user (auto-generated on first access) */
  referralCode: varchar("referralCode", { length: 32 }),
  /** User ID of who referred this user (null if organic) */
  referredBy: int("referredBy"),
  /** Whether a re-engagement email has been sent (1 = sent, 0 = not sent) */
  reengagementSent: int("reengagementSent").default(0).notNull(),
  /** When the user cancelled their subscription (null if never cancelled) */
  cancellationDate: timestamp("cancellationDate"),
  /** End date of the current paid period — access maintained until this date after cancellation */
  subscriptionEndDate: timestamp("subscriptionEndDate"),
  /** Comma-separated list of anniversary milestones already sent (e.g. "1m,3m,6m") */
  anniversaryEmailsSent: varchar("anniversaryEmailsSent", { length: 128 }).default(""),
  /** When the last admin "new subscriber" notification was sent for this user */
  adminNotifiedAt: timestamp("adminNotifiedAt"),
  /** Detected country code (ISO 3166-1 alpha-2, e.g. CH, FR, BE) */
  country: varchar("country", { length: 8 }),
  /** Total number of site visits / logins */
  visitCount: int("visitCount").default(0).notNull(),
  /** UTM source (google, facebook, instagram, email, direct, etc.) */
  utmSource: varchar("utmSource", { length: 128 }),
  /** UTM medium (cpc, organic, social, email, etc.) */
  utmMedium: varchar("utmMedium", { length: 128 }),
  /** UTM campaign name */
  utmCampaign: varchar("utmCampaign", { length: 256 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Editions table — stores each weekly newsletter edition metadata
 */
export const editions = mysqlTable("editions", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 512 }).notNull(),
  summary: text("summary"),
  editionNumber: int("editionNumber").notNull(),
  /** S3 key for the PDF file */
  pdfKey: varchar("pdfKey", { length: 512 }),
  pdfUrl: text("pdfUrl"),
  /** S3 key for the cover image */
  coverKey: varchar("coverKey", { length: 512 }),
  coverUrl: text("coverUrl"),
  /** Whether this edition is free (1 = free, 0 = subscribers only) */
  isFree: int("isFree").default(0).notNull(),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Edition = typeof editions.$inferSelect;
export type InsertEdition = typeof editions.$inferInsert;

/**
 * Contact messages table
 */
export const contactMessages = mysqlTable("contactMessages", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 256 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  subject: varchar("subject", { length: 512 }),
  message: text("message").notNull(),
  isRead: int("isRead").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ContactMessage = typeof contactMessages.$inferSelect;
export type InsertContactMessage = typeof contactMessages.$inferInsert;

/**
 * Email campaigns table — tracks all emails sent from admin dashboard
 */
export const emailCampaigns = mysqlTable("emailCampaigns", {
  id: int("id").autoincrement().primaryKey(),
  subject: varchar("subject", { length: 512 }).notNull(),
  /** Target audience: all | active | monthly | annual | free */
  audience: varchar("audience", { length: 64 }).notNull(),
  /** Template used: custom | new_edition | announcement | report */
  template: varchar("template", { length: 64 }).notNull().default("custom"),
  /** Number of recipients */
  recipientCount: int("recipientCount").notNull().default(0),
  /** Number of emails successfully sent */
  sentCount: int("sentCount").notNull().default(0),
  /** Number of emails that failed */
  failedCount: int("failedCount").notNull().default(0),
  /** Status: draft | sending | sent | failed */
  status: varchar("status", { length: 32 }).notNull().default("draft"),
  /** Admin user ID who sent the campaign */
  sentBy: int("sentBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  sentAt: timestamp("sentAt"),
});

export type EmailCampaign = typeof emailCampaigns.$inferSelect;
export type InsertEmailCampaign = typeof emailCampaigns.$inferInsert;

/**
 * Portfolio positions — virtual portfolio tracking for premium users
 * Each row = one position (long or short) in a user's virtual portfolio
 */
export const portfolioPositions = mysqlTable("portfolioPositions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  /** Ticker symbol, e.g. AAPL, MSFT, BTC-USD */
  symbol: varchar("symbol", { length: 32 }).notNull(),
  /** Display name, e.g. "Apple Inc." */
  name: varchar("name", { length: 256 }),
  /** Position type: long or short */
  positionType: mysqlEnum("positionType", ["long", "short"]).default("long").notNull(),
  /** Number of shares/units */
  quantity: int("quantity").notNull(),
  /** Entry price per share in USD */
  entryPrice: varchar("entryPrice", { length: 32 }).notNull(),
  /** Optional stop-loss price */
  stopLoss: varchar("stopLoss", { length: 32 }),
  /** Optional take-profit price */
  takeProfit: varchar("takeProfit", { length: 32 }),
  /** User notes */
  notes: text("notes"),
  /** Whether the position is still open */
  isOpen: int("isOpen").default(1).notNull(),
  /** Close price (when position is closed) */
  closePrice: varchar("closePrice", { length: 32 }),
  closedAt: timestamp("closedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PortfolioPosition = typeof portfolioPositions.$inferSelect;
export type InsertPortfolioPosition = typeof portfolioPositions.$inferInsert;

/**
 * Formation — Course modules (Académie WMB)
 * Each course = one learning module (e.g. "La Bourse", "Analyse Technique")
 */
export const courses = mysqlTable("courses", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 128 }).notNull().unique(),
  title: varchar("title", { length: 256 }).notNull(),
  description: text("description"),
  /** Module number for ordering (e.g. 1, 2, 3) */
  moduleNumber: int("moduleNumber").notNull().default(0),
  /** Category: fondamentaux | vehicules | analyses | indices | histoire | culture */
  category: varchar("category", { length: 64 }).notNull(),
  /** Icon name from lucide-react */
  icon: varchar("icon", { length: 64 }),
  /** Number of lessons in this course */
  lessonCount: int("lessonCount").notNull().default(0),
  /** Estimated reading time in minutes */
  estimatedMinutes: int("estimatedMinutes").notNull().default(15),
  /** Difficulty: debutant | intermediaire | avance */
  difficulty: varchar("difficulty", { length: 32 }).notNull().default("debutant"),
  /** Whether this course is free (1) or premium (0) */
  isFree: int("isFree").default(0).notNull(),
  /** Cover image URL */
  coverUrl: text("coverUrl"),
  /** Sort order */
  sortOrder: int("sortOrder").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Course = typeof courses.$inferSelect;
export type InsertCourse = typeof courses.$inferInsert;

/**
 * Course lessons — individual lessons within a course
 */
export const courseLessons = mysqlTable("courseLessons", {
  id: int("id").autoincrement().primaryKey(),
  courseId: int("courseId").notNull(),
  slug: varchar("slug", { length: 128 }).notNull(),
  title: varchar("title", { length: 256 }).notNull(),
  /** Lesson content in Markdown */
  content: text("content"),
  /** Lesson order within the course */
  sortOrder: int("sortOrder").notNull().default(0),
  /** Whether this lesson is a free preview */
  isFreePreview: int("isFreePreview").default(0).notNull(),
  /** Estimated reading time in minutes */
  estimatedMinutes: int("estimatedMinutes").notNull().default(5),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CourseLesson = typeof courseLessons.$inferSelect;
export type InsertCourseLesson = typeof courseLessons.$inferInsert;

/**
 * User course progress — tracks which lessons a user has completed
 */
export const userCourseProgress = mysqlTable("userCourseProgress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  courseId: int("courseId").notNull(),
  lessonId: int("lessonId").notNull(),
  completedAt: timestamp("completedAt").defaultNow().notNull(),
});

export type UserCourseProgress = typeof userCourseProgress.$inferSelect;

/**
 * TradingView Scripts — marketplace items
 */
export const tvScripts = mysqlTable("tvScripts", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 128 }).notNull().unique(),
  name: varchar("name", { length: 256 }).notNull(),
  description: text("description"),
  /** Short tagline */
  tagline: varchar("tagline", { length: 256 }),
  /** Category: trend | volume | momentum | oscillator | overlay */
  category: varchar("category", { length: 64 }).notNull(),
  /** Price in CHF cents (e.g. 4900 = 49 CHF) */
  priceCents: int("priceCents").notNull(),
  /** Stripe Price ID for one-time purchase */
  stripePriceId: varchar("stripePriceId", { length: 128 }),
  /** Features list (JSON array of strings) */
  features: text("features"),
  /** Screenshot URLs (JSON array of strings) */
  screenshots: text("screenshots"),
  /** Icon/badge color */
  accentColor: varchar("accentColor", { length: 32 }),
  /** Whether it's included in premium subscription */
  includedInPremium: int("includedInPremium").default(0).notNull(),
  /** Sort order */
  sortOrder: int("sortOrder").notNull().default(0),
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TvScript = typeof tvScripts.$inferSelect;
export type InsertTvScript = typeof tvScripts.$inferInsert;

/**
 * Trading Strategies — catalog items
 */
export const strategies = mysqlTable("strategies", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 128 }).notNull().unique(),
  name: varchar("name", { length: 256 }).notNull(),
  description: text("description"),
  /** Short tagline */
  tagline: varchar("tagline", { length: 256 }),
  /** Category: options | actions | dividendes | penny | pedagogie */
  category: varchar("category", { length: 64 }).notNull(),
  /** Difficulty: debutant | intermediaire | avance */
  difficulty: varchar("difficulty", { length: 32 }).notNull().default("intermediaire"),
  /** Timeframe: court | moyen | long */
  timeframe: varchar("timeframe", { length: 32 }),
  /** Risk level: faible | modere | eleve */
  riskLevel: varchar("riskLevel", { length: 32 }),
  /** Strategy content in Markdown (premium only) */
  content: text("content"),
  /** Preview content (visible to all) */
  previewContent: text("previewContent"),
  /** Icon/badge color */
  accentColor: varchar("accentColor", { length: 32 }),
  /** Whether included in premium subscription (1=yes) */
  includedInPremium: int("includedInPremium").default(1).notNull(),
  /** Price in CHF cents for one-time purchase (0 = premium only) */
  priceCents: int("priceCents").notNull().default(0),
  /** Stripe Price ID for one-time purchase */
  stripePriceId: varchar("stripePriceId", { length: 128 }),
  sortOrder: int("sortOrder").notNull().default(0),
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Strategy = typeof strategies.$inferSelect;
export type InsertStrategy = typeof strategies.$inferInsert;

/**
 * User purchases — tracks one-time purchases (scripts, strategy packs)
 */
export const userPurchases = mysqlTable("userPurchases", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  /** Type of purchase: script | strategy | bundle */
  itemType: varchar("itemType", { length: 32 }).notNull(),
  /** ID of the purchased item */
  itemId: int("itemId").notNull(),
  /** Stripe Payment Intent ID */
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 128 }),
  /** Stripe Checkout Session ID */
  stripeSessionId: varchar("stripeSessionId", { length: 128 }),
  /** Amount paid in cents */
  amountCents: int("amountCents").notNull(),
  /** Currency */
  currency: varchar("currency", { length: 8 }).notNull().default("chf"),
  /** Status: pending | completed | refunded */
  status: varchar("status", { length: 32 }).notNull().default("pending"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserPurchase = typeof userPurchases.$inferSelect;
export type InsertUserPurchase = typeof userPurchases.$inferInsert;

/**
 * Glossary Terms — financial vocabulary for the academy
 */
export const glossaryTerms = mysqlTable("glossaryTerms", {
  id: int("id").autoincrement().primaryKey(),
  term: varchar("term", { length: 256 }).notNull(),
  slug: varchar("slug", { length: 256 }).notNull().unique(),
  definition: text("definition").notNull(),
  /** Level: debutant | intermediaire | avance */
  level: varchar("level", { length: 32 }).notNull().default("debutant"),
  /** Category: marche | analyse | instrument | risque | ordre | indicateur */
  category: varchar("category", { length: 64 }).notNull().default("marche"),
  /** Related course ID (optional) */
  relatedCourseId: int("relatedCourseId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GlossaryTerm = typeof glossaryTerms.$inferSelect;
export type InsertGlossaryTerm = typeof glossaryTerms.$inferInsert;


/**
 * Invoices — stores generated PDF invoices for subscription payments
 */
export const invoices = mysqlTable("invoices", {
  id: int("id").autoincrement().primaryKey(),
  /** Reference to the user */
  userId: int("userId").notNull(),
  /** Unique invoice number (WMB-YYYY-NNNN) */
  invoiceNumber: varchar("invoiceNumber", { length: 64 }).notNull().unique(),
  /** Stripe invoice ID for reference */
  stripeInvoiceId: varchar("stripeInvoiceId", { length: 128 }),
  /** Stripe payment intent ID */
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 128 }),
  /** Amount in cents */
  amountCents: int("amountCents").notNull(),
  /** Currency */
  currency: varchar("currency", { length: 8 }).notNull().default("CHF"),
  /** Subscription plan: monthly | annual */
  plan: varchar("plan", { length: 32 }),
  /** Period start */
  periodStart: timestamp("periodStart"),
  /** Period end */
  periodEnd: timestamp("periodEnd"),
  /** S3 URL of the generated PDF */
  pdfUrl: text("pdfUrl"),
  /** S3 key of the generated PDF */
  pdfKey: varchar("pdfKey", { length: 512 }),
  /** Status: paid | refunded | void */
  status: varchar("status", { length: 32 }).notNull().default("paid"),
  /** Invoice date */
  invoiceDate: timestamp("invoiceDate").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = typeof invoices.$inferInsert;

/**
 * Position Notes — personal notes for tracking stock/ETF positions
 * Inspired by IBKR Notes: each note = one ticker with free-form text
 */
export const positionNotes = mysqlTable("positionNotes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  /** Ticker symbol, e.g. SOFI, MRVL, URA, XLE */
  symbol: varchar("symbol", { length: 32 }).notNull(),
  /** Display name, e.g. "SoFi Technologies" */
  name: varchar("name", { length: 256 }),
  /** Free-form note content (Markdown or plain text) */
  content: text("content"),
  /** Color tag for visual organization */
  colorTag: varchar("colorTag", { length: 32 }).default("blue"),
  /** Whether this note is pinned to the top */
  isPinned: int("isPinned").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PositionNote = typeof positionNotes.$inferSelect;
export type InsertPositionNote = typeof positionNotes.$inferInsert;

/**
 * Course Notes — personal notes taken by users during lessons
 * Each note is linked to a specific lesson within a course
 */
export const courseNotes = mysqlTable("courseNotes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  courseId: int("courseId").notNull(),
  lessonId: int("lessonId").notNull(),
  /** Note content in plain text or Markdown */
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CourseNote = typeof courseNotes.$inferSelect;
export type InsertCourseNote = typeof courseNotes.$inferInsert;

/**
 * User Formation State — tracks the user's overall formation journey
 * Stores the current position in the A-Z learning path
 */
export const userFormationState = mysqlTable("userFormationState", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  /** Current course ID the user is working on */
  currentCourseId: int("currentCourseId"),
  /** Current lesson ID the user is working on */
  currentLessonId: int("currentLessonId"),
  /** Total time spent in minutes (accumulated) */
  totalTimeSpent: int("totalTimeSpent").default(0).notNull(),
  /** When the user started the formation */
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  /** Last activity timestamp */
  lastActivityAt: timestamp("lastActivityAt").defaultNow().onUpdateNow().notNull(),
});

export type UserFormationState = typeof userFormationState.$inferSelect;
export type InsertUserFormationState = typeof userFormationState.$inferInsert;

/**
 * Quiz Questions — questions de validation de fin de module
 * Chaque question est liée à une catégorie de module (fondamentaux, vehicules, etc.)
 */
export const quizQuestions = mysqlTable("quizQuestions", {
  id: int("id").autoincrement().primaryKey(),
  /** Module category: fondamentaux | vehicules | analyses | indices | histoire | options */
  category: varchar("category", { length: 64 }).notNull(),
  /** Question text */
  question: text("question").notNull(),
  /** JSON array of 4 answer options */
  options: text("options").notNull(),
  /** Index of the correct answer (0-3) */
  correctIndex: int("correctIndex").notNull(),
  /** Explanation shown after answering */
  explanation: text("explanation"),
  /** Difficulty: facile | moyen | difficile */
  difficulty: varchar("difficulty", { length: 32 }).notNull().default("moyen"),
  /** Sort order within the module */
  sortOrder: int("sortOrder").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type QuizQuestion = typeof quizQuestions.$inferSelect;
export type InsertQuizQuestion = typeof quizQuestions.$inferInsert;

/**
 * Quiz Results — stores each user's quiz attempt per module
 */
export const quizResults = mysqlTable("quizResults", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  /** Module category */
  category: varchar("category", { length: 64 }).notNull(),
  /** Score: number of correct answers */
  score: int("score").notNull(),
  /** Total number of questions */
  totalQuestions: int("totalQuestions").notNull(),
  /** Percentage score (0-100) */
  percentage: int("percentage").notNull(),
  /** Whether the quiz was passed (>= 70%) */
  passed: int("passed").notNull().default(0),
  /** Time taken in seconds */
  timeTaken: int("timeTaken").notNull().default(0),
  /** JSON array of user answers (indices) */
  answers: text("answers"),
  completedAt: timestamp("completedAt").defaultNow().notNull(),
});

export type QuizResult = typeof quizResults.$inferSelect;
export type InsertQuizResult = typeof quizResults.$inferInsert;

/**
 * User badges — earned by completing module quizzes with ≥70% score.
 * Badge types: module (one per category) + master (all 6 modules completed).
 */
export const userBadges = mysqlTable("userBadges", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  /** Badge type: module_fondamentaux | module_vehicules | module_analyses | module_indices | module_histoire | module_options | master */
  badgeType: varchar("badgeType", { length: 64 }).notNull(),
  /** Module category (null for master badge) */
  category: varchar("category", { length: 64 }),
  /** Quiz score when badge was earned (percentage 0-100) */
  quizScore: int("quizScore"),
  /** Quiz result ID that triggered this badge */
  quizResultId: int("quizResultId"),
  earnedAt: timestamp("earnedAt").defaultNow().notNull(),
});

export type UserBadge = typeof userBadges.$inferSelect;
export type InsertUserBadge = typeof userBadges.$inferInsert;


/**
 * Thematic Watchlists — editorial watchlists with thesis, risks, catalysts
 * Each watchlist = one market theme (IA, Cyber, Defense, etc.)
 * 100% informatif — zéro conseil, zéro signal
 */
export const thematicWatchlists = mysqlTable("thematicWatchlists", {
  id: int("id").autoincrement().primaryKey(),
  /** URL slug: ia-semi, cybersecurite, defense, etc. */
  slug: varchar("slug", { length: 128 }).notNull().unique(),
  /** Display title in French */
  title: varchar("title", { length: 256 }).notNull(),
  /** Neutral thesis: why this theme exists (3-5 lines) */
  thesis: text("thesis").notNull(),
  /** Icon name from Lucide */
  icon: varchar("icon", { length: 64 }).notNull().default("TrendingUp"),
  /** Accent color hex */
  color: varchar("color", { length: 32 }).notNull().default("#344453"),
  /** JSON array of 5 items to watch next week */
  whatToWatch: text("whatToWatch"),
  /** JSON array of 5 general theme risks */
  themeRisks: text("themeRisks"),
  /** Number of items in this watchlist (denormalized for perf) */
  itemCount: int("itemCount").notNull().default(0),
  /** Sort order for display */
  sortOrder: int("sortOrder").notNull().default(0),
  /** Whether this watchlist is published */
  isActive: int("isActive").default(1).notNull(),
  /** Last content update date */
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ThematicWatchlist = typeof thematicWatchlists.$inferSelect;
export type InsertThematicWatchlist = typeof thematicWatchlists.$inferInsert;

/**
 * Watchlist Items — individual companies within a thematic watchlist
 * Each item has: ticker, why it matters, catalysts, risks, sources
 */
export const watchlistItems = mysqlTable("watchlistItems", {
  id: int("id").autoincrement().primaryKey(),
  /** Reference to parent watchlist */
  watchlistId: int("watchlistId").notNull(),
  /** Company name */
  name: varchar("name", { length: 256 }).notNull(),
  /** Ticker symbol (e.g. NVDA, CRWD) */
  ticker: varchar("ticker", { length: 32 }).notNull(),
  /** Sub-sector or sub-theme */
  sector: varchar("sector", { length: 128 }),
  /** Market cap range: Mega | Large | Mid | Small */
  marketCapRange: varchar("marketCapRange", { length: 32 }).notNull().default("Large"),
  /** 1-2 neutral lines: why this company matters in the theme */
  whyItMatters: text("whyItMatters"),
  /** JSON array of 3 catalysts */
  catalysts: text("catalysts"),
  /** JSON array of 3 risks */
  risks: text("risks"),
  /** JSON array of key dates [{label, date}] */
  keyDates: text("keyDates"),
  /** JSON array of sources [{label, date, url}] */
  sources: text("sources"),
  /** Sort order within the watchlist */
  sortOrder: int("sortOrder").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WatchlistItem = typeof watchlistItems.$inferSelect;
export type InsertWatchlistItem = typeof watchlistItems.$inferInsert;


/* ═══════════════════════════════════════════════════════════
 * ETF EXPLORER v3 — 500+ ETF Database
 * ═══════════════════════════════════════════════════════════ */
export const etfs = mysqlTable("etfs", {
  id: int("id").autoincrement().primaryKey(),
  ticker: varchar("ticker", { length: 16 }).notNull().unique(),
  name: varchar("name", { length: 256 }).notNull(),
  issuer: varchar("issuer", { length: 128 }).notNull(),
  /** Category: equity, bond, commodity, sector, thematic, international, crypto, alternative, currency, leveraged */
  category: varchar("category", { length: 64 }).notNull(),
  /** Sub-category for more granular filtering */
  subCategory: varchar("subCategory", { length: 128 }),
  /** AUM in billions USD (e.g. 450.5) */
  aumBillions: varchar("aumBillions", { length: 32 }),
  /** Expense ratio as percentage (e.g. "0.03") */
  expenseRatio: varchar("expenseRatio", { length: 16 }),
  /** Inception date */
  inceptionDate: varchar("inceptionDate", { length: 16 }),
  /** Index tracked */
  indexTracked: varchar("indexTracked", { length: 256 }),
  /** Number of holdings */
  holdings: varchar("holdings", { length: 16 }),
  /** Dividend yield as percentage */
  dividendYield: varchar("dividendYield", { length: 16 }),
  /** Distribution frequency: Monthly, Quarterly, Semi-Annual, Annual */
  distributionFreq: varchar("distributionFreq", { length: 32 }),
  /** Top 10 holdings as JSON array [{ticker, name, weight}] */
  topHoldings: text("topHoldings"),
  /** Sector breakdown as JSON array [{sector, weight}] */
  sectorBreakdown: text("sectorBreakdown"),
  /** Country breakdown as JSON array [{country, weight}] */
  countryBreakdown: text("countryBreakdown"),
  /** Short description (1-2 lines) */
  shortDesc: text("shortDesc"),
  /** Full description */
  fullDesc: text("fullDesc"),
  /** Risk level: 1-5 */
  riskLevel: int("riskLevel").notNull().default(3),
  /** Is leveraged or inverse */
  isLeveraged: int("isLeveraged").notNull().default(0),
  /** Is ESG/SRI */
  isESG: int("isESG").notNull().default(0),
  /** Tags as JSON array ["large-cap", "growth", "US"] */
  tags: text("tags"),
  /** Data source and date */
  dataSource: varchar("dataSource", { length: 256 }),
  dataDate: varchar("dataDate", { length: 32 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type ETF = typeof etfs.$inferSelect;
export type InsertETF = typeof etfs.$inferInsert;


/**
 * Glossary Quiz Questions — questions for the glossary quiz mode
 */
export const glossaryQuizQuestions = mysqlTable("glossaryQuizQuestions", {
  id: int("id").autoincrement().primaryKey(),
  termId: int("termId").notNull(),
  questionType: varchar("questionType", { length: 32 }).notNull(),
  question: text("question").notNull(),
  options: text("options").notNull(),
  correctAnswer: varchar("correctAnswer", { length: 512 }).notNull(),
  explanation: text("explanation"),
  difficulty: varchar("difficulty", { length: 32 }).notNull().default("debutant"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type GlossaryQuizQuestion = typeof glossaryQuizQuestions.$inferSelect;

/**
 * Glossary Paths — guided learning paths through glossary terms
 */
export const glossaryPaths = mysqlTable("glossaryPaths", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 128 }).notNull().unique(),
  title: varchar("title", { length: 256 }).notNull(),
  description: text("description").notNull(),
  icon: varchar("icon", { length: 64 }).notNull().default("BookOpen"),
  estimatedMinutes: int("estimatedMinutes").notNull().default(15),
  difficulty: varchar("difficulty", { length: 32 }).notNull().default("debutant"),
  termIds: text("termIds").notNull(),
  quizCount: int("quizCount").notNull().default(5),
  sortOrder: int("sortOrder").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type GlossaryPath = typeof glossaryPaths.$inferSelect;

/**
 * User Glossary Progress — tracks flashcard mastery per term
 */
export const userGlossaryProgress = mysqlTable("userGlossaryProgress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  termId: int("termId").notNull(),
  status: varchar("status", { length: 32 }).notNull().default("unseen"),
  reviewCount: int("reviewCount").notNull().default(0),
  lastReviewedAt: timestamp("lastReviewedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
});
export type UserGlossaryProgress = typeof userGlossaryProgress.$inferSelect;

/**
 * User Glossary Quiz Scores — tracks quiz results
 */
export const userGlossaryQuizScores = mysqlTable("userGlossaryQuizScores", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  quizType: varchar("quizType", { length: 32 }).notNull().default("general"),
  pathId: int("pathId"),
  totalQuestions: int("totalQuestions").notNull(),
  correctAnswers: int("correctAnswers").notNull(),
  score: int("score").notNull(),
  difficulty: varchar("difficulty", { length: 32 }).notNull().default("debutant"),
  completedAt: timestamp("completedAt").defaultNow().notNull(),
});
export type UserGlossaryQuizScore = typeof userGlossaryQuizScores.$inferSelect;


/**
 * Thème du Mois — Monthly magazine editions
 */
export const monthlyThemes = mysqlTable("monthlyThemes", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 128 }).notNull().unique(),
  title: varchar("title", { length: 256 }).notNull(),
  subtitle: varchar("subtitle", { length: 512 }),
  sector: varchar("sector", { length: 128 }).notNull(),
  tags: varchar("tags", { length: 512 }),
  coverImageUrl: varchar("coverImageUrl", { length: 1024 }),
  coverImageCaption: varchar("coverImageCaption", { length: 256 }),
  readingTime: int("readingTime").notNull().default(20),
  status: varchar("status", { length: 32 }).notNull().default("planned"),
  publishedAt: timestamp("publishedAt"),
  executiveSummary: text("executiveSummary"),
  context: text("context"),
  sectorMap: text("sectorMap"),
  drivers: text("drivers"),
  marketSize: text("marketSize"),
  businessModels: text("businessModels"),
  keyPlayers: text("keyPlayers"),
  etfExposure: text("etfExposure"),
  catalysts: text("catalysts"),
  risks: text("risks"),
  scenarios: text("scenarios"),
  glossary: text("glossary"),
  checklist: text("checklist"),
  conclusion: text("conclusion"),
  sources: text("sources"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
});
export type MonthlyTheme = typeof monthlyThemes.$inferSelect;


/**
 * User Favorites — allows users to save watchlists and individual companies
 * type: "watchlist" (saves a whole thematic watchlist) or "item" (saves a single company)
 * targetId: references thematicWatchlists.id or watchlistItems.id depending on type
 */
export const userFavorites = mysqlTable("userFavorites", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  /** Type of favorite: watchlist | item */
  type: varchar("type", { length: 32 }).notNull(),
  /** ID of the favorited entity (thematicWatchlists.id or watchlistItems.id) */
  targetId: int("targetId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserFavorite = typeof userFavorites.$inferSelect;
export type InsertUserFavorite = typeof userFavorites.$inferInsert;


/* ═══════════════════════════════════════════════════════════
 * GLOBAL QUIZ — Standalone quiz page with 30+ questions per theme
 * Themes: marches, indicateurs, glossaire, formation, etfs
 * ═══════════════════════════════════════════════════════════ */
export const globalQuizQuestions = mysqlTable("globalQuizQuestions", {
  id: int("id").autoincrement().primaryKey(),
  /** Theme: marches | indicateurs | glossaire | formation | etfs */
  theme: varchar("theme", { length: 64 }).notNull(),
  /** Question text */
  question: text("question").notNull(),
  /** JSON array of 4 answer options */
  options: text("options").notNull(),
  /** Index of the correct answer (0-3) */
  correctIndex: int("correctIndex").notNull(),
  /** Explanation shown after answering */
  explanation: text("explanation"),
  /** Difficulty: facile | moyen | difficile */
  difficulty: varchar("difficulty", { length: 32 }).notNull().default("moyen"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type GlobalQuizQuestion = typeof globalQuizQuestions.$inferSelect;
export type InsertGlobalQuizQuestion = typeof globalQuizQuestions.$inferInsert;

/**
 * Global Quiz Results — stores each user's quiz attempt
 */
export const globalQuizResults = mysqlTable("globalQuizResults", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  /** Theme played: marches | indicateurs | glossaire | formation | etfs | mixte */
  theme: varchar("theme", { length: 64 }).notNull(),
  /** Score (number of correct answers) */
  score: int("score").notNull(),
  /** Total number of questions */
  totalQuestions: int("totalQuestions").notNull(),
  /** Skill level earned: debutant | intermediaire | avance | expert */
  skillLevel: varchar("skillLevel", { length: 32 }).notNull(),
  /** Time taken in seconds */
  timeTaken: int("timeTaken"),
  completedAt: timestamp("completedAt").defaultNow().notNull(),
});
export type GlobalQuizResult = typeof globalQuizResults.$inferSelect;
export type InsertGlobalQuizResult = typeof globalQuizResults.$inferInsert;


/**
 * Blog posts table — SEO articles for organic traffic
 */
export const blogPosts = mysqlTable("blogPosts", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 256 }).notNull().unique(),
  title: varchar("title", { length: 512 }).notNull(),
  excerpt: text("excerpt"),
  content: text("content").notNull(),
  /** SEO meta description */
  metaDescription: varchar("metaDescription", { length: 320 }),
  /** Category: marche | education | analyse | strategie | actualite */
  category: varchar("category", { length: 64 }).notNull().default("education"),
  /** Tags comma-separated */
  tags: text("tags"),
  /** Cover image URL */
  coverUrl: text("coverUrl"),
  /** Reading time in minutes */
  readingTime: int("readingTime").default(5),
  /** Whether the post is published (1) or draft (0) */
  isPublished: int("isPublished").default(0).notNull(),
  /** Author name */
  author: varchar("author", { length: 128 }).default("WMB").notNull(),
  /** View count for analytics */
  viewCount: int("viewCount").default(0).notNull(),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = typeof blogPosts.$inferInsert;


/**
 * Newsletter subscribers — captures email leads from the homepage
 * These are people who signed up for the free newsletter but haven't created an account yet
 */
export const newsletterSubscribers = mysqlTable("newsletterSubscribers", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  name: varchar("name", { length: 256 }),
  /** Source: homepage | footer | popup | blog | social */
  source: varchar("source", { length: 64 }).default("homepage"),
  /** Whether the subscriber has been converted to a paid user */
  converted: int("converted").default(0).notNull(),
  /** Conversion status for CRM tracking: cold | warm | hot | converted */
  conversionStatus: varchar("conversionStatus", { length: 32 }).default("cold"),
  /** Whether the subscriber has unsubscribed */
  unsubscribed: int("unsubscribed").default(0).notNull(),
  /** Detected country code (ISO 3166-1 alpha-2, e.g. CH, FR, BE) */
  country: varchar("country", { length: 8 }),
  /** Onboarding email sequence step (0 = not started, 1-5 = steps sent) */
  onboardingStep: int("onboardingStep").default(0).notNull(),
  /** When the onboarding sequence started */
  onboardingStartedAt: timestamp("onboardingStartedAt"),
  /** Last onboarding email sent at */
  lastOnboardingEmailAt: timestamp("lastOnboardingEmailAt"),
  /** Number of complete onboarding loops (cycles of 7 emails completed) */
  onboardingLoopCount: int("onboardingLoopCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type NewsletterSubscriber = typeof newsletterSubscribers.$inferSelect;
export type InsertNewsletterSubscriber = typeof newsletterSubscribers.$inferInsert;


/* ═══════════════════════════════════════════════════════════
 * WMB CONTROL CENTER V1000 — CMS & Admin Tables
 * ═══════════════════════════════════════════════════════════ */

/**
 * Site Pages — CMS pages (home, about, FAQ, legal, etc.)
 * Each page can have multiple blocks (sections)
 */
export const sitePages = mysqlTable("sitePages", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 256 }).notNull(),
  slug: varchar("slug", { length: 256 }).notNull().unique(),
  /** Template type: landing | content | legal | custom */
  templateType: varchar("templateType", { length: 64 }).notNull().default("content"),
  /** Status: draft | published | archived */
  status: varchar("status", { length: 32 }).notNull().default("draft"),
  /** SEO fields */
  seoTitle: varchar("seoTitle", { length: 256 }),
  seoDescription: text("seoDescription"),
  seoCanonical: varchar("seoCanonical", { length: 512 }),
  ogTitle: varchar("ogTitle", { length: 256 }),
  ogDescription: text("ogDescription"),
  ogImage: varchar("ogImage", { length: 1024 }),
  /** Whether page should be indexed by search engines */
  noIndex: int("noIndex").default(0).notNull(),
  /** Hero configuration as JSON */
  heroConfig: text("heroConfig"),
  /** Order of blocks (JSON array of block IDs) */
  blocksOrder: text("blocksOrder"),
  publishedAt: timestamp("publishedAt"),
  createdBy: int("createdBy"),
  updatedBy: int("updatedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type SitePage = typeof sitePages.$inferSelect;
export type InsertSitePage = typeof sitePages.$inferInsert;

/**
 * Page Blocks — sections within a CMS page
 * Each block = one visual section (hero, CTA, features, FAQ, etc.)
 */
export const pageBlocks = mysqlTable("pageBlocks", {
  id: int("id").autoincrement().primaryKey(),
  pageId: int("pageId").notNull(),
  /** Block type: hero | text | features | cta | pricing | faq | testimonial | grid | newsletter | featured_content | academy | theme | briefings | tools | footer_cta | custom */
  blockType: varchar("blockType", { length: 64 }).notNull(),
  title: varchar("title", { length: 256 }),
  subtitle: varchar("subtitle", { length: 512 }),
  /** Main content (Markdown or HTML) */
  content: text("content"),
  /** CTA configuration as JSON {label, link, type, style} */
  ctaData: text("ctaData"),
  /** Media reference (image URL or media asset ID) */
  mediaRef: varchar("mediaRef", { length: 1024 }),
  /** Visibility: always | authenticated | premium | admin */
  visibility: varchar("visibility", { length: 32 }).notNull().default("always"),
  /** Sort order within the page */
  sortOrder: int("sortOrder").notNull().default(0),
  /** Whether this block is visible */
  isVisible: int("isVisible").default(1).notNull(),
  /** Additional settings as JSON */
  settings: text("settings"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type PageBlock = typeof pageBlocks.$inferSelect;
export type InsertPageBlock = typeof pageBlocks.$inferInsert;

/**
 * CTA Configs — reusable Call-to-Action configurations
 */
export const ctaConfigs = mysqlTable("ctaConfigs", {
  id: int("id").autoincrement().primaryKey(),
  /** Internal name for identification */
  name: varchar("name", { length: 128 }).notNull(),
  /** Button label text */
  label: varchar("label", { length: 256 }).notNull(),
  /** Destination URL or route */
  link: varchar("link", { length: 512 }).notNull(),
  /** CTA type: primary | secondary | outline | ghost */
  type: varchar("type", { length: 32 }).notNull().default("primary"),
  /** Visual style: default | hero | banner | inline */
  style: varchar("style", { length: 32 }).notNull().default("default"),
  /** Tracking tag for analytics */
  trackingTag: varchar("trackingTag", { length: 128 }),
  /** Target behavior: same_tab | new_tab | modal | scroll */
  targetBehavior: varchar("targetBehavior", { length: 32 }).notNull().default("same_tab"),
  /** Related funnel name */
  relatedFunnel: varchar("relatedFunnel", { length: 128 }),
  /** Whether this CTA is active */
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type CtaConfig = typeof ctaConfigs.$inferSelect;
export type InsertCtaConfig = typeof ctaConfigs.$inferInsert;

/**
 * Email Templates — editable email templates for all communications
 */
export const emailTemplates = mysqlTable("emailTemplates", {
  id: int("id").autoincrement().primaryKey(),
  /** Internal name: welcome | free_theme | onboarding_d1 | onboarding_d3 | premium_push | weekly_brief | custom */
  name: varchar("name", { length: 128 }).notNull(),
  /** Email subject line */
  subject: varchar("subject", { length: 512 }).notNull(),
  /** Preheader text (preview in inbox) */
  preheader: varchar("preheader", { length: 256 }),
  /** Email body in HTML */
  body: text("body").notNull(),
  /** CTA config as JSON {label, link, style} */
  ctaConfig: text("ctaConfig"),
  /** Email type: transactional | marketing | onboarding | notification */
  emailType: varchar("emailType", { length: 64 }).notNull().default("marketing"),
  /** Status: draft | active | archived */
  status: varchar("status", { length: 32 }).notNull().default("draft"),
  /** Preview text for admin display */
  previewText: text("previewText"),
  /** Version number for tracking changes */
  version: int("version").notNull().default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type EmailTemplate = typeof emailTemplates.$inferSelect;
export type InsertEmailTemplate = typeof emailTemplates.$inferInsert;

/**
 * Email Sequences — automated email sequences triggered by events
 */
export const emailSequences = mysqlTable("emailSequences", {
  id: int("id").autoincrement().primaryKey(),
  /** Sequence name */
  name: varchar("name", { length: 256 }).notNull(),
  /** Description */
  description: text("description"),
  /** Trigger: form_submit | tag_added | registration | purchase | manual */
  triggerType: varchar("triggerType", { length: 64 }).notNull(),
  /** Trigger value (form ID, tag name, etc.) */
  triggerValue: varchar("triggerValue", { length: 256 }),
  /** Status: draft | active | paused | archived */
  status: varchar("status", { length: 32 }).notNull().default("draft"),
  /** Stop rules as JSON (e.g. stop if premium conversion) */
  stopRules: text("stopRules"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type EmailSequence = typeof emailSequences.$inferSelect;
export type InsertEmailSequence = typeof emailSequences.$inferInsert;

/**
 * Email Sequence Steps — individual steps within a sequence
 */
export const emailSequenceSteps = mysqlTable("emailSequenceSteps", {
  id: int("id").autoincrement().primaryKey(),
  sequenceId: int("sequenceId").notNull(),
  /** Step order */
  sortOrder: int("sortOrder").notNull().default(0),
  /** Delay in hours from previous step (or from trigger for first step) */
  delayHours: int("delayHours").notNull().default(0),
  /** Email template ID to send */
  emailTemplateId: int("emailTemplateId"),
  /** Action type: send_email | add_tag | remove_tag | wait | condition */
  actionType: varchar("actionType", { length: 64 }).notNull().default("send_email"),
  /** Action data as JSON */
  actionData: text("actionData"),
  /** Whether this step is active */
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type EmailSequenceStep = typeof emailSequenceSteps.$inferSelect;
export type InsertEmailSequenceStep = typeof emailSequenceSteps.$inferInsert;

/**
 * Leads — enhanced lead tracking with full funnel attribution
 */
export const leads = mysqlTable("leads", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull(),
  name: varchar("name", { length: 256 }),
  /** Source form ID */
  sourceFormId: int("sourceFormId"),
  /** Source page slug */
  sourcePage: varchar("sourcePage", { length: 256 }),
  /** Source CTA name */
  sourceCta: varchar("sourceCta", { length: 128 }),
  /** Tags as JSON array */
  tags: text("tags"),
  /** Opt-in status: pending | confirmed | unsubscribed */
  optInStatus: varchar("optInStatus", { length: 32 }).notNull().default("confirmed"),
  /** Lead magnet requested */
  leadMagnetRequested: varchar("leadMagnetRequested", { length: 256 }),
  /** Current email sequence ID */
  currentSequenceId: int("currentSequenceId"),
  /** Current step in the sequence */
  currentSequenceStep: int("currentSequenceStep").default(0),
  /** Lifecycle stage: subscriber | lead | qualified | customer */
  lifecycleStage: varchar("lifecycleStage", { length: 32 }).notNull().default("subscriber"),
  /** Last email sent date */
  lastEmailSent: timestamp("lastEmailSent"),
  /** Internal notes */
  notes: text("notes"),
  /** Whether this lead has been converted to a user */
  convertedToUserId: int("convertedToUserId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Lead = typeof leads.$inferSelect;
export type InsertLead = typeof leads.$inferInsert;

/**
 * Form Configs — configurable forms for lead capture
 */
export const formConfigs = mysqlTable("formConfigs", {
  id: int("id").autoincrement().primaryKey(),
  /** Form name */
  name: varchar("name", { length: 128 }).notNull(),
  /** Where the form is displayed */
  location: varchar("location", { length: 128 }),
  /** Fields configuration as JSON array [{name, type, required, placeholder}] */
  fields: text("fields").notNull(),
  /** Success message */
  successMessage: text("successMessage"),
  /** Error message */
  errorMessage: text("errorMessage"),
  /** Redirect URL after submission */
  redirectUrl: varchar("redirectUrl", { length: 512 }),
  /** Related lead magnet */
  relatedLeadMagnet: varchar("relatedLeadMagnet", { length: 256 }),
  /** Related email template ID */
  relatedEmailTemplateId: int("relatedEmailTemplateId"),
  /** Related email sequence ID */
  relatedSequenceId: int("relatedSequenceId"),
  /** Tags to apply to leads as JSON array */
  tagsToApply: text("tagsToApply"),
  /** Whether this form is active */
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type FormConfig = typeof formConfigs.$inferSelect;
export type InsertFormConfig = typeof formConfigs.$inferInsert;

/**
 * Navigation Items — header and footer menu items
 */
export const navigationItems = mysqlTable("navigationItems", {
  id: int("id").autoincrement().primaryKey(),
  /** Display label */
  label: varchar("label", { length: 128 }).notNull(),
  /** URL or route path */
  url: varchar("url", { length: 512 }).notNull(),
  /** Parent item ID for sub-menus (null = top-level) */
  parentId: int("parentId"),
  /** Sort order */
  sortOrder: int("sortOrder").notNull().default(0),
  /** Visibility: always | authenticated | premium | admin */
  visibility: varchar("visibility", { length: 32 }).notNull().default("always"),
  /** Menu type: header | footer_col1 | footer_col2 | footer_col3 | footer_legal */
  menuType: varchar("menuType", { length: 64 }).notNull().default("header"),
  /** Whether this item is active */
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type NavigationItem = typeof navigationItems.$inferSelect;
export type InsertNavigationItem = typeof navigationItems.$inferInsert;

/**
 * Site Settings — key-value global settings
 */
export const siteSettings = mysqlTable("siteSettings", {
  id: int("id").autoincrement().primaryKey(),
  /** Setting key: site_name | baseline | contact_email | logo_url | favicon_url | cta_global | lead_magnet_default | banner_text | popup_config | social_links | newsletter_options */
  key: varchar("settingKey", { length: 128 }).notNull().unique(),
  /** Setting value (can be JSON for complex values) */
  value: text("value"),
  /** Group: general | branding | acquisition | social | newsletter | popup | banner | advanced */
  settingGroup: varchar("settingGroup", { length: 64 }).notNull().default("general"),
  /** Whether this setting can be edited from admin */
  isEditable: int("isEditable").default(1).notNull(),
  /** Whether this setting contains sensitive data */
  isProtected: int("isProtected").default(0).notNull(),
  /** Description for admin UI */
  description: varchar("description", { length: 512 }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type SiteSetting = typeof siteSettings.$inferSelect;
export type InsertSiteSetting = typeof siteSettings.$inferInsert;

/**
 * Media Assets — media library for images, PDFs, documents
 */
export const mediaAssets = mysqlTable("mediaAssets", {
  id: int("id").autoincrement().primaryKey(),
  /** Original file name */
  fileName: varchar("fileName", { length: 512 }).notNull(),
  /** MIME type: image/png | image/jpeg | application/pdf | etc. */
  mimeType: varchar("mimeType", { length: 128 }).notNull(),
  /** Alt text for accessibility */
  altText: varchar("altText", { length: 512 }),
  /** Public URL (S3) */
  url: text("url").notNull(),
  /** S3 file key */
  fileKey: varchar("fileKey", { length: 512 }).notNull(),
  /** Folder/category for organization */
  folder: varchar("folder", { length: 128 }).default("general"),
  /** Tags as JSON array */
  tags: text("tags"),
  /** File size in bytes */
  fileSize: int("fileSize"),
  /** Width in pixels (for images) */
  width: int("width"),
  /** Height in pixels (for images) */
  height: int("height"),
  /** Who uploaded this asset */
  uploadedBy: int("uploadedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type MediaAsset = typeof mediaAssets.$inferSelect;
export type InsertMediaAsset = typeof mediaAssets.$inferInsert;

/**
 * Redirect Rules — URL redirects for SEO
 */
export const redirectRules = mysqlTable("redirectRules", {
  id: int("id").autoincrement().primaryKey(),
  /** Source path (e.g. /old-page) */
  fromPath: varchar("fromPath", { length: 512 }).notNull(),
  /** Destination path or URL */
  toPath: varchar("toPath", { length: 512 }).notNull(),
  /** Redirect type: 301 | 302 */
  redirectType: int("redirectType").notNull().default(301),
  /** Whether this redirect is active */
  isActive: int("isActive").default(1).notNull(),
  /** Hit count for analytics */
  hitCount: int("hitCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type RedirectRule = typeof redirectRules.$inferSelect;
export type InsertRedirectRule = typeof redirectRules.$inferInsert;

/**
 * Audit Logs — admin activity tracking for security
 */
export const auditLogs = mysqlTable("auditLogs", {
  id: int("id").autoincrement().primaryKey(),
  /** Admin user ID who performed the action */
  actorId: int("actorId").notNull(),
  /** Actor name (denormalized for display) */
  actorName: varchar("actorName", { length: 256 }),
  /** Action: create | update | delete | publish | archive | login | settings_change | email_send */
  action: varchar("action", { length: 64 }).notNull(),
  /** Target entity type: page | block | cta | email | lead | form | navigation | setting | media | redirect | user | edition | theme | course | quiz | glossary | blog */
  targetType: varchar("targetType", { length: 64 }).notNull(),
  /** Target entity ID */
  targetId: int("targetId"),
  /** Target entity name (for display) */
  targetName: varchar("targetName", { length: 256 }),
  /** State before change as JSON */
  beforeState: text("beforeState"),
  /** State after change as JSON */
  afterState: text("afterState"),
  /** IP address */
  ipAddress: varchar("ipAddress", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

/**
 * Pricing Plans — configurable pricing plans for the pricing page
 */
export const pricingPlans = mysqlTable("pricingPlans", {
  id: int("id").autoincrement().primaryKey(),
  /** Plan name */
  name: varchar("name", { length: 128 }).notNull(),
  /** Price in CHF (e.g. "9.90") */
  price: varchar("price", { length: 32 }).notNull(),
  /** Frequency: monthly | annual | one_time | free */
  frequency: varchar("frequency", { length: 32 }).notNull().default("monthly"),
  /** Features as JSON array of strings */
  features: text("features"),
  /** CTA label */
  ctaLabel: varchar("ctaLabel", { length: 128 }),
  /** CTA link */
  ctaLink: varchar("ctaLink", { length: 512 }),
  /** Whether this plan is featured/recommended */
  isFeatured: int("isFeatured").default(0).notNull(),
  /** Whether this plan is visible on the pricing page */
  isVisible: int("isVisible").default(1).notNull(),
  /** Sort order */
  sortOrder: int("sortOrder").notNull().default(0),
  /** Badge text (e.g. "Populaire", "Meilleur rapport") */
  badgeText: varchar("badgeText", { length: 64 }),
  /** Stripe Price ID */
  stripePriceId: varchar("stripePriceId", { length: 128 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type PricingPlan = typeof pricingPlans.$inferSelect;
export type InsertPricingPlan = typeof pricingPlans.$inferInsert;

/* ═══════════════════════════════════════════════════════════
 * Theme Access Tokens — Allow email-only users to read the latest theme
 * without creating an account. Token is sent via email after signup.
 * ═══════════════════════════════════════════════════════════ */
export const themeAccessTokens = mysqlTable("themeAccessTokens", {
  id: int("id").autoincrement().primaryKey(),
  /** The email that requested access */
  email: varchar("email", { length: 320 }).notNull(),
  /** The theme slug this token grants access to */
  themeSlug: varchar("themeSlug", { length: 128 }).notNull(),
  /** The unique access token (SHA-256 hash, 32 chars) */
  token: varchar("token", { length: 64 }).notNull().unique(),
  /** Number of times the token has been used */
  usageCount: int("usageCount").default(0).notNull(),
  /** Token expiry — 90 days from creation */
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type ThemeAccessToken = typeof themeAccessTokens.$inferSelect;
export type InsertThemeAccessToken = typeof themeAccessTokens.$inferInsert;


/**
 * User sessions — tracks active login sessions for session management
 * Allows users to view and revoke active sessions from other devices
 */
export const userSessions = mysqlTable("userSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  /** Unique session identifier (stored in JWT claims) */
  sessionId: varchar("sessionId", { length: 128 }).notNull().unique(),
  /** User agent string from the login request */
  userAgent: text("userAgent"),
  /** IP address at login time */
  ipAddress: varchar("ipAddress", { length: 64 }),
  /** Device/browser description (parsed from UA) */
  deviceInfo: varchar("deviceInfo", { length: 256 }),
  /** Whether this session is still active */
  isActive: int("isActive").default(1).notNull(),
  /** Whether 2FA was verified for this session */
  totpVerified: int("totpVerified").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  lastActiveAt: timestamp("lastActiveAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt"),
});

export type UserSession = typeof userSessions.$inferSelect;
export type InsertUserSession = typeof userSessions.$inferInsert;

/**
 * Security events log — structured audit trail for security-relevant events
 */
export const securityEvents = mysqlTable("securityEvents", {
  id: int("id").autoincrement().primaryKey(),
  /** Event type (LOGIN_SUCCESS, LOGIN_FAILED, ACCOUNT_LOCKED, etc.) */
  eventType: varchar("eventType", { length: 64 }).notNull(),
  /** Severity level */
  severity: mysqlEnum("severity", ["LOW", "MEDIUM", "HIGH", "CRITICAL"]).notNull(),
  /** User ID if applicable */
  userId: int("userId"),
  /** Email if applicable */
  email: varchar("email", { length: 320 }),
  /** IP address */
  ipAddress: varchar("ipAddress", { length: 64 }),
  /** User agent */
  userAgent: text("userAgent"),
  /** Additional details as JSON */
  details: text("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SecurityEvent = typeof securityEvents.$inferSelect;
export type InsertSecurityEvent = typeof securityEvents.$inferInsert;

/**
 * Referrals — tracks referral relationships between users.
 * Each row = one successful referral (referee signed up via referrer's link).
 */
export const referrals = mysqlTable("referrals", {
  id: int("id").autoincrement().primaryKey(),
  /** User ID of the referrer (who shared the link) */
  referrerId: int("referrerId").notNull(),
  /** User ID of the referee (who signed up via the link) */
  refereeId: int("refereeId").notNull(),
  /** Referral code used */
  referralCode: varchar("referralCode", { length: 32 }).notNull(),
  /** Status: pending | completed | rewarded */
  status: varchar("status", { length: 32 }).default("pending").notNull(),
  /** Whether the referrer has been rewarded */
  referrerRewarded: int("referrerRewarded").default(0).notNull(),
  /** Whether the referee has been rewarded */
  refereeRewarded: int("refereeRewarded").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = typeof referrals.$inferInsert;


/**
 * Daily Briefings — Stores each daily market briefing sent by admin
 * Used to:
 * 1. Auto-send the latest briefing to new subscribers
 * 2. Keep an archive of all daily briefings sent
 */
export const dailyBriefings = mysqlTable("dailyBriefings", {
  id: int("id").autoincrement().primaryKey(),
  /** Subject line of the briefing email */
  subject: varchar("subject", { length: 512 }).notNull(),
  /** HTML content of the briefing email */
  htmlContent: text("htmlContent").notNull(),
  /** Plain text preview (first ~200 chars) */
  previewText: varchar("previewText", { length: 512 }),
  /** Date the briefing covers (e.g. "2026-04-01") */
  briefingDate: varchar("briefingDate", { length: 16 }).notNull(),
  /** Number of recipients it was sent to */
  recipientCount: int("recipientCount").default(0).notNull(),
  /** Admin user ID who sent it */
  sentBy: int("sentBy"),
  /** Status: draft | sent */
  status: varchar("status", { length: 32 }).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  sentAt: timestamp("sentAt"),
  /** Full JSON data from Claude for the web reader (fullAnalysis + emailDigest) */
  jsonData: text("jsonData"),
});
export type DailyBriefing = typeof dailyBriefings.$inferSelect;
export type InsertDailyBriefing = typeof dailyBriefings.$inferInsert;
/**
 * Automation Logs — Tracks every automated job execution
 * Used by the admin dashboard "Pilote Automatique" view
 */
export const automationLogs = mysqlTable("automationLogs", {
  id: int("id").autoincrement().primaryKey(),
  /** Type: onboarding | reengagement | expiration_reminder | reactivation | anniversary | weekly_report | newsletter */
  automationType: varchar("automationType", { length: 64 }).notNull(),
  /** Status: success | partial | failed */
  status: varchar("status", { length: 32 }).notNull().default("success"),
  /** JSON details (recipients, errors, etc.) */
  details: text("details"),
  /** Number of recipients processed */
  recipientCount: int("recipientCount").default(0).notNull(),
  /** Number of errors */
  errorCount: int("errorCount").default(0).notNull(),
  /** Duration in milliseconds */
  durationMs: int("durationMs").default(0),
  executedAt: timestamp("executedAt").defaultNow().notNull(),
});
export type AutomationLog = typeof automationLogs.$inferSelect;
export type InsertAutomationLog = typeof automationLogs.$inferInsert;

/**
 * Promo Codes — Manages Stripe promotion codes
 * Types: welcome (new user -20%), return (ex-subscriber -20%), referral (filleul -10%), custom
 */
export const promoCodes = mysqlTable("promoCodes", {
  id: int("id").autoincrement().primaryKey(),
  /** Human-readable code (e.g. BIENVENUE20) */
  code: varchar("code", { length: 64 }).notNull(),
  /** Stripe coupon ID */
  stripeCouponId: varchar("stripeCouponId", { length: 128 }),
  /** Stripe promotion code ID */
  stripePromotionCodeId: varchar("stripePromotionCodeId", { length: 128 }),
  /** Type: welcome | return | referral | custom */
  type: varchar("type", { length: 32 }).notNull(),
  /** Discount percentage (e.g. 20 for 20%) */
  discountPercent: int("discountPercent").notNull().default(20),
  /** Max number of uses (null = unlimited) */
  maxUses: int("maxUses"),
  /** Number of times used */
  usedCount: int("usedCount").default(0).notNull(),
  /** Expiry date (null = no expiry) */
  expiresAt: timestamp("expiresAt"),
  /** Whether the promo is active */
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type PromoCode = typeof promoCodes.$inferSelect;
export type InsertPromoCode = typeof promoCodes.$inferInsert;


/* ═══════════════════════════════════════════════════════════
 * EDITION MODULES — Dynamic weekly module storage
 * Replaces hardcoded edition files (week8.ts, mondeWeek8.ts, etc.)
 * Each row = one module for one week (usa, monde, suisse, actions, filrouge)
 * ═══════════════════════════════════════════════════════════ */
export const editionModules = mysqlTable("editionModules", {
  id: int("id").autoincrement().primaryKey(),
  /** Week number (8, 9, 10, ...) */
  weekNumber: int("weekNumber").notNull(),
  /** Year (2026, 2027, ...) */
  year: int("year").notNull(),
  /** Module type: usa | monde | suisse | actions | filrouge */
  moduleType: varchar("moduleType", { length: 32 }).notNull(),
  /** Date range display string, e.g. "LUN 24/03 → VEN 28/03" */
  dateRange: varchar("dateRange", { length: 128 }).notNull(),
  /** Module title */
  title: varchar("title", { length: 512 }).notNull(),
  /** Module subtitle */
  subtitle: varchar("subtitle", { length: 512 }),
  /** Full module data as JSON (matches BriefData, MondeModuleData, etc.) */
  data: text("data").notNull(),
  /** Catalog-level metadata: slide count */
  slideCount: int("slideCount").notNull().default(25),
  /** Catalog-level metadata: tags as JSON array */
  tags: text("tags"),
  /** PDF URL for download */
  pdfUrl: text("pdfUrl"),
  /** Cover image URL */
  coverUrl: text("coverUrl"),
  /** Raw input text pasted by admin (for re-conversion) */
  rawInput: text("rawInput"),
  /** Batch ID for grouped Sunday publication */
  batchId: varchar("batchId", { length: 64 }),
  /** Scheduled publication date (null = manual publish) */
  scheduledAt: timestamp("scheduledAt"),
  /** Status: draft | scheduled | published */
  status: varchar("moduleStatus", { length: 32 }).default("draft").notNull(),
  /** Whether this module is published and visible */
  isPublished: int("isPublished").default(0).notNull(),
  /** Publication date */
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type EditionModule = typeof editionModules.$inferSelect;
export type InsertEditionModule = typeof editionModules.$inferInsert;

/**
 * Module Notes — personal notes taken by users on newsletter modules, themes, briefings
 * Linked to a specific content item by contentType + contentId
 */
export const moduleNotes = mysqlTable("moduleNotes", {
  id: int("id").autoincrement().primaryKey(),
  /** User who wrote the note */
  userId: int("userId").notNull(),
  /** Content type: module | theme | briefing */
  contentType: varchar("contentType", { length: 32 }).notNull(),
  /** ID of the content item (editionModules.id, monthlyThemes.id, dailyBriefings.id) */
  contentId: int("contentId").notNull(),
  /** Note title (optional) */
  title: varchar("title", { length: 256 }),
  /** Note content (markdown or plain text) */
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type ModuleNote = typeof moduleNotes.$inferSelect;
export type InsertModuleNote = typeof moduleNotes.$inferInsert;

/**
 * Admin KPI Objectives — customizable goals for the admin dashboard
 */
export const adminObjectives = mysqlTable("adminObjectives", {
  id: int("id").autoincrement().primaryKey(),
  /** Objective key: subscribers_free, subscribers_paid, mrr, conversion_rate, etc. */
  key: varchar("key", { length: 64 }).notNull().unique(),
  /** Display label */
  label: varchar("label", { length: 256 }).notNull(),
  /** Target value */
  targetValue: int("targetValue").notNull(),
  /** Current value (updated periodically) */
  currentValue: int("currentValue").default(0).notNull(),
  /** Unit: count, chf, percent */
  unit: varchar("unit", { length: 32 }).default("count").notNull(),
  /** Icon name (lucide) */
  icon: varchar("icon", { length: 64 }),
  /** Sort order */
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type AdminObjective = typeof adminObjectives.$inferSelect;
export type InsertAdminObjective = typeof adminObjectives.$inferInsert;


/* ═══════════════════════════════════════════════════════════════
 * ADMIN COCKPIT TABLES — Added 29/04/2026
 * These tables power the admin dashboard refonte.
 * NEVER modify existing tables above this line.
 * ═══════════════════════════════════════════════════════════════ */

/** 
 * Daily metrics snapshot — MRR, ARR, churn, NRR computed by cron job.
 * One row per day. Upsert on date.
 */
export const metricsDailyTable = mysqlTable("metrics_daily", {
  id: int("id").autoincrement().primaryKey(),
  date: varchar("date", { length: 10 }).notNull(), // 'YYYY-MM-DD'
  mrr: decimal("mrr", { precision: 10, scale: 2 }).notNull().default("0"),
  arr: decimal("arr", { precision: 10, scale: 2 }).notNull().default("0"),
  totalPaying: int("totalPaying").notNull().default(0),
  totalFree: int("totalFree").notNull().default(0),
  totalContacts: int("totalContacts").notNull().default(0),
  newSubscribers: int("newSubscribers").notNull().default(0),
  churned: int("churned").notNull().default(0),
  nrr: decimal("nrr", { precision: 6, scale: 2 }).default("100"),
  grr: decimal("grr", { precision: 6, scale: 2 }).default("100"),
  arpu: decimal("arpu", { precision: 10, scale: 2 }).default("0"),
  churnRate: decimal("churnRate", { precision: 6, scale: 2 }).default("0"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (t) => ({
  idxDate: index("idx_metrics_daily_date").on(t.date),
}));
export type MetricsDaily = typeof metricsDailyTable.$inferSelect;

/**
 * Admin alerts — health alerts for Stripe, Brevo, system anomalies.
 * Displayed as sticky banner on dashboard when unresolved.
 */
export const adminAlertsTable = mysqlTable("admin_alerts", {
  id: int("id").autoincrement().primaryKey(),
  level: varchar("level", { length: 16 }).notNull(), // 'info' | 'warning' | 'danger' | 'critical'
  category: varchar("category", { length: 32 }).notNull(), // 'stripe' | 'brevo' | 'tidb' | 's3' | 'finnhub' | 'business'
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  ctaLabel: varchar("ctaLabel", { length: 64 }),
  ctaUrl: varchar("ctaUrl", { length: 255 }),
  resolved: int("resolved").default(0).notNull(),
  resolvedAt: timestamp("resolvedAt"),
  resolvedBy: int("resolvedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type AdminAlert = typeof adminAlertsTable.$inferSelect;

/**
 * User events — unified timeline of all user actions across sources.
 * Powers the CRM 360° timeline and analytics.
 */
export const userEventsTable = mysqlTable("user_events", {
  id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
  userId: int("userId"),
  email: varchar("email", { length: 255 }),
  eventType: varchar("eventType", { length: 64 }).notNull(),
  // 'signup', 'login', 'email_opened', 'email_clicked', 'lead_captured',
  // 'subscription_created', 'invoice_paid', 'invoice_failed',
  // 'subscription_canceled', 'page_view', 'note_added'
  source: varchar("source", { length: 32 }), // 'stripe' | 'brevo' | 'app' | 'manual'
  properties: json("properties"),
  occurredAt: timestamp("occurredAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (t) => ({
  idxUser: index("idx_user_events_user").on(t.userId, t.occurredAt),
  idxEmail: index("idx_user_events_email").on(t.email),
}));
export type UserEvent = typeof userEventsTable.$inferSelect;

/**
 * Lead scoring — computed score 0-100 + churn risk for each user.
 * Recalculated every 4 hours by cron job.
 */
export const leadScoresTable = mysqlTable("lead_scores", {
  userId: int("userId").primaryKey(),
  score: tinyint("score").notNull().default(0), // 0-100
  churnRiskScore: tinyint("churnRiskScore").notNull().default(0),
  ltvEstimateChf: decimal("ltvEstimateChf", { precision: 10, scale: 2 }),
  factors: json("factors"), // { engagement: 35, source_quality: 20, recency: 15, ... }
  lastComputed: timestamp("lastComputed").defaultNow().notNull(),
});
export type LeadScore = typeof leadScoresTable.$inferSelect;

/**
 * Email events — Brevo webhook events (delivered, opened, clicked, bounced, etc.)
 */
export const emailEventsTable = mysqlTable("email_events", {
  id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
  messageId: varchar("messageId", { length: 128 }),
  campaignId: int("campaignId"),
  email: varchar("email", { length: 255 }).notNull(),
  eventType: varchar("eventType", { length: 32 }).notNull(),
  // delivered, opened, clicked, hardBounce, softBounce, unsubscribed, spam, blocked, deferred
  link: text("link"),
  ip: varchar("ip", { length: 64 }),
  userAgent: text("userAgent"),
  occurredAt: timestamp("occurredAt").notNull(),
  raw: json("raw"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type EmailEvent = typeof emailEventsTable.$inferSelect;

/**
 * Stripe events — audit trail for all Stripe webhook events.
 * Idempotent: stripe event ID is primary key.
 */
export const stripeEventsTable = mysqlTable("stripe_events", {
  id: varchar("id", { length: 64 }).primaryKey(), // Stripe event ID
  type: varchar("type", { length: 64 }).notNull(),
  apiVersion: varchar("apiVersion", { length: 16 }),
  payload: json("payload").notNull(),
  processed: int("processed").default(0).notNull(),
  processingError: text("processingError"),
  eventCreatedAt: timestamp("eventCreatedAt").notNull(),
  receivedAt: timestamp("receivedAt").defaultNow().notNull(),
});
export type StripeEvent = typeof stripeEventsTable.$inferSelect;

/**
 * Admin notifications — in-app notification center (bell icon).
 */
export const adminNotificationsTable = mysqlTable("admin_notifications", {
  id: int("id").autoincrement().primaryKey(),
  adminId: int("adminId").notNull(),
  type: varchar("type", { length: 32 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  body: text("body"),
  url: varchar("url", { length: 255 }),
  isRead: int("isRead").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type AdminNotification = typeof adminNotificationsTable.$inferSelect;

/**
 * Feature flags — enable/disable modules progressively.
 */
export const featureFlagsTable = mysqlTable("feature_flags", {
  key: varchar("key", { length: 64 }).primaryKey(),
  enabled: int("enabled").default(0).notNull(),
  rollout: tinyint("rollout").default(0),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type FeatureFlag = typeof featureFlagsTable.$inferSelect;

/**
 * Admin preferences — theme, density, notification settings.
 */
export const adminPreferencesTable = mysqlTable("admin_preferences", {
  adminId: int("adminId").primaryKey(),
  theme: varchar("theme", { length: 8 }).default("light"),
  density: varchar("density", { length: 16 }).default("comfortable"),
  defaultView: varchar("defaultView", { length: 32 }).default("dashboard"),
  notifEmail: int("notifEmail").default(1).notNull(),
  notifInapp: int("notifInapp").default(1).notNull(),
  prefs: json("prefs"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type AdminPreference = typeof adminPreferencesTable.$inferSelect;

/**
 * API cache — external API responses cached with TTL.
 * Used for Stripe, Brevo, Finnhub to avoid rate limits.
 */
export const apiCacheTable = mysqlTable("api_cache", {
  cacheKey: varchar("cacheKey", { length: 255 }).primaryKey(),
  payload: json("payload").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type ApiCache = typeof apiCacheTable.$inferSelect;

/**
 * Saved views — CRM saved filters/views for admin.
 */
export const savedViewsTable = mysqlTable("saved_views", {
  id: int("id").autoincrement().primaryKey(),
  adminId: int("adminId").notNull(),
  name: varchar("name", { length: 128 }).notNull(),
  entity: varchar("entity", { length: 32 }).notNull(), // 'clients' | 'campaigns' | 'modules'
  filters: json("filters").notNull(),
  isDefault: int("isDefault").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type SavedView = typeof savedViewsTable.$inferSelect;


/**
 * Admin Boîte à Idées — store content ideas for articles, ads, newsletters, etc.
 */
export const ideas = mysqlTable("ideas", {
  id: int("id").autoincrement().primaryKey(),
  /** Title of the idea */
  title: varchar("title", { length: 255 }).notNull(),
  /** Category: article, pub, newsletter, theme_du_mois, video, formation, quiz, autre */
  category: varchar("category", { length: 64 }).notNull(),
  /** Priority: haute, moyenne, basse */
  priority: varchar("priority", { length: 32 }).default("moyenne").notNull(),
  /** Status: idee, en_cours, planifie, publie, archive */
  status: varchar("status", { length: 32 }).default("idee").notNull(),
  /** Detailed description / notes */
  description: text("description"),
  /** Target date for publication */
  targetDate: timestamp("targetDate"),
  /** Tags (comma-separated) */
  tags: text("tags"),
  /** External links / references */
  links: text("links"),
  /** Admin who created the idea */
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
});
export type Idea = typeof ideas.$inferSelect;
export type NewIdea = typeof ideas.$inferInsert;

/**
 * Email Log — tracks every single email sent to any contact
 * Used for CRM timeline and delivery tracking
 */
export const emailLog = mysqlTable("emailLog", {
  id: int("id").autoincrement().primaryKey(),
  /** Email address of the recipient */
  recipientEmail: varchar("recipientEmail", { length: 320 }).notNull(),
  /** Type of contact: user | subscriber */
  contactType: varchar("contactType", { length: 32 }).notNull(),
  /** Contact ID (userId or subscriberId) */
  contactId: int("contactId").notNull(),
  /** Email category: onboarding | newsletter | briefing | campaign | welcome | theme */
  emailCategory: varchar("emailCategory", { length: 64 }).notNull(),
  /** Specific step or label (e.g. "onboarding_1", "edition_S22", "briefing_2026-06-02") */
  emailLabel: varchar("emailLabel", { length: 128 }),
  /** Subject line of the email */
  subject: varchar("subject", { length: 512 }),
  /** Delivery status: sent | failed | bounced */
  status: varchar("status", { length: 32 }).default("sent").notNull(),
  /** Error message if failed */
  errorMessage: text("errorMessage"),
  sentAt: timestamp("sentAt").defaultNow().notNull(),
});

export type EmailLog = typeof emailLog.$inferSelect;
export type InsertEmailLog = typeof emailLog.$inferInsert;

/**
 * Contact Notes — admin notes on contacts for CRM tracking
 */
export const contactNotes = mysqlTable("contactNotes", {
  id: int("id").autoincrement().primaryKey(),
  /** Type of contact: user | subscriber */
  contactType: varchar("contactType", { length: 32 }).notNull(),
  /** Contact ID (userId or subscriberId) */
  contactId: int("contactId").notNull(),
  /** The note content */
  note: text("note").notNull(),
  /** Admin who wrote the note */
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ContactNote = typeof contactNotes.$inferSelect;
export type InsertContactNote = typeof contactNotes.$inferInsert;
