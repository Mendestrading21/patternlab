/**
 * DashboardGlossaire — Glossaire interactif dans Mon espace
 * Réutilise les composants exportés depuis Glossaire.tsx
 * Modes: Fiches | Flashcards | Quiz | Parcours | Progression
 * Format: Hero sombre + breadcrumb + stats + modes intégrés
 */
import { usePageTitle } from "@/hooks/usePageTitle";
import Layout from "@/components/Layout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useSubscription } from "@/hooks/useSubscription";
import PremiumGate from "@/components/PremiumGate";
import PageBreadcrumb from "@/components/PageBreadcrumb";
import GlossaryWordOfDay from "@/components/GlossaryWordOfDay";
import { useState } from "react";
import { motion } from "framer-motion";
import { Crown, Lock as LockIcon } from "lucide-react";
import {
  BookOpen, Brain, Target, Route, Trophy,
  Search, Sparkles, ArrowRight, GraduationCap,
} from "lucide-react";
import { GLOSSARY } from "@shared/siteConfig";
import {
  type GlossaryTabMode,
  CATEGORY_LABELS,
  CATEGORY_ICONS,
  CATEGORY_COLORS,
  TAB_CONFIG,
  FichesMode,
  FlashcardsMode,
  QuizMode,
  ParcoursMode,
  ProgressionMode,
} from "@/pages/Glossaire";

export default function DashboardGlossaire() {
  usePageTitle("Glossaire — Mon espace");
  const { user, isAuthenticated } = useAuth();
  const { isPremium } = useSubscription();
  const [activeTab, setActiveTab] = useState<GlossaryTabMode>("fiches");

  const PREMIUM_TABS: GlossaryTabMode[] = ["flashcards", "quiz", "parcours", "progression"];
  const isTabPremium = (tab: GlossaryTabMode) => PREMIUM_TABS.includes(tab);

  // Stats
  const { data: stats } = trpc.glossaryV3.stats.useQuery();
  const { data: progress } = trpc.glossaryV3.userProgress.useQuery(undefined, { enabled: isAuthenticated && isPremium });

  const knownCount = progress?.known || 0;
  const totalTerms = stats?.totalTerms || 0;
  const progressPct = totalTerms > 0 ? Math.round((knownCount / totalTerms) * 100) : 0;

  return (
    <Layout>
      {/* ═══════════ HERO ═══════════ */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#344453] via-[#2a3a47] to-[#1a2530]">
        {/* Dot pattern */}
        <div className="absolute inset-0 opacity-[0.04]" style={{
          backgroundImage: `radial-gradient(rgba(212,168,83,0.5) 1px, transparent 1px)`,
          backgroundSize: "24px 24px",
        }} />
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#D4A853]/8 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/4" />

        <div className="container relative py-12 lg:py-16">
          <PageBreadcrumb items={[
            { label: "Mon espace", href: "/dashboard" },
            { label: "Glossaire" },
          ]} className="mb-6" />

          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
            <div className="max-w-2xl">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-3 mb-4"
              >
                <div className="w-10 h-10 rounded-xl bg-[#D4A853]/15 border border-[#D4A853]/25 flex items-center justify-center">
                  <BookOpen size={20} className="text-[#D4A853]" />
                </div>
                <span className="text-white/60 text-sm font-medium uppercase tracking-widest">
                  Encyclopédie financière
                </span>
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-[1.1] mb-4"
              >
                Glossaire interactif
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-white/70 text-base leading-relaxed"
              >
                5 modes d'apprentissage pour maîtriser {GLOSSARY.termLabel} termes financiers.
                Recherchez, révisez, testez-vous et suivez votre progression.
              </motion.p>
            </div>

            {/* Stats cards */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="flex gap-3"
            >
              <div className="bg-white/8 backdrop-blur-sm border border-white/10 rounded-xl px-5 py-3 text-center min-w-[90px]">
                <p className="text-2xl font-bold text-white">{GLOSSARY.termLabel}</p>
                <p className="text-xs text-white/50 mt-0.5">Termes</p>
              </div>
              <div className="bg-white/8 backdrop-blur-sm border border-white/10 rounded-xl px-5 py-3 text-center min-w-[90px]">
                <p className="text-2xl font-bold text-[#D4A853]">{stats?.categories || 6}</p>
                <p className="text-xs text-white/50 mt-0.5">Catégories</p>
              </div>
              {isPremium && (
                <div className="bg-white/8 backdrop-blur-sm border border-white/10 rounded-xl px-5 py-3 text-center min-w-[90px]">
                  <p className="text-2xl font-bold text-[#2E7D5B]">{progressPct}%</p>
                  <p className="text-xs text-white/50 mt-0.5">Maîtrisé</p>
                </div>
              )}
            </motion.div>
          </div>

          {/* Tab Navigation */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className="flex flex-wrap gap-2 mt-8"
          >
            {TAB_CONFIG.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.key;
              const locked = isTabPremium(tab.key) && !isPremium;
              return (
                <button
                  key={tab.key}
                  onClick={() => { if (!locked) setActiveTab(tab.key); }}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    locked
                      ? "bg-white/5 text-white/30 cursor-not-allowed border border-white/10"
                      : isActive
                      ? "bg-[#D4A853] text-[#344453] shadow-lg shadow-[#D4A853]/20"
                      : "bg-white/8 text-white/80 hover:bg-white/12 border border-white/10"
                  }`}
                >
                  <Icon size={16} />
                  <span>{tab.label}</span>
                  {locked ? (
                    <LockIcon size={12} className="text-[#D4A853]/75" />
                  ) : (
                    <span className={`text-xs ${isActive ? "text-[#344453]/70" : "text-white/50"}`}>
                      {tab.desc}
                    </span>
                  )}
                </button>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* ═══════════ MOT DU JOUR ═══════════ */}
      <section className="py-6 bg-white border-b border-[#E1E6EA]">
        <div className="container">
          <div className="max-w-2xl mx-auto">
            <GlossaryWordOfDay />
          </div>
        </div>
      </section>

      {/* ═══════════ CATEGORY PILLS ═══════════ */}
      <section className="py-4 bg-[#F4F5F5] border-b border-[#E1E6EA]">
        <div className="container">
          <div className="flex flex-wrap gap-2 justify-center">
            {Object.entries(CATEGORY_LABELS).map(([key, label]) => {
              const CatIcon = CATEGORY_ICONS[key];
              const colors = CATEGORY_COLORS[key];
              return (
                <div key={key} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-[#E1E6EA]">
                  <CatIcon size={12} style={{ color: colors.accent }} />
                  <span className="text-xs text-[#1E1E1E]/80 font-medium">{label}</span>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ═══════════ CONTENT — Active Mode ═══════════ */}
      <section className="py-10 lg:py-14 bg-[#F4F5F5] min-h-[60vh]">
        <div className="container">
          {activeTab === "fiches" && (
            <FichesMode isPremium={isPremium} isAuthenticated={isAuthenticated} />
          )}
          {activeTab === "flashcards" && (
            <PremiumGate feature="formation:lesson">
              <FlashcardsMode isAuthenticated={isAuthenticated} />
            </PremiumGate>
          )}
          {activeTab === "quiz" && (
            <PremiumGate feature="formation:lesson">
              <QuizMode isAuthenticated={isAuthenticated} />
            </PremiumGate>
          )}
          {activeTab === "parcours" && (
            <PremiumGate feature="formation:lesson">
              <ParcoursMode />
            </PremiumGate>
          )}
          {activeTab === "progression" && (
            <PremiumGate feature="formation:lesson">
              <ProgressionMode isAuthenticated={isAuthenticated} />
            </PremiumGate>
          )}
        </div>
      </section>

      {/* ═══════════ DISCLAIMER ═══════════ */}
      <section className="py-6 bg-white border-t border-[#E1E6EA]">
        <div className="container">
          <p className="text-xs text-[#1E1E1E]/50 text-center max-w-3xl mx-auto leading-relaxed">
            Ce glossaire est fourni à titre strictement informatif. Il ne constitue en aucun cas un conseil en investissement.
          </p>
        </div>
      </section>
    </Layout>
  );
}
