import ShareBar from "@/components/ShareBar";
import { usePageTitle } from "@/hooks/usePageTitle";
import { PRICING } from "@shared/siteConfig";
/**
 * WMB Académie — Lesson Viewer (v6 – UX Excellence)
 * Design: Scroll progress bar, table des matières, typographie améliorée,
 * sidebar propre, notes panel amélioré, navigation claire.
 * Route: /formation/:courseSlug/:lessonSlug
 */
import Layout from "@/components/Layout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useSubscription } from "@/hooks/useSubscription";
import { Link, useParams, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  Clock,
  BookOpen,
  Lock,
  ArrowRight,
  ArrowLeft,
  Crown,
  Star,
  Zap,
  FileText,
  Mail,
  StickyNote,
  X,
  Save,
  PanelLeftOpen,
  PanelLeftClose,
  Play,
  Timer,
  Download,
  Loader2,
  Info,
} from "lucide-react";
import { useMemo, useEffect, useState, useCallback, useRef, Fragment } from "react";
import { LessonContent, NewsletterCTA } from "@/components/academy";
import { toast } from "sonner";

const CATEGORY_COLORS: Record<string, string> = {
  fondamentaux: "#344453",
  vehicules: "#2E7D5B",
  analyses: "#1a3a50",
  indices: "#D4A853",
  histoire: "#344453",
  options: "#344453",
  pratique: "#344453",
};

const CATEGORY_LABELS: Record<string, string> = {
  fondamentaux: "Fondamentaux",
  vehicules: "Véhicules",
  analyses: "Analyses",
  indices: "Indices",
  histoire: "Histoire",
  options: "Options",
  pratique: "Pratique",
};

export default function LessonViewer() {
  usePageTitle("Leçon");
  const { courseSlug, lessonSlug } = useParams<{
    courseSlug: string;
    lessonSlug: string;
  }>();
  const { isAuthenticated } = useAuth();
  const { isPremium, canAccess } = useSubscription();
  const [, navigate] = useLocation();

  // UI state
  const [showNotes, setShowNotes] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const contentRef = useRef<HTMLDivElement>(null);
  const [noteContent, setNoteContent] = useState("");
  const [noteIsDirty, setNoteIsDirty] = useState(false);
  const [readingTime, setReadingTime] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const saveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { data, isLoading } = trpc.academy.getLessonBySlug.useQuery(
    { courseSlug: courseSlug || "", lessonSlug: lessonSlug || "" },
    { enabled: !!courseSlug && !!lessonSlug }
  );

  const { data: allLessons } = trpc.academy.getCourseLessons.useQuery(
    { courseId: data?.course?.id || 0 },
    { enabled: !!data?.course?.id }
  );

  const { data: progress } = trpc.academy.getCourseProgress.useQuery(
    { courseId: data?.course?.id || 0 },
    { enabled: !!data?.course?.id && isAuthenticated }
  );

  // Notes
  const { data: existingNote } = trpc.academy.getLessonNote.useQuery(
    { lessonId: data?.lesson?.id || 0 },
    { enabled: !!data?.lesson?.id && isAuthenticated }
  );

  const saveNote = trpc.academy.saveNote.useMutation({
    onSuccess: () => {
      setNoteIsDirty(false);
    },
  });

  // Formation state
  const updateFormationState = trpc.academy.updateFormationState.useMutation();

  const markComplete = trpc.academy.completeLesson.useMutation({
    onSuccess: () => {
      trpc.useUtils().academy.getCourseProgress.invalidate();
      trpc.useUtils().academy.getAllProgress.invalidate();
      trpc.useUtils().academy.getFormationStats.invalidate();
      trpc.useUtils().academy.getNextLesson.invalidate();
    },
  });

  const markUncomplete = trpc.academy.uncompleteLesson.useMutation({
    onSuccess: () => {
      trpc.useUtils().academy.getCourseProgress.invalidate();
      trpc.useUtils().academy.getAllProgress.invalidate();
      trpc.useUtils().academy.getFormationStats.invalidate();
      trpc.useUtils().academy.getNextLesson.invalidate();
    },
  });

  const course = data?.course;
  const lesson = data?.lesson;
  const isFree = course?.isFree === 1;
  const isFreePreview = lesson?.isFreePreview === 1;
  // Double gating: frontend check + backend isGated flag
  const backendGated = (lesson as any)?.isGated === true;
  const isLocked = backendGated || (!isFree && !isFreePreview && !canAccess("formation:lesson"));
  const catColor = CATEGORY_COLORS[course?.category || ""] || "#344453";
  const catLabel = CATEGORY_LABELS[course?.category || ""] || "Formation";

  const completedSet = useMemo(() => {
    const set = new Set<number>();
    if (progress) {
      for (const p of progress) set.add(p.lessonId);
    }
    return set;
  }, [progress]);

  const isCompleted = lesson ? completedSet.has(lesson.id) : false;

  const { prevLesson, nextLesson, currentIndex } = useMemo(() => {
    if (!allLessons || !lesson) return { prevLesson: null, nextLesson: null, currentIndex: -1 };
    const idx = allLessons.findIndex((l) => l.id === lesson.id);
    return {
      prevLesson: idx > 0 ? allLessons[idx - 1] : null,
      nextLesson: idx < allLessons.length - 1 ? allLessons[idx + 1] : null,
      currentIndex: idx,
    };
  }, [allLessons, lesson]);

  // Load existing note
  useEffect(() => {
    if (existingNote) {
      setNoteContent(existingNote.content);
    } else {
      setNoteContent("");
    }
    setNoteIsDirty(false);
  }, [existingNote, lessonSlug]);

  // Auto-save notes (debounced)
  const handleNoteChange = useCallback((value: string) => {
    setNoteContent(value);
    setNoteIsDirty(true);

    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    saveTimeoutRef.current = setTimeout(() => {
      if (course && lesson && value.trim()) {
        saveNote.mutate({
          courseId: course.id,
          lessonId: lesson.id,
          content: value,
        });
      }
    }, 1500);
  }, [course, lesson, saveNote]);

  // Manual save
  const handleSaveNote = useCallback(() => {
    if (course && lesson && noteContent.trim()) {
      saveNote.mutate({
        courseId: course.id,
        lessonId: lesson.id,
        content: noteContent,
      });
      toast.success("Note sauvegardée");
    }
  }, [course, lesson, noteContent, saveNote]);

  // Export notes
  const [isExporting, setIsExporting] = useState(false);
  const handleExportNotesPdf = useCallback(async () => {
    setIsExporting(true);
    try {
      const response = await fetch("/api/export/notes-pdf", {
        credentials: "include",
      });
      if (!response.ok) {
        const err = await response.json().catch(() => ({}));
        throw new Error(err.error || "Erreur lors de l'export");
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `WMB-Notes-Formation-${new Date().toISOString().split("T")[0]}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success("Notes exportées avec succès");
    } catch (err: any) {
      toast.error(err.message || "Erreur lors de l'export des notes");
    } finally {
      setIsExporting(false);
    }
  }, []);

  // Reading timer
  useEffect(() => {
    if (!isLocked && lesson) {
      setReadingTime(0);
      timerRef.current = setInterval(() => {
        setReadingTime((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [lessonSlug, isLocked, lesson]);

  // Update formation state when viewing a lesson
  useEffect(() => {
    if (isAuthenticated && course && lesson && !isLocked) {
      updateFormationState.mutate({
        currentCourseId: course.id,
        currentLessonId: lesson.id,
      });
    }
  }, [course?.id, lesson?.id, isAuthenticated, isLocked]);

  // Save time spent when leaving
  useEffect(() => {
    return () => {
      if (readingTime > 10 && isAuthenticated) {
        updateFormationState.mutate({
          addTimeSpent: Math.round(readingTime / 60),
        });
      }
    };
  }, [readingTime]);

  // Scroll to top on lesson change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    setShowNotes(false);
    setScrollProgress(0);
  }, [lessonSlug]);

  // Scroll progress tracking
  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (docHeight > 0) {
        setScrollProgress(Math.min(100, Math.round((scrollTop / docHeight) * 100)));
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Extract headings for table of contents
  const tableOfContents = useMemo(() => {
    if (!lesson?.content) return [];
    const headings: { level: number; text: string; id: string }[] = [];
    const lines = lesson.content.split("\n");
    for (const line of lines) {
      const match = line.match(/^(#{2,3})\s+(.+)$/);
      if (match) {
        const level = match[1].length;
        const text = match[2].replace(/\*\*/g, "").trim();
        const id = text.toLowerCase().replace(/[^a-zà-ÿ0-9]+/g, "-").replace(/(^-|-$)/g, "");
        headings.push({ level, text, id });
      }
    }
    return headings;
  }, [lesson?.content]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="w-10 h-10 border-2 border-[#344453]/20 border-t-[#D4A853] rounded-full animate-spin" />
        </div>
      <ShareBar />
    </Layout>
    );
  }

  if (!course || !lesson) {
    return (
      <Layout>
        <div className="container py-24 text-center">
          <h1 className="text-2xl md:text-4xl font-bold text-[#344453] mb-4">Leçon introuvable</h1>
          <p className="text-[#344453]/75 mb-8">Cette leçon n'existe pas ou a été déplacée.</p>
          <Link href="/formation" className="text-[#344453] font-medium hover:underline">
            ← Retour à Apprendre
          </Link>
        </div>
      <ShareBar />
    </Layout>
    );
  }

  const teaserContent = lesson.content
    ? lesson.content.substring(0, 600).replace(/#{1,6}\s/g, "").replace(/\*\*/g, "").replace(/\n/g, " ").trim() + "..."
    : "";

  return (
    <Layout>
      {/* ═══════════ SCROLL PROGRESS BAR ═══════════ */}
      {!isLocked && (
        <div className="fixed top-0 left-0 right-0 z-50 h-1 bg-transparent">
          <div
            className="h-full transition-all duration-150 ease-out"
            style={{
              width: `${scrollProgress}%`,
              backgroundColor: catColor,
              boxShadow: scrollProgress > 0 ? `0 0 8px ${catColor}40` : 'none',
            }}
          />
        </div>
      )}

      {/* ═══════════ TOP BAR ═══════════ */}
      <div className="sticky top-0 z-30 border-b border-[#D0D5DA] bg-white/95 backdrop-blur-sm">
        <div className="container py-3 flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0 overflow-x-auto whitespace-nowrap">
            <Link
              href={`/formation/${courseSlug}`}
              className="flex items-center gap-1.5 text-sm text-[#344453]/75 hover:text-[#344453] transition-colors shrink-0"
            >
              <ChevronLeft size={16} />
              <span className="hidden sm:inline truncate max-w-[200px] whitespace-nowrap overflow-hidden text-ellipsis">{course.title}</span>
              <span className="sm:hidden">Retour</span>
            </Link>
            <span className="text-[#D0D5DA] hidden sm:inline">·</span>
            <span className="text-xs text-[#344453]/80 hidden sm:inline">{catLabel}</span>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Reading timer */}
            {!isLocked && (
              <div className="hidden sm:flex items-center gap-1.5 text-xs text-[#344453]/80 bg-[#F4F5F5] px-3 py-1.5 rounded-lg">
                <Timer size={12} />
                {formatTime(readingTime)}
              </div>
            )}

            {/* Progress dots */}
            <div className="flex items-center gap-1">
              {(allLessons || []).slice(0, 20).map((l) => (
                <div
                  key={l.id}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    l.id === lesson.id
                      ? "bg-[#D4A853] scale-125"
                      : completedSet.has(l.id)
                      ? "bg-emerald-400"
                      : "bg-[#D0D5DA]"
                  }`}
                />
              ))}
              {(allLessons?.length || 0) > 20 && (
                <span className="text-[11px] text-[#344453]/80 ml-1">+{(allLessons?.length || 0) - 20}</span>
              )}
            </div>

            <span className="text-xs text-[#344453]/80 ml-1">
              {currentIndex + 1}/{allLessons?.length || 0}
            </span>

            {isCompleted && (
              <span className="flex items-center gap-1 text-emerald-600 text-xs font-medium">
                <CheckCircle2 size={12} /> Terminé
              </span>
            )}

            {/* Sidebar toggle */}
            <button
              onClick={() => setShowSidebar(!showSidebar)}
              className="p-2 rounded-lg hover:bg-[#F4F5F5] transition-colors text-[#344453]/80 hover:text-[#344453]"
              title="Sommaire du cours"
            >
              {showSidebar ? <PanelLeftClose size={18} /> : <PanelLeftOpen size={18} />}
            </button>

            {/* Notes toggle */}
            {isAuthenticated && !isLocked && (
              <button
                onClick={() => setShowNotes(!showNotes)}
                className={`p-2 rounded-lg transition-colors relative ${
                  showNotes
                    ? "bg-[#D4A853]/10 text-[#8A6E18]"
                    : "hover:bg-[#F4F5F5] text-[#344453]/80 hover:text-[#344453]"
                }`}
                title="Mes notes"
              >
                <StickyNote size={18} />
                {noteContent.trim() && (
                  <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-[#D4A853] rounded-full" />
                )}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ═══════════ MAIN CONTENT AREA ═══════════ */}
      <div className="flex relative">
        {/* ─── SIDEBAR (course navigation) ─── */}
        <AnimatePresence>
          {showSidebar && (
            <motion.aside
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 340, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="hidden lg:block border-r border-[#D0D5DA] bg-[#FAFAFA] overflow-hidden shrink-0"
            >
              <div className="w-[340px] h-[calc(100vh-56px)] overflow-y-auto sticky top-[56px]">
                <div className="p-6">
                  <div className="flex items-center gap-3 mb-5">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm font-bold"
                      style={{ backgroundColor: catColor }}
                    >
                      {course.title.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-sm font-semibold text-[#344453] truncate">{course.title}</h3>
                      <p className="text-xs text-[#344453]/80">
                        {completedSet.size}/{allLessons?.length || 0} leçons terminées
                      </p>
                    </div>
                  </div>

                  {/* Course progress */}
                  <div className="h-2 bg-[#D0D5DA] rounded-full overflow-hidden mb-6">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${allLessons ? Math.round((completedSet.size / allLessons.length) * 100) : 0}%`,
                        backgroundColor: catColor,
                      }}
                    />
                  </div>

                  {/* Table of contents (if headings exist) */}
                  {tableOfContents.length > 2 && (
                    <div className="mb-6 pb-5 border-b border-[#D0D5DA]">
                      <p className="text-[11px] font-bold text-[#344453]/50 uppercase tracking-wider mb-3">Dans cette leçon</p>
                      <div className="space-y-1">
                        {tableOfContents.map((h, i) => (
                          <button
                            key={i}
                            onClick={() => {
                              const el = document.getElementById(h.id);
                              if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
                            }}
                            className={`block w-full text-left text-xs text-[#344453]/70 hover:text-[#344453] transition-colors py-1 truncate ${
                              h.level === 3 ? "pl-4" : ""
                            }`}
                          >
                            {h.text}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Lesson list */}
                  <div className="space-y-1">
                    {(allLessons || []).map((l, i) => {
                      const isCurrentLesson = l.id === lesson.id;
                      const isLessonCompleted = completedSet.has(l.id);

                      return (
                        <Link key={l.id} href={`/formation/${courseSlug}/${l.slug}`}>
                          <div
                            className={`flex items-center gap-3 px-3 py-3 rounded-xl transition-all cursor-pointer ${
                              isCurrentLesson
                                ? "bg-white border border-[#D0D5DA] shadow-sm"
                                : "hover:bg-[#E1E6EA]0"
                            }`}
                          >
                            <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-[11px] font-bold shrink-0 ${
                              isLessonCompleted
                                ? "bg-emerald-100 text-emerald-600"
                                : isCurrentLesson
                                ? "text-white"
                                : "bg-[#D0D5DA] text-[#344453]/80"
                            }`} style={isCurrentLesson && !isLessonCompleted ? { backgroundColor: catColor } : {}}>
                              {isLessonCompleted ? <CheckCircle2 size={13} /> : i + 1}
                            </div>
                            <span className={`text-sm truncate ${
                              isCurrentLesson
                                ? "font-semibold text-[#344453]"
                                : isLessonCompleted
                                ? "text-[#344453]/80 line-through"
                                : "text-[#344453]/80"
                            }`}>
                              {l.title}
                            </span>
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* ─── MAIN CONTENT ─── */}
        <section className="flex-1 min-w-0 py-12 lg:py-20 bg-white">
          <div className="max-w-3xl mx-auto px-4 sm:px-6">
            {/* Lesson header */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-14"
            >
              {/* Category & meta badges */}
              <div className="flex flex-nowrap items-center gap-2.5 mb-6 overflow-x-auto scrollbar-hide">
                <span
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold text-white uppercase tracking-wider"
                  style={{ backgroundColor: catColor }}
                >
                  <BookOpen size={11} />
                  {catLabel}
                </span>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F4F5F5] text-[#344453]/70 text-[11px] font-medium">
                  <Clock size={11} />
                  {lesson.estimatedMinutes || 5} min de lecture
                </span>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F4F5F5] text-[#344453]/70 text-[11px] font-medium">
                  Leçon {currentIndex + 1}/{allLessons?.length || 0}
                </span>
                {isFreePreview && !isFree && (
                  <span className="px-3 py-1 bg-emerald-50 text-emerald-600 text-[11px] font-bold rounded-full uppercase tracking-wider">
                    Aperçu gratuit
                  </span>
                )}
              </div>

              {/* Title */}
              <h1 className="text-2xl md:text-3xl lg:text-[40px] font-bold text-[#344453] leading-[1.15] tracking-tight">
                {lesson.title}
              </h1>

              {/* Decorative accent line */}
              <div className="mt-6 flex items-center gap-3">
                <div className="h-[3px] w-12 rounded-full" style={{ background: `linear-gradient(90deg, ${catColor}, #D4A853)` }} />
                <div className="h-[3px] w-6 rounded-full bg-[#D4A853]/30" />
              </div>
            </motion.div>

            {/* ─── Lesson body ─── */}
            {isLocked ? (
              /* LOCKED: Blurred teaser + paywall */
              <div className="relative">
                <div className="relative overflow-hidden" style={{ maxHeight: "400px" }}>
                  <div className="text-[#344453]/75 text-base leading-relaxed">
                    <p>{teaserContent}</p>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-white via-white/95 to-transparent" />
                </div>

                <div className="relative -mt-8 z-10">
                  <div className="bg-gradient-to-br from-[#FDFBF7] to-white rounded-2xl border border-[#D4A853]/20 shadow-xl shadow-[#D4A853]/5 p-10 md:p-12 text-center">
                    <div className="w-18 h-18 rounded-2xl bg-gradient-to-br from-[#D4A853]/15 to-[#D4A853]/5 border border-[#D4A853]/20 flex items-center justify-center mx-auto mb-6 w-[72px] h-[72px]">
                      <Crown size={32} className="text-[#8A6E18]" />
                    </div>

                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#D4A853]/10 border border-[#D4A853]/20 mb-5">
                      <Star size={11} className="text-[#8A6E18]" />
                      <span className="text-xs font-bold text-[#8A6E18] uppercase tracking-wider">
                        Contenu Premium
                      </span>
                    </div>

                    <h2 className="text-xl md:text-2xl font-bold text-[#344453] mb-3">
                      Cette leçon est réservée aux abonnés
                    </h2>
                    <p className="text-sm text-[#344453]/75 mb-8 max-w-md mx-auto leading-relaxed">
                      Débloquez cette leçon et l'intégralité de la formation WMB — {allLessons?.length || 0} leçons,
                      6 modules, plus la newsletter hebdomadaire et tous les outils.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 max-w-sm mx-auto mb-8">
                      {[
                        { icon: BookOpen, label: "Formation complète" },
                        { icon: Mail, label: "Newsletters" },
                        { icon: Zap, label: "Outils & scripts" },
                      ].map((item) => (
                        <div key={item.label} className="text-center">
                          <div className="w-12 h-12 rounded-xl bg-[#F4F5F5] flex items-center justify-center mx-auto mb-2">
                            <item.icon size={18} className="text-[#344453]" />
                          </div>
                          <p className="text-xs text-[#344453]/75 font-medium">{item.label}</p>
                        </div>
                      ))}
                    </div>

                    <Link
                      href="/pricing"
                      className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C49A4A] text-[#344453] font-bold rounded-xl hover:shadow-lg hover:shadow-[#D4A853]/20 transition-all text-sm"
                    >
                      Voir les offres <ArrowRight size={14} />
                    </Link>
                    <p className="text-xs text-[#344453]/80 mt-4">
                      À partir de {PRICING.plans.premium.price} {PRICING.currency}/mois · Annulation à tout moment
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              /* UNLOCKED: Full content */
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <div className="lesson-prose">
                  <LessonContent content={lesson.content || "Contenu en cours de rédaction..."} />
                </div>

                {/* Mark as complete / completed state */}
                {isAuthenticated && (
                  <div className="mt-14 pt-10 border-t border-[#D0D5DA]">
                    {!isCompleted ? (
                      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                        <button
                          onClick={() => {
                            if (course && lesson) {
                              markComplete.mutate(
                                { courseId: course.id, lessonId: lesson.id },
                                {
                                  onSuccess: () => {
                                    toast.success(
                                      nextLesson
                                        ? "Leçon terminée ! Passage à la suivante..."
                                        : "Bravo, vous avez terminé ce cours !"
                                    );
                                    if (nextLesson) {
                                      setTimeout(() => {
                                        navigate(`/formation/${courseSlug}/${nextLesson.slug}`);
                                      }, 800);
                                    }
                                  },
                                }
                              );
                            }
                          }}
                          disabled={markComplete.isPending}
                          className="inline-flex items-center gap-2 px-7 py-4 bg-[#2E7D5B] text-white font-semibold rounded-xl hover:bg-[#2E7D5B]/90 transition-all hover:shadow-lg hover:shadow-[#2E7D5B]/15 disabled:opacity-50 text-sm"
                        >
                          <CheckCircle2 size={18} />
                          {markComplete.isPending ? "Enregistrement..." : "Marquer comme terminé"}
                          {nextLesson && !markComplete.isPending && (
                            <span className="text-[#344453]/80 text-xs ml-1">→ leçon suivante</span>
                          )}
                        </button>
                        {allLessons && (
                          <span className="text-sm text-[#344453]/80">
                            {completedSet.size}/{allLessons.length} leçons terminées dans ce cours
                          </span>
                        )}
                      </div>
                    ) : (
                      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                        <div className="flex items-center gap-3 px-6 py-3.5 bg-emerald-50 rounded-xl border border-emerald-100">
                          <CheckCircle2 size={20} className="text-emerald-600" />
                          <span className="text-emerald-700 font-medium">Leçon terminée</span>
                        </div>
                        <button
                          onClick={() => {
                            if (course && lesson) {
                              markUncomplete.mutate({ courseId: course.id, lessonId: lesson.id });
                            }
                          }}
                          disabled={markUncomplete.isPending}
                          className="text-sm text-[#344453]/80 hover:text-[#344453]/80 transition-colors underline"
                        >
                          {markUncomplete.isPending ? "..." : "Annuler"}
                        </button>
                        {allLessons && (
                          <span className="text-sm text-[#344453]/80">
                            {completedSet.size}/{allLessons.length} leçons terminées dans ce cours
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Newsletter CTA for non-premium */}
                {!canAccess("formation:lesson") && (
                  <NewsletterCTA variant="lesson-end" />
                )}
              </motion.div>
            )}

            {/* ═══════════ NAVIGATION ═══════════ */}
            <div className="mt-14 pt-10 border-t border-[#D0D5DA]">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {prevLesson ? (
                  <Link
                    href={`/formation/${courseSlug}/${prevLesson.slug}`}
                    className="group flex items-center gap-4 p-5 rounded-2xl border border-[#D0D5DA] hover:border-[#344453]/20 hover:shadow-lg transition-all bg-white"
                  >
                    <div className="w-11 h-11 rounded-xl bg-[#F4F5F5] flex items-center justify-center group-hover:bg-[#344453]/10 transition-colors shrink-0">
                      <ArrowLeft size={18} className="text-[#344453]/70" />
                    </div>
                    <div className="text-left min-w-0">
                      <p className="text-[10px] font-bold text-[#344453]/40 uppercase tracking-[0.15em] mb-1">
                        Précédent
                      </p>
                      <p className="text-sm font-semibold text-[#344453] truncate group-hover:text-[#1a3a50] transition-colors">{prevLesson.title}</p>
                    </div>
                  </Link>
                ) : (
                  <div />
                )}
                {nextLesson ? (
                  <Link
                    href={`/formation/${courseSlug}/${nextLesson.slug}`}
                    className="group flex items-center gap-4 p-5 rounded-2xl border border-[#D0D5DA] hover:border-[#D4A853]/30 hover:shadow-lg hover:shadow-[#D4A853]/5 transition-all bg-white"
                  >
                    <div className="text-right min-w-0 flex-1">
                      <p className="text-[10px] font-bold text-[#8A6E18]/60 uppercase tracking-[0.15em] mb-1">
                        Suivant
                      </p>
                      <p className="text-sm font-semibold text-[#344453] truncate group-hover:text-[#8A6E18] transition-colors">{nextLesson.title}</p>
                    </div>
                    <div className="w-11 h-11 rounded-xl bg-[#D4A853]/10 flex items-center justify-center group-hover:bg-[#D4A853]/20 transition-colors shrink-0">
                      <ArrowRight size={18} className="text-[#8A6E18]" />
                    </div>
                  </Link>
                ) : (
                  <Link
                    href={`/formation/${courseSlug}`}
                    className="group flex items-center gap-4 p-5 rounded-2xl border border-emerald-200 hover:border-emerald-300 hover:shadow-lg transition-all bg-emerald-50/50"
                  >
                    <div className="text-right min-w-0 flex-1">
                      <p className="text-[10px] font-bold text-emerald-500/60 uppercase tracking-[0.15em] mb-1">
                        Cours terminé
                      </p>
                      <p className="text-sm font-semibold text-[#2E7D5B]">Retour au cours</p>
                    </div>
                    <div className="w-11 h-11 rounded-xl bg-emerald-100 flex items-center justify-center shrink-0">
                      <ArrowRight size={18} className="text-[#2E7D5B]" />
                    </div>
                  </Link>
                )}
              </div>
            </div>

            {/* ─── DISCLAIMER ─── */}
            <div className="mt-10 p-5 bg-[#F8F6F0] rounded-xl border border-[#E8E4D8]">
              <div className="flex items-start gap-3">
                <Info size={14} className="text-[#8A6E18] shrink-0 mt-0.5" />
                <p className="text-xs text-[#344453]/80 leading-relaxed">
                  <strong className="text-[#344453]/75">Contenu informatif et informatif uniquement.</strong>{" "}
                  Ne constitue pas un conseil en investissement.{" "}
                  <Link href="/disclaimer" className="underline hover:text-[#344453]">Disclaimer</Link>
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ─── NOTES PANEL (slide-in from right) ─── */}
        <AnimatePresence>
          {showNotes && isAuthenticated && !isLocked && (
            <motion.aside
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 400, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="hidden lg:block border-l border-[#D0D5DA] bg-[#FAFAFA] overflow-hidden shrink-0"
            >
              <div className="w-[400px] h-[calc(100vh-56px)] sticky top-[56px] flex flex-col">
                {/* Notes header */}
                <div className="p-5 border-b border-[#D0D5DA] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <StickyNote size={18} className="text-[#8A6E18]" />
                    <h3 className="text-sm font-semibold text-[#344453]">Mes notes</h3>
                    {noteIsDirty && (
                      <span className="text-[11px] text-[#8A6E18] font-medium">Non sauvegardé</span>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={handleSaveNote}
                      disabled={!noteIsDirty || saveNote.isPending}
                      className="p-2 rounded-lg hover:bg-[#D0D5DA] transition-colors text-[#344453]/80 hover:text-[#344453] disabled:opacity-40"
                      title="Sauvegarder"
                    >
                      <Save size={16} />
                    </button>
                    <button
                      onClick={() => setShowNotes(false)}
                      className="p-2 rounded-lg hover:bg-[#D0D5DA] transition-colors text-[#344453]/80 hover:text-[#344453]"
                    >
                      <X size={16} />
                    </button>
                  </div>
                </div>

                {/* Notes editor */}
                <div className="flex-1 p-5">
                  <textarea
                    value={noteContent}
                    onChange={(e) => handleNoteChange(e.target.value)}
                    placeholder={`Prenez des notes sur "${lesson.title}"...\n\nVos notes sont sauvegardées automatiquement et liées à cette leçon.`}
                    className="w-full h-full bg-white border border-[#D0D5DA] rounded-xl p-5 text-sm text-[#344453]/80 leading-relaxed resize-none focus:outline-none focus:border-[#D4A853]/30 focus:ring-2 focus:ring-[#D4A853]/10 transition-all placeholder:text-[#344453]/75"
                  />
                </div>

                {/* Notes footer */}
                <div className="p-5 border-t border-[#D0D5DA] space-y-3">
                  <button
                    onClick={handleExportNotesPdf}
                    disabled={isExporting}
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-[#344453] text-white text-sm font-semibold rounded-xl hover:bg-[#344453]/90 transition-colors disabled:opacity-50"
                  >
                    {isExporting ? (
                      <><Loader2 size={16} className="animate-spin" /> Export en cours...</>
                    ) : (
                      <><Download size={16} /> Télécharger toutes mes notes</>
                    )}
                  </button>
                  <p className="text-xs text-[#344453]/80 text-center">
                    {saveNote.isPending ? "Sauvegarde en cours..." : noteContent.trim() ? `${noteContent.length} caractères · Sauvegarde automatique` : "Commencez à écrire pour sauvegarder"}
                  </p>
                </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>
      </div>

      {/* ─── MOBILE NOTES (bottom sheet) ─── */}
      <AnimatePresence>
        {showNotes && isAuthenticated && !isLocked && (
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            className="lg:hidden fixed inset-x-0 bottom-0 z-50 bg-white border-t border-[#D0D5DA] shadow-2xl rounded-t-2xl"
            style={{ maxHeight: "60vh" }}
          >
            <div className="flex flex-col h-full" style={{ maxHeight: "60vh" }}>
              {/* Handle */}
              <div className="flex items-center justify-center py-2">
                <div className="w-10 h-1 bg-[#D0D5DA] rounded-full" />
              </div>

              {/* Header */}
              <div className="px-5 pb-3 flex items-center justify-between border-b border-[#D0D5DA]">
                <div className="flex items-center gap-2">
                  <StickyNote size={18} className="text-[#8A6E18]" />
                  <h3 className="text-sm font-semibold text-[#344453]">Mes notes</h3>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={handleSaveNote}
                    disabled={!noteIsDirty}
                    className="text-sm font-medium text-[#8A6E18] disabled:opacity-40"
                  >
                    Sauvegarder
                  </button>
                  <button onClick={() => setShowNotes(false)}>
                    <X size={18} className="text-[#344453]/80" />
                  </button>
                </div>
              </div>

              {/* Editor */}
              <div className="flex-1 p-5 overflow-y-auto">
                <textarea
                  value={noteContent}
                  onChange={(e) => handleNoteChange(e.target.value)}
                  placeholder="Prenez des notes..."
                  className="w-full h-48 bg-[#FAFAFA] border border-[#D0D5DA] rounded-xl p-5 text-sm text-[#344453]/80 leading-relaxed resize-none focus:outline-none focus:border-[#D4A853]/30"
                />
                <button
                  onClick={handleExportNotesPdf}
                  disabled={isExporting}
                  className="mt-4 w-full flex items-center justify-center gap-2 px-4 py-3 bg-[#344453] text-white text-sm font-semibold rounded-xl hover:bg-[#344453]/90 transition-colors disabled:opacity-50"
                >
                  {isExporting ? (
                    <><Loader2 size={16} className="animate-spin" /> Export en cours...</>
                  ) : (
                    <><Download size={16} /> Télécharger mes notes</>
                  )}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── MOBILE NOTES FAB ─── */}
      {isAuthenticated && !isLocked && !showNotes && (
        <button
          onClick={() => setShowNotes(true)}
          className="lg:hidden fixed bottom-6 right-6 z-40 w-14 h-14 bg-[#D4A853] text-[#344453] rounded-full shadow-lg shadow-[#D4A853]/30 flex items-center justify-center hover:bg-[#C49A4A] transition-colors"
        >
          <StickyNote size={22} />
          {noteContent.trim() && (
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#344453] rounded-full flex items-center justify-center">
              <span className="text-[8px] text-white font-bold">1</span>
            </div>
          )}
        </button>
      )}
    <ShareBar />
    </Layout>
  );
}
