/**
 * FormationAnalyse — parcours « Analyse de marché » : modules ordonnés
 * débutant → avancé, chacun avec jauges, exemples concrets et schéma.
 * 100% informatif (voix WMB). Illustrations + jauges SVG originales.
 */
import Layout from "@/components/Layout";
import PageBreadcrumb from "@/components/PageBreadcrumb";
import ConceptIllustration from "@/components/ConceptIllustration";
import { Reveal } from "@/components/Reveal";
import Gauge from "@/components/Gauge";
import PoleCrossLinks from "@/components/PoleCrossLinks";
import { useSEO } from "@/hooks/useSEO";
import { usePageTitle } from "@/hooks/usePageTitle";
import HeroBackdrop from "@/components/HeroBackdrop";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  ANALYSIS_LESSONS,
  LEVEL_META,
  ANALYSIS_LEVELS,
  type AnalysisLesson,
  type Level,
} from "@/data/formationAnalyse";
import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { ArrowRight, GraduationCap, Search, Info, Lightbulb, CheckCircle2, BookOpen, BarChart3, Sprout, TrendingUp, Trophy } from "lucide-react";

// Aperçu visuel du parcours par niveau (icône + descripteur court).
const LEVEL_OVERVIEW: { id: Level; Icon: typeof Sprout; blurb: string }[] = [
  { id: "Débutant", Icon: Sprout, blurb: "Les fondations : prix, tendance, supports, chandeliers." },
  { id: "Intermédiaire", Icon: TrendingUp, blurb: "Lecture combinée : figures, momentum, volumes, confluence." },
  { id: "Avancé", Icon: Trophy, blurb: "Maîtrise : régimes de marché, risque, systèmes, VaR." },
];

export default function FormationAnalyse() {
  usePageTitle("Formation — Analyse de marché");
  useSEO({
    title: "Formation Analyse de Marché — Parcours débutant à avancé | WMB",
    description:
      "Apprenez l'analyse de marché pas à pas : prix, tendances, canaux, chandeliers, figures, momentum, volatilité, confluence. Jauges, exemples concrets et schémas. 100% informatif.",
    canonical: "/formation-analyse",
  });

  const [active, setActive] = useState<Level | "all">("all");
  const [selected, setSelected] = useState<AnalysisLesson | null>(null);

  // Ouverture directe d'une leçon via ?fiche=<slug> (recherche globale, partage).
  useEffect(() => {
    if (typeof window === "undefined") return;
    const slug = new URLSearchParams(window.location.search).get("fiche");
    if (!slug) return;
    const found = ANALYSIS_LESSONS.find((l) => l.slug === slug);
    if (found) setSelected(found);
  }, []);

  const list = useMemo(
    () => (active === "all" ? ANALYSIS_LESSONS : ANALYSIS_LESSONS.filter((l) => l.level === active)),
    [active],
  );

  return (
    <Layout>
      {/* ─── HERO ─── */}
      <section className="relative overflow-hidden min-h-[460px] lg:min-h-[540px] bg-[#23303c]">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a2530] via-[#2a3845] to-[#3a4b5a]" />
        <HeroBackdrop accent="#D4A853" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1a2530]/85 via-[#1a2530]/45 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1a2530]/55 to-transparent" />
        <div className="relative container py-16 lg:py-24 flex items-center min-h-[460px] lg:min-h-[540px]">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-[#D4A853]/20 border border-[#D4A853]/30 px-3 py-1.5 mb-6">
              <GraduationCap size={14} className="text-[#D4A853]" />
              <span className="text-[#D4A853] text-xs font-semibold uppercase tracking-wider">Formation · Analyse de marché</span>
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-[56px] font-bold text-white leading-[1.1] mb-5">
              L'analyse,
              <br />
              <span className="text-[#D4A853]">pas à pas.</span>
            </h1>
            <p className="text-lg text-white/75 leading-relaxed mb-8 max-w-lg">
              {ANALYSIS_LESSONS.length} modules du débutant à l'avancé — prix, tendances, canaux, chandeliers,
              figures, momentum, volatilité, confluence. Chaque module avec jauges, exemples et schémas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/figures-chartistes" className="inline-flex items-center justify-center gap-2 rounded-lg bg-white px-7 py-3.5 text-base font-semibold text-[#344453] hover:bg-white/90 transition-colors">
                <BookOpen size={17} /> Les figures
              </Link>
              <Link href="/methode" className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/30 px-7 py-3.5 text-base font-medium text-white hover:bg-white/10 transition-colors">
                <BarChart3 size={17} /> La méthode
              </Link>
            </div>
          </div>
        </div>
      </section>

      <div className="container">
        <PageBreadcrumb items={[{ label: "Formation Analyse" }]} />
      </div>

      {/* ─── DISCLAIMER ─── */}
      <section className="container">
        <div className="flex items-start gap-3 rounded-xl border border-[#C8A962]/30 bg-[#C8A962]/[0.07] px-4 py-3">
          <Info size={18} className="mt-0.5 shrink-0 text-[#8A6E18]" />
          <p className="text-sm text-[#344453]/85 leading-relaxed">
            <span className="font-semibold text-[#344453]">Contenu strictement informatif.</span> Les jauges sont des
            repères pédagogiques (difficulté, utilité…), pas des données de marché en temps réel ni des signaux.
          </p>
        </div>
      </section>

      {/* ─── PARCOURS PAR NIVEAU (aperçu visuel) ─── */}
      <section className="container mt-8">
        <div className="grid sm:grid-cols-3 gap-4">
          {LEVEL_OVERVIEW.map((lv, i) => {
            const meta = LEVEL_META[lv.id];
            const count = ANALYSIS_LESSONS.filter((l) => l.level === lv.id).length;
            return (
              <Reveal key={lv.id} index={i}>
                <button
                  onClick={() => setActive(lv.id)}
                  className="group w-full text-left flex items-start gap-4 rounded-2xl border border-[#E1E6EA] bg-white p-5 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453]"
                >
                  <div
                    className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl transition-transform group-hover:scale-110"
                    style={{ backgroundColor: `${meta.color}16`, color: meta.color }}
                  >
                    <lv.Icon size={22} />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-2xl font-bold" style={{ color: meta.color }}>{count}</span>
                      <span className="text-xs font-semibold uppercase tracking-wide text-[#344453]/55">modules</span>
                    </div>
                    <p className="mt-0.5 text-sm font-bold text-[#344453]">{lv.id}</p>
                    <p className="mt-1 text-xs text-[#344453]/65 leading-snug">{lv.blurb}</p>
                  </div>
                </button>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* ─── FILTRES ─── */}
      <section className="container mt-8">
        <div className="flex flex-wrap gap-2">
          {ANALYSIS_LEVELS.map((lv) => {
            const isActive = active === lv.id;
            return (
              <button
                key={lv.id}
                onClick={() => setActive(lv.id)}
                className={`rounded-full px-4 py-2 text-sm font-semibold transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453] ${
                  isActive ? "bg-[#344453] text-white shadow-sm" : "bg-white text-[#344453]/80 border border-[#E1E6EA] hover:border-[#344453]/30"
                }`}
                aria-pressed={isActive}
              >
                {lv.label}
              </button>
            );
          })}
        </div>
      </section>

      {/* ─── GRILLE ─── */}
      <section className="container mt-6 pb-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {list.map((l, i) => (
            <Reveal key={l.slug} index={i} className="h-full">
            <button
              onClick={() => setSelected(l)}
              className="group h-full w-full text-left flex flex-col rounded-2xl border border-[#E1E6EA] bg-white overflow-hidden hover:shadow-xl hover:-translate-y-1 hover:border-[#344453]/20 transition-all duration-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453]"
              aria-label={`Module ${l.n} — ${l.title}`}
            >
              <div className="h-1 w-full" style={{ backgroundColor: LEVEL_META[l.level].color }} />
              <div className="relative overflow-hidden bg-gradient-to-br from-[#F8F9FA] to-[#F0F2F4] p-4 pb-2">
                <span className="absolute top-3 left-3 z-10 inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-bold" style={{ color: LEVEL_META[l.level].color, backgroundColor: `${LEVEL_META[l.level].color}18` }}>
                  {l.level}
                </span>
                <span className="absolute top-3 right-3 z-10 flex h-7 w-7 items-center justify-center rounded-full bg-[#344453] text-xs font-bold text-white">
                  {l.n}
                </span>
                <div className="wmb-illu-zoom">
                  <ConceptIllustration type={l.illu} />
                </div>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <h3 className="text-base font-bold text-[#344453]">{l.title}</h3>
                <p className="mt-0.5 text-xs text-[#344453]/50">{l.english}</p>
                <p className="mt-2.5 text-sm text-[#344453]/75 leading-relaxed">{l.summary}</p>
                {l.examples[0] && (
                  <div className="mt-3 rounded-lg bg-[#2E7D5B]/[0.06] border border-[#2E7D5B]/15 px-3 py-2">
                    <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide text-[#2E7D5B]">
                      <Lightbulb size={11} /> Exemple
                    </div>
                    <p className="mt-1 text-xs text-[#344453]/70 leading-snug line-clamp-3">{l.examples[0].detail}</p>
                  </div>
                )}
                <div className="mt-auto pt-4 flex items-center justify-end">
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#344453] group-hover:gap-2 transition-all">
                    Ouvrir le module <ArrowRight size={13} />
                  </span>
                </div>
              </div>
            </button>
            </Reveal>
          ))}
        </div>
        <PoleCrossLinks current="hub" />
      </section>

      {/* ─── FICHE MODULE ─── */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 gap-0">
          {selected && (
            <>
              {/* ─── BANNIÈRE COLORÉE (par niveau) ─── */}
              <div
                className="relative overflow-hidden px-6 pt-7 pb-9"
                style={{ background: `linear-gradient(135deg, ${LEVEL_META[selected.level].color} 0%, #1a2530 96%)` }}
              >
                {(() => {
                  const LvIcon = LEVEL_OVERVIEW.find((l) => l.id === selected.level)?.Icon ?? GraduationCap;
                  return <LvIcon className="absolute -right-5 -top-5 text-white/10" size={150} strokeWidth={1.3} />;
                })()}
                <DialogHeader className="relative text-left">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="inline-flex items-center rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-white backdrop-blur-sm">
                      {selected.level}
                    </span>
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold text-white backdrop-blur-sm">
                      Module {selected.n} / {ANALYSIS_LESSONS.length}
                    </span>
                  </div>
                  <DialogTitle className="mt-3 text-2xl lg:text-[28px] font-bold text-white leading-tight">{selected.title}</DialogTitle>
                  <p className="text-sm text-white/60">{selected.english}</p>
                </DialogHeader>
              </div>

              {/* ─── ILLUSTRATION (chevauche la bannière) ─── */}
              <div className="relative -mt-5 px-6">
                <div className="overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white shadow-md">
                  <div className="h-1 w-full" style={{ backgroundColor: LEVEL_META[selected.level].color }} />
                  <div className="wmb-illu-grid wmb-illu-zoom p-4">
                    <ConceptIllustration type={selected.illu} />
                  </div>
                  <p className="border-t border-[#F0F2F4] px-4 py-2.5 text-center text-xs italic text-[#344453]/55 leading-snug">
                    {selected.summary}
                  </p>
                </div>
              </div>

              <div className="px-6 py-5 space-y-5">
                <p className="text-sm text-[#344453]/85 leading-relaxed">{selected.intro}</p>

                {/* jauges */}
                <div className="grid grid-cols-2 gap-3 rounded-xl border border-[#E1E6EA] bg-white p-4">
                  {selected.gauges.map((g) => (
                    <Gauge key={g.label} value={g.value} label={g.label} verdict={g.verdict} scheme={g.scheme} />
                  ))}
                </div>

                {/* exemples */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#344453]/60 mb-3 flex items-center gap-1.5">
                    <Lightbulb size={13} /> Exemples concrets
                  </h4>
                  <div className="space-y-2.5">
                    {selected.examples.map((ex, i) => (
                      <div key={i} className="rounded-xl border border-[#E1E6EA] bg-white p-3.5">
                        <p className="text-sm font-semibold text-[#344453]">{ex.title}</p>
                        <p className="mt-1 text-sm text-[#344453]/70 leading-snug">{ex.detail}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* points clés */}
                <div className="rounded-xl bg-[#344453] p-5 text-white">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#C8A962] mb-3">À retenir</h4>
                  <ul className="space-y-2">
                    {selected.keyPoints.map((p, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-white/90 leading-snug">
                        <CheckCircle2 size={15} className="mt-0.5 shrink-0 text-[#7FB89E]" />
                        {p}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex flex-wrap gap-3 pt-1">
                  <Link href="/glossaire" className="inline-flex items-center gap-1.5 rounded-lg border border-[#E1E6EA] px-3.5 py-2 text-xs font-semibold text-[#344453] hover:border-[#344453]/30">
                    <Search size={13} /> Le glossaire
                  </Link>
                  <Link href="/indicateurs-tendance" className="inline-flex items-center gap-1.5 rounded-lg border border-[#E1E6EA] px-3.5 py-2 text-xs font-semibold text-[#344453] hover:border-[#344453]/30">
                    <BarChart3 size={13} /> Les indicateurs
                  </Link>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
