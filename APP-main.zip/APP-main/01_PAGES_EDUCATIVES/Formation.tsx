
/**
 * WMB Académie — Formation Landing Page (V22 – Sales Page)
 * Design: Page de vente immersive sans modules visibles.
 * Les modules sont uniquement dans le dashboard Ma Formation.
 * Focus: donner envie, expliquer la valeur, montrer les compétences, pousser vers l'inscription.
 */
import Layout from "@/components/Layout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useSubscription } from "@/hooks/useSubscription";
import { Link, useLocation } from "wouter";
import { motion, useInView } from "framer-motion";
import {
  GraduationCap, Clock, BookOpen, ChevronRight, TrendingUp,
  BarChart3, Layers, Globe, PieChart, Brain, Shield,
  Zap, FileText, Briefcase, Landmark,
  ArrowRight, CheckCircle2, Crown, Play, Target, Rocket, Trophy, Timer, Lock,
  ChevronDown, Sparkles, Award, Download,
  Star, Lightbulb, Compass, BookMarked, Activity,
  BarChart, StickyNote,
} from "lucide-react";
import { useMemo, useState, useRef, useEffect } from "react";
import { NewsletterCTA } from "@/components/academy";
import { useSEO } from "@/hooks/useSEO";
import { SEO_PAGES } from "@/lib/seoConfig";
import { ACADEMY, GLOSSARY, INDICATORS, THEMES, PRICING } from "@shared/siteConfig";
import PageBreadcrumb from "@/components/PageBreadcrumb";
import { usePageTitle } from "@/hooks/usePageTitle";

/* ─── CDN Images ─── */
const IMAGES = {
  hero: "/api/img/wmb-formation-hero-YYm9qMpiARamDo8GDkf96R.webp",
  learning: "/api/img/wmb-formation-learning-M67ResVuUG5XxanN6Hvtm2.webp",
  charts: "/api/img/wmb-formation-charts-fSJX6JnQ2WgwcV9rbbFFYK.webp",
  wallstreet: "/api/img/wmb-formation-wallstreet-3GXjHz9UhTFqMJf9Aj6qM7.webp",
  success: "/api/img/wmb-formation-success-LEhBq73MKn3k9uSrB3BTjK.webp",
};

/* ─── Animations ─── */
const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.08, duration: 0.5, ease: [0, 0, 0.2, 1] as [number, number, number, number] },
  }),
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.06 } },
};

/* ─── Animated Counter ─── */
function AnimatedCounter({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const hasAnimated = useRef(false);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  useEffect(() => {
    if (isInView && target > 0 && !hasAnimated.current) {
      hasAnimated.current = true;
      const duration = 1500;
      const startTime = performance.now();
      let frameId: number;
      const animate = (now: number) => {
        const elapsed = now - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        setCount(Math.round(eased * target));
        if (progress < 1) {
          frameId = requestAnimationFrame(animate);
        } else {
          setCount(target);
        }
      };
      frameId = requestAnimationFrame(animate);
      return () => cancelAnimationFrame(frameId);
    }
  }, [isInView, target]);

  // Fallback: if target is set but animation hasn't run after mount, show target directly
  useEffect(() => {
    if (target > 0 && hasAnimated.current) {
      setCount(target);
    }
  }, [target]);

  return <span ref={ref}>{count || target}{suffix}</span>;
}

/* ─── MAIN COMPONENT ─── */
export default function Formation() {
  usePageTitle("Académie — Formations marchés financiers");
  const { isAuthenticated } = useAuth();
  const { isPremium, canAccess } = useSubscription();
  const [, navigate] = useLocation();
  const { data: coursesData } = trpc.academy.listCourses.useQuery();

  const { data: nextLessonData } = trpc.academy.getNextLesson.useQuery(undefined, {
    enabled: isAuthenticated && canAccess("formation:lesson"),
  });

  const { data: allProgress } = trpc.academy.getAllProgress.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  useSEO(SEO_PAGES.formation);

  const totalCourses = (coursesData?.length && coursesData.length > 0) ? coursesData.length : ACADEMY.courseCount;
  const totalLessons = (coursesData?.length && coursesData.length > 0) ? coursesData.reduce((sum, c) => sum + c.lessonCount, 0) : ACADEMY.lessonCount;
  const totalMinutes = (coursesData?.length && coursesData.length > 0) ? coursesData.reduce((sum, c) => sum + c.estimatedMinutes, 0) : 2890;
  const totalCompleted = allProgress?.length || 0;
  const hasStarted = totalCompleted > 0;

  const PROFILES = [
    { title: "Débutant total", desc: "Vous n'avez jamais investi et voulez comprendre les bases.", modules: "M1 → M2 → M4", icon: Rocket, color: "#344453" },
    { title: "Investisseur autonome", desc: "Vous investissez déjà mais voulez structurer vos connaissances.", modules: "M3 → M4 → M5", icon: TrendingUp, color: "#2E7D5B" },
    { title: "Passionné macro", desc: "Vous voulez comprendre les cycles, la Fed, l'inflation.", modules: "M4 → M5 → M3", icon: Globe, color: "#1a3a50" },
    { title: "Focus actions & ETF", desc: "Vous voulez analyser et sélectionner des instruments.", modules: "M2 → M3 → M6", icon: BarChart3, color: "#D4A853" },
    { title: "Découvrir les options", desc: "Calls, puts et stratégies de couverture.", modules: "M1 → M2 → M6", icon: Target, color: "#344453" },
    { title: "Pratique suisse", desc: "Optimiser votre fiscalité et choisir un broker.", modules: "M1 → M7 → M2", icon: Landmark, color: "#344453" },
  ];

  return (
    <Layout>
      {/* ═══════════ IMMERSIVE HERO ═══════════ */}
      <section className="relative overflow-hidden min-h-[600px] lg:min-h-[700px]">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${IMAGES.hero})` }} />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1a2530]/95 via-[#344453]/85 to-[#344453]/70" />
        {/* Ambient glow */}
        <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-[#D4A853]/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#344453]/20 rounded-full blur-[100px]" />

        <div className="relative container py-20 lg:py-32">
          <PageBreadcrumb items={[{ label: "Académie" }]} className="mb-8" />
          <div className="grid lg:grid-cols-1 sm:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left — Text */}
            <div>
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/15 backdrop-blur-sm mb-8"
              >
                <GraduationCap size={16} className="text-[#D4A853]" />
                <span className="text-white/90 text-sm font-medium">Académie WMB</span>
                <span className="w-px h-4 bg-white/30" />
                <span className="text-[#D4A853] text-xs font-bold">Inclus dans Premium</span>
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.1 }}
                className="text-2xl md:text-4xl md:text-3xl md:text-5xl lg:text-3xl md:text-[56px] font-bold text-white leading-[1.08] mb-6"
              >
                Apprenez à comprendre{" "}
                <span className="bg-gradient-to-r from-[#D4A853] to-[#E8C97A] bg-clip-text text-transparent">
                  les marchés financiers.
                </span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.2 }}
                className="text-lg text-white/80 leading-relaxed mb-10 max-w-xl"
              >
                Une formation complète en {ACADEMY.moduleCount} modules pour maîtriser les fondamentaux
                de l'investissement. De la bourse aux options, de la macro à la fiscalité suisse.
                Pas de guru, pas de signaux — uniquement de la pédagogie.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.3 }}
                className="flex flex-col sm:flex-row gap-4 mb-10"
              >
                {isAuthenticated && canAccess("formation:lesson") ? (
                  <Link
                    href={hasStarted && nextLessonData && 'lesson' in nextLessonData ? `/formation/${nextLessonData.course?.slug}/${nextLessonData.lesson?.slug}` : "/ma-formation"}
                    className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/20 transition-all text-base"
                  >
                    {hasStarted ? <><Play size={18} /> Continuer ma formation</> : <><Rocket size={18} /> Accéder à ma formation</>}
                  </Link>
                ) : (
                  <Link
                    href="/pricing"
                    className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/20 transition-all text-base"
                  >
                    <Crown size={18} /> Commencer la formation
                  </Link>
                )}
                <a
                  href="#programme"
                  className="inline-flex items-center justify-center px-8 py-4 border border-white/25 text-white font-medium rounded-xl hover:bg-white/10 transition-colors text-base"
                >
                  Découvrir le programme
                </a>
              </motion.div>

              {/* Trust signals */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.7, delay: 0.5 }}
                className="flex flex-wrap items-center gap-x-6 gap-y-2 text-white/70 text-xs"
              >
                <span className="flex items-center gap-1.5"><Shield size={12} className="text-[#D4A853]" /> Éducatif uniquement</span>
                <span className="flex items-center gap-1.5"><Clock size={12} /> À votre rythme</span>
                <span className="flex items-center gap-1.5"><Zap size={12} /> Progression sauvegardée</span>
                <span className="flex items-center gap-1.5"><CheckCircle2 size={12} /> Module 1 gratuit</span>
              </motion.div>
            </div>

            {/* Right — Stats Card */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="hidden lg:block"
            >
              <div className="bg-white/[0.06] backdrop-blur-xl rounded-2xl border border-white/15 p-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-40 h-40 bg-[#D4A853]/5 rounded-full blur-3xl" />

                <div className="relative">
                  <div className="flex items-center gap-3 mb-8">
                    <div className="w-12 h-12 rounded-xl bg-[#D4A853]/15 flex items-center justify-center">
                      <GraduationCap size={22} className="text-[#D4A853]" />
                    </div>
                    <div>
                      <p className="text-white font-bold">Programme complet</p>
                      <p className="text-white/60 text-sm">Du débutant à l'autonomie</p>
                    </div>
                  </div>

                  {/* Stats grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                    {[
                      { value: 7, suffix: "", label: "Modules thématiques", icon: Layers, color: "#D4A853" },
                      { value: totalCourses || ACADEMY.courseCount, suffix: "", label: "Cours structurés", icon: BookOpen, color: "#2E7D5B" },
                      { value: totalLessons || ACADEMY.lessonCount, suffix: "+", label: "Leçons détaillées", icon: FileText, color: "#D4A853" },
                      { value: Math.round((totalMinutes || 2890) / 60), suffix: "h", label: "De contenu", icon: Clock, color: "#2E7D5B" },
                    ].map((stat) => (
                      <div key={stat.label} className="bg-white/[0.04] rounded-xl p-4 border border-white/10">
                        <stat.icon size={14} className="mb-2" style={{ color: stat.color }} />
                        <div className="text-2xl font-bold text-white">
                          <AnimatedCounter target={stat.value} suffix={stat.suffix} />
                        </div>
                        <div className="text-[11px] text-white/50 mt-0.5">{stat.label}</div>
                      </div>
                    ))}
                  </div>

                  {/* Module roadmap preview */}
                  <div className="space-y-2">
                    {[
                      { num: 1, title: "Les Fondamentaux", tag: "GRATUIT", tagColor: "bg-emerald-500/80" },
                      { num: 2, title: "Véhicules d'Investissement" },
                      { num: 3, title: "Analyses & Méthodes" },
                      { num: 4, title: "Indices & Indicateurs" },
                    ].map((m) => (
                      <div key={m.num} className="flex items-center gap-3 bg-white/[0.03] rounded-lg p-2.5 border border-white/[0.06]">
                        <div className="w-8 h-8 rounded-lg bg-[#D4A853]/10 flex items-center justify-center">
                          <span className="text-xs font-bold text-[#D4A853]">M{m.num}</span>
                        </div>
                        <p className="text-xs font-medium text-white/80 flex-1 truncate">{m.title}</p>
                        {m.tag && (
                          <span className={`px-2 py-0.5 ${m.tagColor} text-white text-[9px] font-bold rounded-full`}>{m.tag}</span>
                        )}
                      </div>
                    ))}
                    <p className="text-[11px] text-white/40 text-center pt-1">+ 3 modules avancés</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ═══════════ DISCLAIMER ═══════════ */}
      <section className="bg-white border-b border-[#E1E6EA]">
        <div className="container py-4">
          <div className="max-w-5xl mx-auto flex items-center gap-3 p-3 bg-amber-50/50 rounded-lg border border-amber-100/50">
            <Shield size={14} className="text-amber-500 shrink-0" />
            <p className="text-[11px] text-[#1E1E1E]/60 leading-relaxed">
              <strong>Contenu informatif et informatif uniquement.</strong> Ne constitue pas un conseil en investissement.
            </p>
          </div>
        </div>
      </section>

      {/* ═══════════ POURQUOI SE FORMER ═══════════ */}
      <section className="py-20 lg:py-28 bg-[#FAFAFA]">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-14">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#D4A853]/10 rounded-full text-[#8A6E18] text-xs font-bold mb-5"
              >
                <Lightbulb size={12} />
                Approche WMB
              </motion.div>
              <h2 className="text-3xl lg:text-2xl md:text-4xl font-bold text-[#344453] mb-4">
                Pourquoi se former avec WMB ?
              </h2>
              <p className="text-base text-[#1E1E1E]/60 max-w-2xl mx-auto leading-relaxed">
                Pas de guru, pas de signaux, pas de promesses. Uniquement de la pédagogie, de la méthode et des faits.
              </p>
            </div>

            <div className="grid md:grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { icon: Shield, title: "Neutre et objectif", desc: "Aucun conseil d'achat ou de vente. Uniquement de l'éducation, du contexte et des scénarios conditionnels SI/ALORS/SINON.", color: "#344453" },
                { icon: Globe, title: "Focus marchés US", desc: "Spécialisé sur les marchés américains : S&P 500, Nasdaq, Fed, macro US. Le plus grand marché du monde, décrypté.", color: "#2E7D5B" },
                { icon: Landmark, title: "Fiscalité suisse", desc: "Un module entier dédié à la pratique suisse : brokers, fiscalité, 3ème pilier, erreurs à éviter.", color: "#344453" },
                { icon: Target, title: "Scénarios conditionnels", desc: "Approche SI/ALORS/SINON pour développer votre pensée critique et votre autonomie de décision.", color: "#D4A853" },
                { icon: Brain, title: "Quiz & validation", desc: "Testez vos connaissances après chaque module avec des quiz interactifs. Score et progression en temps réel.", color: "#344453" },
                { icon: Compass, title: "Parcours guidé", desc: "Un chemin structuré du Module 1 au Module 7. La prochaine leçon est toujours recommandée automatiquement.", color: "#344453" },
              ].map((item, i) => (
                <motion.div
                  key={item.title}
                  custom={i}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  variants={fadeUp}
                  className="group relative overflow-hidden rounded-2xl bg-white border border-[#E1E6EA] hover:shadow-lg transition-all duration-300"
                >
                  <div className="h-1 w-full" style={{ backgroundColor: item.color }} />
                  <div className="p-7">
                    <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-5 transition-transform group-hover:scale-105" style={{ backgroundColor: `${item.color}08` }}>
                      <item.icon size={24} style={{ color: item.color }} />
                    </div>
                    <h3 className="text-base font-bold text-[#344453] mb-2">{item.title}</h3>
                    <p className="text-sm text-[#1E1E1E]/60 leading-relaxed">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ LE PROGRAMME — OVERVIEW SANS MODULES ═══════════ */}
      <section id="programme" className="py-20 lg:py-28 bg-white">
        <div className="container">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-16">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#344453]/5 rounded-full text-[#344453] text-xs font-bold mb-5"
              >
                <Layers size={12} />
                Le programme
              </motion.div>
              <h2 className="text-3xl lg:text-2xl md:text-4xl font-bold text-[#344453] mb-4">
                {ACADEMY.moduleCount} modules pour devenir autonome
              </h2>
              <p className="text-base text-[#1E1E1E]/60 max-w-2xl mx-auto leading-relaxed">
                Un parcours progressif et structuré, du vocabulaire de base jusqu'aux stratégies avancées.
                Chaque module s'appuie sur le précédent pour une compréhension solide.
              </p>
            </div>

            {/* Visual roadmap — just titles, no course lists */}
            <div>
              <div className="relative">
                {/* Vertical line — only covers module cards, not CTA */}
                <div className="absolute left-6 lg:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-[#D4A853] via-[#344453]/20 to-[#2E7D5B] hidden md:block" />

              <div className="space-y-8 md:space-y-12">
                {/* ── MODULE 1 — GRATUIT (en couleur) ── */}
                {(() => {
                  const m1 = { num: 1, title: "Les Fondamentaux", desc: "Comprendre le terrain de jeu : bourse, acteurs, prix, ordres. Les bases indispensables avant d'investir.", icon: TrendingUp, color: "#344453" };
                  return (
                    <motion.div
                      initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-40px" }} variants={fadeUp}
                      className="relative flex flex-col md:flex-row items-start gap-6"
                    >
                      <div className="hidden md:flex absolute left-1/2 -translate-x-1/2 w-12 h-12 rounded-full border-4 border-white items-center justify-center z-10 shadow-lg" style={{ backgroundColor: m1.color }}>
                        <span className="text-white font-bold text-sm">M1</span>
                      </div>
                      <div className="md:w-[calc(50%-40px)] md:pr-8">
                        <div className="bg-[#FAFAFA] rounded-2xl border-2 border-emerald-200 p-6 hover:shadow-lg transition-all group ring-1 ring-emerald-100">
                          <div className="flex items-start gap-4">
                            <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 bg-emerald-50 group-hover:scale-105 transition-transform">
                              <m1.icon size={22} className="text-emerald-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#344453]/10 text-[#344453] md:hidden">M1</span>
                                <h3 className="text-base font-bold text-[#344453]">{m1.title}</h3>
                                <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-700 text-[9px] font-bold rounded-full flex items-center gap-1"><CheckCircle2 size={10} /> GRATUIT</span>
                              </div>
                              <p className="text-sm text-[#1E1E1E]/60 leading-relaxed">{m1.desc}</p>
                              {canAccess("formation:lesson") ? (
                                <Link href="/dashboard/ma-formation" className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-600 hover:text-emerald-700">
                                  <Play size={12} /> Commencer le module <ArrowRight size={10} />
                                </Link>
                              ) : (
                                <Link href="/dashboard/ma-formation" className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-600 hover:text-emerald-700">
                                  <Play size={12} /> Commencer gratuitement <ArrowRight size={10} />
                                </Link>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="hidden md:block md:w-[calc(50%-40px)]" />
                    </motion.div>
                  );
                })()}

                {/* ── MODULES 2-3 — VISIBLES SANS BADGE PREMIUM CÔTÉ PUBLIC ── */}
                {[
                  { num: 2, title: "Véhicules d'Investissement", desc: "Actions, ETF, obligations, crypto — quel instrument pour quel profil et quel horizon.", icon: Briefcase, color: "#2E7D5B" },
                  { num: 3, title: "Analyses & Méthodes", desc: "Chandeliers, supports/résistances, bilans financiers, ratios — décider avec méthode.", icon: BarChart3, color: "#1a3a50" },
                ].map((m, i) => (
                  <motion.div
                    key={m.num} custom={i + 1} initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-40px" }} variants={fadeUp}
                    className={`relative flex flex-col md:flex-row items-start gap-6 ${(i + 1) % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}
                  >
                    <div className="hidden md:flex absolute left-1/2 -translate-x-1/2 w-12 h-12 rounded-full border-4 border-white items-center justify-center z-10 shadow-lg" style={{ backgroundColor: m.color }}>
                      <span className="text-white font-bold text-sm">M{m.num}</span>
                    </div>
                    <div className={`md:w-[calc(50%-40px)] ${(i + 1) % 2 === 0 ? "md:pr-8" : "md:pl-8"}`}>
                      <div className="bg-[#FAFAFA] rounded-2xl border border-[#E1E6EA] p-6 hover:shadow-lg transition-all group relative">
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform" style={{ backgroundColor: `${m.color}10` }}>
                            <m.icon size={22} style={{ color: m.color }} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full md:hidden" style={{ backgroundColor: `${m.color}15`, color: m.color }}>M{m.num}</span>
                              <h3 className="text-base font-bold text-[#344453]">{m.title}</h3>
                              {isAuthenticated && !canAccess("formation:lesson") && (
                                <span className="px-2 py-0.5 bg-[#D4A853]/10 text-[#D4A853] text-[9px] font-bold rounded-full flex items-center gap-1"><Crown size={8} /> PREMIUM</span>
                              )}
                            </div>
                            <p className="text-sm text-[#1E1E1E]/60 leading-relaxed">{m.desc}</p>
                            <Link href={isAuthenticated ? "/pricing" : "/register"} className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-[#344453] hover:text-[#2E7D5B]">
                              En savoir plus <ArrowRight size={10} />
                            </Link>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="hidden md:block md:w-[calc(50%-40px)]" />
                  </motion.div>
                ))}
              </div>

              {/* ═══════════ MODULES 4-7 — VISIBLES POUR TOUS ═══════════ */}
              {!canAccess("formation:lesson") && (
                <>
                <div className="relative">
                  {/* Vertical line continuation for modules 4-7 */}
                  <div className="absolute left-6 lg:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-[#344453]/20 to-[#2E7D5B] hidden md:block" />
                <div className="space-y-8 md:space-y-12 mt-8">
                  {[
                    { num: 4, title: "Indices & Indicateurs", desc: "S&P 500, VIX, taux directeurs, DXY, CPI, NFP — les baromètres des marchés.", icon: Globe, color: "#D4A853" },
                    { num: 5, title: "Les Options", desc: "Calls, puts, grecques, stratégies de couverture — de la théorie à la pratique.", icon: Target, color: "#B0413E" },
                    { num: 6, title: "Histoire & Culture", desc: "1929, 2000, 2008, COVID — les leçons du passé pour mieux naviguer le présent.", icon: Landmark, color: "#7A6A5A" },
                    { num: 7, title: "Investissement Pratique", desc: "Broker, portefeuille, gestion du risque, fiscalité suisse — passer à l'action.", icon: Rocket, color: "#2E7D5B" },
                  ].map((m, i) => (
                    <motion.div
                      key={m.num} custom={i + 3} initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-40px" }} variants={fadeUp}
                      className={`relative flex flex-col md:flex-row items-start gap-6 ${(i + 3) % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}
                    >
                      <div className="hidden md:flex absolute left-1/2 -translate-x-1/2 w-12 h-12 rounded-full border-4 border-white items-center justify-center z-10 shadow-lg" style={{ backgroundColor: m.color }}>
                        <span className="text-white font-bold text-sm">M{m.num}</span>
                      </div>
                      <div className={`md:w-[calc(50%-40px)] ${(i + 3) % 2 === 0 ? "md:pr-8" : "md:pl-8"}`}>
                        <div className="bg-[#FAFAFA] rounded-2xl border border-[#E1E6EA] p-6 hover:shadow-lg transition-all group relative">
                          <div className="flex items-start gap-4">
                            <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform" style={{ backgroundColor: `${m.color}10` }}>
                              <m.icon size={22} style={{ color: m.color }} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full md:hidden" style={{ backgroundColor: `${m.color}15`, color: m.color }}>M{m.num}</span>
                                <h3 className="text-base font-bold text-[#344453]">{m.title}</h3>
                                {isAuthenticated && (
                                  <span className="px-2 py-0.5 bg-[#D4A853]/10 text-[#D4A853] text-[9px] font-bold rounded-full flex items-center gap-1"><Crown size={8} /> PREMIUM</span>
                                )}
                              </div>
                              <p className="text-sm text-[#1E1E1E]/60 leading-relaxed">{m.desc}</p>
                              <Link href={isAuthenticated ? "/pricing" : "/register"} className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-[#344453] hover:text-[#2E7D5B]">
                                En savoir plus <ArrowRight size={10} />
                              </Link>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="hidden md:block md:w-[calc(50%-40px)]" />
                    </motion.div>
                  ))}
                </div>
                </div>

                  {/* CTA Premium subtil — OUTSIDE timeline div */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="text-center mt-8 py-10 bg-gradient-to-r from-[#D4A853]/5 via-[#D4A853]/10 to-[#D4A853]/5 rounded-2xl border border-[#D4A853]/15"
                  >
                    {isAuthenticated && <Crown size={28} className="text-[#D4A853] mx-auto mb-4" />}
                    <h3 className="text-xl font-bold text-[#344453] mb-2">{isAuthenticated ? "Formation complète — 7 modules" : "Envie d'aller plus loin ?"}</h3>
                    <p className="text-sm text-[#1E1E1E]/60 max-w-md mx-auto mb-6">
                      {isAuthenticated
                        ? "Accédez à l'intégralité de la formation, des quiz et des outils avec un abonnement Premium."
                        : "Créez votre compte pour accéder à la formation complète, aux quiz et à tous les outils WMB."}
                    </p>
                    <div className="flex items-center justify-center gap-3 text-xs text-[#1E1E1E]/40 mb-6">
                      <span className="flex items-center gap-1"><BookOpen size={12} /> 7 modules</span>
                      <span>•</span>
                      <span className="flex items-center gap-1"><Clock size={12} /> 45+ leçons</span>
                      <span>•</span>
                      <span className="flex items-center gap-1"><FileText size={12} /> Quiz inclus</span>
                    </div>
                    <Link
                      href={isAuthenticated ? "/pricing" : "/register"}
                      className="inline-flex items-center gap-2.5 px-8 py-3.5 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-xl hover:shadow-[#D4A853]/20 transition-all"
                    >
                      {isAuthenticated ? <><Crown size={16} /> Voir les offres Premium</> : <>Commencer maintenant <ArrowRight size={16} /></>}
                    </Link>
                  </motion.div>
                </>
              )}

              {/* Si premium : afficher tous les modules normalement */}
              {canAccess("formation:lesson") && (
                <div className="relative">
                  {/* Vertical line continuation for premium modules 4-7 */}
                  <div className="absolute left-6 lg:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-[#344453]/20 to-[#2E7D5B] hidden md:block" />
                <div className="space-y-8 md:space-y-12 mt-8">
                  {[
                    { num: 4, title: "Indices & Indicateurs", desc: "S&P 500, VIX, taux directeurs, DXY, CPI, NFP — les baromètres des marchés.", icon: Globe, color: "#D4A853" },
                    { num: 5, title: "Les Options", desc: "Calls, puts, grecques, stratégies de couverture — de la théorie à la pratique.", icon: Target, color: "#B0413E" },
                    { num: 6, title: "Histoire & Culture", desc: "1929, 2000, 2008, COVID — les leçons du passé pour mieux naviguer le présent.", icon: Landmark, color: "#7A6A5A" },
                    { num: 7, title: "Investissement Pratique", desc: "Broker, portefeuille, gestion du risque, fiscalité suisse — passer à l'action.", icon: Rocket, color: "#2E7D5B" },
                  ].map((m, i) => (
                    <motion.div
                      key={m.num} custom={i + 3} initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-40px" }} variants={fadeUp}
                      className={`relative flex flex-col md:flex-row items-start gap-6 ${(i + 3) % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}
                    >
                      <div className="hidden md:flex absolute left-1/2 -translate-x-1/2 w-12 h-12 rounded-full border-4 border-white items-center justify-center z-10 shadow-lg" style={{ backgroundColor: m.color }}>
                        <span className="text-white font-bold text-sm">M{m.num}</span>
                      </div>
                      <div className={`md:w-[calc(50%-40px)] ${(i + 3) % 2 === 0 ? "md:pr-8" : "md:pl-8"}`}>
                        <div className="bg-[#FAFAFA] rounded-2xl border border-[#E1E6EA] p-6 hover:shadow-lg transition-all group">
                          <div className="flex items-start gap-4">
                            <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform" style={{ backgroundColor: `${m.color}10` }}>
                              <m.icon size={22} style={{ color: m.color }} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full md:hidden" style={{ backgroundColor: `${m.color}15`, color: m.color }}>M{m.num}</span>
                                <h3 className="text-base font-bold text-[#344453]">{m.title}</h3>
                              </div>
                              <p className="text-sm text-[#1E1E1E]/60 leading-relaxed">{m.desc}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="hidden md:block md:w-[calc(50%-40px)]" />
                    </motion.div>
                  ))}
                </div>
                </div>
              )}
              </div>
            </div>

            {/* CTA after roadmap */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mt-16"
            >
              {canAccess("formation:lesson") ? (
                <Link
                  href="/dashboard/ma-formation"
                  className="inline-flex items-center gap-2 px-8 py-4 bg-[#344453] text-white font-bold rounded-xl hover:bg-[#344453]/90 transition-all"
                >
                  <Play size={16} /> Accéder à ma formation <ArrowRight size={14} />
                </Link>
              ) : null}
            </motion.div>
          </div>
        </div>
      </section>

      {/* ═══════════ CE QUE VOUS SAUREZ FAIRE ═══════════ */}
      <section className="py-20 lg:py-28 bg-[#FAFAFA]">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-14">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#D4A853]/10 rounded-full text-[#8A6E18] text-xs font-bold mb-5"
              >
                <Award size={12} />
                Compétences acquises
              </motion.div>
              <h2 className="text-3xl lg:text-2xl md:text-4xl font-bold text-[#344453] mb-4">
                Ce que vous saurez faire
              </h2>
              <p className="text-base text-[#1E1E1E]/60 max-w-2xl mx-auto leading-relaxed">
                À la fin de la formation, vous aurez les compétences concrètes pour analyser,
                comprendre et naviguer les marchés financiers en toute autonomie.
              </p>
            </div>

            <motion.div
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="grid sm:grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {[
                { icon: Activity, title: "Lire un graphique", desc: "Identifier tendances, supports, résistances et patterns de prix sur un graphique en chandelier.", color: "#344453" },
                { icon: BarChart, title: "Analyser un bilan", desc: "Décrypter les états financiers d'une entreprise et évaluer sa santé financière.", color: "#2E7D5B" },
                { icon: Globe, title: "Suivre la macro", desc: "Interpréter les données économiques clés : inflation, emploi, taux directeurs, PIB.", color: "#1a3a50" },
                { icon: Shield, title: "Gérer le risque", desc: "Dimensionner vos positions, placer des stops et protéger votre capital.", color: "#D4A853" },
                { icon: PieChart, title: "Construire un portefeuille", desc: "Diversifier intelligemment entre classes d'actifs, secteurs et géographies.", color: "#344453" },
                { icon: Brain, title: "Maîtriser vos émotions", desc: "Identifier les biais cognitifs et développer une discipline d'investissement.", color: "#344453" },
                { icon: Landmark, title: "Comprendre les cycles", desc: "Reconnaître les phases de marché et adapter votre stratégie en conséquence.", color: "#344453" },
                { icon: Target, title: "Utiliser les options", desc: "Comprendre calls, puts et grecques pour couvrir ou générer des revenus.", color: "#2E7D5B" },
                { icon: Rocket, title: "Passer à l'action", desc: "Ouvrir un compte, construire un portefeuille, gérer la fiscalité suisse.", color: "#344453" },
              ].map((item, i) => (
                <motion.div
                  key={item.title}
                  custom={i}
                  variants={fadeUp}
                  className="relative overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white hover:shadow-lg transition-all group"
                >
                  <div className="h-1 w-full" style={{ backgroundColor: item.color }} />
                  <div className="p-6">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 group-hover:scale-105 transition-transform" style={{ backgroundColor: `${item.color}08` }}>
                      <item.icon size={22} style={{ color: item.color }} />
                    </div>
                    <h3 className="text-base font-bold text-[#344453] mb-2">{item.title}</h3>
                    <p className="text-sm text-[#1E1E1E]/60 leading-relaxed">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* ═══════════ NEWSLETTER + FORMATION = DUO GAGNANT ═══════════ */}
      <section className="py-20 lg:py-28 bg-gradient-to-br from-[#344453] via-[#3d5060] to-[#344453]">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-1 sm:grid-cols-2 gap-12 items-center">
              <div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#D4A853]/10 rounded-full text-[#D4A853] text-xs font-bold mb-6"
                >
                  <Zap size={12} />
                  Le duo gagnant
                </motion.div>
                <h2 className="text-3xl lg:text-2xl md:text-4xl font-bold text-white leading-tight mb-5">
                  La newsletter met en pratique{" "}
                  <span className="text-[#D4A853]">ce que vous apprenez</span>
                </h2>
                <p className="text-base text-white/75 leading-relaxed mb-8">
                  La formation vous donne les fondations. La newsletter hebdomadaire vous montre
                  comment ces concepts s'appliquent en temps réel sur les marchés.
                </p>
                <div className="space-y-5">
                  {[
                    { title: "Formation", desc: "Apprenez les concepts : indices, analyse technique, macro, options, fiscalité suisse...", color: "#D4A853", icon: GraduationCap },
                    { title: "Newsletter", desc: "Voyez ces concepts en action chaque dimanche sur les marchés US.", color: "#2E7D5B", icon: FileText },
                    { title: "Résultat", desc: "Vous comprenez mieux, plus vite, et vous développez votre autonomie.", color: "#fff", icon: Rocket },
                  ].map((item) => (
                    <div key={item.title} className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${item.color}15` }}>
                        <item.icon size={18} style={{ color: item.color }} />
                      </div>
                      <div>
                        <span className="text-sm font-bold text-white">{item.title}</span>
                        <p className="text-xs text-white/65 leading-relaxed mt-0.5">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="bg-white/[0.04] border border-white/[0.08] rounded-2xl p-8 backdrop-blur-sm"
              >
                <div className="text-center">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#D4A853]/20 to-[#D4A853]/5 flex items-center justify-center mx-auto mb-6">
                    <Lightbulb size={36} className="text-[#D4A853]" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">Exemple concret</h3>
                  <div className="bg-white/[0.03] rounded-xl p-5 border border-white/10 mb-6 text-left">
                    <p className="text-xs text-white/80 leading-relaxed">
                      <span className="text-white font-bold">Module 4 :</span> Vous apprenez ce qu'est le VIX, comment il se calcule, et ce qu'il signifie pour le sentiment du marché.
                    </p>
                    <div className="my-3 border-t border-white/10" />
                    <p className="text-xs text-white/80 leading-relaxed">
                      <span className="text-white font-bold">Newsletter dimanche :</span> "Le VIX est à 14.2, sous sa moyenne 200 jours. SI le VIX reste sous 16, ALORS le marché reste en mode risk-on. SINON, surveiller un retour vers les 20."
                    </p>
                  </div>
                  <Link
                    href="/newsletter"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-xl hover:shadow-[#D4A853]/20 transition-all text-sm"
                  >
                    Découvrir la newsletter <ArrowRight size={14} />
                  </Link>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ COMMENT ÇA FONCTIONNE ═══════════ */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="container">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-16">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#344453]/5 rounded-full text-[#344453] text-xs font-bold mb-5"
              >
                <Zap size={12} />
                Déroulement
              </motion.div>
              <h2 className="text-3xl lg:text-2xl md:text-4xl font-bold text-[#344453] mb-4">
                Comment ça fonctionne
              </h2>
              <p className="text-base text-[#1E1E1E]/60 max-w-xl mx-auto leading-relaxed">
                Un parcours pensé pour être simple, progressif et efficace.
              </p>
            </div>

            <div className="grid md:grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { step: "01", icon: Rocket, title: "Débutez le parcours", desc: "Commencez par le Module 1 gratuit. Chaque module s'appuie sur le précédent.", color: "#344453" },
                { step: "02", icon: BookMarked, title: "Apprenez & notez", desc: "Chaque leçon dure 5 à 15 min. Prenez des notes directement dans l'interface.", color: "#2E7D5B" },
                { step: "03", icon: Brain, title: "Testez vos acquis", desc: "Après chaque module, passez le quiz pour valider vos connaissances.", color: "#D4A853" },
                { step: "04", icon: CheckCircle2, title: "Progressez", desc: "Votre progression est sauvegardée. Reprenez là où vous vous êtes arrêté.", color: "#344453" },
              ].map((item, i) => (
                <motion.div
                  key={item.step}
                  custom={i}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  variants={fadeUp}
                  className="relative overflow-hidden rounded-2xl border border-[#E1E6EA] bg-[#FAFAFA] hover:shadow-lg transition-all"
                >
                  <div className="h-1.5 w-full" style={{ backgroundColor: item.color }} />
                  <div className="p-6 relative">
                    <span className="text-3xl md:text-5xl font-bold absolute top-2 right-3" style={{ color: `${item.color}06` }}>{item.step}</span>
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4" style={{ backgroundColor: `${item.color}08` }}>
                      <item.icon size={22} style={{ color: item.color }} />
                    </div>
                    <h3 className="text-sm font-bold text-[#344453] mb-2">{item.title}</h3>
                    <p className="text-xs text-[#1E1E1E]/60 leading-relaxed">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ FONCTIONNALITÉS INCLUSES ═══════════ */}
      <section className="py-20 lg:py-28 bg-[#FAFAFA]">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-14">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#344453]/5 rounded-full text-[#344453] text-xs font-bold mb-5"
              >
                <Sparkles size={12} />
                Fonctionnalités incluses
              </motion.div>
              <h2 className="text-3xl lg:text-2xl md:text-4xl font-bold text-[#344453] mb-4">
                Tout ce dont vous avez besoin
              </h2>
              <p className="text-base text-[#1E1E1E]/60 max-w-xl mx-auto leading-relaxed">
                Une plateforme d'apprentissage complète, pensée pour votre progression.
              </p>
            </div>

            <div className="grid sm:grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { icon: Play, title: "Parcours guidé A-Z", desc: "Suivez un chemin structuré du Module 1 au Module 7. La prochaine leçon est recommandée automatiquement.", color: "#344453" },
                { icon: StickyNote, title: "Notes personnelles", desc: "Prenez des notes directement dans chaque leçon. Sauvegarde automatique dans votre espace.", color: "#2E7D5B" },
                { icon: Trophy, title: "Suivi de progression", desc: "Visualisez votre avancement par module, par cours et globalement.", color: "#D4A853" },
                { icon: Timer, title: "Timer de lecture", desc: "Un chronomètre intégré mesure votre temps de lecture pour suivre votre investissement.", color: "#344453" },
                { icon: Download, title: "Export notes PDF", desc: "Téléchargez toutes vos notes structurées par module, avec couverture et sommaire.", color: "#344453" },
                { icon: Brain, title: "Quiz interactifs", desc: "30 questions aléatoires par thème, score instantané et suivi de progression.", color: "#344453" },
              ].map((item, i) => (
                <motion.div
                  key={item.title}
                  custom={i}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  variants={fadeUp}
                  className="relative overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white hover:shadow-lg transition-all group"
                >
                  <div className="h-1 w-full" style={{ backgroundColor: item.color }} />
                  <div className="p-7">
                    <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-5 group-hover:scale-105 transition-transform" style={{ backgroundColor: `${item.color}08` }}>
                      <item.icon size={24} style={{ color: item.color }} />
                    </div>
                    <h3 className="text-base font-bold text-[#344453] mb-2">{item.title}</h3>
                    <p className="text-sm text-[#1E1E1E]/60 leading-relaxed">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ PARCOURS PAR PROFIL ═══════════ */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="container">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-14">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="inline-flex items-center gap-2 px-4 py-1.5 bg-[#344453]/5 rounded-full text-[#344453] text-xs font-bold mb-5"
              >
                <Compass size={12} />
                Parcours recommandés
              </motion.div>
              <h2 className="text-3xl lg:text-2xl md:text-4xl font-bold text-[#344453] mb-4">
                Quel profil vous correspond ?
              </h2>
              <p className="text-base text-[#1E1E1E]/60 max-w-xl mx-auto leading-relaxed">
                Choisissez votre point de départ selon votre niveau et vos objectifs.
              </p>
            </div>

            <div className="grid sm:grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {PROFILES.map((p, i) => (
                <motion.div
                  key={p.title}
                  custom={i}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  variants={fadeUp}
                  className="rounded-2xl border border-[#E1E6EA] bg-[#FAFAFA] p-6 hover:shadow-lg transition-all group"
                >
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 group-hover:scale-105 transition-transform" style={{ backgroundColor: `${p.color}10` }}>
                    <p.icon size={22} style={{ color: p.color }} />
                  </div>
                  <h3 className="text-base font-bold text-[#344453] mb-1">{p.title}</h3>
                  <p className="text-sm text-[#1E1E1E]/60 leading-relaxed mb-3">{p.desc}</p>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-full" style={{ backgroundColor: `${p.color}10`, color: p.color }}>
                      {p.modules}
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ CHIFFRES CLÉS ═══════════ */}
      <section className="py-20 lg:py-28 bg-[#F4F5F5]">
        <div className="container">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-14">
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#8A6E18] mb-4 block">En chiffres</span>
              <h2 className="text-3xl lg:text-2xl md:text-4xl font-bold text-[#344453] mb-4">La formation WMB en un coup d'œil</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { value: 7, suffix: "", label: "Modules", desc: "Des fondamentaux aux options", icon: Layers },
                { value: totalCourses || ACADEMY.courseCount, suffix: "", label: "Cours", desc: "Structurés et progressifs", icon: BookOpen },
                { value: totalLessons || ACADEMY.lessonCount, suffix: "+", label: "Leçons", desc: "5 à 15 min chacune", icon: FileText },
                { value: Math.round((totalMinutes || 2890) / 60), suffix: "h+", label: "De contenu", desc: "À votre rythme", icon: Clock },
              ].map((stat) => (
                <div key={stat.label} className="bg-white border border-[#E1E6EA] rounded-2xl p-6 text-center hover:shadow-md transition-all">
                  <stat.icon size={18} className="text-[#8A6E18] mx-auto mb-3" />
                  <div className="text-2xl md:text-4xl font-bold text-[#8A6E18] mb-2">
                    <AnimatedCounter target={stat.value} suffix={stat.suffix} />
                  </div>
                  <div className="text-sm font-semibold text-[#344453] mb-1">{stat.label}</div>
                  <p className="text-[11px] text-[#1E1E1E]/50">{stat.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ FAQ ═══════════ */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#8A6E18] mb-4 block">Questions fréquentes</span>
              <h2 className="text-3xl lg:text-2xl md:text-4xl font-bold text-[#344453] mb-3">Tout savoir sur la formation</h2>
            </div>
            <div className="space-y-3">
              {[
                { q: "Faut-il des connaissances préalables ?", a: "Non. Le Module 1 commence par les bases absolues. Aucun prérequis n'est nécessaire. Le parcours est conçu pour être progressif et accessible à tous." },
                { q: "Combien de temps faut-il pour terminer ?", a: `À raison de ${ACADEMY.dailyPace}, comptez environ ${ACADEMY.completionTime} pour parcourir l'intégralité des ${ACADEMY.moduleCount} modules. Votre progression est sauvegardée automatiquement.` },
                { q: "Est-ce que la formation donne des conseils d'investissement ?", a: "Non. La formation est strictement éducative. Elle vous donne les outils pour comprendre les marchés par vous-même, sans aucun conseil d'achat ou de vente." },
                { q: "La formation est-elle mise à jour ?", a: "Oui. Le contenu est mis à jour en continu. De nouvelles leçons et cours sont ajoutés régulièrement." },
                { q: "Puis-je y accéder sur mobile ?", a: "Oui. La plateforme est responsive et optimisée pour smartphone, tablette et ordinateur. Vos notes et progression sont synchronisées." },
                { q: "Quelle différence avec la newsletter ?", a: "La newsletter est un résumé hebdomadaire des marchés. La formation est un parcours structuré pour apprendre les fondamentaux. Les deux sont complémentaires." },
                { q: "Puis-je exporter mes notes ?", a: "Oui. Téléchargez toutes vos notes structurées par module, avec couverture et sommaire automatiques." },
                { q: "Y a-t-il des quiz ?", a: "Oui. Chaque module dispose de quiz interactifs avec 30 questions aléatoires. Score instantané et suivi de progression." },
              ].map((item) => (
                <details key={item.q} className="group bg-[#FAFAFA] rounded-xl border border-[#E1E6EA] overflow-hidden hover:shadow-md transition-all">
                  <summary className="flex items-center justify-between p-5 cursor-pointer list-none">
                    <span className="text-sm font-semibold text-[#344453] pr-4">{item.q}</span>
                    <ChevronDown size={16} className="text-[#1E1E1E]/50 group-open:rotate-180 transition-transform shrink-0" />
                  </summary>
                  <div className="px-5 pb-5">
                    <p className="text-sm text-[#1E1E1E]/60 leading-relaxed">{item.a}</p>
                  </div>
                </details>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ CROSS-SELL OUTILS ═══════════ */}
      <section className="py-20 lg:py-28 bg-[#FAFAFA]">
        <div className="container">
          <div className="max-w-6xl mx-auto text-center">
            <h2 className="text-3xl lg:text-2xl md:text-4xl font-bold text-[#344453] mb-4">
              Allez plus loin avec les outils WMB
            </h2>
            <p className="text-base text-[#1E1E1E]/60 max-w-xl mx-auto mb-14 leading-relaxed">
              Appliquez ce que vous apprenez avec nos outils concrets.
            </p>
            <div className="grid sm:grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { href: "/indicateurs-tendance", icon: TrendingUp, title: "Indicateurs de Tendance", desc: `${INDICATORS.count} indicateurs techniques expliqués.`, color: "#C4A052", cta: "Apprendre" },
                { href: "/glossaire", icon: BookOpen, title: "Glossaire Premium", desc: `${GLOSSARY.termLabel} termes financiers expliqués.`, color: "#344453", cta: "Découvrir" },
                { href: "/thematiques", icon: Target, title: "Thématiques", desc: `${THEMES.countLabel} thématiques sectorielles.`, color: "#D4A853", cta: "Explorer" },
                { href: "/quiz", icon: Brain, title: "Quiz Interactifs", desc: "Testez vos connaissances par thème.", color: "#2E7D5B", cta: "Jouer" },
              ].map((item) => (
                <Link key={item.href} href={item.href} className="group">
                  <div className="relative overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white hover:shadow-xl transition-all text-left h-full">
                    <div className="h-1.5 w-full" style={{ backgroundColor: item.color }} />
                    <div className="p-6">
                      <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-5 group-hover:scale-105 transition-transform" style={{ backgroundColor: `${item.color}10` }}>
                        <item.icon size={22} style={{ color: item.color }} />
                      </div>
                      <h3 className="text-sm font-bold text-[#344453] mb-2">{item.title}</h3>
                      <p className="text-sm text-[#1E1E1E]/60 mb-4">{item.desc}</p>
                      <span className="text-sm font-medium flex items-center gap-1 group-hover:gap-2 transition-all" style={{ color: item.color }}>
                        {item.cta} <ChevronRight size={14} />
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ LEAD MAGNET ═══════════ */}
      {!isAuthenticated && (
        <section className="py-12 bg-gradient-to-r from-[#344453] to-[#2a3845]">
          <div className="container">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-[#D4A853]/15 flex items-center justify-center shrink-0">
                  <Sparkles size={24} className="text-[#D4A853]" />
                </div>
                <div>
                  <p className="text-white font-bold text-lg">Recevez le dernier Thème du Mois gratuitement</p>
                  <p className="text-white/65 text-sm">Une analyse sectorielle approfondie de 20+ slides, offerte à votre inscription.</p>
                </div>
              </div>
              <Link
                href="/register"
                className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/20 transition-all text-base whitespace-nowrap overflow-hidden text-ellipsis"
              >
                Recevoir le Thème du Mois gratuit <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* ═══════════ FINAL CTA ═══════════ */}
      {!canAccess("formation:lesson") && (
        <section className="relative overflow-hidden py-24 lg:py-32">
          <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${IMAGES.success})` }} />
          <div className="absolute inset-0 bg-gradient-to-br from-[#1a2530]/90 via-[#344453]/85 to-[#2a3845]/80" />
          <div className="relative container text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              {isAuthenticated && <Crown size={40} className="text-[#D4A853] mx-auto mb-6" />}
              <h2 className="text-3xl lg:text-3xl md:text-5xl font-bold text-white mb-6">
                Prêt à maîtriser les marchés ?
              </h2>
              <p className="text-lg text-white/70 max-w-xl mx-auto mb-6 leading-relaxed">
                {isAuthenticated
                  ? `Rejoignez la formation WMB et accédez à ${totalCourses || ACADEMY.courseCount} cours, ${totalLessons || ACADEMY.lessonCount}+ leçons, la newsletter hebdomadaire et tous les outils — à partir de ${PRICING.currency} ${PRICING.plans.premium.price}/mois.`
                  : `Accédez à ${totalCourses || ACADEMY.courseCount} cours, ${totalLessons || ACADEMY.lessonCount}+ leçons et tous les outils pour comprendre les marchés financiers.`}
              </p>
              <p className="text-white/50 text-xs max-w-lg mx-auto mb-10">
                Contenu informatif et informatif uniquement. Ne constitue pas un conseil en investissement.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  href="/pricing"
                  className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/30 transition-all text-base"
                >
                  Voir les offres <ArrowRight size={16} />
                </Link>
                <Link
                  href="/extrait"
                  className="inline-flex items-center gap-3 px-8 py-4 border border-white/20 text-white/70 font-medium rounded-xl hover:bg-white/10 transition-all text-base"
                >
                  Lire un extrait gratuit
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      )}
    </Layout>
  );
}
