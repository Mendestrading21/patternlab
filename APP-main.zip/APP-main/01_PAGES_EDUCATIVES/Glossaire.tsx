import { usePageTitle } from "@/hooks/usePageTitle";
/**
 * Glossaire V20 Premium — Learning System
 * Modes: Fiches | Flashcards | Quiz | Parcours | Progression
 * 100% informatif — Aucun conseil — Conformité WMB
 * Design: Premium trading terminal aesthetic, immersive cards, rich interactions
 */
import Layout from "@/components/Layout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useSubscription } from "@/hooks/useSubscription";
import PremiumGate from "@/components/PremiumGate";
import { Link } from "wouter";
import { useState } from "react";
import { Crown, Lock as LockIcon } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search, BookOpen, Brain, Target, Route, Trophy,
  ChevronRight, ChevronLeft, X, Check, RotateCcw,
  Star, Zap, Shield, BarChart3, TrendingUp, AlertTriangle,
  GraduationCap, Clock, Filter, ArrowRight,
  Layers, Activity, Eye, Award,
  CheckCircle, XCircle, Play,
  Sparkles, ArrowUpRight,
} from "lucide-react";
import { useSEO } from "@/hooks/useSEO";
import { SEO_PAGES } from "@/lib/seoConfig";
import { ACADEMY, GLOSSARY, INDICATORS, THEMES } from "@shared/siteConfig";
import { HERO_IMAGES } from "@/lib/heroImages";
import PageBreadcrumb from "@/components/PageBreadcrumb";
import GlossaryWordOfDay from "@/components/GlossaryWordOfDay";

// ═══════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════
export type GlossaryTabMode = "fiches" | "flashcards" | "quiz" | "parcours" | "progression";
type TabMode = GlossaryTabMode;

export interface GlossaryTerm {
  id: number;
  term: string;
  slug: string;
  definition: string;
  level: string;
  category: string;
  relatedCourseId: number | null;
}

// ═══════════════════════════════════════════════════════════
// CONSTANTS — DESIGN SYSTEM
// ═══════════════════════════════════════════════════════════
export const CATEGORY_LABELS: Record<string, string> = {
  marche: "Marché",
  analyse: "Analyse",
  instrument: "Instruments",
  risque: "Risque",
  ordre: "Ordres",
  indicateur: "Indicateurs",
};

export const CATEGORY_ICONS: Record<string, any> = {
  marche: TrendingUp,
  analyse: BarChart3,
  instrument: Layers,
  risque: Shield,
  ordre: Zap,
  indicateur: Activity,
};

export const CATEGORY_COLORS: Record<string, { bg: string; text: string; accent: string; gradient: string; light: string }> = {
  marche: { bg: "#F4F5F5", text: "#344453", accent: "#344453", gradient: "from-blue-500/10 via-blue-500/5 to-transparent", light: "#F4F5F5" },
  analyse: { bg: "#F4F5F5", text: "#344453", accent: "#344453", gradient: "from-violet-500/10 via-violet-500/5 to-transparent", light: "#F4F5F5" },
  instrument: { bg: "#f0f7f4", text: "#2E7D5B", accent: "#2E7D5B", gradient: "from-emerald-500/10 via-emerald-500/5 to-transparent", light: "#f0f7f4" },
  risque: { bg: "#fdf2f1", text: "#B0413E", accent: "#B0413E", gradient: "from-red-500/10 via-red-500/5 to-transparent", light: "#fdf2f1" },
  ordre: { bg: "#faf6ed", text: "#C4A052", accent: "#C4A052", gradient: "from-amber-500/10 via-amber-500/5 to-transparent", light: "#faf6ed" },
  indicateur: { bg: "#F4F5F5", text: "#344453", accent: "#344453", gradient: "from-cyan-500/10 via-cyan-500/5 to-transparent", light: "#F4F5F5" },
};

export const LEVEL_LABELS: Record<string, string> = {
  debutant: "Débutant",
  intermediaire: "Intermédiaire",
  avance: "Avancé",
};

export const LEVEL_CONFIG: Record<string, { color: string; bg: string; icon: string; dots: number }> = {
  debutant: { color: "#2E7D5B", bg: "#f0f7f4", icon: "●○○", dots: 1 },
  intermediaire: { color: "#C4A052", bg: "#faf6ed", icon: "●●○", dots: 2 },
  avance: { color: "#B0413E", bg: "#fdf2f1", icon: "●●●", dots: 3 },
};

export const TAB_CONFIG: { key: GlossaryTabMode; label: string; icon: any; desc: string }[] = [
  { key: "fiches", label: "Fiches", icon: BookOpen, desc: `${GLOSSARY.termLabel} termes` },
  { key: "flashcards", label: "Flashcards", icon: Brain, desc: "Réviser" },
  { key: "quiz", label: "Quiz", icon: Target, desc: "Tester" },
  { key: "parcours", label: "Parcours", icon: Route, desc: "Guidé" },
  { key: "progression", label: "Progression", icon: Trophy, desc: "Stats" },
];

// ═══════════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════════
export default function Glossaire() {
  usePageTitle("Glossaire — 1 007+ termes financiers");
  const { user, isAuthenticated } = useAuth();
  const { isPremium, canAccess, tier } = useSubscription();
  const [activeTab, setActiveTab] = useState<TabMode>("fiches");

  const PREMIUM_TABS: TabMode[] = ["flashcards", "quiz", "parcours", "progression"];
  const isTabPremium = (tab: TabMode) => PREMIUM_TABS.includes(tab);

  useSEO(SEO_PAGES.glossaire);

  return (
    <Layout>
      {/* ═══════════ HERO — Dark Blue Header ═══════════ */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#344453] via-[#2a3a47] to-[#1a2530]">
        <div className="absolute inset-0 opacity-[0.04]" style={{
          backgroundImage: `linear-gradient(rgba(212,168,83,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(212,168,83,0.3) 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }} />
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#D4A853]/8 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/4" />

        <div className="container relative py-16 lg:py-24">
            <PageBreadcrumb items={[{ label: "Glossaire" }]} className="mb-6" />
          <div className="max-w-4xl">
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex items-center gap-3 mb-6"
            >
              <div className="w-10 h-10 rounded-xl bg-[#D4A853]/15 border border-[#D4A853]/25 flex items-center justify-center">
                <BookOpen size={20} className="text-[#D4A853]" />
              </div>
              <span className="text-white/85 text-sm font-medium uppercase tracking-widest">
                Encyclopédie financière
              </span>
            </motion.div>

            {/* Title */}
            <motion.h1
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-[56px] font-bold text-white leading-[1.08] mb-6"
            >
              Glossaire financier
              <br />
              <span className="bg-gradient-to-r from-[#D4A853] via-[#E8C97A] to-[#D4A853] bg-clip-text text-transparent">
                expliqué simplement.
              </span>
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg text-white/85 max-w-2xl leading-relaxed mb-8"
            >
              Le vocabulaire est la fondation de toute analyse. Ce glossaire interactif propose 5 modes d'apprentissage pour maîtriser chaque concept, du débutant à l'avancé.
            </motion.p>

            {/* Category pills */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-wrap gap-2 mb-8"
            >
              {Object.entries(CATEGORY_LABELS).map(([key, label]) => {
                const CatIcon = CATEGORY_ICONS[key];
                const colors = CATEGORY_COLORS[key];
                return (
                  <div key={key} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#E1E6EA] border border-[#D0D5DA] hover:border-[#D0D5DA] transition-colors">
                    <CatIcon size={12} style={{ color: colors.accent }} />
                    <span className="text-xs text-[#1E1E1E] font-medium">{label}</span>
                  </div>
                );
              })}
            </motion.div>

            {/* Tab Navigation — Premium */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.35 }}
              className="flex flex-wrap gap-2"
            >
              {TAB_CONFIG.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.key;
                return (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                      isActive
                        ? "bg-[#D4A853] text-[#344453] shadow-lg shadow-[#D4A853]/20"
                        : "bg-[#E1E6EA] text-[#1E1E1E]/85 hover:bg-white/12 hover:text-[#344453] border border-[#D0D5DA]"
                    }`}
                  >
                    <Icon size={16} />
                    <span>{tab.label}</span>
                    <span className={`text-xs ${isActive ? "text-[#344453]/70" : "text-[#1E1E1E]/75"}`}>
                      {tab.desc}
                    </span>
                  </button>
                );
              })}
            </motion.div>
          </div>
        </div>
      </section>

      {/* ═══════════ MOT DU JOUR ═══════════ */}
      <section className="py-8 bg-white border-b border-[#E1E6EA]">
        <div className="container">
          <div className="max-w-2xl mx-auto">
            <GlossaryWordOfDay />
          </div>
        </div>
      </section>

      {/* ═══════════ POURQUOI MAÎTRISER LE VOCABULAIRE ═══════════ */}
      <section className="py-14 lg:py-20 bg-white">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <div>
              <span className="text-xs font-medium uppercase tracking-widest text-[#8A6E18] mb-4 block">Fondamentaux</span>
              <h1 className="text-3xl lg:text-4xl font-bold text-[#344453] leading-tight mb-6">
                Pourquoi maîtriser le vocabulaire financier ?
              </h1>
              <p className="text-[#1E1E1E]/70 leading-relaxed mb-4">
                Le marché financier possède son propre langage. Quand un analyste parle de <strong className="text-[#344453]">"hawkish pivot"</strong>, de <strong className="text-[#344453]">"yield curve inversion"</strong> ou de <strong className="text-[#344453]">"dead cat bounce"</strong>, il utilise un vocabulaire précis qui porte une signification technique spécifique.
              </p>
              <p className="text-[#1E1E1E]/70 leading-relaxed mb-4">
                Sans cette maîtrise, vous risquez de mal interpréter une information cruciale. Un <strong className="text-[#344453]">"bear market rally"</strong> n'est pas un signal haussier — c'est un rebond temporaire dans une tendance baissière. Un <strong className="text-[#344453]">"short squeeze"</strong> n'est pas une compression physique — c'est un mouvement violent causé par les vendeurs à découvert forcés de racheter.
              </p>
              <p className="text-[#1E1E1E]/70 leading-relaxed">
                {`Ce glossaire de ${GLOSSARY.termCount} termes`} couvre l'intégralité du vocabulaire nécessaire pour comprendre les marchés financiers américains, de la terminologie de base aux concepts avancés.
              </p>
            </div>
            <div className="space-y-3">
              {[
                { title: "Marché", desc: "Bull market, bear market, correction, crash, rally, consolidation, breakout, support, résistance, gap, all-time high...", count: "180+", color: "#344453" },
                { title: "Analyse", desc: "P/E ratio, EPS, free cash flow, EBITDA, book value, ROE, debt-to-equity, operating margin, revenue growth...", count: "220+", color: "#344453" },
                { title: "Instruments", desc: "Actions, ETF, options (call/put), futures, obligations, REIT, SPAC, ADR, warrant, convertible...", count: "150+", color: "#2E7D5B" },
                { title: "Risque", desc: "Volatilité, drawdown, beta, alpha, Sharpe ratio, VaR, correlation, diversification, hedging, tail risk...", count: "180+", color: "#B0413E" },
                { title: "Ordres", desc: "Market order, limit order, stop loss, trailing stop, fill or kill, good till cancelled, bracket order...", count: "120+", color: "#C4A052" },
                { title: "Indicateurs", desc: "RSI, MACD, Bollinger Bands, moving average, volume profile, Fibonacci, Ichimoku, stochastic...", count: "157+", color: "#344453" },
              ].map((item) => (
                <div key={item.title} className="bg-[#F4F5F5] rounded-xl p-4 border border-[#D0D5DA] hover:border-transparent hover:shadow-md transition-all group">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-[#344453] text-sm">{item.title}</h3>
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full" style={{ backgroundColor: `${item.color}12`, color: item.color }}>{item.count} termes</span>
                  </div>
                  <p className="text-xs text-[#344453]/80 leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>



      {/* ═══════════ CONTENT — Active Mode ═══════════ */}
      <section className="py-10 lg:py-14 bg-[#F4F5F5] min-h-[60vh]">
        <div className="container">
          {/* Mobile tab selector */}
          <div className="flex flex-wrap gap-2 mb-8 lg:hidden">
            {TAB_CONFIG.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.key;
              return (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                    isActive ? "bg-[#344453] text-white shadow-md" : "bg-white text-[#344453]/80 border border-[#D0D5DA]"
                  }`}
                >
                  <Icon size={14} />
                  {tab.label}
                </button>
              );
            })}
          </div>

          <AnimatePresence mode="wait">
            {activeTab === "fiches" && <FichesMode key="fiches" isPremium={isPremium} isAuthenticated={isAuthenticated} />}
            {activeTab === "flashcards" && (
              isPremium ? (
                <FlashcardsMode key="flashcards" isAuthenticated={isAuthenticated} />
              ) : (
                <PremiumFeaturePreview
                  key="flashcards-preview"
                  icon={Brain}
                  title="Flashcards interactives"
                  description={`Révisez les ${GLOSSARY.termLabel} termes financiers avec des flashcards interactives. Retournez la carte pour voir la définition, marquez vos termes maîtrisés et suivez votre progression.`}
                  features={["Révision par catégorie et niveau", "Suivi de maîtrise automatique", "Mode aléatoire ou séquentiel"]}
                />
              )
            )}
            {activeTab === "quiz" && (
              isPremium ? (
                <QuizMode key="quiz" isAuthenticated={isAuthenticated} />
              ) : (
                <PremiumFeaturePreview
                  key="quiz-preview"
                  icon={Target}
                  title="Quiz interactifs"
                  description="Testez vos connaissances avec des quiz générés aléatoirement. 30 questions par session, score instantané et analyse de vos points faibles."
                  features={["30 questions aléatoires par session", "Score et correction instantanés", "Suivi de progression par catégorie"]}
                />
              )
            )}
            {activeTab === "parcours" && (
              isPremium ? (
                <ParcoursMode key="parcours" />
              ) : (
                <PremiumFeaturePreview
                  key="parcours-preview"
                  icon={Route}
                  title="Parcours guidés"
                  description="Suivez des parcours d'apprentissage structurés pour maîtriser les concepts financiers étape par étape, du débutant à l'avancé."
                  features={["Parcours par niveau de difficulté", "Progression étape par étape", "Objectifs clairs par parcours"]}
                />
              )
            )}
            {activeTab === "progression" && (
              isPremium ? (
                <ProgressionMode key="progression" isAuthenticated={isAuthenticated} />
              ) : (
                <PremiumFeaturePreview
                  key="progression-preview"
                  icon={Trophy}
                  title="Suivi de progression"
                  description="Visualisez votre avancement global, vos statistiques par catégorie, vos badges débloqués et votre historique d'apprentissage."
                  features={["Statistiques détaillées par catégorie", "Badges et récompenses", "Historique d'apprentissage complet"]}
                />
              )
            )}
          </AnimatePresence>
        </div>
      </section>

      {/* Section 'Continuez votre apprentissage' cross-sell supprimée — LOT 12 */}

      {/* ═══════════ MÉMORISATION ═══════════ */}
      <section className="py-14 lg:py-18 bg-[#F4F5F5]">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-10">
              <span className="text-xs font-medium uppercase tracking-widest text-[#8A6E18] mb-3 block">Méthodologie</span>
              <h2 className="text-2xl lg:text-3xl font-bold text-[#344453] mb-3">Comment mémoriser efficacement ?</h2>
              <p className="text-sm text-[#1E1E1E]/80 max-w-xl mx-auto leading-relaxed">
                La science de l'apprentissage montre que la mémorisation active est 3x plus efficace que la relecture passive.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-5">
              {[
                { step: "01", title: "Répétition espacée", desc: "Revenez sur les termes à intervalles croissants : J+1, J+3, J+7, J+14. Les flashcards WMB utilisent ce principe pour optimiser votre rétention.", color: "#D4A853" },
                { step: "02", title: "Contextualisation", desc: "Associez chaque terme à un exemple concret. Au lieu de mémoriser \"P/E ratio = prix / bénéfice\", pensez \"Apple a un P/E de 28\".", color: "#2E7D5B" },
                { step: "03", title: "Test actif", desc: "Testez-vous régulièrement avec le mode Quiz. L'effort de rappel renforce la mémoire à long terme de manière significative.", color: "#344453" },
              ].map((item) => (
                <div key={item.step} className="bg-white border border-[#D0D5DA] rounded-xl p-6 relative hover:bg-white transition-colors">
                  <span className="text-[#344453]/5 text-5xl font-bold absolute top-3 right-4">{item.step}</span>
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center mb-4" style={{ backgroundColor: `${item.color}20` }}>
                    <span className="text-sm font-bold" style={{ color: item.color }}>{item.step}</span>
                  </div>
                  <h3 className="font-semibold text-[#344453] text-sm mb-2">{item.title}</h3>
                  <p className="text-xs text-[#1E1E1E]/80 leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ FAQ ═══════════ */}
      <section className="py-14 lg:py-18 bg-white border-b border-[#D0D5DA]">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-10">
              <span className="text-xs font-medium uppercase tracking-widest text-[#8A6E18] mb-3 block">Questions fréquentes</span>
              <h2 className="text-2xl lg:text-3xl font-bold text-[#344453] mb-3">Tout savoir sur le glossaire</h2>
            </div>
            <div className="space-y-3">
              {[
                { q: "Combien de termes contient le glossaire ?", a: `Le glossaire WMB contient actuellement ${GLOSSARY.termLabel} termes financiers, répartis en 6 catégories et 3 niveaux de difficulté. De nouveaux termes sont ajoutés régulièrement.` },
                { q: "Les fiches sont-elles accessibles gratuitement ?", a: "Oui, les fiches de définition sont accessibles à tous. Les modes avancés (Flashcards, Quiz, Parcours et Progression) sont réservés aux abonnés Premium." },
                { q: "Comment sont classés les termes ?", a: "Par catégorie thématique et par niveau de difficulté. Vous pouvez filtrer, rechercher et naviguer librement. Le mode Parcours propose des chemins structurés." },
                { q: "Quelle est la différence avec le quiz WMB ?", a: "Le quiz du glossaire teste votre connaissance des définitions. Le Quiz WMB (page Quiz) couvre les concepts de marché, indicateurs et ETFs avec des questions plus contextuelles." },
                { q: "Puis-je suggérer de nouveaux termes ?", a: "Oui ! Si vous rencontrez un terme financier absent, signalez-le. Nous enrichissons continuellement la base pour couvrir l'intégralité du vocabulaire nécessaire." },
              ].map((item) => (
                <details key={item.q} className="group bg-[#F4F5F5] rounded-xl border border-[#D0D5DA] overflow-hidden">
                  <summary className="flex items-center justify-between p-5 cursor-pointer list-none">
                    <span className="text-sm font-semibold text-[#344453] pr-4">{item.q}</span>
                    <ChevronRight size={16} className="text-[#1E1E1E]/80 group-open:rotate-90 transition-transform shrink-0" />
                  </summary>
                  <div className="px-5 pb-5">
                    <p className="text-sm text-[#1E1E1E]/80 leading-relaxed">{item.a}</p>
                  </div>
                </details>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ CTA FINAL ═══════════ */}
      <section className="py-16 lg:py-20 bg-gradient-to-br from-[#344453] via-[#344453] to-[#2a3845]">
        <div className="container text-center">
          <div className="max-w-2xl mx-auto">
            <div className="w-14 h-14 rounded-2xl bg-white/10 border border-[#D0D5DA] flex items-center justify-center mx-auto mb-6">
              <Sparkles size={24} className="text-[#8A6E18]" />
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
              Prêt à maîtriser le vocabulaire ?
            </h2>
            <p className="text-white/85 mb-8 max-w-lg mx-auto leading-relaxed">
              Explorez les fiches, puis découvrez les flashcards, quiz et parcours guidés pour approfondir vos connaissances.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => { setActiveTab("fiches"); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white text-[#344453] font-semibold rounded-xl hover:bg-white/90 transition-colors"
              >
                <BookOpen size={18} />
                Explorer les fiches
              </button>
              <Link
                href="/pricing"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-[#D4A853] text-white font-semibold rounded-xl hover:bg-[#D4A853]/90 transition-colors shadow-lg shadow-[#D4A853]/20"
              >
                <Crown size={18} />
                Débloquer tout
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ DISCLAIMER ═══════════ */}
      <section className="py-8 bg-white border-t border-[#D0D5DA]">
        <div className="container">
          <p className="text-xs text-[#1E1E1E]/80 text-center max-w-3xl mx-auto leading-relaxed">
            Ce glossaire est fourni à titre informatif uniquement. Il ne constitue en aucun cas un conseil en investissement,
            une recommandation d'achat ou de vente, ni une incitation à investir. Consultez un professionnel agréé avant toute décision.
          </p>
        </div>
      </section>
    </Layout>
  );
}

// ═══════════════════════════════════════════════════════════
// TERM CARD — Premium Trading Card Design
// ═══════════════════════════════════════════════════════════
export function TermCard({ term, onClick }: { term: GlossaryTerm; onClick: () => void }) {
  const CatIcon = CATEGORY_ICONS[term.category] || BookOpen;
  const catColors = CATEGORY_COLORS[term.category] || CATEGORY_COLORS.marche;
  const levelCfg = LEVEL_CONFIG[term.level] || LEVEL_CONFIG.debutant;
  const firstLetter = term.term.charAt(0).toUpperCase();

  return (
    <motion.button
      onClick={onClick}
      whileHover={{ y: -3 }}
      transition={{ duration: 0.2 }}
      className="text-left w-full group relative"
    >
      <div className="bg-white rounded-2xl overflow-hidden border border-[#D0D5DA] hover:border-transparent hover:shadow-xl transition-all duration-300">
        {/* Top accent line */}
        <div className="h-1 w-full" style={{ backgroundColor: catColors.accent }} />
        <div className="p-5">
          {/* Header */}
          <div className="flex items-center gap-3 mb-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold shrink-0"
              style={{ backgroundColor: catColors.bg, color: catColors.text }}
            >
              {firstLetter}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <span
                  className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full"
                  style={{ backgroundColor: catColors.bg, color: catColors.text }}
                >
                  {CATEGORY_LABELS[term.category]}
                </span>
                <span
                  className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full"
                  style={{ backgroundColor: levelCfg.bg, color: levelCfg.color }}
                >
                  {levelCfg.icon}
                </span>
              </div>
            </div>
            <ArrowUpRight size={14} className="text-[#344453]/25 group-hover:text-[#344453]/80 transition-colors shrink-0" />
          </div>

          {/* Term name */}
          <h3 className="font-bold text-[#344453] text-base mb-2 group-hover:text-[#344453] transition-colors">
            {term.term}
          </h3>

          {/* Definition preview */}
          <p className="text-xs text-[#344453]/80 leading-relaxed line-clamp-2">
            {term.definition}
          </p>

          {/* Level bar */}
          <div className="mt-3 flex items-center gap-1">
            {[1, 2, 3].map((dot) => (
              <div
                key={dot}
                className="h-1 flex-1 rounded-full"
                style={{
                  backgroundColor: dot <= levelCfg.dots ? levelCfg.color : "#D0D5DA",
                  opacity: dot <= levelCfg.dots ? 1 : 0.3,
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </motion.button>
  );
}

// ═══════════════════════════════════════════════════════════
// TERM DETAIL MODAL — Premium
// ═══════════════════════════════════════════════════════════
export function TermDetailModal({ term, onClose }: { term: GlossaryTerm; onClose: () => void }) {
  const CatIcon = CATEGORY_ICONS[term.category] || BookOpen;
  const catColors = CATEGORY_COLORS[term.category] || CATEGORY_COLORS.marche;
  const levelCfg = LEVEL_CONFIG[term.level] || LEVEL_CONFIG.debutant;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ duration: 0.3 }}
        className="relative bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[85vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Accent bar */}
        <div className="h-1.5 w-full rounded-t-2xl" style={{ backgroundColor: catColors.accent }} />

        <div className="p-6 lg:p-8">
          {/* Close */}
          <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-[#F4F5F5] flex items-center justify-center hover:bg-[#D0D5DA] transition-colors">
            <X size={16} className="text-[#344453]/80" />
          </button>

          {/* Header */}
          <div className="flex items-center gap-3 mb-5">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center text-xl font-bold" style={{ backgroundColor: catColors.bg, color: catColors.text }}>
              {term.term.charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full" style={{ backgroundColor: catColors.bg, color: catColors.text }}>
                  {CATEGORY_LABELS[term.category]}
                </span>
                <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full" style={{ backgroundColor: levelCfg.bg, color: levelCfg.color }}>
                  {LEVEL_LABELS[term.level]}
                </span>
              </div>
              <h2 className="text-xl font-bold text-[#344453]">{term.term}</h2>
            </div>
          </div>

          {/* Definition */}
          <div className="mb-5">
            <p className="text-xs font-bold text-[#344453]/80 uppercase tracking-wider mb-2">Définition</p>
            <p className="text-sm text-[#344453]/75 leading-[1.8]">{term.definition}</p>
          </div>

          {/* Vu dans la newsletter */}
          <div className="mb-5 p-4 rounded-xl border border-[#D4A853]/15 bg-[#D4A853]/5">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={14} className="text-[#8A6E18]" />
              <span className="text-xs font-bold text-[#8A6E18]">Vu dans la newsletter</span>
            </div>
            <p className="text-xs text-[#344453]/80 leading-relaxed">
              Ce terme est régulièrement utilisé dans nos analyses hebdomadaires. Abonnez-vous pour voir comment il s'applique en conditions réelles de marché.
            </p>
            <Link href="/newsletter" className="inline-flex items-center gap-1 text-[11px] font-bold text-[#8A6E18] hover:underline mt-2">
              Voir la newsletter <ArrowUpRight size={10} />
            </Link>
          </div>

          {/* À lire ensuite */}
          <div className="mb-5 p-4 rounded-xl bg-[#F4F5F5] border border-[#D0D5DA]">
            <p className="text-xs font-bold text-[#344453]/80 uppercase tracking-wider mb-2">À lire ensuite</p>
            {term.level === "debutant" && (
              <>
                <p className="text-xs text-[#344453]/80">Continuez avec les termes <strong className="text-[#344453]/75">intermédiaires</strong> de cette catégorie ou commencez la <strong className="text-[#344453]/75">formation Module 1</strong>.</p>
                <Link href="/formation" className="inline-flex items-center gap-1 text-[11px] font-bold text-[#344453] hover:underline mt-1">
                  Formation A-Z <ArrowUpRight size={10} />
                </Link>
              </>
            )}
            {term.level === "intermediaire" && (
              <>
                <p className="text-xs text-[#344453]/80">Passez aux termes <strong className="text-[#344453]/75">avancés</strong> ou explorez les <strong className="text-[#344453]/75">indicateurs techniques</strong> liés.</p>
                <Link href="/indicateurs-tendance" className="inline-flex items-center gap-1 text-[11px] font-bold text-[#344453] hover:underline mt-1">
                  Indicateurs de tendance <ArrowUpRight size={10} />
                </Link>
              </>
            )}
            {term.level === "avance" && (
              <>
                <p className="text-xs text-[#344453]/80">Approfondissez avec les <strong className="text-[#344453]/75">thématiques sectorielles</strong> ou testez vos connaissances avec le <strong className="text-[#344453]/75">quiz</strong>.</p>
                <Link href="/thematiques" className="inline-flex items-center gap-1 text-[11px] font-bold text-[#344453] hover:underline mt-1">
                  Thématiques d'investissement <ArrowUpRight size={10} />
                </Link>
              </>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3 pt-3 border-t border-[#D0D5DA]">
            {term.relatedCourseId && (
              <Link
                href="/formation"
                className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-xl transition-colors"
                style={{ backgroundColor: catColors.bg, color: catColors.text }}
              >
                <GraduationCap size={15} />
                Voir le cours associé
              </Link>
            )}
            <button
              onClick={onClose}
              className="px-4 py-2.5 text-sm font-medium text-[#344453]/80 hover:text-[#344453]/80 transition-colors"
            >
              Fermer
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// MODE 1 — FICHES (Dictionnaire) — Premium Cards
// ═══════════════════════════════════════════════════════════
export function FichesMode({ isPremium, isAuthenticated }: { isPremium: boolean; isAuthenticated: boolean }) {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [level, setLevel] = useState("");
  const [selectedTerm, setSelectedTerm] = useState<GlossaryTerm | null>(null);
  const [page, setPage] = useState(0);
  const pageSize = 30;

  const { data, isLoading } = trpc.glossaryV3.terms.useQuery({
    search: search || undefined,
    category: category || undefined,
    level: level || undefined,
    limit: pageSize,
    offset: page * pageSize,
  });

  const { data: categories } = trpc.glossaryV3.categories.useQuery();

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
      {/* Search & Filters */}
      <div className="bg-white rounded-2xl border border-[#D0D5DA] p-5 mb-8 shadow-sm">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#344453]/75" />
            <input
              type="text"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(0); }}
              placeholder={`Rechercher parmi ${GLOSSARY.termLabel} termes financiers...`}
              className="w-full pl-11 pr-4 py-3.5 bg-[#F4F5F5] rounded-xl text-[#344453] placeholder:text-[#1E1E1E]/80 focus:outline-none focus:ring-2 focus:ring-[#344453]/15 focus:bg-white text-sm transition-all border border-transparent focus:border-[#D0D5DA]"
            />
          </div>
          <div className="flex gap-3">
            <div className="relative">
              <Filter size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#344453]/75 pointer-events-none" />
              <select
                value={category}
                onChange={(e) => { setCategory(e.target.value); setPage(0); }}
                className="pl-8 pr-8 py-3.5 bg-[#F4F5F5] rounded-xl text-sm text-[#344453]/75 focus:outline-none focus:ring-2 focus:ring-[#344453]/15 appearance-none cursor-pointer"
              >
                <option value="">Toutes catégories</option>
                {Object.entries(CATEGORY_LABELS).map(([k, v]) => (
                  <option key={k} value={k}>{v}</option>
                ))}
              </select>
            </div>
            <select
              value={level}
              onChange={(e) => { setLevel(e.target.value); setPage(0); }}
              className="px-4 py-3.5 bg-[#F4F5F5] rounded-xl text-sm text-[#344453]/75 focus:outline-none focus:ring-2 focus:ring-[#344453]/15 appearance-none cursor-pointer"
            >
              <option value="">Tous niveaux</option>
              {Object.entries(LEVEL_LABELS).map(([k, v]) => (
                <option key={k} value={k}>{v}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Active filters + count */}
        <div className="flex items-center justify-between mt-4 pt-3 border-t border-[#F4F5F5]">
          <div className="flex items-center gap-2">
            {category && (
              <button onClick={() => { setCategory(""); setPage(0); }} className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-colors" style={{ backgroundColor: CATEGORY_COLORS[category]?.bg || "#F4F5F5", color: CATEGORY_COLORS[category]?.text || "#344453" }}>
                {CATEGORY_LABELS[category]} <X size={10} />
              </button>
            )}
            {level && (
              <button onClick={() => { setLevel(""); setPage(0); }} className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-colors" style={{ backgroundColor: LEVEL_CONFIG[level]?.bg || "#F4F5F5", color: LEVEL_CONFIG[level]?.color || "#344453" }}>
                {LEVEL_LABELS[level]} <X size={10} />
              </button>
            )}
          </div>
          <p className="text-xs text-[#344453]/80 font-medium">
            {data?.total ?? 0} terme{(data?.total ?? 0) > 1 ? "s" : ""}
            {search && ` pour "${search}"`}
          </p>
        </div>
      </div>

      {/* Terms Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="bg-white rounded-2xl overflow-hidden border border-[#D0D5DA]">
              <div className="h-1 bg-[#D0D5DA]" />
              <div className="p-5">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-[#F4F5F5] animate-pulse" />
                  <div className="space-y-1.5 flex-1">
                    <div className="h-2.5 w-16 bg-[#F4F5F5] rounded animate-pulse" />
                    <div className="h-2 w-12 bg-[#F4F5F5] rounded animate-pulse" />
                  </div>
                </div>
                <div className="h-4 w-3/4 bg-[#F4F5F5] rounded animate-pulse mb-2" />
                <div className="h-3 w-full bg-[#F4F5F5] rounded animate-pulse mb-1" />
                <div className="h-3 w-2/3 bg-[#F4F5F5] rounded animate-pulse" />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {data?.terms.map((term) => (
            <TermCard key={term.id} term={term} onClick={() => setSelectedTerm(term)} />
          ))}
        </div>
      )}

      {/* Paywall CTA */}
      {!isPremium && data && (data as any).limited && (
        <div className="mt-10 relative overflow-hidden rounded-2xl border border-[#D4A853]/20 bg-gradient-to-br from-[#D4A853]/5 via-white to-[#344453]/5 p-10 text-center">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#D4A853]/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
          <div className="relative">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#D4A853]/20 to-[#D4A853]/5 border border-[#D4A853]/20 flex items-center justify-center mx-auto mb-5">
              <Crown size={28} className="text-[#8A6E18]" />
            </div>
            <h4 className="text-xl font-bold text-[#344453] mb-2">Vous avez vu {GLOSSARY.termLabel} termes sur {data.total}</h4>
            <p className="text-[#344453]/80 text-sm mb-8 max-w-md mx-auto leading-relaxed">
              Débloquez l'intégralité du glossaire ({data.total} termes), les flashcards, quiz et parcours guidés.
            </p>
            {isAuthenticated ? (
              <Link href="/pricing" className="inline-flex items-center gap-2 px-8 py-3.5 bg-[#D4A853] text-[#344453] font-semibold rounded-xl hover:bg-[#D4A853]/90 transition-colors text-sm shadow-lg shadow-[#D4A853]/20">
                Voir les offres <ArrowRight size={16} />
              </Link>
            ) : (
              <Link href="/login" className="inline-flex items-center gap-2 px-8 py-3.5 bg-[#D4A853] text-[#344453] font-semibold rounded-xl hover:bg-[#D4A853]/90 transition-colors text-sm shadow-lg shadow-[#D4A853]/20">
                Créer un compte gratuit <ArrowRight size={16} />
              </Link>
            )}
          </div>
        </div>
      )}

      {/* Pagination */}
      {isPremium && data && data.total > pageSize && (
        <div className="flex items-center justify-center gap-4 mt-10">
          <button onClick={() => setPage(Math.max(0, page - 1))} disabled={page === 0} className="flex items-center gap-2 px-5 py-2.5 bg-white rounded-xl border border-[#D0D5DA] text-sm text-[#344453] font-medium disabled:opacity-40 hover:bg-[#F4F5F5] transition-all">
            <ChevronLeft size={16} /> Précédent
          </button>
          <div className="flex items-center gap-1">
            {Array.from({ length: Math.min(5, Math.ceil(data.total / pageSize)) }).map((_, i) => {
              const totalPages = Math.ceil(data.total / pageSize);
              let pageNum: number;
              if (totalPages <= 5) pageNum = i;
              else if (page < 3) pageNum = i;
              else if (page > totalPages - 4) pageNum = totalPages - 5 + i;
              else pageNum = page - 2 + i;
              return (
                <button key={pageNum} onClick={() => setPage(pageNum)} className={`w-9 h-9 rounded-lg text-sm font-medium transition-all ${page === pageNum ? "bg-[#344453] text-white shadow-md" : "bg-white text-[#344453]/80 hover:bg-[#F4F5F5] border border-[#D0D5DA]"}`}>
                  {pageNum + 1}
                </button>
              );
            })}
          </div>
          <button onClick={() => setPage(page + 1)} disabled={(page + 1) * pageSize >= data.total} className="flex items-center gap-2 px-5 py-2.5 bg-white rounded-xl border border-[#D0D5DA] text-sm text-[#344453] font-medium disabled:opacity-40 hover:bg-[#F4F5F5] transition-all">
            Suivant <ChevronRight size={16} />
          </button>
        </div>
      )}

      {/* Term Detail Modal */}
      <AnimatePresence>
        {selectedTerm && <TermDetailModal term={selectedTerm} onClose={() => setSelectedTerm(null)} />}
      </AnimatePresence>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// MODE 2 — FLASHCARDS
// ═══════════════════════════════════════════════════════════
export function FlashcardsMode({ isAuthenticated }: { isAuthenticated: boolean }) {
  const [started, setStarted] = useState(false);
  const [fcCategory, setFcCategory] = useState("");
  const [fcLevel, setFcLevel] = useState("");
  const [currentIdx, setCurrentIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [known, setKnown] = useState<number[]>([]);
  const [toReview, setToReview] = useState<number[]>([]);

  const { data: cards, refetch } = trpc.glossaryV3.flashcards.useQuery(
    { count: 10, category: fcCategory || undefined, level: fcLevel || undefined },
    { enabled: started }
  );

  const updateProgress = trpc.glossaryV3.updateProgress.useMutation();

  const currentCard = cards?.[currentIdx];
  const totalCards = cards?.length ?? 0;
  const isFinished = currentIdx >= totalCards && totalCards > 0;

  const handleAnswer = (status: "known" | "review") => {
    if (!currentCard) return;
    if (status === "known") setKnown((p) => [...p, currentCard.id]);
    else setToReview((p) => [...p, currentCard.id]);
    if (isAuthenticated) updateProgress.mutate({ termId: currentCard.id, status });
    setFlipped(false);
    setCurrentIdx((p) => p + 1);
  };

  const restart = () => {
    setCurrentIdx(0); setFlipped(false); setKnown([]); setToReview([]); refetch();
  };

  if (!started) {
    return (
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
        <div className="max-w-xl mx-auto text-center">
          <div className="w-16 h-16 rounded-2xl bg-[#344453]/10 flex items-center justify-center mx-auto mb-6">
            <Brain size={32} className="text-[#344453]" />
          </div>
          <h2 className="text-2xl font-bold text-[#344453] mb-3">Réviser en 5 minutes</h2>
          <p className="text-[#344453]/80 mb-8">10 flashcards générées aléatoirement. Marquez chaque terme comme "Je connais" ou "À revoir".</p>
          <div className="bg-white rounded-2xl p-6 border border-[#D0D5DA] mb-6 text-left">
            <p className="text-sm font-semibold text-[#344453] mb-4">Personnaliser la session</p>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-[#344453]/80 mb-1 block">Catégorie</label>
                <select value={fcCategory} onChange={(e) => setFcCategory(e.target.value)} className="w-full px-3 py-2.5 bg-[#F4F5F5] rounded-lg border border-[#D0D5DA] text-sm">
                  <option value="">Toutes</option>
                  {Object.entries(CATEGORY_LABELS).map(([k, v]) => (<option key={k} value={k}>{v}</option>))}
                </select>
              </div>
              <div>
                <label className="text-xs text-[#344453]/80 mb-1 block">Niveau</label>
                <select value={fcLevel} onChange={(e) => setFcLevel(e.target.value)} className="w-full px-3 py-2.5 bg-[#F4F5F5] rounded-lg border border-[#D0D5DA] text-sm">
                  <option value="">Tous</option>
                  {Object.entries(LEVEL_LABELS).map(([k, v]) => (<option key={k} value={k}>{v}</option>))}
                </select>
              </div>
            </div>
          </div>
          <button onClick={() => setStarted(true)} className="inline-flex items-center gap-2 px-8 py-4 bg-[#344453] text-white font-semibold rounded-xl hover:bg-[#344453]/90 transition-colors shadow-lg shadow-[#344453]/15">
            <Play size={18} /> Commencer la révision
          </button>
        </div>
      </motion.div>
    );
  }

  if (isFinished) {
    const score = Math.round((known.length / totalCards) * 100);
    return (
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
        <div className="max-w-md mx-auto text-center">
          <div className="w-20 h-20 rounded-full bg-[#344453]/10 flex items-center justify-center mx-auto mb-6">
            <Trophy size={36} className="text-[#344453]" />
          </div>
          <h2 className="text-2xl font-bold text-[#344453] mb-2">Session terminée !</h2>
          <p className="text-[#344453]/80 mb-8">Vous maîtrisez <span className="font-bold text-[#2E7D5B]">{known.length}</span> terme{known.length > 1 ? "s" : ""} sur {totalCards}.</p>
          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-[#2E7D5B]/10 rounded-xl p-5 text-center">
              <p className="text-3xl font-bold text-[#2E7D5B]">{known.length}</p>
              <p className="text-xs text-[#2E7D5B]/70 mt-1">Je connais</p>
            </div>
            <div className="bg-[#C4A052]/10 rounded-xl p-5 text-center">
              <p className="text-3xl font-bold text-[#C4A052]">{toReview.length}</p>
              <p className="text-xs text-[#C4A052]/70 mt-1">À revoir</p>
            </div>
          </div>
          <button onClick={restart} className="inline-flex items-center gap-2 px-6 py-3 bg-[#344453] text-white font-semibold rounded-xl hover:bg-[#344453]/90 transition-colors">
            <RotateCcw size={16} /> Nouvelle session
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
      <div className="max-w-lg mx-auto mb-8">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-[#344453]/80">Carte {currentIdx + 1} / {totalCards}</span>
          <div className="flex gap-2">
            <span className="text-xs text-[#2E7D5B] font-medium">{known.length} connus</span>
            <span className="text-xs text-[#C4A052] font-medium">{toReview.length} à revoir</span>
          </div>
        </div>
        <div className="h-2 bg-[#D0D5DA] rounded-full overflow-hidden">
          <div className="h-full bg-[#344453] rounded-full transition-all duration-300" style={{ width: `${((currentIdx) / totalCards) * 100}%` }} />
        </div>
      </div>

      {currentCard && (
        <div className="max-w-lg mx-auto">
          <div onClick={() => setFlipped(!flipped)} className="relative bg-white rounded-2xl border border-[#D0D5DA] shadow-lg cursor-pointer min-h-[300px] flex flex-col justify-center p-8 hover:shadow-xl transition-shadow overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1.5" style={{ backgroundColor: CATEGORY_COLORS[currentCard.category]?.accent || "#344453" }} />
            {!flipped ? (
              <div className="text-center">
                <div className="flex items-center justify-center gap-2 mb-4">
                  <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full" style={{ backgroundColor: CATEGORY_COLORS[currentCard.category]?.bg, color: CATEGORY_COLORS[currentCard.category]?.text }}>{CATEGORY_LABELS[currentCard.category]}</span>
                  <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full" style={{ backgroundColor: LEVEL_CONFIG[currentCard.level]?.bg, color: LEVEL_CONFIG[currentCard.level]?.color }}>{LEVEL_LABELS[currentCard.level]}</span>
                </div>
                <h3 className="text-2xl font-bold text-[#344453] mb-4">{currentCard.term}</h3>
                <p className="text-sm text-[#1E1E1E]/80">Cliquez pour voir la définition</p>
              </div>
            ) : (
              <div>
                <p className="text-xs font-bold text-[#344453]/80 uppercase tracking-wider mb-3">Définition</p>
                <p className="text-sm text-[#344453]/75 leading-[1.8]">{currentCard.definition}</p>
              </div>
            )}
          </div>
          <div className="flex gap-4 mt-6 justify-center">
            <button onClick={() => handleAnswer("review")} className="flex items-center gap-2 px-6 py-3 bg-[#C4A052]/10 text-[#C4A052] font-semibold rounded-xl hover:bg-[#C4A052]/20 transition-colors">
              <RotateCcw size={16} /> À revoir
            </button>
            <button onClick={() => handleAnswer("known")} className="flex items-center gap-2 px-6 py-3 bg-[#2E7D5B]/10 text-[#2E7D5B] font-semibold rounded-xl hover:bg-[#2E7D5B]/20 transition-colors">
              <Check size={16} /> Je connais
            </button>
          </div>
        </div>
      )}
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// MODE 3 — QUIZ INTELLIGENT
// ═══════════════════════════════════════════════════════════
export function QuizMode({ isAuthenticated }: { isAuthenticated: boolean }) {
  const [started, setStarted] = useState(false);
  const [quizDifficulty, setQuizDifficulty] = useState("");
  const [quizCount, setQuizCount] = useState(10);
  const [currentQ, setCurrentQ] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<boolean[]>([]);

  const { data: questions, refetch } = trpc.glossaryV3.quizQuestions.useQuery(
    { count: quizCount, difficulty: quizDifficulty || undefined },
    { enabled: started }
  );

  const saveScore = trpc.glossaryV3.saveQuizScore.useMutation();
  const currentQuestion = questions?.[currentQ];
  const totalQ = questions?.length ?? 0;
  const isFinished = currentQ >= totalQ && totalQ > 0;

  const handleSubmit = () => {
    if (!currentQuestion || selectedAnswer === null) return;
    const isCorrect = selectedAnswer === currentQuestion.correctAnswer;
    if (isCorrect) setScore((s) => s + 1);
    setAnswers((a) => [...a, isCorrect]);
    setShowResult(true);
  };

  const handleNext = () => {
    setSelectedAnswer(null);
    setShowResult(false);
    setCurrentQ((q) => q + 1);
    if (currentQ + 1 >= totalQ && isAuthenticated) {
      const finalScore = Math.round(((score + (selectedAnswer === currentQuestion?.correctAnswer ? 1 : 0)) / totalQ) * 100);
      saveScore.mutate({ totalQuestions: totalQ, correctAnswers: score + (selectedAnswer === currentQuestion?.correctAnswer ? 1 : 0), score: finalScore, difficulty: quizDifficulty || "debutant" });
    }
  };

  const restart = () => {
    setCurrentQ(0); setSelectedAnswer(null); setShowResult(false); setScore(0); setAnswers([]); setStarted(false);
  };

  if (!started) {
    return (
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
        <div className="max-w-xl mx-auto text-center">
          <div className="w-16 h-16 rounded-2xl bg-[#2E7D5B]/10 flex items-center justify-center mx-auto mb-6">
            <Target size={32} className="text-[#2E7D5B]" />
          </div>
          <h2 className="text-2xl font-bold text-[#344453] mb-3">Tester mes connaissances</h2>
          <p className="text-[#344453]/80 mb-8">QCM, Vrai/Faux et questions à compléter. Testez votre maîtrise du vocabulaire financier.</p>
          <div className="bg-white rounded-2xl p-6 border border-[#D0D5DA] mb-6 text-left">
            <p className="text-sm font-semibold text-[#344453] mb-4">Paramètres du quiz</p>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-[#344453]/80 mb-1 block">Nombre de questions</label>
                <select value={quizCount} onChange={(e) => setQuizCount(Number(e.target.value))} className="w-full px-3 py-2.5 bg-[#F4F5F5] rounded-lg border border-[#D0D5DA] text-sm">
                  <option value={5}>5 questions</option>
                  <option value={10}>10 questions</option>
                  <option value={20}>20 questions</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-[#344453]/80 mb-1 block">Difficulté</label>
                <select value={quizDifficulty} onChange={(e) => setQuizDifficulty(e.target.value)} className="w-full px-3 py-2.5 bg-[#F4F5F5] rounded-lg border border-[#D0D5DA] text-sm">
                  <option value="">Mélangé</option>
                  {Object.entries(LEVEL_LABELS).map(([k, v]) => (<option key={k} value={k}>{v}</option>))}
                </select>
              </div>
            </div>
          </div>
          <button onClick={() => setStarted(true)} className="inline-flex items-center gap-2 px-8 py-4 bg-[#2E7D5B] text-[#344453] font-semibold rounded-xl hover:bg-[#2E7D5B]/90 transition-colors shadow-lg shadow-[#2E7D5B]/15">
            <Play size={18} /> Lancer le quiz
          </button>
        </div>
      </motion.div>
    );
  }

  if (isFinished) {
    const pct = Math.round((score / totalQ) * 100);
    return (
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
        <div className="max-w-md mx-auto text-center">
          <div className="w-20 h-20 rounded-full bg-[#2E7D5B]/10 flex items-center justify-center mx-auto mb-6">
            {pct >= 70 ? <Award size={36} className="text-[#2E7D5B]" /> : <Target size={36} className="text-[#C4A052]" />}
          </div>
          <h2 className="text-2xl font-bold text-[#344453] mb-2">
            {pct >= 90 ? "Excellent !" : pct >= 70 ? "Bien joué !" : pct >= 50 ? "Pas mal !" : "Continuez !"}
          </h2>
          <p className="text-4xl font-bold text-[#344453] mb-2">{pct}%</p>
          <p className="text-[#344453]/80 mb-8">{score} bonne{score > 1 ? "s" : ""} réponse{score > 1 ? "s" : ""} sur {totalQ}</p>
          <div className="flex flex-wrap gap-2 justify-center mb-8">
            {answers.map((correct, i) => (
              <div key={i} className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${correct ? "bg-[#2E7D5B]/15 text-[#2E7D5B]" : "bg-[#B0413E]/15 text-[#B0413E]"}`}>{i + 1}</div>
            ))}
          </div>
          <button onClick={restart} className="inline-flex items-center gap-2 px-6 py-3 bg-[#2E7D5B] text-[#344453] font-semibold rounded-xl hover:bg-[#2E7D5B]/90 transition-colors">
            <RotateCcw size={16} /> Nouveau quiz
          </button>
        </div>
      </motion.div>
    );
  }

  if (!currentQuestion) return null;
  const options: string[] = JSON.parse(currentQuestion.options);

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
      <div className="max-w-xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm text-[#344453]/80">Question {currentQ + 1} / {totalQ}</span>
          <span className="text-sm font-medium text-[#2E7D5B]">{score} correct{score > 1 ? "es" : ""}</span>
        </div>
        <div className="h-2 bg-[#D0D5DA] rounded-full overflow-hidden mb-8">
          <div className="h-full bg-[#2E7D5B] rounded-full transition-all duration-300" style={{ width: `${((currentQ) / totalQ) * 100}%` }} />
        </div>

        <div className="bg-white rounded-2xl border border-[#D0D5DA] p-8 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-[#344453]/10 text-[#344453]">
              {currentQuestion.questionType === "qcm" ? "QCM" : currentQuestion.questionType === "vrai_faux" ? "Vrai / Faux" : "Compléter"}
            </span>
            <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full" style={{ backgroundColor: LEVEL_CONFIG[currentQuestion.difficulty]?.bg, color: LEVEL_CONFIG[currentQuestion.difficulty]?.color }}>
              {LEVEL_LABELS[currentQuestion.difficulty]}
            </span>
          </div>
          <h3 className="text-lg font-semibold text-[#344453] leading-relaxed">{currentQuestion.question}</h3>
        </div>

        <div className="space-y-3 mb-6">
          {options.map((opt, i) => {
            const isSelected = selectedAnswer === String(i);
            const isCorrect = showResult && String(i) === currentQuestion.correctAnswer;
            const isWrong = showResult && isSelected && String(i) !== currentQuestion.correctAnswer;
            return (
              <button key={i} onClick={() => !showResult && setSelectedAnswer(String(i))} disabled={showResult} className={`w-full text-left px-5 py-4 rounded-xl border-2 transition-all text-sm ${isCorrect ? "border-[#2E7D5B] bg-[#2E7D5B]/10 text-[#2E7D5B]" : isWrong ? "border-[#B0413E] bg-[#B0413E]/10 text-[#B0413E]" : isSelected ? "border-[#344453] bg-[#344453]/5 text-[#344453]" : "border-[#D0D5DA] bg-white text-[#344453]/75 hover:border-[#344453]/30"}`}>
                <div className="flex items-center gap-3">
                  <span className="w-7 h-7 rounded-lg bg-[#F4F5F5] flex items-center justify-center text-xs font-bold shrink-0">{String.fromCharCode(65 + i)}</span>
                  <span>{opt}</span>
                  {isCorrect && <CheckCircle size={18} className="ml-auto text-[#2E7D5B]" />}
                  {isWrong && <XCircle size={18} className="ml-auto text-[#B0413E]" />}
                </div>
              </button>
            );
          })}
        </div>

        {showResult && currentQuestion.explanation && (
          <div className="bg-[#344453]/5 rounded-xl p-5 mb-6 border border-[#344453]/10">
            <p className="text-xs font-bold text-[#344453] mb-2">Explication</p>
            <p className="text-sm text-[#344453]/75 leading-relaxed">{currentQuestion.explanation}</p>
          </div>
        )}

        <div className="flex justify-center">
          {!showResult ? (
            <button onClick={handleSubmit} disabled={selectedAnswer === null} className="px-8 py-3 bg-[#2E7D5B] text-[#344453] font-semibold rounded-xl hover:bg-[#2E7D5B]/90 transition-colors disabled:opacity-40">Valider</button>
          ) : (
            <button onClick={handleNext} className="inline-flex items-center gap-2 px-8 py-3 bg-[#2E7D5B] text-[#344453] font-semibold rounded-xl hover:bg-[#2E7D5B]/90 transition-colors">
              {currentQ + 1 >= totalQ ? "Voir les résultats" : "Question suivante"} <ArrowRight size={16} />
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// MODE 4 — PARCOURS GUIDÉS
// ═══════════════════════════════════════════════════════════
export function ParcoursMode() {
  const { data: paths, isLoading } = trpc.glossaryV3.paths.useQuery();

  if (isLoading) {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (<div key={i} className="h-48 bg-white rounded-xl animate-pulse" />))}
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
      <div className="text-center mb-10">
        <h2 className="text-2xl font-bold text-[#344453] mb-3">Parcours guidés</h2>
        <p className="text-[#344453]/80 max-w-lg mx-auto">Des parcours thématiques pour apprendre progressivement. Chaque parcours se termine par un mini-quiz.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {paths?.map((path) => {
          const termIds: number[] = JSON.parse(path.termIds);
          const levelCfg = LEVEL_CONFIG[path.difficulty] || LEVEL_CONFIG.debutant;
          return (
            <div key={path.id} className="bg-white rounded-2xl overflow-hidden border border-[#D0D5DA] hover:shadow-lg hover:border-transparent transition-all group">
              <div className="h-1.5 w-full" style={{ backgroundColor: levelCfg.color }} />
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-[#344453]/8 flex items-center justify-center">
                    <Route size={24} className="text-[#344453]" />
                  </div>
                  <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full" style={{ backgroundColor: levelCfg.bg, color: levelCfg.color }}>
                    {LEVEL_LABELS[path.difficulty]}
                  </span>
                </div>
                <h3 className="font-bold text-[#344453] mb-2 group-hover:text-white transition-colors">{path.title}</h3>
                <p className="text-xs text-[#344453]/80 leading-relaxed mb-4 line-clamp-2">{path.description}</p>
                <div className="flex items-center gap-4 text-xs text-[#344453]/80">
                  <span className="flex items-center gap-1"><BookOpen size={12} />{termIds.length} termes</span>
                  <span className="flex items-center gap-1"><Clock size={12} />{path.estimatedMinutes} min</span>
                  <span className="flex items-center gap-1"><Target size={12} />{path.quizCount} quiz</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════
// MODE 5 — PROGRESSION
// ═══════════════════════════════════════════════════════════
export function ProgressionMode({ isAuthenticated }: { isAuthenticated: boolean }) {
  const { data: progress } = trpc.glossaryV3.userProgress.useQuery(undefined, { enabled: isAuthenticated });
  const { data: quizHistory } = trpc.glossaryV3.quizHistory.useQuery(undefined, { enabled: isAuthenticated });

  if (!isAuthenticated) {
    return (
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
        <div className="max-w-md mx-auto text-center py-12">
          <div className="w-16 h-16 rounded-2xl bg-[#B0413E]/10 flex items-center justify-center mx-auto mb-6">
            <Trophy size={32} className="text-[#B0413E]" />
          </div>
          <h2 className="text-2xl font-bold text-[#344453] mb-3">Suivez votre progression</h2>
          <p className="text-[#344453]/80 mb-8">Connectez-vous pour sauvegarder votre progression, vos scores et vos badges.</p>
          <Link href="/login" className="inline-flex items-center gap-2 px-6 py-3 bg-[#344453] text-white font-semibold rounded-xl hover:bg-[#344453]/90 transition-colors">Se connecter</Link>
        </div>
      </motion.div>
    );
  }

  const masteryPct = progress ? Math.round((progress.known / progress.total) * 100) : 0;
  const badge = masteryPct >= 75 ? "Avancé" : masteryPct >= 40 ? "Analyste" : masteryPct >= 10 ? "Explorateur" : "Débutant";
  const badgeColor = masteryPct >= 75 ? "#B0413E" : masteryPct >= 40 ? "#C4A052" : masteryPct >= 10 ? "#344453" : "#9CA3AF";

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
      <div className="max-w-3xl mx-auto">
        {/* Overview */}
        <div className="bg-white rounded-2xl p-8 border border-[#D0D5DA] mb-8">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 rounded-2xl flex items-center justify-center" style={{ backgroundColor: `${badgeColor}15` }}>
              <Award size={36} style={{ color: badgeColor }} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h2 className="text-xl font-bold text-[#344453]">Votre progression</h2>
                <span className="text-xs font-bold px-3 py-1 rounded-full" style={{ backgroundColor: `${badgeColor}15`, color: badgeColor }}>{badge}</span>
              </div>
              <p className="text-sm text-[#344453]/80 mb-3">Vous maîtrisez <span className="font-bold text-[#344453]">{masteryPct}%</span> du glossaire</p>
              <div className="h-3 bg-[#D0D5DA] rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-500" style={{ width: `${masteryPct}%`, backgroundColor: badgeColor }} />
              </div>
            </div>
          </div>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl p-5 border border-[#D0D5DA] text-center">
            <p className="text-2xl font-bold text-[#2E7D5B]">{progress?.known ?? 0}</p>
            <p className="text-xs text-[#344453]/80 mt-1">Termes maîtrisés</p>
          </div>
          <div className="bg-white rounded-xl p-5 border border-[#D0D5DA] text-center">
            <p className="text-2xl font-bold text-[#C4A052]">{progress?.review ?? 0}</p>
            <p className="text-xs text-[#344453]/80 mt-1">À revoir</p>
          </div>
          <div className="bg-white rounded-xl p-5 border border-[#D0D5DA] text-center">
            <p className="text-2xl font-bold text-[#344453]">{progress?.unseen ?? 0}</p>
            <p className="text-xs text-[#344453]/80 mt-1">Non vus</p>
          </div>
          <div className="bg-white rounded-xl p-5 border border-[#D0D5DA] text-center">
            <p className="text-2xl font-bold text-[#344453]">{quizHistory?.length ?? 0}</p>
            <p className="text-xs text-[#344453]/80 mt-1">Quiz complétés</p>
          </div>
        </div>

        {/* Quiz History */}
        {quizHistory && quizHistory.length > 0 && (
          <div className="bg-white rounded-2xl p-6 border border-[#D0D5DA] mb-8">
            <h3 className="font-bold text-[#344453] mb-4">Historique des quiz</h3>
            <div className="space-y-3">
              {quizHistory.slice(0, 10).map((q) => (
                <div key={q.id} className="flex items-center justify-between py-3 border-b border-[#D0D5DA] last:border-0">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${q.score >= 70 ? "bg-[#2E7D5B]/15" : "bg-[#C4A052]/15"}`}>
                      {q.score >= 70 ? <CheckCircle size={16} className="text-[#2E7D5B]" /> : <Target size={16} className="text-[#C4A052]" />}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-[#344453]">{q.correctAnswers}/{q.totalQuestions} correctes</p>
                      <p className="text-xs text-[#344453]/80">{new Date(q.completedAt).toLocaleDateString("fr-FR")}</p>
                    </div>
                  </div>
                  <span className={`text-lg font-bold ${q.score >= 70 ? "text-[#2E7D5B]" : "text-[#C4A052]"}`}>{q.score}%</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Badges */}
        <div className="bg-white rounded-2xl p-6 border border-[#D0D5DA]">
          <h3 className="font-bold text-[#344453] mb-4">Badges de progression</h3>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { name: "Explorateur", desc: "10% du glossaire", threshold: 10, color: "#344453", icon: Eye },
              { name: "Analyste", desc: "40% du glossaire", threshold: 40, color: "#C4A052", icon: BarChart3 },
              { name: "Avancé", desc: "75% du glossaire", threshold: 75, color: "#B0413E", icon: Star },
              { name: "Expert", desc: "100% du glossaire", threshold: 100, color: "#344453", icon: Award },
            ].map((b) => {
              const unlocked = masteryPct >= b.threshold;
              const Icon = b.icon;
              return (
                <div key={b.name} className={`rounded-xl p-4 text-center border ${unlocked ? "border-transparent" : "border-[#D0D5DA] opacity-40"}`} style={unlocked ? { backgroundColor: `${b.color}10` } : {}}>
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-2" style={{ backgroundColor: unlocked ? `${b.color}20` : "#F4F5F5" }}>
                    <Icon size={24} style={{ color: unlocked ? b.color : "#9CA3AF" }} />
                  </div>
                  <p className="text-sm font-semibold" style={{ color: unlocked ? b.color : "#9CA3AF" }}>{b.name}</p>
                  <p className="text-[11px] text-[#344453]/80 mt-0.5">{b.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════════
 * PremiumFeaturePreview — Présentation attractive d'une fonctionnalité premium
 * Remplace PremiumGate sur les pages publiques pour informer sans bloquer
 * ═══════════════════════════════════════════════════════════ */
function PremiumFeaturePreview({ icon: Icon, title, description, features }: {
  icon: any;
  title: string;
  description: string;
  features: string[];
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="max-w-2xl mx-auto"
    >
      <div className="bg-white rounded-2xl border border-[#E1E6EA] overflow-hidden shadow-sm">
        {/* Header gradient */}
        <div className="bg-gradient-to-br from-[#344453] to-[#4A6275] p-8 text-center">
          <div className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center mx-auto mb-5 border border-white/15">
            <Icon size={28} className="text-[#D4A853]" />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
          <p className="text-white/75 text-sm leading-relaxed max-w-md mx-auto">{description}</p>
        </div>
        {/* Features list */}
        <div className="p-8">
          <p className="text-xs font-bold text-[#1E1E1E]/50 uppercase tracking-widest mb-4">Ce qui est inclus</p>
          <div className="space-y-3 mb-8">
            {features.map((f) => (
              <div key={f} className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-[#2E7D5B]/10 flex items-center justify-center shrink-0">
                  <CheckCircle size={14} className="text-[#2E7D5B]" />
                </div>
                <span className="text-sm text-[#344453]">{f}</span>
              </div>
            ))}
          </div>
          <div className="text-center">
            <Link
              href="/pricing"
              className="inline-flex items-center gap-2 px-8 py-3.5 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#344453] font-bold rounded-xl hover:shadow-lg hover:shadow-[#D4A853]/20 transition-all text-sm"
            >
              <Crown size={16} />
              Découvrir les offres Premium
              <ArrowRight size={14} />
            </Link>
            <p className="text-xs text-[#1E1E1E]/50 mt-3">Accès complet à tous les outils d'apprentissage</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
