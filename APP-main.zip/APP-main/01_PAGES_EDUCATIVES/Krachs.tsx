/**
 * Krachs.tsx — Bibliothèque des krachs & crises historiques.
 * Fiches illustrées (1637 → 2023) : contexte, déclencheur, ampleur, déroulé,
 * conséquences et leçon. 100% informatif (voix WMB), aucune prédiction.
 */
import Layout from "@/components/Layout";
import PageBreadcrumb from "@/components/PageBreadcrumb";
import ConceptIllustration from "@/components/ConceptIllustration";
import CrashCurve from "@/components/CrashCurve";
import { Reveal } from "@/components/Reveal";
import HeroBackdrop from "@/components/HeroBackdrop";
import PoleCrossLinks from "@/components/PoleCrossLinks";
import { useSEO } from "@/hooks/useSEO";
import { usePageTitle } from "@/hooks/usePageTitle";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  MARKET_CRASHES,
  CRASH_ERAS,
  SEVERITY_META,
  type MarketCrash,
  type CrashEra,
} from "@/data/marketCrashes";
import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { ArrowRight, History, Info, TrendingDown, Flame, Activity, Hammer, Sprout, BookOpen, MapPin, CalendarClock } from "lucide-react";

export default function Krachs() {
  usePageTitle("Krachs & crises historiques — de 1637 à 2023");
  useSEO({
    title: `Krachs & Crises Boursières — ${MARKET_CRASHES.length} Effondrements Décryptés | WMB`,
    description:
      `De la tulipomanie de 1637 au krach crypto et aux crises bancaires : ${MARKET_CRASHES.length} krachs historiques expliqués — contexte, déclencheur, ampleur chiffrée, déroulé et leçon. 100% informatif.`,
    canonical: "/krachs",
  });

  const [active, setActive] = useState<CrashEra | "all">("all");
  const [selected, setSelected] = useState<MarketCrash | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const slug = new URLSearchParams(window.location.search).get("fiche");
    if (!slug) return;
    const found = MARKET_CRASHES.find((c) => c.slug === slug);
    if (found) setSelected(found);
  }, []);

  const list = useMemo(
    () => (active === "all" ? MARKET_CRASHES : MARKET_CRASHES.filter((c) => c.era === active)),
    [active],
  );

  return (
    <Layout>
      {/* ─── HERO ─── */}
      <section className="relative overflow-hidden min-h-[440px] lg:min-h-[500px] bg-[#23303c]">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a2530] via-[#2a3845] to-[#3a4b5a]" />
        <HeroBackdrop accent="#B0413E" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1a2530]/85 via-[#1a2530]/45 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1a2530]/55 to-transparent" />
        <div className="relative container py-16 lg:py-24 flex items-center min-h-[440px] lg:min-h-[500px]">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-[#B0413E]/20 border border-[#B0413E]/30 px-3 py-1.5 mb-6">
              <History size={14} className="text-[#E0A07A]" />
              <span className="text-[#E0A07A] text-xs font-semibold uppercase tracking-wider">Histoire des marchés</span>
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-[56px] font-bold text-white leading-[1.1] mb-5">
              Krachs &amp; crises,
              <br />
              <span className="text-[#E0A07A]">décryptés.</span>
            </h1>
            <p className="text-lg text-white/75 leading-relaxed mb-8 max-w-lg">
              {MARKET_CRASHES.length} effondrements de 1637 à 2023 — la tulipomanie, 1929, le Lundi noir, les subprimes,
              le Covid… Contexte, déclencheur, chiffres clés et la leçon à en tirer.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/glossaire?fiche=bulle-speculative" className="inline-flex items-center justify-center gap-2 rounded-lg bg-white px-7 py-3.5 text-base font-semibold text-[#344453] hover:bg-white/90 transition-colors">
                <BookOpen size={17} /> Qu'est-ce qu'une bulle ?
              </Link>
              <Link href="/formation-analyse?fiche=reconnaitre-une-bulle" className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/30 px-7 py-3.5 text-base font-medium text-white hover:bg-white/10 transition-colors">
                <Flame size={17} /> Reconnaître une bulle
              </Link>
            </div>
          </div>
        </div>
      </section>

      <div className="container">
        <PageBreadcrumb items={[{ label: "Krachs & crises" }]} />
      </div>

      {/* ─── DISCLAIMER ─── */}
      <section className="container">
        <div className="flex items-start gap-3 rounded-xl border border-[#C8A962]/30 bg-[#C8A962]/[0.07] px-4 py-3">
          <Info size={18} className="mt-0.5 shrink-0 text-[#8A6E18]" />
          <p className="text-sm text-[#344453]/85 leading-relaxed">
            <span className="font-semibold text-[#344453]">Contenu strictement informatif.</span> L'Histoire éclaire les
            mécanismes des crises, elle ne se répète jamais à l'identique. Rien ici n'est une prédiction ni un conseil.
          </p>
        </div>
      </section>

      {/* ─── FILTRES ─── */}
      <section className="container mt-8">
        <div className="flex flex-wrap gap-2">
          {CRASH_ERAS.map((e) => {
            const isActive = active === e.id;
            return (
              <button
                key={e.id}
                onClick={() => setActive(e.id)}
                className={`rounded-full px-4 py-2 text-sm font-semibold transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453] ${
                  isActive ? "bg-[#344453] text-white shadow-sm" : "bg-white text-[#344453]/80 border border-[#E1E6EA] hover:border-[#344453]/30"
                }`}
                aria-pressed={isActive}
              >
                {e.label}
              </button>
            );
          })}
        </div>
      </section>

      {/* ─── GRILLE ─── */}
      <section className="container mt-6 pb-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {list.map((c, i) => {
            const sev = SEVERITY_META[c.severity];
            return (
              <Reveal key={c.slug} index={i} className="h-full">
                <button
                  onClick={() => setSelected(c)}
                  className="group h-full w-full text-left flex flex-col rounded-2xl border border-[#E1E6EA] bg-white overflow-hidden hover:shadow-xl hover:-translate-y-1 hover:border-[#344453]/20 transition-all duration-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453]"
                  aria-label={`${c.name} — voir la fiche`}
                >
                  <div className="h-1 w-full" style={{ backgroundColor: sev.color }} />
                  <div className="relative overflow-hidden bg-gradient-to-br from-[#F8F9FA] to-[#F0F2F4] p-4 pb-2">
                    <span className="absolute top-3 left-3 z-10 inline-flex items-center gap-1 rounded-full bg-[#344453] px-2.5 py-0.5 text-[10px] font-bold text-white">
                      <CalendarClock size={10} /> {c.year}
                    </span>
                    <span
                      className="absolute top-3 right-3 z-10 inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-bold"
                      style={{ color: sev.color, backgroundColor: `${sev.color}1c` }}
                    >
                      {c.severity}
                    </span>
                    <div className="wmb-illu-zoom">
                      <ConceptIllustration type={c.illu} />
                    </div>
                  </div>
                  <div className="flex flex-1 flex-col p-5">
                    <h3 className="text-base font-bold text-[#344453]">{c.name}</h3>
                    <p className="mt-0.5 flex items-center gap-1 text-xs text-[#344453]/50">
                      <MapPin size={11} /> {c.region}
                    </p>
                    <p className="mt-2.5 text-sm text-[#344453]/75 leading-relaxed">{c.summary}</p>
                    <div className="mt-3 inline-flex w-fit items-center gap-1.5 rounded-lg bg-[#B0413E]/[0.07] border border-[#B0413E]/15 px-3 py-1.5">
                      <TrendingDown size={13} className="text-[#B0413E]" />
                      <span className="text-xs font-bold text-[#B0413E]">{c.drawdownLabel}</span>
                    </div>
                    {/* sparkline « anatomie » (animée, non interactive dans la carte) */}
                    <div className="mt-3 -mx-1">
                      <CrashCurve severity={c.severity} seed={c.slug} height={56} interactive={false} />
                    </div>
                    <div className="mt-auto pt-4 flex items-center justify-end">
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#344453] group-hover:gap-2 transition-all">
                        La fiche <ArrowRight size={13} />
                      </span>
                    </div>
                  </div>
                </button>
              </Reveal>
            );
          })}
        </div>

        <PoleCrossLinks current="hub" />
      </section>

      {/* ─── FICHE DÉTAIL ─── */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 gap-0">
          {selected && (() => {
            const sev = SEVERITY_META[selected.severity];
            return (
              <>
                {/* BANNIÈRE */}
                <div
                  className="relative overflow-hidden px-6 pt-7 pb-9"
                  style={{ background: `linear-gradient(135deg, ${sev.color} 0%, #1a2530 96%)` }}
                >
                  <History className="absolute -right-5 -top-5 text-white/10" size={150} strokeWidth={1.3} />
                  <DialogHeader className="relative text-left">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold text-white backdrop-blur-sm">
                        <CalendarClock size={12} /> {selected.year}
                      </span>
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-white backdrop-blur-sm">
                        {selected.severity}
                      </span>
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold text-white backdrop-blur-sm">
                        <MapPin size={12} /> {selected.region}
                      </span>
                    </div>
                    <DialogTitle className="mt-3 text-2xl lg:text-[28px] font-bold text-white leading-tight">{selected.name}</DialogTitle>
                    <p className="text-sm text-white/60">{selected.english}</p>
                  </DialogHeader>
                </div>

                {/* ILLUSTRATION */}
                <div className="relative -mt-5 px-6">
                  <div className="overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white shadow-md">
                    <div className="h-1 w-full" style={{ backgroundColor: sev.color }} />
                    <div className="wmb-illu-grid p-4">
                      <ConceptIllustration type={selected.illu} />
                    </div>
                    <p className="border-t border-[#F0F2F4] px-4 py-2.5 text-center text-xs italic text-[#344453]/55 leading-snug">
                      {selected.summary}
                    </p>
                  </div>
                </div>

                {/* CORPS */}
                <div className="px-6 py-5 space-y-4">
                  {/* courbe stylisée du krach (interactive) */}
                  <div className="overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white">
                    <div className="flex items-center justify-between px-4 pt-3">
                      <span className="text-[11px] font-bold uppercase tracking-wide text-[#344453]/55">Anatomie du krach</span>
                      <span className="text-[10px] text-[#344453]/40">sommet → effondrement → reprise</span>
                    </div>
                    <CrashCurve severity={selected.severity} seed={selected.slug} />
                    <p className="border-t border-[#F0F2F4] px-4 py-2 text-center text-[11px] italic text-[#344453]/50 leading-snug">
                      Forme caractéristique, illustrative — survolez la courbe pour lire le repli depuis le sommet.
                    </p>
                  </div>

                  {/* chiffres clés */}
                  <div className="grid grid-cols-3 gap-2.5">
                    {selected.keyFigures.map((k) => (
                      <div key={k.label} className="rounded-xl border border-[#E1E6EA] bg-[#F8F9FA] p-3 text-center">
                        <div className="text-sm font-bold text-[#344453] leading-tight">{k.value}</div>
                        <div className="mt-1 text-[10px] font-semibold uppercase tracking-wide text-[#344453]/50 leading-tight">{k.label}</div>
                      </div>
                    ))}
                  </div>

                  {[
                    { Icon: Sprout, label: "Le contexte", value: selected.context, color: "#2E7D5B" },
                    { Icon: Flame, label: "Le déclencheur", value: selected.trigger, color: "#B0413E" },
                    { Icon: TrendingDown, label: "L'ampleur", value: selected.magnitude, color: "#B0413E" },
                    { Icon: Activity, label: "Le déroulé", value: selected.unfolding, color: "#344453" },
                    { Icon: Hammer, label: "Les conséquences", value: selected.aftermath, color: "#8A6E18" },
                  ].map((item) => (
                    <div key={item.label} className="relative rounded-xl border border-[#E1E6EA] bg-white p-3.5 pl-5">
                      <span className="absolute left-0 top-3 bottom-3 w-1 rounded-full" style={{ backgroundColor: item.color }} />
                      <div className="flex items-center gap-1.5 text-xs font-bold" style={{ color: item.color }}>
                        <span className="inline-flex h-5 w-5 items-center justify-center rounded-md" style={{ backgroundColor: `${item.color}18` }}>
                          <item.Icon size={12} />
                        </span>
                        {item.label}
                      </div>
                      <p className="mt-1.5 text-sm text-[#344453]/75 leading-relaxed">{item.value}</p>
                    </div>
                  ))}

                  {/* leçon */}
                  <div className="rounded-xl bg-[#344453] p-5 text-white">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-[#C8A962] mb-2">La leçon à retenir</h4>
                    <p className="text-sm text-white/90 leading-relaxed">{selected.lesson}</p>
                  </div>

                  <div className="flex items-start gap-2 text-xs text-[#344453]/55 leading-relaxed">
                    <BookOpen size={14} className="mt-0.5 shrink-0" />
                    Synthèse historique simplifiée, à but pédagogique. L'Histoire éclaire les mécanismes — elle ne prédit
                    jamais l'avenir.
                  </div>
                </div>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
