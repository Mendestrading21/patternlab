/**
 * Figures Chartistes — bibliothèque interactive des patterns graphiques ET
 * des chandeliers japonais. 100% informatif, voix WMB (zéro signal, zéro conseil).
 * Schémas SVG originaux (PatternChart + CandleFigure).
 */
import Layout from "@/components/Layout";
import PageBreadcrumb from "@/components/PageBreadcrumb";
import PatternChart from "@/components/PatternChart";
import { Reveal } from "@/components/Reveal";
import CandleFigure from "@/components/CandleFigure";
import { useSEO } from "@/hooks/useSEO";
import HeroBackdrop from "@/components/HeroBackdrop";
import PoleCrossLinks from "@/components/PoleCrossLinks";
import {
  CHART_PATTERNS,
  CATEGORY_LABELS,
  PATTERN_CATEGORIES,
  type ChartPattern,
  type PatternCategory,
} from "@/data/chartPatterns";
import {
  CANDLESTICK_PATTERNS,
  CANDLE_GROUP_LABELS,
  CANDLE_GROUPS,
  type CandlestickPattern,
  type CandleGroup,
} from "@/data/candlestickPatterns";
import { getPatternCase } from "@/data/chartPatternCases";
import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  TrendingUp,
  TrendingDown,
  Minus,
  ShieldCheck,
  Target,
  LogIn,
  Octagon,
  ArrowRight,
  Info,
  Search,
  GraduationCap,
  LineChart,
  CandlestickChart,
  Eye,
  CheckCircle2,
  Brain,
  Trophy,
  RotateCcw,
  XCircle,
  Check,
  Landmark,
} from "lucide-react";

type Mode = "figures" | "chandeliers" | "quiz";

const BIAS_META: Record<string, { color: string; bg: string; Icon: typeof TrendingUp }> = {
  Haussier: { color: "#2E7D5B", bg: "rgba(46,125,91,0.10)", Icon: TrendingUp },
  Baissier: { color: "#B0413E", bg: "rgba(176,65,62,0.10)", Icon: TrendingDown },
  Neutre: { color: "#8A6E18", bg: "rgba(200,169,98,0.14)", Icon: Minus },
  Indécision: { color: "#8A6E18", bg: "rgba(200,169,98,0.14)", Icon: Minus },
};

const RELIABILITY_DOTS: Record<string, number> = { Élevée: 3, Moyenne: 2, Variable: 1 };

function ReliabilityDots({ level }: { level: string }) {
  const filled = RELIABILITY_DOTS[level] ?? 1;
  return (
    <span className="inline-flex items-center gap-1" title={`Fiabilité : ${level}`}>
      {[1, 2, 3].map((d) => (
        <span
          key={d}
          className="w-1.5 h-1.5 rounded-full"
          style={{ backgroundColor: d <= filled ? "#344453" : "#D0D5DA" }}
        />
      ))}
    </span>
  );
}

function BiasBadge({ bias }: { bias: string }) {
  const meta = BIAS_META[bias] ?? BIAS_META.Neutre;
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-bold"
      style={{ color: meta.color, backgroundColor: meta.bg }}
    >
      <meta.Icon size={12} /> {bias}
    </span>
  );
}

export default function FiguresChartistes() {
  const total = CHART_PATTERNS.length + CANDLESTICK_PATTERNS.length;
  useSEO({
    title: `Figures Chartistes & Chandeliers — ${total} Patterns Expliqués | WMB`,
    description: `Bibliothèque interactive : ${CHART_PATTERNS.length} figures chartistes (tête-épaules, drapeaux, triangles…) et ${CANDLESTICK_PATTERNS.length} chandeliers japonais (doji, marteau, avalement, étoiles…). Schémas clairs, lecture pédagogique. 100% informatif.`,
    canonical: "/figures-chartistes",
  });

  const [mode, setMode] = useState<Mode>("figures");
  const [activeCat, setActiveCat] = useState<PatternCategory | "all">("all");
  const [activeGroup, setActiveGroup] = useState<CandleGroup | "all">("all");
  const [query, setQuery] = useState("");
  const [selectedFigure, setSelectedFigure] = useState<ChartPattern | null>(null);
  const [selectedCandle, setSelectedCandle] = useState<CandlestickPattern | null>(null);

  // Ouverture directe d'une figure/chandelier via ?mode=&fiche=<slug> (recherche globale).
  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    const slug = params.get("fiche");
    if (!slug) return;
    const candle = CANDLESTICK_PATTERNS.find((p) => p.slug === slug);
    if (candle || params.get("mode") === "chandeliers") {
      setMode("chandeliers");
      if (candle) setSelectedCandle(candle);
      return;
    }
    const figure = CHART_PATTERNS.find((p) => p.slug === slug);
    if (figure) {
      setMode("figures");
      setSelectedFigure(figure);
    }
  }, []);

  const norm = (s: string) =>
    s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
  const q = norm(query.trim());
  const matches = (p: { name: string; english: string }) =>
    !q || norm(p.name).includes(q) || norm(p.english).includes(q);

  const figures = useMemo(
    () =>
      CHART_PATTERNS.filter((p) => (activeCat === "all" || p.category === activeCat) && matches(p)),
    [activeCat, q],
  );
  const candles = useMemo(
    () =>
      CANDLESTICK_PATTERNS.filter((p) => (activeGroup === "all" || p.group === activeGroup) && matches(p)),
    [activeGroup, q],
  );

  return (
    <Layout>
      {/* ─── HERO IMMERSIF ─── */}
      <section className="relative overflow-hidden min-h-[520px] lg:min-h-[600px]">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a2530] via-[#2a3845] to-[#3a4b5a]" />
        <HeroBackdrop accent="#D4A853" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1E1E1E]/95 via-[#344453]/85 to-[#344453]/55" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1E1E1E]/45 to-transparent" />

        <div className="relative container py-16 lg:py-24 flex items-center min-h-[520px] lg:min-h-[600px]">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center w-full">
            {/* Gauche */}
            <div>
              <span className="inline-flex items-center gap-2 rounded-full bg-[#D4A853]/20 border border-[#D4A853]/30 px-3 py-1.5 mb-6">
                <CandlestickChart size={14} className="text-[#D4A853]" />
                <span className="text-[#D4A853] text-xs font-semibold uppercase tracking-wider">Analyse technique · Bibliothèque</span>
              </span>
              <h1 className="text-4xl md:text-5xl lg:text-[56px] font-bold text-white leading-[1.1] mb-5">
                Figures Chartistes
                <br />
                <span className="text-[#D4A853]">& Chandeliers.</span>
              </h1>
              <p className="text-lg text-white/75 leading-relaxed mb-9 max-w-lg">
                {CHART_PATTERNS.length} figures graphiques et {CANDLESTICK_PATTERNS.length} chandeliers japonais
                expliqués clairement — schéma, lecture pédagogique et cadre conditionnel{" "}
                <span className="font-semibold text-white">SI / ALORS / SINON</span>.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/glossaire"
                  className="inline-flex items-center justify-center gap-2 rounded-lg bg-white px-7 py-3.5 text-base font-semibold text-[#344453] hover:bg-white/90 transition-colors"
                >
                  <Search size={17} /> Le glossaire
                </Link>
                <Link
                  href="/formation"
                  className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/30 px-7 py-3.5 text-base font-medium text-white hover:bg-white/10 transition-colors"
                >
                  <GraduationCap size={17} /> La formation
                </Link>
              </div>
            </div>

            {/* Droite — carte stats glassmorphism */}
            <div className="hidden lg:block">
              <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center">
                    <p className="text-4xl font-bold text-white">{CHART_PATTERNS.length}</p>
                    <p className="text-white/50 text-sm mt-1">Figures graphiques</p>
                  </div>
                  <div className="text-center">
                    <p className="text-4xl font-bold text-[#D4A853]">{CANDLESTICK_PATTERNS.length}</p>
                    <p className="text-white/50 text-sm mt-1">Chandeliers</p>
                  </div>
                  <div className="text-center">
                    <p className="text-4xl font-bold text-white">6</p>
                    <p className="text-white/50 text-sm mt-1">Catégories</p>
                  </div>
                  <div className="text-center">
                    <p className="text-4xl font-bold text-[#2E7D5B]">100%</p>
                    <p className="text-white/50 text-sm mt-1">Éducatif</p>
                  </div>
                </div>
                <div className="mt-6 pt-6 border-t border-white/10 text-center">
                  <p className="text-white/40 text-xs">Schémas originaux · Enrichi régulièrement</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="container">
        <PageBreadcrumb items={[{ label: "Figures Chartistes" }]} />
      </div>

      {/* ─── DISCLAIMER ÉDUCATIF ─── */}
      <section className="container">
        <div className="flex items-start gap-3 rounded-xl border border-[#C8A962]/30 bg-[#C8A962]/[0.07] px-4 py-3">
          <Info size={18} className="mt-0.5 shrink-0 text-[#8A6E18]" />
          <p className="text-sm text-[#344453]/85 leading-relaxed">
            <span className="font-semibold text-[#344453]">Contenu strictement informatif.</span> Ces fiches
            décrivent ce que les analystes observent. Aucune figure ne fonctionne à 100% — ce ne sont pas des
            signaux d'achat ou de vente, ni des conseils d'investissement.
          </p>
        </div>
      </section>

      {/* ─── SÉLECTEUR DE MODE ─── */}
      <section className="container mt-8">
        <div className="inline-flex rounded-xl border border-[#E1E6EA] bg-white p-1">
          {([
            { id: "figures", label: "Figures graphiques", Icon: LineChart, count: CHART_PATTERNS.length },
            { id: "chandeliers", label: "Chandeliers japonais", Icon: CandlestickChart, count: CANDLESTICK_PATTERNS.length },
            { id: "quiz", label: "Quiz", Icon: Brain, count: null },
          ] as const).map((m) => {
            const isActive = mode === m.id;
            return (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                className={`inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453] ${
                  isActive ? "bg-[#344453] text-white shadow-sm" : "text-[#344453]/70 hover:text-[#344453]"
                }`}
                aria-pressed={isActive}
              >
                <m.Icon size={16} /> {m.label}
                {m.count !== null && (
                  <span
                    className={`ml-0.5 rounded-full px-1.5 py-0.5 text-[10px] font-bold ${
                      isActive ? "bg-white/20 text-white" : "bg-[#F4F5F5] text-[#344453]/60"
                    }`}
                  >
                    {m.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </section>

      {/* ─── RECHERCHE + LÉGENDE ─── */}
      {mode !== "quiz" && (
      <section className="container mt-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative w-full sm:max-w-xs">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#344453]/40" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Rechercher une figure…"
              aria-label="Rechercher une figure"
              className="w-full rounded-xl border border-[#E1E6EA] bg-white py-2.5 pl-9 pr-3 text-sm text-[#344453] placeholder:text-[#344453]/40 focus:border-[#344453]/40 focus:outline-none"
            />
          </div>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-[#344453]/70">
            {[
              { c: "#344453", l: "Entrée" },
              { c: "#B0413E", l: "Stop" },
              { c: "#2E7D5B", l: "Objectif" },
            ].map((it) => (
              <span key={it.l} className="inline-flex items-center gap-1.5">
                <span className="h-0.5 w-4 rounded-full" style={{ backgroundColor: it.c }} />
                {it.l}
              </span>
            ))}
            <span className="inline-flex items-center gap-1.5">
              <span className="h-0 w-4 border-t border-dashed border-[#344453]" />
              Ligne de cou / tendance
            </span>
          </div>
        </div>
      </section>
      )}

      {/* ═══════════ MODE QUIZ ═══════════ */}
      {mode === "quiz" && <QuizMode />}

      {/* ═══════════ MODE FIGURES GRAPHIQUES ═══════════ */}
      {mode === "figures" && (
        <>
          <section className="container mt-6">
            <div className="flex flex-wrap gap-2">
              {PATTERN_CATEGORIES.map((cat) => {
                const isActive = activeCat === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setActiveCat(cat.id)}
                    className={`rounded-full px-4 py-2 text-sm font-semibold transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453] ${
                      isActive
                        ? "bg-[#344453] text-white shadow-sm"
                        : "bg-white text-[#344453]/80 border border-[#E1E6EA] hover:border-[#344453]/30"
                    }`}
                    aria-pressed={isActive}
                  >
                    {cat.label}
                  </button>
                );
              })}
            </div>
          </section>

          <section className="container mt-6 pb-20">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {figures.map((p, i) => {
                const cat = CATEGORY_LABELS[p.category];
                return (
                  <Reveal key={p.slug} index={i} className="h-full">
                  <button
                    onClick={() => setSelectedFigure(p)}
                    className="group h-full w-full text-left flex flex-col rounded-2xl border border-[#E1E6EA] bg-white overflow-hidden hover:shadow-xl hover:-translate-y-1 hover:border-[#344453]/20 transition-all duration-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453]"
                    aria-label={`${p.name} — voir la fiche`}
                  >
                    <div className="h-1 w-full" style={{ backgroundColor: cat.color }} />
                    <div className="relative overflow-hidden bg-gradient-to-br from-[#F8F9FA] to-[#F0F2F4] px-2 pt-2">
                      <span className="absolute top-3 left-3 z-10">
                        <BiasBadge bias={p.bias} />
                      </span>
                      <div className="wmb-illu-zoom">
                        <PatternChart spec={p.spec} height={180} />
                      </div>
                    </div>
                    <div className="flex flex-1 flex-col p-5">
                      <div className="flex items-center justify-between gap-2">
                        <h3 className="text-base font-bold text-[#344453]">{p.name}</h3>
                        <ReliabilityDots level={p.reliability} />
                      </div>
                      <p className="mt-0.5 text-xs text-[#344453]/50">{p.english}</p>
                      <p className="mt-2.5 text-sm text-[#344453]/75 leading-relaxed">{p.summary}</p>
                      <div className="mt-auto pt-4 flex items-center justify-between">
                        <span
                          className="inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold"
                          style={{ color: cat.color, backgroundColor: `${cat.color}14` }}
                        >
                          {cat.label}
                        </span>
                        <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#344453] group-hover:gap-2 transition-all">
                          Détails <ArrowRight size={13} />
                        </span>
                      </div>
                    </div>
                  </button>
                  </Reveal>
                );
              })}
            </div>
          </section>
        </>
      )}

      {/* ═══════════ MODE CHANDELIERS ═══════════ */}
      {mode === "chandeliers" && (
        <>
          <CandleAnatomy />
          <section className="container mt-6">
            <div className="flex flex-wrap gap-2">
              {CANDLE_GROUPS.map((g) => {
                const isActive = activeGroup === g.id;
                return (
                  <button
                    key={g.id}
                    onClick={() => setActiveGroup(g.id)}
                    className={`rounded-full px-4 py-2 text-sm font-semibold transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453] ${
                      isActive
                        ? "bg-[#344453] text-white shadow-sm"
                        : "bg-white text-[#344453]/80 border border-[#E1E6EA] hover:border-[#344453]/30"
                    }`}
                    aria-pressed={isActive}
                  >
                    {g.label}
                  </button>
                );
              })}
            </div>
          </section>

          <section className="container mt-6 pb-20">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {candles.map((p, i) => {
                const grp = CANDLE_GROUP_LABELS[p.group];
                return (
                  <Reveal key={p.slug} index={i} className="h-full">
                  <button
                    onClick={() => setSelectedCandle(p)}
                    className="group h-full w-full text-left flex flex-col rounded-2xl border border-[#E1E6EA] bg-white overflow-hidden hover:shadow-xl hover:-translate-y-1 hover:border-[#344453]/20 transition-all duration-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453]"
                    aria-label={`${p.name} — voir la fiche`}
                  >
                    <div className="h-1 w-full" style={{ backgroundColor: grp.color }} />
                    <div className="relative overflow-hidden bg-gradient-to-br from-[#F8F9FA] to-[#F0F2F4] px-2 pt-2">
                      <span className="absolute top-3 left-3 z-10">
                        <BiasBadge bias={p.bias} />
                      </span>
                      <span className="absolute top-3 right-3 z-10 rounded-full bg-white/80 px-2 py-0.5 text-[10px] font-bold text-[#344453]/70">
                        {p.candleCount} bougie{p.candleCount > 1 ? "s" : ""}
                      </span>
                      <div className="wmb-illu-zoom">
                        <CandleFigure candles={p.candles} patternFrom={p.patternFrom} height={180} />
                      </div>
                    </div>
                    <div className="flex flex-1 flex-col p-5">
                      <div className="flex items-center justify-between gap-2">
                        <h3 className="text-base font-bold text-[#344453]">{p.name}</h3>
                        <ReliabilityDots level={p.reliability} />
                      </div>
                      <p className="mt-0.5 text-xs text-[#344453]/50">{p.english}</p>
                      <p className="mt-2.5 text-sm text-[#344453]/75 leading-relaxed">{p.summary}</p>
                      <div className="mt-auto pt-4 flex items-center justify-between">
                        <span
                          className="inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold"
                          style={{ color: grp.color, backgroundColor: `${grp.color}14` }}
                        >
                          {grp.label}
                        </span>
                        <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#344453] group-hover:gap-2 transition-all">
                          Détails <ArrowRight size={13} />
                        </span>
                      </div>
                    </div>
                  </button>
                  </Reveal>
                );
              })}
            </div>
          </section>
        </>
      )}

      {/* ─── MAILLAGE DU PÔLE ─── */}
      <section className="container pb-16">
        <PoleCrossLinks current="figures" />
      </section>

      {/* ─── FICHE DÉTAIL : FIGURE GRAPHIQUE ─── */}
      <Dialog open={!!selectedFigure} onOpenChange={(o) => !o && setSelectedFigure(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 gap-0">
          {selectedFigure && (
            <>
              {/* ─── BANNIÈRE COLORÉE (par catégorie) ─── */}
              <div
                className="relative overflow-hidden px-6 pt-7 pb-9"
                style={{ background: `linear-gradient(135deg, ${CATEGORY_LABELS[selectedFigure.category].color} 0%, #1a2530 96%)` }}
              >
                <LineChart className="absolute -right-5 -top-5 text-white/10" size={150} strokeWidth={1.3} />
                <DialogHeader className="relative text-left">
                  <div className="flex items-center gap-2 flex-wrap">
                    <BiasBadge bias={selectedFigure.bias} />
                    <span className="inline-flex items-center rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-white backdrop-blur-sm">
                      {CATEGORY_LABELS[selectedFigure.category].label}
                    </span>
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold text-white backdrop-blur-sm">
                      <ShieldCheck size={12} /> Fiabilité : {selectedFigure.reliability}
                    </span>
                  </div>
                  <DialogTitle className="mt-3 text-2xl lg:text-[28px] font-bold text-white leading-tight">
                    {selectedFigure.name}
                  </DialogTitle>
                  <p className="text-sm text-white/60">{selectedFigure.english}</p>
                </DialogHeader>
              </div>

              {/* ─── SCHÉMA (chevauche la bannière) ─── */}
              <div className="relative -mt-5 px-6">
                <div className="overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white shadow-md">
                  <div className="h-1 w-full" style={{ backgroundColor: CATEGORY_LABELS[selectedFigure.category].color }} />
                  <div className="bg-gradient-to-br from-[#F8F9FA] to-[#F0F2F4] p-2">
                    <PatternChart spec={selectedFigure.spec} height={240} />
                  </div>
                  <p className="border-t border-[#F0F2F4] px-4 py-2.5 text-center text-xs italic text-[#344453]/55 leading-snug">
                    {selectedFigure.summary}
                  </p>
                </div>
              </div>

              <div className="px-6 py-5 space-y-5">
                <p className="text-sm text-[#344453]/85 leading-relaxed">{selectedFigure.description}</p>

                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#344453]/60 mb-3">
                    Comment les analystes la lisent
                  </h4>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {[
                      { Icon: Target, label: "Signal", value: selectedFigure.reading.signal, color: "#344453" },
                      { Icon: LogIn, label: "Entrée", value: selectedFigure.reading.entry, color: "#344453" },
                      { Icon: Octagon, label: "Stop", value: selectedFigure.reading.stop, color: "#B0413E" },
                      { Icon: Target, label: "Objectif", value: selectedFigure.reading.target, color: "#2E7D5B" },
                    ].map((item) => (
                      <div key={item.label} className="rounded-xl border border-[#E1E6EA] bg-white p-3.5">
                        <div className="flex items-center gap-1.5 text-xs font-bold" style={{ color: item.color }}>
                          <item.Icon size={13} /> {item.label}
                        </div>
                        <p className="mt-1.5 text-sm text-[#344453]/75 leading-snug">{item.value}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {(() => {
                  const rc = getPatternCase(selectedFigure.slug);
                  if (!rc) return null;
                  return (
                    <div className="rounded-xl border border-[#C8A962]/35 bg-[#C8A962]/[0.08] p-4">
                      <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#8A6E18]">
                        <Landmark size={13} /> Cas réel — {rc.title}
                      </div>
                      <p className="mt-2 text-sm text-[#344453]/85 leading-relaxed">{rc.detail}</p>
                    </div>
                  );
                })()}

                <ScenarioBlock scenario={selectedFigure.scenario} />
                <DisclaimerLine />
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* ─── FICHE DÉTAIL : CHANDELIER ─── */}
      <Dialog open={!!selectedCandle} onOpenChange={(o) => !o && setSelectedCandle(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-0 gap-0">
          {selectedCandle && (
            <>
              {/* ─── BANNIÈRE COLORÉE (par groupe) ─── */}
              <div
                className="relative overflow-hidden px-6 pt-7 pb-9"
                style={{ background: `linear-gradient(135deg, ${CANDLE_GROUP_LABELS[selectedCandle.group].color} 0%, #1a2530 96%)` }}
              >
                <CandlestickChart className="absolute -right-5 -top-5 text-white/10" size={150} strokeWidth={1.3} />
                <DialogHeader className="relative text-left">
                  <div className="flex items-center gap-2 flex-wrap">
                    <BiasBadge bias={selectedCandle.bias} />
                    <span className="inline-flex items-center rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-white backdrop-blur-sm">
                      {CANDLE_GROUP_LABELS[selectedCandle.group].label}
                    </span>
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold text-white backdrop-blur-sm">
                      <ShieldCheck size={12} /> Fiabilité : {selectedCandle.reliability}
                    </span>
                  </div>
                  <DialogTitle className="mt-3 text-2xl lg:text-[28px] font-bold text-white leading-tight">
                    {selectedCandle.name}
                  </DialogTitle>
                  <p className="text-sm text-white/60">
                    {selectedCandle.english} · {selectedCandle.candleCount} bougie
                    {selectedCandle.candleCount > 1 ? "s" : ""}
                  </p>
                </DialogHeader>
              </div>

              {/* ─── SCHÉMA (chevauche la bannière) ─── */}
              <div className="relative -mt-5 px-6">
                <div className="overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white shadow-md">
                  <div className="h-1 w-full" style={{ backgroundColor: CANDLE_GROUP_LABELS[selectedCandle.group].color }} />
                  <div className="bg-gradient-to-br from-[#F8F9FA] to-[#F0F2F4] p-2">
                    <CandleFigure candles={selectedCandle.candles} patternFrom={selectedCandle.patternFrom} height={240} />
                  </div>
                  <p className="border-t border-[#F0F2F4] px-4 py-2.5 text-center text-xs italic text-[#344453]/55 leading-snug">
                    {selectedCandle.summary}
                  </p>
                </div>
              </div>

              <div className="px-6 py-5 space-y-5">
                <p className="text-sm text-[#344453]/85 leading-relaxed">{selectedCandle.description}</p>

                <div className="grid sm:grid-cols-2 gap-3">
                  <div className="rounded-xl border border-[#E1E6EA] bg-white p-3.5">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#344453]">
                      <Eye size={13} /> Ce qu'il indique
                    </div>
                    <p className="mt-1.5 text-sm text-[#344453]/75 leading-snug">{selectedCandle.indicates}</p>
                  </div>
                  <div className="rounded-xl border border-[#E1E6EA] bg-white p-3.5">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#2E7D5B]">
                      <CheckCircle2 size={13} /> Fiabilité & contexte
                    </div>
                    <p className="mt-1.5 text-sm text-[#344453]/75 leading-snug">{selectedCandle.context}</p>
                  </div>
                </div>

                <ScenarioBlock scenario={selectedCandle.scenario} />
                <DisclaimerLine />
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </Layout>
  );
}

function ScenarioBlock({ scenario }: { scenario: { si: string; alors: string; sinon: string } }) {
  return (
    <div className="rounded-xl bg-[#344453] p-5 text-white">
      <h4 className="text-xs font-bold uppercase tracking-wider text-[#C8A962] mb-3">Scénario conditionnel</h4>
      <ul className="space-y-2.5 text-sm leading-relaxed">
        <li>
          <span className="font-bold text-[#C8A962]">SI</span>{" "}
          <span className="text-white/85">{scenario.si}</span>
        </li>
        <li>
          <span className="font-bold text-[#7FB89E]">ALORS</span>{" "}
          <span className="text-white/85">{scenario.alors}</span>
        </li>
        <li>
          <span className="font-bold text-[#E0A07A]">SINON</span>{" "}
          <span className="text-white/85">{scenario.sinon}</span>
        </li>
      </ul>
    </div>
  );
}

function DisclaimerLine() {
  return (
    <div className="flex items-start gap-2 text-xs text-[#344453]/55 leading-relaxed">
      <Info size={14} className="mt-0.5 shrink-0" />
      Lecture pédagogique du schéma, jamais un signal d'achat/vente. Une figure peut échouer (faux signal) — le
      volume et le contexte de marché restent déterminants.
    </div>
  );
}

function CandleAnatomy() {
  return (
    <section className="container mt-6">
      <div className="rounded-2xl border border-[#E1E6EA] bg-white p-5 sm:p-6">
        <div className="grid items-center gap-6 sm:grid-cols-[180px_1fr]">
          <svg viewBox="0 0 200 220" width="100%" role="img" aria-label="Anatomie d'une bougie japonaise" className="max-w-[180px] mx-auto sm:mx-0">
            {/* bougie haussière (verte) */}
            <line x1={56} x2={56} y1={20} y2={70} stroke="#2E7D5B" strokeWidth={2} strokeLinecap="round" />
            <line x1={56} x2={56} y1={150} y2={200} stroke="#2E7D5B" strokeWidth={2} strokeLinecap="round" />
            <rect x={42} y={70} width={28} height={80} rx={2} fill="#2E7D5B" />
            <text x={56} y={213} textAnchor="middle" fontSize="11" fontWeight="700" fill="#2E7D5B">Hausse</text>
            {/* bougie baissière (rouge) */}
            <line x1={140} x2={140} y1={30} y2={78} stroke="#B0413E" strokeWidth={2} strokeLinecap="round" />
            <line x1={140} x2={140} y1={158} y2={205} stroke="#B0413E" strokeWidth={2} strokeLinecap="round" />
            <rect x={126} y={78} width={28} height={80} rx={2} fill="#B0413E" />
            <text x={140} y={213} textAnchor="middle" fontSize="11" fontWeight="700" fill="#B0413E">Baisse</text>
            {/* repères */}
            <line x1={70} x2={92} y1={70} y2={70} stroke="#344453" strokeWidth={1} strokeDasharray="2 2" />
            <text x={95} y={73} fontSize="10" fill="#344453">Clôture</text>
            <line x1={70} x2={92} y1={150} y2={150} stroke="#344453" strokeWidth={1} strokeDasharray="2 2" />
            <text x={95} y={153} fontSize="10" fill="#344453">Ouverture</text>
            <text x={56} y={14} textAnchor="middle" fontSize="9" fill="#344453" opacity={0.7}>plus haut</text>
          </svg>
          <div>
            <h2 className="text-lg font-bold text-[#344453]">Anatomie d'une bougie</h2>
            <div className="mt-1 w-10 h-1 rounded-full bg-[#C8A962]" />
            <ul className="mt-4 space-y-2.5 text-sm text-[#344453]/80 leading-relaxed">
              <li className="flex items-start gap-2.5">
                <span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-sm bg-[#2E7D5B]" />
                <span><span className="font-semibold text-[#344453]">Corps</span> — l'écart entre l'ouverture et la clôture. Vert si la clôture est plus haute (hausse), rouge si elle est plus basse (baisse).</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="mt-1.5 h-2.5 w-0.5 shrink-0 rounded-full bg-[#344453]" />
                <span><span className="font-semibold text-[#344453]">Mèches</span> — les fins traits au-dessus et en dessous marquent le plus haut et le plus bas atteints dans la séance.</span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-[#C8A962]" />
                <span><span className="font-semibold text-[#344453]">À retenir</span> — un grand corps traduit une forte conviction ; de longues mèches traduisent un rejet des prix ou de l'indécision.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

type QuizItem =
  | { name: string; kind: "figure"; spec: ChartPattern["spec"]; tag: string }
  | { name: string; kind: "candle"; candles: CandlestickPattern["candles"]; patternFrom: number; tag: string };

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function QuizMode() {
  const pool = useMemo<QuizItem[]>(
    () => [
      ...CHART_PATTERNS.map((p) => ({ name: p.name, kind: "figure" as const, spec: p.spec, tag: CATEGORY_LABELS[p.category].label })),
      ...CANDLESTICK_PATTERNS.map((p) => ({ name: p.name, kind: "candle" as const, candles: p.candles, patternFrom: p.patternFrom, tag: CANDLE_GROUP_LABELS[p.group].label })),
    ],
    [],
  );

  const makeQuestion = () => {
    const item = pool[Math.floor(Math.random() * pool.length)];
    const sameKind = pool.filter((p) => p.kind === item.kind && p.name !== item.name);
    const distractors = shuffle(sameKind).slice(0, 3).map((p) => p.name);
    return { item, options: shuffle([item.name, ...distractors]) };
  };

  const [q, setQ] = useState(makeQuestion);
  const [picked, setPicked] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [count, setCount] = useState(0);
  const [streak, setStreak] = useState(0);
  const [best, setBest] = useState(0);

  const answer = (name: string) => {
    if (picked) return;
    setPicked(name);
    setCount((c) => c + 1);
    const correct = name === q.item.name;
    if (correct) setScore((s) => s + 1);
    const newStreak = correct ? streak + 1 : 0;
    setStreak(newStreak);
    setBest((b) => Math.max(b, newStreak));
  };

  const next = () => {
    setPicked(null);
    setQ(makeQuestion());
  };
  const reset = () => {
    setPicked(null);
    setScore(0);
    setCount(0);
    setStreak(0);
    setBest(0);
    setQ(makeQuestion());
  };

  return (
    <section className="container mt-6 pb-20">
      <div className="mx-auto max-w-2xl">
        <div className="mb-5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm">
            <Trophy size={16} className="text-[#C8A962]" />
            <span className="font-bold text-[#344453]">{score}</span>
            <span className="text-[#344453]/50">/ {count}</span>
            <span className="ml-3 text-[#344453]/50">Série</span>
            <span className="font-bold text-[#2E7D5B]">{streak}</span>
            {best > 0 && <span className="text-[#344453]/40">· record {best}</span>}
          </div>
          <button onClick={reset} className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#344453]/60 hover:text-[#344453] transition-colors">
            <RotateCcw size={13} /> Réinitialiser
          </button>
        </div>

        <div className="overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white">
          <div className="relative bg-gradient-to-br from-[#F8F9FA] to-[#F0F2F4] px-3 pt-3">
            <span className="absolute top-4 left-4 z-10 rounded-full bg-white/80 px-2.5 py-1 text-[11px] font-semibold text-[#344453]/70">
              {q.item.kind === "figure" ? "Figure graphique" : "Chandelier"} · {q.item.tag}
            </span>
            {q.item.kind === "figure" ? (
              <PatternChart spec={q.item.spec} height={240} showLevels={false} />
            ) : (
              <CandleFigure candles={q.item.candles} patternFrom={q.item.patternFrom} height={240} />
            )}
          </div>
          <div className="p-5">
            <p className="mb-3 text-sm font-semibold text-[#344453]">Quelle est cette figure ?</p>
            <div className="grid gap-2.5 sm:grid-cols-2">
              {q.options.map((opt) => {
                const isCorrect = opt === q.item.name;
                const isPicked = opt === picked;
                let cls = "border-[#E1E6EA] hover:border-[#344453]/40 text-[#344453]";
                if (picked) {
                  if (isCorrect) cls = "border-[#2E7D5B] bg-[#2E7D5B]/[0.07] text-[#2E7D5B]";
                  else if (isPicked) cls = "border-[#B0413E] bg-[#B0413E]/[0.07] text-[#B0413E]";
                  else cls = "border-[#E1E6EA] text-[#344453]/40";
                }
                return (
                  <button
                    key={opt}
                    onClick={() => answer(opt)}
                    disabled={!!picked}
                    className={`flex items-center justify-between gap-2 rounded-xl border px-4 py-3 text-left text-sm font-medium transition-all ${cls}`}
                  >
                    {opt}
                    {picked && isCorrect && <Check size={16} className="shrink-0" />}
                    {picked && isPicked && !isCorrect && <XCircle size={16} className="shrink-0" />}
                  </button>
                );
              })}
            </div>

            {picked && (
              <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-sm">
                  {picked === q.item.name ? (
                    <span className="font-semibold text-[#2E7D5B]">Bravo, c'est bien {q.item.name}.</span>
                  ) : (
                    <span className="font-semibold text-[#B0413E]">Raté — c'était {q.item.name}.</span>
                  )}
                </p>
                <button
                  onClick={next}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#344453] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#2a3a47] transition-colors"
                >
                  Question suivante <ArrowRight size={15} />
                </button>
              </div>
            )}
          </div>
        </div>

        <p className="mt-4 text-center text-xs text-[#344453]/45">
          Entraînement ludique · {pool.length} figures et chandeliers · 100% informatif
        </p>
      </div>
    </section>
  );
}
