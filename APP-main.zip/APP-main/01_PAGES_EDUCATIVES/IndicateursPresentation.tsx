/**
 * IndicateursPresentation — Page publique de présentation des Indicateurs WMB
 * Format identique à Formation.tsx : hero immersif, sections explicatives, CTA pricing
 * Aucun outil interactif — les fiches sont uniquement dans /dashboard/indicateurs
 */
import Layout from "@/components/Layout";
import { useAuth } from "@/_core/hooks/useAuth";
import { useSubscription } from "@/hooks/useSubscription";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Activity, Clock, BookOpen, ChevronRight, TrendingUp,
  BarChart3, BarChart2, Layers, Gauge,
  ArrowRight, CheckCircle2, Crown, Target, Shield,
  Zap, Lightbulb, Star, Eye,
  GraduationCap, Brain, CandlestickChart, Building2, Combine,
} from "lucide-react";
import { useSEO } from "@/hooks/useSEO";
import { SEO_PAGES } from "@/lib/seoConfig";
import { INDICATORS as INDICATORS_CONFIG } from "@shared/siteConfig";
import { INDICATORS as FREE_INDICATORS } from "@/data/indicators";
import PageBreadcrumb from "@/components/PageBreadcrumb";
import { usePageTitle } from "@/hooks/usePageTitle";
import HeroBackdrop from "@/components/HeroBackdrop";
import CountUp from "@/components/CountUp";
import ConceptIllustration, { type ConceptType } from "@/components/ConceptIllustration";
import { getLoginUrl } from "@/const";
import IndicatorsLibrary from "@/components/IndicatorsLibrary";

/* ─── Animations ─── */
const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.08, duration: 0.5, ease: [0, 0, 0.2, 1] as [number, number, number, number] },
  }),
};

const CATEGORY_CARDS = [
  { icon: TrendingUp, label: "Tendance", count: "9", desc: "Moyennes mobiles, Ichimoku, ADX, SuperTrend, Parabolic SAR...", color: "#344453" },
  { icon: Gauge, label: "Momentum", count: "10", desc: "MACD, RSI, Stochastique, CCI, ROC, Williams %R, TSI...", color: "#2E7D5B" },
  { icon: Activity, label: "Volatilité", count: "7", desc: "Bollinger, ATR, Keltner, Donchian, VIX, Chaikin Volatility...", color: "#D4A853" },
  { icon: BarChart2, label: "Volume", count: "7", desc: "OBV, VWAP, A/D Line, MFI, CMF, Volume Profile...", color: "#344453" },
  { icon: CandlestickChart, label: "Patterns", count: "6", desc: "Supports/résistances, Fibonacci, chandeliers, figures chartistes...", color: "#B0413E" },
  { icon: Building2, label: "Structure", count: "6", desc: "Largeur de marché, rotation sectorielle, analyse intermarché...", color: "#344453" },
  { icon: Shield, label: "Institutionnel", count: "5", desc: "Put/Call ratio, COT, Dark Pools, Yield Curve, AAII Sentiment...", color: "#7A6A5A" },
  { icon: Combine, label: "Synthèse", count: "5", desc: "Triple Screen, Ichimoku complet, divergences, Squeeze, régimes...", color: "#B0413E" },
];

export default function IndicateursPresentation() {
  usePageTitle(SEO_PAGES.indicateurs?.title || "Indicateurs Techniques — WMB");
  useSEO(SEO_PAGES.indicateurs);

  const { isAuthenticated } = useAuth();
  const { canAccess } = useSubscription();
  const hasAccess = canAccess("formation:lesson");

  return (
    <Layout>
      {/* ═══════════ IMMERSIVE HERO ═══════════ */}
      <section className="relative overflow-hidden min-h-[600px] lg:min-h-[700px]">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a2530] via-[#2a3845] to-[#3a4b5a]" />
        <HeroBackdrop accent="#D4A853" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1a2530]/95 via-[#344453]/85 to-[#344453]/70" />
        <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-[#D4A853]/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#344453]/20 rounded-full blur-[100px]" />

        <div className="relative container py-20 lg:py-32">
          <PageBreadcrumb items={[{ label: "Académie", href: "/formation" }, { label: "Indicateurs" }]} className="mb-8" />
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left — Text */}
            <div>
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/15 backdrop-blur-sm mb-8"
              >
                <Activity size={16} className="text-[#D4A853]" />
                <span className="text-white/90 text-sm font-medium">Encyclopédie Technique</span>
                <span className="w-px h-4 bg-white/30" />
                <span className="text-[#D4A853] text-xs font-bold">{FREE_INDICATORS.length} indicateurs</span>
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.1 }}
                className="text-4xl md:text-5xl lg:text-[56px] font-bold text-white leading-[1.08] mb-6"
              >
                Maîtrisez les{" "}
                <span className="bg-gradient-to-r from-[#D4A853] to-[#E8C97A] bg-clip-text text-transparent">
                  indicateurs techniques.
                </span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.2 }}
                className="text-lg text-white/80 leading-relaxed mb-10 max-w-xl"
              >
                {FREE_INDICATORS.length} indicateurs expliqués en détail dans {INDICATORS_CONFIG.familyCount} catégories.
                Définition, interprétation, limites, erreurs courantes et cas pratiques pour chaque indicateur.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.3 }}
                className="flex flex-col sm:flex-row gap-4 mb-10"
              >
                {isAuthenticated && hasAccess ? (
                  <Link
                    href="/dashboard/indicateurs"
                    className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/20 transition-all text-base"
                  >
                    <Activity size={18} /> Accéder aux indicateurs
                  </Link>
                ) : isAuthenticated ? (
                  <Link
                    href="/pricing"
                    className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/20 transition-all text-base"
                  >
                    <Crown size={18} /> Débloquer tous les indicateurs
                  </Link>
                ) : (
                  <a
                    href={getLoginUrl("/dashboard/indicateurs")}
                    className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/20 transition-all text-base"
                  >
                    <Activity size={18} /> Découvrir gratuitement
                  </a>
                )}
                <a
                  href="#categories"
                  className="inline-flex items-center justify-center px-8 py-4 border border-white/25 text-white font-medium rounded-xl hover:bg-white/10 transition-colors text-base"
                >
                  Voir les catégories
                </a>
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.7, delay: 0.5 }}
                className="flex flex-wrap items-center gap-x-6 gap-y-2 text-white/70 text-xs"
              >
                <span className="flex items-center gap-1.5"><Shield size={12} className="text-[#D4A853]" /> Éducatif uniquement</span>
                <span className="flex items-center gap-1.5"><Clock size={12} /> 5-8 min par fiche</span>
                <span className="flex items-center gap-1.5"><Layers size={12} /> {INDICATORS_CONFIG.familyCount} catégories</span>
                <span className="flex items-center gap-1.5"><CheckCircle2 size={12} /> Accès découverte inclus</span>
              </motion.div>
            </div>

            {/* Right — Stats Card */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="hidden lg:block"
            >
              <div className="bg-white/[0.06] backdrop-blur-xl rounded-2xl border border-white/15 p-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-40 h-40 bg-[#D4A853]/5 rounded-full blur-3xl" />
                <div className="relative">
                  <div className="flex items-center gap-3 mb-8">
                    <div className="w-12 h-12 rounded-xl bg-[#D4A853]/15 flex items-center justify-center">
                      <Activity size={22} className="text-[#D4A853]" />
                    </div>
                    <div>
                      <p className="text-white font-bold text-lg">Encyclopédie Technique</p>
                      <p className="text-white/50 text-xs">Indicateurs de A à Z</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    {[
                      { value: String(FREE_INDICATORS.length), label: "Indicateurs", icon: Activity },
                      { value: String(INDICATORS_CONFIG.familyCount), label: "Catégories", icon: Layers },
                      { value: "3", label: "Niveaux", icon: Target },
                      { value: "5-8 min", label: "Par fiche", icon: Clock },
                    ].map((stat) => (
                      <div key={stat.label} className="bg-white/[0.06] rounded-xl p-4 border border-white/[0.08]">
                        <stat.icon size={16} className="text-[#D4A853] mb-2" />
                        <p className="text-2xl font-bold text-white">{stat.value}</p>
                        <p className="text-white/40 text-xs">{stat.label}</p>
                      </div>
                    ))}
                  </div>
                  <div className="bg-[#D4A853]/10 border border-[#D4A853]/20 rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-1">
                      <BookOpen size={14} className="text-[#D4A853]" />
                      <p className="text-[#D4A853] text-xs font-bold">Contenu par fiche</p>
                    </div>
                    <p className="text-white/60 text-[11px]">Définition, interprétation (haussier/baissier/range/divergence), limites, erreurs courantes, combinaisons et cas pratique</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ═══════════ DISCLAIMER ═══════════ */}
      <section className="bg-white border-b border-[#E1E6EA]">
        <div className="container py-4">
          <p className="text-[11px] text-[#1E1E1E]/40 text-center">
            Les indicateurs techniques sont des outils de lecture du marché, pas des prédicteurs infaillibles. Ce contenu est strictement informatif.
          </p>
        </div>
      </section>

      {/* ═══════════ POURQUOI LES INDICATEURS ═══════════ */}
      <section className="py-20 lg:py-28 bg-[#FAFAFA]">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} custom={0} variants={fadeUp}>
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#D4A853]/10 text-[#8A6E18] text-xs font-bold mb-6">
                <Lightbulb size={14} /> Pourquoi les indicateurs
              </span>
              <h2 className="text-3xl lg:text-4xl font-bold text-[#344453] mb-4">
                Comprendre le langage des marchés
              </h2>
              <p className="text-[#1E1E1E]/60 text-lg leading-relaxed">
                Les indicateurs techniques sont les outils qui permettent de lire et d'interpréter les mouvements du marché.
                Les maîtriser, c'est comprendre ce que le prix vous dit.
              </p>
            </motion.div>
          </div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-8"
          >
            {[
              {
                icon: Eye, title: "Lire le marché", illu: "chart-anatomy" as ConceptType,
                desc: "Chaque indicateur révèle un aspect du marché : tendance, momentum, volatilité ou volume. Ensemble, ils forment une image complète.",
              },
              {
                icon: Target, title: "Identifier les signaux", illu: "momentum" as ConceptType,
                desc: "Apprenez à repérer les signaux haussiers, baissiers, les divergences et les conditions de surachat/survente.",
              },
              {
                icon: Shield, title: "Éviter les pièges", illu: "drawdown" as ConceptType,
                desc: "Chaque fiche détaille les limites et les erreurs courantes. Un bon trader sait quand un indicateur ment.",
              },
            ].map((item, i) => (
              <motion.div key={item.title} custom={i} variants={fadeUp} className="bg-white rounded-2xl p-6 border border-[#E1E6EA] overflow-hidden">
                <div className="rounded-xl border border-[#E1E6EA] bg-gradient-to-br from-[#FAFBFC] to-[#F0F2F4] p-2 mb-5 wmb-illu-zoom">
                  <ConceptIllustration type={item.illu} />
                </div>
                <div className="flex items-center gap-2 mb-3">
                  <span className="w-9 h-9 rounded-lg bg-[#344453]/5 flex items-center justify-center shrink-0">
                    <item.icon size={18} className="text-[#344453]" />
                  </span>
                  <h3 className="text-lg font-bold text-[#344453]">{item.title}</h3>
                </div>
                <p className="text-sm text-[#1E1E1E]/60 leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ═══════════ LES CATÉGORIES ═══════════ */}
      <section id="categories" className="py-20 lg:py-28 bg-white">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#344453]/5 text-[#344453] text-xs font-bold mb-6">
              <Layers size={14} /> {INDICATORS_CONFIG.familyCount} catégories
            </span>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#344453] mb-4">
              {INDICATORS_CONFIG.familyCount} familles d'indicateurs
            </h2>
            <p className="text-[#1E1E1E]/60 text-lg leading-relaxed">
              De la tendance au volume, des patterns aux indicateurs institutionnels — chaque famille couvre un aspect essentiel de l'analyse technique.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {CATEGORY_CARDS.map((cat, i) => (
              <motion.div
                key={cat.label}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                custom={i}
                variants={fadeUp}
              >
                <Link
                  href="/indicateurs-tendance"
                  className="group flex flex-col h-full bg-white rounded-2xl border border-[#E1E6EA] overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453]"
                >
                  <div className="h-1.5 w-full" style={{ backgroundColor: cat.color }} />
                  <div className="flex flex-1 flex-col p-5">
                    <div className="flex items-center justify-between mb-3">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center transition-transform duration-300 group-hover:scale-110" style={{ backgroundColor: `${cat.color}12` }}>
                        <cat.icon size={18} style={{ color: cat.color }} />
                      </div>
                      <span className="text-xs font-bold" style={{ color: cat.color }}>{cat.count} fiches</span>
                    </div>
                    <h3 className="text-base font-bold text-[#344453] mb-1.5">{cat.label}</h3>
                    <p className="text-xs text-[#1E1E1E]/50 leading-relaxed">{cat.desc}</p>
                    <div className="mt-auto pt-4 flex items-center gap-1.5 text-xs font-semibold text-[#344453]/70 group-hover:text-[#344453] transition-colors">
                      Explorer
                      <ArrowRight size={13} className="transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ BIBLIOTHÈQUE INTERACTIVE ═══════════ */}
      <IndicatorsLibrary />

      {/* ═══════════ CE QUE CONTIENT CHAQUE FICHE ═══════════ */}
      <section className="py-20 lg:py-28 bg-[#FAFAFA]">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#D4A853]/10 text-[#8A6E18] text-xs font-bold mb-6">
                <Star size={14} /> Contenu détaillé
              </span>
              <h2 className="text-3xl lg:text-4xl font-bold text-[#344453] mb-6">
                Ce que contient chaque fiche
              </h2>
              <p className="text-[#1E1E1E]/60 text-lg leading-relaxed mb-8">
                Chaque indicateur est traité en profondeur avec une structure pédagogique cohérente.
              </p>
              <ul className="space-y-4">
                {[
                  { icon: CheckCircle2, text: "Définition et description complète" },
                  { icon: CheckCircle2, text: "Comment ça fonctionne (formule et logique)" },
                  { icon: CheckCircle2, text: "Interprétation : haussier, baissier, range, divergence" },
                  { icon: CheckCircle2, text: "Analyse multi-timeframe" },
                  { icon: CheckCircle2, text: "Limites et erreurs courantes à éviter" },
                  { icon: CheckCircle2, text: "Combinaisons recommandées avec d'autres indicateurs" },
                  { icon: CheckCircle2, text: "Cas pratique concret" },
                  { icon: CheckCircle2, text: "Indicateurs liés et navigation croisée" },
                ].map((item) => (
                  <li key={item.text} className="flex items-start gap-3">
                    <item.icon size={18} className="text-[#2E7D5B] mt-0.5 shrink-0" />
                    <span className="text-[#1E1E1E]/70 text-base">{item.text}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-gradient-to-br from-[#344453] to-[#1a2530] rounded-2xl p-8 lg:p-10">
              <div className="space-y-4">
                <div className="bg-white/[0.06] rounded-xl p-5 border border-white/[0.08]">
                  <p className="text-white/40 text-xs font-bold uppercase tracking-wider mb-2">Exemple : RSI</p>
                  <p className="text-white font-medium mb-3">Relative Strength Index</p>
                  <p className="text-white/60 text-sm leading-relaxed mb-4">
                    Oscillateur borné entre 0 et 100 qui mesure la vitesse et l'amplitude des mouvements de prix.
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3">
                      <p className="text-emerald-400 text-[10px] font-bold uppercase">Haussier</p>
                      <p className="text-white/70 text-xs mt-1">RSI &gt; 50 avec pente ascendante</p>
                    </div>
                    <div className="bg-rose-500/10 border border-rose-500/20 rounded-lg p-3">
                      <p className="text-rose-400 text-[10px] font-bold uppercase">Baissier</p>
                      <p className="text-white/70 text-xs mt-1">RSI &lt; 50 avec pente descendante</p>
                    </div>
                  </div>
                </div>
                <div className="bg-amber-500/5 border border-amber-500/15 rounded-xl p-4">
                  <p className="text-amber-400 text-xs font-bold mb-1">Erreur courante</p>
                  <p className="text-white/60 text-sm">Acheter dès que le RSI touche 30 sans confirmer avec le prix ou le volume.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ NIVEAUX ═══════════ */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#344453] mb-4">3 niveaux de difficulté</h2>
            <p className="text-[#1E1E1E]/60 text-lg">Chaque indicateur est classé par niveau pour guider votre apprentissage progressif.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              { level: "Débutant", color: "#2E7D5B", desc: "Les indicateurs essentiels pour commencer : RSI, moyennes mobiles, MACD, supports/résistances, volume.", count: "Tendance & momentum" },
              { level: "Intermédiaire", color: "#D4A853", desc: "Indicateurs plus techniques : Stochastique, Bollinger, ATR, VWAP, CCI, ADX, OBV.", count: "Volatilité & volume" },
              { level: "Avancé", color: "#B0413E", desc: "Lectures fines et systèmes complets : Ichimoku, Parabolic SAR, Vortex, Elder-Ray, Choppiness, Fisher.", count: "Schémas avancés" },
            ].map((item) => (
              <div key={item.level} className="text-center">
                <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center" style={{ backgroundColor: `${item.color}10`, border: `1px solid ${item.color}30` }}>
                  <Target size={24} style={{ color: item.color }} />
                </div>
                <h3 className="text-lg font-bold text-[#344453] mb-1">{item.level}</h3>
                <p className="text-xs font-medium mb-3" style={{ color: item.color }}>{item.count}</p>
                <p className="text-sm text-[#1E1E1E]/50 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ CHIFFRES CLÉS ═══════════ */}
      <section className="py-16 lg:py-20 bg-[#FAFAFA]">
        <div className="container">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { num: FREE_INDICATORS.length, value: "", label: "Indicateurs", sub: "fiches détaillées" },
              { num: INDICATORS_CONFIG.familyCount, value: "", label: "Catégories", sub: "familles d'indicateurs" },
              { num: null as number | null, value: "5-8 min", label: "Par fiche", sub: "temps de lecture moyen" },
              { num: null as number | null, value: "100%", label: "Pédagogique", sub: "contenu informatif" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <p className="text-3xl lg:text-4xl font-bold text-[#344453]">{stat.num !== null ? <CountUp value={stat.num} /> : stat.value}</p>
                <p className="text-sm font-semibold text-[#344453] mt-1">{stat.label}</p>
                <p className="text-xs text-[#1E1E1E]/40 mt-0.5">{stat.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ CROSS-SELL ═══════════ */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-2xl lg:text-3xl font-bold text-[#344453] mb-4">Complétez votre apprentissage</h2>
            <p className="text-[#1E1E1E]/50 text-base">Les indicateurs se combinent avec les autres outils de l'Académie WMB.</p>
          </div>
          <div className="grid sm:grid-cols-3 gap-6">
            {[
              { icon: GraduationCap, title: "Formation", desc: "7 modules complets pour maîtriser les fondamentaux.", href: "/formation" },
              { icon: Brain, title: "Quiz", desc: "174+ questions pour tester vos connaissances.", href: "/quiz" },
              { icon: BookOpen, title: "Glossaire", desc: "1 111+ termes financiers expliqués clairement.", href: "/glossaire" },
            ].map((item) => (
              <Link key={item.title} href={item.href} className="bg-[#FAFAFA] rounded-2xl p-6 border border-[#E1E6EA] hover:border-[#D4A853]/30 hover:shadow-lg transition-all group">
                <div className="w-10 h-10 rounded-xl bg-[#344453]/5 flex items-center justify-center mb-4">
                  <item.icon size={18} className="text-[#344453]" />
                </div>
                <h3 className="text-base font-bold text-[#344453] mb-2">{item.title}</h3>
                <p className="text-sm text-[#1E1E1E]/50 leading-relaxed mb-3">{item.desc}</p>
                <span className="text-xs font-medium text-[#D4A853] flex items-center gap-1 group-hover:gap-2 transition-all">
                  Découvrir <ChevronRight size={12} />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ FINAL CTA ═══════════ */}
      <section className="py-20 lg:py-28 bg-gradient-to-br from-[#344453] via-[#3d5060] to-[#344453]">
        <div className="container text-center">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} custom={0} variants={fadeUp}>
            <div className="w-16 h-16 rounded-2xl bg-[#D4A853]/15 flex items-center justify-center mx-auto mb-6">
              <Activity size={28} className="text-[#D4A853]" />
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
              Prêt à maîtriser les indicateurs ?
            </h2>
            <p className="text-white/70 text-lg mb-10 max-w-xl mx-auto">
              {FREE_INDICATORS.length} indicateurs techniques expliqués en détail. Créez un compte pour découvrir l'encyclopédie complète.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {isAuthenticated ? (
                <Link
                  href={hasAccess ? "/dashboard/indicateurs" : "/pricing"}
                  className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/20 transition-all"
                >
                  {hasAccess ? <><Activity size={18} /> Accéder aux indicateurs</> : <><Crown size={18} /> Passer Premium</>}
                </Link>
              ) : (
                <a
                  href={getLoginUrl("/dashboard/indicateurs")}
                  className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/20 transition-all"
                >
                  <Activity size={18} /> Découvrir gratuitement
                </a>
              )}
              <Link
                href="/pricing"
                className="inline-flex items-center justify-center px-8 py-4 border border-white/25 text-white font-medium rounded-xl hover:bg-white/10 transition-colors"
              >
                Voir les offres
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
}
