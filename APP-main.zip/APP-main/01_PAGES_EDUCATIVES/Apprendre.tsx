/**
 * Apprendre — page-index « Tout apprendre » : hub de navigation qui rassemble
 * tous les contenus pédagogiques (glossaire, concepts, figures, indicateurs,
 * méthode, formation) en un parcours clair par niveau. 100% informatif.
 */
import Layout from "@/components/Layout";
import PageBreadcrumb from "@/components/PageBreadcrumb";
import { useSEO } from "@/hooks/useSEO";
import { usePageTitle } from "@/hooks/usePageTitle";
import HeroBackdrop from "@/components/HeroBackdrop";
import ConceptIllustration from "@/components/ConceptIllustration";
import CountUp from "@/components/CountUp";
import { Reveal } from "@/components/Reveal";
import { Link } from "wouter";
import {
  Search, BookOpen, CandlestickChart, Gauge, Route as RouteIcon, GraduationCap,
  ArrowRight, Compass, Sparkles, Info, Wrench, History,
} from "lucide-react";
import { MARKET_CRASHES } from "@/data/marketCrashes";
import { CHART_PATTERNS } from "@/data/chartPatterns";
import { CANDLESTICK_PATTERNS } from "@/data/candlestickPatterns";
import { INDICATORS } from "@/data/indicators";
import { GLOSSARY_CONCEPTS } from "@/data/glossaryConcepts";
import { TRADING_GUIDES } from "@/data/tradingGuides";
import { ANALYSIS_LESSONS } from "@/data/formationAnalyse";

const FIGURES = CHART_PATTERNS.length + CANDLESTICK_PATTERNS.length;
const TOOLS_COUNT = 50; // = nombre d'outils dans pages/tools/OutilsExpress.tsx

const PILLARS = [
  { title: "Glossaire & Concepts", desc: `${GLOSSARY_CONCEPTS.length} concepts illustrés + 1 000+ termes : le vocabulaire des marchés, montré et expliqué.`, href: "/glossaire", badge: `${GLOSSARY_CONCEPTS.length} illustrés`, Icon: Search, accent: "#344453", illu: "chart-anatomy" as const },
  { title: "Figures & Chandeliers", desc: `${FIGURES} motifs graphiques et chandeliers japonais, schémas interactifs + quiz.`, href: "/figures-chartistes", badge: `${FIGURES} motifs`, Icon: CandlestickChart, accent: "#2E7D5B", illu: "support-resistance" as const },
  { title: "Indicateurs", desc: `${INDICATORS.length} indicateurs en graphes bougies (RSI, MACD, Bollinger…), avec lecture.`, href: "/indicateurs-tendance", badge: `${INDICATORS.length} indicateurs`, Icon: Gauge, accent: "#D4A853", illu: "momentum" as const },
  { title: "Méthode & Règles", desc: `${TRADING_GUIDES.length} guides : lire un graphique, gérer le risque, construire un plan, éviter les pièges.`, href: "/methode", badge: `${TRADING_GUIDES.length} guides`, Icon: RouteIcon, accent: "#344453", illu: "stop-tp" as const },
  { title: "Formation Analyse", desc: `${ANALYSIS_LESSONS.length} modules pas à pas, du débutant à l'avancé, avec jauges et exemples.`, href: "/formation-analyse", badge: "Parcours", Icon: GraduationCap, accent: "#2E7D5B", illu: "trend" as const },
  { title: "Pôle Analyse technique", desc: "La porte d'entrée qui relie toutes les bibliothèques en un seul endroit.", href: "/analyse-technique", badge: "Hub", Icon: Compass, accent: "#D4A853", illu: "channel" as const },
  { title: "Boîte à outils", desc: `${TOOLS_COUNT} simulateurs interactifs : payoff & prix d'options, Monte-Carlo, intérêts composés, levier, frais, Sharpe… Gratuit.`, href: "/boite-a-outils", badge: `${TOOLS_COUNT} outils`, Icon: Wrench, accent: "#2E7D5B", illu: "compound" as const },
  { title: "Krachs & crises", desc: `${MARKET_CRASHES.length} effondrements historiques décryptés (1637 → 2023) : contexte, chiffres clés et leçons.`, href: "/krachs", badge: `${MARKET_CRASHES.length} crises`, Icon: History, accent: "#B0413E", illu: "bubble" as const },
];

const PATHS = [
  {
    level: "Débutant",
    color: "#2E7D5B",
    intro: "Comprendre le vocabulaire et les bases, sans se presser.",
    steps: [
      { label: "Le vocabulaire essentiel", href: "/glossaire" },
      { label: "Les concepts illustrés (levier, intérêts composés…)", href: "/glossaire" },
      { label: "Guide « Par où commencer »", href: "/methode" },
      { label: "Formation Analyse — modules 1 à 3", href: "/formation-analyse" },
    ],
  },
  {
    level: "Intermédiaire",
    color: "#C8A962",
    intro: "Lire un graphique et structurer ses décisions.",
    steps: [
      { label: "Les figures chartistes & chandeliers", href: "/figures-chartistes" },
      { label: "Les indicateurs (RSI, MACD, Bollinger)", href: "/indicateurs-tendance" },
      { label: "Méthode : canaux, gestion du risque, plan", href: "/methode" },
      { label: "Formation Analyse — modules 4 à 7", href: "/formation-analyse" },
    ],
  },
  {
    level: "Avancé",
    color: "#B0413E",
    intro: "Affiner, combiner les signaux et maîtriser le risque.",
    steps: [
      { label: "La confluence & la décision", href: "/methode" },
      { label: "Indicateurs avancés (Ichimoku, ATR, divergences)", href: "/indicateurs-tendance" },
      { label: "Méthode : options, fiscalité, krachs, money management", href: "/methode" },
      { label: "Formation Analyse — modules 8 & 9", href: "/formation-analyse" },
    ],
  },
];

export default function Apprendre() {
  const total = GLOSSARY_CONCEPTS.length + FIGURES + INDICATORS.length + TRADING_GUIDES.length + ANALYSIS_LESSONS.length;
  usePageTitle("Tout apprendre — La bibliothèque de l'analyse de marché");
  useSEO({
    title: "Tout Apprendre — Bibliothèque de l'analyse de marché | WMB",
    description:
      "Le parcours complet pour apprendre l'analyse de marché en français : glossaire, concepts illustrés, figures, indicateurs, méthode et formation. Du débutant à l'avancé. 100% informatif.",
    canonical: "/apprendre",
  });

  return (
    <Layout>
      {/* ─── HERO ─── */}
      <section className="relative overflow-hidden min-h-[460px] lg:min-h-[540px]">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a2530] via-[#2a3845] to-[#3a4b5a]" />
        <HeroBackdrop accent="#D4A853" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1a2530]/95 via-[#344453]/88 to-[#344453]/55" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1E1E1E]/45 to-transparent" />
        <div className="relative container py-16 lg:py-24 flex items-center min-h-[460px] lg:min-h-[540px]">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-[#D4A853]/20 border border-[#D4A853]/30 px-3 py-1.5 mb-6">
              <Sparkles size={14} className="text-[#D4A853]" />
              <span className="text-[#D4A853] text-xs font-semibold uppercase tracking-wider">Tout apprendre</span>
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-[56px] font-bold text-white leading-[1.1] mb-5">
              La bibliothèque de
              <br />
              <span className="text-[#D4A853]">l'analyse de marché.</span>
            </h1>
            <p className="text-lg text-white/75 leading-relaxed mb-8 max-w-lg">
              Tout pour comprendre les marchés, en français, du débutant à l'avancé — vocabulaire, schémas,
              indicateurs, méthode et formation, réunis en un seul parcours.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/recherche" className="inline-flex items-center justify-center gap-2 rounded-lg bg-white px-7 py-3.5 text-base font-semibold text-[#344453] hover:bg-white/90 transition-colors">
                <Search size={17} /> Rechercher dans la bibliothèque
              </Link>
              <Link href="/glossaire" className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/30 px-7 py-3.5 text-base font-medium text-white hover:bg-white/10 transition-colors">
                <RouteIcon size={17} /> Parcourir le glossaire
              </Link>
            </div>
          </div>
        </div>
      </section>

      <div className="container">
        <PageBreadcrumb items={[{ label: "Tout apprendre" }]} />
      </div>

      {/* ─── STATS ─── */}
      <section className="container">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { n: total, suffix: "+", v: "", l: "Contenus interactifs" },
            { n: 1000, suffix: "+", v: "", l: "Termes au glossaire" },
            { n: 6, suffix: "", v: "", l: "Bibliothèques reliées" },
            { n: null as number | null, suffix: "", v: "100%", l: "Éducatif, en français" },
          ].map((s) => (
            <div key={s.l} className="rounded-2xl border border-[#E1E6EA] bg-white px-5 py-6 text-center hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300">
              <p className="text-3xl lg:text-4xl font-bold text-[#344453]">{s.n !== null ? <CountUp value={s.n} suffix={s.suffix} /> : s.v}</p>
              <p className="mt-1 text-sm text-[#344453]/55">{s.l}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ─── PARCOURS PAR NIVEAU ─── */}
      <section className="container mt-14">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-3xl lg:text-4xl font-bold text-[#344453]">Un parcours par niveau</h2>
          <p className="mt-4 text-[#1E1E1E]/60 text-lg">Suivez l'ordre, ou piochez là où vous en êtes.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {PATHS.map((p) => (
            <div key={p.level} className="rounded-2xl border border-[#E1E6EA] bg-white overflow-hidden flex flex-col">
              <div className="h-1.5 w-full" style={{ backgroundColor: p.color }} />
              <div className="p-6 flex flex-1 flex-col">
                <h3 className="text-lg font-bold text-[#344453]">{p.level}</h3>
                <p className="mt-1 text-sm text-[#344453]/60">{p.intro}</p>
                <ol className="mt-5 space-y-2.5 flex-1">
                  {p.steps.map((st, i) => (
                    <li key={i}>
                      <Link href={st.href} className="group flex items-start gap-2.5 text-sm text-[#344453]/85 hover:text-[#344453]">
                        <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[11px] font-bold text-white" style={{ backgroundColor: p.color }}>
                          {i + 1}
                        </span>
                        <span className="group-hover:underline">{st.label}</span>
                      </Link>
                    </li>
                  ))}
                </ol>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ─── LES 6 BIBLIOTHÈQUES ─── */}
      <section className="container mt-16 pb-12">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-3xl lg:text-4xl font-bold text-[#344453]">Les bibliothèques</h2>
          <p className="mt-4 text-[#1E1E1E]/60 text-lg">Six pôles reliés entre eux — explorez par envie.</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {PILLARS.map((card, i) => (
            <Reveal key={card.title} index={i} className="h-full">
            <Link
              href={card.href}
              className="group flex h-full flex-col overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white transition-all duration-300 hover:shadow-xl hover:-translate-y-1.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453]"
              aria-label={card.title}
            >
              <div
                className="relative h-40 overflow-hidden"
                style={{ background: `linear-gradient(135deg, ${card.accent} 0%, #1a2530 95%)` }}
              >
                {/* Icône filigrane (visuel original, sans image externe) */}
                <card.Icon
                  className="absolute -bottom-5 -left-4 text-white/12 transition-transform duration-500 group-hover:scale-110 group-hover:-rotate-3"
                  size={130}
                  strokeWidth={1.4}
                />
                {/* Vignette schéma SVG original (jamais une page sans graphique) */}
                <div className="wmb-illu-zoom absolute right-3 top-9 bottom-12 w-[44%] rounded-xl bg-white/92 border border-white/40 shadow-sm flex items-center justify-center overflow-hidden p-1.5">
                  <ConceptIllustration type={card.illu} />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1a2530]/80 via-transparent to-transparent" />
                <span className="absolute top-3 left-3 inline-flex items-center gap-1.5 rounded-full bg-white/90 px-2.5 py-1 text-[11px] font-bold text-[#344453]">
                  <card.Icon size={13} style={{ color: card.accent }} /> {card.badge}
                </span>
                <h3 className="absolute bottom-3 left-4 right-4 text-xl font-bold text-white">{card.title}</h3>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <p className="text-sm text-[#344453]/75 leading-relaxed">{card.desc}</p>
                <div className="mt-auto pt-4 flex items-center gap-1.5 text-sm font-semibold text-[#344453] group-hover:gap-2.5 transition-all">
                  Explorer
                  <ArrowRight size={15} className="transition-transform group-hover:translate-x-1" style={{ color: card.accent }} />
                </div>
              </div>
            </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ─── DISCLAIMER ─── */}
      <section className="container pb-20">
        <div className="mx-auto max-w-3xl flex items-start gap-3 rounded-xl border border-[#C8A962]/30 bg-[#C8A962]/[0.07] px-4 py-3">
          <Info size={18} className="mt-0.5 shrink-0 text-[#8A6E18]" />
          <p className="text-sm text-[#344453]/85 leading-relaxed">
            <span className="font-semibold text-[#344453]">Strictement informatif.</span> WMB explique ce que les
            analystes observent. Aucun contenu n'est un conseil d'investissement ni un signal d'achat/vente.
          </p>
        </div>
      </section>
    </Layout>
  );
}
