/**
 * AnalyseTechnique — page-pôle « Analyse technique » : hub premium réunissant
 * Figures, Indicateurs, Glossaire, Quiz et Formation. Illustrée par les images
 * sous licence du site. 100% informatif (voix WMB).
 */
import Layout from "@/components/Layout";
import PageBreadcrumb from "@/components/PageBreadcrumb";
import { useSEO } from "@/hooks/useSEO";
import { usePageTitle } from "@/hooks/usePageTitle";
import HeroBackdrop from "@/components/HeroBackdrop";
import ConceptIllustration from "@/components/ConceptIllustration";
import CountUp from "@/components/CountUp";
import { Reveal } from "@/components/Reveal";
import { Link } from "wouter";
import {
  CandlestickChart,
  Gauge,
  Search,
  Brain,
  GraduationCap,
  ArrowRight,
  Info,
  TrendingUp,
  BookOpen,
  Route as RouteIcon,
} from "lucide-react";
import { CHART_PATTERNS } from "@/data/chartPatterns";
import { CANDLESTICK_PATTERNS } from "@/data/candlestickPatterns";
import { INDICATORS } from "@/data/indicators";
import { GLOSSARY_CONCEPTS } from "@/data/glossaryConcepts";

const POLE_CARDS = [
  {
    title: "Figures Chartistes",
    desc: "Tête-épaules, drapeaux, triangles, double sommet… Schémas interactifs et lecture pédagogique.",
    href: "/figures-chartistes",

    badge: `${CHART_PATTERNS.length + CANDLESTICK_PATTERNS.length} motifs`,
    Icon: CandlestickChart,
    accent: "#2E7D5B",
    illu: "support-resistance" as const,
  },
  {
    title: "Indicateurs Techniques",
    desc: "RSI, MACD, Bollinger, Ichimoku… Chaque indicateur en graphe, avec ce qu'il mesure et comment il se lit.",
    href: "/indicateurs-tendance",

    badge: `${INDICATORS.length} indicateurs`,
    Icon: Gauge,
    accent: "#D4A853",
    illu: "momentum" as const,
  },
  {
    title: "Glossaire & Concepts illustrés",
    desc: `${GLOSSARY_CONCEPTS.length} concepts clés montrés par un schéma + 1 000+ termes : fiches, recherche, quiz et parcours.`,
    href: "/glossaire",

    badge: `${GLOSSARY_CONCEPTS.length} illustrés`,
    Icon: Search,
    accent: "#344453",
    illu: "chart-anatomy" as const,
  },
  {
    title: "Quiz — Reconnais la figure",
    desc: "Un schéma, quatre propositions : entraînez votre œil et battez votre record.",
    href: "/figures-chartistes",

    badge: "Entraînement",
    Icon: Brain,
    accent: "#2E7D5B",
    illu: "channel" as const,
  },
  {
    title: "Formation",
    desc: "Un parcours structuré du débutant à l'avancé : marchés, indices, analyse technique, options.",
    href: "/formation",

    badge: "Parcours complet",
    Icon: GraduationCap,
    accent: "#D4A853",
    illu: "trend" as const,
  },
  {
    title: "Méthode & Règles",
    desc: "Lire un graphique, tracer un canal, gérer le risque, construire un plan, dompter ses biais — la méthode.",
    href: "/methode",

    badge: "Guides pratiques",
    Icon: BookOpen,
    accent: "#344453",
    illu: "stop-tp" as const,
  },
  {
    title: "Formation Analyse",
    desc: "Un parcours pas à pas de l'analyse de marché, avec jauges, exemples concrets et schémas par module.",
    href: "/formation-analyse",

    badge: "Débutant → avancé",
    Icon: RouteIcon,
    accent: "#2E7D5B",
    illu: "compound" as const,
  },
];

const STATS = [
  { num: CHART_PATTERNS.length + CANDLESTICK_PATTERNS.length, suffix: "", label: "Figures & chandeliers" },
  { num: INDICATORS.length, suffix: "", label: "Indicateurs en graphes" },
  { num: GLOSSARY_CONCEPTS.length, suffix: "", label: "Concepts illustrés" },
  { num: 1000, suffix: "+", label: "Termes au glossaire" },
];

export default function AnalyseTechnique() {
  usePageTitle("Analyse Technique — Le pôle complet");
  useSEO({
    title: "Analyse Technique — Figures, Indicateurs & Glossaire | WMB",
    description:
      `Le pôle analyse technique de WMB : ${CHART_PATTERNS.length + CANDLESTICK_PATTERNS.length} figures chartistes & chandeliers, ${INDICATORS.length} indicateurs en graphes interactifs, glossaire de 1 000+ termes et quiz. 100% informatif, en français.`,
    canonical: "/analyse-technique",
  });

  return (
    <Layout>
      {/* ─── HERO IMMERSIF ─── */}
      <section className="relative overflow-hidden min-h-[460px] lg:min-h-[540px]">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a2530] via-[#2a3845] to-[#3a4b5a]" />
        <HeroBackdrop accent="#D4A853" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1a2530]/95 via-[#344453]/88 to-[#344453]/60" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1E1E1E]/45 to-transparent" />

        <div className="relative container py-16 lg:py-24 flex items-center min-h-[460px] lg:min-h-[540px]">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-[#D4A853]/20 border border-[#D4A853]/30 px-3 py-1.5 mb-6">
              <TrendingUp size={14} className="text-[#D4A853]" />
              <span className="text-[#D4A853] text-xs font-semibold uppercase tracking-wider">Le pôle Analyse technique</span>
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-[56px] font-bold text-white leading-[1.1] mb-5">
              Tout pour lire
              <br />
              <span className="text-[#D4A853]">les marchés.</span>
            </h1>
            <p className="text-lg text-white/75 leading-relaxed mb-8 max-w-lg">
              Figures, chandeliers, indicateurs et vocabulaire — réunis dans une bibliothèque interactive,
              claire et 100% en français. La référence pour comprendre, pas pour suivre des signaux.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/figures-chartistes" className="inline-flex items-center justify-center gap-2 rounded-lg bg-white px-7 py-3.5 text-base font-semibold text-[#344453] hover:bg-white/90 transition-colors">
                <CandlestickChart size={17} /> Explorer les figures
              </Link>
              <Link href="/indicateurs-tendance" className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/30 px-7 py-3.5 text-base font-medium text-white hover:bg-white/10 transition-colors">
                <Gauge size={17} /> Voir les indicateurs
              </Link>
            </div>
          </div>
        </div>
      </section>

      <div className="container">
        <PageBreadcrumb items={[{ label: "Analyse technique" }]} />
      </div>

      {/* ─── STATS ─── */}
      <section className="container">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {STATS.map((s) => (
            <div key={s.label} className="rounded-2xl border border-[#E1E6EA] bg-white px-5 py-6 text-center hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300">
              <p className="text-3xl lg:text-4xl font-bold text-[#344453]"><CountUp value={s.num} suffix={s.suffix} /></p>
              <p className="mt-1 text-sm text-[#344453]/55">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ─── CARTES DU PÔLE (avec images) ─── */}
      <section className="container mt-12 lg:mt-16 pb-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-3xl lg:text-4xl font-bold text-[#344453]">Cinq portes d'entrée</h2>
          <p className="mt-4 text-[#1E1E1E]/60 text-lg">Choisissez par où commencer — tout est relié.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {POLE_CARDS.map((card, i) => (
            <Reveal key={card.title} index={i} className="h-full">
            <Link
              href={card.href}
              className="group flex h-full flex-col overflow-hidden rounded-2xl border border-[#E1E6EA] bg-white transition-all duration-300 hover:shadow-xl hover:-translate-y-1.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453]"
              aria-label={card.title}
            >
              <div
                className="relative h-44 overflow-hidden"
                style={{ background: `linear-gradient(135deg, ${card.accent} 0%, #1a2530 95%)` }}
              >
                {/* Icône filigrane (visuel original, sans image externe) */}
                <card.Icon
                  className="absolute -bottom-6 -left-5 text-white/12 transition-transform duration-500 group-hover:scale-110 group-hover:-rotate-3"
                  size={140}
                  strokeWidth={1.4}
                />
                {/* Vignette schéma SVG original (jamais une carte sans graphique) */}
                <div className="wmb-illu-zoom absolute right-3 top-9 bottom-12 w-[44%] rounded-xl bg-white/92 border border-white/40 shadow-sm flex items-center justify-center overflow-hidden p-1.5">
                  <ConceptIllustration type={card.illu} />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-[#1a2530]/80 via-transparent to-transparent" />
                <span className="absolute top-3 left-3 inline-flex items-center gap-1.5 rounded-full bg-white/90 px-2.5 py-1 text-[11px] font-bold text-[#344453]">
                  <card.Icon size={13} style={{ color: card.accent }} /> {card.badge}
                </span>
                <h3 className="absolute bottom-3 left-4 right-4 text-xl font-bold text-white">{card.title}</h3>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <p className="text-sm text-[#344453]/75 leading-relaxed">{card.desc}</p>
                <div className="mt-auto pt-4 flex items-center gap-1.5 text-sm font-semibold text-[#344453] group-hover:gap-2.5 transition-all">
                  Découvrir
                  <ArrowRight size={15} className="transition-transform group-hover:translate-x-1" style={{ color: card.accent }} />
                </div>
              </div>
            </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ─── DISCLAIMER ─── */}
      <section className="container pb-20">
        <div className="mx-auto max-w-3xl flex items-start gap-3 rounded-xl border border-[#C8A962]/30 bg-[#C8A962]/[0.07] px-4 py-3">
          <Info size={18} className="mt-0.5 shrink-0 text-[#8A6E18]" />
          <p className="text-sm text-[#344453]/85 leading-relaxed">
            <span className="font-semibold text-[#344453]">Strictement informatif.</span> WMB explique ce que les
            analystes observent. Aucun contenu n'est un conseil d'investissement ni un signal d'achat/vente.
          </p>
        </div>
      </section>
    </Layout>
  );
}
