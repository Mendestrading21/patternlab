import ShareBar from "@/components/ShareBar";
import { usePageTitle } from "@/hooks/usePageTitle";
import useSEO from "@/hooks/useSEO";
import { PRICING } from "@shared/siteConfig";
/**
 * WMB Académie — Course Detail Page (v7 – Visual Excellence)
 * Design: Leçons visuellement riches avec descriptions, icônes de contenu,
 * aperçu visuel, et design premium engageant.
 * Route: /formation/:courseSlug
 */
import Layout from "@/components/Layout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useSubscription } from "@/hooks/useSubscription";
import { Link, useParams, useLocation } from "wouter";
import { motion } from "framer-motion";
import {
  BookOpen, ChevronLeft, ChevronRight, Clock, Lock,
  CheckCircle2, ArrowRight, GraduationCap, FileText, Crown,
  BarChart3, Globe, Landmark, Briefcase, TrendingUp, Target,
  Play, Rocket, StickyNote, AlertTriangle, Info, Layers,
  Brain, Lightbulb, Zap, Star, Award, Sparkles,
} from "lucide-react";
import { useMemo, useState } from "react";
import { NewsletterCTA } from "@/components/academy";

/* ─── Config Maps ─── */
const CATEGORY_COLORS: Record<string, string> = {
  fondamentaux: "#344453", vehicules: "#2E7D5B", analyses: "#1a3a50",
  indices: "#D4A853", histoire: "#344453", options: "#344453", pratique: "#344453",
};
const CATEGORY_LABELS: Record<string, string> = {
  fondamentaux: "Les Fondamentaux", vehicules: "Véhicules d'Investissement",
  analyses: "Analyses & Méthodes", indices: "Indices & Indicateurs",
  histoire: "Histoire & Culture", options: "Les Options", pratique: "Investissement Pratique",
};
const MODULE_NUMBERS: Record<string, number> = {
  fondamentaux: 1, vehicules: 2, analyses: 3, indices: 4, histoire: 5, options: 6, pratique: 7,
};
const MODULE_COVER_ICONS: Record<string, React.ElementType> = {
  fondamentaux: GraduationCap, vehicules: Briefcase as React.ElementType,
  analyses: BarChart3, indices: Globe, histoire: Landmark, options: Target, pratique: Rocket,
};
const MODULE_GRADIENTS: Record<string, string> = {
  fondamentaux: "from-[#4A6275] via-[#344453] to-[#344453]",
  vehicules: "from-[#1a3a2a] via-[#2E7D5B] to-[#2E7D5B]",
  analyses: "from-[#0d1f2d] via-[#1a3a50] to-[#2a5a70]",
  indices: "from-[#3a2a0a] via-[#D4A853] to-[#C4A052]",
  histoire: "from-[#2a1f15] via-[#344453] to-[#7A6A5A]",
  options: "from-[#2a1530] via-[#344453] to-[#B0413E]",
  pratique: "from-[#0d2a3d] via-[#344453] to-[#344453]",
};
const MODULE_COVER_IMAGES: Record<string, string> = {
  fondamentaux: "/api/img/fondamentaux-UYfJqxkKxNHFvLNxGwLdJq.webp",
  analyses: "/api/img/analyses-9YbxCwKCMYTFjdBRCYYEQx.webp",
  indices: "/api/img/indices-2RNbPCnPJyxPqYhz9VXxjP.webp",
  vehicules: "/api/img/vehicules-JBbJUeHXdqAjjVqQWMVCvR.webp",
  options: "/api/img/options-2Ew1RFbUPiVPGFEBqXJZFi.webp",
  histoire: "/api/img/histoire-HUk4ekGfun3Dfh3tSGP6wB.webp",
  pratique: "/api/img/pratique-F5qp3KazbwFjh2A3cHzQpH.webp",
};
const DIFFICULTY_LABELS: Record<string, { label: string; color: string; bgColor: string }> = {
  debutant: { label: "Débutant", color: "text-emerald-700", bgColor: "bg-emerald-100" },
  intermediaire: { label: "Intermédiaire", color: "text-amber-700", bgColor: "bg-amber-100" },
  avance: { label: "Avancé", color: "text-red-700", bgColor: "bg-red-100" },
};

/* ─── Lesson content type icons ─── */
const LESSON_CONTENT_ICONS = [
  { icon: FileText, label: "Théorie" },
  { icon: Lightbulb, label: "Exemples" },
  { icon: Brain, label: "Quiz" },
];

/* ─── Circular Progress Ring ─── */
function ProgressRing({ percent, size = 64, strokeWidth = 4, color = "#D4A853" }: {
  percent: number; size?: number; strokeWidth?: number; color?: string;
}) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percent / 100) * circumference;
  return (
    <svg width={size} height={size} className="transform -rotate-90">
      <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#E1E6EA" strokeWidth={strokeWidth} />
      <motion.circle
        cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={color} strokeWidth={strokeWidth}
        strokeLinecap="round" strokeDasharray={circumference}
        initial={{ strokeDashoffset: circumference }}
        animate={{ strokeDashoffset: offset }}
        transition={{ duration: 1.2, ease: "easeOut" }}
      />
    </svg>
  );
}

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.04, duration: 0.4, ease: [0, 0, 0.2, 1] as [number, number, number, number] },
  }),
};

export default function CourseDetail() {
  usePageTitle("Formation");
  const { courseSlug } = useParams<{ courseSlug: string }>();
  const { isAuthenticated } = useAuth();
  const { isPremium, canAccess } = useSubscription();
  const [, navigate] = useLocation();
  const [expandedLesson, setExpandedLesson] = useState<number | null>(null);

  const { data: course, isLoading: courseLoading } = trpc.academy.getCourse.useQuery(
    { slug: courseSlug || "" }, { enabled: !!courseSlug }
  );
  const { data: lessons, isLoading: lessonsLoading } = trpc.academy.getCourseLessons.useQuery(
    { courseId: course?.id || 0 }, { enabled: !!course?.id }
  );
  const { data: progress } = trpc.academy.getCourseProgress.useQuery(
    { courseId: course?.id || 0 }, { enabled: !!course?.id && isAuthenticated }
  );

  const completedSet = useMemo(() => {
    const set = new Set<number>();
    if (progress) for (const p of progress) set.add(p.lessonId);
    return set;
  }, [progress]);

  const isLoading = courseLoading || lessonsLoading;
  const isFree = course?.isFree === 1;
  const isLocked = !isFree && !canAccess("formation:lesson");
  const catColor = CATEGORY_COLORS[course?.category || ""] || "#344453";
  const catLabel = CATEGORY_LABELS[course?.category || ""] || "";
  const moduleNumber = MODULE_NUMBERS[course?.category || ""] || 1;
  const moduleGradient = MODULE_GRADIENTS[course?.category || ""] || MODULE_GRADIENTS.fondamentaux;
  const ModuleCoverIcon = MODULE_COVER_ICONS[course?.category || ""] || TrendingUp;
  const moduleCoverImage = MODULE_COVER_IMAGES[course?.category || ""] || "";
  const diff = DIFFICULTY_LABELS[course?.difficulty || "debutant"] || DIFFICULTY_LABELS.debutant;
  const completedCount = completedSet.size;
  const totalCount = lessons?.length || 0;
  const progressPct = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
  const totalMinutes = lessons?.reduce((sum, l) => sum + (l.estimatedMinutes || 5), 0) || 0;

  // SEO dynamique basé sur les données du cours
  useSEO({
    title: course ? `${course.title} — Formation Bourse | WMB` : "Formation Bourse | WMB",
    description: course?.description
      ? course.description.slice(0, 155) + (course.description.length > 155 ? "…" : "")
      : "Cours de formation bourse WMB — Parcours structuré du débutant à l'avancé.",
    canonical: `/formation/${courseSlug}`,
    ogType: "article",
  });

  const nextUncompletedLesson = useMemo(() => {
    if (!lessons) return null;
    return lessons.find((l) => !completedSet.has(l.id)) || null;
  }, [lessons, completedSet]);

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="w-10 h-10 border-2 border-[#344453]/20 border-t-[#D4A853] rounded-full animate-spin" />
        </div>
      <ShareBar />
    </Layout>
    );
  }

  if (!course) {
    return (
      <Layout>
        <div className="container py-24 text-center">
          <h1 className="text-2xl font-bold text-[#344453] mb-4">Cours introuvable</h1>
          <p className="text-[#344453]/75 mb-8">Ce cours n'existe pas ou a été déplacé.</p>
          <Link href="/formation" className="text-[#344453] font-medium hover:underline">← Retour à Apprendre</Link>
        </div>
      <ShareBar />
    </Layout>
    );
  }

  return (
    <Layout>
      {/* ═══════════ HERO ═══════════ */}
      <section className={`relative overflow-hidden bg-gradient-to-br ${moduleGradient}`}>
        <div className="absolute inset-0 opacity-[0.05]">
          <div className="absolute top-0 left-0 w-full h-full" style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.3'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")" }} />
        </div>
        <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full bg-white/5 animate-pulse" style={{ animationDuration: "10s" }} />
        <div className="absolute -bottom-16 -left-16 w-64 h-64 rounded-full bg-white/5" />
        {moduleCoverImage ? (
          <div className="absolute top-1/2 right-10 -translate-y-1/2 hidden lg:block w-[320px] h-[200px] rounded-2xl overflow-hidden border border-white/15 shadow-2xl shadow-black/30">
            <img src={moduleCoverImage} alt={catLabel} className="w-full h-full object-cover opacity-60" />
            <div className="absolute inset-0 bg-gradient-to-l from-transparent via-transparent to-black/30" />
          </div>
        ) : (
          <div className="absolute top-1/2 right-16 -translate-y-1/2 hidden lg:flex items-center justify-center w-40 h-40 rounded-3xl bg-white/5 backdrop-blur-sm border border-white/10">
            <ModuleCoverIcon size={60} className="text-white/30" />
          </div>
        )}

        <div className="relative container py-16 lg:py-24">
          <Link href="/formation" className="inline-flex items-center gap-2 text-white/80 text-sm hover:text-white transition-colors mb-10">
            <ChevronLeft size={16} /> Retour à Apprendre
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-end">
            <div className="lg:col-span-2">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-wrap items-center gap-3 mb-5">
                <span className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/15 backdrop-blur-sm rounded-full text-white/90 text-xs font-medium">
                  <BookOpen size={12} /> Module {moduleNumber} · {catLabel}
                </span>
                <span className={`px-3 py-1 text-xs font-medium rounded-full ${diff.bgColor} ${diff.color}`}>{diff.label}</span>
                {isFree && (
                  <span className="px-3 py-1 text-xs font-bold rounded-full bg-emerald-100 text-emerald-700 uppercase tracking-wider">Gratuit</span>
                )}
              </motion.div>

              <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }}
                className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-5">
                {course.title}
              </motion.h1>

              <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }}
                className="text-lg text-white/80 leading-relaxed mb-8 max-w-xl">
                {course.description}
              </motion.p>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.3 }}
                className="flex flex-wrap items-center gap-6">
                <div className="flex items-center gap-2 text-white/75 text-sm"><FileText size={15} /><span>{totalCount} leçons</span></div>
                <div className="flex items-center gap-2 text-white/75 text-sm"><Clock size={15} /><span>{totalMinutes} min</span></div>
                {isAuthenticated && completedCount > 0 && (
                  <div className="flex items-center gap-2 text-emerald-300 text-sm font-medium">
                    <CheckCircle2 size={15} /><span>{completedCount}/{totalCount} terminées</span>
                  </div>
                )}
              </motion.div>
            </div>

            {/* Action card */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-white/10 backdrop-blur-md rounded-2xl p-7 border border-white/25">
              {isAuthenticated && completedCount > 0 ? (
                progressPct === 100 ? (
                  <div className="text-center">
                    <div className="relative inline-flex items-center justify-center mb-4">
                      <ProgressRing percent={100} size={80} strokeWidth={5} color="#34d399" />
                      <Award size={28} className="text-emerald-300 absolute" />
                    </div>
                    <h3 className="text-lg font-bold text-white mb-1">Cours terminé !</h3>
                    <p className="text-white/60 text-sm mb-5">Félicitations, vous avez complété ce cours.</p>
                    <Link href={`/formation/${courseSlug}/${lessons?.[0]?.slug || ""}`}
                      className="inline-flex items-center gap-2 px-6 py-3 bg-white/20 text-white font-medium rounded-xl hover:bg-white/30 transition-colors text-sm w-full justify-center">
                      <BookOpen size={16} /> Revoir le cours
                    </Link>
                  </div>
                ) : (
                  <div className="text-center">
                    <div className="relative inline-flex items-center justify-center mb-4">
                      <ProgressRing percent={progressPct} size={80} strokeWidth={5} color={catColor} />
                      <span className="text-white text-lg font-bold absolute">{progressPct}%</span>
                    </div>
                    <h3 className="text-lg font-bold text-white mb-1">En cours</h3>
                    <p className="text-white/60 text-sm mb-5">{totalCount - completedCount} leçons restantes</p>
                    {nextUncompletedLesson && (
                      <Link href={`/formation/${courseSlug}/${nextUncompletedLesson.slug}`}
                        className="inline-flex items-center gap-2 px-6 py-3 bg-white text-[#344453] font-semibold rounded-xl hover:bg-white/90 transition-colors text-sm w-full justify-center">
                        <Play size={16} /> Continuer
                      </Link>
                    )}
                  </div>
                )
              ) : isLocked ? (
                <div className="text-center">
                  <Crown size={32} className="text-[#D4A853] mx-auto mb-4" />
                  <h3 className="text-lg font-bold text-white mb-2">Contenu Premium</h3>
                  <p className="text-white/60 text-sm mb-5">Débloquez ce cours avec un abonnement.</p>
                  <Link href="/pricing"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-lg transition-all text-sm w-full justify-center">
                    <Crown size={16} /> Voir les offres
                  </Link>
                </div>
              ) : (
                <div className="text-center">
                  <Play size={32} className="text-white/80 mx-auto mb-4" />
                  <h3 className="text-lg font-bold text-white mb-2">Prêt à commencer ?</h3>
                  <p className="text-white/60 text-sm mb-5">{totalCount} leçons · {totalMinutes} min</p>
                  <Link href={`/formation/${courseSlug}/${lessons?.[0]?.slug || ""}`}
                    className="inline-flex items-center gap-2 px-6 py-3 bg-white text-[#344453] font-semibold rounded-xl hover:bg-white/90 transition-colors text-sm w-full justify-center">
                    <Play size={16} /> Commencer le cours
                  </Link>
                </div>
              )}
            </motion.div>
          </div>

          {/* Global Progress Bar */}
          {!isLocked && totalCount > 0 && completedCount > 0 && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="mt-10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white/60 text-xs">Progression du cours</span>
                <span className="text-white text-sm font-bold">{progressPct}%</span>
              </div>
              <div className="h-2.5 bg-white/10 rounded-full overflow-hidden">
                <motion.div initial={{ width: 0 }} animate={{ width: `${progressPct}%` }} transition={{ duration: 1.2, ease: "easeOut" }}
                  className="h-full rounded-full" style={{ backgroundColor: progressPct === 100 ? "#34d399" : "#D4A853" }} />
              </div>
            </motion.div>
          )}
        </div>
      </section>

      {/* ═══════════ COURSE OVERVIEW STATS ═══════════ */}
      <section className="bg-white border-b border-[#E1E6EA]">
        <div className="container py-8">
          <div className="max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { icon: FileText, value: `${totalCount}`, label: "Leçons", color: catColor },
              { icon: Clock, value: `${totalMinutes} min`, label: "Durée totale", color: "#2E7D5B" },
              { icon: Lightbulb, value: "Exemples", label: "Cas pratiques", color: "#D4A853" },
              { icon: Brain, value: "Quiz", label: "Auto-évaluation", color: "#B0413E" },
            ].map((stat, i) => (
              <motion.div key={stat.label} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="flex items-center gap-4 p-4 rounded-xl bg-[#FAFAFA] border border-[#E1E6EA]">
                <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${stat.color}10` }}>
                  <stat.icon size={20} style={{ color: stat.color }} />
                </div>
                <div>
                  <p className="text-lg font-bold text-[#344453]">{stat.value}</p>
                  <p className="text-xs text-[#1E1E1E]/50">{stat.label}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ LESSONS LIST — VISUAL RICH ═══════════ */}
      <section className="py-14 lg:py-20 bg-[#FAFAFA]">
        <div className="container">
          <div className="max-w-5xl mx-auto">
            {/* Section header */}
            <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-10">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-10 h-1.5 rounded-full" style={{ backgroundColor: catColor }} />
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#1E1E1E]/50">Programme du cours</span>
                </div>
                <h2 className="text-2xl lg:text-3xl font-bold text-[#344453]">{totalCount} leçons à parcourir</h2>
              </div>
              {!isLocked && completedCount > 0 && (
                <div className="flex items-center gap-3 text-sm">
                  <span className="font-semibold" style={{ color: progressPct === 100 ? "#2E7D5B" : catColor }}>{progressPct}% complété</span>
                  <span className="text-[#1E1E1E]/30">·</span>
                  <span className="text-[#1E1E1E]/50">{totalCount - completedCount} restantes</span>
                </div>
              )}
            </div>

            {isLocked ? (
              /* ─── LOCKED STATE ─── */
              <div className="relative">
                <div className="space-y-4">
                  {(lessons || []).slice(0, 3).map((lesson, i) => {
                    const isFreePreview = lesson.isFreePreview === 1;
                    return (
                      <motion.div key={lesson.id} custom={i} initial="hidden" animate="visible" variants={fadeUp}>
                        {isFreePreview ? (
                          <Link href={`/formation/${courseSlug}/${lesson.slug}`}>
                            <div className="group bg-white rounded-2xl border border-[#D0D5DA] hover:border-[#344453]/20 hover:shadow-lg transition-all cursor-pointer overflow-hidden">
                              <div className="flex items-stretch">
                                {/* Left accent */}
                                <div className="w-1.5 shrink-0 rounded-l-2xl" style={{ backgroundColor: catColor }} />
                                <div className="flex-1 p-6">
                                  <div className="flex items-start justify-between gap-4">
                                    <div className="flex-1">
                                      <div className="flex items-center gap-3 mb-2">
                                        <span className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-white shrink-0" style={{ backgroundColor: catColor }}>
                                          {i + 1}
                                        </span>
                                        <h3 className="text-base font-semibold text-[#344453] group-hover:text-[#1a3a50] transition-colors">{lesson.title}</h3>
                                      </div>
                                      <div className="flex items-center gap-4 ml-11">
                                        <span className="inline-flex items-center gap-1 text-xs text-[#1E1E1E]/50"><Clock size={11} /> {lesson.estimatedMinutes || 5} min</span>
                                        <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-600 text-[11px] font-bold rounded-full">GRATUIT</span>
                                        {LESSON_CONTENT_ICONS.map((ci) => (
                                          <span key={ci.label} className="inline-flex items-center gap-1 text-[10px] text-[#1E1E1E]/40">
                                            <ci.icon size={10} /> {ci.label}
                                          </span>
                                        ))}
                                      </div>
                                    </div>
                                    <ArrowRight size={18} className="text-[#1E1E1E]/30 group-hover:text-[#344453] group-hover:translate-x-1 transition-all shrink-0 mt-1" />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </Link>
                        ) : (
                          <div className="bg-white/60 rounded-2xl border border-[#D0D5DA] overflow-hidden">
                            <div className="flex items-stretch">
                              <div className="w-1.5 shrink-0 rounded-l-2xl bg-[#E1E6EA]" />
                              <div className="flex-1 p-6">
                                <div className="flex items-start justify-between gap-4">
                                  <div className="flex-1">
                                    <div className="flex items-center gap-3 mb-2">
                                      <span className="w-8 h-8 rounded-lg bg-[#E1E6EA] flex items-center justify-center text-xs font-bold text-[#1E1E1E]/40 shrink-0">{i + 1}</span>
                                      <h3 className="text-base font-semibold text-[#1E1E1E]/50">{lesson.title}</h3>
                                    </div>
                                    <div className="flex items-center gap-4 ml-11">
                                      <span className="inline-flex items-center gap-1 text-xs text-[#1E1E1E]/30"><Clock size={11} /> {lesson.estimatedMinutes || 5} min</span>
                                      <span className="inline-flex items-center gap-1 text-xs text-[#8A6E18]/60"><Lock size={11} /> Premium</span>
                                    </div>
                                  </div>
                                  <Lock size={16} className="text-[#8A6E18]/40 shrink-0 mt-1" />
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </motion.div>
                    );
                  })}
                </div>

                {/* Blurred remaining + CTA */}
                <div className="relative mt-4">
                  <div className="space-y-4 filter blur-sm pointer-events-none select-none opacity-20">
                    {(lessons || []).slice(3, 7).map((lesson, i) => (
                      <div key={lesson.id} className="bg-white rounded-2xl border border-[#D0D5DA] p-6">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-gray-200 shrink-0" />
                          <div className="flex-1"><div className="h-4 bg-gray-200 rounded w-3/4" /><div className="h-3 bg-gray-100 rounded w-1/3 mt-2" /></div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center bg-white/95 backdrop-blur-sm rounded-2xl p-10 border border-[#D4A853]/20 shadow-xl max-w-sm">
                      <div className="w-[72px] h-[72px] rounded-2xl bg-gradient-to-br from-[#D4A853]/15 to-[#D4A853]/5 border border-[#D4A853]/20 flex items-center justify-center mx-auto mb-6">
                        <Crown size={32} className="text-[#8A6E18]" />
                      </div>
                      <h3 className="text-xl font-bold text-[#344453] mb-3">Débloquez ce cours</h3>
                      <p className="text-sm text-[#1E1E1E]/60 mb-7 leading-relaxed">
                        Accédez à l'intégralité de ce cours et de toute la formation WMB avec un abonnement.
                      </p>
                      <Link href="/pricing"
                        className="inline-flex items-center gap-2 px-7 py-3.5 bg-gradient-to-r from-[#D4A853] to-[#C49A4A] text-[#344453] font-bold rounded-xl hover:shadow-lg transition-all text-sm">
                        Voir les offres <ArrowRight size={14} />
                      </Link>
                      <p className="text-xs text-[#1E1E1E]/40 mt-4">Dès {PRICING.plans.premium.price} {PRICING.currency}/mois · Annulation à tout moment</p>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              /* ─── UNLOCKED STATE: Immersive visual lesson cards ─── */
              <div className="space-y-5">
                {(lessons || []).map((lesson, i) => {
                  const isCompleted = completedSet.has(lesson.id);
                  const isNextUp = !isCompleted && i === completedCount && completedCount > 0;
                  const lessonIcons = [
                    BookOpen, Landmark, Globe, Layers, BarChart3, TrendingUp,
                    Target, Brain, Lightbulb, Zap, Star, Award, Sparkles,
                    FileText, Briefcase, Rocket, GraduationCap,
                  ];
                  const LessonIcon = lessonIcons[i % lessonIcons.length];
                  const accentHue = (i * 37 + 200) % 360;
                  const accentColor = isCompleted ? "#2E7D5B" : isNextUp ? "#D4A853" : catColor;

                  return (
                    <motion.div key={lesson.id} custom={i} initial="hidden" animate="visible" variants={fadeUp}>
                      <Link href={`/formation/${courseSlug}/${lesson.slug}`}>
                        <div className={`group relative bg-white rounded-2xl overflow-hidden transition-all duration-300 cursor-pointer ${
                          isCompleted
                            ? "border-2 border-emerald-200 shadow-sm hover:shadow-md hover:border-emerald-300"
                            : isNextUp
                            ? "border-2 border-[#D4A853]/50 shadow-lg shadow-[#D4A853]/10 hover:shadow-xl"
                            : "border-2 border-[#E1E6EA] hover:border-[#D0D5DA] hover:shadow-lg"
                        }`}>
                          {/* Top accent gradient */}
                          <div className="h-1" style={{ background: `linear-gradient(90deg, ${accentColor}, ${accentColor}66)` }} />

                          <div className="p-5 lg:p-6">
                            <div className="flex items-start gap-5">
                              {/* Visual lesson number with icon */}
                              <div className="relative shrink-0">
                                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
                                  isCompleted
                                    ? "bg-emerald-50 border-2 border-emerald-200"
                                    : isNextUp
                                    ? "bg-gradient-to-br from-[#D4A853]/15 to-[#D4A853]/5 border-2 border-[#D4A853]/30"
                                    : "bg-[#F4F5F5] border-2 border-[#E1E6EA] group-hover:border-[#D0D5DA]"
                                }`}>
                                  {isCompleted ? (
                                    <CheckCircle2 size={24} className="text-emerald-500" />
                                  ) : (
                                    <LessonIcon size={22} style={{ color: accentColor }} className="opacity-70 group-hover:opacity-100 transition-opacity" />
                                  )}
                                </div>
                                {/* Lesson number overlay */}
                                <div className={`absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                                  isCompleted
                                    ? "bg-emerald-500 text-white"
                                    : isNextUp
                                    ? "bg-[#D4A853] text-white"
                                    : "bg-[#344453] text-white"
                                }`}>
                                  {i + 1}
                                </div>
                              </div>

                              {/* Content */}
                              <div className="flex-1 min-w-0">
                                {/* Title row */}
                                <div className="flex items-start justify-between gap-3">
                                  <h3 className={`text-lg font-bold transition-colors leading-snug ${
                                    isCompleted ? "text-emerald-700" : "text-[#344453] group-hover:text-[#1a3a50]"
                                  }`}>
                                    {lesson.title}
                                  </h3>
                                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-all ${
                                    isNextUp
                                      ? "bg-[#D4A853]/15 group-hover:bg-[#D4A853]/25"
                                      : "bg-[#F4F5F5] group-hover:bg-[#E1E6EA]"
                                  }`}>
                                    <ArrowRight size={16} className={`transition-transform group-hover:translate-x-0.5 ${
                                      isCompleted ? "text-emerald-400" : isNextUp ? "text-[#8A6E18]" : "text-[#1E1E1E]/30"
                                    }`} />
                                  </div>
                                </div>

                                {/* Meta row with rich badges */}
                                <div className="flex flex-wrap items-center gap-2.5 mt-3">
                                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#F4F5F5] text-xs text-[#1E1E1E]/60">
                                    <Clock size={12} className="text-[#1E1E1E]/40" /> {lesson.estimatedMinutes || 5} min
                                  </span>
                                  {isCompleted && (
                                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 text-xs text-emerald-600 font-medium">
                                      <CheckCircle2 size={12} /> Terminée
                                    </span>
                                  )}
                                  {isNextUp && (
                                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold" style={{ backgroundColor: `${catColor}10`, color: catColor }}>
                                      <Play size={12} /> Prochaine leçon
                                    </span>
                                  )}
                                  {lesson.isFreePreview === 1 && !isFree && (
                                    <span className="px-2.5 py-1 bg-emerald-50 text-emerald-600 text-[11px] font-bold rounded-lg">GRATUIT</span>
                                  )}
                                  {/* Content type pills */}
                                  <div className="hidden sm:flex items-center gap-1.5 ml-auto">
                                    {LESSON_CONTENT_ICONS.map((ci) => (
                                      <span key={ci.label} className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-[#F8F9FA] text-[11px] text-[#1E1E1E]/45 border border-[#E1E6EA]/50">
                                        <ci.icon size={11} /> {ci.label}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Next up highlight bar */}
                          {isNextUp && (
                            <div className="px-6 pb-4">
                              <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#D4A853]/10 to-transparent border border-[#D4A853]/15">
                                <Sparkles size={14} className="text-[#8A6E18]" />
                                <span className="text-xs font-medium text-[#8A6E18]">Continuez votre apprentissage ici</span>
                              </div>
                            </div>
                          )}
                        </div>
                      </Link>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ═══════════ NEWSLETTER CTA (non-premium) ═══════════ */}
      {!canAccess("formation:lesson") && (
        <section className="py-14 lg:py-20 bg-white">
          <div className="container">
            <div className="max-w-3xl mx-auto">
              <NewsletterCTA variant="course-end" courseName={course.title} />
            </div>
          </div>
        </section>
      )}

      {/* ═══════════ DISCLAIMER ═══════════ */}
      <section className="bg-[#F8F6F0] border-y border-[#E8E4D8]">
        <div className="container py-4">
          <div className="flex items-start gap-3 max-w-4xl mx-auto">
            <Info size={16} className="text-[#8A6E18] shrink-0 mt-0.5" />
            <p className="text-xs text-[#1E1E1E]/60 leading-relaxed">
              <strong className="text-[#1E1E1E]/70">Contenu informatif et informatif uniquement.</strong>{" "}
              Ce cours ne constitue pas un conseil en investissement. Les marchés financiers comportent des risques de perte en capital.
              Consultez un professionnel agréé avant toute décision d'investissement.{" "}
              <Link href="/disclaimer" className="underline hover:text-[#344453]">Disclaimer complet</Link>
            </p>
          </div>
        </div>
      </section>

      {/* ═══════════ CONTINUE LEARNING ═══════════ */}
      <section className="py-14 lg:py-20 bg-white">
        <div className="container">
          <div className="max-w-3xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6 bg-[#FAFAFA] rounded-2xl p-10 border border-[#D0D5DA]">
            <div>
              <h3 className="text-xl font-bold text-[#344453] mb-2">Continuez votre apprentissage</h3>
              <p className="text-sm text-[#1E1E1E]/50">Explorez les autres cours de la formation WMB.</p>
            </div>
            <Link href="/formation"
              className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#344453] text-white font-semibold rounded-xl hover:bg-[#344453]/90 transition-colors text-sm shrink-0">
              <GraduationCap size={16} /> Tous les cours
            </Link>
          </div>
        </div>
      </section>
    <ShareBar />
    </Layout>
  );
}
