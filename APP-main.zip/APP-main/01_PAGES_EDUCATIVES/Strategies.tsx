import { usePageTitle } from "@/hooks/usePageTitle";
import { useSEO } from "@/hooks/useSEO";
/**
 * WMB Stratégies de Trading — Catalog
 * Premium strategies with detailed content
 * Route: /strategies
 */
import Layout from "@/components/Layout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useSubscription } from "@/hooks/useSubscription";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Target,
  TrendingUp,
  Shield,
  Clock,
  Lock,
  ArrowRight,
  ChevronRight,
  Sparkles,
  GraduationCap,
  BarChart3,
  Zap,
  LineChart,
  Code2,
  DollarSign,
  Layers,
  AlertTriangle,
} from "lucide-react";
import { getLoginUrl } from "@/const";

const EASE_OUT: [number, number, number, number] = [0.22, 1, 0.36, 1];

const RISK_COLORS: Record<string, { bg: string; text: string; label: string }> = {
  faible: { bg: "bg-emerald-100", text: "text-emerald-700", label: "Risque faible" },
  modere: { bg: "bg-amber-100", text: "text-amber-700", label: "Risque modéré" },
  eleve: { bg: "bg-red-100", text: "text-red-700", label: "Risque élevé" },
};

const TIMEFRAME_LABELS: Record<string, string> = {
  court: "Court terme",
  moyen: "Moyen terme",
  long: "Long terme",
};

/* ─── Strategy Card ─── */
function StrategyCard({
  strategy,
  index,
  isPremium,
  isAuthenticated,
}: {
  strategy: any;
  index: number;
  isPremium: boolean;
  isAuthenticated: boolean;
}) {
  const isLocked = !isPremium;
  const risk = RISK_COLORS[strategy.riskLevel || "modere"] || RISK_COLORS.modere;
  const timeframe = TIMEFRAME_LABELS[strategy.timeframe || "moyen"] || "Moyen terme";

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.5, delay: index * 0.06, ease: EASE_OUT }}
      className="group"
    >
      <div className="bg-white rounded-2xl border border-[#D0D5DA] overflow-hidden hover:border-[#344453]/20 hover:shadow-xl hover:shadow-[#344453]/5 transition-all duration-300 h-full flex flex-col">
        {/* Visual preview - strategy diagram */}
        <div className="relative h-36 bg-gradient-to-br from-[#2A1A1A] via-[#3A2020] to-[#344453] overflow-hidden">
          {/* Risk/reward diagram */}
          <svg className="absolute inset-0 w-full h-full" viewBox="0 0 200 80" preserveAspectRatio="none">
            {/* Entry zone */}
            <rect x="40" y="30" width="30" height="25" fill="#344453" opacity="0.15" rx="2" />
            <line x1="55" y1="28" x2="55" y2="57" stroke="#344453" strokeWidth="1" strokeDasharray="3,2" opacity="0.4" />
            {/* Take profit zone */}
            <rect x="100" y="10" width="40" height="20" fill="#2E7D5B" opacity="0.15" rx="2" />
            <text x="120" y="23" textAnchor="middle" fill="#2E7D5B" fontSize="6" opacity="0.5">TP</text>
            {/* Stop loss zone */}
            <rect x="100" y="55" width="40" height="18" fill="#D4A853" opacity="0.15" rx="2" />
            <text x="120" y="67" textAnchor="middle" fill="#D4A853" fontSize="6" opacity="0.5">SL</text>
            {/* Price line */}
            <path d={`M10,${45 + index * 2} L40,${42 - index} L55,${38 + index} L80,${35 - index * 2} L120,${20 + index} L160,${18 - index} L190,${22 + index}`} fill="none" stroke="#D4A853" strokeWidth="1.5" opacity="0.5" />
            {/* Arrow */}
            <path d="M55,38 L80,25" fill="none" stroke="#2E7D5B" strokeWidth="1" opacity="0.3" markerEnd="url(#arrowGreen)" />
            <defs>
              <marker id="arrowGreen" markerWidth="6" markerHeight="4" refX="6" refY="2" orient="auto">
                <path d="M0,0 L6,2 L0,4" fill="#2E7D5B" opacity="0.4" />
              </marker>
            </defs>
          </svg>
          {/* Badges overlay */}
          <div className="absolute top-3 right-3 flex items-center gap-2">
            {isLocked && <Lock size={12} className="text-[#1E1E1E]/80" />}
            <span className="flex items-center gap-1 px-2 py-0.5 bg-[#D4A853]/90 backdrop-blur-sm text-[#344453] text-[11px] font-bold rounded-full uppercase tracking-wider">
              <Sparkles size={10} /> Premium
            </span>
          </div>
          {/* Strategy type label */}
          <div className="absolute bottom-3 left-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-white/10 backdrop-blur-sm flex items-center justify-center">
                <Target size={16} className="text-[#8A6E18]" />
              </div>
              <span className="text-[#1E1E1E]/70 text-xs font-medium">{timeframe}</span>
            </div>
          </div>
        </div>

        <div className="p-6 flex-1 flex flex-col">

          {/* Title */}
          <h3 className="text-lg font-bold text-[#344453] mb-2 leading-tight">
            {strategy.name}
          </h3>

          {/* Description */}
          <p className="text-sm text-[#344453]/75 leading-relaxed mb-4 flex-1 line-clamp-3">
            {strategy.tagline || strategy.description}
          </p>

          {/* Meta tags */}
          <div className="flex flex-wrap gap-2 mb-4">
            <span className={`px-2 py-0.5 text-[11px] font-medium rounded-full ${risk.bg} ${risk.text}`}>
              {risk.label}
            </span>
            <span className="px-2 py-0.5 text-[11px] font-medium rounded-full bg-[#344453]/5 text-[#344453]/75">
              {timeframe}
            </span>
            {strategy.category && (
              <span className="px-2 py-0.5 text-[11px] font-medium rounded-full bg-[#344453]/10 text-[#344453]">
                {strategy.category}
              </span>
            )}
          </div>

          {/* CTA */}
          <div className="pt-4 border-t border-[#D0D5DA]/60">
            {isPremium ? (
              <Link
                href={`/strategies/${strategy.slug}`}
                className="inline-flex items-center gap-1.5 text-sm font-medium text-[#8A6E18] hover:text-[#8A6E18]/80 transition-colors group-hover:gap-2"
              >
                Voir la stratégie
                <ChevronRight size={14} />
              </Link>
            ) : isAuthenticated ? (
              <Link
                href="/pricing"
                className="inline-flex items-center gap-1.5 text-sm font-medium text-[#8A6E18] hover:text-[#8A6E18]/80 transition-colors"
              >
                <Lock size={12} />
                Débloquer avec Premium
                <ArrowRight size={14} />
              </Link>
            ) : (
              <a
                href={getLoginUrl()}
                className="inline-flex items-center gap-1.5 text-sm font-medium text-[#344453] hover:text-white/80 transition-colors"
              >
                Connexion pour accéder
                <ArrowRight size={14} />
              </a>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

/* ─── Main Page ─── */
export default function Strategies() {
  usePageTitle("Stratégies d'investissement");
  useSEO({
    title: "Stratégies d'Investissement — Approches Pédagogiques | WMB",
    description: "8 stratégies de trading documentées : options, swing, dividendes, penny stocks. Règles d'entrée/sortie, money management et exemples réels.",
    canonical: "/strategies",
  });
  const { isAuthenticated } = useAuth();
  const { isPremium, canAccess } = useSubscription();

  const { data: strategies, isLoading } = trpc.academy.listStrategies.useQuery();

  return (
    <Layout>
      {/* HERO */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#344453] via-[#2a3a47] to-[#1a2530]">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-[#D4A853]/30 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-20 w-96 h-96 bg-[#2E7D5B]/20 rounded-full blur-3xl" />
        </div>
        <div className="relative container py-16 lg:py-24">
          <div className="max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/10 rounded-full text-white/85 text-sm mb-6"
            >
              <Target size={16} />
              Stratégies de Trading
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-[56px] font-bold text-white leading-[1.1] mb-6"
            >
              Des stratégies éprouvées,
              <br />
              <span className="text-[#8A6E18]">expliquées pas à pas.</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-lg text-white/75 leading-relaxed max-w-xl mb-10"
            >
              8 stratégies documentées : options, swing, dividendes, penny stocks.
              Chaque fiche détaille les règles d'entrée, de sortie, le money management
              et des exemples réels. Aucun conseil — que de la pédagogie structurée.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="flex flex-wrap gap-6"
            >
              {[
                { icon: Target, label: "Règles claires" },
                { icon: Shield, label: "Gestion du risque" },
                { icon: AlertTriangle, label: "Disclaimer intégré" },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-2 text-white/85 text-sm">
                  <item.icon size={14} />
                  <span>{item.label}</span>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* DISCLAIMER */}
      <section className="bg-[#faf6ed] border-b border-[#D4A853]/20 py-3">
        <div className="container flex items-center gap-3 text-sm text-[#8B6914]">
          <AlertTriangle size={16} className="shrink-0" />
          <p>
            <strong>Avertissement :</strong> Les stratégies présentées sont à but
            informatif uniquement. Elles ne constituent en aucun cas un conseil
            d'investissement personnalisé. Tout investissement comporte des risques.
          </p>
        </div>
      </section>

      {/* APPROACH SECTION */}
      <section className="py-16 lg:py-20 bg-white">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <div>
              <h1 className="text-3xl font-bold text-[#344453]">Notre approche des stratégies</h1>
              <span className="wmb-accent" />
              <p className="mt-8 text-[#344453]/80 leading-relaxed text-lg">
                Chaque stratégie présentée sur WMB suit un cadre pédagogique rigoureux.
                L'objectif n'est pas de vous dire quoi acheter ou vendre, mais de vous montrer
                comment fonctionnent différentes approches de trading, avec leurs avantages,
                leurs limites et leurs risques.
              </p>
              <p className="mt-4 text-[#344453]/80 leading-relaxed text-lg">
                Chaque fiche stratégie détaille les règles d'entrée et de sortie, le money
                management associé, les conditions de marché favorables, et des exemples
                concrets pour illustrer le fonctionnement. Le disclaimer est toujours visible :
                ces stratégies sont éducatives, pas des recommandations.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: Target, title: "Règles d'entrée", desc: "Conditions précises pour ouvrir une position : indicateurs, niveaux techniques, confirmation de tendance." },
                { icon: Shield, title: "Money management", desc: "Taille de position, stop loss, take profit, ratio risque/rendement — la gestion du capital détaillée." },
                { icon: BarChart3, title: "Exemples réels", desc: "Des exemples concrets sur des actions réelles pour illustrer chaque stratégie en situation." },
                { icon: AlertTriangle, title: "Risques identifiés", desc: "Chaque stratégie liste ses risques spécifiques et les conditions de marché défavorables." },
              ].map((item) => (
                <div key={item.title} className="bg-[#F4F5F5] rounded-2xl p-5 border border-[#D0D5DA]">
                  <item.icon size={22} className="text-[#344453] mb-3" strokeWidth={2} />
                  <h3 className="font-semibold text-[#344453] text-sm mb-1">{item.title}</h3>
                  <p className="text-xs text-[#344453]/75 leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* STRATEGIES GRID */}
      <section className="py-16 lg:py-24 bg-[#F4F5F5]">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center justify-between mb-10">
              <h2 className="text-2xl font-bold text-[#344453]">
                Toutes les stratégies
              </h2>
              <span className="text-sm text-[#344453]/80">
                {strategies?.length || 0} stratégies disponibles
              </span>
            </div>

            {isLoading ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="h-72 bg-white rounded-2xl animate-pulse" />
                ))}
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {(strategies || []).map((strategy, i) => (
                  <StrategyCard
                    key={strategy.id}
                    strategy={strategy}
                    index={i}
                    isPremium={canAccess("strategies:trading")}
                    isAuthenticated={isAuthenticated}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* CROSS-SELL */}
      <section className="py-16 lg:py-20 bg-white">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-2xl lg:text-3xl font-bold text-[#344453] mb-4">
              Complétez votre arsenal
            </h2>
            <p className="text-[#344453]/75 mb-10 max-w-2xl mx-auto">
              Les stratégies prennent tout leur sens avec la formation et les scripts.
              Théorie + outils + méthode = une approche complète des marchés.
            </p>
            <div className="grid sm:grid-cols-2 gap-6">
              <Link
                href="/formation"
                className="group bg-white rounded-2xl p-6 border border-[#D0D5DA] hover:border-[#344453]/20 hover:shadow-lg transition-all text-left"
              >
                <div className="w-12 h-12 rounded-xl bg-[#344453]/10 flex items-center justify-center mb-4">
                  <GraduationCap size={22} className="text-[#344453]" />
                </div>
                <h3 className="text-lg font-semibold text-[#344453] mb-2">
                  Formation WMB
                </h3>
                <p className="text-sm text-[#344453]/75 mb-3">
                  62 cours structurés, 437+ leçons — des fondamentaux à l'analyse
                  technique.
                </p>
                <span className="text-sm font-medium text-[#344453] flex items-center gap-1 group-hover:gap-2 transition-all">
                  Voir la formation <ChevronRight size={14} />
                </span>
              </Link>
              <Link
                href="/admin/scripts"
                className="group bg-white rounded-2xl p-6 border border-[#D0D5DA] hover:border-[#344453]/20 hover:shadow-lg transition-all text-left"
              >
                <div className="w-12 h-12 rounded-xl bg-[#344453]/10 flex items-center justify-center mb-4">
                  <Code2 size={22} className="text-[#344453]" />
                </div>
                <h3 className="text-lg font-semibold text-[#344453] mb-2">
                  Scripts TradingView
                </h3>
                <p className="text-sm text-[#344453]/75 mb-3">
                  8 indicateurs Pine Script professionnels pour automatiser votre
                  analyse technique.
                </p>
                <span className="text-sm font-medium text-[#344453] flex items-center gap-1 group-hover:gap-2 transition-all">
                  Découvrir les scripts <ChevronRight size={14} />
                </span>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
