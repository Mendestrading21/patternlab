/**
 * QuizPresentation — Page publique de présentation du Quiz WMB
 * Format identique à Formation.tsx : hero immersif, sections explicatives, CTA pricing
 * Aucun outil interactif — le quiz est uniquement dans /dashboard/quiz
 */
import Layout from "@/components/Layout";
import { useAuth } from "@/_core/hooks/useAuth";
import { useSubscription } from "@/hooks/useSubscription";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Brain, Clock, BookOpen, ChevronRight, TrendingUp,
  BarChart3, PieChart, GraduationCap,
  ArrowRight, CheckCircle2, Crown, Target, Trophy, Shield,
  Zap, Lightbulb, Award, Star, Sparkles,
  Shuffle, Activity, Timer, BarChart, Layers,
} from "lucide-react";
import { useSEO } from "@/hooks/useSEO";
import { SEO_PAGES } from "@/lib/seoConfig";
import { QUIZ, ACADEMY } from "@shared/siteConfig";
import PageBreadcrumb from "@/components/PageBreadcrumb";
import { usePageTitle } from "@/hooks/usePageTitle";
import HeroBackdrop from "@/components/HeroBackdrop";
import { getLoginUrl } from "@/const";

/* ─── Animations ─── */
const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.08, duration: 0.5, ease: [0, 0, 0.2, 1] as [number, number, number, number] },
  }),
};


const THEME_CARDS = [
  { icon: TrendingUp, label: "Marchés", desc: "S&P 500, Fed, IPO, bear/bull markets, circuit breakers...", count: "35", color: "#344453" },
  { icon: BarChart3, label: "Indicateurs", desc: "RSI, MACD, Bollinger, Ichimoku, ADX, Put/Call ratio...", count: "35", color: "#2E7D5B" },
  { icon: BookOpen, label: "Glossaire", desc: "ETF, SPAC, alpha/beta, QE, margin call, FOMO...", count: "36", color: "#D4A853" },
  { icon: GraduationCap, label: "Formation", desc: "MPT, Sharpe, DCA, analyse fondamentale, règle des 72...", count: "34", color: "#344453" },
  { icon: PieChart, label: "ETFs", desc: "SPY, QQQ, smart beta, TER, réplication, inverse...", count: "34", color: "#B0413E" },
  { icon: Shuffle, label: "Mode Mixte", desc: "Toutes les catégories mélangées — le défi ultime", count: "30", color: "#D4A853" },
];

export default function QuizPresentation() {
  usePageTitle(SEO_PAGES.quiz?.title || "Quiz Bourse — WMB");
  useSEO(SEO_PAGES.quiz);

  const { isAuthenticated } = useAuth();
  const { canAccess } = useSubscription();
  const hasQuizAccess = canAccess("formation:quiz");

  return (
    <Layout>
      {/* ═══════════ IMMERSIVE HERO ═══════════ */}
      <section className="relative overflow-hidden min-h-[600px] lg:min-h-[700px] bg-[#23303c]">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a2530] via-[#2a3845] to-[#3a4b5a]" />
        <HeroBackdrop accent="#D4A853" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1a2530]/85 via-[#1a2530]/45 to-transparent" />
        <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-[#D4A853]/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#344453]/20 rounded-full blur-[100px]" />

        <div className="relative container py-20 lg:py-32">
          <PageBreadcrumb items={[{ label: "Académie", href: "/formation" }, { label: "Quiz" }]} className="mb-8" />
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left — Text */}
            <div>
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/15 backdrop-blur-sm mb-8"
              >
                <Brain size={16} className="text-[#D4A853]" />
                <span className="text-white/90 text-sm font-medium">Quiz WMB</span>
                <span className="w-px h-4 bg-white/30" />
                <span className="text-[#D4A853] text-xs font-bold">{QUIZ.totalLabel} questions</span>
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.1 }}
                className="text-4xl md:text-5xl lg:text-[56px] font-bold text-white leading-[1.08] mb-6"
              >
                Testez vos connaissances{" "}
                <span className="bg-gradient-to-r from-[#D4A853] to-[#E8C97A] bg-clip-text text-transparent">
                  en bourse.
                </span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.2 }}
                className="text-lg text-white/80 leading-relaxed mb-10 max-w-xl"
              >
                {QUIZ.totalLabel} questions réparties en {QUIZ.themeCount} catégories pour évaluer et renforcer
                vos connaissances. Chaque question est accompagnée d'une explication pédagogique détaillée.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.3 }}
                className="flex flex-col sm:flex-row gap-4 mb-10"
              >
                {isAuthenticated && hasQuizAccess ? (
                  <Link
                    href="/dashboard/quiz"
                    className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/20 transition-all text-base"
                  >
                    <Brain size={18} /> Accéder au quiz
                  </Link>
                ) : isAuthenticated ? (
                  <Link
                    href="/pricing"
                    className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/20 transition-all text-base"
                  >
                    <Crown size={18} /> Débloquer le quiz complet
                  </Link>
                ) : (
                  <a
                    href={getLoginUrl("/dashboard/quiz")}
                    className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/20 transition-all text-base"
                  >
                    <Brain size={18} /> Essayer gratuitement
                  </a>
                )}
                <a
                  href="#comment-ca-marche"
                  className="inline-flex items-center justify-center px-8 py-4 border border-white/25 text-white font-medium rounded-xl hover:bg-white/10 transition-colors text-base"
                >
                  Comment ça marche
                </a>
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.7, delay: 0.5 }}
                className="flex flex-wrap items-center gap-x-6 gap-y-2 text-white/70 text-xs"
              >
                <span className="flex items-center gap-1.5"><Shield size={12} className="text-[#D4A853]" /> Éducatif uniquement</span>
                <span className="flex items-center gap-1.5"><Sparkles size={12} /> Accès découverte inclus</span>
                <span className="flex items-center gap-1.5"><Trophy size={12} /> Badges à gagner</span>
                <span className="flex items-center gap-1.5"><Zap size={12} /> Explications détaillées</span>
              </motion.div>
            </div>

            {/* Right — Stats Card */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="hidden lg:block"
            >
              <div className="bg-white/[0.06] backdrop-blur-xl rounded-2xl border border-white/15 p-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-40 h-40 bg-[#D4A853]/5 rounded-full blur-3xl" />
                <div className="relative">
                  <div className="flex items-center gap-3 mb-8">
                    <div className="w-12 h-12 rounded-xl bg-[#D4A853]/15 flex items-center justify-center">
                      <Brain size={22} className="text-[#D4A853]" />
                    </div>
                    <div>
                      <p className="text-white font-bold text-lg">Quiz WMB</p>
                      <p className="text-white/50 text-xs">Testez, apprenez, progressez</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    {[
                      { value: QUIZ.totalLabel, label: "Questions", icon: Brain },
                      { value: String(QUIZ.themeCount), label: "Thèmes", icon: Layers },
                      { value: "4", label: "Niveaux", icon: Target },
                      { value: String(QUIZ.questionsPerSession), label: "Par session", icon: Timer },
                    ].map((stat) => (
                      <div key={stat.label} className="bg-white/[0.06] rounded-xl p-4 border border-white/[0.08]">
                        <stat.icon size={16} className="text-[#D4A853] mb-2" />
                        <p className="text-2xl font-bold text-white">{stat.value}</p>
                        <p className="text-white/40 text-xs">{stat.label}</p>
                      </div>
                    ))}
                  </div>
                  <div className="bg-[#D4A853]/10 border border-[#D4A853]/20 rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-1">
                      <Trophy size={14} className="text-[#D4A853]" />
                      <p className="text-[#D4A853] text-xs font-bold">Système de badges</p>
                    </div>
                    <p className="text-white/60 text-[11px]">Gagnez des badges en atteignant {QUIZ.badgeThreshold}% de bonnes réponses par thème</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ═══════════ DISCLAIMER ═══════════ */}
      <section className="bg-white border-b border-[#E1E6EA]">
        <div className="container py-4">
          <p className="text-[11px] text-[#1E1E1E]/40 text-center">
            Ce quiz est strictement informatif. Il ne constitue en aucun cas un conseil en investissement.
          </p>
        </div>
      </section>

      {/* ═══════════ POURQUOI TESTER SES CONNAISSANCES ═══════════ */}
      <section className="py-20 lg:py-28 bg-[#FAFAFA]">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} custom={0} variants={fadeUp}>
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#D4A853]/10 text-[#8A6E18] text-xs font-bold mb-6">
                <Lightbulb size={14} /> Pourquoi se tester
              </span>
              <h2 className="text-3xl lg:text-4xl font-bold text-[#344453] mb-4">
                Apprendre, c'est bien. Vérifier, c'est mieux.
              </h2>
              <p className="text-[#1E1E1E]/60 text-lg leading-relaxed">
                Le quiz WMB vous permet de mesurer votre compréhension réelle des marchés financiers.
                Chaque question est accompagnée d'une explication détaillée pour renforcer vos acquis.
              </p>
            </motion.div>
          </div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-8"
          >
            {[
              {
                icon: Brain, title: "Apprentissage actif",
                desc: "Répondre à des questions engage votre mémoire bien plus efficacement que la lecture passive. Chaque erreur est une opportunité d'apprentissage.",
              },
              {
                icon: Target, title: "Identifiez vos lacunes",
                desc: "Le quiz révèle précisément les domaines où vous devez progresser. Concentrez vos efforts là où ils comptent le plus.",
              },
              {
                icon: Trophy, title: "Mesurez votre progression",
                desc: "Suivez votre score, gagnez des badges et voyez votre niveau évoluer au fil du temps. La progression est la meilleure motivation.",
              },
            ].map((item, i) => (
              <motion.div key={item.title} custom={i} variants={fadeUp} className="bg-white rounded-2xl p-8 border border-[#E1E6EA]">
                <div className="w-12 h-12 rounded-xl bg-[#344453]/5 flex items-center justify-center mb-5">
                  <item.icon size={22} className="text-[#344453]" />
                </div>
                <h3 className="text-lg font-bold text-[#344453] mb-3">{item.title}</h3>
                <p className="text-sm text-[#1E1E1E]/60 leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ═══════════ LES THÈMES ═══════════ */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#344453]/5 text-[#344453] text-xs font-bold mb-6">
              <Layers size={14} /> {QUIZ.themeCount} catégories
            </span>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#344453] mb-4">
              {QUIZ.themeCount} thèmes pour couvrir l'essentiel
            </h2>
            <p className="text-[#1E1E1E]/60 text-lg leading-relaxed">
              Chaque thème couvre un domaine clé de la finance. Choisissez votre spécialité ou tentez le mode mixte pour un défi complet.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {THEME_CARDS.map((theme, i) => (
              <motion.div
                key={theme.label}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                custom={i}
                variants={fadeUp}
                className="bg-white rounded-2xl border border-[#E1E6EA] overflow-hidden hover:shadow-lg hover:shadow-[#344453]/5 transition-all group"
              >
                <div className="h-1.5 w-full" style={{ backgroundColor: theme.color }} />
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${theme.color}10` }}>
                      <theme.icon size={20} style={{ color: theme.color }} />
                    </div>
                    <span className="text-xs font-bold text-[#1E1E1E]/40">{theme.count} questions</span>
                  </div>
                  <h3 className="text-lg font-bold text-[#344453] mb-2">{theme.label}</h3>
                  <p className="text-sm text-[#1E1E1E]/50 leading-relaxed">{theme.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ COMMENT ÇA MARCHE ═══════════ */}
      <section id="comment-ca-marche" className="py-20 lg:py-28 bg-[#FAFAFA]">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#2E7D5B]/10 text-[#2E7D5B] text-xs font-bold mb-6">
              <Zap size={14} /> Fonctionnement
            </span>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#344453] mb-4">
              Comment fonctionne le quiz
            </h2>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: "01", title: "Choisissez un thème", desc: "Sélectionnez une catégorie ou le mode mixte pour un défi complet.", icon: Layers },
              { step: "02", title: "Répondez aux questions", desc: `${QUIZ.questionsPerSession} questions par session avec 4 choix de réponse. Pas de limite de temps.`, icon: Brain },
              { step: "03", title: "Lisez les explications", desc: "Chaque réponse est accompagnée d'une explication pédagogique détaillée.", icon: BookOpen },
              { step: "04", title: "Gagnez des badges", desc: `Atteignez ${QUIZ.badgeThreshold}% de bonnes réponses pour débloquer le badge du thème.`, icon: Award },
            ].map((item, i) => (
              <motion.div
                key={item.step}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                custom={i}
                variants={fadeUp}
                className="text-center"
              >
                <div className="w-16 h-16 rounded-2xl bg-white border border-[#E1E6EA] flex items-center justify-center mx-auto mb-4 shadow-sm">
                  <item.icon size={24} className="text-[#344453]" />
                </div>
                <span className="text-[#D4A853] text-xs font-bold">{item.step}</span>
                <h3 className="text-base font-bold text-[#344453] mt-1 mb-2">{item.title}</h3>
                <p className="text-sm text-[#1E1E1E]/50 leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ FONCTIONNALITÉS ═══════════ */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#D4A853]/10 text-[#8A6E18] text-xs font-bold mb-6">
                <Star size={14} /> Fonctionnalités
              </span>
              <h2 className="text-3xl lg:text-4xl font-bold text-[#344453] mb-6">
                Un quiz pensé pour apprendre
              </h2>
              <p className="text-[#1E1E1E]/60 text-lg leading-relaxed mb-8">
                Chaque fonctionnalité est conçue pour maximiser votre apprentissage et rendre l'expérience engageante.
              </p>
              <ul className="space-y-4">
                {[
                  { icon: CheckCircle2, text: "Explications pédagogiques après chaque réponse" },
                  { icon: CheckCircle2, text: "Système de streak pour maintenir la motivation" },
                  { icon: CheckCircle2, text: "Badges par thème et badge Master global" },
                  { icon: CheckCircle2, text: "Historique complet de vos sessions" },
                  { icon: CheckCircle2, text: "Questions toujours différentes (ordre aléatoire)" },
                  { icon: CheckCircle2, text: "Statistiques détaillées par catégorie" },
                ].map((item) => (
                  <li key={item.text} className="flex items-start gap-3">
                    <item.icon size={18} className="text-[#2E7D5B] mt-0.5 shrink-0" />
                    <span className="text-[#1E1E1E]/70 text-base">{item.text}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-gradient-to-br from-[#344453] to-[#1a2530] rounded-2xl p-8 lg:p-10">
              <div className="space-y-6">
                <div className="bg-white/[0.06] rounded-xl p-5 border border-white/[0.08]">
                  <p className="text-white/40 text-xs font-bold uppercase tracking-wider mb-2">Exemple de question</p>
                  <p className="text-white font-medium mb-4">Quel indicateur mesure la force d'une tendance sans indiquer sa direction ?</p>
                  <div className="space-y-2">
                    {["RSI", "MACD", "ADX", "Stochastique"].map((opt, i) => (
                      <div key={opt} className={`px-4 py-2.5 rounded-lg text-sm ${i === 2 ? "bg-[#2E7D5B]/20 border border-[#2E7D5B]/30 text-[#2E7D5B]" : "bg-white/[0.04] border border-white/[0.06] text-white/60"}`}>
                        {opt}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-[#2E7D5B]/10 border border-[#2E7D5B]/20 rounded-xl p-4">
                  <p className="text-[#2E7D5B] text-xs font-bold mb-1">Explication</p>
                  <p className="text-white/70 text-sm leading-relaxed">L'ADX (Average Directional Index) mesure la force d'une tendance de 0 à 100, sans indiquer si elle est haussière ou baissière.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ CHIFFRES CLÉS ═══════════ */}
      <section className="py-16 lg:py-20 bg-[#FAFAFA]">
        <div className="container">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { value: QUIZ.totalLabel, label: "Questions", sub: "réparties en " + QUIZ.themeCount + " thèmes" },
              { value: String(QUIZ.themeCount) + "+1", label: "Catégories", sub: "dont le mode mixte" },
              { value: "4", label: "Choix", sub: "par question" },
              { value: String(QUIZ.badgeThreshold) + "%", label: "Pour le badge", sub: "objectif à atteindre" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <p className="text-3xl lg:text-4xl font-bold text-[#344453]">{stat.value}</p>
                <p className="text-sm font-semibold text-[#344453] mt-1">{stat.label}</p>
                <p className="text-xs text-[#1E1E1E]/40 mt-0.5">{stat.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ CROSS-SELL ═══════════ */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-2xl lg:text-3xl font-bold text-[#344453] mb-4">Complétez votre apprentissage</h2>
            <p className="text-[#1E1E1E]/50 text-base">Le quiz fonctionne en synergie avec les autres outils de l'Académie WMB.</p>
          </div>
          <div className="grid sm:grid-cols-3 gap-6">
            {[
              { icon: GraduationCap, title: "Formation", desc: "7 modules complets pour maîtriser les fondamentaux.", href: "/formation" },
              { icon: BarChart3, title: "Indicateurs", desc: "54 fiches techniques détaillées avec interprétation.", href: "/indicateurs-tendance" },
              { icon: BookOpen, title: "Glossaire", desc: "1 111+ termes financiers expliqués clairement.", href: "/glossaire" },
            ].map((item) => (
              <Link key={item.title} href={item.href} className="bg-[#FAFAFA] rounded-2xl p-6 border border-[#E1E6EA] hover:border-[#D4A853]/30 hover:shadow-lg transition-all group">
                <div className="w-10 h-10 rounded-xl bg-[#344453]/5 flex items-center justify-center mb-4">
                  <item.icon size={18} className="text-[#344453]" />
                </div>
                <h3 className="text-base font-bold text-[#344453] mb-2">{item.title}</h3>
                <p className="text-sm text-[#1E1E1E]/50 leading-relaxed mb-3">{item.desc}</p>
                <span className="text-xs font-medium text-[#D4A853] flex items-center gap-1 group-hover:gap-2 transition-all">
                  Découvrir <ChevronRight size={12} />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ FINAL CTA ═══════════ */}
      <section className="py-20 lg:py-28 bg-gradient-to-br from-[#344453] via-[#3d5060] to-[#344453]">
        <div className="container text-center">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} custom={0} variants={fadeUp}>
            <div className="w-16 h-16 rounded-2xl bg-[#D4A853]/15 flex items-center justify-center mx-auto mb-6">
              <Brain size={28} className="text-[#D4A853]" />
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
              Prêt à tester vos connaissances ?
            </h2>
            <p className="text-white/70 text-lg mb-10 max-w-xl mx-auto">
              Testez vos connaissances financières avec des questions à choix multiples. Créez un compte pour commencer.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {isAuthenticated ? (
                <Link
                  href={hasQuizAccess ? "/dashboard/quiz" : "/pricing"}
                  className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/20 transition-all"
                >
                  {hasQuizAccess ? <><Brain size={18} /> Accéder au quiz</> : <><Crown size={18} /> Passer Premium</>}
                </Link>
              ) : (
                <a
                  href={getLoginUrl("/dashboard/quiz")}
                  className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-[#D4A853] to-[#C4A052] text-[#1a2530] font-bold rounded-xl hover:shadow-2xl hover:shadow-[#D4A853]/20 transition-all"
                >
                  <Brain size={18} /> Essayer gratuitement
                </a>
              )}
              <Link
                href="/pricing"
                className="inline-flex items-center justify-center px-8 py-4 border border-white/25 text-white font-medium rounded-xl hover:bg-white/10 transition-colors"
              >
                Voir les offres
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
}
