/**
 * DashboardIndicateurs — Indicateurs de tendance dans l'espace membre
 * Fiches intégrées directement (pas de redirection vers la page publique)
 * Route: /dashboard/indicateurs
 */
import { usePageTitle } from "@/hooks/usePageTitle";
import { useSEO } from "@/hooks/useSEO";
import Layout from "@/components/Layout";
import { useAuth } from "@/_core/hooks/useAuth";
import { useSubscription } from "@/hooks/useSubscription";
import { Link } from "wouter";
import { useState, useMemo, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Activity, BarChart3, TrendingUp, Layers, Target,
  ChevronRight, Lock, Loader2, ArrowRight, Crown,
  BookOpen, Zap, Search, Eye, LineChart, Gauge,
  ArrowLeft, Clock, Star, AlertTriangle, Lightbulb,
  Shield, X, Filter, Grid3X3, ChevronDown, ChevronUp,
  Info, Crosshair,
} from "lucide-react";
import { INDICATORS as INDICATORS_CONFIG } from "@shared/siteConfig";
import PageBreadcrumb from "@/components/PageBreadcrumb";
import { getLoginUrl } from "@/const";
import {
  INDICATORS,
  LEVEL_STYLES,
  CATEGORY_LABELS,
  CATEGORY_COLORS,
  CATEGORY_ICONS,
  FREE_INDICATOR_LIMIT,
  type Indicator,
  type Level,
  type Category,
} from "@/pages/IndicateursTendance";

// ═══════════════════════════════════════════════════════════
// CATEGORY TABS
// ═══════════════════════════════════════════════════════════
const CATEGORY_TABS: { key: string; label: string; icon: typeof Layers }[] = [
  { key: "all", label: "Tous", icon: Grid3X3 },
  { key: "tendance", label: "Tendance", icon: TrendingUp },
  { key: "momentum", label: "Momentum", icon: Gauge },
  { key: "volatilite", label: "Volatilité", icon: Activity },
  { key: "volume", label: "Volume", icon: BarChart3 },
  { key: "pattern", label: "Patterns", icon: Eye },
  { key: "structure", label: "Structure", icon: Layers },
  { key: "institutionnel", label: "Institutionnel", icon: Shield },
  { key: "synthese", label: "Synthèse", icon: Target },
];

// Complexity bar
function ComplexityBar({ level }: { level: number }) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((i) => (
        <div
          key={i}
          className={`h-1.5 w-5 rounded-full ${i <= level ? "bg-[#D4A853]" : "bg-white/10"}`}
        />
      ))}
    </div>
  );
}

export default function DashboardIndicateurs() {
  usePageTitle("Indicateurs — Espace Membre");
  useSEO({
    title: "Mes Indicateurs | Espace Membre WMB",
    description: "Explorez les 54 indicateurs techniques de l'encyclopédie WMB.",
    canonical: "/dashboard/indicateurs",
  });

  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const { isPremium, canAccess } = useSubscription();

  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedIndicator, setSelectedIndicator] = useState<Indicator | null>(null);

  const filteredIndicators = useMemo(() => {
    let list = INDICATORS;
    if (selectedCategory !== "all") {
      list = list.filter((ind) => ind.category === selectedCategory);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (ind) =>
          ind.name.toLowerCase().includes(q) ||
          ind.nameFr.toLowerCase().includes(q) ||
          ind.shortDesc.toLowerCase().includes(q)
      );
    }
    return list;
  }, [selectedCategory, searchQuery]);

  const freeIds = useMemo(() => INDICATORS.slice(0, FREE_INDICATOR_LIMIT).map((i) => i.id), []);

  const isLocked = useCallback(
    (ind: Indicator) => !isPremium && !freeIds.includes(ind.id),
    [isPremium, freeIds]
  );

  /* ─── Loading ─── */
  if (authLoading) {
    return (
      <Layout>
        <section className="min-h-[80vh] flex items-center justify-center bg-[#FAFAFA]">
          <div className="text-center">
            <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-[#D4A853] to-[#C4A052] flex items-center justify-center shadow-lg shadow-[#D4A853]/20">
              <Loader2 size={28} className="animate-spin text-white" />
            </div>
            <p className="text-[#1E1E1E]/50 text-sm">Chargement...</p>
          </div>
        </section>
      </Layout>
    );
  }

  /* ─── Not authenticated ─── */
  if (!isAuthenticated) {
    return (
      <Layout>
        <section className="min-h-[80vh] flex items-center justify-center bg-[#FAFAFA]">
          <div className="max-w-md text-center px-6">
            <div className="w-20 h-20 mx-auto mb-6 rounded-3xl bg-[#344453]/5 flex items-center justify-center">
              <Lock size={36} className="text-[#344453]/30" />
            </div>
            <h1 className="text-2xl font-bold text-[#344453] mb-3">Connexion requise</h1>
            <p className="text-[#1E1E1E]/60 mb-8">Connectez-vous pour accéder aux indicateurs techniques.</p>
            <a href={getLoginUrl()} className="inline-flex items-center gap-2 px-8 py-4 bg-[#344453] text-white font-semibold rounded-xl hover:bg-[#344453]/90 transition-colors">
              Se connecter <ArrowRight size={16} />
            </a>
          </div>
        </section>
      </Layout>
    );
  }

  /* ═══════════════════════════════════════════════════════════
   * INDICATOR DETAIL VIEW (inline, no redirect)
   * ═══════════════════════════════════════════════════════════ */
  if (selectedIndicator) {
    const ind = selectedIndicator;
    const lvl = LEVEL_STYLES[ind.level];
    const catColor = CATEGORY_COLORS[ind.category] || "from-gray-600 to-gray-700";
    const CatIcon = CATEGORY_ICONS[ind.category] || Layers;

    if (isLocked(ind)) {
      return (
        <Layout>
          <div className="bg-gradient-to-br from-[#344453] via-[#2a3a47] to-[#1E1E1E] min-h-screen">
            <div className={`bg-gradient-to-r ${catColor} py-12`}>
              <div className="container">
                <button onClick={() => setSelectedIndicator(null)} className="flex items-center gap-2 text-white/75 hover:text-white mb-6 transition-colors text-sm">
                  <ArrowLeft size={16} /> Retour aux indicateurs
                </button>
                <h1 className="text-3xl md:text-4xl font-bold text-white">{ind.nameFr}</h1>
                <p className="text-white/75 mt-2 text-lg max-w-2xl">{ind.shortDesc}</p>
              </div>
            </div>
            <div className="container py-16">
              <div className="max-w-lg mx-auto text-center">
                <div className="w-20 h-20 rounded-2xl bg-[#D4A853]/10 border border-[#D4A853]/20 flex items-center justify-center mx-auto mb-6">
                  <Crown size={36} className="text-[#8A6E18]" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-3">Contenu Premium</h2>
                <p className="text-white/85 mb-8">Débloquez l'accès complet aux {INDICATORS.length} fiches d'indicateurs techniques avec définitions détaillées, interprétations multi-scénarios, limites et cas pratiques.</p>
                <Link href="/pricing" className="inline-flex items-center gap-2 px-7 py-3.5 bg-gradient-to-r from-[#D4A853] to-[#C49A4A] text-white font-bold rounded-xl hover:shadow-lg hover:shadow-[#D4A853]/20 transition-all">
                  Voir les offres Premium
                </Link>
              </div>
            </div>
          </div>
        </Layout>
      );
    }

    return (
      <Layout>
        <div className="bg-gradient-to-br from-[#344453] via-[#2a3a47] to-[#1E1E1E] min-h-screen">
          {/* Detail Header */}
          <div className={`bg-gradient-to-br ${catColor} relative overflow-hidden`}>
            <div className="absolute inset-0 opacity-5" style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")" }} />
            <div className="relative container py-10 lg:py-14">
              <PageBreadcrumb items={[{ label: "Mon espace", href: "/dashboard" }, { label: "Indicateurs", href: "/dashboard/indicateurs" }, { label: ind.nameFr }]} className="mb-6" />
              <button onClick={() => setSelectedIndicator(null)} className="flex items-center gap-2 text-white/85 hover:text-white mb-6 transition-colors text-sm font-medium">
                <ArrowLeft size={16} /> Retour aux indicateurs
              </button>
              <div className="flex flex-wrap items-center gap-3 mb-4">
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${lvl.bg} ${lvl.text} border ${lvl.border}`}>{lvl.label}</span>
                <span className="px-3 py-1 rounded-full text-xs font-medium bg-white/10 text-white/85 flex items-center gap-1.5"><CatIcon size={11} /> {CATEGORY_LABELS[ind.category]}</span>
                <span className="flex items-center gap-1.5 text-white/80 text-xs"><Clock size={12} /> {ind.readTime} min de lecture</span>
              </div>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-2">{ind.nameFr}</h1>
              <p className="text-sm text-white/70 font-mono mb-4">{ind.name}</p>
              <p className="text-base text-white/85 max-w-2xl leading-relaxed">{ind.shortDesc}</p>
              <div className="mt-6 flex items-center gap-3">
                <span className="text-[11px] uppercase tracking-widest text-white/70">Complexité</span>
                <ComplexityBar level={ind.complexity} />
              </div>
            </div>
          </div>

          {/* Detail Content */}
          <div className="container py-10 lg:py-14">
            <div className="max-w-4xl mx-auto space-y-8">
              {/* Image */}
              {ind.image && (
                <div className="rounded-2xl overflow-hidden border border-white/10">
                  <img src={ind.image} alt={ind.nameFr} className="w-full object-contain max-h-[400px] bg-[#0f1a24]" />
                </div>
              )}

              {/* Chart Reading Guide */}
              {ind.chartReadingGuide && (
                <div className="bg-[#D4A853]/10 border border-[#D4A853]/20 rounded-2xl p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Eye size={18} className="text-[#D4A853]" />
                    <h3 className="text-base font-bold text-[#D4A853]">Guide de lecture du graphique</h3>
                  </div>
                  <p className="text-white/80 text-sm leading-relaxed">{ind.chartReadingGuide}</p>
                </div>
              )}

              {/* Description complète */}
              <div className="bg-white/[0.04] rounded-2xl p-6 border border-white/[0.08]">
                <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                  <BookOpen size={18} className="text-[#D4A853]" /> Description
                </h3>
                <p className="text-white/80 text-sm leading-relaxed">{ind.fullDesc}</p>
              </div>

              {/* Comment ça fonctionne */}
              <div className="bg-white/[0.04] rounded-2xl p-6 border border-white/[0.08]">
                <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                  <Lightbulb size={18} className="text-[#D4A853]" /> Comment ça fonctionne
                </h3>
                <p className="text-white/80 text-sm leading-relaxed">{ind.howItWorks}</p>
              </div>

              {/* Secondary Image */}
              {ind.secondaryImage && (
                <div className="rounded-2xl overflow-hidden border border-white/10">
                  <img src={ind.secondaryImage} alt={`${ind.nameFr} — détail`} className="w-full object-contain max-h-[350px] bg-[#0f1a24]" />
                </div>
              )}

              {/* Interprétation */}
              <div className="bg-white/[0.04] rounded-2xl p-6 border border-white/[0.08]">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <Crosshair size={18} className="text-[#D4A853]" /> Interprétation
                </h3>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-4">
                    <p className="text-emerald-400 text-xs font-bold uppercase tracking-wider mb-2">Signal haussier</p>
                    <p className="text-white/80 text-sm leading-relaxed">{ind.interpretation.bullish}</p>
                  </div>
                  <div className="bg-rose-500/10 border border-rose-500/20 rounded-xl p-4">
                    <p className="text-rose-400 text-xs font-bold uppercase tracking-wider mb-2">Signal baissier</p>
                    <p className="text-white/80 text-sm leading-relaxed">{ind.interpretation.bearish}</p>
                  </div>
                  <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4">
                    <p className="text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">En range</p>
                    <p className="text-white/80 text-sm leading-relaxed">{ind.interpretation.range}</p>
                  </div>
                  <div className="bg-violet-500/10 border border-violet-500/20 rounded-xl p-4">
                    <p className="text-violet-400 text-xs font-bold uppercase tracking-wider mb-2">Divergence</p>
                    <p className="text-white/80 text-sm leading-relaxed">{ind.interpretation.divergence}</p>
                  </div>
                </div>
              </div>

              {/* Multi-Timeframe */}
              <div className="bg-white/[0.04] rounded-2xl p-6 border border-white/[0.08]">
                <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                  <Clock size={18} className="text-[#D4A853]" /> Multi-Timeframe
                </h3>
                <p className="text-white/80 text-sm leading-relaxed">{ind.multiTimeframe}</p>
              </div>

              {/* Limites & Erreurs courantes */}
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="bg-white/[0.04] rounded-2xl p-6 border border-white/[0.08]">
                  <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
                    <AlertTriangle size={16} className="text-amber-400" /> Limites
                  </h3>
                  <ul className="space-y-2">
                    {ind.limits.map((l, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-white/70">
                        <span className="w-1 h-1 rounded-full bg-amber-400 mt-2 shrink-0" />
                        {l}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-white/[0.04] rounded-2xl p-6 border border-white/[0.08]">
                  <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
                    <X size={16} className="text-rose-400" /> Erreurs courantes
                  </h3>
                  <ul className="space-y-2">
                    {ind.commonMistakes.map((m, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-white/70">
                        <span className="w-1 h-1 rounded-full bg-rose-400 mt-2 shrink-0" />
                        {m}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Combinaisons */}
              <div className="bg-white/[0.04] rounded-2xl p-6 border border-white/[0.08]">
                <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
                  <Zap size={16} className="text-[#D4A853]" /> Combinaisons recommandées
                </h3>
                <div className="flex flex-wrap gap-2">
                  {ind.combinations.map((c, i) => (
                    <span key={i} className="px-3 py-1.5 bg-[#D4A853]/10 border border-[#D4A853]/20 rounded-lg text-sm text-[#D4A853]">{c}</span>
                  ))}
                </div>
              </div>

              {/* Cas pratique */}
              <div className="bg-emerald-500/5 border border-emerald-500/15 rounded-2xl p-6">
                <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
                  <Star size={16} className="text-emerald-400" /> Cas pratique
                </h3>
                <p className="text-white/80 text-sm leading-relaxed italic">{ind.practicalCase}</p>
              </div>

              {/* Key Levels */}
              {ind.keyLevels && ind.keyLevels.length > 0 && (
                <div className="bg-white/[0.04] rounded-2xl p-6 border border-white/[0.08]">
                  <h3 className="text-base font-bold text-white mb-3">Niveaux clés</h3>
                  <div className="flex flex-wrap gap-2">
                    {ind.keyLevels.map((kl, i) => (
                      <span key={i} className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white/70">{kl}</span>
                    ))}
                  </div>
                </div>
              )}

              {/* Advanced Version */}
              {ind.advancedVersion && (
                <div className="bg-violet-500/5 border border-violet-500/15 rounded-2xl p-6">
                  <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
                    <Info size={16} className="text-violet-400" /> Version avancée
                  </h3>
                  <p className="text-white/80 text-sm leading-relaxed">{ind.advancedVersion}</p>
                </div>
              )}

              {/* Related Indicators */}
              {ind.relatedIndicators.length > 0 && (
                <div className="bg-white/[0.04] rounded-2xl p-6 border border-white/[0.08]">
                  <h3 className="text-base font-bold text-white mb-3">Indicateurs liés</h3>
                  <div className="flex flex-wrap gap-2">
                    {ind.relatedIndicators.map((name) => {
                      const related = INDICATORS.find((i) => i.name === name || i.nameFr === name);
                      return (
                        <button
                          key={name}
                          onClick={() => related && setSelectedIndicator(related)}
                          className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white/70 hover:bg-white/10 hover:text-white transition-colors"
                        >
                          {name}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Disclaimer */}
              <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl p-4 text-center">
                <p className="text-white/30 text-[11px] leading-relaxed">
                  Ce contenu est strictement strictement informatif. Il ne constitue en aucun cas un conseil en investissement. Consultez un professionnel agréé avant toute décision.
                </p>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  /* ═══════════════════════════════════════════════════════════
   * MAIN LIST VIEW
   * ═══════════════════════════════════════════════════════════ */
  return (
    <Layout>
      {/* ═══════════ HERO ═══════════ */}
      <section className="relative overflow-hidden bg-[#1a2530]">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-[#344453] via-[#1a2530] to-[#0f1a24]" />
          <div className="absolute inset-0 opacity-[0.04]" style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, white 1px, transparent 0)`,
            backgroundSize: "32px 32px",
          }} />
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#D4A853]/5 rounded-full blur-[120px]" />
        </div>

        <div className="relative container py-10 lg:py-14">
          <PageBreadcrumb items={[{ label: "Mon espace", href: "/dashboard" }, { label: "Indicateurs" }]} className="mb-8" />

          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8 mb-10">
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
              <div className="flex items-center gap-2 mb-3">
                <div className="h-px w-8 bg-[#D4A853]" />
                <span className="text-[#D4A853] text-xs font-bold uppercase tracking-[0.2em]">Encyclopédie technique</span>
              </div>
              <h1 className="text-3xl lg:text-4xl font-bold text-white mb-2">
                Indicateurs de Tendance
              </h1>
              <p className="text-white/50 text-base max-w-md">
                {INDICATORS_CONFIG.count} indicateurs techniques expliqués en détail : définition, interprétation, limites et cas pratiques.
              </p>
              {!isPremium && (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-500/15 rounded-full mt-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  <span className="text-emerald-300 text-xs font-medium">{FREE_INDICATOR_LIMIT} indicateurs gratuits</span>
                </div>
              )}
            </motion.div>
          </div>

          {/* Stats Row */}
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
            className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
            {[
              { value: INDICATORS.length, label: "Indicateurs", sub: "fiches détaillées", icon: Activity, color: "#D4A853" },
              { value: Object.keys(CATEGORY_LABELS).length, label: "Catégories", sub: "familles d'indicateurs", icon: Layers, color: "#2E7D5B" },
              { value: 3, label: "Niveaux", sub: "débutant à avancé", icon: Target, color: "#344453" },
              { value: "5-8", suffix: " min", label: "Lecture", sub: "par indicateur", icon: BookOpen, color: "#6B7280" },
            ].map((stat) => (
              <div key={stat.label} className="bg-white/[0.06] backdrop-blur-sm rounded-2xl p-4 lg:p-5 border border-white/[0.08]">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${stat.color}20` }}>
                    <stat.icon size={15} style={{ color: stat.color }} />
                  </div>
                  <span className="text-white/40 text-xs font-medium">{stat.label}</span>
                </div>
                <div className="text-2xl lg:text-3xl font-bold text-white mb-0.5">
                  {stat.value}{stat.suffix || ""}
                </div>
                <p className="text-white/30 text-[11px]">{stat.sub}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ═══════════ SEARCH + CATEGORY FILTER ═══════════ */}
      <section className="bg-white border-b border-[#E1E6EA] sticky top-0 z-30">
        <div className="container py-4">
          {/* Search */}
          <div className="relative mb-4">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#1E1E1E]/30" />
            <input
              type="text"
              placeholder="Rechercher un indicateur..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-3 bg-[#F4F5F5] border border-[#E1E6EA] rounded-xl text-sm text-[#344453] placeholder:text-[#1E1E1E]/30 focus:outline-none focus:border-[#D4A853]/40 focus:ring-2 focus:ring-[#D4A853]/10 transition-all"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery("")} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#1E1E1E]/30 hover:text-[#1E1E1E]/60">
                <X size={16} />
              </button>
            )}
          </div>
          {/* Category tabs */}
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
            {CATEGORY_TABS.map((cat) => {
              const Icon = cat.icon;
              const isActive = selectedCategory === cat.key;
              return (
                <button
                  key={cat.key}
                  onClick={() => setSelectedCategory(cat.key)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                    isActive
                      ? "bg-[#344453] text-white"
                      : "bg-[#F4F5F5] text-[#1E1E1E]/60 hover:bg-[#E8EAEC] hover:text-[#344453]"
                  }`}
                >
                  <Icon size={13} />
                  {cat.label}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* ═══════════ INDICATORS GRID ═══════════ */}
      <section className="py-8 lg:py-12 bg-[#FAFAFA]">
        <div className="container">
          <div className="flex items-center justify-between mb-6">
            <p className="text-sm text-[#1E1E1E]/50">
              {filteredIndicators.length} indicateur{filteredIndicators.length > 1 ? "s" : ""} trouvé{filteredIndicators.length > 1 ? "s" : ""}
              {selectedCategory !== "all" && ` dans ${CATEGORY_TABS.find((c) => c.key === selectedCategory)?.label}`}
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <AnimatePresence mode="popLayout">
              {(isPremium ? filteredIndicators : filteredIndicators.slice(0, FREE_INDICATOR_LIMIT)).map((ind, i) => {
                const lvl = LEVEL_STYLES[ind.level];
                const CatIcon = CATEGORY_ICONS[ind.category] || Layers;
                return (
                  <motion.div
                    key={ind.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ delay: i * 0.03 }}
                  >
                    <button
                      onClick={() => setSelectedIndicator(ind)}
                      className="w-full text-left bg-white rounded-2xl border border-[#E1E6EA] hover:border-[#D4A853]/30 hover:shadow-lg hover:shadow-[#D4A853]/5 transition-all group overflow-hidden"
                    >
                      {/* Top color bar */}
                      <div className={`h-1 w-full bg-gradient-to-r ${CATEGORY_COLORS[ind.category] || "from-gray-400 to-gray-500"}`} />
                      <div className="p-5">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <div className="w-9 h-9 rounded-lg bg-[#344453]/5 flex items-center justify-center">
                              <CatIcon size={16} className="text-[#344453]" />
                            </div>
                            <div>
                              <p className="text-sm font-bold text-[#344453]">{ind.nameFr}</p>
                              <p className="text-[11px] text-[#1E1E1E]/40 font-mono">{ind.name}</p>
                            </div>
                          </div>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${lvl.bg} ${lvl.text}`}>{lvl.label}</span>
                        </div>
                        <p className="text-xs text-[#1E1E1E]/60 leading-relaxed line-clamp-2 mb-3">{ind.shortDesc}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3 text-[11px] text-[#1E1E1E]/40">
                            <span className="flex items-center gap-1"><Clock size={11} /> {ind.readTime} min</span>
                            <span className="flex items-center gap-1"><Activity size={11} /> Complexité {ind.complexity}/5</span>
                          </div>
                          <ChevronRight size={14} className="text-[#1E1E1E]/30 group-hover:text-[#D4A853] group-hover:translate-x-1 transition-all" />
                        </div>
                      </div>
                    </button>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>

          {/* Locked indicator preview (non-premium) */}
          {!isPremium && filteredIndicators.length > FREE_INDICATOR_LIMIT && (
            <div className="mt-6">
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 opacity-50 pointer-events-none">
                {filteredIndicators.slice(FREE_INDICATOR_LIMIT, FREE_INDICATOR_LIMIT + 3).map((ind) => {
                  const CatIcon = CATEGORY_ICONS[ind.category] || Layers;
                  return (
                    <div key={ind.id} className="bg-white rounded-2xl border border-[#E1E6EA] overflow-hidden relative">
                      <div className={`h-1 w-full bg-gradient-to-r ${CATEGORY_COLORS[ind.category] || "from-gray-400 to-gray-500"}`} />
                      <div className="p-5">
                        <div className="flex items-center gap-2 mb-3">
                          <div className="w-9 h-9 rounded-lg bg-[#344453]/5 flex items-center justify-center">
                            <CatIcon size={16} className="text-[#344453]" />
                          </div>
                          <p className="text-sm font-bold text-[#344453]">{ind.nameFr}</p>
                        </div>
                        <p className="text-xs text-[#1E1E1E]/40 line-clamp-2">{ind.shortDesc}</p>
                      </div>
                      <div className="absolute inset-0 flex items-center justify-center bg-white/60">
                        <Lock size={20} className="text-[#344453]/30" />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Upgrade CTA */}
              <div className="mt-8 max-w-xl mx-auto text-center">
                <div className="w-14 h-14 rounded-2xl bg-[#D4A853]/10 border border-[#D4A853]/20 flex items-center justify-center mx-auto mb-4">
                  <Crown size={24} className="text-[#8A6E18]" />
                </div>
                <h3 className="text-lg font-bold text-[#344453] mb-2">Débloquez tous les indicateurs</h3>
                <p className="text-sm text-[#1E1E1E]/50 mb-4">
                  {FREE_INDICATOR_LIMIT} indicateurs sur {filteredIndicators.length} affichés. Passez Premium pour accéder à l'encyclopédie complète.
                </p>
                <Link
                  href="/pricing"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#D4A853] to-[#C49A4A] text-white font-bold rounded-xl hover:shadow-lg hover:shadow-[#D4A853]/20 transition-all"
                >
                  <Crown size={16} />
                  Voir les offres Premium
                </Link>
              </div>
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
}
