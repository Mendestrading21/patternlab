/**
 * GlossairePresentation — Page publique de présentation du Glossaire WMB
 * Format identique à Formation.tsx : hero immersif, sections explicatives, CTA pricing
 * Aucun outil interactif — le glossaire complet est dans /dashboard/glossaire
 */
import Layout from "@/components/Layout";
import { useAuth } from "@/_core/hooks/useAuth";
import { useSubscription } from "@/hooks/useSubscription";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  BookOpen, Search, Brain, Target, Trophy,
  ArrowRight, CheckCircle2, Crown, Shield,
  BarChart3, GraduationCap, Clock, Sparkles,
  Zap, Star, Award, Layers,
  AlertTriangle, Activity, TrendingUp, Lightbulb,
} from "lucide-react";
import { useSEO } from "@/hooks/useSEO";
import { SEO_PAGES } from "@/lib/seoConfig";
import { GLOSSARY, ACADEMY } from "@shared/siteConfig";
import PageBreadcrumb from "@/components/PageBreadcrumb";
import { usePageTitle } from "@/hooks/usePageTitle";
import HeroBackdrop from "@/components/HeroBackdrop";
import GlossaryConcepts from "@/components/GlossaryConcepts";
import ConceptIllustration from "@/components/ConceptIllustration";
import CountUp from "@/components/CountUp";
import { getLoginUrl } from "@/const";

/* ─── Animations ─── */
const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.08, duration: 0.5, ease: [0, 0, 0.2, 1] as [number, number, number, number] },
  }),
};


const CATEGORY_CARDS = [
  { icon: TrendingUp, label: "Marchés", desc: "Bull/bear market, correction, rally, volatilité, circuit breaker, dark pool...", count: "200+", color: "#344453", illu: "bull-bear" as const },
  { icon: BarChart3, label: "Analyse technique", desc: "RSI, MACD, Bollinger, support/résistance, chandelier japonais...", count: "180+", color: "#2E7D5B", illu: "support-resistance" as const },
  { icon: Layers, label: "Produits financiers", desc: "ETF, SPAC, options, futures, obligations, REITs, CFD...", count: "200+", color: "#D4A853", illu: "option-payoff" as const },
  { icon: Activity, label: "Macro-économie", desc: "PIB, inflation, taux directeur, QE/QT, courbe des taux...", count: "150+", color: "#B0413E", illu: "inflation" as const },
  { icon: Shield, label: "Gestion du risque", desc: "Stop-loss, hedging, diversification, drawdown, Sharpe ratio...", count: "130+", color: "#344453", illu: "drawdown" as const },
  { icon: Brain, label: "Psychologie", desc: "FOMO, biais de confirmation, aversion à la perte, effet de disposition...", count: "100+", color: "#7A6A5A", illu: "emotions" as const },
];

const MODES = [
  { icon: BookOpen, title: "Fiches détaillées", desc: "Chaque terme est expliqué avec une définition claire, un exemple concret et le contexte d'utilisation." },
  { icon: Zap, title: "Flashcards", desc: "Mode révision rapide pour mémoriser les termes essentiels. Retournez la carte pour voir la réponse." },
  { icon: Target, title: "Quiz intégré", desc: "Testez vos connaissances avec des quiz par catégorie. Suivez votre progression au fil du temps." },
  { icon: Trophy, title: "Parcours guidés", desc: "Des parcours thématiques pour apprendre les termes dans un ordre logique et progressif." },
];

const STEPS = [
  { step: "01", title: "Choisissez une catégorie", desc: "6 catégories couvrant tous les aspects de la finance : marchés, analyse, produits, macro, risque et psychologie." },
  { step: "02", title: "Explorez les fiches", desc: "Chaque terme est expliqué simplement avec des exemples. Utilisez la recherche pour trouver un terme précis." },
  { step: "03", title: "Révisez et testez-vous", desc: "Flashcards, quiz et parcours guidés pour ancrer vos connaissances durablement." },
];

export default function GlossairePresentation() {
  usePageTitle(SEO_PAGES.glossaire?.title || "Glossaire Financier — WMB");
  useSEO(SEO_PAGES.glossaire);
  const { isAuthenticated } = useAuth();
  const { isPremium } = useSubscription();

  return (
    <Layout>
      {/* ═══════════ IMMERSIVE HERO ═══════════ */}
      <section className="relative overflow-hidden min-h-[600px] lg:min-h-[700px]">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a2530] via-[#2a3845] to-[#3a4b5a]" />
        <HeroBackdrop accent="#D4A853" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1E1E1E]/95 via-[#344453]/85 to-[#344453]/60" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1E1E1E]/40 to-transparent" />

        <div className="relative container py-20 lg:py-28 flex items-center min-h-[600px] lg:min-h-[700px]">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center w-full">
            {/* Left */}
            <div>
              <PageBreadcrumb
                items={[
                  { label: "Académie", href: "/formation" },
                  { label: "Glossaire" },
                ]}
                className="mb-6 text-white/40"
              />
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6 }}
                className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#D4A853]/20 border border-[#D4A853]/30 rounded-full mb-6">
                <BookOpen size={14} className="text-[#D4A853]" />
                <span className="text-[#D4A853] text-xs font-semibold uppercase tracking-wider">Glossaire financier</span>
              </motion.div>
              <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.1 }}
                className="text-4xl md:text-5xl lg:text-[56px] font-bold text-white leading-[1.1] mb-6">
                {GLOSSARY.termCount}+ termes expliqués,
                <br />
                <span className="text-[#D4A853]">simplement.</span>
              </motion.h1>
              <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.2 }}
                className="text-lg text-white/70 leading-relaxed mb-10 max-w-lg">
                Le dictionnaire financier le plus complet en français. Fiches détaillées, flashcards,
                quiz et parcours guidés — tout pour maîtriser le vocabulaire des marchés.
              </motion.p>
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.3 }}
                className="flex flex-col sm:flex-row gap-4">
                {isAuthenticated ? (
                  <Link href="/dashboard" className="inline-flex items-center justify-center px-8 py-4 bg-white text-[#344453] font-semibold rounded-lg hover:bg-white/90 transition-colors text-base">
                    Accéder à Mon espace <ArrowRight size={18} className="ml-2" />
                  </Link>
                ) : (
                  <a href={getLoginUrl()} className="inline-flex items-center justify-center px-8 py-4 bg-white text-[#344453] font-semibold rounded-lg hover:bg-white/90 transition-colors text-base">
                    Créer un compte gratuit <ArrowRight size={18} className="ml-2" />
                  </a>
                )}
                <Link href="/pricing" className="inline-flex items-center justify-center px-8 py-4 border border-white/30 text-white font-medium rounded-lg hover:bg-white/10 transition-colors text-base">
                  Voir les offres
                </Link>
              </motion.div>
            </div>

            {/* Right — Stats */}
            <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8, delay: 0.3 }}
              className="hidden lg:block">
              <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center">
                    <p className="text-4xl font-bold text-white"><CountUp value={GLOSSARY.termCount} suffix="+" /></p>
                    <p className="text-white/50 text-sm mt-1">Termes</p>
                  </div>
                  <div className="text-center">
                    <p className="text-4xl font-bold text-[#D4A853]">6</p>
                    <p className="text-white/50 text-sm mt-1">Catégories</p>
                  </div>
                  <div className="text-center">
                    <p className="text-4xl font-bold text-white">3</p>
                    <p className="text-white/50 text-sm mt-1">Niveaux</p>
                  </div>
                  <div className="text-center">
                    <p className="text-4xl font-bold text-[#2E7D5B]">4</p>
                    <p className="text-white/50 text-sm mt-1">Modes d'apprentissage</p>
                  </div>
                </div>
                <div className="mt-6 pt-6 border-t border-white/10 text-center">
                  <p className="text-white/40 text-xs">Enrichi régulièrement</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ═══════════ TRUST BAR ═══════════ */}
      <section className="bg-white border-b border-[#E1E6EA]">
        <div className="container py-4 flex items-center justify-center gap-8 text-xs text-[#344453]/50 font-medium">
          <span className="flex items-center gap-1.5"><CheckCircle2 size={14} className="text-[#2E7D5B]" /> {GLOSSARY.termCount}+ termes</span>
          <span className="hidden sm:flex items-center gap-1.5"><Shield size={14} className="text-[#344453]" /> 100% pédagogique</span>
          <span className="flex items-center gap-1.5"><Star size={14} className="text-[#D4A853]" /> 4 modes d'apprentissage</span>
          <span className="hidden md:flex items-center gap-1.5"><Sparkles size={14} className="text-[#D4A853]" /> Enrichi régulièrement</span>
        </div>
      </section>

      {/* ═══════════ CATÉGORIES ═══════════ */}
      <section className="py-20 lg:py-28 bg-[#FAFAFA]">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#344453]/5 rounded-full text-xs font-semibold text-[#344453] uppercase tracking-wider mb-4">
              <Layers size={14} /> 6 catégories
            </span>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#344453]">
              Tous les domaines de la finance couverts
            </h2>
            <p className="mt-4 text-[#1E1E1E]/60 text-lg">
              Du vocabulaire de base aux concepts avancés, organisés par thème.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {CATEGORY_CARDS.map((card, i) => (
              <motion.div key={card.label} custom={i} initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeUp}>
                <Link
                  href="/glossaire"
                  className="group relative flex flex-col h-full overflow-hidden bg-white rounded-2xl p-6 border border-[#E1E6EA] transition-all duration-300 hover:shadow-xl hover:-translate-y-1.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#344453]"
                  style={{ ["--cat" as string]: card.color }}
                >
                  <span className="absolute inset-x-0 top-0 h-1 opacity-70 group-hover:opacity-100 transition-opacity" style={{ backgroundColor: card.color }} />
                  <div className="rounded-xl border border-[#E1E6EA] bg-gradient-to-br from-[#FAFBFC] to-[#F0F2F4] p-2 mb-4 wmb-illu-zoom">
                    <ConceptIllustration type={card.illu} />
                  </div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-11 h-11 rounded-xl flex items-center justify-center transition-transform duration-300 group-hover:scale-110 shrink-0" style={{ backgroundColor: `${card.color}12` }}>
                      <card.icon size={22} style={{ color: card.color }} />
                    </div>
                    <div>
                      <h3 className="font-bold text-[#344453]">{card.label}</h3>
                      <p className="text-xs font-semibold" style={{ color: card.color }}>{card.count} termes</p>
                    </div>
                  </div>
                  <p className="text-sm text-[#1E1E1E]/60 leading-relaxed">{card.desc}</p>
                  <div className="mt-auto pt-4 flex items-center gap-1.5 text-xs font-semibold text-[#344453]/70 group-hover:text-[#344453] transition-colors">
                    Explorer le glossaire
                    <ArrowRight size={13} className="transition-transform group-hover:translate-x-1" />
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ CONCEPTS ILLUSTRÉS ═══════════ */}
      <GlossaryConcepts />

      {/* ═══════════ MODES D'APPRENTISSAGE ═══════════ */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#2E7D5B]/10 rounded-full text-xs font-semibold text-[#2E7D5B] uppercase tracking-wider mb-4">
                <Zap size={14} /> 4 modes
              </span>
              <h2 className="text-3xl lg:text-4xl font-bold text-[#344453] leading-tight">
                Apprenez comme vous voulez
              </h2>
              <p className="mt-6 text-lg text-[#1E1E1E]/70 leading-relaxed">
                Fiches détaillées pour comprendre, flashcards pour mémoriser, quiz pour tester,
                parcours guidés pour progresser — choisissez votre mode.
              </p>
              <div className="mt-8 space-y-6">
                {MODES.map((mode, i) => (
                  <motion.div key={mode.title} custom={i} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}
                    className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-[#344453]/5 flex items-center justify-center shrink-0">
                      <mode.icon size={20} className="text-[#344453]" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#344453] mb-1">{mode.title}</h3>
                      <p className="text-sm text-[#1E1E1E]/60 leading-relaxed">{mode.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="bg-gradient-to-br from-[#344453] to-[#2a3a48] rounded-2xl p-8 text-white">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                    <BookOpen size={20} className="text-[#D4A853]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">Exemple de fiche</h3>
                    <p className="text-white/50 text-xs">Terme : Stop-Loss</p>
                  </div>
                </div>
                <div className="space-y-4 text-sm">
                  <div className="bg-white/5 rounded-xl p-4">
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Définition</p>
                    <p className="text-white/80 leading-relaxed">Ordre automatique qui clôture une position lorsque le prix atteint un seuil prédéfini, limitant ainsi la perte maximale.</p>
                  </div>
                  <div className="bg-white/5 rounded-xl p-4">
                    <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Exemple</p>
                    <p className="text-white/60 text-xs">Vous achetez AAPL à $180. Vous placez un stop-loss à $170. Si le prix descend à $170, l'ordre se déclenche automatiquement.</p>
                  </div>
                  <div className="flex gap-2">
                    <span className="px-2 py-1 bg-[#2E7D5B]/20 text-[#2E7D5B] rounded text-xs">Gestion du risque</span>
                    <span className="px-2 py-1 bg-[#D4A853]/20 text-[#D4A853] rounded text-xs">Débutant</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ COMMENT ÇA MARCHE ═══════════ */}
      <section className="py-20 lg:py-28 bg-[#FAFAFA]">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <h2 className="text-3xl lg:text-4xl font-bold text-[#344453]">Comment ça fonctionne</h2>
            <p className="mt-4 text-[#1E1E1E]/60 text-lg">Trois étapes pour maîtriser le vocabulaire financier.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {STEPS.map((item, i) => (
              <motion.div key={item.step} custom={i} initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} variants={fadeUp}
                className="bg-white rounded-2xl p-8 border border-[#E1E6EA] relative">
                <span className="text-[#344453]/10 text-6xl font-bold absolute top-4 right-6">{item.step}</span>
                <h3 className="text-lg font-semibold text-[#344453] mb-3 mt-4">{item.title}</h3>
                <p className="text-[#1E1E1E]/60 text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════ DISCLAIMER ═══════════ */}
      <section className="py-16 lg:py-20 bg-white">
        <div className="container">
          <div className="max-w-3xl mx-auto bg-[#F4F5F5] rounded-2xl p-8 border border-[#E1E6EA]">
            <div className="flex items-start gap-4">
              <AlertTriangle size={24} className="text-[#D4A853] shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-[#344453] mb-2">Avertissement important</h3>
                <p className="text-sm text-[#1E1E1E]/60 leading-relaxed">
                  Le glossaire WMB est fourni à titre strictement informatif uniquement.
                  Il ne constitue en aucun cas un conseil en investissement.
                  Les définitions sont simplifiées pour faciliter la compréhension et peuvent ne pas couvrir
                  toutes les nuances juridiques ou techniques.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ═══════════ CROSS-LINKS ═══════════ */}
      <section className="py-20 lg:py-28 bg-[#FAFAFA]">
        <div className="container">
          <h2 className="text-2xl font-bold text-[#344453] mb-8 text-center">Explorez aussi</h2>
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <Link href="/formation" className="bg-white rounded-2xl p-6 border border-[#E1E6EA] hover:shadow-lg transition-shadow group">
              <GraduationCap size={24} className="text-[#344453] mb-3" />
              <h3 className="font-bold text-[#344453] group-hover:text-[#D4A853] transition-colors">Ma Formation</h3>
              <p className="text-sm text-[#1E1E1E]/50 mt-1">{ACADEMY.lessonCount}+ leçons structurées</p>
            </Link>
            <Link href="/quiz" className="bg-white rounded-2xl p-6 border border-[#E1E6EA] hover:shadow-lg transition-shadow group">
              <Brain size={24} className="text-[#344453] mb-3" />
              <h3 className="font-bold text-[#344453] group-hover:text-[#D4A853] transition-colors">Quiz WMB</h3>
              <p className="text-sm text-[#1E1E1E]/50 mt-1">Testez vos connaissances</p>
            </Link>
            <Link href="/indicateurs-tendance" className="bg-white rounded-2xl p-6 border border-[#E1E6EA] hover:shadow-lg transition-shadow group">
              <BarChart3 size={24} className="text-[#344453] mb-3" />
              <h3 className="font-bold text-[#344453] group-hover:text-[#D4A853] transition-colors">Indicateurs</h3>
              <p className="text-sm text-[#1E1E1E]/50 mt-1">100 indicateurs techniques</p>
            </Link>
          </div>
        </div>
      </section>

      {/* ═══════════ FINAL CTA ═══════════ */}
      <section className="py-20 lg:py-28 bg-gradient-to-br from-[#344453] via-[#3d5060] to-[#344453]">
        <div className="container text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.7 }}>
            <Crown size={32} className="text-[#D4A853] mx-auto mb-6" />
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
              Maîtrisez le vocabulaire des marchés
            </h2>
            <p className="text-white/60 text-lg max-w-xl mx-auto mb-10">
              {GLOSSARY.termCount}+ termes, 6 catégories, 4 modes d'apprentissage.
              Créez votre compte pour commencer.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {isAuthenticated ? (
                isPremium ? (
                  <Link href="/dashboard" className="inline-flex items-center justify-center px-8 py-4 bg-[#D4A853] text-[#344453] font-bold rounded-lg hover:bg-[#C49A4A] transition-colors text-base">
                    Accéder à Mon espace <ArrowRight size={18} className="ml-2" />
                  </Link>
                ) : (
                  <Link href="/pricing" className="inline-flex items-center justify-center px-8 py-4 bg-[#D4A853] text-[#344453] font-bold rounded-lg hover:bg-[#C49A4A] transition-colors text-base">
                    Passer Premium <Crown size={18} className="ml-2" />
                  </Link>
                )
              ) : (
                <>
                  <a href={getLoginUrl()} className="inline-flex items-center justify-center px-8 py-4 bg-white text-[#344453] font-semibold rounded-lg hover:bg-white/90 transition-colors text-base">
                    Créer un compte gratuit
                  </a>
                  <Link href="/pricing" className="inline-flex items-center justify-center px-8 py-4 border border-white/30 text-white font-medium rounded-lg hover:bg-white/10 transition-colors text-base">
                    Voir les offres Premium
                  </Link>
                </>
              )}
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
}
