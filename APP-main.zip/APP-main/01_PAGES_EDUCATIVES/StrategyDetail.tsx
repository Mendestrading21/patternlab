import ShareBar from "@/components/ShareBar";
import { usePageTitle } from "@/hooks/usePageTitle";
/**
 * WMB Strategy Detail — Single strategy viewer
 * Route: /strategies/:slug
 */
import Layout from "@/components/Layout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useSubscription } from "@/hooks/useSubscription";
import { Link, useParams } from "wouter";
import { motion } from "framer-motion";
import {
  ChevronLeft,
  Target,
  Shield,
  Clock,
  Lock,
  ArrowRight,
  AlertTriangle,
} from "lucide-react";
import { Streamdown } from "streamdown";

const RISK_COLORS: Record<string, { bg: string; text: string; label: string }> = {
  faible: { bg: "bg-emerald-100", text: "text-emerald-700", label: "Risque faible" },
  modere: { bg: "bg-amber-100", text: "text-amber-700", label: "Risque modéré" },
  eleve: { bg: "bg-red-100", text: "text-red-700", label: "Risque élevé" },
};

export default function StrategyDetail() {
  usePageTitle("Stratégie d'investissement");
  const { slug } = useParams<{ slug: string }>();
  const { isAuthenticated } = useAuth();
  const { isPremium, canAccess } = useSubscription();

  const { data: strategy, isLoading } = trpc.academy.getStrategy.useQuery(
    { slug: slug || "" },
    { enabled: !!slug }
  );

  const isLocked = !canAccess("strategies:trading");
  const risk = RISK_COLORS[strategy?.riskLevel || "modere"] || RISK_COLORS.modere;

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="w-8 h-8 border-2 border-[#344453]/20 border-t-[#D4A853] rounded-full animate-spin" />
        </div>
      <ShareBar />
    </Layout>
    );
  }

  if (!strategy) {
    return (
      <Layout>
        <div className="container py-20 text-center">
          <h1 className="text-2xl font-bold text-[#344453] mb-4">Stratégie introuvable</h1>
          <p className="text-[#344453]/75 mb-6">Cette stratégie n'existe pas ou a été déplacée.</p>
          <Link href="/admin/strategies" className="text-[#344453] font-medium hover:underline">
            ← Retour aux stratégies
          </Link>
        </div>
      <ShareBar />
    </Layout>
    );
  }

  return (
    <Layout>
      {/* HERO */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#F4F5F5] via-[#F4F5F5] to-white py-16 lg:py-20">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 right-20 w-64 h-64 bg-[#344453] rounded-full blur-3xl" />
        </div>
        <div className="relative container">
          <Link
            href="/admin/strategies"
            className="inline-flex items-center gap-1.5 text-[#1E1E1E]/80 text-sm hover:text-[#1E1E1E]/70 transition-colors mb-6"
          >
            <ChevronLeft size={14} />
            Retour aux stratégies
          </Link>

          <div className="max-w-3xl">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl lg:text-5xl font-bold text-[#344453] leading-tight mb-4"
            >
              {strategy.name}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-lg text-[#1E1E1E]/80 leading-relaxed mb-6 max-w-xl"
            >
              {strategy.tagline || strategy.description}
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex flex-wrap items-center gap-4"
            >
              <span className={`px-3 py-1 text-xs font-medium rounded-full ${risk.bg} ${risk.text}`}>
                {risk.label}
              </span>
              {strategy.timeframe && (
                <span className="px-3 py-1 text-xs font-medium rounded-full bg-[#344453]/5 text-[#344453]/80">
                  {strategy.timeframe === "court" ? "Court terme" : strategy.timeframe === "long" ? "Long terme" : "Moyen terme"}
                </span>
              )}
              {strategy.category && (
                <span className="px-3 py-1 text-xs font-medium rounded-full bg-[#D4A853]/20 text-[#8A6E18]">
                  {strategy.category}
                </span>
              )}
            </motion.div>
          </div>
        </div>
      </section>

      {/* DISCLAIMER */}
      <section className="bg-[#faf6ed] border-b border-[#D4A853]/20 py-3">
        <div className="container flex items-center gap-3 text-sm text-[#8B6914]">
          <AlertTriangle size={16} className="shrink-0" />
          <p>
            <strong>Avertissement :</strong> Cette stratégie est présentée à titre
            informatif uniquement. Elle ne constitue pas un conseil d'investissement.
          </p>
        </div>
      </section>

      {/* CONTENT */}
      <section className="py-12 lg:py-20 bg-white">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            {isLocked ? (
              <div className="text-center py-16">
                <div className="w-16 h-16 rounded-2xl bg-[#D4A853]/10 border border-[#D4A853]/20 flex items-center justify-center mx-auto mb-6">
                  <Lock size={28} className="text-[#8A6E18]" />
                </div>
                <h2 className="text-xl font-bold text-[#344453] mb-3">
                  Stratégie réservée aux abonnés Premium
                </h2>
                <p className="text-[#1E1E1E]/80 mb-8 max-w-md mx-auto">
                  Débloquez cette stratégie et toutes les autres avec un abonnement Premium WMB.
                </p>
                <Link
                  href="/pricing"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#D4A853] to-[#C49A4A] text-[#344453] font-bold rounded-xl hover:shadow-lg transition-all text-sm"
                >
                  Voir les offres <ArrowRight size={14} />
                </Link>
              </div>
            ) : (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <div className="prose prose-lg max-w-none prose-headings:text-white prose-p:text-[#344453]/75 prose-strong:text-white prose-a:text-[#2E7D5B] prose-blockquote:border-l-[#D4A853] prose-blockquote:bg-[#D4A853]/5 prose-blockquote:py-2 prose-blockquote:px-4 prose-blockquote:rounded-r-lg prose-li:text-[#344453]/75">
                  <Streamdown>{strategy.content || "Contenu en cours de rédaction..."}</Streamdown>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </section>
    <ShareBar />
    </Layout>
  );
}
