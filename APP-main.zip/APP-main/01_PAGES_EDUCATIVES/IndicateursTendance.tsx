import { usePageTitle } from "@/hooks/usePageTitle";
/**
 * Indicateurs Techniques — Encyclopédie Premium WMB V20+
 * 54 indicateurs, 8 catégories, design trading premium
 * Palette WMB : #344453, #2E7D5B, #D4A853
 * 100% informatif — zéro conseil, zéro signal
 */
import Layout from "@/components/Layout";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useState, useMemo, useCallback } from "react";
import { useSubscription } from "@/hooks/useSubscription";
import { useAuth } from "@/_core/hooks/useAuth";
import { Crown, Lock, Sparkles, ArrowRight as ArrowRightIcon } from "lucide-react";
import {
  TrendingUp, TrendingDown, BarChart3, Activity, Target, Layers,
  ArrowLeft, ChevronRight, ChevronDown, ChevronUp, BookOpen, Lightbulb,
  Shield, Zap, Eye, X, Search, SlidersHorizontal, Clock, Star,
  AlertTriangle, Building2, Combine, Filter, RotateCcw, Maximize2, Info,
  Gauge, LineChart, CandlestickChart, BarChart2, Crosshair, Flame,
  Radio, Radar, Hash, Grid3X3, ArrowUpDown, Percent, CircleDot,
} from "lucide-react";
import { useSEO } from "@/hooks/useSEO";
import { SEO_PAGES } from "@/lib/seoConfig";
import { ACADEMY as ACADEMY_CONFIG, GLOSSARY as GLOSSARY_CONFIG } from "@shared/siteConfig";
import { HERO_IMAGES } from "@/lib/heroImages";
import PageBreadcrumb from "@/components/PageBreadcrumb";

/* ═══════════════════════════════════════════════════════════
 * CDN IMAGES
 * ═══════════════════════════════════════════════════════════ */
const HERO_IMG = "/api/img/indicators-trend-kVUZDcKSgbbtsdB2GEUg2g.webp";
const MOMENTUM_IMG = "/api/img/indicators-momentum-PcEuKxsTYX6X2YyrBtM8cH.webp";
const TREND_IMG = "/api/img/indicators-support-resistance-Kum9J25CWXXZHvaPxMvWvn.webp";
const VOLUME_IMG = "/api/img/indicators-volume-PkWkf3c86Sm8CWyxNwoW9C.webp";
const VOLATILITY_IMG = "/api/img/indicators-volatility-Df5av3vzhAk5L4gzF9o4GN.webp";
const MACRO_IMG = "/api/img/indicators-macro-CLDWZDKDaDhU4F5JCTmwAQ.webp";

const IMG: Record<string, string> = {
  /* ── Originaux (session) ── */
  trendTypes: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/GWUfkwDygbyVblUz.png",
  maCrossover: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/YtbmyUwZhomwYfBg.png",
  macd: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/pOxPffvKVINAgelx.png",
  rsi: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/kFthfQWpAfaHvdMK.png",
  bollinger: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/EsFrlcbJKOpqVAVh.png",
  stochastic: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/MsgghGdTJOWCNbQz.png",
  supportResistance: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/KbhHkkvVudrJnnXN.png",
  fibonacci: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/cpWTqhHGsxALyRDj.png",
  candlestick: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/JUDGKMTvyiJyhPRv.png",
  volume: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/fmLWDUknNLeZBZLB.png",
  ichimoku: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/tdrCPUmFKAYKWgqg.png",
  adx: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/KVjvTWpxeRjserLb.png",
  atr: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/dupnhvLWjostIdkH.png",
  vwap: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/ggQCmxTfZBAoHYjY.png",
  parabolicSar: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/iddqdVxGhoIjVZwu.png",
  obv: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/OlJSOeVvawELhTYA.png",
  williamsR: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/FybycGIYYjOUAImm.png",
  cci: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/FyVlrFOOBqUmnbMo.png",
  donchian: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/RsFTmCmKSzOgzUbd.png",
  keltner: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663135061541/iOdtbrggpGqiabFr.png",
  /* ── Nouvelles images CDN (spécifiques) ── */
  adxChart: "/api/img/adx-chart_9c158a10.png",
  atrRayner: "/api/img/atr-rayner_e9e45bc7.png",
  atrIg: "/api/img/atr-ig_f2a687ec.webp",
  bollingerChart: "/api/img/bollinger-chart_707a68b4.png",
  bollingerStochastic: "/api/img/bollinger-stochastic_a6f38e18.webp",
  cciFidelity: "/api/img/cci-fidelity_c12303fb.png",
  channelsComparison: "/api/img/channels-comparison_84df2070.png",
  fibonacciFidelity: "/api/img/fibonacci-fidelity_62ff8bed.png",
  fibonacciRetracement: "/api/img/fibonacci-retracement_76671f44.png",
  ichimokuCloud: "/api/img/ichimoku-cloud_a192a4df.png",
  ichimokuExplained: "/api/img/ichimoku-explained_e1a118a7.jpg",
  obvFidelity: "/api/img/obv-fidelity_f4dcfff6.png",
  obvTradingview: "/api/img/obv-tradingview_f736104b.webp",
  parabolicSarNew: "/api/img/parabolic-sar_f1e80eb5.png",
  parabolicSarInvestopedia: "/api/img/parabolic-sar-investopedia_f6364176.jpg",
  rsiMacdCombo: "/api/img/rsi-macd-combo_365d5d35.png",
  rsiSignals: "/api/img/rsi-signals_6e7095ce.jpg",
  supportResistanceNew: "/api/img/support-resistance_3595bf6f.png",
  supportResistanceLevels: "/api/img/support-resistance-levels_ed4cadc2.jpg",
  vwapInvestopedia: "/api/img/vwap-investopedia_4c8891d9.png",
  vwapExplained: "/api/img/vwap-explained_f68dee85.jpg",
  williamsRNew: "/api/img/williams-r_66d68e05.png",
  keltnerChannel: "/api/img/keltner-channel_bb77bfb9.jpeg",
  /* ── Batch V2 — 39 images spécifiques par indicateur ── */
  aaiiSentiment: "/api/img/aaii-sentiment-replacement_359449b0.png",
  accumulationDistribution: "/api/img/accumulation-distribution-replacement_46afa150.png",
  aroon: "/api/img/aroon-replacement_85a036bf.png",
  awesomeOscillator: "/api/img/awesome-oscillator-replacement_737b24b0.png",
  bollingerKeltnerSqueeze: "/api/img/bollinger-keltner-squeeze_d0cc68b5.jpg",
  candlestickPatterns: "/api/img/candlestick-patterns_200c1ce6.jpg",
  chaikinMoneyFlow: "/api/img/chaikin-money-flow_d100010e.jpg",
  chaikinVolatility: "/api/img/chaikin-volatility_aa7fc255.jpg",
  chartPatterns: "/api/img/chart-patterns_5ebfb654.png",
  cotReport: "/api/img/cot-report_a5b402b3.jpg",
  darkPoolActivity: "/api/img/dark-pool-activity_fcec0e7c.png",
  divergenceTrading: "/api/img/divergence-trading_29a4a88d.png",
  donchianChannels: "/api/img/donchian-channels_1e56317f.png",
  elliottWaves: "/api/img/elliott-waves_1125a941.png",
  emaRibbon: "/api/img/ema-ribbon_10d4f6d9.jpg",
  fearGreedIndex: "/api/img/fear-greed-index_0305a29e.png",
  historicalVolatility: "/api/img/historical-volatility_9e71aa54.png",
  ichimokuSystem: "/api/img/ichimoku-system_ec61f45d.png",
  intermarketAnalysis: "/api/img/intermarket-analysis_f999deae.jpg",
  linearRegression: "/api/img/linear-regression_eb33e5f8.gif",
  marketBreadth: "/api/img/market-breadth_72d13a4c.jpg",
  marketRegime: "/api/img/market-regime_9d1f4023.webp",
  momentumIndicator: "/api/img/momentum-indicator_e90de8a1.gif",
  moneyFlowIndex: "/api/img/money-flow-index_fc380925.png",
  movingAverages: "/api/img/moving-averages_24501807.png",
  newHighsLows: "/api/img/new-highs-lows_f3648afa.webp",
  pivotPoints: "/api/img/pivot-points_d982205d.jpg",
  ppo: "/api/img/ppo_86159c54.png",
  putCallRatio: "/api/img/put-call-ratio_426a071a.jpg",
  rocRateOfChange: "/api/img/roc-rate-of-change_ca49f46c.gif",
  sectorRotation: "/api/img/sector-rotation_e017fc33.jpg",
  supertrend: "/api/img/supertrend_d0e57ae6.jpeg",
  trendTypesNew: "/api/img/trend-types_cfc97344.jpeg",
  tripleScreen: "/api/img/triple-screen_1c6bc9de.png",
  tsi: "/api/img/true-strength-index-tsi_0d1e86d3.jpg",
  vix: "/api/img/vix_3deb16d0.jpg",
  volumeAnalysis: "/api/img/volume-analysis_18e496bb.gif",
  volumeProfile: "/api/img/volume-profile_64557035.png",
  yieldCurve: "/api/img/yield-curve_1be26420.png",
};

/* ═══════════════════════════════════════════════════════════
 * TYPES
 * ═══════════════════════════════════════════════════════════ */
export type Level = "debutant" | "intermediaire" | "avance";
export type Category = "tendance" | "momentum" | "volatilite" | "volume" | "pattern" | "structure" | "institutionnel" | "synthese";

export interface Indicator {
  id: string;
  name: string;
  nameFr: string;
  category: Category;
  level: Level;
  image: string;
  readTime: number;
  complexity: number;
  shortDesc: string;
  fullDesc: string;
  howItWorks: string;
  interpretation: {
    bullish: string;
    bearish: string;
    range: string;
    divergence: string;
  };
  multiTimeframe: string;
  limits: string[];
  commonMistakes: string[];
  combinations: string[];
  practicalCase: string;
  advancedVersion?: string;
  keyLevels?: string[];
  relatedIndicators: string[];
  popular?: boolean;
  secondaryImage?: string;
  chartReadingGuide?: string;
}

/* ═══════════════════════════════════════════════════════════
 * CATEGORIES & STYLES — TRADING PREMIUM
 * ═══════════════════════════════════════════════════════════ */
const CATEGORIES: { key: string; label: string; icon: typeof Layers; color: string }[] = [
  { key: "all", label: "Tous", icon: Grid3X3, color: "#344453" },
  { key: "tendance", label: "Tendance", icon: TrendingUp, color: "#344453" },
  { key: "momentum", label: "Momentum", icon: Gauge, color: "#344453" },
  { key: "volatilite", label: "Volatilité", icon: Activity, color: "#C4A052" },
  { key: "volume", label: "Volume", icon: BarChart2, color: "#344453" },
  { key: "pattern", label: "Patterns", icon: CandlestickChart, color: "#2E7D5B" },
  { key: "structure", label: "Structure", icon: Building2, color: "#344453" },
  { key: "institutionnel", label: "Institutionnel", icon: Shield, color: "#344453" },
  { key: "synthese", label: "Synthèse", icon: Combine, color: "#B0413E" },
];

export const LEVEL_STYLES: Record<Level, { bg: string; text: string; border: string; label: string; dot: string }> = {
  debutant: { bg: "bg-emerald-500/10", text: "text-emerald-400", border: "border-emerald-500/20", label: "Débutant", dot: "bg-emerald-400" },
  intermediaire: { bg: "bg-amber-500/10", text: "text-amber-400", border: "border-amber-500/20", label: "Intermédiaire", dot: "bg-amber-400" },
  avance: { bg: "bg-rose-500/10", text: "text-rose-400", border: "border-rose-500/20", label: "Avancé", dot: "bg-rose-400" },
};

export const CATEGORY_COLORS: Record<string, string> = {
  tendance: "from-[#344453] to-[#1a2a35]",
  momentum: "from-violet-700 to-violet-900",
  volatilite: "from-amber-700 to-amber-900",
  volume: "from-cyan-700 to-cyan-900",
  pattern: "from-emerald-700 to-emerald-900",
  structure: "from-indigo-700 to-indigo-900",
  institutionnel: "from-slate-700 to-slate-900",
  synthese: "from-rose-700 to-rose-900",
};

export const CATEGORY_LABELS: Record<string, string> = {
  tendance: "Tendance", momentum: "Momentum", volatilite: "Volatilité",
  volume: "Volume", pattern: "Patterns", structure: "Structure de marché",
  institutionnel: "Institutionnel", synthese: "Synthèse",
};

export const CATEGORY_ICONS: Record<string, typeof Layers> = {
  tendance: TrendingUp, momentum: Gauge, volatilite: Activity,
  volume: BarChart2, pattern: CandlestickChart, structure: Building2,
  institutionnel: Shield, synthese: Combine,
};

const DISCLAIMER = "Ce contenu est strictement strictement informatif. Il ne constitue en aucun cas un conseil en investissement, une recommandation d'achat ou de vente, ni un signal de trading. Les indicateurs techniques sont des outils de lecture du marché, pas des prédicteurs infaillibles. Consultez un professionnel agréé avant toute décision d'investissement.";

export const INDICATORS: Indicator[] = [
  // ──────────── TENDANCE (9) ────────────
  {
    id: "trend-types",
    name: "Types de Tendances",
    nameFr: "Les 3 Types de Tendances",
    category: "tendance",
    level: "debutant",
    image: IMG.trendTypesNew,
    secondaryImage: IMG.trendTypes,
    chartReadingGuide: "Sur le graphique : identifiez la succession des sommets (highs) et des creux (lows). Sommets et creux ascendants = tendance haussière. Sommets et creux descendants = tendance baissière. Prix oscillant entre deux niveaux horizontaux = range/tendance latérale. Tracez des lignes reliant les creux (support) et les sommets (résistance) pour visualiser la structure.",
    readTime: 4,
    complexity: 1,
    popular: true,
    shortDesc: "Comprendre les trois directions possibles du marché : haussière, baissière et latérale.",
    fullDesc: "Avant d'utiliser n'importe quel indicateur technique, il est essentiel de comprendre les trois types de tendances qui existent sur les marchés financiers. Une tendance haussière (uptrend) se caractérise par des sommets et des creux de plus en plus hauts. Une tendance baissière (downtrend) montre des sommets et des creux de plus en plus bas. Une tendance latérale (sideways/range) indique que le prix oscille entre un support et une résistance sans direction claire.",
    howItWorks: "Pour identifier une tendance, observez la succession des sommets (highs) et des creux (lows) sur le graphique. En tendance haussière, chaque nouveau sommet dépasse le précédent et chaque creux reste au-dessus du creux précédent. L'inverse est vrai en tendance baissière. En range, le prix rebondit entre deux niveaux horizontaux.",
    interpretation: {
      bullish: "Sommets et creux ascendants → tendance haussière confirmée. Le momentum est du côté des acheteurs.",
      bearish: "Sommets et creux descendants → tendance baissière confirmée. Les vendeurs dominent le marché.",
      range: "Le prix oscille entre un support et une résistance horizontaux. Ni les acheteurs ni les vendeurs ne dominent clairement.",
      divergence: "Un changement dans la structure des sommets/creux peut signaler un retournement de tendance imminent.",
    },
    multiTimeframe: "Utilisez le weekly pour la tendance principale, le daily pour la tendance intermédiaire, et le 4H pour le timing d'entrée. La tendance du timeframe supérieur prime toujours.",
    limits: [
      "L'identification est subjective — deux analystes peuvent voir des tendances différentes",
      "Les transitions entre tendances ne sont pas toujours claires",
      "Le marché passe environ 70% du temps en range, pas en tendance",
    ],
    commonMistakes: [
      "Chercher des tendances sur des timeframes trop courts (1min, 5min)",
      "Ignorer la tendance du timeframe supérieur",
      "Confondre un pullback (correction temporaire) avec un retournement de tendance",
    ],
    combinations: [
      "ADX pour confirmer la force de la tendance",
      "Moyennes Mobiles pour objectiver la direction",
      "Volume pour valider la conviction du mouvement",
    ],
    practicalCase: "Exemple S&P 500, 2023 : Après un creux en octobre 2022, l'indice a formé une série de sommets et creux ascendants sur le weekly. Le creux de mars 2023 est resté au-dessus de celui d'octobre → tendance haussière confirmée. Les traders qui ont identifié cette structure ont pu chercher des entrées sur les pullbacks vers les creux précédents.",
    relatedIndicators: ["Moyennes Mobiles", "MACD", "ADX"],
  },
  {
    id: "moving-averages",
    name: "Moving Averages",
    nameFr: "Moyennes Mobiles (SMA / EMA)",
    category: "tendance",
    level: "debutant",
    image: IMG.movingAverages,
    secondaryImage: IMG.maCrossover,
    chartReadingGuide: "Sur le graphique : les lignes lisses (MAs) suivent le prix. La MA 50 (ligne orange) et la MA 200 (ligne bleue) sont les plus surveillées. Prix au-dessus des MAs = tendance haussière. Golden Cross = MA 50 croise au-dessus de MA 200 (signal haussier fort). Death Cross = l'inverse. Les MAs servent aussi de support/résistance dynamique.",
    readTime: 6,
    complexity: 2,
    popular: true,
    shortDesc: "L'indicateur le plus utilisé pour identifier la direction de la tendance et les signaux de croisement.",
    fullDesc: "Les moyennes mobiles lissent les fluctuations de prix pour révéler la tendance sous-jacente. La SMA (Simple Moving Average) calcule la moyenne arithmétique des prix sur une période donnée. L'EMA (Exponential Moving Average) donne plus de poids aux prix récents, la rendant plus réactive. Les périodes les plus utilisées sont 20 (court terme), 50 (moyen terme) et 200 (long terme).",
    howItWorks: "Quand le prix est au-dessus de la moyenne mobile, la tendance est considérée haussière. Quand il est en dessous, elle est baissière. Le croisement doré (Golden Cross) se produit quand la MA 50 croise au-dessus de la MA 200 — signal haussier fort. Le croisement mortel (Death Cross) est l'inverse — signal baissier.",
    interpretation: {
      bullish: "Golden Cross (MA 50 > MA 200), prix au-dessus de la MA 200, rebond sur la MA 50 en tendance haussière.",
      bearish: "Death Cross (MA 50 < MA 200), prix en dessous de la MA 200, rejet sur la MA 50 en tendance baissière.",
      range: "Les MAs se croisent fréquemment et s'aplatissent → marché sans direction. Les faux signaux sont nombreux.",
      divergence: "Le prix fait de nouveaux sommets mais la pente des MAs s'aplatit → essoufflement potentiel de la tendance.",
    },
    multiTimeframe: "MA 200 weekly = tendance long terme (années). MA 200 daily = tendance moyen terme (mois). MA 20 daily = tendance court terme (semaines). La MA 200 daily est la plus suivie par les institutionnels.",
    limits: [
      "Indicateur retardé (lagging) — il confirme la tendance mais ne la prédit pas",
      "Génère de nombreux faux signaux en marché latéral",
      "Le choix de la période est subjectif et impacte fortement les résultats",
    ],
    commonMistakes: [
      "Utiliser une seule MA sans contexte — toujours combiner avec d'autres indicateurs",
      "Ignorer les faux signaux en range — vérifier avec l'ADX avant",
      "Changer constamment de période pour \"optimiser\" (overfitting)",
    ],
    combinations: [
      "ADX pour confirmer si le marché est en tendance (ADX > 25) avant d'utiliser les MAs",
      "RSI pour confirmer les zones de surachat/survente aux niveaux des MAs",
      "Volume pour valider les croisements (Golden/Death Cross avec volume élevé = plus fiable)",
    ],
    practicalCase: "Exemple Apple (AAPL), 2023 : Le Golden Cross (MA 50 > MA 200) s'est produit en mars 2023 sur le daily. Le prix a ensuite progressé de +40% en 6 mois. Le volume était supérieur à la moyenne lors du croisement, confirmant la conviction. Les traders qui ont attendu un pullback vers la MA 50 après le Golden Cross ont obtenu un meilleur ratio risque/rendement.",
    keyLevels: ["MA 20 — tendance court terme", "MA 50 — tendance moyen terme", "MA 200 — tendance long terme (la plus suivie)"],
    relatedIndicators: ["MACD", "Types de Tendances", "Bollinger Bands"],
  },
  {
    id: "ichimoku",
    name: "Ichimoku Kinko Hyo",
    nameFr: "Ichimoku Kinko Hyo",
    category: "tendance",
    level: "avance",
    image: IMG.ichimokuCloud,
    secondaryImage: IMG.ichimokuExplained,
    chartReadingGuide: "Sur le graphique : le nuage (Kumo) est la zone colorée entre Senkou Span A et B. Nuage vert = tendance haussière. Nuage rouge = tendance baissière. Le prix au-dessus du nuage = signal haussier. Tenkan (ligne rapide) et Kijun (ligne lente) se croisent comme des moyennes mobiles. Chikou Span (ligne décalée) confirme le signal.",
    readTime: 10,
    complexity: 5,
    shortDesc: "Système complet d'analyse technique japonais qui identifie tendance, momentum, supports/résistances en un seul coup d'œil.",
    fullDesc: "L'Ichimoku Kinko Hyo (\"équilibre d'un graphique en un coup d'œil\") est un système d'analyse technique complet développé par Goichi Hosoda. Il se compose de 5 lignes : Tenkan-sen (9 périodes), Kijun-sen (26 périodes), Senkou Span A et B (qui forment le nuage/Kumo), et Chikou Span (ligne retardée). Le nuage représente le support/résistance dynamique.",
    howItWorks: "Le prix au-dessus du nuage = tendance haussière. En dessous = baissière. Dans le nuage = indécision. Le croisement Tenkan/Kijun donne les signaux d'entrée. Le Chikou Span confirme en regardant le passé. Le nuage futur (projeté 26 périodes) anticipe les zones de support/résistance.",
    interpretation: {
      bullish: "Prix au-dessus du nuage, Tenkan > Kijun, nuage futur vert (Senkou A > B), Chikou au-dessus du prix passé.",
      bearish: "Prix en dessous du nuage, Tenkan < Kijun, nuage futur rouge (Senkou A < B), Chikou en dessous du prix passé.",
      range: "Prix dans le nuage, Tenkan et Kijun plats et proches. Le nuage plat agit comme un aimant.",
      divergence: "Chikou Span diverge du prix actuel — peut signaler un retournement imminent.",
    },
    multiTimeframe: "Weekly pour la tendance principale, daily pour les signaux d'entrée. Les paramètres originaux (9/26/52) sont optimisés pour le marché japonais (semaine de 6 jours). Certains traders utilisent 10/30/60 pour les marchés occidentaux.",
    limits: [
      "Complexe visuellement — 5 lignes + nuage peuvent surcharger le graphique",
      "Les paramètres originaux datent des années 1930 — débat sur leur pertinence actuelle",
      "Moins efficace sur les timeframes très courts (< 1H)",
    ],
    commonMistakes: [
      "Utiliser un seul élément de l'Ichimoku au lieu du système complet",
      "Ignorer le Chikou Span qui est pourtant un filtre de confirmation puissant",
      "Appliquer l'Ichimoku en range — il est conçu pour les marchés en tendance",
    ],
    combinations: [
      "RSI pour confirmer les zones de surachat/survente aux niveaux du nuage",
      "Volume pour valider les cassures du nuage",
      "Fibonacci pour affiner les niveaux de support/résistance dans le nuage",
    ],
    practicalCase: "Exemple Nikkei 225, 2023 : Le prix a cassé au-dessus du nuage weekly en mai 2023 avec les 5 éléments alignés (Tenkan > Kijun, nuage futur vert, Chikou libre). C'était un signal haussier de haute qualité. L'indice a ensuite progressé de +15% en 3 mois. Le nuage weekly a servi de support dynamique lors des corrections.",
    relatedIndicators: ["Moyennes Mobiles", "MACD", "ADX"],
  },
  {
    id: "adx",
    name: "ADX",
    nameFr: "ADX (Average Directional Index)",
    category: "tendance",
    level: "intermediaire",
    image: IMG.adxChart,
    secondaryImage: IMG.adx,
    chartReadingGuide: "Sur le graphique : la ligne ADX (noire) mesure la FORCE de la tendance, pas sa direction. ADX > 25 = tendance forte. ADX < 20 = marché en range. Les lignes +DI (verte) et -DI (rouge) montrent la direction : +DI au-dessus de -DI = tendance haussière. L'inverse = tendance baissière.",
    readTime: 6,
    complexity: 3,
    popular: true,
    shortDesc: "Mesure la force d'une tendance (pas sa direction) — indispensable pour savoir si le marché est en tendance ou en range.",
    fullDesc: "L'ADX (Average Directional Index) a été développé par J. Welles Wilder. Il mesure la force d'une tendance sur une échelle de 0 à 100, indépendamment de sa direction. Il est accompagné de deux lignes directionnelles : +DI et -DI. L'ADX lui-même ne donne pas la direction — il dit seulement si la tendance est forte ou faible.",
    howItWorks: "Un ADX au-dessus de 25 indique une tendance forte. Un ADX en dessous de 20 indique un range. Le croisement +DI/-DI donne la direction. Un ADX qui monte = tendance qui se renforce. Un ADX qui baisse = tendance qui s'essouffle.",
    interpretation: {
      bullish: "+DI croise au-dessus de -DI avec ADX > 25. ADX en hausse avec prix en hausse.",
      bearish: "-DI croise au-dessus de +DI avec ADX > 25. ADX en hausse avec prix en baisse.",
      range: "ADX < 20 — pas de tendance claire. Utiliser des stratégies de range (RSI, Bollinger).",
      divergence: "ADX qui baisse alors que le prix continue de monter/baisser → essoufflement de la tendance.",
    },
    multiTimeframe: "ADX weekly pour la tendance principale. ADX daily pour le timing. Un ADX > 25 sur le weekly ET le daily = tendance très forte.",
    limits: [
      "Indicateur retardé — il confirme la tendance après qu'elle a commencé",
      "Ne donne pas la direction — seulement la force",
      "Peut rester bas longtemps en range, frustrant les traders de tendance",
    ],
    commonMistakes: [
      "Confondre ADX élevé avec direction haussière — l'ADX mesure la FORCE, pas la direction",
      "Ignorer les croisements +DI/-DI qui donnent la direction",
      "Utiliser l'ADX seul sans confirmer avec le prix ou d'autres indicateurs",
    ],
    combinations: [
      "Moyennes Mobiles : utiliser les MAs quand ADX > 25, les ignorer quand ADX < 20",
      "RSI/Bollinger : utiliser en range quand ADX < 20",
      "Parabolic SAR : combiner pour le suivi de tendance quand ADX confirme",
    ],
    practicalCase: "Exemple Tesla (TSLA), 2023 : L'ADX est passé au-dessus de 25 en juin 2023 avec +DI > -DI, signalant le début d'une tendance haussière forte. Le titre a progressé de +60% en 2 mois. Quand l'ADX a commencé à redescendre sous 25 en août, la tendance s'est essoufflée et le prix est entré en consolidation.",
    keyLevels: ["0-20 — Pas de tendance (range)", "20-25 — Tendance naissante", "25-50 — Tendance forte", "50-75 — Tendance très forte", "75-100 — Tendance extrême (rare)"],
    relatedIndicators: ["Moyennes Mobiles", "MACD", "Parabolic SAR"],
  },
  {
    id: "parabolic-sar",
    name: "Parabolic SAR",
    nameFr: "Parabolic SAR (Stop And Reverse)",
    category: "tendance",
    level: "debutant",
    image: IMG.parabolicSarNew,
    secondaryImage: IMG.parabolicSarInvestopedia,
    chartReadingGuide: "Sur le graphique : les points (dots) se placent au-dessus ou en dessous du prix. Points sous le prix = tendance haussière. Points au-dessus = tendance baissière. Quand les points changent de côté, c'est un signal de retournement (SAR = Stop And Reverse). Les points accélèrent vers le prix au fil du temps.",
    readTime: 5,
    complexity: 3,
    shortDesc: "Indicateur de suivi de tendance qui place des points au-dessus ou en dessous du prix pour signaler la direction.",
    fullDesc: "Le Parabolic SAR (Stop And Reverse) affiche des points au-dessus ou en dessous des bougies. Points sous le prix = tendance haussière. Points au-dessus = tendance baissière. Quand le prix touche un point, le signal s'inverse.",
    howItWorks: "Les points SAR se rapprochent progressivement du prix grâce à un facteur d'accélération (AF). Plus la tendance dure, plus les points se rapprochent. C'est un excellent indicateur pour les trailing stops.",
    interpretation: {
      bullish: "Points SAR passent en dessous du prix (retournement haussier), prix s'éloigne des points (tendance forte).",
      bearish: "Points SAR passent au-dessus du prix (retournement baissier), points se rapprochent du prix (fin de tendance).",
      range: "Les points alternent rapidement au-dessus et en dessous → faux signaux fréquents. Éviter le SAR en range.",
      divergence: "Non applicable directement — le SAR est un indicateur de suivi, pas d'oscillation.",
    },
    multiTimeframe: "Daily pour les positions swing. 4H pour les entrées plus précises. Weekly pour les tendances long terme. Les paramètres standard (AF=0.02, max=0.20) fonctionnent sur tous les timeframes.",
    limits: [
      "Fonctionne mal en range — les faux signaux sont fréquents",
      "Le facteur d'accélération peut rendre les stops trop serrés en fin de tendance",
      "Pas de zone neutre — toujours long ou short, ce qui ne reflète pas la réalité",
    ],
    commonMistakes: [
      "Utiliser le SAR en range sans vérifier avec l'ADX d'abord",
      "Ignorer le contexte de tendance — le SAR fonctionne uniquement en tendance",
      "Modifier les paramètres AF sans comprendre l'impact sur la sensibilité",
    ],
    combinations: [
      "ADX : utiliser le SAR seulement quand ADX > 25",
      "Moyennes Mobiles : confirmer la direction avec la MA 200",
      "ATR : ajuster les stops en fonction de la volatilité",
    ],
    practicalCase: "Exemple Microsoft (MSFT), 2023 : Le SAR est passé en dessous du prix en mars 2023, signalant un retournement haussier. Les points SAR ont servi de trailing stop pendant 4 mois, permettant de capturer un mouvement de +25%. Le signal de sortie (SAR au-dessus du prix) est arrivé en juillet, protégeant les gains.",
    relatedIndicators: ["ADX", "Moyennes Mobiles", "ATR"],
  },
  {
    id: "ema-ribbon",
    name: "EMA Ribbon",
    nameFr: "Ruban de Moyennes Mobiles (EMA Ribbon)",
    category: "tendance",
    level: "intermediaire",
    image: IMG.emaRibbon,
    secondaryImage: IMG.maCrossover,
    chartReadingGuide: "Sur le graphique : 6 à 8 EMAs forment un ruban coloré. Quand les EMAs sont ordonnées (courtes au-dessus des longues) et espacées = tendance haussière forte. Quand elles se compriment et se croisent = changement de tendance imminent. L'écartement du ruban montre la force du momentum. La compression est le signal le plus important à surveiller.",
    readTime: 5,
    complexity: 3,
    shortDesc: "Ensemble de 6 à 8 EMAs qui forment un ruban visuel montrant la force et la direction de la tendance.",
    fullDesc: "Le ruban EMA utilise plusieurs EMAs rapprochées (typiquement 8, 13, 21, 34, 55, 89 — suite de Fibonacci) pour créer un effet visuel de ruban. Quand les EMAs sont ordonnées et espacées, la tendance est forte. Quand elles se compriment et se croisent, un changement de tendance est probable.",
    howItWorks: "EMAs ordonnées de la plus courte (en haut) à la plus longue (en bas) = tendance haussière forte. L'inverse = tendance baissière forte. Le resserrement du ruban = compression avant un mouvement explosif. L'écartement = momentum qui s'accélère.",
    interpretation: {
      bullish: "Ruban ordonné (courtes au-dessus des longues), ruban qui s'écarte vers le haut, prix au-dessus du ruban.",
      bearish: "Ruban inversé (longues au-dessus des courtes), ruban qui s'écarte vers le bas, prix en dessous du ruban.",
      range: "Le ruban se comprime, les EMAs se croisent fréquemment → pas de tendance claire.",
      divergence: "Le ruban commence à se comprimer alors que le prix continue → essoufflement de la tendance.",
    },
    multiTimeframe: "Weekly pour la tendance principale. Daily pour les entrées. Le ruban est particulièrement efficace sur le daily et le 4H.",
    limits: [
      "Indicateur retardé comme toutes les moyennes mobiles",
      "Surcharge visuelle possible avec 6-8 lignes sur le graphique",
      "Moins utile en range — les croisements fréquents brouillent le signal",
    ],
    commonMistakes: [
      "Utiliser trop d'EMAs qui rendent le graphique illisible",
      "Ignorer la compression du ruban qui est le signal le plus important",
      "Ne pas attendre la confirmation (ruban ordonné) avant d'entrer en position",
    ],
    combinations: [
      "ADX pour confirmer la force de la tendance quand le ruban est ordonné",
      "Volume pour valider les expansions du ruban",
      "RSI pour les entrées sur pullback vers le ruban",
    ],
    practicalCase: "Exemple Nvidia (NVDA), 2023 : Le ruban EMA s'est ordonné en janvier 2023 (toutes les EMAs courtes au-dessus des longues) et s'est écarté progressivement. Chaque pullback vers le ruban a été une opportunité d'entrée. Le titre a progressé de +200% pendant que le ruban restait ordonné.",
    relatedIndicators: ["Moyennes Mobiles", "ADX", "MACD"],
  },
  {
    id: "supertrend",
    name: "SuperTrend",
    nameFr: "SuperTrend",
    category: "tendance",
    level: "debutant",
    image: IMG.supertrend,
    secondaryImage: IMG.parabolicSar,
    chartReadingGuide: "Sur le graphique : une seule ligne qui change de couleur. Ligne verte sous le prix = tendance haussière (support dynamique). Ligne rouge au-dessus du prix = tendance baissière (résistance dynamique). Le changement de couleur = signal de retournement. Simple et visuel, idéal pour les débutants. Les rebonds sur la ligne verte sont des zones d'entrée potentielles.",
    readTime: 4,
    complexity: 2,
    popular: true,
    shortDesc: "Indicateur de tendance simple basé sur l'ATR — une seule ligne qui change de couleur selon la direction.",
    fullDesc: "Le SuperTrend est un indicateur de suivi de tendance qui utilise l'ATR pour calculer des bandes dynamiques autour du prix. Il affiche une seule ligne qui passe en vert (haussier) quand le prix est au-dessus, et en rouge (baissier) quand le prix est en dessous. Simple à lire, il est très populaire chez les débutants.",
    howItWorks: "Le SuperTrend calcule une bande supérieure et inférieure basées sur l'ATR (typiquement 10 périodes, multiplicateur 3). Quand le prix clôture au-dessus de la bande supérieure, la ligne passe en support (vert). Quand il clôture en dessous de la bande inférieure, elle passe en résistance (rouge).",
    interpretation: {
      bullish: "Ligne verte sous le prix = tendance haussière. Le prix rebondit sur la ligne SuperTrend.",
      bearish: "Ligne rouge au-dessus du prix = tendance baissière. Le prix est rejeté par la ligne SuperTrend.",
      range: "La ligne change fréquemment de couleur → marché sans direction. Faux signaux nombreux.",
      divergence: "Non applicable directement — le SuperTrend est binaire (haussier ou baissier).",
    },
    multiTimeframe: "Daily pour le swing trading. 4H pour le day trading. Weekly pour les positions long terme. Le multiplicateur ATR peut être ajusté (2 = plus sensible, 4 = moins sensible).",
    limits: [
      "Indicateur retardé — les retournements sont signalés après le fait",
      "Faux signaux en range (comme le Parabolic SAR)",
      "Le choix du multiplicateur ATR impacte fortement la sensibilité",
    ],
    commonMistakes: [
      "Utiliser un multiplicateur trop bas (1-2) qui génère trop de faux signaux",
      "Ne pas combiner avec un filtre de tendance (ADX) pour éviter les ranges",
      "Ignorer le contexte de marché et suivre aveuglément les changements de couleur",
    ],
    combinations: [
      "ADX pour filtrer les signaux en range",
      "Volume pour confirmer les changements de direction",
      "RSI pour affiner les entrées sur les pullbacks",
    ],
    practicalCase: "Exemple Amazon (AMZN), 2023 : Le SuperTrend (10, 3) est passé en vert en février 2023. La ligne verte a servi de support dynamique pendant 5 mois, avec 3 rebonds confirmés. Le signal de sortie (passage en rouge) est arrivé en août, après un mouvement de +35%.",
    relatedIndicators: ["Parabolic SAR", "ATR", "ADX"],
  },
  {
    id: "aroon",
    name: "Aroon",
    nameFr: "Aroon (Up/Down)",
    category: "tendance",
    level: "intermediaire",
    image: IMG.aroon,
    secondaryImage: IMG.adx,
    chartReadingGuide: "Sur le graphique : deux lignes oscillent entre 0 et 100. Aroon Up (verte) mesure le temps depuis le dernier plus haut. Aroon Down (rouge) mesure le temps depuis le dernier plus bas. Aroon Up > 70 et Aroon Down < 30 = tendance haussière forte. Le croisement des deux lignes signale un changement de tendance. Les deux lignes autour de 50 = pas de tendance.",
    readTime: 5,
    complexity: 3,
    shortDesc: "Mesure le temps écoulé depuis le dernier plus haut/plus bas pour identifier le début et la fin des tendances.",
    fullDesc: "L'indicateur Aroon, développé par Tushar Chande, se compose de deux lignes : Aroon Up (temps depuis le dernier plus haut) et Aroon Down (temps depuis le dernier plus bas). Les deux oscillent entre 0 et 100. Un Aroon Up proche de 100 signifie qu'un nouveau plus haut vient d'être atteint — la tendance haussière est forte.",
    howItWorks: "Aroon Up = ((période - nombre de barres depuis le plus haut) / période) × 100. Aroon Down = même calcul avec le plus bas. Quand Aroon Up > 70 et Aroon Down < 30, la tendance est haussière. L'inverse = tendance baissière. Le croisement des deux lignes signale un changement de tendance.",
    interpretation: {
      bullish: "Aroon Up > 70, Aroon Down < 30. Aroon Up croise au-dessus de Aroon Down.",
      bearish: "Aroon Down > 70, Aroon Up < 30. Aroon Down croise au-dessus de Aroon Up.",
      range: "Les deux lignes oscillent autour de 50, se croisent fréquemment → pas de tendance.",
      divergence: "Aroon Up commence à baisser alors que le prix fait de nouveaux sommets → essoufflement.",
    },
    multiTimeframe: "Daily pour les signaux swing. Weekly pour la tendance principale. La période standard est 25.",
    limits: [
      "Sensible aux petits mouvements de prix qui peuvent créer de faux signaux",
      "Moins connu que l'ADX, donc moins suivi par les traders",
      "La période de 25 n'est pas optimale pour tous les actifs",
    ],
    commonMistakes: [
      "Confondre Aroon avec l'ADX — l'Aroon mesure le TEMPS, l'ADX mesure la FORCE",
      "Ignorer les croisements qui sont les signaux les plus importants",
      "Utiliser une période trop courte qui génère trop de bruit",
    ],
    combinations: [
      "ADX pour confirmer la force quand l'Aroon signale une direction",
      "Volume pour valider les croisements Aroon",
      "Moyennes Mobiles pour confirmer la direction",
    ],
    practicalCase: "Exemple Meta (META), 2023 : L'Aroon Up est passé au-dessus de 70 en février 2023 tandis que l'Aroon Down est tombé sous 30, signalant le début d'une tendance haussière forte. Le signal a précédé un mouvement de +100% en 6 mois.",
    relatedIndicators: ["ADX", "Moyennes Mobiles", "SuperTrend"],
  },
  {
    id: "linear-regression",
    name: "Linear Regression Channel",
    nameFr: "Canal de Régression Linéaire",
    category: "tendance",
    level: "avance",
    image: IMG.linearRegression,
    secondaryImage: IMG.maCrossover,
    chartReadingGuide: "Sur le graphique : une droite centrale (régression linéaire) avec deux bandes parallèles à ±2 écarts-types. La pente de la droite indique la direction. Le prix qui touche la bande supérieure est statistiquement 'étiré' (surachat). Le prix qui touche la bande inférieure est 'comprimé' (survente). Les rebonds sur la droite centrale sont des zones d'entrée statistiquement favorables.",
    readTime: 7,
    complexity: 4,
    shortDesc: "Canal statistique basé sur la régression linéaire — identifie la tendance mathématique et les écarts significatifs.",
    fullDesc: "Le canal de régression linéaire trace une droite de meilleur ajustement (régression linéaire) à travers les prix, avec des bandes parallèles à 1 ou 2 écarts-types. La pente de la droite indique la direction de la tendance. Les bandes montrent les limites statistiques du mouvement.",
    howItWorks: "La droite centrale est la régression linéaire des prix de clôture sur N périodes. Les bandes supérieure et inférieure sont à ±2 écarts-types. Le prix qui touche la bande supérieure est statistiquement \"étiré\" vers le haut. Le prix qui touche la bande inférieure est \"étiré\" vers le bas.",
    interpretation: {
      bullish: "Pente positive, prix rebondit sur la bande inférieure ou la droite centrale.",
      bearish: "Pente négative, prix rejeté par la bande supérieure ou la droite centrale.",
      range: "Pente proche de zéro, prix oscille entre les bandes → marché latéral.",
      divergence: "Le prix fait de nouveaux sommets mais la pente de la régression s'aplatit → essoufflement.",
    },
    multiTimeframe: "200 périodes sur le daily pour la tendance long terme. 50 périodes pour le moyen terme. 20 périodes pour le court terme.",
    limits: [
      "La régression est recalculée à chaque nouvelle bougie — le canal peut changer rétrospectivement",
      "Sensible à la période choisie — des périodes différentes donnent des résultats très différents",
      "Assume une relation linéaire qui n'est pas toujours réaliste",
    ],
    commonMistakes: [
      "Utiliser une période trop courte qui rend le canal instable",
      "Ignorer que le canal se recalcule — ce qui semble être un support peut disparaître",
      "Confondre avec un canal de tendance tracé manuellement",
    ],
    combinations: [
      "RSI pour confirmer les conditions de surachat/survente aux bandes",
      "Volume pour valider les rebonds sur les bandes",
      "Bollinger Bands pour une double confirmation statistique",
    ],
    practicalCase: "Exemple S&P 500, 2023 : Un canal de régression linéaire sur 100 jours a montré une pente positive avec le prix oscillant entre la droite centrale et la bande supérieure. Les corrections vers la droite centrale ont été des zones d'entrée statistiquement favorables.",
    relatedIndicators: ["Bollinger Bands", "Moyennes Mobiles", "Fibonacci"],
  },
  // ──────────── MOMENTUM (10) ────────────
  {
    id: "macd",
    name: "MACD",
    nameFr: "MACD (Moving Average Convergence Divergence)",
    category: "momentum",
    level: "debutant",
    image: IMG.rsiMacdCombo,
    secondaryImage: IMG.macd,
    chartReadingGuide: "Sur le graphique : la ligne MACD (bleue) et la ligne de signal (orange) se croisent. Quand la MACD croise au-dessus du signal = momentum haussier. L'histogramme (barres vertes/rouges) montre la force du momentum. Plus les barres sont grandes, plus le momentum est fort. Le croisement de la ligne zéro est un signal clé.",
    readTime: 7,
    complexity: 3,
    popular: true,
    shortDesc: "Indicateur de momentum qui mesure la convergence et la divergence entre deux EMAs.",
    fullDesc: "Le MACD se compose de trois éléments : la ligne MACD (EMA 12 - EMA 26), la ligne de signal (EMA 9 du MACD), et l'histogramme (différence entre MACD et signal). Il permet d'identifier la direction du momentum, sa force, et les potentiels retournements.",
    howItWorks: "Le MACD oscille autour de la ligne zéro. Quand la ligne MACD croise au-dessus du signal, c'est un signal haussier. L'histogramme montre la force du momentum : barres croissantes = momentum qui s'accélère.",
    interpretation: {
      bullish: "Croisement MACD au-dessus du signal, histogramme positif et croissant, MACD au-dessus de zéro.",
      bearish: "Croisement MACD en dessous du signal, histogramme négatif et décroissant, MACD en dessous de zéro.",
      range: "MACD oscille autour de zéro sans direction claire. Les croisements sont fréquents et peu fiables.",
      divergence: "Prix fait un nouveau sommet mais MACD fait un sommet plus bas = divergence baissière (signal de retournement puissant).",
    },
    multiTimeframe: "Weekly MACD pour la tendance principale. Daily pour les signaux d'entrée. Les divergences sur le weekly sont les plus fiables.",
    limits: [
      "Indicateur retardé — les croisements arrivent après le début du mouvement",
      "Faux signaux fréquents en range",
      "Les paramètres standard (12/26/9) ne sont pas optimaux pour tous les actifs",
    ],
    commonMistakes: [
      "Ignorer les divergences qui sont les signaux les plus fiables du MACD",
      "Utiliser le MACD en range sans filtre de tendance",
      "Se fier uniquement aux croisements sans regarder la position par rapport à zéro",
    ],
    combinations: [
      "RSI pour confirmer les signaux de surachat/survente",
      "ADX pour filtrer les signaux en range (ADX < 20 = ignorer le MACD)",
      "Volume pour confirmer la force des croisements",
    ],
    practicalCase: "Exemple Nvidia (NVDA), 2023 : Une divergence haussière MACD/prix s'est formée en janvier 2023 (prix stable, MACD en hausse). Le croisement haussier qui a suivi a précédé un rallye de +200%. L'histogramme croissant a confirmé l'accélération du momentum.",
    relatedIndicators: ["RSI", "Moyennes Mobiles", "Stochastique"],
  },
  {
    id: "rsi",
    name: "RSI",
    nameFr: "RSI (Relative Strength Index)",
    category: "momentum",
    level: "debutant",
    image: IMG.rsiSignals,
    secondaryImage: IMG.rsi,
    chartReadingGuide: "Sur le graphique : la ligne RSI oscille entre 0 et 100. La zone au-dessus de 70 (surachat) est colorée en rouge, celle en dessous de 30 (survente) en vert. Quand la ligne RSI entre dans ces zones, c'est un signal de tension. Les divergences entre le prix (en haut) et le RSI (en bas) sont les signaux les plus fiables.",
    readTime: 6,
    complexity: 2,
    popular: true,
    shortDesc: "Oscillateur borné entre 0 et 100 qui mesure la vitesse et l'amplitude des mouvements de prix.",
    fullDesc: "Le RSI, développé par J. Welles Wilder, mesure la force relative des mouvements haussiers par rapport aux mouvements baissiers sur 14 périodes. C'est l'un des indicateurs les plus utilisés pour identifier les conditions de surachat (>70) et de survente (<30).",
    howItWorks: "Le RSI compare la magnitude des gains récents aux pertes récentes. RSI > 70 = surachat. RSI < 30 = survente. Le niveau 50 sert de ligne médiane — au-dessus = momentum haussier, en dessous = momentum baissier.",
    interpretation: {
      bullish: "RSI < 30 puis remonte au-dessus, divergence haussière, RSI rebondit sur 50 en tendance haussière.",
      bearish: "RSI > 70 puis redescend sous 70, divergence baissière, RSI rejeté par 50 en tendance baissière.",
      range: "RSI oscille entre 40 et 60 sans direction claire. Les signaux de surachat/survente sont plus fiables en range.",
      divergence: "Prix fait un nouveau sommet mais RSI fait un sommet plus bas = divergence baissière. L'un des signaux les plus fiables.",
    },
    multiTimeframe: "RSI 14 daily = standard. RSI weekly pour la tendance long terme. En tendance haussière forte, le RSI oscille entre 40-80. En tendance baissière, entre 20-60.",
    limits: [
      "En tendance forte, le RSI peut rester en surachat/survente très longtemps",
      "Les niveaux 70/30 ne sont pas des signaux automatiques de retournement",
      "La période de 14 n'est pas optimale pour tous les timeframes",
    ],
    commonMistakes: [
      "Vendre automatiquement quand RSI > 70 en tendance haussière forte",
      "Ignorer les divergences qui sont les signaux les plus puissants",
      "Utiliser le RSI seul sans contexte de tendance",
    ],
    combinations: [
      "MACD pour confirmer les divergences (double divergence = signal très fort)",
      "Bollinger Bands pour confirmer les zones de surachat/survente",
      "Supports/Résistances pour les entrées aux niveaux clés quand le RSI est en zone extrême",
    ],
    practicalCase: "Exemple Apple (AAPL), 2023 : Le RSI weekly est tombé à 28 en janvier 2023 (survente) avec une divergence haussière (prix en baisse, RSI en hausse). Le rebond qui a suivi a mené à un rallye de +50% en 6 mois. Le RSI n'a plus touché 30 pendant toute la hausse.",
    keyLevels: ["70 — zone de surachat", "50 — ligne médiane", "30 — zone de survente"],
    relatedIndicators: ["MACD", "Stochastique", "Bollinger Bands"],
  },
  {
    id: "stochastic",
    name: "Stochastic Oscillator",
    nameFr: "Oscillateur Stochastique",
    category: "momentum",
    level: "intermediaire",
    image: IMG.bollingerStochastic,
    secondaryImage: IMG.stochastic,
    chartReadingGuide: "Sur le graphique : deux lignes (%K rapide et %D lente) oscillent entre 0 et 100. Zone > 80 = surachat. Zone < 20 = survente. Le croisement de %K au-dessus de %D en zone de survente est un signal haussier. L'inverse en zone de surachat est baissier. Les divergences stochastique/prix sont des signaux puissants.",
    readTime: 6,
    complexity: 3,
    shortDesc: "Oscillateur qui compare le prix de clôture à la fourchette de prix sur une période donnée.",
    fullDesc: "L'oscillateur stochastique mesure la position du prix de clôture par rapport à la fourchette haut-bas sur 14 périodes. Il se compose de %K (ligne rapide) et %D (moyenne mobile de %K). Il oscille entre 0 et 100, avec surachat >80 et survente <20.",
    howItWorks: "Le stochastique est efficace en range pour identifier les retournements aux extrêmes. %K croise au-dessus de %D en zone de survente = signal haussier. %K croise en dessous de %D en zone de surachat = signal baissier.",
    interpretation: {
      bullish: "Croisement %K > %D sous 20, divergence haussière, sortie de la zone de survente.",
      bearish: "Croisement %K < %D au-dessus de 80, divergence baissière, sortie de la zone de surachat.",
      range: "Le stochastique excelle en range — les signaux de surachat/survente sont les plus fiables.",
      divergence: "Prix fait un nouveau bas mais %K fait un bas plus haut = divergence haussière.",
    },
    multiTimeframe: "Daily pour les signaux swing. 4H pour le day trading. Le stochastique lent (Slow Stochastic) est préféré pour réduire les faux signaux.",
    limits: [
      "En tendance forte, le stochastique peut rester en surachat/survente longtemps",
      "Plus de faux signaux que le RSI en tendance",
      "Le stochastique rapide est très bruité — préférer le lent",
    ],
    commonMistakes: [
      "Utiliser le stochastique rapide au lieu du lent (trop de faux signaux)",
      "Vendre en surachat pendant une tendance haussière forte",
      "Ignorer le contexte de marché (tendance vs range)",
    ],
    combinations: [
      "RSI pour confirmer les zones extrêmes (double confirmation)",
      "Supports/Résistances pour les entrées aux niveaux clés",
      "ADX pour déterminer si le marché est en tendance ou en range",
    ],
    practicalCase: "Exemple EUR/USD, 2023 : En range entre 1.05 et 1.10, le stochastique lent a donné 6 signaux de surachat/survente fiables en 3 mois. Chaque croisement en zone extrême a précédé un retournement de 200-300 pips.",
    keyLevels: ["80 — zone de surachat", "50 — ligne médiane", "20 — zone de survente"],
    relatedIndicators: ["RSI", "MACD", "Bollinger Bands"],
  },
  {
    id: "williams-r",
    name: "Williams %R",
    nameFr: "Williams %R",
    category: "momentum",
    level: "intermediaire",
    image: IMG.williamsRNew,
    secondaryImage: IMG.williamsR,
    chartReadingGuide: "Sur le graphique : la ligne Williams %R oscille entre 0 et -100 (inversé par rapport au RSI). Zone entre 0 et -20 = surachat. Zone entre -80 et -100 = survente. Quand la ligne quitte la zone de survente (remonte au-dessus de -80) = signal haussier. L'échelle inversée peut être déroutante au début.",
    readTime: 4,
    complexity: 2,
    shortDesc: "Oscillateur rapide qui identifie les conditions de surachat/survente — similaire au stochastique mais inversé.",
    fullDesc: "Le Williams %R oscille entre 0 et -100. Il mesure le niveau de fermeture par rapport au plus haut de la période. C'est essentiellement l'inverse du stochastique rapide, plus réactif que le RSI.",
    howItWorks: "Williams %R compare le prix de clôture au range sur 14 périodes. 0 à -20 = surachat. -80 à -100 = survente. Les valeurs sont négatives (0 = plus haut, -100 = plus bas).",
    interpretation: {
      bullish: "Williams %R passe de -80/-100 au-dessus de -80, divergence haussière.",
      bearish: "Williams %R passe de 0/-20 en dessous de -20, divergence baissière.",
      range: "Excellent en range — les signaux aux extrêmes sont fiables.",
      divergence: "Divergences Williams %R/prix = signaux de retournement fiables.",
    },
    multiTimeframe: "14 périodes standard. Plus réactif que le RSI — idéal pour le scalping et le day trading.",
    limits: [
      "Très réactif = plus de faux signaux que le RSI",
      "En tendance forte, reste en zone extrême longtemps",
      "Moins populaire que le RSI, donc moins suivi",
    ],
    commonMistakes: [
      "Confondre avec le RSI — les échelles sont inversées",
      "Utiliser seul sans confirmation",
      "Ignorer le contexte de tendance",
    ],
    combinations: [
      "RSI pour confirmation croisée",
      "Stochastique pour triple confirmation des zones extrêmes",
      "Supports/Résistances pour les entrées précises",
    ],
    practicalCase: "Exemple Bitcoin (BTC), 2023 : Le Williams %R est tombé à -95 en mars 2023 (survente extrême) avec une divergence haussière. Le rebond qui a suivi a mené à un rallye de +40% en 2 mois.",
    keyLevels: ["0 à -20 — Surachat", "-50 — Médiane", "-80 à -100 — Survente"],
    relatedIndicators: ["RSI", "Stochastique", "MACD"],
  },
  {
    id: "cci",
    name: "CCI",
    nameFr: "CCI (Commodity Channel Index)",
    category: "momentum",
    level: "intermediaire",
    image: IMG.cciFidelity,
    secondaryImage: IMG.cci,
    chartReadingGuide: "Sur le graphique : la ligne CCI oscille autour de zéro sans limites fixes. Au-dessus de +100 = surachat / momentum fort. En dessous de -100 = survente / momentum faible. Le croisement de zéro est un signal de changement de direction. Les divergences CCI/prix sont des signaux de retournement fiables.",
    readTime: 6,
    complexity: 4,
    shortDesc: "Oscillateur non borné qui mesure l'écart du prix par rapport à sa moyenne statistique.",
    fullDesc: "Le CCI mesure l'écart du prix typique par rapport à sa SMA, normalisé par l'écart moyen. Il oscille typiquement entre +100 et -100 mais n'est pas borné. Développé par Donald Lambert, il fonctionne sur tous les marchés.",
    howItWorks: "CCI > +100 = force haussière ou surachat. CCI < -100 = force baissière ou survente. Le passage au-dessus/en dessous de 0 = changement de momentum.",
    interpretation: {
      bullish: "CCI passe au-dessus de +100 (tendance haussière forte), rebond depuis -100.",
      bearish: "CCI passe en dessous de -100 (tendance baissière forte), retombe depuis +100.",
      range: "CCI oscille entre -100 et +100 — les signaux aux extrêmes sont plus fiables.",
      divergence: "Divergences CCI/prix très fiables pour les retournements.",
    },
    multiTimeframe: "CCI 20 périodes standard. 14 pour plus de réactivité. Daily pour le swing, 4H pour le day trading.",
    limits: [
      "Non borné — des valeurs de +200 ou -200 sont possibles",
      "Moins intuitif que le RSI pour les débutants",
      "Le choix de la période impacte fortement les résultats",
    ],
    commonMistakes: [
      "Traiter +100/-100 comme des limites absolues — le CCI peut aller bien au-delà",
      "Ignorer les divergences qui sont les signaux les plus fiables",
      "Utiliser une période trop courte qui génère trop de bruit",
    ],
    combinations: [
      "RSI pour confirmer les zones extrêmes",
      "ADX pour filtrer les signaux en range",
      "Volume pour valider les mouvements au-delà de ±100",
    ],
    practicalCase: "Exemple Or (GLD), 2023 : Le CCI est passé au-dessus de +200 en mars 2023, signalant un momentum haussier extrême. Plutôt qu'un signal de vente, cela a confirmé la force du mouvement. L'or a continué à progresser de +10% supplémentaires.",
    keyLevels: ["+200 — Surachat extrême", "+100 — Force haussière", "0 — Neutre", "-100 — Force baissière", "-200 — Survente extrême"],
    relatedIndicators: ["RSI", "Stochastique", "ADX"],
  },
  {
    id: "roc",
    name: "ROC",
    nameFr: "ROC (Rate of Change)",
    category: "momentum",
    level: "debutant",
    image: IMG.rocRateOfChange,
    secondaryImage: IMG.rsi,
    chartReadingGuide: "Sur le graphique : la ligne ROC oscille autour de zéro. ROC positif = le prix est plus haut qu'il y a N périodes (momentum haussier). ROC négatif = le prix est plus bas. Le croisement de zéro est le signal clé. La pente du ROC montre l'accélération ou la décélération du momentum. Les divergences ROC/prix signalent les essoufflements.",
    readTime: 4,
    complexity: 1,
    shortDesc: "Mesure le pourcentage de variation du prix sur une période donnée — le momentum dans sa forme la plus pure.",
    fullDesc: "Le ROC (Rate of Change) calcule simplement le pourcentage de variation du prix par rapport à N périodes en arrière. C'est l'indicateur de momentum le plus simple et le plus direct. ROC = ((Prix actuel - Prix N périodes) / Prix N périodes) × 100.",
    howItWorks: "ROC positif = le prix est plus haut qu'il y a N périodes (momentum haussier). ROC négatif = le prix est plus bas (momentum baissier). ROC qui augmente = momentum qui s'accélère. ROC qui diminue = momentum qui s'essouffle.",
    interpretation: {
      bullish: "ROC positif et en hausse. ROC croise au-dessus de zéro.",
      bearish: "ROC négatif et en baisse. ROC croise en dessous de zéro.",
      range: "ROC oscille autour de zéro sans direction claire.",
      divergence: "Prix fait un nouveau sommet mais ROC fait un sommet plus bas = essoufflement.",
    },
    multiTimeframe: "ROC 12 daily = standard. ROC 52 weekly = momentum annuel. ROC 1 = momentum quotidien.",
    limits: [
      "Très simple — ne capture pas les nuances des autres oscillateurs",
      "Sensible aux valeurs aberrantes (gaps, earnings)",
      "Pas de zones de surachat/survente définies",
    ],
    commonMistakes: [
      "Utiliser seul sans contexte — trop simple pour des décisions complexes",
      "Ignorer l'effet de base (un ROC élevé après une forte baisse n'est pas forcément haussier)",
      "Confondre vitesse (ROC) et direction (tendance)",
    ],
    combinations: [
      "Moyennes Mobiles pour la direction de la tendance",
      "RSI pour les zones de surachat/survente",
      "Volume pour confirmer la conviction du momentum",
    ],
    practicalCase: "Exemple S&P 500, 2023 : Le ROC 12 mois est passé de -20% (janvier 2023) à +20% (décembre 2023), montrant clairement le retournement du momentum annuel. Ce type de swing du ROC annuel est historiquement suivi de rendements positifs.",
    relatedIndicators: ["Momentum Indicator", "MACD", "RSI"],
  },
  {
    id: "momentum-indicator",
    name: "Momentum Indicator",
    nameFr: "Indicateur de Momentum",
    category: "momentum",
    level: "debutant",
    image: IMG.momentumIndicator,
    secondaryImage: IMG.rsi,
    chartReadingGuide: "Sur le graphique : la ligne Momentum oscille autour de zéro (ou 100 selon la plateforme). Au-dessus de zéro = prix plus haut qu'il y a N périodes. En dessous = prix plus bas. La pente est plus importante que la valeur absolue. Un momentum qui accélère vers le haut = force acheteuse croissante. Les divergences momentum/prix = signaux de retournement.",
    readTime: 3,
    complexity: 1,
    shortDesc: "Mesure la différence absolue de prix sur N périodes — version non normalisée du ROC.",
    fullDesc: "L'indicateur de Momentum calcule la différence entre le prix actuel et le prix N périodes en arrière. Contrairement au ROC qui donne un pourcentage, le Momentum donne une valeur absolue. Momentum = Prix actuel - Prix N périodes.",
    howItWorks: "Momentum positif = prix plus haut qu'avant. Momentum négatif = prix plus bas. La ligne zéro est le pivot. La pente du momentum est plus importante que sa valeur absolue.",
    interpretation: {
      bullish: "Momentum positif et en hausse. Croisement au-dessus de zéro.",
      bearish: "Momentum négatif et en baisse. Croisement en dessous de zéro.",
      range: "Momentum oscille autour de zéro.",
      divergence: "Divergences momentum/prix = signaux de retournement.",
    },
    multiTimeframe: "10-14 périodes standard. Daily pour le swing. Weekly pour le long terme.",
    limits: [
      "Valeur absolue — difficile de comparer entre différents actifs",
      "Pas de zones de surachat/survente standardisées",
      "Le ROC (version pourcentage) est généralement préféré",
    ],
    commonMistakes: [
      "Comparer le momentum de deux actifs avec des prix différents",
      "Ignorer la direction de la pente",
      "Utiliser seul sans autres indicateurs",
    ],
    combinations: [
      "ROC pour la version normalisée",
      "Moyennes Mobiles pour la direction",
      "Volume pour la confirmation",
    ],
    practicalCase: "Exemple : Le momentum 14 jours de Microsoft est passé de -15 à +20 en mars 2023, signalant un retournement clair du momentum à court terme.",
    relatedIndicators: ["ROC", "MACD", "RSI"],
  },
  {
    id: "tsi",
    name: "TSI",
    nameFr: "TSI (True Strength Index)",
    category: "momentum",
    level: "avance",
    image: IMG.tsi,
    secondaryImage: IMG.macd,
    chartReadingGuide: "Sur le graphique : la ligne TSI (bleue) oscille entre -100 et +100 avec une ligne de signal (rouge). TSI au-dessus de zéro = momentum haussier. Le croisement TSI/signal donne les entrées. Le double lissage rend la ligne plus lisse que le MACD, filtrant le bruit. Les divergences TSI/prix sont très fiables grâce au filtrage du bruit.",
    readTime: 7,
    complexity: 4,
    shortDesc: "Oscillateur de momentum doublement lissé qui filtre le bruit tout en restant réactif aux changements de tendance.",
    fullDesc: "Le TSI (True Strength Index) applique un double lissage exponentiel au momentum des prix. Il oscille entre -100 et +100 et est accompagné d'une ligne de signal. Le double lissage élimine le bruit tout en préservant la réactivité — un avantage sur le MACD.",
    howItWorks: "Le TSI calcule le momentum (variation de prix), puis applique deux EMA successives (25 et 13 périodes par défaut). Le résultat est normalisé entre -100 et +100. La ligne de signal est une EMA 7 du TSI.",
    interpretation: {
      bullish: "TSI croise au-dessus de la ligne de signal. TSI au-dessus de zéro.",
      bearish: "TSI croise en dessous de la ligne de signal. TSI en dessous de zéro.",
      range: "TSI oscille autour de zéro sans direction claire.",
      divergence: "Divergences TSI/prix très fiables grâce au double lissage qui filtre les faux signaux.",
    },
    multiTimeframe: "Paramètres standard (25, 13, 7). Daily pour le swing. Weekly pour le long terme.",
    limits: [
      "Plus complexe que le MACD — moins intuitif pour les débutants",
      "Le double lissage ajoute du retard",
      "Moins populaire, donc moins de ressources éducatives disponibles",
    ],
    commonMistakes: [
      "Confondre avec le MACD — le TSI est plus lissé et moins réactif",
      "Modifier les paramètres sans comprendre l'impact du double lissage",
      "Ignorer la ligne de signal",
    ],
    combinations: [
      "RSI pour confirmer les zones extrêmes",
      "ADX pour confirmer la force de la tendance",
      "Volume pour valider les croisements",
    ],
    practicalCase: "Exemple Alphabet (GOOGL), 2023 : Le TSI a formé une divergence haussière en janvier 2023 (prix stable, TSI en hausse) puis a croisé au-dessus de sa ligne de signal. Le titre a progressé de +50% en 6 mois.",
    relatedIndicators: ["MACD", "RSI", "PPO"],
  },
  {
    id: "ppo",
    name: "PPO",
    nameFr: "PPO (Percentage Price Oscillator)",
    category: "momentum",
    level: "intermediaire",
    image: IMG.ppo,
    secondaryImage: IMG.macd,
    chartReadingGuide: "Sur le graphique : identique au MACD visuellement mais en pourcentage. La ligne PPO, la ligne de signal et l'histogramme fonctionnent comme le MACD. L'avantage : les valeurs en % permettent de comparer le momentum entre actifs de prix différents (ex: AAPL à 180$ vs TSLA à 250$). Mêmes signaux de croisement et divergences que le MACD.",
    readTime: 5,
    complexity: 3,
    shortDesc: "Version normalisée du MACD en pourcentage — permet de comparer le momentum entre différents actifs.",
    fullDesc: "Le PPO est identique au MACD dans son calcul mais exprime le résultat en pourcentage plutôt qu'en valeur absolue. PPO = ((EMA 12 - EMA 26) / EMA 26) × 100. Cela permet de comparer le momentum entre des actifs de prix très différents.",
    howItWorks: "Même interprétation que le MACD : croisements, histogramme, divergences. L'avantage est la normalisation en pourcentage qui permet les comparaisons inter-actifs.",
    interpretation: {
      bullish: "PPO croise au-dessus de la ligne de signal. PPO au-dessus de zéro.",
      bearish: "PPO croise en dessous de la ligne de signal. PPO en dessous de zéro.",
      range: "PPO oscille autour de zéro.",
      divergence: "Mêmes divergences que le MACD mais comparables entre actifs.",
    },
    multiTimeframe: "Mêmes paramètres que le MACD (12/26/9). L'avantage du PPO est la comparaison entre timeframes et actifs.",
    limits: [
      "Même retard que le MACD",
      "Moins connu que le MACD — moins de support communautaire",
      "La normalisation n'ajoute pas de valeur si on ne compare pas entre actifs",
    ],
    commonMistakes: [
      "Utiliser le PPO quand le MACD suffit (un seul actif)",
      "Confondre les signaux PPO avec ceux du MACD — ils sont identiques en direction",
      "Ignorer l'avantage comparatif du PPO",
    ],
    combinations: [
      "RSI pour les zones extrêmes",
      "ADX pour la force de la tendance",
      "Comparaison PPO entre secteurs pour identifier les rotations",
    ],
    practicalCase: "Exemple : En comparant le PPO du Nasdaq (QQQ) et du S&P 500 (SPY) en 2023, le PPO du QQQ était significativement plus élevé, confirmant la surperformance du secteur tech.",
    relatedIndicators: ["MACD", "TSI", "RSI"],
  },
  {
    id: "awesome-oscillator",
    name: "Awesome Oscillator",
    nameFr: "Awesome Oscillator (AO)",
    category: "momentum",
    level: "intermediaire",
    image: IMG.awesomeOscillator,
    secondaryImage: IMG.macd,
    chartReadingGuide: "Sur le graphique : un histogramme coloré (vert = barre supérieure à la précédente, rouge = inférieure). AO > 0 = momentum haussier. AO < 0 = momentum baissier. Le croisement de zéro est le signal principal. Le pattern 'Saucer' (3 barres consécutives au-dessus de zéro, la dernière plus haute) est un signal spécifique. Le 'Twin Peaks' est une forme de divergence propre à l'AO.",
    readTime: 5,
    complexity: 3,
    shortDesc: "Oscillateur de momentum créé par Bill Williams qui mesure la différence entre deux SMAs du prix médian.",
    fullDesc: "L'Awesome Oscillator (AO) calcule la différence entre la SMA 5 et la SMA 34 du prix médian ((High + Low) / 2). Il est affiché sous forme d'histogramme coloré : vert quand la barre est supérieure à la précédente, rouge quand elle est inférieure.",
    howItWorks: "AO > 0 = momentum haussier. AO < 0 = momentum baissier. Le croisement de zéro est le signal principal. Le \"Saucer\" (soucoupe) est un pattern spécifique : 3 barres consécutives au-dessus de zéro dont la dernière est plus haute que la précédente.",
    interpretation: {
      bullish: "AO croise au-dessus de zéro. Pattern Saucer haussier. Twin Peaks haussier (deux creux sous zéro, le second plus haut).",
      bearish: "AO croise en dessous de zéro. Pattern Saucer baissier. Twin Peaks baissier.",
      range: "AO oscille autour de zéro avec des barres de faible amplitude.",
      divergence: "Twin Peaks = forme de divergence spécifique à l'AO.",
    },
    multiTimeframe: "Paramètres fixes (5/34). Daily pour le swing. 4H pour le day trading.",
    limits: [
      "Paramètres non ajustables dans la version originale",
      "Moins précis que le MACD pour les croisements",
      "Les patterns (Saucer, Twin Peaks) sont subjectifs",
    ],
    commonMistakes: [
      "Modifier les paramètres (5/34) — ils sont conçus pour fonctionner ensemble",
      "Ignorer les patterns spécifiques (Saucer, Twin Peaks) qui sont les signaux les plus fiables",
      "Confondre avec le MACD — l'AO utilise le prix médian, pas le close",
    ],
    combinations: [
      "Fractals de Bill Williams pour les entrées",
      "Alligator de Bill Williams pour la confirmation de tendance",
      "Volume pour valider les croisements de zéro",
    ],
    practicalCase: "Exemple AMD, 2023 : L'AO a formé un Twin Peaks haussier en février 2023 (deux creux sous zéro, le second plus haut) suivi d'un croisement au-dessus de zéro. Le titre a progressé de +80% en 6 mois.",
    relatedIndicators: ["MACD", "RSI", "Momentum Indicator"],
  },
  // ──────────── VOLATILITÉ (7) ────────────
  {
    id: "bollinger-bands",
    name: "Bollinger Bands",
    nameFr: "Bandes de Bollinger",
    category: "volatilite",
    level: "debutant",
    image: IMG.bollingerChart,
    secondaryImage: IMG.bollinger,
    chartReadingGuide: "Sur le graphique : les 3 lignes forment un canal. La ligne centrale (SMA 20) est la moyenne. Les bandes supérieure et inférieure sont à ±2 écarts-types. Quand les bandes se resserrent (squeeze) = faible volatilité, explosion imminente. Quand le prix touche la bande supérieure = surachat potentiel. Bande inférieure = survente potentielle.",
    readTime: 7,
    complexity: 3,
    popular: true,
    shortDesc: "Indicateur de volatilité qui crée un canal dynamique autour du prix basé sur l'écart-type.",
    fullDesc: "Les Bandes de Bollinger se composent de trois lignes : bande médiane (SMA 20), bande supérieure (SMA 20 + 2σ) et bande inférieure (SMA 20 - 2σ). Elles s'élargissent quand la volatilité augmente et se resserrent quand elle diminue. 95% des prix restent à l'intérieur des bandes.",
    howItWorks: "Le squeeze (resserrement) annonce un mouvement explosif. Le prix qui touche la bande supérieure n'est pas forcément un signal de vente en tendance haussière. Le retour vers la SMA 20 est souvent un bon point d'entrée.",
    interpretation: {
      bullish: "Rebond sur la bande inférieure, squeeze suivi d'une cassure haussière, prix qui marche le long de la bande supérieure.",
      bearish: "Rejet sur la bande supérieure, squeeze suivi d'une cassure baissière, prix qui marche le long de la bande inférieure.",
      range: "Le prix oscille entre les bandes — acheter sur la bande inférieure, vendre sur la supérieure.",
      divergence: "Le prix touche la bande supérieure mais le RSI ne confirme pas le surachat → signal de force.",
    },
    multiTimeframe: "SMA 20 / 2σ standard. Daily pour le swing. Weekly pour le long terme. Le squeeze sur le weekly est un signal très puissant.",
    limits: [
      "En tendance forte, le prix peut \"marcher\" le long d'une bande pendant longtemps",
      "Le squeeze ne prédit pas la direction du breakout",
      "Les paramètres (20, 2) ne sont pas optimaux pour tous les actifs",
    ],
    commonMistakes: [
      "Vendre automatiquement quand le prix touche la bande supérieure",
      "Ignorer le squeeze qui est le signal le plus important",
      "Ne pas utiliser d'indicateur directionnel pour déterminer le sens du breakout après un squeeze",
    ],
    combinations: [
      "RSI pour confirmer les zones de surachat/survente aux bandes",
      "Keltner Channels pour le Bollinger/Keltner Squeeze (signal premium)",
      "Volume pour confirmer les breakouts après un squeeze",
    ],
    practicalCase: "Exemple Tesla (TSLA), 2023 : Un squeeze majeur (bandes les plus serrées en 6 mois) s'est formé en mai 2023. Le breakout haussier qui a suivi, confirmé par un volume élevé, a mené à un rallye de +40% en 6 semaines.",
    relatedIndicators: ["RSI", "Keltner Channels", "ATR"],
  },
  {
    id: "atr",
    name: "ATR",
    nameFr: "ATR (Average True Range)",
    category: "volatilite",
    level: "debutant",
    image: IMG.atrRayner,
    secondaryImage: IMG.atrIg,
    chartReadingGuide: "Sur le graphique : la ligne ATR monte quand la volatilité augmente et descend quand elle diminue. L'ATR ne donne PAS de direction — il mesure uniquement l'amplitude des mouvements. Un ATR élevé = grandes bougies, marché nerveux. Un ATR bas = petites bougies, marché calme. Utile pour dimensionner les stop-loss.",
    readTime: 5,
    complexity: 3,
    popular: true,
    shortDesc: "Mesure la volatilité moyenne — essentiel pour placer les stop-loss et dimensionner les positions.",
    fullDesc: "L'ATR mesure la volatilité moyenne sur 14 périodes. Le True Range est le plus grand des trois : (High - Low), |High - Close précédent|, |Low - Close précédent|. L'ATR est la moyenne mobile de ces True Ranges.",
    howItWorks: "ATR élevé = marché volatile. ATR faible = marché calme. Utilisé pour : 1) Stop-loss (2× ATR), 2) Position sizing (risque fixe / ATR), 3) Identifier les breakouts (mouvement > 1.5× ATR).",
    interpretation: {
      bullish: "ATR en expansion après compression (breakout imminent). ATR élevé en début de tendance haussière.",
      bearish: "ATR en expansion avec prix en baisse (panique). ATR très élevé = climax de volatilité possible.",
      range: "ATR faible et stable = marché calme, range étroit.",
      divergence: "ATR qui se compresse alors que le prix fait de petits mouvements → explosion imminente.",
    },
    multiTimeframe: "ATR 14 daily = standard. ATR weekly pour le position sizing long terme. Ajuster les stops selon le timeframe.",
    limits: [
      "Ne donne pas de direction — seulement la volatilité",
      "L'ATR peut rester élevé longtemps après un choc",
      "Les gaps faussent le calcul du True Range",
    ],
    commonMistakes: [
      "Placer des stops trop serrés (< 1 ATR) qui sont touchés par le bruit normal",
      "Ignorer l'ATR pour le position sizing — risquer le même montant sur un actif volatile et un actif calme",
      "Confondre ATR élevé avec direction (l'ATR monte aussi bien en hausse qu'en baisse)",
    ],
    combinations: [
      "SuperTrend qui utilise l'ATR pour ses bandes",
      "Bollinger Bands pour une double mesure de la volatilité",
      "Position sizing : risque fixe / (ATR × multiplicateur) = taille de position",
    ],
    practicalCase: "Exemple : L'ATR 14 de l'or (GLD) était de 2.50$ en janvier 2023. Un stop-loss à 2× ATR (5$) aurait protégé contre le bruit normal tout en laissant la position respirer. Les traders qui ont utilisé l'ATR pour dimensionner leurs positions ont mieux géré le risque pendant la hausse de +15% qui a suivi.",
    relatedIndicators: ["Bollinger Bands", "SuperTrend", "Parabolic SAR"],
  },
  {
    id: "keltner-channels",
    name: "Keltner Channels",
    nameFr: "Canaux de Keltner",
    category: "volatilite",
    level: "intermediaire",
    image: IMG.keltnerChannel,
    secondaryImage: IMG.channelsComparison,
    chartReadingGuide: "Sur le graphique : les 3 lignes forment un canal similaire aux Bollinger. La différence : Keltner utilise l'ATR (volatilité réelle) au lieu de l'écart-type. Le canal est donc plus lisse et moins réactif aux pics de volatilité. Prix au-dessus de la bande supérieure = forte tendance haussière. Utilisé avec Bollinger pour détecter les squeezes.",
    readTime: 5,
    complexity: 3,
    shortDesc: "Canal de volatilité basé sur l'ATR autour d'une EMA — plus lisse que les Bandes de Bollinger.",
    fullDesc: "Les Canaux de Keltner utilisent une EMA 20 comme ligne centrale avec des bandes à ±2× ATR. Contrairement aux Bollinger Bands qui utilisent l'écart-type, les Keltner utilisent l'ATR, ce qui produit des canaux plus lisses et moins réactifs aux mouvements brusques.",
    howItWorks: "Le prix au-dessus de la bande supérieure = momentum haussier fort. En dessous de la bande inférieure = momentum baissier fort. Le Bollinger/Keltner Squeeze se produit quand les Bollinger Bands passent à l'intérieur des Keltner Channels — signal de compression extrême.",
    interpretation: {
      bullish: "Prix casse au-dessus de la bande supérieure Keltner. Bollinger Squeeze suivi d'un breakout haussier.",
      bearish: "Prix casse en dessous de la bande inférieure. Bollinger Squeeze suivi d'un breakout baissier.",
      range: "Prix oscille entre les bandes. Le Squeeze (Bollinger dans Keltner) annonce un breakout imminent.",
      divergence: "Le prix touche la bande mais le RSI ne confirme pas → signal de force ou de faiblesse.",
    },
    multiTimeframe: "EMA 20 / ATR 10 / multiplicateur 2 standard. Daily pour le swing. Le Squeeze est plus fiable sur le weekly.",
    limits: ["Plus lisse que Bollinger = moins réactif aux changements rapides", "Le Squeeze ne prédit pas la direction du breakout", "Moins connu que Bollinger, donc moins suivi"],
    commonMistakes: ["Confondre avec les Bollinger Bands — les Keltner sont basés sur l'ATR, pas l'écart-type", "Ignorer le Bollinger/Keltner Squeeze qui est le signal premium", "Utiliser les Keltner seuls sans indicateur directionnel"],
    combinations: ["Bollinger Bands pour le Squeeze (signal premium)", "MACD pour la direction du breakout après le Squeeze", "Volume pour confirmer les cassures"],
    practicalCase: "Exemple QQQ, 2023 : Un Bollinger/Keltner Squeeze s'est formé en avril 2023. Le breakout haussier confirmé par le MACD a précédé un rallye de +20% en 3 mois.",
    relatedIndicators: ["Bollinger Bands", "ATR", "Donchian Channels"],
  },
  {
    id: "donchian-channels",
    name: "Donchian Channels",
    nameFr: "Canaux de Donchian",
    category: "volatilite",
    level: "intermediaire",
    image: IMG.donchian,
    readTime: 5,
    complexity: 2,
    shortDesc: "Canal basé sur le plus haut et le plus bas de N périodes — à la base du système Turtle Trading.",
    fullDesc: "Les Canaux de Donchian tracent le plus haut et le plus bas des 20 dernières périodes. La ligne médiane est la moyenne des deux. C'est l'indicateur utilisé par les célèbres Turtle Traders de Richard Dennis dans les années 1980.",
    howItWorks: "Cassure au-dessus de la bande supérieure = signal haussier (nouveau plus haut de 20 jours). Cassure en dessous = signal baissier. La largeur du canal mesure la volatilité.",
    interpretation: {
      bullish: "Prix casse au-dessus du canal (nouveau plus haut de 20 jours). Canal qui s'élargit vers le haut.",
      bearish: "Prix casse en dessous du canal (nouveau plus bas de 20 jours). Canal qui s'élargit vers le bas.",
      range: "Canal étroit et horizontal. Le prix oscille entre les bandes.",
      divergence: "Le prix touche la bande supérieure mais ne la casse pas → essoufflement.",
    },
    multiTimeframe: "20 périodes standard (Turtle Trading). 55 périodes pour le long terme. Daily pour le swing.",
    limits: ["Très simple — ne capture pas les nuances de la volatilité", "Les faux breakouts sont fréquents en range", "Pas de pondération — le plus haut/bas de 20 jours a le même poids que le plus récent"],
    commonMistakes: ["Suivre tous les breakouts sans filtre — beaucoup sont faux", "Ignorer le contexte de tendance", "Utiliser une période trop courte qui génère trop de signaux"],
    combinations: ["ADX pour filtrer les breakouts (ADX > 25 = breakout plus fiable)", "ATR pour le position sizing et les stop-loss", "Volume pour confirmer les cassures"],
    practicalCase: "Exemple : Le système Turtle Trading original utilisait un breakout du canal 20 jours pour entrer et un breakout du canal 10 jours dans le sens opposé pour sortir. Ce système a généré des rendements exceptionnels dans les années 1980.",
    relatedIndicators: ["Keltner Channels", "Bollinger Bands", "ATR"],
  },
  {
    id: "vix",
    name: "VIX",
    nameFr: "VIX (Indice de Volatilité CBOE)",
    category: "volatilite",
    level: "intermediaire",
    image: IMG.vix,
    secondaryImage: IMG.atr,
    chartReadingGuide: "Sur le graphique : la ligne VIX monte quand la peur augmente (marché en baisse) et descend quand le calme revient. VIX < 15 = complaisance. VIX 15-20 = normal. VIX 20-30 = stress. VIX > 30 = panique. Le VIX est inversement corrélé au S&P 500. Les pics de VIX marquent souvent des creux de marché (signal contrarian).",
    readTime: 6,
    complexity: 3,
    popular: true,
    shortDesc: "L'indice de la peur — mesure la volatilité implicite attendue du S&P 500 sur 30 jours.",
    fullDesc: "Le VIX est calculé à partir des prix des options sur le S&P 500. Il mesure la volatilité implicite attendue sur les 30 prochains jours. Un VIX élevé signifie que les investisseurs anticipent de grands mouvements (peur). Un VIX bas signifie complaisance.",
    howItWorks: "VIX < 15 = marché calme (complaisance). VIX 15-20 = volatilité normale. VIX 20-30 = stress élevé. VIX > 30 = panique. Le VIX est inversement corrélé au S&P 500 — il monte quand le marché baisse.",
    interpretation: {
      bullish: "VIX en baisse depuis un pic = la peur se dissipe. VIX < 15 = marché calme (mais attention à la complaisance).",
      bearish: "VIX en forte hausse = panique. VIX > 30 = stress extrême.",
      range: "VIX stable entre 15-20 = volatilité normale, marché sans conviction forte.",
      divergence: "S&P 500 fait de nouveaux sommets mais VIX monte = les investisseurs achètent de la protection → prudence.",
    },
    multiTimeframe: "VIX daily pour le sentiment court terme. VIX weekly pour la tendance de la volatilité. La moyenne historique du VIX est environ 19-20.",
    limits: ["Le VIX mesure la volatilité ATTENDUE, pas la volatilité réalisée", "Un VIX bas ne signifie pas que le marché ne peut pas baisser", "Le VIX est spécifique au S&P 500 — il existe d'autres indices de volatilité"],
    commonMistakes: ["Penser qu'un VIX élevé = signal d'achat automatique", "Ignorer la structure à terme du VIX (contango vs backwardation)", "Confondre volatilité implicite et réalisée"],
    combinations: ["Put/Call Ratio pour confirmer le sentiment", "S&P 500 pour la corrélation inverse", "VVIX (volatilité du VIX) pour les extrêmes"],
    practicalCase: "Exemple : Le VIX a atteint 37 en mars 2023 lors de la crise bancaire (SVB). Ce pic de peur a marqué un creux de marché — le S&P 500 a rebondi de +20% dans les 6 mois suivants. Historiquement, les pics de VIX > 30 sont souvent suivis de rebonds.",
    keyLevels: ["< 15 — Complaisance", "15-20 — Normal", "20-30 — Stress élevé", "> 30 — Panique", "> 40 — Panique extrême (rare)"],
    relatedIndicators: ["ATR", "Bollinger Bands", "Put/Call Ratio"],
  },
  {
    id: "historical-volatility",
    name: "Historical Volatility",
    nameFr: "Volatilité Historique (HV)",
    category: "volatilite",
    level: "avance",
    image: IMG.historicalVolatility,
    secondaryImage: IMG.atr,
    chartReadingGuide: "Sur le graphique : la ligne HV monte quand les mouvements de prix récents sont amples et descend quand ils sont faibles. Contrairement au VIX (volatilité implicite/attendue), la HV mesure ce qui s'est RÉELLEMENT passé. Comparer HV et IV : si IV > HV, les options sont chères. Si IV < HV, elles sont bon marché. La HV 20 jours est la plus utilisée pour le court terme.",
    readTime: 6,
    complexity: 4,
    shortDesc: "Mesure la volatilité réalisée du prix sur une période passée — base de comparaison avec la volatilité implicite.",
    fullDesc: "La volatilité historique (HV) calcule l'écart-type annualisé des rendements logarithmiques sur N périodes. Elle mesure ce qui s'est RÉELLEMENT passé, contrairement à la volatilité implicite qui mesure ce qui est ATTENDU. La comparaison HV vs IV est un outil puissant.",
    howItWorks: "HV 20 jours = volatilité court terme réalisée. HV 60 jours = moyen terme. Si IV > HV, les options sont relativement chères. Si IV < HV, elles sont relativement bon marché.",
    interpretation: {
      bullish: "HV en baisse = marché qui se calme. HV basse + IV basse = conditions calmes pour les tendances.",
      bearish: "HV en forte hausse = marché agité. HV élevée = mouvements importants en cours.",
      range: "HV stable et basse = marché en range calme.",
      divergence: "IV >> HV = les traders d'options anticipent plus de volatilité que ce qui se réalise.",
    },
    multiTimeframe: "HV 20 jours pour le court terme. HV 60 jours pour le moyen terme. HV 252 jours pour l'annuel.",
    limits: ["Regarde le passé — ne prédit pas l'avenir", "Sensible à la période choisie", "Les événements ponctuels (earnings, gaps) faussent le calcul"],
    commonMistakes: ["Confondre volatilité historique et implicite", "Utiliser une seule période sans comparer", "Ignorer le contexte (earnings, événements) qui explique les pics"],
    combinations: ["VIX pour comparer avec la volatilité implicite", "ATR pour une mesure complémentaire", "Bollinger Bands qui utilisent l'écart-type (lié à la HV)"],
    practicalCase: "Exemple : En janvier 2023, la HV 20 jours du S&P 500 était de 15% tandis que le VIX (IV) était à 20%. L'écart IV-HV de 5 points suggérait que les options étaient relativement chères — les traders d'options auraient pu envisager des stratégies de vente de volatilité.",
    relatedIndicators: ["VIX", "ATR", "Bollinger Bands"],
  },
  {
    id: "chaikin-volatility",
    name: "Chaikin Volatility",
    nameFr: "Volatilité de Chaikin",
    category: "volatilite",
    level: "avance",
    image: IMG.chaikinVolatility,
    secondaryImage: IMG.atr,
    chartReadingGuide: "Sur le graphique : la ligne Chaikin Volatility mesure le TAUX DE VARIATION de la volatilité, pas son niveau absolu. En hausse = la volatilité s'accélère (souvent en fin de tendance ou début de panique). En baisse = la volatilité se calme (consolidation). Un pic suivi d'une baisse rapide = la panique se dissipe, retournement possible.",
    readTime: 5,
    complexity: 4,
    shortDesc: "Mesure le taux de variation de l'ATR — identifie les accélérations et décélérations de la volatilité.",
    fullDesc: "La Volatilité de Chaikin mesure le pourcentage de variation de l'EMA du range (High-Low) sur 10 périodes. Elle identifie les moments où la volatilité s'accélère ou décélère, ce qui peut précéder des retournements.",
    howItWorks: "Chaikin Volatility en hausse = la volatilité s'accélère (souvent en fin de tendance ou début de panique). En baisse = la volatilité se calme (consolidation ou début de nouvelle tendance).",
    interpretation: {
      bullish: "Chaikin Vol. qui baisse après un pic = la panique se dissipe, retournement possible.",
      bearish: "Chaikin Vol. qui monte fortement = panique en cours, vente forcée possible.",
      range: "Chaikin Vol. stable et basse = marché calme.",
      divergence: "Prix fait de nouveaux sommets mais Chaikin Vol. monte = instabilité croissante.",
    },
    multiTimeframe: "10 périodes standard. Daily pour le swing. Weekly pour les tendances de volatilité long terme.",
    limits: ["Moins connu et moins utilisé que l'ATR ou le VIX", "Peut donner des signaux ambigus", "La période de 10 n'est pas optimale pour tous les actifs"],
    commonMistakes: ["Confondre avec l'ATR — Chaikin mesure le CHANGEMENT de volatilité, pas son niveau", "Utiliser seul sans contexte de prix", "Ignorer que la hausse de volatilité peut accompagner aussi bien les hausses que les baisses"],
    combinations: ["ATR pour le niveau absolu de volatilité", "VIX pour le sentiment de marché", "RSI pour les zones extrêmes"],
    practicalCase: "Exemple : La Volatilité de Chaikin du Nasdaq a atteint un pic en mars 2023 (crise SVB) puis a rapidement baissé. Cette décélération de la volatilité a coïncidé avec le creux du marché.",
    relatedIndicators: ["ATR", "VIX", "Bollinger Bands"],
  },
  // ──────────── VOLUME (7) ────────────
  {
    id: "volume-analysis",
    name: "Volume Analysis",
    nameFr: "Analyse du Volume",
    category: "volume",
    level: "debutant",
    image: IMG.volumeAnalysis,
    secondaryImage: IMG.volume,
    chartReadingGuide: "Sur le graphique : les barres de volume (en bas) montrent le nombre d'actions échangées. Barres vertes = jour de hausse. Barres rouges = jour de baisse. Volume élevé + hausse = conviction acheteuse. Volume élevé + baisse = conviction vendeuse. Volume faible + hausse = rallèye suspect. Comparez toujours au volume moyen 20 jours (ligne horizontale).",
    readTime: 5,
    complexity: 2,
    popular: true,
    shortDesc: "Le volume confirme ou infirme les mouvements de prix — sans volume, un mouvement est suspect.",
    fullDesc: "Le volume représente le nombre d'actions/contrats échangés sur une période. C'est le carburant du marché. Un mouvement de prix accompagné d'un volume élevé est plus fiable qu'un mouvement avec un volume faible. Le volume précède souvent le prix.",
    howItWorks: "Volume élevé + hausse = conviction acheteuse. Volume élevé + baisse = conviction vendeuse. Volume faible + hausse = rallye suspect. Volume faible + baisse = correction technique normale.",
    interpretation: {
      bullish: "Hausse avec volume croissant. Breakout avec volume > 150% de la moyenne. Volume climax en fin de baisse (capitulation).",
      bearish: "Baisse avec volume croissant. Volume faible sur les rebonds. Distribution (volume élevé sans progression du prix).",
      range: "Volume faible et stable = pas d'intérêt, marché en attente.",
      divergence: "Prix fait de nouveaux sommets mais volume décroissant = divergence baissière volume/prix.",
    },
    multiTimeframe: "Volume daily = standard. Volume weekly pour les tendances. Comparer au volume moyen 20 jours pour contextualiser.",
    limits: ["Le volume seul ne donne pas de direction", "Les marchés forex n'ont pas de volume centralisé fiable", "Le volume peut être faussé par le trading algorithmique"],
    commonMistakes: ["Ignorer le volume — c'est l'erreur la plus courante des débutants", "Analyser le volume en valeur absolue au lieu de le comparer à la moyenne", "Confondre volume élevé avec direction haussière"],
    combinations: ["OBV pour la tendance cumulative du volume", "VWAP pour le prix moyen pondéré par le volume", "RSI pour confirmer les divergences volume/prix"],
    practicalCase: "Exemple Nvidia (NVDA), 2023 : Le breakout au-dessus de 300$ en mai 2023 s'est fait avec un volume 5× supérieur à la moyenne 20 jours. Ce volume exceptionnel a confirmé la conviction et le titre a doublé en 3 mois.",
    relatedIndicators: ["OBV", "VWAP", "Volume Profile"],
  },
  {
    id: "obv",
    name: "OBV",
    nameFr: "OBV (On-Balance Volume)",
    category: "volume",
    level: "debutant",
    image: IMG.obvFidelity,
    secondaryImage: IMG.obvTradingview,
    chartReadingGuide: "Sur le graphique : la ligne OBV monte quand le volume accompagne les hausses de prix et descend quand le volume accompagne les baisses. La direction de l'OBV est plus importante que sa valeur absolue. Si le prix monte mais l'OBV descend = divergence baissière (le volume ne confirme pas). OBV en hausse + prix en hausse = tendance saine.",
    readTime: 5,
    complexity: 2,
    popular: true,
    shortDesc: "Indicateur cumulatif qui additionne le volume les jours de hausse et le soustrait les jours de baisse.",
    fullDesc: "L'OBV additionne le volume total quand le prix clôture en hausse et le soustrait quand il clôture en baisse. La direction de l'OBV est plus importante que sa valeur absolue. Un OBV en hausse avec un prix plat = accumulation (signal haussier).",
    howItWorks: "Si le prix clôture en hausse : OBV = OBV précédent + Volume. Si en baisse : OBV = OBV précédent - Volume. L'OBV qui monte = les acheteurs dominent. L'OBV qui baisse = les vendeurs dominent.",
    interpretation: {
      bullish: "OBV en hausse avec prix en hausse (confirmation). OBV en hausse avec prix plat (accumulation — signal fort).",
      bearish: "OBV en baisse avec prix en baisse (confirmation). OBV en baisse avec prix plat (distribution — signal fort).",
      range: "OBV plat = pas de conviction ni des acheteurs ni des vendeurs.",
      divergence: "Prix fait un nouveau sommet mais OBV ne confirme pas = divergence baissière (distribution cachée).",
    },
    multiTimeframe: "Daily pour le swing. Weekly pour les tendances d'accumulation/distribution long terme.",
    limits: ["Sensible aux gaps qui faussent le calcul", "Ne distingue pas le volume institutionnel du retail", "La valeur absolue n'a pas de signification — seule la direction compte"],
    commonMistakes: ["Regarder la valeur absolue de l'OBV au lieu de sa direction", "Ignorer les divergences OBV/prix qui sont les signaux les plus puissants", "Utiliser l'OBV sur des actifs à faible volume"],
    combinations: ["MACD pour confirmer les divergences", "Supports/Résistances pour les breakouts confirmés par l'OBV", "Volume moyen pour contextualiser"],
    practicalCase: "Exemple Apple (AAPL), 2023 : L'OBV a commencé à monter en janvier 2023 alors que le prix était encore plat — signe d'accumulation institutionnelle. Le breakout haussier est arrivé 3 semaines plus tard, confirmant le signal de l'OBV.",
    relatedIndicators: ["Volume Analysis", "VWAP", "Accumulation/Distribution"],
  },
  {
    id: "vwap",
    name: "VWAP",
    nameFr: "VWAP (Volume Weighted Average Price)",
    category: "volume",
    level: "intermediaire",
    image: IMG.vwapInvestopedia,
    secondaryImage: IMG.vwapExplained,
    chartReadingGuide: "Sur le graphique : la ligne VWAP représente le prix moyen pondéré par le volume de la journée. Prix au-dessus du VWAP = les acheteurs dominent. Prix en dessous = les vendeurs dominent. Le VWAP sert de support/résistance dynamique intraday. Les institutionnels l'utilisent comme benchmark pour leurs exécutions.",
    readTime: 6,
    complexity: 3,
    popular: true,
    shortDesc: "Prix moyen pondéré par le volume — le benchmark des institutionnels pour évaluer la qualité d'exécution.",
    fullDesc: "Le VWAP calcule le prix moyen d'un actif pondéré par le volume échangé à chaque niveau de prix. C'est LE benchmark utilisé par les institutionnels. Un prix au-dessus du VWAP = les acheteurs du jour sont en profit. En dessous = ils sont en perte.",
    howItWorks: "VWAP = Somme(Prix × Volume) / Somme(Volume). Il se réinitialise chaque jour. Le prix au-dessus du VWAP = biais haussier intraday. En dessous = biais baissier. Le VWAP agit comme un aimant — le prix y revient souvent.",
    interpretation: {
      bullish: "Prix au-dessus du VWAP, rebond sur le VWAP en tendance haussière, VWAP en pente ascendante.",
      bearish: "Prix en dessous du VWAP, rejet sur le VWAP en tendance baissière, VWAP en pente descendante.",
      range: "Prix oscille autour du VWAP = marché en équilibre, pas de conviction.",
      divergence: "Non applicable directement — le VWAP est un niveau de référence, pas un oscillateur.",
    },
    multiTimeframe: "Intraday standard (se réinitialise chaque jour). Anchored VWAP = VWAP ancré à un événement spécifique (earnings, gap, etc.) — version avancée très puissante.",
    limits: ["Se réinitialise chaque jour — pas utile pour le swing trading (sauf Anchored VWAP)", "Moins pertinent sur les actifs à faible volume", "Ne fonctionne pas sur le forex (pas de volume centralisé)"],
    commonMistakes: ["Utiliser le VWAP daily pour des décisions swing — il se réinitialise chaque jour", "Ignorer l'Anchored VWAP qui est la version la plus puissante", "Traiter le VWAP comme un indicateur de direction au lieu d'un niveau de référence"],
    combinations: ["Volume Profile pour les niveaux de prix à fort volume", "Supports/Résistances pour les confluences", "RSI pour les entrées aux niveaux VWAP en zone extrême"],
    practicalCase: "Exemple : Les algorithmes institutionnels utilisent le VWAP comme benchmark. Si un fonds achète 1 million d'actions à un prix moyen inférieur au VWAP, l'exécution est considérée comme bonne. Les traders retail peuvent utiliser le VWAP comme support/résistance dynamique intraday.",
    advancedVersion: "L'Anchored VWAP (AVWAP) est ancré à un événement spécifique (earnings, gap, pivot) au lieu de se réinitialiser chaque jour. Il montre le prix moyen pondéré depuis cet événement et agit comme un support/résistance puissant sur le swing et le position trading.",
    relatedIndicators: ["OBV", "Volume Profile", "Volume Analysis"],
  },
  {
    id: "accumulation-distribution",
    name: "Accumulation/Distribution",
    nameFr: "Ligne Accumulation/Distribution (A/D)",
    category: "volume",
    level: "intermediaire",
    image: IMG.accumulationDistribution,
    secondaryImage: IMG.obv,
    chartReadingGuide: "Sur le graphique : la ligne A/D monte quand le volume accompagne les clôtures près du haut du range (accumulation) et descend quand les clôtures sont près du bas (distribution). Contrairement à l'OBV, l'A/D pondère par la position de la clôture dans le range. A/D en hausse + prix plat = accumulation cachée (signal haussier). A/D en baisse + prix en hausse = distribution cachée (danger).",
    readTime: 5,
    complexity: 3,
    shortDesc: "Mesure le flux d'argent en tenant compte de la position de la clôture dans le range du jour.",
    fullDesc: "La ligne A/D est similaire à l'OBV mais plus sophistiquée. Elle pondère le volume par la position de la clôture dans le range High-Low. Si le prix clôture près du haut, la majorité du volume est considérée comme de l'accumulation. Près du bas = distribution.",
    howItWorks: "Money Flow Multiplier = ((Close - Low) - (High - Close)) / (High - Low). A/D = A/D précédent + (MFM × Volume). L'A/D qui monte = accumulation. L'A/D qui baisse = distribution.",
    interpretation: {
      bullish: "A/D en hausse avec prix en hausse (confirmation). A/D en hausse avec prix plat (accumulation cachée).",
      bearish: "A/D en baisse avec prix en baisse (confirmation). A/D en baisse avec prix en hausse (distribution cachée — danger).",
      range: "A/D plat = équilibre entre acheteurs et vendeurs.",
      divergence: "Prix fait un nouveau sommet mais A/D ne confirme pas = distribution cachée (signal baissier puissant).",
    },
    multiTimeframe: "Daily pour le swing. Weekly pour les tendances d'accumulation/distribution long terme.",
    limits: ["Sensible aux gaps", "Ne distingue pas le volume institutionnel du retail", "Peut être trompeur sur les actifs à faible volume"],
    commonMistakes: ["Confondre avec l'OBV — l'A/D pondère par la position de la clôture", "Ignorer les divergences A/D/prix", "Analyser la valeur absolue au lieu de la direction"],
    combinations: ["OBV pour confirmation croisée", "MACD pour les divergences", "Volume pour le contexte"],
    practicalCase: "Exemple : La ligne A/D de Tesla a commencé à baisser en juillet 2023 alors que le prix était encore en hausse — distribution cachée. Le prix a corrigé de -15% dans les semaines suivantes.",
    relatedIndicators: ["OBV", "Money Flow Index", "Chaikin Money Flow"],
  },
  {
    id: "money-flow-index",
    name: "Money Flow Index",
    nameFr: "MFI (Money Flow Index)",
    category: "volume",
    level: "intermediaire",
    image: IMG.moneyFlowIndex,
    secondaryImage: IMG.obv,
    chartReadingGuide: "Sur le graphique : la ligne MFI oscille entre 0 et 100, comme le RSI mais pondéré par le volume. MFI > 80 = surachat avec volume (les acheteurs s'épuisent). MFI < 20 = survente avec volume (les vendeurs s'épuisent). Les divergences MFI/prix sont plus fiables que celles du RSI car elles intègrent la conviction (volume). Le croisement de 50 indique un changement de biais.",
    readTime: 5,
    complexity: 3,
    shortDesc: "RSI pondéré par le volume — combine momentum et flux d'argent pour des signaux plus fiables.",
    fullDesc: "Le MFI est souvent appelé le RSI pondéré par le volume. Il oscille entre 0 et 100 et intègre le volume dans le calcul du momentum. MFI > 80 = surachat avec volume. MFI < 20 = survente avec volume. Les signaux sont plus fiables que le RSI seul car ils intègrent la conviction (volume).",
    howItWorks: "Le MFI calcule le ratio entre le flux d'argent positif et négatif sur 14 périodes. Le flux d'argent = prix typique × volume. Si le prix typique monte, c'est un flux positif. S'il baisse, c'est un flux négatif.",
    interpretation: {
      bullish: "MFI < 20 (survente avec volume). MFI qui remonte depuis la zone de survente.",
      bearish: "MFI > 80 (surachat avec volume). MFI qui redescend depuis la zone de surachat.",
      range: "MFI oscille entre 30 et 70 = pas de conviction extrême.",
      divergence: "Prix fait un nouveau sommet mais MFI fait un sommet plus bas = distribution avec volume décroissant.",
    },
    multiTimeframe: "14 périodes standard. Daily pour le swing. Le MFI est plus fiable que le RSI sur les actions à fort volume.",
    limits: ["Nécessite des données de volume fiables", "Moins utile sur le forex (pas de volume centralisé)", "Les niveaux 80/20 ne sont pas des signaux automatiques"],
    commonMistakes: ["Traiter le MFI exactement comme le RSI — le MFI intègre le volume", "Ignorer les divergences MFI/prix", "Utiliser sur des actifs à faible volume"],
    combinations: ["RSI pour confirmation croisée (momentum pur vs momentum+volume)", "OBV pour la tendance cumulative du volume", "Supports/Résistances pour les entrées"],
    practicalCase: "Exemple : Le MFI de Microsoft est tombé à 15 en octobre 2023 (survente extrême avec volume) tandis que le RSI était à 32 (pas encore en survente). Le MFI a donné un signal plus précoce et plus fiable — le titre a rebondi de +20% en 2 mois.",
    keyLevels: ["80 — Surachat (avec volume)", "50 — Neutre", "20 — Survente (avec volume)"],
    relatedIndicators: ["RSI", "OBV", "Accumulation/Distribution"],
  },
  {
    id: "chaikin-money-flow",
    name: "Chaikin Money Flow",
    nameFr: "CMF (Chaikin Money Flow)",
    category: "volume",
    level: "avance",
    image: IMG.chaikinMoneyFlow,
    secondaryImage: IMG.obv,
    chartReadingGuide: "Sur le graphique : la ligne CMF oscille entre -1 et +1 (mais reste généralement entre -0.3 et +0.3). CMF > 0 = pression acheteuse dominante. CMF < 0 = pression vendeuse dominante. Le croisement de zéro est le signal principal. Plus la valeur est éloignée de zéro, plus la pression est forte. CMF en hausse + prix en hausse = tendance saine.",
    readTime: 5,
    complexity: 4,
    shortDesc: "Mesure la pression d'achat/vente sur 20 périodes en combinant prix et volume.",
    fullDesc: "Le CMF oscille entre -1 et +1. Il mesure la somme du Money Flow Volume sur 20 périodes divisée par la somme du volume. CMF > 0 = pression acheteuse. CMF < 0 = pression vendeuse. Plus la valeur est élevée, plus la pression est forte.",
    howItWorks: "CMF = Somme(MFV sur 20 périodes) / Somme(Volume sur 20 périodes). Le MFV utilise le même multiplicateur que la ligne A/D. Le CMF est une version bornée et temporelle de l'A/D.",
    interpretation: {
      bullish: "CMF > 0 et en hausse = pression acheteuse croissante. CMF qui passe de négatif à positif.",
      bearish: "CMF < 0 et en baisse = pression vendeuse croissante. CMF qui passe de positif à négatif.",
      range: "CMF proche de 0 = équilibre.",
      divergence: "Prix en hausse mais CMF en baisse = la pression acheteuse faiblit malgré la hausse des prix.",
    },
    multiTimeframe: "20 périodes standard. Daily pour le swing.",
    limits: ["Borné entre -1 et +1 — les valeurs extrêmes sont rares", "Sensible à la période choisie", "Peut donner des signaux contradictoires avec l'OBV"],
    commonMistakes: ["Confondre avec l'OBV ou l'A/D — le CMF est borné et temporel", "Ignorer le croisement de zéro qui est le signal principal", "Utiliser sur des actifs à faible volume"],
    combinations: ["OBV pour la tendance long terme du volume", "A/D pour confirmation", "MACD pour les divergences de momentum"],
    practicalCase: "Exemple : Le CMF d'Amazon est passé de -0.15 à +0.20 en février 2023, signalant un retournement de la pression de volume. Le titre a progressé de +30% dans les 4 mois suivants.",
    relatedIndicators: ["Accumulation/Distribution", "OBV", "Money Flow Index"],
  },
  {
    id: "volume-profile",
    name: "Volume Profile",
    nameFr: "Profil de Volume (Volume Profile)",
    category: "volume",
    level: "avance",
    image: IMG.volumeProfile,
    secondaryImage: IMG.volume,
    chartReadingGuide: "Sur le graphique : un histogramme HORIZONTAL sur le côté gauche montre le volume échangé à chaque niveau de prix. Les barres longues (HVN) = zones de fort intérêt (support/résistance). Les barres courtes (LVN) = zones de faible intérêt (le prix passe vite). Le POC (Point of Control) est la barre la plus longue = prix avec le plus de volume. La Value Area (70% du volume) définit la zone de prix 'juste'.",
    readTime: 8,
    complexity: 5,
    shortDesc: "Affiche le volume échangé à chaque niveau de prix — révèle les zones d'intérêt institutionnel.",
    fullDesc: "Le Volume Profile affiche un histogramme horizontal montrant le volume échangé à chaque niveau de prix sur une période donnée. Le POC (Point of Control) est le prix avec le plus de volume. Les HVN (High Volume Nodes) sont des zones de support/résistance. Les LVN (Low Volume Nodes) sont des zones de faible intérêt où le prix passe rapidement.",
    howItWorks: "Le POC agit comme un aimant — le prix y revient souvent. Les HVN sont des zones de consensus (support/résistance). Les LVN sont des zones de rejet rapide. La Value Area (70% du volume) définit la zone de prix juste.",
    interpretation: {
      bullish: "Prix au-dessus du POC et de la Value Area. Breakout d'une LVN vers le haut avec volume.",
      bearish: "Prix en dessous du POC et de la Value Area. Breakout d'une LVN vers le bas.",
      range: "Prix oscille autour du POC dans la Value Area = marché en équilibre.",
      divergence: "Le prix s'éloigne du POC mais le volume diminue = mouvement non soutenu.",
    },
    multiTimeframe: "Session (intraday), Weekly, Monthly, ou ancré à un événement. Le Volume Profile mensuel est le plus utilisé par les institutionnels.",
    limits: ["Nécessite des données tick ou minute pour être précis", "Complexe à interpréter pour les débutants", "Pas disponible sur toutes les plateformes"],
    commonMistakes: ["Ignorer le POC qui est le niveau le plus important", "Confondre HVN (support/résistance) et LVN (zone de passage rapide)", "Utiliser un Volume Profile sur une période trop courte"],
    combinations: ["VWAP pour confirmation du prix moyen", "Supports/Résistances classiques pour les confluences", "Fibonacci pour les niveaux de retracement dans les LVN"],
    practicalCase: "Exemple : Le Volume Profile mensuel du S&P 500 en 2023 montrait un POC à 4400. Chaque fois que le prix s'éloignait de ce niveau, il y revenait. Les traders qui ont utilisé le POC comme point de référence ont eu un avantage significatif.",
    advancedVersion: "Le Volume Profile Visible Range (VPVR) affiche le volume sur toute la période visible du graphique. Le Fixed Range Volume Profile permet de sélectionner une période spécifique. Le Session Volume Profile se réinitialise chaque jour.",
    relatedIndicators: ["VWAP", "OBV", "Supports/Résistances"],
  },
  // ──────────── PATTERNS (5) ────────────
  {
    id: "support-resistance",
    name: "Support & Resistance",
    nameFr: "Supports et Résistances",
    category: "pattern",
    level: "debutant",
    image: IMG.supportResistanceLevels,
    secondaryImage: IMG.supportResistanceNew,
    chartReadingGuide: "Sur le graphique : les lignes horizontales marquent les niveaux où le prix a rebondi (support) ou été rejeté (résistance) par le passé. Plus un niveau a été testé souvent, plus il est significatif. Quand un support est cassé, il devient souvent une résistance (et vice versa). Les chiffres ronds (100$, 200$) sont des niveaux psychologiques.",
    readTime: 6,
    complexity: 2,
    popular: true,
    shortDesc: "Les niveaux de prix clés où le marché a historiquement réagi — la base de toute analyse technique.",
    fullDesc: "Un support est un niveau de prix où la demande est suffisamment forte pour empêcher le prix de baisser davantage. Une résistance est un niveau où l'offre est suffisamment forte pour empêcher le prix de monter. Ces niveaux sont créés par la mémoire du marché — les traders se souviennent des prix importants.",
    howItWorks: "Plus un niveau a été testé sans être cassé, plus il est fort. Quand un support est cassé, il devient souvent une résistance (et vice versa). Les niveaux ronds (100$, 200$, etc.) ont une importance psychologique.",
    interpretation: {
      bullish: "Rebond sur un support fort. Cassure d'une résistance avec volume. Ancien résistance devenue support (pullback).",
      bearish: "Rejet sur une résistance forte. Cassure d'un support avec volume. Ancien support devenu résistance.",
      range: "Prix oscille entre un support et une résistance clairement définis.",
      divergence: "Le prix teste un support/résistance mais le RSI/MACD diverge → signal de cassure ou de rebond.",
    },
    multiTimeframe: "Les supports/résistances du weekly sont plus forts que ceux du daily. Les niveaux du monthly sont les plus importants. Toujours vérifier le timeframe supérieur.",
    limits: ["Les niveaux sont des zones, pas des lignes exactes", "Subjectif — deux analystes peuvent tracer des niveaux différents", "Les faux breakouts sont fréquents"],
    commonMistakes: ["Tracer trop de niveaux qui rendent le graphique illisible", "Ignorer les niveaux du timeframe supérieur", "Ne pas attendre la confirmation d'un breakout (faux breakouts)"],
    combinations: ["Volume pour confirmer les breakouts", "RSI pour les divergences aux niveaux clés", "Fibonacci pour les niveaux de retracement"],
    practicalCase: "Exemple S&P 500, 2023 : Le niveau 4200 a servi de résistance pendant 6 mois (août 2022 - mai 2023). Quand il a été cassé en mai 2023 avec un volume élevé, il est devenu support. Le pullback vers 4200 en juin a été une opportunité d'entrée classique.",
    relatedIndicators: ["Fibonacci", "Volume Profile", "Pivot Points"],
  },
  {
    id: "fibonacci",
    name: "Fibonacci Retracement",
    nameFr: "Retracements de Fibonacci",
    category: "pattern",
    level: "intermediaire",
    image: IMG.fibonacciFidelity,
    secondaryImage: IMG.fibonacciRetracement,
    chartReadingGuide: "Sur le graphique : les lignes horizontales marquent les niveaux de retracement (23.6%, 38.2%, 50%, 61.8%, 78.6%) entre un point bas et un point haut. Le niveau 61.8% (le 'golden ratio') est le plus surveillé. Quand le prix corrige et rebondit sur un niveau Fibonacci = zone de support potentielle. Le 50% est un niveau psychologique important.",
    readTime: 7,
    complexity: 3,
    popular: true,
    shortDesc: "Niveaux de retracement basés sur la suite de Fibonacci — les plus utilisés pour anticiper les zones de rebond.",
    fullDesc: "Les retracements de Fibonacci tracent des niveaux horizontaux aux ratios clés (23.6%, 38.2%, 50%, 61.8%, 78.6%) entre un point haut et un point bas. Le niveau 61.8% (le nombre d'or) est le plus important. Ces niveaux identifient les zones potentielles de support/résistance pendant les corrections.",
    howItWorks: "Tracer du bas au haut en tendance haussière (ou du haut au bas en tendance baissière). Les niveaux de retracement montrent où le prix pourrait trouver un support pendant une correction. Le 38.2% = correction faible (tendance forte). Le 61.8% = correction profonde.",
    interpretation: {
      bullish: "Rebond sur le 38.2% ou 50% en tendance haussière forte. Rebond sur le 61.8% (dernier rempart).",
      bearish: "Rejet sur le 38.2% ou 50% en tendance baissière. Cassure du 78.6% = invalidation de la tendance.",
      range: "Les niveaux Fibonacci dans un range identifient les zones de pivot internes.",
      divergence: "RSI en divergence haussière au niveau du 61.8% = signal de rebond très fort.",
    },
    multiTimeframe: "Fibonacci sur le weekly = niveaux les plus importants. Daily pour les entrées. Les confluences (même niveau sur deux timeframes) sont très puissantes.",
    limits: ["Subjectif — le choix des points haut/bas impacte les niveaux", "Pas de base scientifique prouvée — fonctionne par prophétie auto-réalisatrice", "Les niveaux ne sont pas des garanties de rebond"],
    commonMistakes: ["Tracer Fibonacci sur des mouvements trop courts", "Ignorer le contexte de tendance", "Utiliser Fibonacci seul sans confirmation (volume, RSI, pattern)"],
    combinations: ["Supports/Résistances pour les confluences (Fib + S/R = zone très forte)", "RSI pour les divergences aux niveaux Fibonacci", "Volume pour confirmer les rebonds"],
    practicalCase: "Exemple Nasdaq (QQQ), 2023 : Le retracement de 38.2% du rallye janvier-juillet 2023 a correspondu exactement au support horizontal à 360$. Cette confluence Fibonacci + S/R a produit un rebond de +15% en 2 mois.",
    keyLevels: ["23.6% — Correction très faible", "38.2% — Correction faible (tendance forte)", "50% — Correction moyenne", "61.8% — Correction profonde (nombre d'or)", "78.6% — Correction très profonde"],
    relatedIndicators: ["Supports/Résistances", "Volume Profile", "Elliott Waves"],
  },
  {
    id: "candlestick-patterns",
    name: "Candlestick Patterns",
    nameFr: "Patterns de Chandeliers Japonais",
    category: "pattern",
    level: "debutant",
    image: IMG.candlestickPatterns,
    secondaryImage: IMG.candlestick,
    chartReadingGuide: "Sur le graphique : chaque bougie montre 4 informations (ouverture, clôture, plus haut, plus bas). Corps vert = clôture > ouverture (haussier). Corps rouge = clôture < ouverture (baissier). Les mèches montrent les extrêmes. Marteau (longue mèche basse) = rejet des vendeurs. Étoile filante (longue mèche haute) = rejet des acheteurs. Englobante = une bougie qui 'avale' la précédente.",
    readTime: 8,
    complexity: 2,
    popular: true,
    shortDesc: "Les formations de bougies qui signalent les retournements et continuations — le langage visuel du marché.",
    fullDesc: "Les chandeliers japonais montrent 4 informations : ouverture, clôture, plus haut, plus bas. Les patterns de bougies (doji, marteau, englobante, étoile du matin/soir) signalent les retournements potentiels. Ils sont plus fiables aux niveaux de support/résistance et avec confirmation de volume.",
    howItWorks: "Patterns de retournement haussier : Marteau, Englobante haussière, Étoile du matin, Doji après baisse. Patterns de retournement baissier : Étoile filante, Englobante baissière, Étoile du soir, Doji après hausse. Patterns de continuation : Trois soldats blancs, Trois corbeaux noirs.",
    interpretation: {
      bullish: "Marteau sur un support avec volume. Englobante haussière après une baisse. Étoile du matin (pattern de 3 bougies).",
      bearish: "Étoile filante sur une résistance. Englobante baissière après une hausse. Étoile du soir.",
      range: "Doji = indécision. Plusieurs dojis consécutifs = le marché hésite avant un mouvement.",
      divergence: "Pattern de retournement + divergence RSI = signal très fort.",
    },
    multiTimeframe: "Les patterns sur le weekly sont les plus fiables. Daily pour les signaux swing. Les patterns intraday sont moins fiables.",
    limits: ["Subjectif — l'identification des patterns n'est pas toujours claire", "Les patterns seuls ne suffisent pas — toujours confirmer", "Moins fiables en intraday qu'en daily/weekly"],
    commonMistakes: ["Trader un pattern sans contexte (support/résistance, tendance)", "Ignorer le volume qui confirme ou infirme le pattern", "Chercher des patterns partout — se concentrer sur les niveaux clés"],
    combinations: ["Supports/Résistances pour le contexte", "Volume pour la confirmation", "RSI pour les divergences aux patterns de retournement"],
    practicalCase: "Exemple : Un marteau (hammer) s'est formé sur le S&P 500 au niveau du support 4200 en octobre 2023, avec un volume supérieur à la moyenne. Ce pattern de retournement haussier au bon endroit a précédé un rallye de +12% en 2 mois.",
    relatedIndicators: ["Supports/Résistances", "Volume Analysis", "RSI"],
  },
  {
    id: "chart-patterns",
    name: "Chart Patterns",
    nameFr: "Figures Chartistes (Tête-Épaules, Triangles, etc.)",
    category: "pattern",
    level: "intermediaire",
    image: IMG.chartPatterns,
    secondaryImage: IMG.supportResistance,
    chartReadingGuide: "Sur le graphique : les figures chartistes sont des formations de prix reconnaissables. Tête-Épaules : 3 sommets dont le central est le plus haut, la cassure de la ligne de cou = signal baissier. Double Top : 2 sommets au même niveau = signal baissier. Triangle ascendant : résistance horizontale + supports ascendants = généralement haussier. Cup & Handle : forme de tasse avec anse = continuation haussière.",
    readTime: 8,
    complexity: 3,
    shortDesc: "Les formations graphiques classiques qui signalent les retournements et continuations de tendance.",
    fullDesc: "Les figures chartistes sont des formations de prix reconnaissables : Tête-Épaules (retournement), Double Top/Bottom (retournement), Triangles (continuation ou retournement), Drapeaux/Fanions (continuation), Cup & Handle (continuation haussière). Chaque figure a un objectif de prix théorique.",
    howItWorks: "Tête-Épaules : 3 sommets dont le central est le plus haut. La cassure de la ligne de cou = signal baissier. Objectif = hauteur de la tête projetée sous la ligne de cou. Double Top : 2 sommets au même niveau. Cassure du creux intermédiaire = signal baissier.",
    interpretation: {
      bullish: "Tête-Épaules inversée, Double Bottom, Triangle ascendant, Cup & Handle, Drapeau haussier.",
      bearish: "Tête-Épaules, Double Top, Triangle descendant, Drapeau baissier.",
      range: "Triangle symétrique = indécision. Rectangle = range défini.",
      divergence: "Figure de retournement + divergence RSI/MACD = confirmation puissante.",
    },
    multiTimeframe: "Les figures sur le weekly sont les plus fiables et ont les objectifs les plus grands. Daily pour les figures swing.",
    limits: ["Subjectif — l'identification est un art, pas une science", "Les objectifs de prix sont théoriques, pas garantis", "Les faux breakouts sont fréquents"],
    commonMistakes: ["Voir des figures partout (biais de confirmation)", "Entrer avant la cassure confirmée", "Ignorer le volume qui doit confirmer le breakout"],
    combinations: ["Volume pour confirmer les breakouts", "Fibonacci pour les objectifs de prix", "RSI/MACD pour les divergences de confirmation"],
    practicalCase: "Exemple : Un Cup & Handle s'est formé sur Microsoft (MSFT) entre mars et juin 2023. La cassure du handle avec volume a donné un objectif à +15% qui a été atteint en 2 mois.",
    relatedIndicators: ["Supports/Résistances", "Fibonacci", "Volume Analysis"],
  },
  {
    id: "pivot-points",
    name: "Pivot Points",
    nameFr: "Points Pivots",
    category: "pattern",
    level: "intermediaire",
    image: IMG.pivotPoints,
    secondaryImage: IMG.supportResistance,
    chartReadingGuide: "Sur le graphique : des lignes horizontales marquées P (pivot central), R1/R2/R3 (résistances) et S1/S2/S3 (supports). Le pivot central = niveau d'équilibre. Prix au-dessus du pivot = biais haussier. En dessous = biais baissier. R1/S1 = premiers objectifs. R2/S2 = objectifs étendus. Les pivots se recalculent chaque période (jour, semaine, mois).",
    readTime: 5,
    complexity: 2,
    shortDesc: "Niveaux de support/résistance calculés mathématiquement à partir des données de la veille.",
    fullDesc: "Les Points Pivots calculent des niveaux de support (S1, S2, S3) et de résistance (R1, R2, R3) à partir du High, Low et Close de la période précédente. Pivot = (H + L + C) / 3. Très utilisés par les traders intraday et les market makers.",
    howItWorks: "Le pivot central est le niveau d'équilibre. Au-dessus = biais haussier. En dessous = biais baissier. R1/S1 = premiers objectifs. R2/S2 = objectifs étendus. R3/S3 = extrêmes.",
    interpretation: {
      bullish: "Prix au-dessus du pivot, rebond sur S1, cassure de R1 avec volume.",
      bearish: "Prix en dessous du pivot, rejet sur R1, cassure de S1 avec volume.",
      range: "Prix oscille entre S1 et R1 autour du pivot = marché en équilibre.",
      divergence: "Non applicable directement — les pivots sont des niveaux statiques.",
    },
    multiTimeframe: "Pivots daily pour l'intraday. Pivots weekly pour le swing. Pivots monthly pour le position trading.",
    limits: ["Se réinitialisent chaque période", "Moins utiles en tendance forte (le prix peut dépasser tous les niveaux)", "Plusieurs méthodes de calcul (Standard, Fibonacci, Camarilla) donnent des résultats différents"],
    commonMistakes: ["Utiliser les pivots seuls sans contexte de tendance", "Ignorer le volume aux niveaux pivots", "Confondre les différentes méthodes de calcul"],
    combinations: ["VWAP pour confirmation intraday", "Fibonacci pour les confluences", "Volume pour confirmer les réactions aux niveaux"],
    practicalCase: "Exemple : Les pivots mensuels du S&P 500 ont servi de niveaux de référence précis en 2023. Le pivot mensuel de novembre (4400) a été testé 3 fois avant de servir de tremplin pour le rallye de fin d'année.",
    relatedIndicators: ["Supports/Résistances", "Fibonacci", "VWAP"],
  },
  // ──────────── STRUCTURE DE MARCHÉ (5) ────────────
  {
    id: "elliott-waves",
    name: "Elliott Wave Theory",
    nameFr: "Théorie des Vagues d'Elliott",
    category: "pattern",
    level: "avance",
    image: IMG.elliottWaves,
    secondaryImage: IMG.fibonacci,
    chartReadingGuide: "Sur le graphique : les vagues d'Elliott forment un cycle de 5 vagues impulsives (1-2-3-4-5) dans la direction de la tendance, suivies de 3 vagues correctives (A-B-C). Vague 3 est généralement la plus longue et la plus forte. Vague 2 ne retrace jamais 100% de la vague 1. Vague 4 ne chevauche jamais le sommet de la vague 1. Les niveaux de Fibonacci définissent les objectifs de chaque vague.",
    readTime: 10,
    complexity: 5,
    shortDesc: "Théorie selon laquelle les marchés évoluent en cycles de 5 vagues impulsives et 3 vagues correctives.",
    fullDesc: "La théorie d'Elliott postule que les marchés suivent des patterns fractals de 5 vagues dans la direction de la tendance (impulsives) et 3 vagues contre la tendance (correctives). Chaque vague contient des sous-vagues, créant une structure fractale. Les vagues 1, 3, 5 sont impulsives, les vagues 2 et 4 sont correctives.",
    howItWorks: "Vague 1 : début de tendance. Vague 2 : correction (ne dépasse pas le début de V1). Vague 3 : la plus forte (jamais la plus courte). Vague 4 : correction (ne chevauche pas V1). Vague 5 : dernière impulsion. Puis ABC correctif.",
    interpretation: {
      bullish: "Début de Vague 3 (la plus puissante). Fin de Vague C (fin de correction).",
      bearish: "Fin de Vague 5 (épuisement). Début de correction ABC.",
      range: "Vague 4 ou Vague B = corrections complexes, souvent en range.",
      divergence: "Vague 5 avec divergence RSI = signal classique de fin de tendance.",
    },
    multiTimeframe: "Les vagues existent sur tous les timeframes — du tick au mensuel. Les vagues du weekly/monthly définissent le contexte principal.",
    limits: ["Très subjectif — le comptage des vagues est un art", "Plusieurs comptages possibles simultanément", "Difficile à appliquer en temps réel"],
    commonMistakes: ["Forcer un comptage pour confirmer un biais", "Ignorer les règles strictes (V2 ne dépasse pas V1, V3 jamais la plus courte)", "Utiliser Elliott seul sans confirmation"],
    combinations: ["Fibonacci pour les objectifs de vagues (V3 = 1.618× V1, V5 = V1)", "RSI pour les divergences en fin de V5", "Volume pour confirmer les vagues impulsives"],
    practicalCase: "Exemple S&P 500, 2022-2023 : La baisse de 2022 peut être comptée comme une correction ABC. La Vague C s'est terminée en octobre 2022 au niveau du retracement 38.2% Fibonacci du rallye 2020-2022. Le rallye de 2023 serait le début d'un nouveau cycle impulsif.",
    relatedIndicators: ["Fibonacci", "RSI", "Volume Analysis"],
  },
  {
    id: "market-breadth",
    name: "Market Breadth",
    nameFr: "Largeur de Marché (Advance/Decline)",
    category: "structure",
    level: "intermediaire",
    image: IMG.marketBreadth,
    secondaryImage: IMG.adx,
    chartReadingGuide: "Sur le graphique : la ligne A/D (Advance/Decline) monte quand plus d'actions montent que baissent. Elle baisse dans le cas contraire. Comparez-la au S&P 500 : si l'indice monte mais la ligne A/D baisse = divergence négative (le rallèye est porté par peu de titres, fragile). Si les deux montent ensemble = marché sain. Le % d'actions au-dessus de leur MA 200 est un autre indicateur de largeur clé.",
    readTime: 6,
    complexity: 3,
    shortDesc: "Mesure combien d'actions participent au mouvement — un rallye sain est un rallye large.",
    fullDesc: "La largeur de marché mesure le nombre d'actions en hausse vs en baisse. La ligne Advance/Decline (A/D Line) cumule la différence quotidienne. Un marché sain voit la majorité des actions participer au mouvement. Un rallye porté par quelques mega-caps avec une A/D Line en baisse est fragile.",
    howItWorks: "A/D Line = cumul de (Avancées - Déclins). Si le S&P 500 monte mais l'A/D Line baisse = divergence négative (le rallye est étroit). Le % d'actions au-dessus de leur MA 200 est un autre indicateur de largeur.",
    interpretation: {
      bullish: "A/D Line en hausse avec l'indice. >70% des actions au-dessus de leur MA 200.",
      bearish: "A/D Line en baisse alors que l'indice monte (divergence). <30% des actions au-dessus de leur MA 200.",
      range: "A/D Line plate = marché sans conviction.",
      divergence: "Indice fait un nouveau sommet mais A/D Line ne confirme pas = rallye fragile (signal classique de sommet).",
    },
    multiTimeframe: "A/D Line daily pour le court terme. % au-dessus de MA 200 pour le long terme.",
    limits: ["Spécifique aux indices (pas applicable aux actifs individuels)", "Peut diverger longtemps avant qu'un retournement se produise", "Les mega-caps peuvent masquer la faiblesse de la largeur"],
    commonMistakes: ["Ignorer la largeur de marché et se concentrer uniquement sur l'indice", "Penser qu'une divergence = signal immédiat de retournement", "Confondre A/D Line avec la ligne Accumulation/Distribution"],
    combinations: ["VIX pour le sentiment", "% au-dessus de MA 50/200 pour la confirmation", "RSI de l'indice pour les divergences"],
    practicalCase: "Exemple 2023 : Le S&P 500 a atteint de nouveaux sommets en juillet 2023, mais seulement 30% des composants étaient au-dessus de leur MA 200 (les Magnificent 7 portaient l'indice). Cette divergence de largeur a précédé une correction de -10% en août-octobre.",
    relatedIndicators: ["VIX", "Put/Call Ratio", "New Highs/New Lows"],
  },
  {
    id: "new-highs-lows",
    name: "New Highs/Lows",
    nameFr: "Nouveaux Plus Hauts / Plus Bas",
    category: "structure",
    level: "intermediaire",
    image: IMG.newHighsLows,
    secondaryImage: IMG.adx,
    chartReadingGuide: "Sur le graphique : un histogramme montre le nombre d'actions atteignant de nouveaux plus hauts 52 semaines (vert) vs nouveaux plus bas (rouge). Un marché sain montre beaucoup de nouveaux highs et peu de nouveaux lows. Si l'indice monte mais les nouveaux highs diminuent = divergence dangereuse. Le ratio NH/(NH+NL) > 0.7 = marché très fort. < 0.3 = marché très faible.",
    readTime: 5,
    complexity: 3,
    shortDesc: "Compte le nombre d'actions atteignant de nouveaux sommets ou creux sur 52 semaines.",
    fullDesc: "Cet indicateur compte quotidiennement combien d'actions font un nouveau plus haut ou plus bas sur 52 semaines. Un marché sain produit beaucoup de nouveaux plus hauts et peu de nouveaux plus bas. Le ratio NH/NL et la différence nette sont les métriques clés.",
    howItWorks: "NH-NL > 0 = plus d'actions font des sommets que des creux (haussier). NH-NL < 0 = l'inverse (baissier). Un indice qui monte avec peu de nouveaux plus hauts = rallye fragile.",
    interpretation: {
      bullish: "Nombre élevé de nouveaux plus hauts. NH-NL nettement positif.",
      bearish: "Nombre élevé de nouveaux plus bas. NH-NL nettement négatif.",
      range: "NH et NL tous deux faibles = marché sans conviction.",
      divergence: "Indice en hausse mais nouveaux plus hauts en baisse = divergence classique de sommet.",
    },
    multiTimeframe: "Données quotidiennes. Moyenne mobile 10 jours pour lisser le bruit.",
    limits: ["Données disponibles uniquement pour les indices majeurs", "Sensible aux conditions de marché extrêmes", "Le seuil 52 semaines est arbitraire"],
    commonMistakes: ["Ignorer cet indicateur qui est l'un des meilleurs indicateurs de structure", "Regarder les chiffres absolus au lieu du ratio", "Ne pas lisser avec une moyenne mobile"],
    combinations: ["A/D Line pour confirmation de la largeur", "VIX pour le sentiment", "% au-dessus de MA 200 pour le contexte"],
    practicalCase: "Exemple : En décembre 2023, le NYSE a enregistré plus de 400 nouveaux plus hauts sur 52 semaines en une seule journée — un signal de largeur extrêmement haussier qui a confirmé le rallye de fin d'année.",
    relatedIndicators: ["Market Breadth", "VIX", "Advance/Decline"],
  },
  {
    id: "sector-rotation",
    name: "Sector Rotation",
    nameFr: "Rotation Sectorielle",
    category: "structure",
    level: "avance",
    image: IMG.sectorRotation,
    secondaryImage: IMG.adx,
    chartReadingGuide: "Sur le graphique : le modèle de rotation sectorielle montre un cycle : Expansion (Tech, Consommation discrétionnaire) → Pic (Industrie, Matériaux) → Contraction (Santé, Utilities, Consommation de base) → Creux (Énergie, Finance). Identifiez quels secteurs surperforment pour déterminer où on est dans le cycle. La performance relative sectorielle (RRG) est l'outil de visualisation le plus utilisé.",
    readTime: 7,
    complexity: 4,
    shortDesc: "Analyse des flux entre secteurs pour identifier la phase du cycle économique.",
    fullDesc: "La rotation sectorielle observe quels secteurs surperforment et sous-performent pour identifier la phase du cycle économique. En expansion : tech, consommation discrétionnaire. En ralentissement : énergie, matériaux. En récession : utilities, santé, consommation de base. En reprise : financières, industrielles.",
    howItWorks: "Comparer la performance relative des 11 secteurs GICS par rapport au S&P 500. Les secteurs qui surperforment indiquent la phase du cycle. Le Relative Rotation Graph (RRG) est l'outil visuel le plus efficace.",
    interpretation: {
      bullish: "Rotation vers les secteurs cycliques (tech, conso. discrétionnaire, financières) = expansion.",
      bearish: "Rotation vers les secteurs défensifs (utilities, santé, conso. de base) = ralentissement/récession.",
      range: "Pas de rotation claire = marché en transition entre phases.",
      divergence: "L'indice monte mais la rotation va vers les défensifs = signal de prudence.",
    },
    multiTimeframe: "Performance relative sur 1 mois, 3 mois, 6 mois. Le RRG utilise typiquement 10-14 semaines.",
    limits: ["Le cycle n'est pas toujours linéaire", "Les rotations peuvent être temporaires", "Les secteurs ne réagissent pas tous en même temps"],
    commonMistakes: ["Appliquer le modèle de rotation de manière rigide", "Ignorer les facteurs spécifiques à chaque cycle", "Confondre rotation sectorielle et stock picking"],
    combinations: ["Courbe des taux pour confirmer la phase du cycle", "ISM Manufacturing pour les données macro", "VIX pour le sentiment"],
    practicalCase: "Exemple 2023 : La rotation massive vers la tech (IA) en H1 2023 puis l'élargissement vers les financières et industrielles en H2 a signalé le passage d'un rallye étroit à un rallye plus large — signe de santé du marché.",
    relatedIndicators: ["Market Breadth", "Relative Strength", "Yield Curve"],
  },
  {
    id: "intermarket-analysis",
    name: "Intermarket Analysis",
    nameFr: "Analyse Intermarché",
    category: "structure",
    level: "avance",
    image: IMG.intermarketAnalysis,
    secondaryImage: IMG.adx,
    chartReadingGuide: "Sur le graphique : comparez 4 classes d'actifs simultanément : Actions, Obligations, Matières premières, Dollar. En cycle normal : Dollar baisse → Matières premières montent → Taux montent → Obligations baissent → Actions baissent. Quand une corrélation historique se brise (ex: actions et obligations baissent ensemble) = régime de marché inhabituel. Le ratio cuivre/or est un indicateur clé du sentiment économique.",
    readTime: 8,
    complexity: 5,
    shortDesc: "Analyse des corrélations entre actions, obligations, matières premières et devises pour comprendre les flux globaux.",
    fullDesc: "L'analyse intermarchés étudie les relations entre les 4 classes d'actifs : actions, obligations, matières premières et devises. Ces marchés sont interconnectés : les taux d'intérêt (obligations) impactent les actions, le dollar impacte les matières premières, etc.",
    howItWorks: "Relations classiques : Dollar fort → matières premières faibles. Taux en hausse → obligations en baisse → actions sous pression. Or en hausse → aversion au risque. Cuivre en hausse → croissance économique (Dr. Copper).",
    interpretation: {
      bullish: "Taux qui baissent + dollar stable + cuivre en hausse = environnement favorable aux actions.",
      bearish: "Taux qui montent + dollar fort + or en hausse = environnement défavorable aux actions.",
      range: "Signaux contradictoires entre les marchés = indécision.",
      divergence: "Actions en hausse mais obligations en baisse forte = tension qui devra se résoudre.",
    },
    multiTimeframe: "Weekly et monthly pour les tendances intermarchés. Les corrélations changent selon les régimes de marché.",
    limits: ["Les corrélations ne sont pas constantes — elles changent selon les régimes", "Complexe — beaucoup de variables à suivre", "Les relations causales ne sont pas toujours claires"],
    commonMistakes: ["Appliquer des corrélations historiques sans vérifier qu'elles sont toujours valides", "Simplifier excessivement les relations intermarchés", "Ignorer que les corrélations changent en période de crise"],
    combinations: ["VIX pour le sentiment", "Courbe des taux pour les signaux obligataires", "DXY (Dollar Index) pour les devises"],
    practicalCase: "Exemple 2023 : La corrélation inverse actions/obligations s'est rétablie en H2 2023 après avoir été positive en 2022. Quand les taux ont commencé à baisser en novembre 2023, les actions ont rallié fortement — l'analyse intermarchés classique a fonctionné.",
    relatedIndicators: ["Sector Rotation", "VIX", "Yield Curve"],
  },
  // ──────────── INSTITUTIONNEL (5) ────────────
  {
    id: "put-call-ratio",
    name: "Put/Call Ratio",
    nameFr: "Ratio Put/Call",
    category: "institutionnel",
    level: "intermediaire",
    image: IMG.putCallRatio,
    secondaryImage: IMG.atr,
    chartReadingGuide: "Sur le graphique : la ligne Put/Call Ratio oscille généralement entre 0.5 et 1.5. Ratio > 1 = plus de puts que de calls (peur, couverture). Ratio < 0.7 = plus de calls que de puts (complaisance, optimisme). C'est un indicateur contrarian : ratio très élevé = peur excessive (signal haussier). Ratio très bas = complaisance excessive (signal baissier). Utilisez la MA 5 jours pour lisser.",
    readTime: 5,
    complexity: 3,
    popular: true,
    shortDesc: "Ratio entre les options de vente (puts) et d'achat (calls) — indicateur de sentiment contrarian.",
    fullDesc: "Le Put/Call Ratio mesure le volume des options put divisé par le volume des options call. Un ratio élevé (>1.0) = beaucoup de puts achetés = pessimisme extrême (signal contrarian haussier). Un ratio bas (<0.7) = beaucoup de calls = optimisme extrême (signal contrarian baissier).",
    howItWorks: "P/C Ratio = Volume Puts / Volume Calls. Moyenne mobile 5 ou 10 jours pour lisser. Le CBOE publie le ratio equity-only (plus fiable) et le ratio total (inclut les indices).",
    interpretation: {
      bullish: "P/C Ratio > 1.0 (pessimisme extrême = signal contrarian haussier). Pic de P/C = capitulation.",
      bearish: "P/C Ratio < 0.7 (optimisme extrême = signal contrarian baissier). Complaisance.",
      range: "P/C Ratio entre 0.8 et 1.0 = sentiment neutre.",
      divergence: "Marché en hausse mais P/C Ratio qui monte = les investisseurs achètent de la protection → prudence.",
    },
    multiTimeframe: "Daily pour le sentiment court terme. MA 10 jours pour la tendance. MA 21 jours pour le moyen terme.",
    limits: ["Indicateur contrarian — va à l'encontre de l'instinct", "Les niveaux extrêmes varient selon les périodes", "Le ratio total est faussé par le hedging institutionnel"],
    commonMistakes: ["Utiliser le ratio total au lieu du ratio equity-only", "Ignorer le contexte de marché", "Agir sur un seul jour extrême au lieu d'attendre une tendance"],
    combinations: ["VIX pour confirmation du sentiment", "Market Breadth pour la structure", "RSI pour les zones extrêmes"],
    practicalCase: "Exemple : Le P/C Ratio equity-only a atteint 1.2 en octobre 2023 (pessimisme extrême). Ce signal contrarian a coïncidé avec le creux du marché. Le S&P 500 a rallié de +15% dans les 2 mois suivants.",
    keyLevels: ["> 1.0 — Pessimisme extrême (contrarian haussier)", "0.8-1.0 — Neutre", "< 0.7 — Optimisme extrême (contrarian baissier)"],
    relatedIndicators: ["VIX", "Market Breadth", "AAII Sentiment"],
  },
  {
    id: "cot-report",
    name: "COT Report",
    nameFr: "Rapport COT (Commitments of Traders)",
    category: "institutionnel",
    level: "avance",
    image: IMG.cotReport,
    secondaryImage: IMG.atr,
    chartReadingGuide: "Sur le graphique : 3 catégories de traders sont affichées. Commercials (hedgers, ligne bleue) = les 'smart money' qui couvrent leur exposition réelle. Large Speculators (fonds, ligne rouge) = suiveurs de tendance. Small Speculators (retail, ligne verte) = souvent contrarian. Quand les Commercials sont très longs = signal haussier. Quand les Small Specs sont très longs = signal contrarian baissier.",
    readTime: 8,
    complexity: 4,
    shortDesc: "Rapport hebdomadaire de la CFTC montrant les positions des commerciaux, grands spéculateurs et petits traders.",
    fullDesc: "Le rapport COT est publié chaque vendredi par la CFTC. Il montre les positions nettes (long - short) de trois catégories : Commercials (hedgers, smart money), Large Speculators (fonds, trend followers), et Small Speculators (retail). Les Commercials sont généralement contrarians et ont raison aux extrêmes.",
    howItWorks: "Commercials très longs = signal haussier (ils connaissent leur marché). Large Specs très longs = signal contrarian baissier (ils suivent la tendance et sont souvent en retard aux retournements).",
    interpretation: {
      bullish: "Commercials en position nette longue extrême. Large Specs en position nette courte extrême.",
      bearish: "Commercials en position nette courte extrême. Large Specs en position nette longue extrême.",
      range: "Positions neutres pour toutes les catégories.",
      divergence: "Prix en hausse mais Commercials qui vendent = smart money qui prend ses profits.",
    },
    multiTimeframe: "Hebdomadaire uniquement. Utiliser un percentile sur 3 ans pour contextualiser les extrêmes.",
    limits: ["Données retardées (mardi → vendredi)", "Spécifique aux futures — pas directement applicable aux actions", "Les catégories ne sont pas toujours homogènes"],
    commonMistakes: ["Suivre les Large Specs au lieu des Commercials", "Ignorer le contexte de tendance", "Utiliser les données brutes au lieu des percentiles"],
    combinations: ["Analyse technique pour le timing", "Saisonnalité pour les matières premières", "VIX pour le sentiment sur les indices"],
    practicalCase: "Exemple : Les Commercials sur l'or étaient en position nette longue extrême (percentile 95%) en octobre 2023. Ce signal a précédé un rallye de +15% de l'or en 3 mois.",
    relatedIndicators: ["Put/Call Ratio", "VIX", "Market Breadth"],
  },
  {
    id: "dark-pool-activity",
    name: "Dark Pool Activity",
    nameFr: "Activité des Dark Pools",
    category: "institutionnel",
    level: "avance",
    image: IMG.darkPoolActivity,
    secondaryImage: IMG.volume,
    chartReadingGuide: "Sur le graphique : le % de volume exécuté en dark pools (généralement 35-45% du volume total). Une hausse soudaine du volume dark pool sur un titre = activité institutionnelle. Les dark pool prints (transactions) au-dessus du prix moyen = accumulation institutionnelle. En dessous = distribution. Le Short Sale Volume en dark pool est aussi un indicateur clé du positionnement institutionnel.",
    readTime: 7,
    complexity: 5,
    shortDesc: "Volume échangé hors marché par les institutionnels — révèle l'accumulation/distribution cachée.",
    fullDesc: "Les Dark Pools sont des plateformes d'échange privées où les institutionnels exécutent de gros ordres sans impacter le marché public. Le Dark Pool Index (DIX) et le Gamma Exposure (GEX) sont des métriques dérivées. Un DIX élevé = accumulation institutionnelle. Un GEX élevé = le marché est stable (les market makers achètent les baisses).",
    howItWorks: "DIX > 45% = accumulation institutionnelle forte (haussier). DIX < 40% = distribution (baissier). GEX positif = les market makers stabilisent le marché. GEX négatif = les market makers amplifient les mouvements (volatilité accrue).",
    interpretation: {
      bullish: "DIX élevé (>45%) = les institutionnels accumulent. GEX positif élevé = marché stable.",
      bearish: "DIX bas (<40%) = distribution institutionnelle. GEX négatif = volatilité amplifiée.",
      range: "DIX et GEX neutres = pas de signal clair.",
      divergence: "Prix en baisse mais DIX en hausse = les institutionnels achètent la baisse (signal contrarian haussier).",
    },
    multiTimeframe: "Données quotidiennes. Moyenne mobile 5 jours pour lisser.",
    limits: ["Données retardées et incomplètes", "L'interprétation est complexe", "Pas toujours fiable — les dark pools ont des usages variés"],
    commonMistakes: ["Surinterpreter les données dark pool", "Ignorer que les dark pools servent aussi au hedging", "Utiliser comme signal unique sans confirmation"],
    combinations: ["OBV pour le volume public", "Put/Call Ratio pour le sentiment", "VIX pour la volatilité"],
    practicalCase: "Exemple : Le DIX a atteint 48% en octobre 2023 alors que le S&P 500 était en correction. Ce signal d'accumulation institutionnelle massive a précédé le rallye de fin d'année de +15%.",
    relatedIndicators: ["OBV", "Volume Profile", "Put/Call Ratio"],
  },
  {
    id: "yield-curve",
    name: "Yield Curve",
    nameFr: "Courbe des Taux (Yield Curve)",
    category: "institutionnel",
    level: "intermediaire",
    image: IMG.yieldCurve,
    secondaryImage: IMG.atr,
    chartReadingGuide: "Sur le graphique : la courbe des taux montre les rendements obligataires par maturité (de 3 mois à 30 ans). Courbe normale (pente positive) = les taux longs > taux courts (économie saine). Courbe inversée (pente négative) = taux courts > taux longs (signal de récession). Le spread 10Y-2Y est la métrique la plus surveillée. L'inversion précède les récessions de 6 à 18 mois en moyenne.",
    readTime: 7,
    complexity: 3,
    popular: true,
    shortDesc: "La forme de la courbe des taux obligataires — le meilleur prédicteur historique de récession.",
    fullDesc: "La courbe des taux montre les rendements des obligations d'État par maturité (2 ans, 5 ans, 10 ans, 30 ans). Normalement, les taux longs > taux courts (courbe ascendante). Quand les taux courts > taux longs = courbe inversée = signal de récession (fiabilité historique >80%).",
    howItWorks: "Spread 10Y-2Y > 0 = courbe normale (croissance). Spread 10Y-2Y < 0 = courbe inversée (récession probable dans 6-18 mois). Le dés-inversion (retour en positif) est souvent le signal que la récession est imminente.",
    interpretation: {
      bullish: "Courbe qui se pentifie (taux longs montent plus vite) = anticipation de croissance.",
      bearish: "Courbe qui s'inverse = anticipation de récession. Dés-inversion = récession imminente.",
      range: "Courbe plate = incertitude sur la direction économique.",
      divergence: "Actions en hausse mais courbe inversée = tension qui devra se résoudre.",
    },
    multiTimeframe: "Données quotidiennes. Le spread 10Y-2Y est le plus suivi. Le spread 10Y-3M est le plus fiable historiquement.",
    limits: ["Le timing est imprécis — l'inversion peut précéder la récession de 6 à 24 mois", "Les interventions des banques centrales (QE) faussent la courbe", "La courbe ne prédit pas l'ampleur de la récession"],
    commonMistakes: ["Paniquer dès l'inversion — le marché peut monter encore longtemps", "Ignorer la dés-inversion qui est souvent le signal le plus immédiat", "Confondre les différents spreads (10Y-2Y vs 10Y-3M)"],
    combinations: ["ISM Manufacturing pour les données macro", "Taux de chômage pour confirmer le cycle", "VIX pour le sentiment"],
    practicalCase: "Exemple : La courbe des taux US s'est inversée en juillet 2022 (spread 10Y-2Y négatif). Elle est restée inversée pendant plus d'un an. La dés-inversion progressive en 2024 a été surveillée de près comme signal de récession imminente.",
    keyLevels: ["Spread > 0 — Courbe normale", "Spread = 0 — Courbe plate", "Spread < 0 — Courbe inversée (alerte récession)"],
    relatedIndicators: ["VIX", "Sector Rotation", "Intermarket Analysis"],
  },
  {
    id: "aaii-sentiment",
    name: "AAII Sentiment Survey",
    nameFr: "Enquête de Sentiment AAII",
    category: "institutionnel",
    level: "debutant",
    image: IMG.aaiiSentiment,
    secondaryImage: IMG.atr,
    chartReadingGuide: "Sur le graphique : 3 lignes montrent le % de répondants haussiers (vert), baissiers (rouge) et neutres (gris). Le Bull-Bear Spread (différence haussiers - baissiers) est la métrique clé. Spread > +30% = optimisme extrême (contrarian baissier). Spread < -20% = pessimisme extrême (contrarian haussier). Comparez au S&P 500 pour détecter les divergences sentiment/prix.",
    readTime: 4,
    complexity: 2,
    shortDesc: "Sondage hebdomadaire du sentiment des investisseurs individuels — indicateur contrarian classique.",
    fullDesc: "L'AAII (American Association of Individual Investors) publie chaque semaine un sondage demandant aux membres s'ils sont haussiers, baissiers ou neutres sur les 6 prochains mois. C'est un indicateur contrarian : quand tout le monde est haussier, le marché est souvent proche d'un sommet.",
    howItWorks: "Bull% > 50% = optimisme extrême (contrarian baissier). Bear% > 50% = pessimisme extrême (contrarian haussier). Le Bull-Bear Spread est la métrique clé.",
    interpretation: {
      bullish: "Bear% > 50% ou Bull-Bear Spread < -20% = pessimisme extrême (contrarian haussier).",
      bearish: "Bull% > 50% ou Bull-Bear Spread > +30% = optimisme extrême (contrarian baissier).",
      range: "Sentiment neutre (Bull ≈ Bear) = pas de signal contrarian.",
      divergence: "Marché en hausse mais sentiment qui se détériore = les investisseurs ne font pas confiance au rallye.",
    },
    multiTimeframe: "Hebdomadaire. Moyenne mobile 4 semaines pour lisser.",
    limits: ["Échantillon limité (membres AAII uniquement)", "Indicateur contrarian — va contre l'instinct", "Le timing n'est pas précis — le sentiment peut rester extrême longtemps"],
    commonMistakes: ["Suivre le sentiment au lieu de le contrer", "Agir sur une seule semaine extrême", "Ignorer que le sentiment est un indicateur de timing, pas de direction"],
    combinations: ["Put/Call Ratio pour confirmation", "VIX pour le sentiment institutionnel", "Market Breadth pour la structure"],
    practicalCase: "Exemple : Le sentiment AAII Bear% a atteint 60% en octobre 2022 (pessimisme extrême). Ce signal contrarian a marqué le creux exact du marché. Le S&P 500 a rallié de +30% dans les 12 mois suivants.",
    relatedIndicators: ["Put/Call Ratio", "VIX", "Fear & Greed Index"],
  },
  // ──────────── SYNTHÈSE MULTI-INDICATEURS (6) ────────────
  {
    id: "fear-greed-index",
    name: "Fear & Greed Index",
    nameFr: "Indice Fear & Greed (CNN)",
    category: "synthese",
    level: "debutant",
    image: IMG.fearGreedIndex,
    secondaryImage: IMG.atr,
    chartReadingGuide: "Sur le graphique : un cadran de 0 à 100 avec des zones colorées. 0-25 (rouge) = Peur extrême. 25-50 (orange) = Peur. 50-75 (jaune-vert) = Avidité. 75-100 (vert foncé) = Avidité extrême. C'est un indicateur contrarian : peur extrême = opportunité d'achat historique. Avidité extrême = prudence. Comparez le score actuel à celui d'il y a 1 semaine et 1 mois pour la tendance.",
    readTime: 4,
    complexity: 1,
    popular: true,
    shortDesc: "Indice composite CNN qui agrège 7 indicateurs de sentiment en un seul score de 0 (peur extrême) à 100 (avidité extrême).",
    fullDesc: "Le Fear & Greed Index de CNN combine 7 indicateurs : momentum du S&P 500, force du prix, largeur du prix, put/call ratio, demande d'obligations junk, volatilité (VIX), et demande de valeurs refuges. Le résultat est un score de 0 à 100.",
    howItWorks: "0-25 = Peur extrême (contrarian haussier). 25-50 = Peur. 50-75 = Avidité. 75-100 = Avidité extrême (contrarian baissier). L'indice est mis à jour quotidiennement.",
    interpretation: {
      bullish: "Score < 25 (peur extrême) = signal contrarian haussier historiquement fiable.",
      bearish: "Score > 75 (avidité extrême) = signal contrarian baissier.",
      range: "Score 40-60 = sentiment neutre, pas de signal contrarian.",
      divergence: "Marché en hausse mais F&G qui baisse = les indicateurs sous-jacents se détériorent.",
    },
    multiTimeframe: "Quotidien. Comparer au score d'il y a 1 semaine, 1 mois, 1 an pour le contexte.",
    limits: ["Indicateur composite simplifié — les composants individuels sont plus informatifs", "Le timing n'est pas précis", "Ne fonctionne que pour le marché US"],
    commonMistakes: ["Utiliser comme signal de trading direct", "Ignorer les composants individuels", "Penser que peur extrême = achat immédiat (le timing est incertain)"],
    combinations: ["VIX pour le détail de la volatilité", "Put/Call Ratio pour le détail du sentiment options", "AAII pour le sentiment retail"],
    practicalCase: "Exemple : Le Fear & Greed Index est tombé à 12 (peur extrême) en octobre 2023. Ce signal contrarian a précédé le rallye de fin d'année de +15% du S&P 500.",
    keyLevels: ["0-25 — Peur extrême", "25-50 — Peur", "50-75 — Avidité", "75-100 — Avidité extrême"],
    relatedIndicators: ["VIX", "Put/Call Ratio", "AAII Sentiment"],
  },
  {
    id: "triple-screen",
    name: "Triple Screen System",
    nameFr: "Système Triple Écran (Elder)",
    category: "synthese",
    level: "avance",
    image: IMG.tripleScreen,
    secondaryImage: IMG.macd,
    chartReadingGuide: "Sur le graphique : 3 écrans côte à côte. Écran 1 (Weekly) : MACD pour la direction de la tendance. Écran 2 (Daily) : oscillateur (Stochastique ou Force Index) pour identifier les pullbacks dans la direction de la tendance. Écran 3 (4H/Intraday) : breakout ou pattern pour le timing précis de l'entrée. On ne trade que dans la direction de l'écran 1.",
    readTime: 8,
    complexity: 4,
    shortDesc: "Système d'Alexander Elder qui combine 3 timeframes et 3 types d'indicateurs pour des signaux de haute qualité.",
    fullDesc: "Le Triple Screen d'Alexander Elder utilise 3 écrans : 1) Tendance (timeframe supérieur, MACD weekly), 2) Oscillateur (timeframe intermédiaire, Force Index ou Stochastique daily), 3) Entrée (timeframe inférieur, breakout intraday). On ne trade que dans la direction de la tendance du timeframe supérieur.",
    howItWorks: "Écran 1 (Weekly MACD) : détermine la direction. Écran 2 (Daily oscillateur) : identifie les pullbacks dans la direction de la tendance. Écran 3 (Intraday) : timing précis de l'entrée.",
    interpretation: {
      bullish: "MACD weekly haussier + oscillateur daily en survente = opportunité d'achat.",
      bearish: "MACD weekly baissier + oscillateur daily en surachat = opportunité de vente.",
      range: "MACD weekly plat = pas de trade. Attendre un signal directionnel.",
      divergence: "Divergence sur l'écran 1 (weekly) = signal de retournement majeur.",
    },
    multiTimeframe: "C'est un système multi-timeframe par définition : Weekly → Daily → 4H (ou Daily → 4H → 1H).",
    limits: ["Nécessite de la patience — les signaux alignés sont rares", "Le choix des indicateurs pour chaque écran est subjectif", "Peut manquer des mouvements rapides"],
    commonMistakes: ["Trader contre la tendance du timeframe supérieur", "Utiliser le même timeframe pour les 3 écrans", "Ignorer l'écran 3 (timing) et entrer trop tôt"],
    combinations: ["MACD pour l'écran 1", "Stochastique ou Force Index pour l'écran 2", "Breakout ou pattern pour l'écran 3"],
    practicalCase: "Exemple : En mars 2023, le MACD weekly du S&P 500 était haussier (écran 1). Le stochastique daily est tombé en survente (écran 2). Un breakout intraday au-dessus de la résistance 4H a donné l'entrée (écran 3). Le trade a capturé un mouvement de +8%.",
    relatedIndicators: ["MACD", "Stochastique", "Force Index"],
  },
  {
    id: "ichimoku-system",
    name: "Ichimoku Trading System",
    nameFr: "Système de Trading Ichimoku Complet",
    category: "synthese",
    level: "avance",
    image: IMG.ichimokuSystem,
    secondaryImage: IMG.ichimoku,
    chartReadingGuide: "Sur le graphique : 5 éléments à vérifier. 1) Tenkan-sen (rouge) > Kijun-sen (bleu) = haussier. 2) Prix au-dessus du nuage = haussier. 3) Nuage futur vert (Senkou A > Senkou B) = haussier. 4) Chikou Span au-dessus du prix passé = confirmation. 5) Nuage qui s'épaissit = tendance qui se renforce. Signal 5/5 = très haute qualité. Prix dans le nuage = zone d'incertitude, pas de trade.",
    readTime: 10,
    complexity: 5,
    shortDesc: "Utilisation complète des 5 éléments Ichimoku comme système de trading intégré.",
    fullDesc: "Le système Ichimoku complet utilise les 5 éléments en synergie : Tenkan-sen et Kijun-sen pour les croisements, le Kumo (nuage) pour le support/résistance dynamique, le Chikou Span pour la confirmation, et le nuage futur pour l'anticipation. Un signal est fort quand les 5 éléments sont alignés.",
    howItWorks: "Signal fort haussier (5/5) : 1) Tenkan > Kijun, 2) Prix > Nuage, 3) Nuage futur vert, 4) Chikou > Prix passé, 5) Nuage futur qui s'épaissit. Chaque élément manquant réduit la qualité du signal.",
    interpretation: {
      bullish: "5/5 éléments alignés haussiers = signal de très haute qualité. 3-4/5 = signal correct.",
      bearish: "5/5 éléments alignés baissiers. Le passage du prix dans le nuage = zone de danger.",
      range: "Prix dans le nuage, Tenkan et Kijun plats = pas de signal. Attendre la sortie du nuage.",
      divergence: "Chikou Span qui diverge du prix = signal précoce de retournement.",
    },
    multiTimeframe: "Weekly pour la direction principale. Daily pour les entrées. Le système est conçu pour être utilisé sur un seul timeframe mais la confirmation multi-TF le renforce.",
    limits: ["Complexe — 5 éléments à surveiller simultanément", "Moins efficace en range", "Les paramètres originaux sont débattus pour les marchés modernes"],
    commonMistakes: ["Utiliser un seul élément au lieu du système complet", "Entrer dans le nuage (zone d'incertitude)", "Ignorer le Chikou Span qui est le filtre le plus important"],
    combinations: ["RSI pour les divergences aux niveaux du nuage", "Volume pour confirmer les cassures du nuage", "Fibonacci pour affiner les niveaux dans le nuage"],
    practicalCase: "Exemple Nikkei 225, 2023 : Signal 5/5 haussier en mai 2023 sur le weekly. Le rallye qui a suivi a été l'un des plus forts de l'année (+20%). Le nuage weekly a servi de support parfait lors de chaque correction.",
    relatedIndicators: ["Ichimoku Cloud", "MACD", "RSI"],
  },
  {
    id: "divergence-trading",
    name: "Divergence Trading",
    nameFr: "Trading des Divergences (Multi-Indicateurs)",
    category: "synthese",
    level: "intermediaire",
    image: IMG.divergenceTrading,
    secondaryImage: IMG.rsi,
    chartReadingGuide: "Sur le graphique : comparez le prix (en haut) et l'oscillateur (en bas). Divergence haussière régulière : prix fait un nouveau bas, oscillateur fait un bas PLUS HAUT (les vendeurs s'épuisent). Divergence baissière régulière : prix fait un nouveau haut, oscillateur fait un haut PLUS BAS (les acheteurs s'épuisent). Tracez des lignes entre les sommets/creux pour visualiser. Double divergence (RSI + MACD) = signal très fort.",
    readTime: 7,
    complexity: 3,
    popular: true,
    shortDesc: "Méthode qui identifie les divergences entre le prix et les oscillateurs pour anticiper les retournements.",
    fullDesc: "Une divergence se produit quand le prix et un oscillateur vont dans des directions opposées. Divergence régulière : signal de retournement. Divergence cachée : signal de continuation. Les divergences sur plusieurs indicateurs simultanément (RSI + MACD + OBV) sont les plus fiables.",
    howItWorks: "Divergence haussière régulière : prix fait un nouveau bas, oscillateur fait un bas plus haut. Divergence baissière régulière : prix fait un nouveau haut, oscillateur fait un haut plus bas. Divergence cachée : l'inverse (signal de continuation).",
    interpretation: {
      bullish: "Divergence haussière régulière (prix bas, oscillateur haut) = retournement haussier. Divergence cachée haussière = continuation.",
      bearish: "Divergence baissière régulière (prix haut, oscillateur bas) = retournement baissier. Divergence cachée baissière = continuation.",
      range: "Les divergences sont plus fiables en range qu'en tendance forte.",
      divergence: "Double ou triple divergence (RSI + MACD + OBV) = signal de très haute fiabilité.",
    },
    multiTimeframe: "Les divergences sur le weekly sont les plus fiables. Daily pour le timing. Les divergences intraday sont moins fiables.",
    limits: ["Les divergences peuvent durer longtemps avant de se résoudre", "En tendance forte, les divergences sont souvent ignorées par le marché", "Subjectif — l'identification n'est pas toujours claire"],
    commonMistakes: ["Agir immédiatement sur une divergence sans attendre la confirmation", "Ignorer la tendance principale", "Confondre divergence régulière et cachée"],
    combinations: ["RSI + MACD pour la double divergence", "OBV pour la divergence volume", "Supports/Résistances pour le contexte"],
    practicalCase: "Exemple : En janvier 2023, le S&P 500 a formé une triple divergence haussière (RSI + MACD + OBV) au niveau du support 3800. Ce signal de très haute qualité a précédé un rallye de +25% en 6 mois.",
    relatedIndicators: ["RSI", "MACD", "OBV"],
  },
  {
    id: "bollinger-keltner-squeeze",
    name: "Bollinger/Keltner Squeeze",
    nameFr: "Squeeze Bollinger/Keltner (TTM Squeeze)",
    category: "synthese",
    level: "avance",
    image: IMG.bollingerKeltnerSqueeze,
    secondaryImage: IMG.bollinger,
    chartReadingGuide: "Sur le graphique : les Bandes de Bollinger (bleues) et les Canaux de Keltner (rouges) sont superposés. Quand Bollinger est à L'INTÉRIEUR de Keltner = Squeeze ON (points rouges en bas, compression extrême). Quand Bollinger sort de Keltner = Squeeze OFF (points verts, breakout). L'histogramme de momentum (vert/rouge) indique la direction probable. Squeeze ON prolongé = explosion imminente.",
    readTime: 7,
    complexity: 4,
    shortDesc: "Combinaison des Bollinger Bands et Keltner Channels pour identifier les compressions de volatilité extrêmes.",
    fullDesc: "Le TTM Squeeze (développé par John Carter) se produit quand les Bandes de Bollinger passent à l'intérieur des Canaux de Keltner. Cela indique une compression de volatilité extrême qui précède souvent un mouvement explosif. L'histogramme de momentum (basé sur le canal de régression linéaire) donne la direction probable du breakout.",
    howItWorks: "Squeeze ON (points rouges) : Bollinger à l'intérieur de Keltner = compression. Squeeze OFF (points verts) : Bollinger sort de Keltner = expansion (breakout). L'histogramme de momentum indique la direction.",
    interpretation: {
      bullish: "Squeeze OFF + histogramme positif et croissant = breakout haussier.",
      bearish: "Squeeze OFF + histogramme négatif et décroissant = breakout baissier.",
      range: "Squeeze ON prolongé = compression extrême, explosion imminente (mais direction inconnue).",
      divergence: "Histogramme qui change de direction pendant le squeeze = indice sur la direction du breakout.",
    },
    multiTimeframe: "Daily pour les signaux swing. Weekly pour les signaux de position (plus rares mais plus puissants). Le squeeze weekly est l'un des signaux les plus fiables.",
    limits: ["Ne prédit pas la direction du breakout avec certitude", "Les faux breakouts existent", "Nécessite un indicateur directionnel complémentaire"],
    commonMistakes: ["Entrer pendant le squeeze au lieu d'attendre le breakout", "Ignorer l'histogramme de momentum qui donne la direction", "Utiliser sur des timeframes trop courts"],
    combinations: ["MACD pour confirmer la direction du breakout", "Volume pour valider le breakout", "ADX pour confirmer que la tendance se développe après le breakout"],
    practicalCase: "Exemple Tesla (TSLA), 2023 : Un squeeze weekly (le premier en 6 mois) s'est formé en mai 2023. Le breakout haussier avec un histogramme positif a précédé un rallye de +40% en 6 semaines. Le volume au breakout était 3× la moyenne.",
    relatedIndicators: ["Bollinger Bands", "Keltner Channels", "MACD"],
  },
  {
    id: "market-regime",
    name: "Market Regime Detection",
    nameFr: "Détection de Régime de Marché",
    category: "synthese",
    level: "avance",
    image: IMG.marketRegime,
    secondaryImage: IMG.adx,
    chartReadingGuide: "Sur le graphique : combinez ADX + Bollinger + VIX pour classifier le régime. Tendance forte : ADX > 25, MAs ordonnées, Bollinger écartées. Range : ADX < 20, Bollinger serrées, prix entre S/R. Transition : ADX 20-25, signaux contradictoires. Volatilité extrême : VIX > 30, ATR élevé. Chaque régime nécessite des indicateurs différents — c'est la clé de la performance.",
    readTime: 8,
    complexity: 5,
    shortDesc: "Méthode systématique pour identifier si le marché est en tendance, en range, ou en transition — et adapter sa stratégie.",
    fullDesc: "La détection de régime combine plusieurs indicateurs pour classifier l'état du marché : Tendance forte (ADX > 25 + MAs ordonnées), Range (ADX < 20 + Bollinger serrées), Transition (ADX entre 20-25 + signaux contradictoires), Volatilité extrême (VIX > 30 + ATR élevé). Chaque régime nécessite une stratégie différente.",
    howItWorks: "Régime Tendance : utiliser MAs, MACD, SAR, SuperTrend. Régime Range : utiliser RSI, Stochastique, Bollinger, S/R. Régime Transition : réduire la taille des positions, attendre la clarification. Régime Volatilité : élargir les stops, réduire l'exposition.",
    interpretation: {
      bullish: "Régime Tendance haussière confirmé = utiliser les indicateurs de suivi de tendance.",
      bearish: "Régime Tendance baissière = utiliser les indicateurs de suivi de tendance à la baisse.",
      range: "Régime Range confirmé = utiliser les oscillateurs et les niveaux de support/résistance.",
      divergence: "Transition entre régimes = les indicateurs donnent des signaux contradictoires.",
    },
    multiTimeframe: "Identifier le régime sur le weekly, trader sur le daily. Le régime du timeframe supérieur prime.",
    limits: ["La classification est parfois ambiguë", "Les transitions entre régimes sont les plus difficiles à gérer", "Aucun système n'est parfait — les faux signaux existent dans tous les régimes"],
    commonMistakes: ["Utiliser des indicateurs de tendance en range (et vice versa)", "Ignorer les transitions entre régimes", "Ne pas adapter sa stratégie au régime actuel"],
    combinations: ["ADX pour la force de la tendance", "Bollinger Bands pour la volatilité", "VIX pour le sentiment", "Market Breadth pour la structure"],
    practicalCase: "Exemple 2023 : Le S&P 500 est passé d'un régime de range (janvier-mars, ADX < 20) à un régime de tendance haussière (avril-juillet, ADX > 30) puis à un régime de volatilité (août-octobre, VIX > 20) avant de revenir en tendance haussière (novembre-décembre). Les traders qui ont adapté leurs indicateurs à chaque régime ont surperformé.",
    relatedIndicators: ["ADX", "VIX", "Bollinger Bands"],
  },
];


/* ═══════════════════════════════════════════════════════════
 * COMPONENT — TRADING PREMIUM DESIGN
 * ═══════════════════════════════════════════════════════════ */
export const FREE_INDICATOR_LIMIT = 12;

/* Complexity bar — visual trading-style meter */
function ComplexityBar({ level, size = "sm" }: { level: number; size?: "sm" | "lg" }) {
  const h = size === "lg" ? "h-2" : "h-1.5";
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className={`${h} w-4 rounded-sm ${i < level ? "bg-[#D4A853]" : "bg-white/10"}`} />
      ))}
    </div>
  );
}

/* Stat pill for the hero */
function HeroStat({ value, label }: { value: string; label: string }) {
  return (
    <div className="text-center px-5">
      <div className="text-2xl md:text-3xl font-bold text-[#8A6E18] font-mono tracking-tight">{value}</div>
      <div className="text-[11px] uppercase tracking-widest text-white/75 mt-1">{label}</div>
    </div>
  );
}

export default function IndicateursTendance() {
  usePageTitle("Indicateurs de tendance");
  const { isPremium, isAuthenticated } = useSubscription();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedLevel, setSelectedLevel] = useState<Level | "all">("all");
  const [selectedIndicator, setSelectedIndicator] = useState<Indicator | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  useSEO(SEO_PAGES.indicateurs);

  const filteredIndicators = useMemo(() => {
    return INDICATORS.filter((ind) => {
      const matchesSearch =
        searchQuery === "" ||
        ind.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ind.nameFr.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ind.shortDesc.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === "all" || ind.category === selectedCategory;
      const matchesLevel = selectedLevel === "all" || ind.level === selectedLevel;
      return matchesSearch && matchesCategory && matchesLevel;
    });
  }, [searchQuery, selectedCategory, selectedLevel]);

  const popularIndicators = useMemo(() => INDICATORS.filter((i) => i.popular), []);

  const resetFilters = useCallback(() => {
    setSearchQuery("");
    setSelectedCategory("all");
    setSelectedLevel("all");
  }, []);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { all: INDICATORS.length };
    INDICATORS.forEach((ind) => {
      counts[ind.category] = (counts[ind.category] || 0) + 1;
    });
    return counts;
  }, []);

  const levelCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    INDICATORS.forEach((ind) => {
      counts[ind.level] = (counts[ind.level] || 0) + 1;
    });
    return counts;
  }, []);

  /* ─── DETAIL VIEW — TRADING TERMINAL STYLE ─── */
  if (selectedIndicator) {
    const ind = selectedIndicator;
    const lvl = LEVEL_STYLES[ind.level];
    const catColor = CATEGORY_COLORS[ind.category] || "from-gray-600 to-gray-700";
    const CatIcon = CATEGORY_ICONS[ind.category] || Layers;
    // Restriction pour comptes gratuits connectés (pas premium)
    const freeIds = INDICATORS.slice(0, FREE_INDICATOR_LIMIT).map(i => i.id);
    const isLockedForFreeUser = isAuthenticated && !isPremium && !freeIds.includes(ind.id);

    if (isLockedForFreeUser) {
      return (
        <Layout>
          <div className="bg-gradient-to-br from-[#344453] via-[#2a3a47] to-[#1E1E1E] min-h-screen">
            <div className={`bg-gradient-to-r ${catColor} py-12`}>
              <div className="container">
                <button onClick={() => setSelectedIndicator(null)} className="flex items-center gap-2 text-white/75 hover:text-white mb-6 transition-colors text-sm">
                  <ArrowLeft size={16} /> Retour aux indicateurs
                </button>
                <h1 className="text-3xl md:text-4xl font-bold text-white">{ind.nameFr}</h1>
                <p className="text-white/75 mt-2 text-lg max-w-2xl">{ind.shortDesc}</p>
              </div>
            </div>
            <div className="container py-16">
              <div className="max-w-lg mx-auto text-center">
                <div className="w-20 h-20 rounded-2xl bg-[#D4A853]/10 border border-[#D4A853]/20 flex items-center justify-center mx-auto mb-6">
                  <Crown size={36} className="text-[#8A6E18]" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-3">Contenu Premium</h2>
                <p className="text-white/85 mb-8">Débloquez l'accès complet aux {INDICATORS.length} fiches d'indicateurs techniques avec définitions détaillées, interprétations multi-scénarios, limites et cas pratiques.</p>
                <Link href="/pricing" className="inline-flex items-center gap-2 px-7 py-3.5 bg-gradient-to-r from-[#D4A853] to-[#C49A4A] text-white font-bold rounded-xl hover:shadow-lg hover:shadow-[#D4A853]/20 transition-all">
                  Voir les offres
                </Link>
              </div>
            </div>
          </div>
        </Layout>
      );
    }

    return (
      <Layout>
        <div className="bg-gradient-to-br from-[#344453] via-[#2a3a47] to-[#1E1E1E] min-h-screen">
          {/* Detail Header — Trading Terminal */}
          <div className={`bg-gradient-to-br ${catColor} relative overflow-hidden`}>
            <div className="absolute inset-0 opacity-5" style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")" }} />
            <div className="relative container py-10 lg:py-14">
              <button onClick={() => setSelectedIndicator(null)} className="flex items-center gap-2 text-white/85 hover:text-white mb-6 transition-colors text-sm font-medium">
                <ArrowLeft size={16} /> Retour aux indicateurs
              </button>
              <div className="flex flex-wrap items-center gap-3 mb-4">
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${lvl.bg} ${lvl.text} border ${lvl.border}`}>{lvl.label}</span>
                <span className="px-3 py-1 rounded-full text-xs font-medium bg-white/10 text-white/85 flex items-center gap-1.5"><CatIcon size={11} /> {CATEGORY_LABELS[ind.category]}</span>
                <span className="flex items-center gap-1.5 text-white/80 text-xs"><Clock size={12} /> {ind.readTime} min de lecture</span>
              </div>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-2">{ind.nameFr}</h1>
              <p className="text-sm text-white/70 font-mono mb-4">{ind.name}</p>
              <p className="text-base text-white/85 max-w-2xl leading-relaxed">{ind.shortDesc}</p>
              {/* Complexity meter */}
              <div className="mt-6 flex items-center gap-3">
                <span className="text-[11px] uppercase tracking-widest text-white/70">Complexité</span>
                <ComplexityBar level={ind.complexity} size="lg" />
              </div>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="container mt-6">
            <div className="bg-amber-500/5 border border-amber-500/15 rounded-xl p-4 flex items-start gap-3">
              <AlertTriangle size={16} className="text-amber-400 mt-0.5 shrink-0" />
              <p className="text-amber-200/60 text-xs leading-relaxed">{DISCLAIMER}</p>
            </div>
          </div>

          {/* Content Grid */}
          <div className="container py-8">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Main Content */}
              <div className="lg:col-span-2 space-y-6">
                {/* Image */}
                {ind.image && (
                  <div className="bg-white rounded-xl border border-[#D0D5DA] overflow-hidden">
                    <img src={ind.image} alt={ind.nameFr} className="w-full object-contain max-h-[400px]" loading="lazy" />
                    <p className="text-[11px] text-[#1E1E1E]/75 p-3 text-center font-mono">Source : WMB Encyclopédie</p>
                  </div>
                )}

                {/* 📊 Comment lire ce graphique — NEW SECTION */}
                {ind.chartReadingGuide && (
                  <section className="bg-white rounded-xl border border-cyan-500/10 p-6">
                    <h2 className="text-lg font-bold text-[#344453] mb-5 flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-cyan-500/15 flex items-center justify-center"><Eye size={15} className="text-cyan-400" /></div>
                      Comment lire ce graphique
                    </h2>
                    {ind.secondaryImage && (
                      <div className="mb-5 bg-gradient-to-br from-[#344453] via-[#2a3a47] to-[#1E1E1E] rounded-lg border border-[#D0D5DA] overflow-hidden">
                        <img src={ind.secondaryImage} alt={`Guide de lecture — ${ind.nameFr}`} className="w-full object-contain max-h-[350px]" loading="lazy" />
                        <p className="text-[11px] text-white/70 p-2 text-center font-mono">Illustration graphique — {ind.name}</p>
                      </div>
                    )}
                    <div className="bg-cyan-500/5 border border-cyan-500/10 rounded-lg p-4">
                      <p className="text-[#1E1E1E]/80 leading-relaxed text-sm">{ind.chartReadingGuide}</p>
                    </div>
                  </section>
                )}

                {/* Définition */}
                <section className="bg-white rounded-xl border border-[#D0D5DA] p-6">
                  <h2 className="text-lg font-bold text-[#344453] mb-4 flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-[#344453] flex items-center justify-center"><BookOpen size={15} className="text-white/85" /></div>
                    Définition
                  </h2>
                  <p className="text-[#1E1E1E]/80 leading-relaxed text-sm">{ind.fullDesc}</p>
                </section>

                {/* Fonctionnement */}
                <section className="bg-white rounded-xl border border-[#D0D5DA] p-6">
                  <h2 className="text-lg font-bold text-[#344453] mb-4 flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-violet-600/20 flex items-center justify-center"><Lightbulb size={15} className="text-violet-400" /></div>
                    Comment ça fonctionne
                  </h2>
                  <p className="text-[#1E1E1E]/75 leading-relaxed text-sm">{ind.howItWorks}</p>
                </section>

                {/* Interprétation — Trading Cards */}
                <section className="bg-white rounded-xl border border-[#D0D5DA] p-6">
                  <h2 className="text-lg font-bold text-[#344453] mb-5 flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-cyan-600/20 flex items-center justify-center"><Eye size={15} className="text-cyan-400" /></div>
                    Interprétation Multi-Scénarios
                  </h2>
                  <div className="grid sm:grid-cols-2 gap-3">
                    <div className="bg-emerald-500/5 border border-emerald-500/15 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp size={14} className="text-emerald-400" />
                        <h3 className="font-bold text-emerald-400 text-xs uppercase tracking-wider">Bullish</h3>
                      </div>
                      <p className="text-[#1E1E1E]/75 text-sm leading-relaxed">{ind.interpretation.bullish}</p>
                    </div>
                    <div className="bg-rose-500/5 border border-rose-500/15 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingDown size={14} className="text-rose-400" />
                        <h3 className="font-bold text-rose-400 text-xs uppercase tracking-wider">Bearish</h3>
                      </div>
                      <p className="text-[#1E1E1E]/75 text-sm leading-relaxed">{ind.interpretation.bearish}</p>
                    </div>
                    <div className="bg-amber-500/5 border border-amber-500/15 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <ArrowUpDown size={14} className="text-amber-400" />
                        <h3 className="font-bold text-amber-400 text-xs uppercase tracking-wider">Range</h3>
                      </div>
                      <p className="text-[#1E1E1E]/75 text-sm leading-relaxed">{ind.interpretation.range}</p>
                    </div>
                    <div className="bg-violet-500/5 border border-violet-500/15 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Zap size={14} className="text-violet-400" />
                        <h3 className="font-bold text-violet-400 text-xs uppercase tracking-wider">Divergence</h3>
                      </div>
                      <p className="text-[#1E1E1E]/75 text-sm leading-relaxed">{ind.interpretation.divergence}</p>
                    </div>
                  </div>
                </section>

                {/* Multi-Timeframe */}
                <section className="bg-white rounded-xl border border-[#D0D5DA] p-6">
                  <h2 className="text-lg font-bold text-[#344453] mb-4 flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-indigo-600/20 flex items-center justify-center"><Layers size={15} className="text-indigo-400" /></div>
                    Multi-Timeframe
                  </h2>
                  <p className="text-[#1E1E1E]/75 leading-relaxed text-sm">{ind.multiTimeframe}</p>
                </section>

                {/* Key Levels */}
                {ind.keyLevels && ind.keyLevels.length > 0 && (
                  <section className="bg-white rounded-xl border border-[#D0D5DA] p-6">
                    <h2 className="text-lg font-bold text-[#344453] mb-4 flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-[#D4A853]/20 flex items-center justify-center"><Target size={15} className="text-[#8A6E18]" /></div>
                      Niveaux Clés
                    </h2>
                    <div className="space-y-2">
                      {ind.keyLevels.map((level, i) => (
                        <div key={i} className="flex items-center gap-3 bg-white/3 rounded-lg px-4 py-3 border border-[#D0D5DA]">
                          <span className="w-2 h-2 rounded-full bg-[#D4A853]" />
                          <span className="text-[#1E1E1E]/75 text-sm">{level}</span>
                        </div>
                      ))}
                    </div>
                  </section>
                )}

                {/* Toggle Avancé */}
                <button
                  onClick={() => setShowAdvanced(!showAdvanced)}
                  className="w-full flex items-center justify-between bg-white rounded-xl border border-[#D0D5DA] p-5 hover:border-[#D4A853]/30 transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-rose-600/20 flex items-center justify-center">
                      <Flame size={15} className="text-rose-400" />
                    </div>
                    <div className="text-left">
                      <span className="text-[#344453] font-semibold text-sm block">Mode Avancé</span>
                      <span className="text-[#1E1E1E]/75 text-xs">Limites, erreurs, combinaisons, cas pratique</span>
                    </div>
                  </div>
                  {showAdvanced ? <ChevronUp size={18} className="text-[#1E1E1E]/75" /> : <ChevronDown size={18} className="text-[#1E1E1E]/75" />}
                </button>

                <AnimatePresence>
                  {showAdvanced && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="space-y-6 overflow-hidden">
                      {/* Limites */}
                      <section className="bg-white rounded-xl border border-amber-500/10 p-6">
                        <h2 className="text-lg font-bold text-[#344453] mb-4 flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-amber-600/20 flex items-center justify-center"><AlertTriangle size={15} className="text-amber-400" /></div>
                          Limites et Pièges
                        </h2>
                        <ul className="space-y-2">
                          {ind.limits.map((limit, i) => (
                            <li key={i} className="flex items-start gap-3">
                              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 shrink-0" />
                              <span className="text-[#1E1E1E]/75 text-sm">{limit}</span>
                            </li>
                          ))}
                        </ul>
                      </section>

                      {/* Erreurs */}
                      <section className="bg-white rounded-xl border border-rose-500/10 p-6">
                        <h2 className="text-lg font-bold text-[#344453] mb-4 flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-rose-600/20 flex items-center justify-center"><Shield size={15} className="text-rose-400" /></div>
                          Erreurs Fréquentes
                        </h2>
                        <ul className="space-y-2">
                          {ind.commonMistakes.map((mistake, i) => (
                            <li key={i} className="flex items-start gap-3">
                              <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-2 shrink-0" />
                              <span className="text-[#1E1E1E]/75 text-sm">{mistake}</span>
                            </li>
                          ))}
                        </ul>
                      </section>

                      {/* Combinaisons */}
                      <section className="bg-white rounded-xl border border-emerald-500/10 p-6">
                        <h2 className="text-lg font-bold text-[#344453] mb-4 flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-emerald-600/20 flex items-center justify-center"><Combine size={15} className="text-emerald-400" /></div>
                          Combinaisons Informatives
                        </h2>
                        <ul className="space-y-2">
                          {ind.combinations.map((combo, i) => (
                            <li key={i} className="flex items-start gap-3">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-2 shrink-0" />
                              <span className="text-[#1E1E1E]/75 text-sm">{combo}</span>
                            </li>
                          ))}
                        </ul>
                      </section>

                      {/* Cas pratique */}
                      <section className="bg-white rounded-xl border border-[#D4A853]/10 p-6">
                        <h2 className="text-lg font-bold text-[#344453] mb-4 flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-[#D4A853]/20 flex items-center justify-center"><BarChart3 size={15} className="text-[#8A6E18]" /></div>
                          Cas Pratique Annoté
                        </h2>
                        <p className="text-[#1E1E1E]/75 leading-relaxed text-sm">{ind.practicalCase}</p>
                      </section>

                      {/* Version avancée */}
                      {ind.advancedVersion && (
                        <section className="bg-white rounded-xl border border-violet-500/10 p-6">
                          <h2 className="text-lg font-bold text-[#344453] mb-4 flex items-center gap-2">
                            <div className="w-8 h-8 rounded-lg bg-violet-600/20 flex items-center justify-center"><Zap size={15} className="text-violet-400" /></div>
                            Version Avancée
                          </h2>
                          <p className="text-[#1E1E1E]/75 leading-relaxed text-sm">{ind.advancedVersion}</p>
                        </section>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Sidebar — Trading Style */}
              <div className="space-y-5">
                {/* Quick Stats */}
                <div className="bg-white rounded-xl border border-[#D0D5DA] p-5">
                  <h3 className="text-xs uppercase tracking-widest text-[#1E1E1E]/75 mb-4">Fiche Technique</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-[#344453]/75 text-xs">Catégorie</span>
                      <span className="text-[#344453] text-xs font-medium flex items-center gap-1.5"><CatIcon size={11} /> {CATEGORY_LABELS[ind.category]}</span>
                    </div>
                    <div className="h-px bg-white/5" />
                    <div className="flex justify-between items-center">
                      <span className="text-[#344453]/75 text-xs">Niveau</span>
                      <span className={`text-xs font-medium ${lvl.text}`}>{lvl.label}</span>
                    </div>
                    <div className="h-px bg-white/5" />
                    <div className="flex justify-between items-center">
                      <span className="text-[#344453]/75 text-xs">Lecture</span>
                      <span className="text-[#344453] text-xs font-medium">{ind.readTime} min</span>
                    </div>
                    <div className="h-px bg-white/5" />
                    <div className="flex justify-between items-center">
                      <span className="text-[#344453]/75 text-xs">Complexité</span>
                      <ComplexityBar level={ind.complexity} />
                    </div>
                  </div>
                </div>

                {/* Related indicators */}
                <div className="bg-white rounded-xl border border-[#D0D5DA] p-5">
                  <h3 className="text-xs uppercase tracking-widest text-[#1E1E1E]/75 mb-4">Indicateurs Liés</h3>
                  <div className="space-y-1">
                    {ind.relatedIndicators.map((name) => {
                      const related = INDICATORS.find((i) => i.name === name || i.nameFr.includes(name));
                      return (
                        <button
                          key={name}
                          onClick={() => related && setSelectedIndicator(related)}
                          className="w-full text-left px-3 py-2.5 rounded-lg hover:bg-white transition-colors flex items-center justify-between group"
                        >
                          <span className="text-sm text-[#344453]/75 group-hover:text-[#344453] transition-colors">{name}</span>
                          <ChevronRight size={13} className="text-[#344453]/75 group-hover:text-[#344453]/80" />
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Vu dans la newsletter */}
                <div className="rounded-xl border border-[#D4A853]/10 bg-gradient-to-br from-[#D4A853]/5 to-transparent p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-7 h-7 rounded-lg bg-[#D4A853]/10 flex items-center justify-center">
                      <Sparkles size={13} className="text-[#8A6E18]" />
                    </div>
                    <h3 className="font-semibold text-[#344453] text-sm">Vu dans la newsletter</h3>
                  </div>
                  <p className="text-xs text-[#344453]/75 leading-relaxed mb-3">
                    Cet indicateur est régulièrement utilisé dans nos éditions hebdomadaires pour analyser les marchés US.
                  </p>
                  <Link href="/newsletter" className="inline-flex items-center gap-1 text-[11px] font-bold text-[#8A6E18] hover:underline">
                    Découvrir la newsletter <ChevronRight size={10} />
                  </Link>
                </div>

                {/* À lire ensuite */}
                <div className="rounded-xl border border-[#2E7D5B]/10 bg-gradient-to-br from-[#2E7D5B]/5 to-transparent p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-7 h-7 rounded-lg bg-[#2E7D5B]/10 flex items-center justify-center">
                      <BookOpen size={13} className="text-[#2E7D5B]" />
                    </div>
                    <h3 className="font-semibold text-[#344453] text-sm">À lire ensuite</h3>
                  </div>
                  <div className="space-y-1.5">
                    {[
                      { href: "/formation", label: "Formation A-Z" },
                      { href: "/glossaire", label: "Glossaire financier" },
                      { href: "/thematiques", label: "Thématiques" },
                    ].map((link) => (
                      <Link key={link.href} href={link.href} className="flex items-center justify-between px-3 py-2 rounded-lg bg-white/3 hover:bg-white transition-colors group">
                        <span className="text-xs text-[#344453]/80 group-hover:text-[#344453]">{link.label}</span>
                        <ChevronRight size={12} className="text-[#344453]/75 group-hover:text-[#344453]/80" />
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  /* ─── HUB VIEW — TRADING TERMINAL ─── */
  return (
    <Layout>
      <div className="bg-white min-h-screen">
        {/* Hero — Trading Terminal */}
        <section className="relative overflow-hidden bg-gradient-to-br from-[#344453] via-[#2a3a47] to-[#1E1E1E]">          {/* Grid pattern background */}
          <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 39px, rgba(255,255,255,0.1) 39px, rgba(255,255,255,0.1) 40px), repeating-linear-gradient(90deg, transparent, transparent 39px, rgba(255,255,255,0.1) 39px, rgba(255,255,255,0.1) 40px)" }} />
          {/* Gradient overlays */}
          <div className="absolute top-0 left-0 w-96 h-96 bg-[#344453]/20 rounded-full blur-[120px]" />
          <div className="absolute bottom-0 right-0 w-80 h-80 bg-[#D4A853]/10 rounded-full blur-[100px]" />

          <div className="relative container py-16 lg:py-24">
            <PageBreadcrumb items={[{ label: "Outils", href: "/outils" }, { label: "Indicateurs de tendance" }]} className="mb-6" />
            <div className="max-w-3xl">
              <div className="flex items-center gap-3 mb-6">
                <span className="bg-[#D4A853]/10 border border-[#D4A853]/20 text-[#8A6E18] px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider">Encyclopédie</span>
                <span className="bg-white/15 border border-white/25 text-white/85 px-3 py-1.5 rounded-full text-xs font-medium">{INDICATORS.length} indicateurs</span>
              </div>
              <h1 className="text-2xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-[1.05] mb-5">
                Indicateurs
                <br />
                <span className="bg-gradient-to-r from-[#D4A853] to-[#E8C875] bg-clip-text text-transparent">Techniques</span>
              </h1>
              <p className="text-base md:text-lg text-white/85 max-w-xl leading-relaxed mb-10">
                Guide complet et pédagogique de {INDICATORS.length} indicateurs, classés par catégorie et niveau. Définition, interprétation, limites, cas pratique.
              </p>

              {/* Stats bar */}
              <div className="flex items-center divide-x divide-white/10">
                <HeroStat value={INDICATORS.length.toString()} label="Indicateurs" />
                <HeroStat value="8" label="Catégories" />
                <HeroStat value="3" label="Niveaux" />
                <HeroStat value={`${Math.round(INDICATORS.reduce((s, i) => s + i.readTime, 0) / 60)}h+`} label="De contenu" />
              </div>
            </div>
          </div>
        </section>

        {/* Search Bar — Floating */}
        <div className="container -mt-6 relative z-10">
          <div className="bg-white rounded-2xl border border-[#D0D5DA] p-4 shadow-2xl shadow-[#344453]/10">
            <div className="flex flex-col md:flex-row gap-3">
              <div className="flex-1 relative">
                <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#1E1E1E]/75" />
                <input
                  type="text"
                  placeholder="Rechercher un indicateur (RSI, MACD, Bollinger, Ichimoku...)"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-11 pr-4 py-3.5 rounded-xl bg-white border border-[#D0D5DA] focus:border-[#D4A853]/50 focus:ring-1 focus:ring-[#D4A853]/30 outline-none text-sm text-[#344453] placeholder:text-[#344453]/75"
                />
              </div>
              {(searchQuery || selectedCategory !== "all" || selectedLevel !== "all") && (
                <button onClick={resetFilters} className="flex items-center gap-2 px-4 py-3 rounded-xl text-sm text-[#344453]/75 hover:text-[#8A6E18] hover:bg-[#F4F5F5] transition-colors">
                  <RotateCcw size={14} /> Réinitialiser
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Category Pills */}
        <div className="container mt-6">
          <div className="flex gap-2 overflow-x-auto pb-2 sm:flex-wrap sm:overflow-visible scrollbar-hide">
            {CATEGORIES.map((cat) => {
              const isActive = selectedCategory === cat.key;
              return (
                <button
                  key={cat.key}
                  onClick={() => setSelectedCategory(cat.key)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-medium transition-all whitespace-nowrap ${
                    isActive
                      ? "bg-[#D4A853] text-[#344453] shadow-lg shadow-[#D4A853]/20"
                      : "bg-[#F4F5F5] text-[#344453]/80 hover:bg-[#E8EAED] hover:text-[#344453] border border-[#D0D5DA]"
                  }`}
                >
                  <cat.icon size={13} />
                  {cat.label}
                  <span className={isActive ? "opacity-70" : "opacity-30"}>({categoryCounts[cat.key] || 0})</span>
                </button>
              );
            })}
          </div>
          {/* Level pills */}
          <div className="flex gap-2 overflow-x-auto pb-2 sm:flex-wrap sm:overflow-visible mt-3 scrollbar-hide">
            <button
              onClick={() => setSelectedLevel("all")}
              className={`px-3 py-1.5 rounded-full text-[11px] font-medium transition-all ${selectedLevel === "all" ? "bg-[#344453]/10 text-[#344453]" : "bg-[#F4F5F5] text-[#1E1E1E]/75 hover:text-[#344453]/80"}`}
            >
              Tous niveaux
            </button>
            {(Object.keys(LEVEL_STYLES) as Level[]).map((level) => {
              const s = LEVEL_STYLES[level];
              return (
                <button
                  key={level}
                  onClick={() => setSelectedLevel(level)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-medium transition-all ${
                    selectedLevel === level ? `${s.bg} ${s.text} border ${s.border}` : "bg-[#F4F5F5] text-[#1E1E1E]/75 hover:text-[#344453]/80"
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />
                  {s.label} ({levelCounts[level] || 0})
                </button>
              );
            })}
          </div>
        </div>

        {/* Popular — Only when no filters */}
        {searchQuery === "" && selectedCategory === "all" && selectedLevel === "all" && (
          <div className="container mt-10">
            <h2 className="text-lg font-bold text-[#344453] mb-4 flex items-center gap-2">
              <Star size={18} className="text-[#8A6E18]" /> Les plus utilisés
            </h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {(!isAuthenticated || isPremium ? popularIndicators.slice(0, 8) : popularIndicators.slice(0, FREE_INDICATOR_LIMIT)).map((ind) => {
                const lvl = LEVEL_STYLES[ind.level];
                return (
                  <button key={ind.id} onClick={() => setSelectedIndicator(ind)} className="bg-white rounded-xl border border-[#D0D5DA] p-4 text-left hover:border-[#D4A853]/30 hover:shadow-lg hover:shadow-[#D4A853]/5 transition-all group">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`w-1.5 h-1.5 rounded-full ${lvl.dot}`} />
                      <span className={`text-[11px] font-medium ${lvl.text}`}>{lvl.label}</span>
                      <span className="text-[11px] text-[#344453]/75 ml-auto">{ind.readTime}m</span>
                    </div>
                    <h3 className="font-semibold text-[#344453] text-sm mb-1 group-hover:text-[#8A6E18] transition-colors">{ind.nameFr}</h3>
                    <p className="text-[11px] text-[#1E1E1E]/75 line-clamp-2">{ind.shortDesc}</p>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Results Grid */}
        <div className="container mt-10 pb-20">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-[#344453]">
              {searchQuery || selectedCategory !== "all" || selectedLevel !== "all"
                ? `${filteredIndicators.length} résultat${filteredIndicators.length > 1 ? "s" : ""}`
                : `Tous les indicateurs`}
            </h2>
            <span className="text-xs text-[#344453]/75 font-mono">{filteredIndicators.length}/{INDICATORS.length}</span>
          </div>

          {filteredIndicators.length === 0 ? (
            <div className="bg-white rounded-xl border border-[#D0D5DA] p-16 text-center">
              <Search size={40} className="text-[#344453]/75 mx-auto mb-4" />
              <p className="text-[#344453]/75 text-lg">Aucun indicateur trouvé</p>
              <button onClick={resetFilters} className="mt-4 text-[#8A6E18] text-sm font-medium hover:underline">Réinitialiser les filtres</button>
            </div>
          ) : (
            <>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {(!isAuthenticated || isPremium ? filteredIndicators : filteredIndicators.slice(0, FREE_INDICATOR_LIMIT)).map((ind) => {
                  const lvl = LEVEL_STYLES[ind.level];
                  const CatIcon = CATEGORY_ICONS[ind.category] || Layers;
                  return (
                    <motion.button
                      key={ind.id}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      onClick={() => setSelectedIndicator(ind)}
                      className="bg-white rounded-xl border border-[#D0D5DA] p-5 text-left hover:border-[#D4A853]/20 hover:shadow-xl hover:shadow-[#D4A853]/5 transition-all group relative overflow-hidden"
                    >
                      {/* Top accent line */}
                      <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r opacity-0 group-hover:opacity-100 transition-opacity" style={{ backgroundImage: `linear-gradient(to right, ${CATEGORIES.find(c => c.key === ind.category)?.color || "#344453"}, transparent)` }} />

                      <div className="flex items-center gap-2 mb-3">
                        <span className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold ${lvl.bg} ${lvl.text} border ${lvl.border}`}>
                          <span className={`w-1 h-1 rounded-full ${lvl.dot}`} />
                          {lvl.label}
                        </span>
                        <span className="flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-[#F4F5F5] text-[#344453]/75">
                          <CatIcon size={9} /> {CATEGORY_LABELS[ind.category]}
                        </span>
                      </div>
                      <h3 className="font-bold text-[#344453] text-sm mb-0.5 group-hover:text-[#8A6E18] transition-colors">{ind.nameFr}</h3>
                      <p className="text-[11px] text-[#344453]/75 font-mono mb-3">{ind.name}</p>
                      <p className="text-sm text-[#344453]/75 line-clamp-2 mb-4">{ind.shortDesc}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 text-[11px] text-[#344453]/75">
                          <span className="flex items-center gap-1"><Clock size={11} /> {ind.readTime}m</span>
                          <ComplexityBar level={ind.complexity} />
                        </div>
                        <ChevronRight size={14} className="text-[#344453]/80 group-hover:text-[#8A6E18]" />
                      </div>
                    </motion.button>
                  );
                })}
              </div>

              {/* CTA Premium */}
              {isAuthenticated && !isPremium && filteredIndicators.length > FREE_INDICATOR_LIMIT ? (
                <div className="mt-10 rounded-2xl border border-[#D4A853]/15 bg-gradient-to-br from-[#D4A853]/5 via-[#344453] to-transparent p-10 text-center">
                  <div className="w-16 h-16 rounded-xl bg-[#D4A853]/10 border border-[#D4A853]/20 flex items-center justify-center mx-auto mb-5">
                    <Crown size={28} className="text-[#8A6E18]" />
                  </div>
                  <h4 className="text-xl font-bold text-[#344453] mb-2">
                    {FREE_INDICATOR_LIMIT} indicateurs sur {filteredIndicators.length} affichés
                  </h4>
                  <p className="text-[#1E1E1E]/80 text-sm mb-6 max-w-md mx-auto">
                    Débloquez les {INDICATORS.length} fiches complètes avec définitions, interprétations multi-scénarios, limites et cas pratiques.
                  </p>
                  <Link
                    href="/pricing"
                    className="inline-flex items-center gap-2 px-7 py-3.5 bg-gradient-to-r from-[#D4A853] to-[#C49A4A] text-[#344453] font-bold rounded-xl hover:shadow-lg hover:shadow-[#D4A853]/20 transition-all text-sm"
                  >
                    Voir les offres
                  </Link>
                </div>
              ) : !isAuthenticated ? (
                <div className="mt-10 rounded-2xl border border-[#D4A853]/15 bg-gradient-to-br from-[#D4A853]/5 via-white to-[#344453]/5 p-10 text-center">
                  <div className="w-16 h-16 rounded-xl bg-[#D4A853]/10 border border-[#D4A853]/20 flex items-center justify-center mx-auto mb-5">
                    <Crown size={28} className="text-[#8A6E18]" />
                  </div>
                  <h4 className="text-xl font-bold text-[#344453] mb-2">
                    {INDICATORS.length} indicateurs techniques détaillés
                  </h4>
                  <p className="text-[#1E1E1E]/80 text-sm mb-6 max-w-md mx-auto">
                    Accédez à toutes les fiches complètes avec définitions, interprétations multi-scénarios, limites et cas pratiques dans votre espace membre.
                  </p>
                  <Link
                    href="/register"
                    className="inline-flex items-center gap-2 px-7 py-3.5 bg-gradient-to-r from-[#D4A853] to-[#C49A4A] text-[#344453] font-bold rounded-xl hover:shadow-lg hover:shadow-[#D4A853]/20 transition-all text-sm"
                  >
                    Créer un compte gratuit
                  </Link>
                </div>
              ) : null}
            </>
          )}
        </div>

        {/* Lead Magnet */}
        <section className="py-10 bg-gradient-to-r from-[#344453] to-[#2a3845] border-t border-[#D0D5DA]">
          <div className="container">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#D4A853]/10 flex items-center justify-center shrink-0">
                  <Sparkles size={22} className="text-[#8A6E18]" />
                </div>
                <div>
                  <p className="text-white font-bold text-base">Recevez le dernier Thème du Mois gratuitement</p>
                  <p className="text-white/75 text-sm">Inscrivez-vous et recevez une analyse sectorielle de 20+ slides, offerte.</p>
                </div>
              </div>
              <Link href="/register" className="inline-flex items-center gap-2 px-6 py-3 bg-[#D4A853] text-white font-bold rounded-lg hover:bg-[#D4A853]/90 transition-all text-sm whitespace-nowrap">
                Recevoir le Thème du Mois gratuit <ArrowRightIcon size={14} />
              </Link>
            </div>
          </div>
        </section>

        {/* Cross-sell */}
        <section className="py-16 lg:py-20 bg-gradient-to-br from-[#344453] via-[#2a3a47] to-[#1E1E1E] border-t border-[#D0D5DA]">
          <div className="container">
            <div className="max-w-5xl mx-auto text-center">
              <h2 className="text-2xl lg:text-3xl font-bold text-white mb-3">Complétez votre boîte à outils</h2>
              <p className="text-sm text-white/75 max-w-xl mx-auto mb-10">Les indicateurs techniques ne sont qu'une partie de l'équation.</p>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { href: "/formation", title: "Formation A-Z", desc: `${ACADEMY_CONFIG.moduleCount} modules pour maîtriser les marchés.`, color: "#344453" },
                  { href: "/glossaire", title: "Glossaire Premium", desc: `${GLOSSARY_CONFIG.termLabel} termes financiers expliqués.`, color: "#2E7D5B" },
                  { href: "/thematiques", title: "Thématiques", desc: "Analyses sectorielles avec scénarios.", color: "#D4A853" },
                  { href: "/quiz", title: "Quiz Interactifs", desc: "Testez vos connaissances.", color: "#C4A052" },
                ].map((item) => (
                  <Link key={item.href} href={item.href} className="group">
                    <div className="bg-white rounded-xl border border-[#D0D5DA] hover:border-white/25 transition-all text-left h-full overflow-hidden">
                      <div className="h-1 w-full" style={{ backgroundColor: item.color }} />
                      <div className="p-5">
                        <h3 className="text-sm font-semibold text-[#344453] mb-1.5 group-hover:text-[#8A6E18] transition-colors">{item.title}</h3>
                        <p className="text-xs text-[#344453]/75 leading-relaxed">{item.desc}</p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
}
