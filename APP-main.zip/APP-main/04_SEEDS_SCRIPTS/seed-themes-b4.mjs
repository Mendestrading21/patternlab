import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();
const conn = await mysql.createConnection(process.env.DATABASE_URL);

const [maxWl] = await conn.execute("SELECT MAX(id) as maxId FROM thematicWatchlists");
const [maxItem] = await conn.execute("SELECT MAX(id) as maxId FROM watchlistItems");
let wlId = Math.max(maxWl[0].maxId + 1, 43000);
let itemId = Math.max(maxItem[0].maxId + 1, 53000);
let sortOrder = 400;

const THEMES = [
  { slug: "intelligence-artificielle-defense", title: "IA Militaire & Defense Autonome", icon: "ShieldAlert", color: "#991B1B",
    thesis: "L'IA militaire transforme la defense avec drones autonomes, surveillance et decision assistee.",
    items: [
      { ticker: "LMT", name: "Lockheed Martin", sector: "Defense", mcap: "Mega", thesis: "Premier contractant defense US." },
      { ticker: "RTX", name: "RTX Corporation", sector: "Defense", mcap: "Mega", thesis: "Missiles, radars, moteurs avions." },
      { ticker: "NOC", name: "Northrop Grumman", sector: "Defense", mcap: "Large", thesis: "B-21 Raider, systemes spatiaux." },
      { ticker: "PLTR", name: "Palantir", sector: "Data/Defense", mcap: "Large", thesis: "Plateforme IA pour le renseignement." },
      { ticker: "KTOS", name: "Kratos Defense", sector: "Drones", mcap: "Mid", thesis: "Drones de combat autonomes." },
    ]
  },
  { slug: "satellites-connectivite", title: "Satellites & Connectivite Spatiale", icon: "Rocket", color: "#1D4ED8",
    thesis: "Les mega-constellations de satellites LEO revolutionnent la connectivite mondiale.",
    items: [
      { ticker: "RKLB", name: "Rocket Lab", sector: "Lanceur", mcap: "Mid", thesis: "Lanceur Electron et Neutron." },
      { ticker: "IRDM", name: "Iridium Communications", sector: "Satellite", mcap: "Mid", thesis: "Reseau satellite mondial." },
      { ticker: "GSAT", name: "Globalstar", sector: "Satellite", mcap: "Mid", thesis: "Partenariat Apple pour satellite." },
      { ticker: "VSAT", name: "Viasat", sector: "Satellite", mcap: "Mid", thesis: "Internet satellite haut debit." },
      { ticker: "LUNR", name: "Intuitive Machines", sector: "Lunaire", mcap: "Small", thesis: "Services de livraison lunaire." },
    ]
  },
  { slug: "paiements-digitaux", title: "Paiements Digitaux & BNPL", icon: "CreditCard", color: "#7C3AED",
    thesis: "Les paiements digitaux remplacent le cash. BNPL et wallets mobiles en forte adoption.",
    items: [
      { ticker: "V", name: "Visa", sector: "Reseau", mcap: "Mega", thesis: "Premier reseau de paiement mondial." },
      { ticker: "MA", name: "Mastercard", sector: "Reseau", mcap: "Mega", thesis: "Deuxieme reseau, forte croissance cross-border." },
      { ticker: "PYPL", name: "PayPal", sector: "Digital", mcap: "Large", thesis: "Leader paiements en ligne." },
      { ticker: "SQ", name: "Block (Square)", sector: "Fintech", mcap: "Large", thesis: "Cash App et Square pour PME." },
      { ticker: "AFRM", name: "Affirm", sector: "BNPL", mcap: "Mid", thesis: "Leader BNPL aux US." },
    ]
  },
  { slug: "neobanques-challenger", title: "Neobanques & Challenger Banks", icon: "Landmark", color: "#059669",
    thesis: "Les neobanques captent des parts de marche avec des experiences digitales superieures.",
    items: [
      { ticker: "NU", name: "Nu Holdings", sector: "Neobanque", mcap: "Large", thesis: "Plus grande neobanque mondiale." },
      { ticker: "SOFI", name: "SoFi Technologies", sector: "Fintech", mcap: "Mid", thesis: "Super-app financiere US." },
      { ticker: "LC", name: "LendingClub", sector: "Pret P2P", mcap: "Mid", thesis: "Plateforme pret en ligne." },
      { ticker: "UPST", name: "Upstart", sector: "AI Lending", mcap: "Mid", thesis: "Credit scoring par IA." },
      { ticker: "HOOD", name: "Robinhood", sector: "Trading", mcap: "Mid", thesis: "Trading zero commission, crypto." },
    ]
  },
  { slug: "defi-web3", title: "DeFi & Web3", icon: "Link", color: "#F59E0B",
    thesis: "La finance decentralisee et le Web3 creent de nouvelles primitives financieres sur blockchain.",
    items: [
      { ticker: "COIN", name: "Coinbase", sector: "Exchange", mcap: "Large", thesis: "Premier exchange crypto US regulee." },
      { ticker: "MSTR", name: "MicroStrategy", sector: "Bitcoin", mcap: "Large", thesis: "Plus grande reserve Bitcoin corporate." },
      { ticker: "SQ", name: "Block", sector: "Crypto/Fintech", mcap: "Large", thesis: "Cash App Bitcoin et TBD Web5." },
      { ticker: "MARA", name: "Marathon Digital", sector: "Mining BTC", mcap: "Mid", thesis: "Plus grand mineur Bitcoin US." },
      { ticker: "RIOT", name: "Riot Platforms", sector: "Mining BTC", mcap: "Mid", thesis: "Mining Bitcoin et infra." },
    ]
  },
  { slug: "automobile-autonome", title: "Conduite Autonome & ADAS", icon: "Car", color: "#0F766E",
    thesis: "La conduite autonome progresse avec l'IA et les capteurs. Robotaxis et ADAS en deploiement.",
    items: [
      { ticker: "TSLA", name: "Tesla", sector: "EV/Autonome", mcap: "Mega", thesis: "FSD et robotaxi en developpement." },
      { ticker: "GOOGL", name: "Alphabet (Waymo)", sector: "Robotaxi", mcap: "Mega", thesis: "Waymo leader robotaxi commercial." },
      { ticker: "MBLY", name: "Mobileye", sector: "ADAS", mcap: "Mid", thesis: "Leader systemes ADAS pour constructeurs." },
      { ticker: "LAZR", name: "Luminar Technologies", sector: "LiDAR", mcap: "Small", thesis: "LiDAR pour vehicules autonomes." },
      { ticker: "ON", name: "ON Semiconductor", sector: "Capteurs", mcap: "Large", thesis: "Capteurs d'image pour ADAS." },
    ]
  },
  { slug: "biocarburants-saf", title: "Biocarburants & SAF Aviation", icon: "Flame", color: "#B45309",
    thesis: "Les biocarburants durables (SAF) sont essentiels pour decarboner l'aviation. Mandats reglementaires.",
    items: [
      { ticker: "GEVO", name: "Gevo Inc.", sector: "SAF", mcap: "Small", thesis: "Producteur SAF a partir de biomasse." },
      { ticker: "REGI", name: "REX Energy", sector: "Biodiesel", mcap: "Small", thesis: "Biodiesel et diesel renouvelable." },
      { ticker: "DAR", name: "Darling Ingredients", sector: "Matieres grasses", mcap: "Mid", thesis: "Matieres premieres pour biocarburants." },
      { ticker: "ADM", name: "Archer-Daniels-Midland", sector: "Agro", mcap: "Large", thesis: "Geant agro-industriel, biocarburants." },
      { ticker: "NESTE", name: "Neste Oyj", sector: "Diesel renouv", mcap: "Large", thesis: "Leader mondial diesel renouvelable." },
    ]
  },
  { slug: "capture-carbone-ccs", title: "Capture de Carbone (CCS/DAC)", icon: "Leaf", color: "#166534",
    thesis: "La capture du carbone est necessaire pour atteindre le net-zero. Technologies DAC et CCS en emergence.",
    items: [
      { ticker: "OXY", name: "Occidental Petroleum", sector: "Petrole/DAC", mcap: "Large", thesis: "Investit massivement dans le DAC via 1PointFive." },
      { ticker: "LIN", name: "Linde", sector: "Gaz industriels", mcap: "Mega", thesis: "Solutions CCS pour industrie." },
      { ticker: "APD", name: "Air Products", sector: "Gaz industriels", mcap: "Large", thesis: "Projets CCS et hydrogene bleu." },
      { ticker: "BKR", name: "Baker Hughes", sector: "Services energie", mcap: "Large", thesis: "Technologies CCS pour petrole et gaz." },
      { ticker: "AKER", name: "Aker Carbon Capture", sector: "CCS", mcap: "Small", thesis: "Pure-play capture carbone." },
    ]
  },
  { slug: "restauration-rapide", title: "Restauration Rapide & QSR", icon: "ShoppingCart", color: "#DC2626",
    thesis: "Les chaines de restauration rapide beneficient du pricing power et de l'expansion internationale.",
    items: [
      { ticker: "MCD", name: "McDonald's", sector: "QSR", mcap: "Mega", thesis: "Leader mondial fast-food." },
      { ticker: "SBUX", name: "Starbucks", sector: "Cafe", mcap: "Large", thesis: "Leader mondial cafes premium." },
      { ticker: "CMG", name: "Chipotle", sector: "Fast-casual", mcap: "Large", thesis: "Fast-casual en forte croissance." },
      { ticker: "YUM", name: "Yum! Brands", sector: "QSR", mcap: "Large", thesis: "KFC, Pizza Hut, Taco Bell." },
      { ticker: "CAVA", name: "CAVA Group", sector: "Fast-casual", mcap: "Mid", thesis: "Fast-casual mediterraneen." },
    ]
  },
  { slug: "alcool-spiritueux", title: "Alcool & Spiritueux Premium", icon: "Gem", color: "#7C2D12",
    thesis: "La premiumisation des spiritueux et la croissance des marches emergents soutiennent le secteur.",
    items: [
      { ticker: "DEO", name: "Diageo", sector: "Spiritueux", mcap: "Large", thesis: "Johnnie Walker, Guinness, Tanqueray." },
      { ticker: "BF.B", name: "Brown-Forman", sector: "Whiskey", mcap: "Large", thesis: "Jack Daniel's, Woodford Reserve." },
      { ticker: "STZ", name: "Constellation Brands", sector: "Biere/Spirits", mcap: "Large", thesis: "Modelo, Corona, vins premium." },
      { ticker: "SAM", name: "Boston Beer", sector: "Craft beer", mcap: "Mid", thesis: "Samuel Adams, Truly hard seltzer." },
      { ticker: "TAP", name: "Molson Coors", sector: "Biere", mcap: "Mid", thesis: "Coors Light, Miller Lite." },
    ]
  },
  { slug: "cosmetique-beaute", title: "Cosmetique & Beaute", icon: "Heart", color: "#DB2777",
    thesis: "Le marche mondial de la beaute depasse 600Md$. Innovation, K-beauty et clean beauty.",
    items: [
      { ticker: "EL", name: "Estee Lauder", sector: "Beaute luxe", mcap: "Large", thesis: "Leader beaute premium mondiale." },
      { ticker: "ULTA", name: "Ulta Beauty", sector: "Retail beaute", mcap: "Large", thesis: "Leader retail beaute US." },
      { ticker: "COTY", name: "Coty Inc.", sector: "Beaute", mcap: "Mid", thesis: "CoverGirl, Burberry Beauty." },
      { ticker: "IPAR", name: "Inter Parfums", sector: "Parfums", mcap: "Mid", thesis: "Parfums sous licence marques luxe." },
      { ticker: "ELF", name: "e.l.f. Beauty", sector: "Beaute abordable", mcap: "Mid", thesis: "Beaute abordable en forte croissance." },
    ]
  },
  { slug: "sport-entertainment", title: "Sport & Entertainment Live", icon: "Globe", color: "#9333EA",
    thesis: "Le sport live et l'entertainment generent des revenus records. Droits TV, stades et experiences.",
    items: [
      { ticker: "LYV", name: "Live Nation", sector: "Concerts", mcap: "Large", thesis: "Leader mondial concerts et Ticketmaster." },
      { ticker: "DIS", name: "Walt Disney", sector: "Entertainment", mcap: "Large", thesis: "Parcs, ESPN, streaming." },
      { ticker: "DKNG", name: "DraftKings", sector: "Paris sportifs", mcap: "Mid", thesis: "Leader paris sportifs en ligne US." },
      { ticker: "FLUT", name: "Flutter Entertainment", sector: "Paris", mcap: "Large", thesis: "FanDuel, Betfair, leader mondial." },
      { ticker: "EDR", name: "Endeavor Group", sector: "Agence", mcap: "Large", thesis: "UFC, WME, IMG, droits sportifs." },
    ]
  },
  { slug: "mode-fast-fashion", title: "Mode & Fast Fashion", icon: "ShoppingCart", color: "#E11D48",
    thesis: "La mode rapide evolue vers le digital et la durabilite. E-commerce et resale en croissance.",
    items: [
      { ticker: "INDITEX", name: "Inditex (Zara)", sector: "Fast fashion", mcap: "Mega", thesis: "Leader mondial fast fashion." },
      { ticker: "TJX", name: "TJX Companies", sector: "Off-price", mcap: "Large", thesis: "Leader off-price retail." },
      { ticker: "GPS", name: "Gap Inc.", sector: "Casual", mcap: "Mid", thesis: "Gap, Old Navy, Banana Republic." },
      { ticker: "RVLV", name: "Revolve Group", sector: "E-commerce mode", mcap: "Small", thesis: "E-commerce mode millennials." },
      { ticker: "POSH", name: "Poshmark", sector: "Resale", mcap: "Small", thesis: "Plateforme revente mode." },
    ]
  },
  { slug: "cloud-securite-saas", title: "Cloud Security & SaaS Securite", icon: "Cloud", color: "#2563EB",
    thesis: "La securite cloud est le segment le plus dynamique de la cybersecurite. SASE et CNAPP en croissance.",
    items: [
      { ticker: "ZS", name: "Zscaler", sector: "SASE", mcap: "Large", thesis: "Leader Zero Trust cloud." },
      { ticker: "NET", name: "Cloudflare", sector: "Edge security", mcap: "Large", thesis: "CDN et securite edge." },
      { ticker: "CRWD", name: "CrowdStrike", sector: "XDR", mcap: "Large", thesis: "Plateforme securite cloud-native." },
      { ticker: "DDOG", name: "Datadog", sector: "Observabilite", mcap: "Large", thesis: "Monitoring et securite cloud." },
      { ticker: "OKTA", name: "Okta", sector: "Identite", mcap: "Mid", thesis: "Leader gestion identite cloud." },
    ]
  },
  { slug: "semiconducteurs-auto", title: "Semiconducteurs Automobiles", icon: "Cpu", color: "#0D9488",
    thesis: "Les vehicules modernes contiennent 3000+ puces. ADAS, infotainment et EV accelerent la demande.",
    items: [
      { ticker: "ON", name: "ON Semiconductor", sector: "Power/Capteurs", mcap: "Large", thesis: "SiC et capteurs pour EV et ADAS." },
      { ticker: "NXPI", name: "NXP Semiconductors", sector: "Auto semi", mcap: "Large", thesis: "Leader semi auto, radar et connectivity." },
      { ticker: "MCHP", name: "Microchip Technology", sector: "MCU", mcap: "Large", thesis: "Microcontroleurs pour automobile." },
      { ticker: "STM", name: "STMicroelectronics", sector: "Semi diversifie", mcap: "Large", thesis: "SiC pour EV, capteurs MEMS." },
      { ticker: "MBLY", name: "Mobileye", sector: "ADAS", mcap: "Mid", thesis: "Systemes vision ADAS." },
    ]
  },
  { slug: "internet-des-objets", title: "Internet des Objets (IoT)", icon: "Zap", color: "#7C3AED",
    thesis: "L'IoT connecte 30Md+ d'appareils. Smart home, industrie 4.0 et villes intelligentes.",
    items: [
      { ticker: "ANET", name: "Arista Networks", sector: "Networking", mcap: "Large", thesis: "Switches pour IoT et datacenter." },
      { ticker: "TER", name: "Teradyne", sector: "Test", mcap: "Large", thesis: "Test semi et robots collaboratifs." },
      { ticker: "SWKS", name: "Skyworks", sector: "RF", mcap: "Mid", thesis: "Puces RF pour IoT." },
      { ticker: "QRVO", name: "Qorvo", sector: "RF", mcap: "Mid", thesis: "Solutions RF pour IoT et 5G." },
      { ticker: "ST", name: "Sensata Technologies", sector: "Capteurs", mcap: "Mid", thesis: "Capteurs pour auto et industrie." },
    ]
  },
  { slug: "sante-femme", title: "Sante des Femmes (FemTech)", icon: "Heart", color: "#EC4899",
    thesis: "Le marche FemTech depasse 50Md$ d'ici 2030. Fertilite, menopause et sante reproductive.",
    items: [
      { ticker: "HOLX", name: "Hologic", sector: "Diagnostics", mcap: "Mid", thesis: "Leader diagnostics sante feminine." },
      { ticker: "HIMS", name: "Hims & Hers", sector: "Telehealth", mcap: "Mid", thesis: "Telemedecine sante feminine." },
      { ticker: "INMD", name: "InMode", sector: "Esthetique", mcap: "Mid", thesis: "Dispositifs esthetiques mini-invasifs." },
      { ticker: "IOVA", name: "Iovance Biotherapeutics", sector: "Oncologie", mcap: "Mid", thesis: "Therapie cellulaire cancers feminins." },
      { ticker: "GDRX", name: "GoodRx", sector: "Pharma digital", mcap: "Mid", thesis: "Acces medicaments abordables." },
    ]
  },
  { slug: "economie-circulaire", title: "Economie Circulaire & Upcycling", icon: "Leaf", color: "#15803D",
    thesis: "L'economie circulaire reduit les dechets et cree de la valeur. Recyclage, resale et remanufacturing.",
    items: [
      { ticker: "WM", name: "Waste Management", sector: "Recyclage", mcap: "Large", thesis: "Leader recyclage et gestion dechets." },
      { ticker: "TPIC", name: "TPI Composites", sector: "Recyclage", mcap: "Small", thesis: "Recyclage pales eoliennes." },
      { ticker: "REAL", name: "The RealReal", sector: "Luxe resale", mcap: "Small", thesis: "Revente luxe authentifie." },
      { ticker: "POSH", name: "Poshmark", sector: "Mode resale", mcap: "Small", thesis: "Plateforme revente mode." },
      { ticker: "RSG", name: "Republic Services", sector: "Recyclage", mcap: "Large", thesis: "Recyclage et valorisation dechets." },
    ]
  },
  { slug: "intelligence-artificielle-sante", title: "IA en Sante & Drug Discovery", icon: "Brain", color: "#7C3AED",
    thesis: "L'IA accelere la decouverte de medicaments et le diagnostic. Reduction des couts R&D de 30-50%.",
    items: [
      { ticker: "RXRX", name: "Recursion Pharmaceuticals", sector: "AI Drug", mcap: "Mid", thesis: "IA pour decouverte medicaments." },
      { ticker: "SDGR", name: "Schrodinger", sector: "Simulation", mcap: "Mid", thesis: "Simulation moleculaire par IA." },
      { ticker: "EXAI", name: "Exscientia", sector: "AI Drug", mcap: "Small", thesis: "IA pour conception de medicaments." },
      { ticker: "VEEV", name: "Veeva Systems", sector: "Cloud pharma", mcap: "Large", thesis: "Cloud pour industrie pharma." },
      { ticker: "ISRG", name: "Intuitive Surgical", sector: "Robot chirurgie", mcap: "Large", thesis: "IA integree dans chirurgie robotique." },
    ]
  },
  { slug: "micro-mobilite", title: "Micro-Mobilite & Mobilite Urbaine", icon: "Car", color: "#0891B2",
    thesis: "Trottinettes, velos electriques et mobilite partagee transforment les deplacements urbains.",
    items: [
      { ticker: "UBER", name: "Uber", sector: "Mobilite", mcap: "Large", thesis: "Super-app mobilite et livraison." },
      { ticker: "LYFT", name: "Lyft", sector: "VTC", mcap: "Mid", thesis: "VTC US, rentabilite en hausse." },
      { ticker: "GRAB", name: "Grab Holdings", sector: "Super-app", mcap: "Mid", thesis: "Super-app mobilite Asie du Sud-Est." },
      { ticker: "GOEV", name: "Canoo", sector: "EV urbain", mcap: "Small", thesis: "Vehicules electriques urbains." },
      { ticker: "LEV", name: "Lion Electric", sector: "Bus EV", mcap: "Small", thesis: "Bus et camions electriques." },
    ]
  },
  { slug: "assurance-parametrique", title: "InsurTech & Assurance Parametrique", icon: "ShieldCheck", color: "#6366F1",
    thesis: "L'InsurTech digitalise l'assurance. L'assurance parametrique automatise les indemnisations.",
    items: [
      { ticker: "LMND", name: "Lemonade", sector: "InsurTech", mcap: "Small", thesis: "Assurance IA-first pour millennials." },
      { ticker: "ROOT", name: "Root Inc.", sector: "Auto InsurTech", mcap: "Small", thesis: "Assurance auto basee sur la conduite." },
      { ticker: "OSCR", name: "Oscar Health", sector: "Sante", mcap: "Mid", thesis: "Assurance sante tech-first." },
      { ticker: "HIPO", name: "Hippo Holdings", sector: "Habitation", mcap: "Small", thesis: "Assurance habitation digitale." },
      { ticker: "KNSL", name: "Kinsale Capital", sector: "E&S", mcap: "Mid", thesis: "Assurance specialty tech-enabled." },
    ]
  },
  { slug: "bourse-emergente-frontier", title: "Marches Frontieres & Emergents", icon: "Globe", color: "#EA580C",
    thesis: "Les marches frontieres offrent une diversification et une croissance superieure. Vietnam, Nigeria, Bangladesh.",
    items: [
      { ticker: "FM", name: "iShares Frontier ETF", sector: "ETF Frontier", mcap: "Small", thesis: "ETF marches frontieres." },
      { ticker: "VWO", name: "Vanguard Emerging Markets", sector: "ETF EM", mcap: "Large", thesis: "ETF reference emergents." },
      { ticker: "MELI", name: "MercadoLibre", sector: "E-commerce LatAm", mcap: "Large", thesis: "Amazon d'Amerique latine." },
      { ticker: "SE", name: "Sea Limited", sector: "Tech SEA", mcap: "Mid", thesis: "E-commerce et gaming Asie du Sud-Est." },
      { ticker: "GRAB", name: "Grab Holdings", sector: "Super-app", mcap: "Mid", thesis: "Super-app Asie du Sud-Est." },
    ]
  },
  { slug: "obligations-high-yield", title: "Obligations High Yield & Credit", icon: "Coins", color: "#B91C1C",
    thesis: "Les obligations high yield offrent des rendements attractifs dans un environnement de taux eleves.",
    items: [
      { ticker: "HYG", name: "iShares High Yield ETF", sector: "ETF HY", mcap: "Large", thesis: "ETF reference high yield US." },
      { ticker: "JNK", name: "SPDR High Yield ETF", sector: "ETF HY", mcap: "Large", thesis: "ETF high yield diversifie." },
      { ticker: "BKLN", name: "Invesco Senior Loan ETF", sector: "ETF Loans", mcap: "Mid", thesis: "ETF prets senior a taux variable." },
      { ticker: "EMB", name: "iShares EM Bond ETF", sector: "ETF EM Debt", mcap: "Large", thesis: "ETF dette emergente." },
      { ticker: "VCIT", name: "Vanguard Corp Bond ETF", sector: "ETF IG", mcap: "Large", thesis: "ETF obligations investment grade." },
    ]
  },
  { slug: "tresorerie-money-market", title: "Tresorerie & Money Market", icon: "Landmark", color: "#475569",
    thesis: "Les fonds monetaires et bons du Tresor offrent des rendements 5%+ avec risque minimal.",
    items: [
      { ticker: "BIL", name: "SPDR T-Bill ETF", sector: "ETF T-Bills", mcap: "Large", thesis: "ETF bons du Tresor US court terme." },
      { ticker: "SHV", name: "iShares Short Treasury", sector: "ETF Treasury", mcap: "Large", thesis: "ETF Tresor US ultra-court." },
      { ticker: "SGOV", name: "iShares 0-3M Treasury", sector: "ETF T-Bills", mcap: "Large", thesis: "ETF T-Bills 0-3 mois." },
      { ticker: "USFR", name: "WisdomTree Floating Rate", sector: "ETF Float", mcap: "Mid", thesis: "ETF taux variable US." },
      { ticker: "FLOT", name: "iShares Floating Rate", sector: "ETF Float", mcap: "Mid", thesis: "ETF obligations taux variable." },
    ]
  },
  { slug: "volatilite-hedging", title: "Volatilite & Strategies de Couverture", icon: "AlertTriangle", color: "#DC2626",
    thesis: "Les instruments de volatilite permettent de se couvrir contre les baisses de marche.",
    items: [
      { ticker: "VIXY", name: "ProShares VIX Short-Term", sector: "ETF VIX", mcap: "Small", thesis: "ETF sur futures VIX court terme." },
      { ticker: "UVXY", name: "ProShares Ultra VIX", sector: "ETF VIX 2x", mcap: "Small", thesis: "ETF VIX leveraged 2x." },
      { ticker: "TAIL", name: "Cambria Tail Risk ETF", sector: "ETF Tail Risk", mcap: "Small", thesis: "ETF protection tail risk." },
      { ticker: "SH", name: "ProShares Short S&P 500", sector: "ETF Inverse", mcap: "Mid", thesis: "ETF inverse S&P 500." },
      { ticker: "GLD", name: "SPDR Gold Trust", sector: "ETF Or", mcap: "Large", thesis: "ETF or physique, valeur refuge." },
    ]
  },
];

for (const theme of THEMES) {
  const itemCount = theme.items.length;
  await conn.execute(
    `INSERT INTO thematicWatchlists (id, slug, title, thesis, icon, color, whatToWatch, themeRisks, itemCount, sortOrder, isActive) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`,
    [wlId, theme.slug, theme.title, theme.thesis, theme.icon, theme.color,
     JSON.stringify(["Suivre les resultats trimestriels", "Surveiller les changements reglementaires", "Analyser les flux institutionnels"]),
     JSON.stringify(["Risque de valorisation elevee", "Risque reglementaire", "Risque de concentration sectorielle", "Risque de liquidite", "Risque macro-economique"]),
     itemCount, sortOrder]
  );
  for (const item of theme.items) {
    await conn.execute(
      `INSERT INTO watchlistItems (id, watchlistId, name, ticker, sector, marketCapRange, whyItMatters, catalysts, risks, sortOrder) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [itemId, wlId, item.name, item.ticker, item.sector, item.mcap, item.thesis,
       JSON.stringify(["Resultats trimestriels", "Guidance forward", "Mouvements institutionnels"]),
       JSON.stringify(["Valorisation", "Competition", "Regulation"]),
       itemId - 53000]
    );
    itemId++;
  }
  wlId++;
  sortOrder++;
  console.log(`  + ${theme.title} (${itemCount} items)`);
}

console.log(`\nBatch 4 done. ${THEMES.length} themes added.`);
const [total] = await conn.execute("SELECT COUNT(*) as cnt FROM thematicWatchlists");
const [totalItems] = await conn.execute("SELECT COUNT(*) as cnt FROM watchlistItems");
console.log(`Total themes: ${total[0].cnt}, Total items: ${totalItems[0].cnt}`);
await conn.end();
