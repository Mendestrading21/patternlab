/**
 * Script to trigger the weekly announcement email (S14) to all recipients.
 * Run with: npx tsx scripts/send-weekly-now.ts
 */
import { sendWeeklyAnnouncementToAll } from "../server/jobs/newsletter";

async function main() {
  console.log("[Script] Sending weekly announcement S14 to all recipients...");
  
  try {
    const result = await sendWeeklyAnnouncementToAll();
    console.log("[Script] ✅ Done!");
    console.log(`  Total recipients: ${result.totalRecipients}`);
    console.log(`  Sent: ${result.sent}`);
    console.log(`  Failed: ${result.failed}`);
    console.log(`  Subject: ${result.subject}`);
  } catch (err) {
    console.error("[Script] ❌ Error:", err);
  }
  
  process.exit(0);
}

main();
