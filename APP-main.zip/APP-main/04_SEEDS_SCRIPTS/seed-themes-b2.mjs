import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();
const conn = await mysql.createConnection(process.env.DATABASE_URL);

const [maxWl] = await conn.execute("SELECT MAX(id) as maxId FROM thematicWatchlists");
const [maxItem] = await conn.execute("SELECT MAX(id) as maxId FROM watchlistItems");
let wlId = Math.max(maxWl[0].maxId + 1, 41000);
let itemId = Math.max(maxItem[0].maxId + 1, 51000);
let sortOrder = 200;

const THEMES = [
  { slug: "metaverse-xr", title: "Metaverse & Realite Etendue (XR)", icon: "Globe", color: "#A855F7",
    thesis: "Convergence VR, AR et spatial computing pour gaming, entreprise et education.",
    items: [
      { ticker: "META", name: "Meta Platforms", sector: "Social/VR", mcap: "Mega", thesis: "Reality Labs et metaverse social." },
      { ticker: "U", name: "Unity Software", sector: "Moteur 3D", mcap: "Mid", thesis: "Moteur 3D dominant pour XR." },
      { ticker: "SNAP", name: "Snap Inc.", sector: "AR Social", mcap: "Mid", thesis: "Pioneer realite augmentee sociale." },
      { ticker: "QCOM", name: "Qualcomm", sector: "Puces XR", mcap: "Large", thesis: "Snapdragon XR pour casques." },
      { ticker: "MVIS", name: "MicroVision", sector: "LiDAR/AR", mcap: "Small", thesis: "Technologie LiDAR et affichage AR." },
    ]
  },
  { slug: "generative-ai-llm", title: "IA Generative & LLM", icon: "Brain", color: "#EC4899",
    thesis: "Les LLM transforment productivite et creation de contenu. Marche estime a 1.3T$ d'ici 2032.",
    items: [
      { ticker: "MSFT", name: "Microsoft", sector: "Cloud/AI", mcap: "Mega", thesis: "Partenariat OpenAI, Copilot integre." },
      { ticker: "GOOGL", name: "Alphabet", sector: "Search/AI", mcap: "Mega", thesis: "Gemini et DeepMind." },
      { ticker: "NVDA", name: "NVIDIA", sector: "GPU/AI", mcap: "Mega", thesis: "Infrastructure GPU pour entrainement." },
      { ticker: "CRM", name: "Salesforce", sector: "CRM/AI", mcap: "Large", thesis: "Einstein AI et agents autonomes." },
      { ticker: "PLTR", name: "Palantir", sector: "Data/AI", mcap: "Large", thesis: "AIP pour decisions operationnelles." },
    ]
  },
  { slug: "data-centers-infra", title: "Data Centers & Infrastructure Cloud", icon: "Server", color: "#0EA5E9",
    thesis: "L'explosion de l'IA necessite des investissements massifs en data centers. Marche mondial 300Md$+.",
    items: [
      { ticker: "EQIX", name: "Equinix", sector: "REIT DC", mcap: "Large", thesis: "Plus grand operateur mondial de DC." },
      { ticker: "DLR", name: "Digital Realty", sector: "REIT DC", mcap: "Large", thesis: "Portefeuille mondial colocation." },
      { ticker: "VRT", name: "Vertiv Holdings", sector: "Cooling", mcap: "Large", thesis: "Refroidissement pour data centers." },
      { ticker: "PSTG", name: "Pure Storage", sector: "Stockage", mcap: "Mid", thesis: "Stockage flash pour workloads AI." },
      { ticker: "SMCI", name: "Super Micro", sector: "Serveurs", mcap: "Mid", thesis: "Serveurs GPU optimises IA." },
    ]
  },
  { slug: "telecom-5g", title: "5G & Telecommunications", icon: "Zap", color: "#14B8A6",
    thesis: "Deploiement mondial 5G avec cas d'usage industriels. Marche 700Md$ d'ici 2030.",
    items: [
      { ticker: "T", name: "AT&T", sector: "Telecom", mcap: "Large", thesis: "Deploiement 5G massif US." },
      { ticker: "VZ", name: "Verizon", sector: "Telecom", mcap: "Large", thesis: "Leader 5G mmWave et C-Band." },
      { ticker: "ERIC", name: "Ericsson", sector: "Equipement", mcap: "Large", thesis: "Infrastructure reseau 5G mondial." },
      { ticker: "NOK", name: "Nokia", sector: "Equipement", mcap: "Mid", thesis: "Solutions 5G et private networks." },
      { ticker: "MRVL", name: "Marvell Technology", sector: "Semi 5G", mcap: "Large", thesis: "Puces custom infra 5G." },
    ]
  },
  { slug: "gaming-esport", title: "Gaming & Esport", icon: "Rocket", color: "#F43F5E",
    thesis: "Industrie du jeu video 200Md$+ de revenus. Cloud gaming, mobile et esport en croissance.",
    items: [
      { ticker: "TTWO", name: "Take-Two Interactive", sector: "Editeur", mcap: "Large", thesis: "GTA VI, franchise NBA 2K." },
      { ticker: "EA", name: "Electronic Arts", sector: "Editeur", mcap: "Large", thesis: "EA Sports FC, Apex Legends." },
      { ticker: "RBLX", name: "Roblox", sector: "Plateforme", mcap: "Mid", thesis: "Gaming social pour Gen Z." },
      { ticker: "SE", name: "Sea Limited", sector: "Gaming Asie", mcap: "Mid", thesis: "Garena domine le mobile en Asie." },
      { ticker: "NTES", name: "NetEase", sector: "Gaming Chine", mcap: "Large", thesis: "Deuxieme editeur chinois." },
    ]
  },
  { slug: "medtech-devices", title: "MedTech & Dispositifs Medicaux", icon: "Heart", color: "#EF4444",
    thesis: "Innovation en chirurgie robotique, diagnostics IA et wearables transforme les soins.",
    items: [
      { ticker: "ISRG", name: "Intuitive Surgical", sector: "Chirurgie robot", mcap: "Large", thesis: "Leader chirurgie robotique da Vinci." },
      { ticker: "ABT", name: "Abbott Laboratories", sector: "Diagnostics", mcap: "Mega", thesis: "FreeStyle Libre et diagnostics." },
      { ticker: "SYK", name: "Stryker", sector: "Orthopedie", mcap: "Large", thesis: "Implants et robot Mako." },
      { ticker: "DXCM", name: "DexCom", sector: "CGM", mcap: "Large", thesis: "Surveillance continue du glucose." },
      { ticker: "HOLX", name: "Hologic", sector: "Diagnostics", mcap: "Mid", thesis: "Diagnostics moleculaires." },
    ]
  },
  { slug: "genomique-crispr", title: "Genomique & Edition Genetique", icon: "Atom", color: "#D946EF",
    thesis: "CRISPR et therapies geniques ouvrent une nouvelle ere medicale. Marche 30Md$ d'ici 2030.",
    items: [
      { ticker: "CRSP", name: "CRISPR Therapeutics", sector: "Gene editing", mcap: "Mid", thesis: "Casgevy approuve, pipeline oncologie." },
      { ticker: "NTLA", name: "Intellia Therapeutics", sector: "Gene editing", mcap: "Mid", thesis: "Therapies in vivo CRISPR." },
      { ticker: "BEAM", name: "Beam Therapeutics", sector: "Base editing", mcap: "Small", thesis: "Edition de bases precises." },
      { ticker: "ILMN", name: "Illumina", sector: "Sequencage", mcap: "Large", thesis: "Leader mondial sequencage ADN." },
      { ticker: "PACB", name: "PacBio", sector: "Sequencage", mcap: "Small", thesis: "Sequencage long-read." },
    ]
  },
  { slug: "cannabis-legal", title: "Cannabis Legal & Regulation", icon: "Leaf", color: "#65A30D",
    thesis: "Legalisation progressive du cannabis aux US et en Europe cree un marche reglemente.",
    items: [
      { ticker: "TLRY", name: "Tilray Brands", sector: "Cannabis", mcap: "Mid", thesis: "Leader mondial cannabis." },
      { ticker: "CGC", name: "Canopy Growth", sector: "Cannabis", mcap: "Small", thesis: "Partenariat Constellation Brands." },
      { ticker: "CRON", name: "Cronos Group", sector: "Cannabis", mcap: "Small", thesis: "Adosse a Altria." },
      { ticker: "CURLF", name: "Curaleaf Holdings", sector: "MSO US", mcap: "Mid", thesis: "Plus grand MSO americain." },
      { ticker: "GTBIF", name: "Green Thumb Industries", sector: "MSO US", mcap: "Mid", thesis: "MSO rentable multi-etats." },
    ]
  },
  { slug: "lithium-terres-rares", title: "Lithium & Terres Rares", icon: "Mountain", color: "#F59E0B",
    thesis: "Transition energetique depend du lithium et terres rares. Enjeu geopolitique majeur.",
    items: [
      { ticker: "ALB", name: "Albemarle", sector: "Lithium", mcap: "Large", thesis: "Premier producteur mondial lithium." },
      { ticker: "SQM", name: "SQM", sector: "Lithium", mcap: "Mid", thesis: "Producteur chilien lithium et iode." },
      { ticker: "LAC", name: "Lithium Americas", sector: "Lithium", mcap: "Small", thesis: "Projet Thacker Pass, plus grande mine US." },
      { ticker: "MP", name: "MP Materials", sector: "Terres rares", mcap: "Mid", thesis: "Seul producteur terres rares US." },
      { ticker: "PLL", name: "Piedmont Lithium", sector: "Lithium", mcap: "Small", thesis: "Projet lithium en Caroline du Nord." },
    ]
  },
  { slug: "hydrogene-vert", title: "Hydrogene Vert & Piles a Combustible", icon: "Flame", color: "#06B6D4",
    thesis: "Hydrogene vert pilier de la decarbonation industrielle. IRA et EU Green Deal accelerent.",
    items: [
      { ticker: "PLUG", name: "Plug Power", sector: "H2 vert", mcap: "Mid", thesis: "Solutions hydrogene integrees." },
      { ticker: "BLDP", name: "Ballard Power", sector: "Piles", mcap: "Small", thesis: "Piles a combustible transport lourd." },
      { ticker: "BE", name: "Bloom Energy", sector: "SOFC", mcap: "Mid", thesis: "Serveurs energetiques pile solide." },
      { ticker: "FCEL", name: "FuelCell Energy", sector: "Piles", mcap: "Small", thesis: "Centrales pile a combustible." },
      { ticker: "APD", name: "Air Products", sector: "Gaz indus", mcap: "Large", thesis: "Leader gaz industriels, investit H2 vert." },
    ]
  },
  { slug: "infrastructure-us", title: "Infrastructure Americaine & IIJA", icon: "Building", color: "#78716C",
    thesis: "Plan IIJA 1.2T$ finance renovation routes, ponts, reseaux electriques et broadband.",
    items: [
      { ticker: "CAT", name: "Caterpillar", sector: "Equipement BTP", mcap: "Mega", thesis: "Leader mondial engins construction." },
      { ticker: "VMC", name: "Vulcan Materials", sector: "Agregats", mcap: "Large", thesis: "Premier producteur agregats US." },
      { ticker: "MLM", name: "Martin Marietta", sector: "Materiaux", mcap: "Large", thesis: "Materiaux construction infrastructures." },
      { ticker: "PWR", name: "Quanta Services", sector: "Services infra", mcap: "Large", thesis: "Construction infra electriques." },
      { ticker: "URI", name: "United Rentals", sector: "Location", mcap: "Large", thesis: "Plus grand loueur equipements." },
    ]
  },
  { slug: "private-equity-alt", title: "Private Equity & Alternatives", icon: "Briefcase", color: "#1E3A5F",
    thesis: "Gestionnaires d'actifs alternatifs beneficient de la democratisation du PE. AUM en croissance.",
    items: [
      { ticker: "BX", name: "Blackstone", sector: "PE/Immo", mcap: "Mega", thesis: "Plus grand gestionnaire alternatifs." },
      { ticker: "KKR", name: "KKR & Co", sector: "PE/Credit", mcap: "Large", thesis: "Pioneer LBO, diversifie credit." },
      { ticker: "APO", name: "Apollo Global", sector: "Credit prive", mcap: "Large", thesis: "Leader credit prive." },
      { ticker: "ARES", name: "Ares Management", sector: "Credit", mcap: "Large", thesis: "Specialiste credit direct." },
      { ticker: "CG", name: "Carlyle Group", sector: "PE global", mcap: "Large", thesis: "PE global defense et aero." },
    ]
  },
  { slug: "dividendes-aristocrates", title: "Dividendes Aristocrates", icon: "Coins", color: "#CA8A04",
    thesis: "Dividend Aristocrats: 25+ annees de hausses consecutives. Strategie defensive et revenus passifs.",
    items: [
      { ticker: "JNJ", name: "Johnson & Johnson", sector: "Pharma", mcap: "Mega", thesis: "62 ans de hausses dividendes." },
      { ticker: "PG", name: "Procter & Gamble", sector: "Conso", mcap: "Mega", thesis: "68 ans de hausses." },
      { ticker: "KO", name: "Coca-Cola", sector: "Boissons", mcap: "Mega", thesis: "62 ans de hausses." },
      { ticker: "MMM", name: "3M Company", sector: "Industriel", mcap: "Large", thesis: "Conglomerat diversifie." },
      { ticker: "CL", name: "Colgate-Palmolive", sector: "Hygiene", mcap: "Large", thesis: "61 ans de hausses." },
    ]
  },
  { slug: "small-caps-russell", title: "Small Caps US & Russell 2000", icon: "TrendingUp", color: "#F97316",
    thesis: "Small caps US sous-evaluees vs large caps. Rattrapage possible si taux baissent.",
    items: [
      { ticker: "IWM", name: "iShares Russell 2000", sector: "ETF", mcap: "Large", thesis: "ETF reference small caps US." },
      { ticker: "CELH", name: "Celsius Holdings", sector: "Boissons", mcap: "Mid", thesis: "Boissons energetiques en croissance." },
      { ticker: "CAVA", name: "CAVA Group", sector: "Restauration", mcap: "Mid", thesis: "Fast-casual mediterraneen." },
      { ticker: "DUOL", name: "Duolingo", sector: "EdTech", mcap: "Mid", thesis: "App langues, monetisation en hausse." },
      { ticker: "HIMS", name: "Hims & Hers Health", sector: "Telehealth", mcap: "Mid", thesis: "Telemedecine et bien-etre." },
    ]
  },
  { slug: "semiconducteurs-avances", title: "Semiconducteurs Avances", icon: "Cpu", color: "#6366F1",
    thesis: "Les puces avancees (3nm, 2nm) sont au coeur de l'IA, du HPC et de l'automobile.",
    items: [
      { ticker: "TSM", name: "TSMC", sector: "Fonderie", mcap: "Mega", thesis: "Fondeur dominant mondial." },
      { ticker: "ASML", name: "ASML Holding", sector: "Litho EUV", mcap: "Mega", thesis: "Monopole sur la lithographie EUV." },
      { ticker: "AVGO", name: "Broadcom", sector: "Semi diversifie", mcap: "Mega", thesis: "Puces custom AI et networking." },
      { ticker: "AMD", name: "AMD", sector: "CPU/GPU", mcap: "Large", thesis: "Alternative credible a NVIDIA." },
      { ticker: "INTC", name: "Intel", sector: "IDM", mcap: "Large", thesis: "Restructuration et fonderie US." },
    ]
  },
  { slug: "sante-mentale-digital", title: "Sante Mentale & Digital Health", icon: "Heart", color: "#F472B6",
    thesis: "La sante mentale devient priorite mondiale. Les plateformes digitales democratisent l'acces aux soins.",
    items: [
      { ticker: "TDOC", name: "Teladoc Health", sector: "Telehealth", mcap: "Mid", thesis: "Leader telemedecine et sante mentale." },
      { ticker: "HIMS", name: "Hims & Hers", sector: "Bien-etre", mcap: "Mid", thesis: "Telemedecine et prescriptions en ligne." },
      { ticker: "AMWL", name: "Amwell", sector: "Telehealth", mcap: "Small", thesis: "Plateforme telemedecine pour hopitaux." },
      { ticker: "GDRX", name: "GoodRx", sector: "Pharma digital", mcap: "Mid", thesis: "Comparateur prix medicaments." },
      { ticker: "OSCR", name: "Oscar Health", sector: "Assurance", mcap: "Mid", thesis: "Assurance sante tech-first." },
    ]
  },
  { slug: "proptech-immobilier", title: "PropTech & Innovation Immobiliere", icon: "Building", color: "#0891B2",
    thesis: "La technologie transforme l'immobilier: iBuying, gestion locative, construction modulaire.",
    items: [
      { ticker: "ZG", name: "Zillow Group", sector: "Portail immo", mcap: "Mid", thesis: "Plus grand portail immobilier US." },
      { ticker: "RDFN", name: "Redfin", sector: "Courtage tech", mcap: "Small", thesis: "Courtage immobilier technologique." },
      { ticker: "OPEN", name: "Opendoor", sector: "iBuying", mcap: "Small", thesis: "Achat/vente immobilier instantane." },
      { ticker: "CSGP", name: "CoStar Group", sector: "Data immo", mcap: "Large", thesis: "Donnees et analytics immobilier commercial." },
      { ticker: "ABNB", name: "Airbnb", sector: "Location courte", mcap: "Large", thesis: "Leader mondial location courte duree." },
    ]
  },
  { slug: "cleantech-carbone", title: "CleanTech & Marche du Carbone", icon: "Leaf", color: "#059669",
    thesis: "Les credits carbone et technologies propres creent un nouveau marche. Objectif net-zero 2050.",
    items: [
      { ticker: "ENPH", name: "Enphase Energy", sector: "Solaire", mcap: "Mid", thesis: "Micro-onduleurs solaires leader." },
      { ticker: "SEDG", name: "SolarEdge", sector: "Solaire", mcap: "Mid", thesis: "Optimiseurs et onduleurs solaires." },
      { ticker: "RUN", name: "Sunrun", sector: "Solaire residentiel", mcap: "Mid", thesis: "Leader solaire residentiel US." },
      { ticker: "KRBN", name: "KraneShares Carbon ETF", sector: "ETF Carbone", mcap: "Small", thesis: "ETF credits carbone europeens." },
      { ticker: "NEE", name: "NextEra Energy", sector: "Renouvelable", mcap: "Mega", thesis: "Plus grand producteur eolien/solaire." },
    ]
  },
  { slug: "transport-logistique", title: "Transport & Logistique Intelligente", icon: "ShoppingCart", color: "#7C3AED",
    thesis: "L'automatisation et l'IA transforment la supply chain. Drones, robots et vehicules autonomes.",
    items: [
      { ticker: "UPS", name: "United Parcel Service", sector: "Colis", mcap: "Large", thesis: "Leader mondial livraison colis." },
      { ticker: "FDX", name: "FedEx", sector: "Express", mcap: "Large", thesis: "Logistique express et supply chain." },
      { ticker: "XPO", name: "XPO Inc.", sector: "LTL", mcap: "Mid", thesis: "Transport LTL en croissance." },
      { ticker: "UBER", name: "Uber Technologies", sector: "Mobilite", mcap: "Large", thesis: "Mobilite et livraison a la demande." },
      { ticker: "GXO", name: "GXO Logistics", sector: "3PL", mcap: "Mid", thesis: "Leader logistique contractuelle." },
    ]
  },
  { slug: "alimentation-saine", title: "Alimentation Saine & Proteines Alt", icon: "Wheat", color: "#84CC16",
    thesis: "La demande pour une alimentation plus saine et durable croit. Proteines alternatives et bio.",
    items: [
      { ticker: "BYND", name: "Beyond Meat", sector: "Proteines alt", mcap: "Small", thesis: "Pioneer des proteines vegetales." },
      { ticker: "HAIN", name: "Hain Celestial", sector: "Bio/Naturel", mcap: "Small", thesis: "Marques alimentaires naturelles." },
      { ticker: "OTLY", name: "Oatly Group", sector: "Lait vegetal", mcap: "Small", thesis: "Leader mondial lait d'avoine." },
      { ticker: "SFM", name: "Sprouts Farmers", sector: "Distribution", mcap: "Mid", thesis: "Supermarches bio et naturels." },
      { ticker: "VITL", name: "Vital Farms", sector: "Oeufs premium", mcap: "Small", thesis: "Oeufs ethiques et premium." },
    ]
  },
];

for (const theme of THEMES) {
  const itemCount = theme.items.length;
  await conn.execute(
    `INSERT INTO thematicWatchlists (id, slug, title, thesis, icon, color, whatToWatch, themeRisks, itemCount, sortOrder, isActive) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`,
    [wlId, theme.slug, theme.title, theme.thesis, theme.icon, theme.color,
     JSON.stringify(["Suivre les resultats trimestriels", "Surveiller les changements reglementaires", "Analyser les flux institutionnels"]),
     JSON.stringify(["Risque de valorisation elevee", "Risque reglementaire", "Risque de concentration sectorielle", "Risque de liquidite", "Risque macro-economique"]),
     itemCount, sortOrder]
  );
  for (const item of theme.items) {
    await conn.execute(
      `INSERT INTO watchlistItems (id, watchlistId, name, ticker, sector, marketCapRange, whyItMatters, catalysts, risks, sortOrder) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [itemId, wlId, item.name, item.ticker, item.sector, item.mcap, item.thesis,
       JSON.stringify(["Resultats trimestriels", "Guidance forward", "Mouvements institutionnels"]),
       JSON.stringify(["Valorisation", "Competition", "Regulation"]),
       itemId - 51000]
    );
    itemId++;
  }
  wlId++;
  sortOrder++;
  console.log(`  + ${theme.title} (${itemCount} items)`);
}

console.log(`\nBatch 2 done. ${THEMES.length} themes added.`);
const [total] = await conn.execute("SELECT COUNT(*) as cnt FROM thematicWatchlists");
console.log(`Total themes now: ${total[0].cnt}`);
await conn.end();
