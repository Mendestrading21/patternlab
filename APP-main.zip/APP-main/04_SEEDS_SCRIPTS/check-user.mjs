import 'dotenv/config';
import { createConnection } from 'mysql2/promise';

const conn = await createConnection({
  uri: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: true }
});

// Check user elio_mendes@hotmail.com
const [users] = await conn.execute(
  'SELECT id, email, name, role, subscription_status, subscription_plan, subscription_active, stripe_customer_id, stripe_subscription_id, email_verified, auth_provider, login_method, onboarding_step, created_at, updated_at FROM users WHERE email = ?',
  ['elio_mendes@hotmail.com']
);
console.log('=== USER elio_mendes@hotmail.com ===');
if (users.length === 0) {
  console.log('NOT FOUND in users table!');
} else {
  for (const u of users) {
    console.log(JSON.stringify(u, null, 2));
  }
}

// Check newsletter subscriber
const [subs] = await conn.execute(
  'SELECT * FROM newsletter_subscribers WHERE email = ?',
  ['elio_mendes@hotmail.com']
);
console.log('\n=== NEWSLETTER SUBSCRIBER elio_mendes@hotmail.com ===');
if (subs.length === 0) {
  console.log('NOT FOUND in newsletter_subscribers table!');
} else {
  for (const s of subs) {
    console.log(JSON.stringify(s, null, 2));
  }
}

// Check ALL users to see the full picture
const [allUsers] = await conn.execute(
  'SELECT id, email, name, subscription_plan, subscription_active, stripe_customer_id, stripe_subscription_id, created_at FROM users ORDER BY created_at DESC LIMIT 10'
);
console.log('\n=== ALL RECENT USERS ===');
for (const u of allUsers) {
  console.log(JSON.stringify(u));
}

await conn.end();
