/**
 * Seed additional quiz questions to reach 30+ per theme
 * Current: marches=30, indicateurs=29, glossaire=30, formation=29, etfs=29 → Total 147
 * Need: ~10 more per theme (especially difficile level)
 */
import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

const NEW_QUESTIONS = [
  // ═══════════════ MARCHÉS — need ~3 more difficile ═══════════════
  {
    theme: "marches",
    question: "Qu'est-ce que le 'circuit breaker' (coupe-circuit) sur les marchés boursiers américains ?",
    options: JSON.stringify(["Un mécanisme qui suspend les échanges temporairement après une chute rapide des indices", "Un outil de trading algorithmique", "Un type d'ordre de vente automatique", "Un indicateur de volatilité"]),
    correctIndex: 0,
    explanation: "Les circuit breakers sont des mécanismes réglementaires qui suspendent temporairement les échanges sur les marchés lorsque les indices chutent de 7%, 13% ou 20% en une journée. Ils ont été mis en place après le krach de 1987 pour éviter les paniques incontrôlées.",
    difficulty: "difficile"
  },
  {
    theme: "marches",
    question: "Que signifie le terme 'dead cat bounce' en analyse de marché ?",
    options: JSON.stringify(["Un rebond temporaire dans un marché baissier avant une nouvelle chute", "Une hausse soudaine après une annonce de la Fed", "Un signal d'achat technique", "Une correction de marché saine"]),
    correctIndex: 0,
    explanation: "Le 'dead cat bounce' est un rebond temporaire des prix après une forte baisse, suivi d'une reprise de la tendance baissière. L'expression vient de l'idée que même un chat mort rebondirait s'il tombait d'assez haut — ce n'est pas un signe de reprise durable.",
    difficulty: "difficile"
  },
  {
    theme: "marches",
    question: "Qu'est-ce que le 'window dressing' en gestion de portefeuille ?",
    options: JSON.stringify(["La pratique de restructurer un portefeuille en fin de trimestre pour améliorer son apparence", "L'achat d'actions juste avant la clôture du marché", "La diversification sectorielle d'un fonds", "L'ajout de produits dérivés pour couvrir un portefeuille"]),
    correctIndex: 0,
    explanation: "Le window dressing est la pratique des gestionnaires de fonds qui achètent les actions performantes et vendent les perdantes juste avant la fin du trimestre, pour que le rapport trimestriel montre un portefeuille attractif aux investisseurs.",
    difficulty: "difficile"
  },
  {
    theme: "marches",
    question: "Quelle est la différence entre le 'front-running' et le 'insider trading' ?",
    options: JSON.stringify(["Le front-running exploite la connaissance d'ordres clients à venir, l'insider trading utilise des informations non publiques de l'entreprise", "Ce sont deux termes pour la même pratique illégale", "Le front-running est légal, l'insider trading est illégal", "Le front-running concerne les options, l'insider trading concerne les actions"]),
    correctIndex: 0,
    explanation: "Le front-running consiste à passer des ordres en sachant qu'un gros ordre client va arriver et influencer le prix. L'insider trading utilise des informations matérielles non publiques sur une entreprise. Les deux sont illégaux mais exploitent des types d'informations différents.",
    difficulty: "difficile"
  },
  {
    theme: "marches",
    question: "Que mesure le 'Buffett Indicator' ?",
    options: JSON.stringify(["Le ratio capitalisation boursière totale / PIB d'un pays", "La performance annuelle de Berkshire Hathaway", "Le nombre d'acquisitions de Warren Buffett par an", "Le ratio prix/bénéfice moyen du S&P 500"]),
    correctIndex: 0,
    explanation: "Le Buffett Indicator compare la capitalisation boursière totale d'un pays à son PIB. Warren Buffett l'a qualifié de 'meilleur indicateur unique' de la valorisation du marché. Un ratio supérieur à 100% suggère une surévaluation.",
    difficulty: "moyen"
  },

  // ═══════════════ INDICATEURS — need ~3 more difficile ═══════════════
  {
    theme: "indicateurs",
    question: "Qu'est-ce que l'indicateur 'Ichimoku Kinko Hyo' et que mesure-t-il ?",
    options: JSON.stringify(["Un système complet d'analyse technique japonais qui identifie tendance, support/résistance et momentum en un seul graphique", "Un indicateur de volume japonais", "Un oscillateur de surachat/survente", "Un indicateur de volatilité basé sur les chandeliers japonais"]),
    correctIndex: 0,
    explanation: "L'Ichimoku Kinko Hyo ('équilibre d'un graphique en un coup d'œil') est un système d'analyse technique complet développé au Japon. Il combine 5 lignes (Tenkan, Kijun, Senkou A/B, Chikou) pour identifier la tendance, les niveaux de support/résistance et le momentum simultanément.",
    difficulty: "difficile"
  },
  {
    theme: "indicateurs",
    question: "Que signifie une divergence entre le prix et le RSI ?",
    options: JSON.stringify(["Le prix et le RSI évoluent dans des directions opposées, signalant un possible retournement", "Le RSI est supérieur à 70", "Le prix a franchi une moyenne mobile", "Le volume est en baisse"]),
    correctIndex: 0,
    explanation: "Une divergence RSI se produit quand le prix fait de nouveaux sommets (ou creux) mais le RSI ne confirme pas. Une divergence baissière (prix monte, RSI descend) suggère un affaiblissement du momentum haussier. C'est un signal avancé de retournement potentiel.",
    difficulty: "difficile"
  },
  {
    theme: "indicateurs",
    question: "Qu'est-ce que le 'Death Cross' et le 'Golden Cross' ?",
    options: JSON.stringify(["Le croisement de la MA50 sous/au-dessus de la MA200, signalant respectivement un signal baissier/haussier", "Deux patterns de chandeliers japonais", "Des niveaux de Fibonacci spécifiques", "Des configurations de volume"]),
    correctIndex: 0,
    explanation: "Le Death Cross se produit quand la moyenne mobile 50 jours croise sous la MA200, signalant une tendance baissière. Le Golden Cross est l'inverse (MA50 croise au-dessus de MA200), signalant une tendance haussière. Ce sont des signaux de tendance à long terme très suivis.",
    difficulty: "moyen"
  },
  {
    theme: "indicateurs",
    question: "Comment interpréter les Bandes de Bollinger quand elles se resserrent fortement ?",
    options: JSON.stringify(["Un 'squeeze' indique une période de faible volatilité qui précède souvent un mouvement important", "Le marché est en tendance haussière forte", "Il faut vendre immédiatement", "Le volume est en augmentation"]),
    correctIndex: 0,
    explanation: "Le 'Bollinger Squeeze' se produit quand les bandes se resserrent fortement, indiquant une compression de la volatilité. Historiquement, ces périodes de faible volatilité précèdent souvent des mouvements de prix importants (dans un sens ou l'autre). C'est un signal de préparation, pas de direction.",
    difficulty: "moyen"
  },
  {
    theme: "indicateurs",
    question: "Que mesure l'indicateur ADX (Average Directional Index) ?",
    options: JSON.stringify(["La force de la tendance, sans indiquer sa direction", "La direction de la tendance (haussière ou baissière)", "Le volume moyen sur 14 jours", "La volatilité implicite des options"]),
    correctIndex: 0,
    explanation: "L'ADX mesure uniquement la force de la tendance, pas sa direction. Un ADX supérieur à 25 indique une tendance forte, inférieur à 20 une absence de tendance. Les lignes DI+ et DI- associées indiquent la direction. C'est un outil clé pour distinguer les marchés en tendance des marchés en range.",
    difficulty: "difficile"
  },
  {
    theme: "indicateurs",
    question: "Qu'est-ce que le ratio Put/Call et comment l'interpréter ?",
    options: JSON.stringify(["Le ratio entre le volume de puts et de calls, un ratio élevé signale un pessimisme extrême (potentiel rebond)", "Le ratio entre les positions longues et courtes", "Le rapport entre les ordres d'achat et de vente", "Le ratio entre les actions en hausse et en baisse"]),
    correctIndex: 0,
    explanation: "Le ratio Put/Call compare le volume de puts (options de vente) aux calls (options d'achat). Un ratio élevé (>1.0) indique un pessimisme extrême des investisseurs, souvent un signal contrarien de rebond. Un ratio bas (<0.7) suggère un optimisme excessif et un risque de correction.",
    difficulty: "difficile"
  },

  // ═══════════════ GLOSSAIRE — need ~3 more difficile ═══════════════
  {
    theme: "glossaire",
    question: "Qu'est-ce qu'un 'SPAC' (Special Purpose Acquisition Company) ?",
    options: JSON.stringify(["Une société créée uniquement pour lever des fonds en bourse et acquérir une entreprise privée", "Un fonds d'investissement spécialisé en technologie", "Un type de produit dérivé", "Une obligation convertible"]),
    correctIndex: 0,
    explanation: "Un SPAC est une 'coquille vide' cotée en bourse qui lève des fonds via une IPO dans le seul but d'acquérir une entreprise privée existante. C'est une alternative à l'IPO traditionnelle. Le SPAC a généralement 2 ans pour trouver une cible, sinon les fonds sont rendus aux investisseurs.",
    difficulty: "difficile"
  },
  {
    theme: "glossaire",
    question: "Quelle est la différence entre 'alpha' et 'beta' en finance ?",
    options: JSON.stringify(["L'alpha mesure la surperformance par rapport au marché, le beta mesure la sensibilité au marché", "L'alpha est le rendement total, le beta est le risque total", "L'alpha concerne les actions, le beta concerne les obligations", "L'alpha est calculé annuellement, le beta mensuellement"]),
    correctIndex: 0,
    explanation: "Le beta mesure la sensibilité d'un actif aux mouvements du marché (beta=1.5 signifie que l'actif bouge 1.5x plus que le marché). L'alpha mesure la surperformance ajustée du risque par rapport au benchmark. Un alpha positif signifie que le gestionnaire a battu le marché après ajustement du risque.",
    difficulty: "difficile"
  },
  {
    theme: "glossaire",
    question: "Qu'est-ce que le 'quantitative easing' (QE) ?",
    options: JSON.stringify(["Un programme d'achat massif d'actifs par une banque centrale pour injecter des liquidités dans l'économie", "Une hausse des taux d'intérêt par la Fed", "Une réduction des impôts par le gouvernement", "Un programme de prêts aux banques commerciales"]),
    correctIndex: 0,
    explanation: "Le QE est un outil de politique monétaire non conventionnel où la banque centrale achète massivement des obligations d'État et parfois des actifs privés pour injecter des liquidités, baisser les taux longs et stimuler l'économie. La Fed a utilisé le QE massivement en 2008-2014 et 2020-2022.",
    difficulty: "moyen"
  },
  {
    theme: "glossaire",
    question: "Qu'est-ce qu'un 'margin call' ?",
    options: JSON.stringify(["Un appel de marge du courtier exigeant un dépôt supplémentaire quand la valeur du collatéral baisse trop", "Un appel téléphonique de votre banquier", "Une notification de dividende", "Un ordre d'achat automatique"]),
    correctIndex: 0,
    explanation: "Un margin call se produit quand la valeur de votre portefeuille sur marge tombe en dessous du seuil de maintenance exigé par le courtier. Vous devez alors déposer des fonds supplémentaires ou le courtier liquidera vos positions. C'est un risque majeur du trading sur marge.",
    difficulty: "moyen"
  },
  {
    theme: "glossaire",
    question: "Que signifie 'FOMO' dans le contexte des marchés financiers ?",
    options: JSON.stringify(["Fear Of Missing Out — la peur de rater une opportunité, poussant à acheter impulsivement", "First Order Market Obligation", "Federal Open Market Operations", "Futures Options Market Order"]),
    correctIndex: 0,
    explanation: "FOMO (Fear Of Missing Out) est un biais psychologique où l'investisseur achète par peur de rater un rallye, souvent au pire moment (près des sommets). C'est un des biais comportementaux les plus dangereux en investissement, car il pousse à ignorer l'analyse rationnelle.",
    difficulty: "facile"
  },
  {
    theme: "glossaire",
    question: "Qu'est-ce que le 'free float' d'une action ?",
    options: JSON.stringify(["La proportion d'actions disponibles au trading public, excluant les actions détenues par les insiders et les actionnaires stratégiques", "Le prix d'introduction en bourse", "Le dividende flottant", "La variation journalière maximale autorisée"]),
    correctIndex: 0,
    explanation: "Le free float représente le nombre d'actions réellement disponibles au trading sur le marché. Il exclut les actions détenues par les fondateurs, dirigeants, gouvernements et actionnaires stratégiques. Un faible free float peut entraîner une volatilité plus élevée.",
    difficulty: "difficile"
  },

  // ═══════════════ FORMATION — need ~3 more difficile ═══════════════
  {
    theme: "formation",
    question: "Qu'est-ce que la 'Modern Portfolio Theory' (MPT) de Markowitz ?",
    options: JSON.stringify(["Une théorie qui montre comment construire un portefeuille optimal en maximisant le rendement pour un niveau de risque donné via la diversification", "Une méthode de sélection d'actions individuelles", "Un algorithme de trading haute fréquence", "Une stratégie de market timing"]),
    correctIndex: 0,
    explanation: "La MPT de Harry Markowitz (1952, Prix Nobel 1990) démontre mathématiquement que la diversification réduit le risque sans nécessairement réduire le rendement. La 'frontière efficiente' représente les portefeuilles offrant le meilleur rendement pour chaque niveau de risque.",
    difficulty: "difficile"
  },
  {
    theme: "formation",
    question: "Qu'est-ce que le ratio de Sharpe et comment l'interpréter ?",
    options: JSON.stringify(["Le rendement excédentaire par unité de risque — plus il est élevé, meilleur est le rendement ajusté du risque", "Le ratio entre le prix et les bénéfices", "Le pourcentage de jours positifs sur un an", "Le ratio entre les dividendes et le prix de l'action"]),
    correctIndex: 0,
    explanation: "Le ratio de Sharpe = (Rendement du portefeuille - Taux sans risque) / Écart-type du portefeuille. Un ratio > 1 est bon, > 2 est excellent, > 3 est exceptionnel. Il permet de comparer des investissements en tenant compte du risque pris pour obtenir le rendement.",
    difficulty: "difficile"
  },
  {
    theme: "formation",
    question: "Qu'est-ce que le 'dollar-cost averaging' (DCA) ?",
    options: JSON.stringify(["Investir un montant fixe à intervalles réguliers, quel que soit le prix du marché", "Acheter uniquement quand le dollar est fort", "Convertir ses investissements en dollars", "Investir tout son capital en une seule fois"]),
    correctIndex: 0,
    explanation: "Le DCA consiste à investir un montant fixe régulièrement (ex: 500€/mois). Quand les prix sont bas, vous achetez plus d'unités ; quand ils sont hauts, moins. Cela lisse le prix d'achat moyen et élimine le stress du market timing. C'est la stratégie recommandée pour la plupart des investisseurs.",
    difficulty: "facile"
  },
  {
    theme: "formation",
    question: "Qu'est-ce que l'analyse fondamentale et en quoi diffère-t-elle de l'analyse technique ?",
    options: JSON.stringify(["L'analyse fondamentale évalue la valeur intrinsèque via les finances de l'entreprise, l'analyse technique étudie les graphiques de prix et volumes", "L'analyse fondamentale est pour les débutants, l'analyse technique pour les experts", "L'analyse fondamentale utilise des algorithmes, l'analyse technique est manuelle", "Ce sont deux noms pour la même méthode"]),
    correctIndex: 0,
    explanation: "L'analyse fondamentale évalue la valeur intrinsèque d'une entreprise en examinant ses états financiers, sa position concurrentielle, son secteur et l'économie. L'analyse technique étudie les patterns de prix et de volume sur les graphiques pour prédire les mouvements futurs. Les deux approches sont complémentaires.",
    difficulty: "facile"
  },
  {
    theme: "formation",
    question: "Qu'est-ce que la 'règle des 72' en finance ?",
    options: JSON.stringify(["Une formule rapide pour estimer le temps nécessaire pour doubler un investissement : 72 / taux de rendement annuel", "La règle selon laquelle 72% des investisseurs perdent de l'argent", "Le nombre maximum d'actions dans un portefeuille diversifié", "Le pourcentage optimal d'actions dans un portefeuille"]),
    correctIndex: 0,
    explanation: "La règle des 72 est un raccourci mental : divisez 72 par le taux de rendement annuel pour estimer le nombre d'années nécessaires pour doubler votre investissement. Exemple : à 8% par an, il faut environ 72/8 = 9 ans pour doubler. C'est une approximation utile pour les calculs rapides.",
    difficulty: "facile"
  },

  // ═══════════════ ETFs — need ~3 more difficile ═══════════════
  {
    theme: "etfs",
    question: "Qu'est-ce qu'un ETF 'inverse' (bear ETF) et quels sont ses risques ?",
    options: JSON.stringify(["Un ETF qui performe à l'inverse de son indice de référence, avec un risque de decay sur les positions longues", "Un ETF qui investit dans des obligations inversées", "Un ETF qui achète des actions en baisse", "Un ETF qui verse des dividendes négatifs"]),
    correctIndex: 0,
    explanation: "Un ETF inverse (ex: SH pour le S&P 500) est conçu pour performer à l'inverse de son indice au quotidien. Si le S&P 500 baisse de 1%, l'ETF monte de ~1%. Attention : le rééquilibrage quotidien crée un 'decay' qui érode la valeur sur le long terme. Ils sont conçus pour le trading court terme, pas l'investissement.",
    difficulty: "difficile"
  },
  {
    theme: "etfs",
    question: "Quelle est la différence entre un ETF à réplication physique et synthétique ?",
    options: JSON.stringify(["La réplication physique détient les actifs réels, la synthétique utilise des swaps/dérivés pour reproduire la performance", "La physique est plus chère, la synthétique est gratuite", "La physique est pour les actions, la synthétique pour les obligations", "Il n'y a aucune différence pratique"]),
    correctIndex: 0,
    explanation: "Un ETF à réplication physique achète réellement les titres de l'indice (ex: les 500 actions du S&P 500). Un ETF synthétique utilise des contrats de swap avec une contrepartie bancaire pour reproduire la performance. La réplication physique est plus transparente mais peut avoir un tracking error plus élevé sur certains marchés.",
    difficulty: "difficile"
  },
  {
    theme: "etfs",
    question: "Qu'est-ce que le 'tracking error' d'un ETF ?",
    options: JSON.stringify(["L'écart de performance entre l'ETF et son indice de référence", "Le délai de mise à jour du prix de l'ETF", "Le spread bid-ask de l'ETF", "Le nombre d'erreurs dans la composition de l'ETF"]),
    correctIndex: 0,
    explanation: "Le tracking error mesure la déviation de la performance de l'ETF par rapport à son indice de référence. Il est causé par les frais de gestion, les coûts de transaction, le cash drag et les méthodes de réplication. Un tracking error faible (<0.1%) indique une bonne réplication de l'indice.",
    difficulty: "moyen"
  },
  {
    theme: "etfs",
    question: "Qu'est-ce qu'un ETF 'smart beta' ?",
    options: JSON.stringify(["Un ETF qui suit un indice pondéré par des facteurs (valeur, momentum, qualité) plutôt que par la capitalisation", "Un ETF géré par intelligence artificielle", "Un ETF avec des frais de gestion nuls", "Un ETF qui investit uniquement dans les entreprises tech"]),
    correctIndex: 0,
    explanation: "Les ETFs smart beta utilisent des règles alternatives de pondération basées sur des facteurs comme la valeur (P/E bas), le momentum (performance récente), la qualité (ROE élevé) ou la faible volatilité. Ils visent à surperformer les indices classiques pondérés par capitalisation tout en restant passifs.",
    difficulty: "moyen"
  },
  {
    theme: "etfs",
    question: "Pourquoi le TER (Total Expense Ratio) est-il crucial dans le choix d'un ETF ?",
    options: JSON.stringify(["Car les frais composés sur le long terme peuvent réduire significativement le rendement final", "Car un TER élevé garantit une meilleure performance", "Car le TER détermine le prix de l'ETF", "Car le TER est remboursé aux investisseurs chaque année"]),
    correctIndex: 0,
    explanation: "Le TER représente les frais annuels prélevés par le gestionnaire. Sur 30 ans, la différence entre un TER de 0.07% (ex: VOO) et 1.5% (fonds actif) peut représenter des dizaines de milliers d'euros de rendement perdu à cause de l'effet composé. C'est pourquoi les ETFs à faible TER sont privilégiés pour l'investissement long terme.",
    difficulty: "facile"
  }
];

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  
  console.log(`Inserting ${NEW_QUESTIONS.length} new questions...`);
  
  for (const q of NEW_QUESTIONS) {
    await conn.execute(
      "INSERT INTO globalQuizQuestions (theme, question, options, correctIndex, explanation, difficulty) VALUES (?, ?, ?, ?, ?, ?)",
      [q.theme, q.question, q.options, q.correctIndex, q.explanation, q.difficulty]
    );
  }
  
  // Verify counts
  const [rows] = await conn.execute("SELECT theme, COUNT(*) as cnt FROM globalQuizQuestions GROUP BY theme ORDER BY theme");
  console.log("\nUpdated question counts:");
  console.table(rows);
  
  const [total] = await conn.execute("SELECT COUNT(*) as total FROM globalQuizQuestions");
  console.log(`Total questions: ${total[0].total}`);
  
  await conn.end();
  console.log("Done!");
}

main().catch(console.error);
