/**
 * Script pour envoyer un email test V10 "Dark Shell + Light Core"
 * Usage: node scripts/send-test-v10.mjs
 */
import 'dotenv/config';
import { createRequire } from 'module';

// Load env from the project
const require = createRequire(import.meta.url);

// We'll use tsx to run the actual TypeScript code
import { execSync } from 'child_process';

// Create a small TS script inline and execute it with tsx
const tsScript = `
import { sendEmail, buildWmbEmailHtml } from "../server/email";
import { buildGenericModuleEmail } from "../server/emails/templates";

const ADMIN_EMAIL = "contact@wallstreetmarketbrief.ch";

async function main() {
  console.log("[Test V10] Sending test emails to", ADMIN_EMAIL);

  // 1. Test buildWmbEmailHtml (generic wrapper)
  const genericHtml = buildWmbEmailHtml({
    title: "Test V10 — Dark Shell + Light Core",
    preheader: "Ceci est un email test pour valider le nouveau design V10",
    bodyHtml: \`
      <p style="color:#1A1A1A;font-size:15px;line-height:1.7;margin:0 0 18px;">
        Ceci est un <strong>email test</strong> pour valider le nouveau design V10 "Dark Shell + Light Core".
      </p>
      <p style="color:#374151;font-size:15px;line-height:1.7;margin:0 0 18px;">
        Le header et le footer restent en dark (#111318), tandis que le body est en blanc (#FFFFFF).
        Ce pattern est utilis\\u00e9 par Bloomberg, Morning Brew et The Hustle.
      </p>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:16px 20px;background-color:#F7F8FA;border-radius:8px;border:1px solid #E5E7EB;">
            <p style="margin:0 0 8px;font-size:13px;font-weight:700;color:#1A1A1A;">Points cl\\u00e9s du design V10 :</p>
            <p style="margin:0;font-size:14px;color:#374151;line-height:1.7;">
              Header dark avec logo WMB + ligne dor\\u00e9e<br>
              Body blanc pour lisibilit\\u00e9 maximale<br>
              Cartes \\u00e9lev\\u00e9es en #F7F8FA<br>
              Footer dark avec disclaimer<br>
              Compatible dark mode natif
            </p>
          </td>
        </tr>
      </table>
    \`,
    ctaText: "Acc\\u00e9der \\u00e0 WMB",
    ctaUrl: "https://wallstreetmarketbrief.ch/dashboard",
  });

  const r1 = await sendEmail({
    to: ADMIN_EMAIL,
    subject: "[TEST V10] Generic Wrapper — Dark Shell + Light Core",
    html: genericHtml,
  });
  console.log("[Test V10] Generic wrapper:", r1 ? "OK" : "FAILED");

  // 2. Test module email (debrief)
  const moduleHtml = buildGenericModuleEmail({
    moduleType: "debrief",
    title: "Test V10 — Module Debrief",
    bodyHtml: \`
      <p style="color:#1A1A1A;font-size:15px;line-height:1.7;margin:0 0 18px;">
        Ceci est un test du template <strong>module Debrief</strong> en V10.
      </p>
      <p style="color:#374151;font-size:15px;line-height:1.7;margin:0 0 18px;">
        Le scoreboard, les sections et le CTA utilisent d\\u00e9sormais le design "Dark Shell + Light Core".
        Le body est blanc, les textes sont sombres, et les cartes sont en gris tr\\u00e8s clair.
      </p>
    \`,
    ctaText: "Lire le briefing complet",
    ctaUrl: "https://wallstreetmarketbrief.ch/dashboard",
  });

  const r2 = await sendEmail({
    to: ADMIN_EMAIL,
    subject: "[TEST V10] Module Debrief — Dark Shell + Light Core",
    html: moduleHtml,
  });
  console.log("[Test V10] Module debrief:", r2 ? "OK" : "FAILED");

  // 3. Test module email (monde)
  const mondeHtml = buildGenericModuleEmail({
    moduleType: "monde",
    title: "Test V10 — Module Monde",
    bodyHtml: \`
      <p style="color:#1A1A1A;font-size:15px;line-height:1.7;margin:0 0 18px;">
        Ceci est un test du template <strong>module Monde</strong> en V10.
      </p>
      <p style="color:#374151;font-size:15px;line-height:1.7;margin:0 0 18px;">
        Les couleurs d'accent du module Monde (bleu #2563EB) sont utilis\\u00e9es pour les badges et titres de section,
        tandis que le body reste en blanc pour la lisibilit\\u00e9.
      </p>
    \`,
    ctaText: "Lire la revue Monde",
    ctaUrl: "https://wallstreetmarketbrief.ch/dashboard",
  });

  const r3 = await sendEmail({
    to: ADMIN_EMAIL,
    subject: "[TEST V10] Module Monde — Dark Shell + Light Core",
    html: mondeHtml,
  });
  console.log("[Test V10] Module monde:", r3 ? "OK" : "FAILED");

  console.log("\\n[Test V10] Done! Check contact@wallstreetmarketbrief.ch for 3 test emails.");
}

main().catch(console.error);
`;

import { writeFileSync } from 'fs';
writeFileSync('/home/ubuntu/wallstreet-market-brief/scripts/_test-v10-runner.ts', tsScript);

try {
  execSync('cd /home/ubuntu/wallstreet-market-brief && npx tsx scripts/_test-v10-runner.ts', {
    stdio: 'inherit',
    timeout: 30000,
  });
} catch (e) {
  console.error('Script failed:', e.message);
}
