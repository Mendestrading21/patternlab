import fs from 'fs';
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const results = JSON.parse(fs.readFileSync('/home/ubuntu/enrich_short_lessons.json', 'utf-8'));

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  
  let updated = 0;
  let errors = 0;
  
  for (const r of results.results) {
    const { lesson_id, enriched_content, char_count, has_quiz } = r.output;
    
    try {
      // Read the enriched content file
      const content = fs.readFileSync(enriched_content, 'utf-8');
      
      if (!content || content.length < 1000) {
        console.log(`[SKIP] Lesson ${lesson_id}: content too short (${content.length} chars)`);
        errors++;
        continue;
      }
      
      // Update the lesson in the database
      const [result] = await conn.execute(
        'UPDATE courseLessons SET content = ? WHERE id = ?',
        [content, lesson_id]
      );
      
      if (result.affectedRows > 0) {
        console.log(`[OK] Lesson ${lesson_id}: updated (${content.length} chars, quiz=${has_quiz})`);
        updated++;
      } else {
        console.log(`[WARN] Lesson ${lesson_id}: no rows affected`);
        errors++;
      }
    } catch (err) {
      console.error(`[ERROR] Lesson ${lesson_id}: ${err.message}`);
      errors++;
    }
  }
  
  console.log(`\nDone: ${updated} updated, ${errors} errors`);
  await conn.end();
}

main().catch(console.error);
