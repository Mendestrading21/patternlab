/**
 * WMB — Test ALL email types V10
 * Sends one of each email type to all 3 addresses
 */
import { sendEmail, buildWmbEmailHtml } from "../server/email";
import {
  buildModuleUsaEmail,
  buildModuleActionsEmail,
  buildModuleMondeEmail,
  buildModuleSuisseEmail,
} from "../server/emails/templates";
import { buildWeeklyAnnouncementEmail } from "../server/emails/weeklyAnnouncement";

const RECIPIENTS = [
  "contact@wallstreetmarketbrief.ch",
  "E.mendestrading@gmail.com",
  "Elio_mendes@hotmail.com",
];

async function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function sendToAll(subject: string, html: string) {
  for (const to of RECIPIENTS) {
    const ok = await sendEmail({ to, subject, html });
    console.log(`  → ${to}: ${ok ? "OK" : "FAIL"}`);
    await delay(300);
  }
}

async function main() {
  console.log("═══════════════════════════════════════════════");
  console.log("  WMB — Test complet de TOUS les emails V10");
  console.log("═══════════════════════════════════════════════\n");

  // ─── 1. Vérification Email ───
  console.log("1/8 — Vérification Email");
  const verifyHtml = buildWmbEmailHtml({
    title: "Bienvenue, Elio !",
    preheader: "Vérifiez votre adresse email pour activer votre compte WMB.",
    bodyHtml: `
      <p style="font-size:15px;color:#1a1a1a;line-height:1.7;margin:0 0 12px;">Merci de vous &ecirc;tre inscrit sur <strong style="color:#1a1a1a;">WallStreet Market Brief</strong>.</p>
      <p style="font-size:14px;color:#374151;line-height:1.7;margin:0 0 16px;">Pour activer votre compte, veuillez v&eacute;rifier votre adresse email en cliquant ci-dessous.</p>
      <p style="font-size:12px;color:#6B7280;margin:0;">Ce lien expire dans 24 heures.</p>
    `,
    ctaText: "Vérifier mon email",
    ctaUrl: "https://wallstreetmarketbrief.ch/verify-email?token=test",
    footerText: "Vous recevez cet email suite à votre inscription sur WallStreet Market Brief.",
  });
  await sendToAll("[TEST FINAL] 1/8 — Vérification Email", verifyHtml);
  await delay(500);

  // ─── 2. Reset Mot de Passe ───
  console.log("\n2/8 — Reset Mot de Passe");
  const resetHtml = buildWmbEmailHtml({
    title: "Bonjour, Elio",
    preheader: "Réinitialisez votre mot de passe.",
    bodyHtml: `
      <p style="font-size:15px;color:#1a1a1a;line-height:1.7;margin:0 0 12px;">Vous avez demand&eacute; la r&eacute;initialisation de votre mot de passe.</p>
      <p style="font-size:14px;color:#374151;line-height:1.7;margin:0 0 16px;">Cliquez ci-dessous pour choisir un nouveau mot de passe.</p>
      <p style="font-size:12px;color:#6B7280;margin:0;">Ce lien expire dans 1 heure.</p>
    `,
    ctaText: "Réinitialiser mon mot de passe",
    ctaUrl: "https://wallstreetmarketbrief.ch/reset-password?token=test",
    footerText: "Demande de réinitialisation de mot de passe.",
  });
  await sendToAll("[TEST FINAL] 2/8 — Reset Mot de Passe", resetHtml);
  await delay(500);

  // ─── 3. Weekly Brief USA ───
  console.log("\n3/8 — Weekly Brief USA");
  const marcheHtml = buildModuleUsaEmail({
    weekNumber: 15,
    year: 2026,
    dateRange: "7 — 11 avril 2026",
    title: "Semaine de consolidation — le S&P 500 teste les 5 200",
    subtitle: "Le march&eacute; digère les donn&eacute;es macro dans un contexte de volatilit&eacute; contenue.",
    keyPointsPast: [
      "CPI core stable à 3.2% YoY — pas de surprise inflationniste.",
      "215k créations d'emplois — marché du travail toujours solide.",
      "Le S&P 500 consolide autour des 5 200 points.",
    ],
    keyPointsAhead: [
      "Saison des earnings Q1 : les banques ouvrent le bal.",
      "Discours de Powell mercredi — ton attendu prudent.",
      "Données retail sales vendredi.",
    ],
    lectureWMB: "Le marché reste en mode consolidation. La tendance de fond est haussière mais le momentum ralentit. Surveiller le support des 5 150.",
    sp500: { value: "5,208", change: "+0.4%" },
    nasdaq: { value: "16,340", change: "+0.8%" },
    dowJones: { value: "38,920", change: "+0.2%" },
    vix: { value: "14.2", regime: "Faible" },
    signal: "Neutre — consolidation technique en cours.",
    risk: "Risque modéré — surveiller les earnings et le discours Fed.",
    highlights: [
      "Le Nasdaq surperforme grâce aux tech (+0.8%).",
      "Le VIX reste sous 15 — environnement favorable.",
      "Les taux 10Y remontent légèrement à 4.28%.",
    ],
    ctaUrl: "https://wallstreetmarketbrief.ch/editions",
  });
  await sendToAll("[TEST FINAL] 3/8 — Weekly Brief USA", marcheHtml);
  await delay(500);

  // ─── 4. Module Actions US ───
  console.log("\n4/8 — Module Actions US");
  const actionsHtml = buildModuleActionsEmail({
    weekNumber: 15,
    year: 2026,
    dateRange: "7 — 11 avril 2026",
    title: "NVIDIA en t&ecirc;te, Tesla sous pression",
    subtitle: "Les tech portent le march&eacute; tandis que l'auto souffre.",
    topGainers: [
      { ticker: "NVDA", company: "NVIDIA Corp", perf: "+5.2%", catalyst: "Nouveaux contrats data center AI" },
      { ticker: "META", company: "Meta Platforms", perf: "+2.4%", catalyst: "Résultats pub au-dessus des attentes" },
      { ticker: "AMZN", company: "Amazon", perf: "+1.8%", catalyst: "AWS en accélération" },
    ],
    topLosers: [
      { ticker: "TSLA", company: "Tesla Inc", perf: "-3.1%", catalyst: "Inquiétudes sur les marges Q1" },
      { ticker: "BA", company: "Boeing Co", perf: "-2.5%", catalyst: "Retards de livraison 737 MAX" },
      { ticker: "PFE", company: "Pfizer Inc", perf: "-1.8%", catalyst: "Guidance revue à la baisse" },
    ],
    sectorHighlight: "La tech domine avec +1.5% sur la semaine. L'énergie recule de -0.8% sur la baisse du pétrole. La santé sous-performe avec -0.5%.",
    earningsHighlights: [
      "JPMorgan (JPM) : résultats Q1 attendus vendredi — consensus EPS $4.12.",
      "Goldman Sachs (GS) : focus sur les revenus trading.",
      "Morgan Stanley (MS) : wealth management en focus.",
    ],
    watchlistItems: [
      { ticker: "AAPL", reason: "Keynote WWDC en approche — potentiel catalyseur IA" },
      { ticker: "GOOGL", reason: "Antitrust : décision attendue en mai" },
    ],
    ctaUrl: "https://wallstreetmarketbrief.ch/editions",
  });
  await sendToAll("[TEST FINAL] 4/8 — Module Actions US", actionsHtml);
  await delay(500);

  // ─── 5. Module Monde ───
  console.log("\n5/8 — Module Monde");
  const mondeHtml = buildModuleMondeEmail({
    weekNumber: 15,
    year: 2026,
    dateRange: "7 — 11 avril 2026",
    title: "L'Europe acc&eacute;l&egrave;re, l'Asie h&eacute;site",
    subtitle: "Le dollar recule, l'or atteint de nouveaux sommets.",
    keyPointsPast: [
      "Le Stoxx 600 gagne +1.2%, porté par le luxe et l'industrie.",
      "La BCE maintient ses taux mais le ton devient accommodant.",
      "Le Nikkei progresse modestement (+0.6%), le CSI 300 recule.",
    ],
    keyPointsAhead: [
      "Réunion BCE jeudi — guidance attendue.",
      "Données PMI zone euro vendredi.",
      "Tensions commerciales US-Chine : nouveaux tarifs possibles.",
    ],
    lectureWMB: "L'Europe surperforme les US cette semaine. Le pivot BCE se rapproche. L'Asie reste sous pression des tensions géopolitiques.",
    europeIndices: [
      { name: "Stoxx 600", value: "518", change: "+1.2%" },
      { name: "CAC 40", value: "8,120", change: "+0.9%" },
      { name: "DAX", value: "18,450", change: "+1.4%" },
    ],
    europeLecture: "Le luxe et l'industrie portent les indices européens. La BCE devrait signaler une baisse en juin.",
    asiaIndices: [
      { name: "Nikkei 225", value: "39,450", change: "+0.6%" },
      { name: "CSI 300", value: "3,580", change: "-0.3%" },
      { name: "Hang Seng", value: "17,200", change: "+0.2%" },
    ],
    asiaLecture: "Le Japon bénéficie de la faiblesse du yen. La Chine reste sous pression des tensions commerciales.",
    forexPairs: [
      { pair: "EUR/USD", value: "1.0920", change: "+0.4%" },
      { pair: "USD/JPY", value: "151.20", change: "-0.3%" },
      { pair: "GBP/USD", value: "1.2680", change: "+0.2%" },
    ],
    forexLecture: "Le dollar recule face à la plupart des devises. Le yen se renforce sur les attentes de normalisation BOJ.",
    commodities: [
      { name: "Or", value: "$2,380", change: "+1.1%" },
      { name: "Pétrole WTI", value: "$78.50", change: "-1.2%" },
      { name: "Cuivre", value: "$4.25", change: "+0.8%" },
    ],
    commoditiesLecture: "L'or atteint de nouveaux sommets sur les achats des banques centrales. Le pétrole recule sur les craintes de demande.",
    highlights: [
      "L'Europe surperforme les US pour la 3e semaine consécutive.",
      "L'or franchit les $2,380 — nouveau record historique.",
      "Le dollar index recule sous les 104.",
    ],
    ctaUrl: "https://wallstreetmarketbrief.ch/editions",
  });
  await sendToAll("[TEST FINAL] 5/8 — Module Monde", mondeHtml);
  await delay(500);

  // ─── 6. Module Suisse ───
  console.log("\n6/8 — Module Suisse");
  const suisseHtml = buildModuleSuisseEmail({
    weekNumber: 15,
    year: 2026,
    dateRange: "7 — 11 avril 2026",
    title: "SMI en hausse — Nestl&eacute; et Novartis portent l'indice",
    subtitle: "Le march&eacute; suisse profite du rebond europ&eacute;en.",
    keyPointsPast: [
      "Le SMI gagne +0.7% à 11,850 points.",
      "Nestlé +1.4% après des chiffres de ventes encourageants.",
      "Novartis +0.9% sur des résultats d'essais cliniques positifs.",
    ],
    keyPointsAhead: [
      "Résultats trimestriels UBS mercredi.",
      "Données inflation suisse vendredi.",
      "Réunion BNS le 20 juin — marché anticipe un statu quo.",
    ],
    lectureWMB: "Le SMI reste bien orienté. Les blue chips défensives (Nestlé, Novartis, Roche) portent l'indice. Le CHF reste stable.",
    smiValue: "11,850",
    smiChange: "+0.7%",
    chfPairs: [
      { pair: "EUR/CHF", value: "0.9380", change: "-0.1%" },
      { pair: "USD/CHF", value: "0.8590", change: "-0.4%" },
    ],
    chfLecture: "Le franc suisse reste stable face à l'euro. La BNS maintient son taux directeur à 1.25%.",
    bnsRate: "1.25%",
    bnsStance: "Neutre — pas de changement attendu avant juin.",
    blueChips: [
      { ticker: "NESN", value: "CHF 98.20", change: "+1.4%" },
      { ticker: "NOVN", value: "CHF 92.50", change: "+0.9%" },
      { ticker: "ROG", value: "CHF 248.30", change: "+0.3%" },
    ],
    blueChipsLecture: "Les trois poids lourds du SMI progressent. Nestlé mène le bal grâce à des ventes organiques solides.",
    topMovers: [
      { ticker: "NESN", change: "+1.4%" },
      { ticker: "NOVN", change: "+0.9%" },
      { ticker: "SREN", change: "+0.8%" },
    ],
    flopMovers: [
      { ticker: "ABBN", change: "-0.5%" },
      { ticker: "LONN", change: "-0.3%" },
    ],
    highlights: [
      "Le SMI surperforme le Stoxx 600 cette semaine.",
      "Le secteur pharma suisse reste un pilier défensif.",
      "Le marché immobilier montre des signes de stabilisation.",
    ],
    ctaUrl: "https://wallstreetmarketbrief.ch/editions",
  });
  await sendToAll("[TEST FINAL] 6/8 — Module Suisse", suisseHtml);
  await delay(500);

  // ─── 7. Weekly Announcement ───
  console.log("\n7/8 — Weekly Announcement (Scoreboard)");
  const weeklyResult = buildWeeklyAnnouncementEmail({
    weekNumber: 15,
    year: 2026,
    dateRange: "7 — 11 avril 2026",
    headline: "Consolidation autour des 5 200",
    subheadline: "Le marché digère les données macro dans un contexte de volatilité contenue.",
    sp500: { value: "5,208", change: "+0.4%", positive: true },
    nasdaq: { value: "16,340", change: "+0.8%", positive: true },
    vix: { value: "14.2", regime: "Faible" },
    oil: { value: "$78.50", change: "-1.2%", positive: false },
    gold: { value: "$2,380", change: "+1.1%", positive: true },
    tenYear: { value: "4.28%", change: "+5bps" },
    takeaways: [
      "Le S&P 500 consolide autour des 5 200 — support technique solide.",
      "Le VIX reste sous 15 — environnement favorable.",
      "La Fed maintient son biais restrictif mais le marché price 2 baisses.",
      "Saison des earnings Q1 : les banques ouvrent le bal.",
    ],
    lectureTeaser: "Cette semaine : positionnement sectoriel, tarifs douaniers, scénarios Q2.",
    modules: [
      { name: "Marché US", icon: "📊", available: true },
      { name: "Actions US", icon: "📈", available: true },
      { name: "Marchés Mondiaux", icon: "🌍", available: true },
      { name: "Module Suisse", icon: "🇨🇭", available: true },
    ],
    ctaUrl: "https://wallstreetmarketbrief.ch/editions",
  });
  await sendToAll("[TEST FINAL] 7/8 — " + weeklyResult.subject, weeklyResult.html);
  await delay(500);

  // ─── 8. Admin Notification ───
  console.log("\n8/8 — Admin Notification");
  const adminHtml = buildWmbEmailHtml({
    title: "Nouvelle inscription",
    preheader: "Nouvel inscrit — Elio Mendes",
    bodyHtml: `
      <p style="font-size:14px;color:#374151;line-height:1.7;margin:0 0 16px;">Un nouvel utilisateur vient de cr&eacute;er un compte sur WallStreet Market Brief.</p>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 16px;">
        <tr>
          <td style="padding:8px 14px;background-color:rgba(37,99,235,0.08);border-radius:6px;display:inline-block;">
            <span style="font-size:11px;font-weight:700;letter-spacing:1px;color:#2563EB;">INSCRIPTION</span>
          </td>
        </tr>
      </table>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:18px 20px;background-color:#F7F8FA;border-radius:8px;border:1px solid #E5E7EB;">
            <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
              <tr>
                <td style="padding:6px 0;font-size:12px;color:#6B7280;font-weight:600;width:100px;">Client</td>
                <td style="padding:6px 0;font-size:13px;color:#1A1A1A;">Elio Mendes</td>
              </tr>
              <tr>
                <td style="padding:6px 0;font-size:12px;color:#6B7280;font-weight:600;width:100px;">Email</td>
                <td style="padding:6px 0;font-size:13px;color:#1A1A1A;">E.mendestrading@gmail.com</td>
              </tr>
              <tr>
                <td style="padding:6px 0;font-size:12px;color:#6B7280;font-weight:600;width:100px;">Date</td>
                <td style="padding:6px 0;font-size:13px;color:#1A1A1A;">9 avril 2026, 10:30</td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    `,
    ctaText: "Voir le Dashboard Admin",
    ctaUrl: "https://wallstreetmarketbrief.ch/admin",
    footerText: "Notification automatique — WallStreet Market Brief Admin",
    accentColor: "#2563EB",
  });
  await sendToAll("[TEST FINAL] 8/8 — Admin Notification", adminHtml);

  console.log("\n═══════════════════════════════════════════════");
  console.log("  TERMINÉ — 8 types × 3 destinataires = 24 emails");
  console.log("═══════════════════════════════════════════════");
}

main().catch(console.error);
