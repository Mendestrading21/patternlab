import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();
const conn = await mysql.createConnection(process.env.DATABASE_URL);

const [maxWl] = await conn.execute("SELECT MAX(id) as maxId FROM thematicWatchlists");
const [maxItem] = await conn.execute("SELECT MAX(id) as maxId FROM watchlistItems");
let wlId = Math.max(maxWl[0].maxId + 1, 42000);
let itemId = Math.max(maxItem[0].maxId + 1, 52000);
let sortOrder = 300;

const THEMES = [
  { slug: "cybersecurite-zero-trust", title: "Zero Trust & Securite Cloud", icon: "ShieldCheck", color: "#DC2626",
    thesis: "Le modele Zero Trust remplace les perimetres traditionnels. Marche cybersecurite 300Md$+ d'ici 2028.",
    items: [
      { ticker: "CRWD", name: "CrowdStrike", sector: "Endpoint", mcap: "Large", thesis: "Leader XDR et protection endpoint cloud-native." },
      { ticker: "ZS", name: "Zscaler", sector: "SASE", mcap: "Large", thesis: "Leader Zero Trust Network Access." },
      { ticker: "PANW", name: "Palo Alto Networks", sector: "Plateforme", mcap: "Large", thesis: "Plateforme securite unifiee." },
      { ticker: "FTNT", name: "Fortinet", sector: "Firewall", mcap: "Large", thesis: "Firewall et SD-WAN securise." },
      { ticker: "S", name: "SentinelOne", sector: "AI Security", mcap: "Mid", thesis: "Securite autonome par IA." },
    ]
  },
  { slug: "energie-solaire", title: "Energie Solaire & Photovoltaique", icon: "Zap", color: "#EAB308",
    thesis: "Le solaire est desormais la source d'electricite la moins chere. Capacite mondiale doublee d'ici 2027.",
    items: [
      { ticker: "FSLR", name: "First Solar", sector: "Panneaux", mcap: "Large", thesis: "Leader panneaux thin-film US." },
      { ticker: "ENPH", name: "Enphase Energy", sector: "Micro-onduleurs", mcap: "Mid", thesis: "Micro-onduleurs solaires leader." },
      { ticker: "SEDG", name: "SolarEdge", sector: "Onduleurs", mcap: "Mid", thesis: "Optimiseurs et onduleurs." },
      { ticker: "RUN", name: "Sunrun", sector: "Residentiel", mcap: "Mid", thesis: "Leader solaire residentiel US." },
      { ticker: "ARRY", name: "Array Technologies", sector: "Trackers", mcap: "Mid", thesis: "Systemes de suivi solaire." },
    ]
  },
  { slug: "eolien-offshore", title: "Eolien Offshore & Onshore", icon: "Zap", color: "#0D9488",
    thesis: "L'eolien offshore represente un marche de 100Md$+. Les projets se multiplient en Europe et aux US.",
    items: [
      { ticker: "VWDRY", name: "Vestas Wind Systems", sector: "Turbines", mcap: "Large", thesis: "Premier fabricant mondial de turbines." },
      { ticker: "GE", name: "GE Vernova", sector: "Turbines", mcap: "Large", thesis: "Division energie de GE, turbines offshore." },
      { ticker: "TPIC", name: "TPI Composites", sector: "Pales", mcap: "Small", thesis: "Fabricant de pales d'eoliennes." },
      { ticker: "NEP", name: "NextEra Energy Partners", sector: "Renouvelable", mcap: "Mid", thesis: "Portefeuille d'actifs eoliens et solaires." },
      { ticker: "ORA", name: "Ormat Technologies", sector: "Geothermie", mcap: "Mid", thesis: "Leader geothermie et stockage." },
    ]
  },
  { slug: "reseaux-electriques", title: "Reseaux Electriques & Smart Grid", icon: "Zap", color: "#2563EB",
    thesis: "La modernisation des reseaux electriques est critique pour integrer les renouvelables et l'IA.",
    items: [
      { ticker: "ETN", name: "Eaton Corporation", sector: "Electrique", mcap: "Large", thesis: "Gestion de l'energie et distribution." },
      { ticker: "EMR", name: "Emerson Electric", sector: "Automatisation", mcap: "Large", thesis: "Automatisation industrielle et electrique." },
      { ticker: "GNRC", name: "Generac Holdings", sector: "Generateurs", mcap: "Mid", thesis: "Generateurs et stockage residentiel." },
      { ticker: "ITRI", name: "Itron", sector: "Smart meters", mcap: "Mid", thesis: "Compteurs intelligents et IoT energie." },
      { ticker: "PWR", name: "Quanta Services", sector: "Services", mcap: "Large", thesis: "Construction lignes electriques." },
    ]
  },
  { slug: "sante-animale-vet", title: "Sante Animale & Veterinaire", icon: "Heart", color: "#A3E635",
    thesis: "Le marche de la sante animale croit avec l'humanisation des animaux de compagnie. 50Md$+ d'ici 2030.",
    items: [
      { ticker: "IDXX", name: "IDEXX Laboratories", sector: "Diagnostics vet", mcap: "Large", thesis: "Leader diagnostics veterinaires." },
      { ticker: "ZTS", name: "Zoetis", sector: "Pharma animale", mcap: "Mega", thesis: "Premier labo pharma animale mondial." },
      { ticker: "ELAN", name: "Elanco Animal Health", sector: "Pharma animale", mcap: "Mid", thesis: "Medicaments et vaccins animaux." },
      { ticker: "CHWY", name: "Chewy", sector: "E-commerce pet", mcap: "Mid", thesis: "E-commerce produits pour animaux." },
      { ticker: "TRUP", name: "Trupanion", sector: "Assurance pet", mcap: "Mid", thesis: "Assurance sante pour animaux." },
    ]
  },
  { slug: "voyage-tourisme", title: "Voyage, Tourisme & Loisirs", icon: "Globe", color: "#F472B6",
    thesis: "Le tourisme mondial depasse les niveaux pre-Covid. Revenge travel et experiences premium.",
    items: [
      { ticker: "BKNG", name: "Booking Holdings", sector: "OTA", mcap: "Mega", thesis: "Leader mondial reservation en ligne." },
      { ticker: "ABNB", name: "Airbnb", sector: "Location", mcap: "Large", thesis: "Leader location courte duree." },
      { ticker: "MAR", name: "Marriott International", sector: "Hotellerie", mcap: "Large", thesis: "Plus grande chaine hoteliere." },
      { ticker: "RCL", name: "Royal Caribbean", sector: "Croisieres", mcap: "Large", thesis: "Leader croisieres, demande record." },
      { ticker: "EXPE", name: "Expedia Group", sector: "OTA", mcap: "Large", thesis: "Plateforme voyage diversifiee." },
    ]
  },
  { slug: "streaming-media", title: "Streaming & Media Numerique", icon: "Globe", color: "#7C3AED",
    thesis: "La guerre du streaming se consolide. Monetisation par la pub et bundling deviennent cles.",
    items: [
      { ticker: "NFLX", name: "Netflix", sector: "Streaming", mcap: "Mega", thesis: "Leader mondial streaming video." },
      { ticker: "DIS", name: "Walt Disney", sector: "Media/Streaming", mcap: "Large", thesis: "Disney+, Hulu, ESPN, parcs." },
      { ticker: "SPOT", name: "Spotify", sector: "Audio", mcap: "Large", thesis: "Leader streaming audio mondial." },
      { ticker: "WBD", name: "Warner Bros Discovery", sector: "Media", mcap: "Mid", thesis: "Max streaming et contenu premium." },
      { ticker: "ROKU", name: "Roku", sector: "CTV", mcap: "Mid", thesis: "Plateforme TV connectee leader US." },
    ]
  },
  { slug: "nutrition-sport", title: "Nutrition Sportive & Wellness", icon: "Heart", color: "#F97316",
    thesis: "Le marche du wellness et de la nutrition sportive explose avec la tendance sante et fitness.",
    items: [
      { ticker: "CELH", name: "Celsius Holdings", sector: "Boissons", mcap: "Mid", thesis: "Boissons energetiques fitness." },
      { ticker: "MNST", name: "Monster Beverage", sector: "Energy drinks", mcap: "Large", thesis: "Leader energy drinks mondial." },
      { ticker: "LULU", name: "Lululemon", sector: "Athleisure", mcap: "Large", thesis: "Leader vetements sport premium." },
      { ticker: "PLNT", name: "Planet Fitness", sector: "Fitness", mcap: "Mid", thesis: "Chaine fitness low-cost en croissance." },
      { ticker: "NKE", name: "Nike", sector: "Sportswear", mcap: "Mega", thesis: "Leader mondial equipement sportif." },
    ]
  },
  { slug: "education-edtech", title: "Education & EdTech", icon: "GraduationCap", color: "#4F46E5",
    thesis: "L'education en ligne et l'IA pedagogique transforment l'apprentissage. Marche 400Md$+ d'ici 2028.",
    items: [
      { ticker: "DUOL", name: "Duolingo", sector: "Langues", mcap: "Mid", thesis: "App langues gamifiee, monetisation forte." },
      { ticker: "COUR", name: "Coursera", sector: "MOOC", mcap: "Small", thesis: "Plateforme cours universitaires en ligne." },
      { ticker: "CHGG", name: "Chegg", sector: "Aide scolaire", mcap: "Small", thesis: "Aide aux devoirs et tutorat IA." },
      { ticker: "TWOU", name: "2U Inc.", sector: "OPM", mcap: "Small", thesis: "Programmes universitaires en ligne." },
      { ticker: "LRN", name: "Stride Inc.", sector: "K-12 online", mcap: "Mid", thesis: "Education K-12 en ligne." },
    ]
  },
  { slug: "impression-3d", title: "Impression 3D & Fabrication Additive", icon: "Layers", color: "#A855F7",
    thesis: "L'impression 3D industrielle accelere dans l'aeronautique, le medical et l'automobile.",
    items: [
      { ticker: "DDD", name: "3D Systems", sector: "Impression 3D", mcap: "Small", thesis: "Pioneer impression 3D industrielle." },
      { ticker: "SSYS", name: "Stratasys", sector: "Impression 3D", mcap: "Small", thesis: "Leader FDM et PolyJet." },
      { ticker: "XONE", name: "ExOne/Desktop Metal", sector: "Metal 3D", mcap: "Small", thesis: "Impression 3D metal binder jetting." },
      { ticker: "MKFG", name: "Markforged", sector: "Composite 3D", mcap: "Small", thesis: "Impression 3D composite et metal." },
      { ticker: "NNDM", name: "Nano Dimension", sector: "Electronique 3D", mcap: "Small", thesis: "Impression 3D de circuits electroniques." },
    ]
  },
  { slug: "drones-uav", title: "Drones & UAV", icon: "Rocket", color: "#0369A1",
    thesis: "Les drones commerciaux et militaires connaissent une adoption rapide. Livraison, inspection, defense.",
    items: [
      { ticker: "AVAV", name: "AeroVironment", sector: "Drones defense", mcap: "Mid", thesis: "Leader drones tactiques militaires US." },
      { ticker: "JOBY", name: "Joby Aviation", sector: "eVTOL", mcap: "Mid", thesis: "Taxi aerien electrique, certification FAA." },
      { ticker: "ACHR", name: "Archer Aviation", sector: "eVTOL", mcap: "Mid", thesis: "eVTOL pour mobilite urbaine." },
      { ticker: "KTOS", name: "Kratos Defense", sector: "Drones combat", mcap: "Mid", thesis: "Drones de combat autonomes." },
      { ticker: "RKLB", name: "Rocket Lab", sector: "Spatial/Drones", mcap: "Mid", thesis: "Lanceur spatial et composants drones." },
    ]
  },
  { slug: "stockage-energie", title: "Stockage d'Energie & BESS", icon: "Battery", color: "#15803D",
    thesis: "Le stockage par batteries (BESS) est essentiel pour stabiliser les reseaux renouvelables.",
    items: [
      { ticker: "TSLA", name: "Tesla", sector: "Megapack", mcap: "Mega", thesis: "Megapack leader stockage grid-scale." },
      { ticker: "FLNC", name: "Fluence Energy", sector: "BESS", mcap: "Mid", thesis: "Solutions stockage grid-scale." },
      { ticker: "STEM", name: "Stem Inc.", sector: "AI Stockage", mcap: "Small", thesis: "Optimisation stockage par IA." },
      { ticker: "ENVX", name: "Enovis", sector: "Batteries", mcap: "Mid", thesis: "Batteries solid-state next-gen." },
      { ticker: "QS", name: "QuantumScape", sector: "Solid-state", mcap: "Mid", thesis: "Batteries solid-state pour EV." },
    ]
  },
  { slug: "marche-indien", title: "Marche Indien & Emergence", icon: "Globe", color: "#EA580C",
    thesis: "L'Inde est la 5e economie mondiale avec une croissance de 6-7% par an. Demographie favorable.",
    items: [
      { ticker: "INDA", name: "iShares MSCI India ETF", sector: "ETF Inde", mcap: "Large", thesis: "ETF reference marche indien." },
      { ticker: "IBN", name: "ICICI Bank", sector: "Banque", mcap: "Large", thesis: "Deuxieme banque privee indienne." },
      { ticker: "INFY", name: "Infosys", sector: "IT Services", mcap: "Large", thesis: "Leader services IT indiens." },
      { ticker: "HDB", name: "HDFC Bank", sector: "Banque", mcap: "Large", thesis: "Plus grande banque privee indienne." },
      { ticker: "WIT", name: "Wipro", sector: "IT Services", mcap: "Mid", thesis: "Services IT et consulting." },
    ]
  },
  { slug: "marche-japonais", title: "Marche Japonais & Nikkei", icon: "Globe", color: "#BE185D",
    thesis: "Le Japon connait un renouveau boursier avec les reformes de gouvernance et la fin de la deflation.",
    items: [
      { ticker: "EWJ", name: "iShares MSCI Japan ETF", sector: "ETF Japon", mcap: "Large", thesis: "ETF reference marche japonais." },
      { ticker: "TM", name: "Toyota Motor", sector: "Automobile", mcap: "Mega", thesis: "Premier constructeur mondial." },
      { ticker: "SONY", name: "Sony Group", sector: "Tech/Media", mcap: "Large", thesis: "Gaming, musique, semi-conducteurs." },
      { ticker: "MUFG", name: "Mitsubishi UFJ", sector: "Banque", mcap: "Large", thesis: "Plus grande banque japonaise." },
      { ticker: "NTDOY", name: "Nintendo", sector: "Gaming", mcap: "Large", thesis: "Switch 2 et franchises iconiques." },
    ]
  },
  { slug: "marche-chinois", title: "Marche Chinois & Tech China", icon: "Globe", color: "#DC2626",
    thesis: "La tech chinoise offre des valorisations attractives malgre les risques reglementaires et geopolitiques.",
    items: [
      { ticker: "BABA", name: "Alibaba Group", sector: "E-commerce", mcap: "Large", thesis: "Leader e-commerce et cloud chinois." },
      { ticker: "PDD", name: "PDD Holdings", sector: "E-commerce", mcap: "Large", thesis: "Temu et Pinduoduo en forte croissance." },
      { ticker: "BIDU", name: "Baidu", sector: "Search/AI", mcap: "Mid", thesis: "Google chinois, investit dans l'IA." },
      { ticker: "JD", name: "JD.com", sector: "E-commerce", mcap: "Mid", thesis: "E-commerce et logistique integree." },
      { ticker: "NIO", name: "NIO Inc.", sector: "EV Chine", mcap: "Mid", thesis: "Constructeur EV premium chinois." },
    ]
  },
  { slug: "marche-bresilien", title: "Marche Bresilien & LatAm", icon: "Globe", color: "#16A34A",
    thesis: "Le Bresil est la premiere economie d'Amerique latine avec des ressources naturelles abondantes.",
    items: [
      { ticker: "EWZ", name: "iShares MSCI Brazil ETF", sector: "ETF Bresil", mcap: "Large", thesis: "ETF reference marche bresilien." },
      { ticker: "VALE", name: "Vale S.A.", sector: "Minerai fer", mcap: "Large", thesis: "Premier producteur minerai de fer." },
      { ticker: "PBR", name: "Petrobras", sector: "Petrole", mcap: "Large", thesis: "Geant petrolier bresilien, dividendes eleves." },
      { ticker: "NU", name: "Nu Holdings", sector: "Fintech", mcap: "Large", thesis: "Plus grande neobanque du monde." },
      { ticker: "MELI", name: "MercadoLibre", sector: "E-commerce", mcap: "Large", thesis: "Amazon d'Amerique latine." },
    ]
  },
  { slug: "tabac-transition", title: "Tabac & Transition Nicotine", icon: "Leaf", color: "#78716C",
    thesis: "Les geants du tabac pivotent vers les produits a risque reduit. Dividendes eleves et pricing power.",
    items: [
      { ticker: "PM", name: "Philip Morris", sector: "Tabac", mcap: "Mega", thesis: "Leader IQOS et ZYN, transition reussie." },
      { ticker: "MO", name: "Altria Group", sector: "Tabac US", mcap: "Large", thesis: "Marlboro US, dividende 8%+." },
      { ticker: "BTI", name: "British American Tobacco", sector: "Tabac", mcap: "Large", thesis: "Vuse et glo, transition en cours." },
      { ticker: "SWMA", name: "Swedish Match", sector: "Snus", mcap: "Large", thesis: "Leader snus et nicotine pouches." },
      { ticker: "TPB", name: "Turning Point Brands", sector: "Nicotine alt", mcap: "Small", thesis: "Produits nicotine alternatifs." },
    ]
  },
  { slug: "luxe-mondial", title: "Luxe Mondial & Marques Premium", icon: "Gem", color: "#D4A853",
    thesis: "Le luxe mondial resiste aux cycles economiques. Les marques fortes beneficient du pricing power.",
    items: [
      { ticker: "LVMUY", name: "LVMH", sector: "Luxe", mcap: "Mega", thesis: "Premier groupe de luxe mondial." },
      { ticker: "HESAY", name: "Hermes", sector: "Luxe", mcap: "Mega", thesis: "Marque la plus exclusive, Birkin." },
      { ticker: "CFRUY", name: "Richemont", sector: "Joaillerie", mcap: "Large", thesis: "Cartier, Van Cleef, IWC." },
      { ticker: "RMS", name: "Ferrari", sector: "Auto luxe", mcap: "Large", thesis: "Marque automobile la plus desirable." },
      { ticker: "EL", name: "Estee Lauder", sector: "Beaute luxe", mcap: "Large", thesis: "Leader beaute premium mondiale." },
    ]
  },
  { slug: "materiaux-construction", title: "Materiaux de Construction", icon: "Building", color: "#92400E",
    thesis: "La demande en materiaux de construction est soutenue par les plans d'infrastructure mondiaux.",
    items: [
      { ticker: "VMC", name: "Vulcan Materials", sector: "Agregats", mcap: "Large", thesis: "Premier producteur agregats US." },
      { ticker: "MLM", name: "Martin Marietta", sector: "Materiaux", mcap: "Large", thesis: "Materiaux construction infra." },
      { ticker: "CX", name: "Cemex", sector: "Ciment", mcap: "Mid", thesis: "Cimentier mondial diversifie." },
      { ticker: "SHW", name: "Sherwin-Williams", sector: "Peintures", mcap: "Mega", thesis: "Leader mondial peintures et revetements." },
      { ticker: "JHX", name: "James Hardie", sector: "Fibrociment", mcap: "Mid", thesis: "Leader fibrociment pour construction." },
    ]
  },
  { slug: "acier-metaux", title: "Acier & Metaux Industriels", icon: "Mountain", color: "#64748B",
    thesis: "L'acier et les metaux industriels beneficient de l'infrastructure et de la transition energetique.",
    items: [
      { ticker: "NUE", name: "Nucor", sector: "Acier", mcap: "Large", thesis: "Premier producteur acier US." },
      { ticker: "STLD", name: "Steel Dynamics", sector: "Acier", mcap: "Large", thesis: "Acier recycle, marges elevees." },
      { ticker: "FCX", name: "Freeport-McMoRan", sector: "Cuivre", mcap: "Large", thesis: "Premier producteur cuivre cote." },
      { ticker: "SCCO", name: "Southern Copper", sector: "Cuivre", mcap: "Large", thesis: "Producteur cuivre a bas cout." },
      { ticker: "AA", name: "Alcoa", sector: "Aluminium", mcap: "Mid", thesis: "Leader aluminium integre." },
    ]
  },
  { slug: "gestion-dechets", title: "Gestion des Dechets & Recyclage", icon: "Leaf", color: "#4ADE80",
    thesis: "L'economie circulaire et la gestion des dechets sont des megatendances environnementales.",
    items: [
      { ticker: "WM", name: "Waste Management", sector: "Dechets", mcap: "Large", thesis: "Leader gestion dechets US." },
      { ticker: "RSG", name: "Republic Services", sector: "Dechets", mcap: "Large", thesis: "Deuxieme gestionnaire dechets US." },
      { ticker: "WCN", name: "Waste Connections", sector: "Dechets", mcap: "Large", thesis: "Gestionnaire dechets en croissance." },
      { ticker: "CLH", name: "Clean Harbors", sector: "Dechets dangereux", mcap: "Mid", thesis: "Leader dechets dangereux et environnement." },
      { ticker: "SRCL", name: "Stericycle", sector: "Dechets medicaux", mcap: "Mid", thesis: "Gestion dechets medicaux." },
    ]
  },
  { slug: "services-publics", title: "Utilities & Services Publics", icon: "Zap", color: "#0284C7",
    thesis: "Les utilities offrent stabilite et dividendes. La demande electrique explose avec l'IA et les data centers.",
    items: [
      { ticker: "NEE", name: "NextEra Energy", sector: "Renouvelable", mcap: "Mega", thesis: "Plus grand producteur renouvelable." },
      { ticker: "SO", name: "Southern Company", sector: "Utility", mcap: "Large", thesis: "Utility diversifiee sud-est US." },
      { ticker: "DUK", name: "Duke Energy", sector: "Utility", mcap: "Large", thesis: "Grande utility regulee US." },
      { ticker: "AEP", name: "American Electric Power", sector: "Utility", mcap: "Large", thesis: "Reseau electrique 11 etats." },
      { ticker: "VST", name: "Vistra Corp", sector: "Producteur", mcap: "Large", thesis: "Producteur electricite, beneficiaire IA." },
    ]
  },
  { slug: "reit-commercial", title: "REIT Commercial & Bureaux", icon: "Building", color: "#475569",
    thesis: "Les REIT commerciaux offrent des rendements eleves mais font face au teletravail et aux taux.",
    items: [
      { ticker: "SPG", name: "Simon Property Group", sector: "Centres comm", mcap: "Large", thesis: "Leader centres commerciaux premium." },
      { ticker: "O", name: "Realty Income", sector: "Net lease", mcap: "Large", thesis: "Dividende mensuel, 650+ locataires." },
      { ticker: "PLD", name: "Prologis", sector: "Logistique", mcap: "Mega", thesis: "Leader REIT logistique mondial." },
      { ticker: "AMT", name: "American Tower", sector: "Tours telecom", mcap: "Large", thesis: "Leader tours de telecommunication." },
      { ticker: "CCI", name: "Crown Castle", sector: "Tours telecom", mcap: "Large", thesis: "Infrastructure telecom et fibre." },
    ]
  },
  { slug: "assurance-vie-epargne", title: "Assurance Vie & Epargne Retraite", icon: "ShieldCheck", color: "#4338CA",
    thesis: "Le vieillissement de la population stimule la demande en assurance vie et produits de retraite.",
    items: [
      { ticker: "MET", name: "MetLife", sector: "Assurance vie", mcap: "Large", thesis: "Leader assurance vie US." },
      { ticker: "PRU", name: "Prudential Financial", sector: "Assurance", mcap: "Large", thesis: "Assurance et gestion d'actifs." },
      { ticker: "AFL", name: "Aflac", sector: "Assurance supp", mcap: "Large", thesis: "Leader assurance supplementaire." },
      { ticker: "LNC", name: "Lincoln National", sector: "Annuites", mcap: "Mid", thesis: "Annuites et assurance vie." },
      { ticker: "VOYA", name: "Voya Financial", sector: "Retraite", mcap: "Mid", thesis: "Solutions retraite et investissement." },
    ]
  },
];

for (const theme of THEMES) {
  const itemCount = theme.items.length;
  await conn.execute(
    `INSERT INTO thematicWatchlists (id, slug, title, thesis, icon, color, whatToWatch, themeRisks, itemCount, sortOrder, isActive) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`,
    [wlId, theme.slug, theme.title, theme.thesis, theme.icon, theme.color,
     JSON.stringify(["Suivre les resultats trimestriels", "Surveiller les changements reglementaires", "Analyser les flux institutionnels"]),
     JSON.stringify(["Risque de valorisation elevee", "Risque reglementaire", "Risque de concentration sectorielle", "Risque de liquidite", "Risque macro-economique"]),
     itemCount, sortOrder]
  );
  for (const item of theme.items) {
    await conn.execute(
      `INSERT INTO watchlistItems (id, watchlistId, name, ticker, sector, marketCapRange, whyItMatters, catalysts, risks, sortOrder) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [itemId, wlId, item.name, item.ticker, item.sector, item.mcap, item.thesis,
       JSON.stringify(["Resultats trimestriels", "Guidance forward", "Mouvements institutionnels"]),
       JSON.stringify(["Valorisation", "Competition", "Regulation"]),
       itemId - 52000]
    );
    itemId++;
  }
  wlId++;
  sortOrder++;
  console.log(`  + ${theme.title} (${itemCount} items)`);
}

console.log(`\nBatch 3 done. ${THEMES.length} themes added.`);
const [total] = await conn.execute("SELECT COUNT(*) as cnt FROM thematicWatchlists");
console.log(`Total themes now: ${total[0].cnt}`);
await conn.end();
