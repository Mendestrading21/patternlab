import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const NEW_THEMES = [
  {
    slug: "or-valeurs-refuge",
    title: "Or & Valeurs Refuge : Le Retour du Métal Jaune",
    subtitle: "Pourquoi l'or atteint des records historiques et ce que cela signifie pour les investisseurs",
    sector: "Matières Premières",
    tags: "Or,Valeurs refuge,Banques centrales,Inflation,Géopolitique",
    readingTime: 20,
    status: "planned",
    executiveSummary: "L'or a franchi les $2,800/oz en 2025, porté par les achats massifs des banques centrales, l'incertitude géopolitique et la dédollarisation progressive. Ce thème analyse les fondamentaux du marché aurifère, les acteurs clés et les véhicules d'investissement.",
    context: "Le marché de l'or traverse une transformation structurelle. Les banques centrales, menées par la Chine, l'Inde et la Turquie, achètent des quantités record d'or physique pour diversifier leurs réserves. Parallèlement, les tensions géopolitiques et l'inflation persistante renforcent l'attrait du métal jaune comme valeur refuge.",
    drivers: JSON.stringify(["Achats banques centrales record (1,000+ tonnes/an)", "Dédollarisation et diversification des réserves", "Taux réels en baisse avec les baisses de taux Fed", "Tensions géopolitiques (Ukraine, Moyen-Orient, Taiwan)", "Demande joaillière asiatique en hausse"]),
    risks: JSON.stringify(["Hausse des taux réels si inflation repart", "Renforcement du dollar US", "Ventes massives de banques centrales", "Concurrence du Bitcoin comme 'or numérique'", "Ralentissement de la demande joaillière"]),
    keyPlayers: JSON.stringify([
      { name: "Newmont (NEM)", description: "Plus grand producteur d'or mondial" },
      { name: "Barrick Gold (GOLD)", description: "N°2 mondial, mines tier-1" },
      { name: "GLD (SPDR Gold)", description: "Plus grand ETF or physique" },
      { name: "Franco-Nevada (FNV)", description: "Modèle royalties/streaming" },
    ]),
  },
  {
    slug: "vehicules-electriques",
    title: "Véhicules Électriques : La Guerre des Prix",
    subtitle: "Comment la concurrence chinoise et la surcapacité redessinent le marché mondial des VE",
    sector: "Automobile & Énergie",
    tags: "VE,Tesla,BYD,Batteries,Transition,Subventions",
    readingTime: 22,
    status: "planned",
    executiveSummary: "Le marché des véhicules électriques entre dans une phase de consolidation. La guerre des prix initiée par Tesla et amplifiée par BYD comprime les marges de tous les constructeurs. Ce thème analyse la chaîne de valeur complète, de la mine de lithium au réseau de recharge.",
    context: "Les VE représentent ~20% des ventes mondiales de voitures neuves en 2025. Mais la croissance ralentit dans les marchés matures tandis que la Chine domine la chaîne de valeur. Les constructeurs traditionnels peinent à atteindre la rentabilité sur leurs modèles électriques.",
    drivers: JSON.stringify(["Subventions IRA aux US, Green Deal en Europe", "Baisse des coûts des batteries (-90% en 10 ans)", "Réglementation émissions de plus en plus stricte", "Infrastructure de recharge en expansion rapide", "Autonomie et technologie en amélioration constante"]),
    risks: JSON.stringify(["Guerre des prix et compression des marges", "Surcapacité mondiale de production", "Dépendance aux subventions gouvernementales", "Domination chinoise de la chaîne de valeur", "Problèmes d'approvisionnement en lithium/cobalt"]),
    keyPlayers: JSON.stringify([
      { name: "Tesla (TSLA)", description: "Leader mondial, Supercharger network" },
      { name: "BYD", description: "N°1 mondial en volume, intégration verticale" },
      { name: "Rivian (RIVN)", description: "Pick-ups électriques, partenariat Amazon" },
      { name: "CATL", description: "N°1 mondial des batteries" },
    ]),
  },
  {
    slug: "banques-taux-interet",
    title: "Banques & Taux d'Intérêt : Le Nouveau Paradigme",
    subtitle: "Comment la normalisation des taux redessine le secteur bancaire mondial",
    sector: "Finance & Banques",
    tags: "Banques,Taux,Fed,Crédit,NIM,Régulation",
    readingTime: 20,
    status: "planned",
    executiveSummary: "Après une décennie de taux zéro, la normalisation des taux d'intérêt transforme le secteur bancaire. Les marges nettes d'intérêt s'améliorent, mais les risques de crédit et la crise de l'immobilier commercial pèsent sur les bilans.",
    context: "Le secteur bancaire américain a traversé une mini-crise en 2023 (SVB, First Republic) qui a rappelé les risques de duration. En 2025-2026, les banques naviguent entre l'amélioration des marges et la détérioration potentielle de la qualité du crédit.",
    drivers: JSON.stringify(["Marges nettes d'intérêt en hausse", "Activité M&A et IPO en reprise", "Gestion de patrimoine en croissance", "Digitalisation et réduction des coûts", "Rachats d'actions massifs"]),
    risks: JSON.stringify(["Exposition à l'immobilier commercial", "Hausse des défauts de crédit", "Régulation renforcée (Bâle III endgame)", "Concurrence des fintechs", "Risque de récession"]),
    keyPlayers: JSON.stringify([
      { name: "JPMorgan (JPM)", description: "Plus grande banque US, diversification exemplaire" },
      { name: "Goldman Sachs (GS)", description: "Leader M&A et trading" },
      { name: "Bank of America (BAC)", description: "Sensible aux taux, forte base de dépôts" },
    ]),
  },
  {
    slug: "assurance-catastrophes",
    title: "Assurance & Catastrophes Climatiques : Le Hard Market",
    subtitle: "Pourquoi les primes d'assurance explosent et comment le secteur s'adapte au risque climatique",
    sector: "Assurance & Risk",
    tags: "Assurance,Climat,Primes,Réassurance,Catastrophes,Hard Market",
    readingTime: 18,
    status: "planned",
    executiveSummary: "Le secteur de l'assurance traverse un 'hard market' historique avec des hausses de primes à deux chiffres. Les catastrophes climatiques de plus en plus fréquentes et coûteuses redessinent le paysage du risque mondial.",
    context: "Les pertes assurées liées aux catastrophes naturelles ont dépassé $100 milliards par an en 2023-2024. Le secteur répond par des hausses de primes, des exclusions de couverture et une tarification plus sophistiquée du risque climatique.",
    drivers: JSON.stringify(["Hausse des primes (hard market)", "Rendements d'investissement améliorés", "Demande croissante de couverture cyber", "Consolidation du secteur", "Innovation InsurTech"]),
    risks: JSON.stringify(["Catastrophes climatiques extrêmes", "Risque de réserves insuffisantes", "Régulation des primes", "Concentration des risques", "Pression politique sur l'accessibilité"]),
    keyPlayers: JSON.stringify([
      { name: "Berkshire Hathaway (BRK-B)", description: "GEICO, Gen Re, plus grand assureur mondial" },
      { name: "Chubb (CB)", description: "Leader assurance commerciale" },
      { name: "Swiss Re", description: "N°2 mondial de la réassurance" },
    ]),
  },
  {
    slug: "data-centers-ia",
    title: "Data Centers & IA : L'Infrastructure de la Révolution",
    subtitle: "La demande explosive en puissance de calcul pour l'IA transforme le marché des data centers",
    sector: "Infrastructure Tech",
    tags: "Data Centers,IA,GPU,Énergie,Cloud,Hyperscalers",
    readingTime: 22,
    status: "planned",
    executiveSummary: "La révolution de l'IA générative crée une demande sans précédent en infrastructure de calcul. Les investissements dans les data centers dépassent $300 milliards par an, créant des opportunités dans l'immobilier, l'énergie et le refroidissement.",
    context: "Les hyperscalers (AWS, Azure, GCP) investissent massivement dans de nouveaux data centers pour répondre à la demande IA. Cette course crée des tensions sur l'approvisionnement en énergie, en GPU et en terrains adaptés.",
    drivers: JSON.stringify(["Demande IA en croissance exponentielle", "Investissements hyperscalers record", "Edge computing et 5G", "Souveraineté des données (régulation)", "Croissance du cloud computing"]),
    risks: JSON.stringify(["Surcapacité si la demande IA ralentit", "Contraintes énergétiques et environnementales", "Coûts de construction en hausse", "Pénurie de GPU et composants", "Risques de concentration géographique"]),
    keyPlayers: JSON.stringify([
      { name: "Equinix (EQIX)", description: "N°1 mondial des data centers, REIT" },
      { name: "Digital Realty (DLR)", description: "N°2 mondial, focus hyperscale" },
      { name: "NVIDIA (NVDA)", description: "Fournisseur de GPU pour IA" },
      { name: "Vertiv (VRT)", description: "Refroidissement et alimentation data centers" },
    ]),
  },
  {
    slug: "luxe-premium",
    title: "Luxe & Premium : Résilience ou Correction ?",
    subtitle: "Le secteur du luxe face au ralentissement chinois et à la normalisation post-Covid",
    sector: "Luxe & Consommation",
    tags: "Luxe,LVMH,Hermès,Chine,Premium,Consommation",
    readingTime: 20,
    status: "planned",
    executiveSummary: "Le secteur du luxe, longtemps considéré comme défensif, fait face à des vents contraires : ralentissement chinois, normalisation post-Covid et changement des habitudes de consommation. Ce thème analyse les gagnants et perdants de cette transition.",
    context: "Après deux années de croissance exceptionnelle post-Covid, le luxe connaît une normalisation. La Chine, qui représente 30-35% de la demande mondiale, ralentit. Les marques doivent naviguer entre exclusivité et accessibilité.",
    drivers: JSON.stringify(["Pricing power exceptionnel", "Croissance de la classe moyenne mondiale", "Tourisme international en reprise", "Digitalisation et e-commerce luxe", "Demande des millennials et Gen Z"]),
    risks: JSON.stringify(["Ralentissement économique chinois", "Normalisation post-Covid", "Contrefaçon et dilution de marque", "Changement des préférences consommateurs", "Risques géopolitiques (tarifs, sanctions)"]),
    keyPlayers: JSON.stringify([
      { name: "LVMH (MC.PA)", description: "N°1 mondial du luxe, 75+ maisons" },
      { name: "Hermès (RMS.PA)", description: "Marque la plus exclusive, marges record" },
      { name: "Ferrari (RACE)", description: "Ultra-luxe automobile, liste d'attente" },
    ]),
  },
  {
    slug: "immobilier-commercial",
    title: "Immobilier Commercial : La Grande Réinitialisation",
    subtitle: "Comment le télétravail, les taux élevés et le e-commerce transforment l'immobilier commercial",
    sector: "Immobilier & REITs",
    tags: "Immobilier,REITs,Bureaux,Logistique,Taux,Télétravail",
    readingTime: 20,
    status: "planned",
    executiveSummary: "L'immobilier commercial traverse sa plus grande transformation depuis des décennies. Les bureaux souffrent du télétravail, les centres commerciaux du e-commerce, tandis que la logistique et les data centers prospèrent.",
    context: "Les taux élevés ont provoqué une correction des valorisations immobilières. Les prêts arrivant à maturité créent un risque de refinancement. Mais certains segments (logistique, data centers, santé) restent très demandés.",
    drivers: JSON.stringify(["Baisse des taux attendue (soutien aux valorisations)", "Demande logistique e-commerce", "Data centers en forte demande", "Résidences seniors (démographie)", "Reconversion des bureaux"]),
    risks: JSON.stringify(["Taux élevés prolongés", "Vacance des bureaux record", "Refinancement des prêts à maturité", "Obsolescence des centres commerciaux", "Risques de défaut des emprunteurs"]),
    keyPlayers: JSON.stringify([
      { name: "Prologis (PLD)", description: "N°1 mondial logistique, REIT" },
      { name: "Equinix (EQIX)", description: "Data centers, REIT" },
      { name: "Welltower (WELL)", description: "Résidences seniors, REIT" },
    ]),
  },
  {
    slug: "petrole-geopolitique",
    title: "Pétrole & Géopolitique : L'Échiquier Énergétique",
    subtitle: "OPEC+, shale US, transition énergétique : les forces qui façonnent le marché pétrolier",
    sector: "Énergie & Pétrole",
    tags: "Pétrole,OPEC,Shale,Géopolitique,Énergie,Transition",
    readingTime: 22,
    status: "planned",
    executiveSummary: "Le marché pétrolier reste au cœur de la géopolitique mondiale. Entre les coupes OPEC+, la production record des US et la transition énergétique, les forces en jeu sont complexes et souvent contradictoires.",
    context: "Les US sont devenus le premier producteur mondial de pétrole (13+ Mb/j). L'OPEC+ maintient des coupes pour soutenir les prix. La transition énergétique crée un 'peak demand' débattu, tandis que les investissements E&P restent contraints.",
    drivers: JSON.stringify(["Discipline OPEC+ sur les coupes", "Demande asiatique en croissance", "Sous-investissement en E&P", "Tensions Moyen-Orient", "Stocks stratégiques bas"]),
    risks: JSON.stringify(["Surabondance si OPEC+ relâche les coupes", "Ralentissement économique mondial", "Accélération de la transition énergétique", "Production US shale record", "Risques géopolitiques (sanctions, conflits)"]),
    keyPlayers: JSON.stringify([
      { name: "ExxonMobil (XOM)", description: "Plus grande major pétrolière US" },
      { name: "Chevron (CVX)", description: "N°2 US, exposition GNL" },
      { name: "SLB (SLB)", description: "N°1 services pétroliers" },
    ]),
  },
  {
    slug: "dollar-devises",
    title: "Dollar & Devises : La Guerre Monétaire Silencieuse",
    subtitle: "Dédollarisation, BRICS, crypto : les forces qui remettent en question la suprématie du dollar",
    sector: "Devises & Macro",
    tags: "Dollar,Devises,BRICS,Dédollarisation,Fed,Crypto",
    readingTime: 18,
    status: "planned",
    executiveSummary: "Le dollar reste la monnaie de réserve mondiale, mais des forces structurelles remettent en question sa suprématie. Ce thème analyse les dynamiques monétaires mondiales et leurs implications pour les investisseurs.",
    context: "Les BRICS cherchent à réduire leur dépendance au dollar. Les banques centrales diversifient leurs réserves vers l'or et le yuan. Parallèlement, les stablecoins créent une nouvelle forme de 'dollarisation numérique'.",
    drivers: JSON.stringify(["Politique monétaire Fed (taux, QT)", "Déficits budgétaires US croissants", "Différentiels de taux entre zones", "Commerce international en mutation", "Adoption des stablecoins"]),
    risks: JSON.stringify(["Perte de confiance dans le dollar", "Fragmentation du système monétaire", "Volatilité des devises émergentes", "Risques de change pour les multinationales", "Instabilité des stablecoins"]),
    keyPlayers: JSON.stringify([
      { name: "DXY (Dollar Index)", description: "Indice de référence du dollar" },
      { name: "EUR/USD", description: "Paire la plus échangée au monde" },
      { name: "USD/CHF", description: "Franc suisse, valeur refuge" },
    ]),
  },
  {
    slug: "private-equity-alternatives",
    title: "Private Equity & Alternatives : La Démocratisation",
    subtitle: "Comment les investissements alternatifs deviennent accessibles aux investisseurs individuels",
    sector: "Finance Alternative",
    tags: "Private Equity,Alternatives,KKR,Blackstone,Secondaires,Retail",
    readingTime: 20,
    status: "planned",
    executiveSummary: "Le private equity et les investissements alternatifs, longtemps réservés aux institutionnels, s'ouvrent progressivement aux investisseurs individuels. Ce thème analyse les opportunités et les risques de cette démocratisation.",
    context: "Les géants du PE (Blackstone, KKR, Apollo) lancent des produits accessibles au retail. Les actifs sous gestion en alternatives dépassent $20T. La recherche de rendement dans un monde de taux normalisés pousse les investisseurs vers ces classes d'actifs.",
    drivers: JSON.stringify(["Démocratisation via produits retail", "Recherche de rendement et diversification", "Croissance du marché secondaire", "Consolidation du secteur", "Innovation produit (interval funds, BDCs)"]),
    risks: JSON.stringify(["Illiquidité des investissements", "Valorisations élevées", "Frais de gestion importants", "Manque de transparence", "Risque de 'denominator effect'"]),
    keyPlayers: JSON.stringify([
      { name: "Blackstone (BX)", description: "Plus grand gestionnaire alternatif mondial" },
      { name: "KKR (KKR)", description: "Pioneer du PE, diversification" },
      { name: "Apollo (APO)", description: "Crédit alternatif, assurance" },
      { name: "Ares Management (ARES)", description: "Crédit privé, leader BDC" },
    ]),
  },
];

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  
  for (const theme of NEW_THEMES) {
    // Check if slug already exists
    const [existing] = await conn.query('SELECT id FROM monthlyThemes WHERE slug = ?', [theme.slug]);
    if (existing.length > 0) {
      console.log(`SKIP: ${theme.slug} already exists`);
      continue;
    }
    
    const [result] = await conn.query(
      `INSERT INTO monthlyThemes (slug, title, subtitle, sector, tags, readingTime, status, executiveSummary, context, drivers, risks, keyPlayers, createdAt, updatedAt) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
      [theme.slug, theme.title, theme.subtitle, theme.sector, theme.tags, theme.readingTime, theme.status, theme.executiveSummary, theme.context, theme.drivers, theme.risks, theme.keyPlayers]
    );
    
    console.log(`ADDED: ${theme.slug} (id=${result.insertId})`);
  }
  
  const [count] = await conn.query('SELECT COUNT(*) as total FROM monthlyThemes');
  console.log(`\nTotal monthly themes: ${count[0].total}`);
  
  await conn.end();
}

main().catch(console.error);
