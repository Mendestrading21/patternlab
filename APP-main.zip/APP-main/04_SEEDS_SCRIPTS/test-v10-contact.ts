import { sendEmail, buildWmbEmailHtml } from "../server/email";
import { buildGenericModuleEmail } from "../server/emails/templates";

const EMAIL = "contact@wallstreetmarketbrief.ch";

async function main() {
  console.log(`\n[Test V10] Sending 3 test emails to ${EMAIL}...`);

  // 1. Generic wrapper
  const genericHtml = buildWmbEmailHtml({
    title: "Test V10 \u2014 Dark Shell + Light Core",
    preheader: "Ceci est un email test pour valider le nouveau design V10",
    bodyHtml: `
      <p style="color:#1A1A1A;font-size:15px;line-height:1.7;margin:0 0 18px;">
        Ceci est un <strong>email test</strong> pour valider le nouveau design V10 "Dark Shell + Light Core".
      </p>
      <p style="color:#374151;font-size:15px;line-height:1.7;margin:0 0 18px;">
        Le header et le footer restent en dark (#111318), tandis que le body est en blanc (#FFFFFF).
        Ce pattern est utilis\u00e9 par Bloomberg, Morning Brew et The Hustle.
      </p>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:16px 20px;background-color:#F7F8FA;border-radius:8px;border:1px solid #E5E7EB;">
            <p style="margin:0 0 8px;font-size:13px;font-weight:700;color:#1A1A1A;">Points cl\u00e9s du design V10 :</p>
            <p style="margin:0;font-size:14px;color:#374151;line-height:1.7;">
              Header dark avec logo WMB + ligne dor\u00e9e<br>
              Body blanc pour lisibilit\u00e9 maximale<br>
              Cartes \u00e9lev\u00e9es en #F7F8FA<br>
              Footer dark avec disclaimer<br>
              Compatible dark mode natif
            </p>
          </td>
        </tr>
      </table>
    `,
    ctaText: "Acc\u00e9der \u00e0 WMB",
    ctaUrl: "https://wallstreetmarketbrief.ch/dashboard",
  });

  const r1 = await sendEmail({
    to: EMAIL,
    subject: "[TEST V10] Logo V3 \u2014 Generic Wrapper",
    html: genericHtml,
  });
  console.log(`  Generic wrapper: ${r1 ? "OK" : "FAILED"}`);

  // 2. Module Debrief
  const debriefHtml = buildGenericModuleEmail({
    moduleType: "debrief",
    title: "Test V10 \u2014 Module Debrief USA",
    bodyHtml: `
      <p style="color:#1A1A1A;font-size:15px;line-height:1.7;margin:0 0 18px;">
        Ceci est un test du template <strong>module Debrief</strong> en V10.
      </p>
      <p style="color:#374151;font-size:15px;line-height:1.7;margin:0 0 18px;">
        Le scoreboard, les sections et le CTA utilisent d\u00e9sormais le design "Dark Shell + Light Core".
        Le body est blanc, les textes sont sombres, et les cartes sont en gris tr\u00e8s clair.
      </p>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:16px 20px;background-color:#F7F8FA;border-radius:8px;border:1px solid #E5E7EB;">
            <p style="margin:0 0 6px;font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#C8A960;font-weight:700;">EXEMPLE SCOREBOARD</p>
            <p style="margin:0;font-size:14px;color:#374151;line-height:1.7;">
              S&amp;P 500 : 5,528 (+1.2%)<br>
              Nasdaq : 17,382 (+1.8%)<br>
              VIX : 18.4 (R\u00e9gime neutre)
            </p>
          </td>
        </tr>
      </table>
    `,
    ctaText: "Lire le briefing complet",
    ctaUrl: "https://wallstreetmarketbrief.ch/dashboard",
  });

  const r2 = await sendEmail({
    to: EMAIL,
    subject: "[TEST V10] Logo V3 \u2014 Module Debrief",
    html: debriefHtml,
  });
  console.log(`  Module debrief: ${r2 ? "OK" : "FAILED"}`);

  // 3. Module Monde
  const mondeHtml = buildGenericModuleEmail({
    moduleType: "monde",
    title: "Test V10 \u2014 Module Monde",
    bodyHtml: `
      <p style="color:#1A1A1A;font-size:15px;line-height:1.7;margin:0 0 18px;">
        Ceci est un test du template <strong>module Monde</strong> en V10.
      </p>
      <p style="color:#374151;font-size:15px;line-height:1.7;margin:0 0 18px;">
        Les couleurs d'accent du module Monde (bleu #2563EB) sont utilis\u00e9es pour les badges et titres de section,
        tandis que le body reste en blanc pour la lisibilit\u00e9.
      </p>
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin:0 0 20px;">
        <tr>
          <td style="padding:16px 20px;background-color:#F7F8FA;border-radius:8px;border:1px solid #E5E7EB;">
            <p style="margin:0 0 6px;font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#2563EB;font-weight:700;">ZONES CL\u00c9S</p>
            <p style="margin:0;font-size:14px;color:#374151;line-height:1.7;">
              Europe : Stoxx 600 +0.8% | Asie : Nikkei +1.4%<br>
              \u00c9mergents : MSCI EM -0.3% | Chine : CSI 300 +0.5%
            </p>
          </td>
        </tr>
      </table>
    `,
    ctaText: "Lire la revue Monde",
    ctaUrl: "https://wallstreetmarketbrief.ch/dashboard",
  });

  const r3 = await sendEmail({
    to: EMAIL,
    subject: "[TEST V10] Logo V3 \u2014 Module Monde",
    html: mondeHtml,
  });
  console.log(`  Module monde: ${r3 ? "OK" : "FAILED"}`);

  console.log("\n[Test V10] Done! 3 emails sent to contact@wallstreetmarketbrief.ch.");
  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
