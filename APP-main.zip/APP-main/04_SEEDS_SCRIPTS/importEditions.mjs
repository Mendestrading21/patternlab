/**
 * Import all hardcoded editions into the editionModules DB table.
 * Run with: node scripts/importEditions.mjs
 * 
 * This script:
 * 1. Reads all 5 routers' catalogs + full data
 * 2. Inserts each edition into the editionModules table
 * 3. Skips duplicates (same weekNumber + year + moduleType)
 */
import 'dotenv/config';
import mysql from 'mysql2/promise';

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL not set");
  process.exit(1);
}

// Parse DATABASE_URL
const url = new URL(DATABASE_URL);
const connOpts = {
  host: url.hostname,
  port: parseInt(url.port || '3306'),
  user: url.username,
  password: url.password,
  database: url.pathname.slice(1),
  ssl: { rejectUnauthorized: true },
};

// ═══════════ USA EDITIONS ═══════════
const USA_CATALOG = [
  { weekNumber: 15, year: 2026, dateRange: "LUN 06/04 - VEN 10/04", title: "Cessez-le-feu US-Iran : Rally Historique, S&P +3,56%, Petrole -16%", subtitle: "VIX sous 20, Industrials +5,6%, TSMC +35% Q1, Consumer Sentiment record bas", publishedAt: "2026-04-12T07:00:00Z", slideCount: 25, tags: ["Cessez-le-feu", "Rally", "Petrole", "TSMC", "VIX", "Industrials", "Rotation"], file: "week15" },
  { weekNumber: 14, year: 2026, dateRange: "LUN 24/03 - VEN 28/03", title: "5e Semaine de Pertes, Nasdaq en Correction, Petrole >$100 et Iran Escalade", subtitle: "S&P -1,67%, Nasdaq -10,27%, VIX 30,43, Petrole $101, Mag 7 -$850B", publishedAt: "2026-03-29T07:00:00Z", slideCount: 25, tags: ["Correction", "Nasdaq", "Petrole", "Iran", "VIX", "Mag7", "Stagflation"], file: "week14" },
  { weekNumber: 13, year: 2026, dateRange: "LUN 17/03 - VEN 21/03", title: "4eme Semaine de Baisse, Fed Statu Quo, Petrole >$110 et Or en Chute Libre", subtitle: "S&P -1,9%, Fed hold, Micron beat, Or -10%, VIX 26,78", publishedAt: "2026-03-22T08:00:00Z", slideCount: 25, tags: ["Fed", "Petrole", "Or", "Micron", "Correction", "VIX"], file: "week13" },
  { weekNumber: 12, year: 2026, dateRange: "LUN 10/03 - VEN 14/03", title: "Correction Officielle, Broadcom Record et Rotation Energie", subtitle: "S&P -10%, Broadcom AI +108%, Exxon ATH, FOMC en vue", publishedAt: "2026-03-15T08:00:00Z", slideCount: 25, tags: ["Correction", "Broadcom", "Energie", "FOMC", "Stagflation", "Mag7"], file: "week12" },
  { weekNumber: 11, year: 2026, dateRange: "LUN 03/03 - VEN 07/03", title: "Petrole, NFP et Stagflation : Trois Chocs en Une Semaine", subtitle: "Petrole +35%, NFP -92K, VIX 29, Dollar en force, Or en baisse", publishedAt: "2026-03-08T08:00:00Z", slideCount: 25, tags: ["Petrole", "NFP", "Stagflation", "VIX", "Iran", "Dollar"], file: "week11" },
  { weekNumber: 10, year: 2026, dateRange: "LUN 02/03 - VEN 06/03", title: "Frappes Iran, Petrole en Spike & NFP Decisif -- Semaine a Haut Risque", subtitle: "Frappes Iran, petrole +5%, Broadcom en test, NFP vendredi", publishedAt: "2026-03-01T08:00:00Z", slideCount: 25, tags: ["Iran", "Petrole", "Broadcom", "NFP", "Defense"], file: "week10" },
  { weekNumber: 9, year: 2026, dateRange: "LUN 23/02 - VEN 27/02", title: "NVIDIA Earnings, PCE Inflation & Tarifs Douaniers -- Volatilite Attendue", subtitle: "NVIDIA Q4, PCE core, tarifs Trump, rotation sectorielle", publishedAt: "2026-02-22T08:00:00Z", slideCount: 23, tags: ["NVIDIA", "PCE", "Tarifs", "Rotation", "Tech"], file: "week9" },
  { weekNumber: 8, year: 2026, dateRange: "LUN 16/02 - VEN 20/02", title: "Fed Minutes, Walmart Earnings & Rebond Tech -- Marche en Equilibre", subtitle: "Fed minutes, Walmart Q4, rebond tech, VIX en baisse", publishedAt: "2026-02-15T08:00:00Z", slideCount: 22, tags: ["Fed", "Walmart", "Tech", "VIX", "Earnings"], file: "week8" },
];

// ═══════════ MONDE EDITIONS ═══════════
const MONDE_CATALOG = [
  { weekNumber: 15, year: 2026, dateRange: "LUN 06/04 - VEN 10/04", title: "Cessez-le-feu US-Iran : Rally Mondial, Petrole -16%, Europe +3,88%", subtitle: "STOXX 600 +3,88%, DAX +5,06%, Nikkei +4,2%, DXY -1,50%", publishedAt: "2026-04-12T07:00:00Z", slideCount: 22, tags: ["Cessez-le-feu", "Rally", "Petrole", "STOXX 600", "DAX", "Nikkei", "Emergents"], file: "mondeWeek15" },
  { weekNumber: 14, year: 2026, dateRange: "LUN 24/03 - VEN 28/03", title: "5e Semaine de Pertes, Petrole >$100, Nasdaq Correction, Iran Escalade", subtitle: "Marches internationaux, petrole, Iran, BCE, BNS, risk-off global", publishedAt: "2026-03-29T07:00:00Z", slideCount: 22, tags: ["Petrole", "Iran", "Correction", "BCE", "BNS", "Risk-Off"], file: "mondeWeek14" },
  { weekNumber: 13, year: 2026, dateRange: "LUN 17/03 - VEN 21/03", title: "4eme Semaine de Baisse, Petrole >$112, Or -10% -- Stress Global Maximum", subtitle: "Marches internationaux, petrole, or, BCE, BNS, conflit Iran", publishedAt: "2026-03-22T08:00:00Z", slideCount: 22, tags: ["Petrole", "Or", "Iran", "BCE", "BNS", "Correction"], file: "mondeWeek13" },
  { weekNumber: 12, year: 2026, dateRange: "LUN 10/03 - VEN 14/03", title: "STOXX 600 en Baisse, Nikkei -3.5%, Petrole >$100 -- Stress Global", subtitle: "Marches internationaux, petrole, BCE, defense europeenne, rotation", publishedAt: "2026-03-15T08:00:00Z", slideCount: 22, tags: ["STOXX 600", "Nikkei", "Petrole", "Defense", "BCE"], file: "mondeWeek12" },
  { weekNumber: 11, year: 2026, dateRange: "LUN 03/03 - VEN 07/03", title: "STOXX 600 -5.8%, Nikkei -4.2%, Petrole >$80 -- Choc Global", subtitle: "Marches internationaux, choc petrolier, BCE, BoJ, rotation defensive", publishedAt: "2026-03-08T08:00:00Z", slideCount: 22, tags: ["STOXX 600", "Nikkei", "Petrole", "BCE", "BoJ"], file: "mondeWeek11" },
  { weekNumber: 10, year: 2026, dateRange: "LUN 24/02 - VEN 28/02", title: "STOXX 600 Record, DAX +14.5% YTD, Frappes Iran -- Petrole en Spike", subtitle: "Marches internationaux, geopolitique, petrole, rotation Europe", publishedAt: "2026-03-01T08:00:00Z", slideCount: 22, tags: ["STOXX 600", "DAX", "Iran", "Petrole"], file: "mondeWeek10" },
  { weekNumber: 9, year: 2026, dateRange: "LUN 23/02 - VEN 27/02", title: "Europe en Tete, Nikkei +3.2%, Chine Relance -- Rotation Geographique", subtitle: "STOXX 600, Nikkei, relance Chine, rotation geographique", publishedAt: "2026-02-22T08:00:00Z", slideCount: 20, tags: ["Europe", "Nikkei", "Chine", "Rotation"], file: "mondeWeek9" },
  { weekNumber: 8, year: 2026, dateRange: "LUN 16/02 - VEN 20/02", title: "BCE Pause, Emergents en Hausse & Yen Sous Pression -- Divergence Monetaire", subtitle: "BCE, emergents, yen, divergence monetaire mondiale", publishedAt: "2026-02-15T08:00:00Z", slideCount: 19, tags: ["BCE", "Emergents", "Yen", "Monetaire"], file: "mondeWeek8" },
];

// ═══════════ SUISSE EDITIONS ═══════════
const SUISSE_CATALOG = [
  { weekNumber: 15, year: 2026, dateRange: "LUN 06/04 - VEN 10/04", title: "SMI Rebondit avec le Cessez-le-feu, CHF Fort, Confiance en Chute", subtitle: "SMI 13 183 (+2,53%), CHF refuge, consumer confidence -43", publishedAt: "2026-04-12T07:00:00Z", slideCount: 18, tags: ["SMI", "CHF", "BNS", "Consumer Confidence", "Cessez-le-feu"], file: "suisseWeek15" },
  { weekNumber: 14, year: 2026, dateRange: "LUN 24/03 - VEN 28/03", title: "SMI en Baisse, BNS a 0% Sans Marge, CHF Refuge Absolu", subtitle: "SMI -1,2%, CHF fort, BNS 0% sans marge, petrole >$100", publishedAt: "2026-03-29T07:00:00Z", slideCount: 18, tags: ["SMI", "BNS", "CHF", "Petrole", "Deflation"], file: "suisseWeek14" },
  { weekNumber: 13, year: 2026, dateRange: "LUN 17/03 - VEN 21/03", title: "BNS Maintient 0%, SMI -1.11%, CHF Refuge et Or en Chute", subtitle: "BNS statu quo, SMI 12 320, CHF/EUR 0.9580, Or -10%", publishedAt: "2026-03-22T08:00:00Z", slideCount: 18, tags: ["BNS", "SMI", "CHF", "Or", "Petrole"], file: "suisseWeek13" },
  { weekNumber: 12, year: 2026, dateRange: "LUN 10/03 - VEN 14/03", title: "SMI en Correction, BNS a 0% et CHF Fort", subtitle: "SMI -2.7%, CHF fort, BNS 20 mars, inflation 0.1%", publishedAt: "2026-03-15T08:00:00Z", slideCount: 18, tags: ["SMI", "CHF", "BNS", "Deflation", "Luxe"], file: "suisseWeek12" },
  { weekNumber: 11, year: 2026, dateRange: "LUN 03/03 - VEN 07/03", title: "SMI -6.56%, CHF Valeur Refuge & SNB le 20 Mars -- Choc Petrolier Global", subtitle: "SMI chute, CHF refuge, BNS 20 mars, inflation nulle", publishedAt: "2026-03-08T08:00:00Z", slideCount: 18, tags: ["SMI", "CHF", "BNS", "Petrole"], file: "suisseWeek11" },
  { weekNumber: 10, year: 2026, dateRange: "LUN 24/02 - VEN 28/02", title: "SMI Record 14,014 -- PIB +0.1%, BNS Profit Record CHF 26.58 Mds", subtitle: "SMI record, PIB stagnation, BNS profit record, CHF refuge", publishedAt: "2026-03-01T08:00:00Z", slideCount: 18, tags: ["SMI", "BNS", "PIB", "CHF"], file: "suisseWeek10" },
  { weekNumber: 9, year: 2026, dateRange: "LUN 23/02 - VEN 27/02", title: "SMI +1.8%, Nestle Sous Pression & CHF Stable -- Marche Suisse Resilient", subtitle: "SMI hausse, Nestle earnings, CHF stable, BNS attentiste", publishedAt: "2026-02-22T08:00:00Z", slideCount: 17, tags: ["SMI", "Nestle", "CHF", "BNS"], file: "suisseWeek9" },
  { weekNumber: 8, year: 2026, dateRange: "LUN 16/02 - VEN 20/02", title: "Roche +4%, UBS Resultats & Inflation CH 1.3% -- Pharma en Vedette", subtitle: "Roche hausse, UBS Q4, inflation suisse, pharma", publishedAt: "2026-02-15T08:00:00Z", slideCount: 16, tags: ["Roche", "UBS", "Inflation", "Pharma"], file: "suisseWeek8" },
];

// ═══════════ ACTIONS EDITIONS ═══════════
const ACTIONS_CATALOG = [
  { weekNumber: 15, year: 2026, dateRange: "LUN 06/04 - VEN 10/04", title: "Cessez-le-feu Rally : Rotation Massive vers les Cycliques", subtitle: "Industrials +5,6%, Tech +4,8%, Energy -3,8%, TSMC +35% Q1", publishedAt: "2026-04-12T07:00:00Z", slideCount: 30, tags: ["Cessez-le-feu", "Rotation", "Industrials", "TSMC", "Energy", "Banques"], file: "actionsWeek15" },
  { weekNumber: 14, year: 2026, dateRange: "LUN 24/03 - VEN 28/03", title: "Mag 7 -$850B, Defense +22%, Nasdaq en Correction -- Risk-Off Total", subtitle: "Meta survendue, RTX +22%, NVIDIA -14% YTD, Nike test consommateur, VIX 30", publishedAt: "2026-03-29T07:00:00Z", slideCount: 30, tags: ["Mag7", "Defense", "Correction", "Meta", "NVIDIA", "Nike", "VIX"], file: "actionsWeek14" },
  { weekNumber: 13, year: 2026, dateRange: "LUN 17/03 - VEN 21/03", title: "Micron Explose, Energie Domine, Mag 7 en Difficulte", subtitle: "Micron EPS $12,20, XOM ATH, Tesla -5%, Or -10%, VIX 26,78", publishedAt: "2026-03-22T08:00:00Z", slideCount: 30, tags: ["Micron", "Energie", "Tesla", "Mag7", "Correction", "Or"], file: "actionsWeek13" },
  { weekNumber: 12, year: 2026, dateRange: "LUN 10/03 - VEN 14/03", title: "Broadcom Record, Mag 7 en Correction et Rotation Energie", subtitle: "Broadcom AI +108%, Exxon ATH, Tesla -8.5%, FOMC en vue", publishedAt: "2026-03-15T08:00:00Z", slideCount: 30, tags: ["Broadcom", "Exxon", "Tesla", "Mag7", "Correction", "Energie"], file: "actionsWeek12" },
  { weekNumber: 11, year: 2026, dateRange: "LUN 03/03 - VEN 07/03", title: "Energie +4.8%, Tech -2.4%, Oracle & Adobe en Test -- Rotation Defensive Confirmee", subtitle: "Top movers, secteurs, earnings Oracle/Adobe, stagflation, watchlist", publishedAt: "2026-03-08T08:00:00Z", slideCount: 30, tags: ["Oracle", "Adobe", "Energie", "Stagflation", "Rotation", "CPI"], file: "actionsWeek11" },
  { weekNumber: 10, year: 2026, dateRange: "LUN 02/03 - VEN 06/03", title: "Frappes Iran, Dell +22% & Broadcom en Test -- Rotation Defensive Acceleree", subtitle: "Top movers, secteurs, earnings, geopolitique Iran, watchlist", publishedAt: "2026-03-01T08:00:00Z", slideCount: 30, tags: ["Iran", "Dell", "Broadcom", "Defense", "Energie", "Rotation"], file: "actionsWeek10" },
  { weekNumber: 9, year: 2026, dateRange: "LUN 23/02 - VEN 27/02", title: "NVIDIA +8%, Rotation Growth-Value & Tarifs en Vue -- Semaine Volatile", subtitle: "NVIDIA earnings, rotation sectorielle, tarifs douaniers, watchlist", publishedAt: "2026-02-22T08:00:00Z", slideCount: 28, tags: ["NVIDIA", "Rotation", "Tarifs", "Growth", "Value"], file: "actionsWeek9" },
  { weekNumber: 8, year: 2026, dateRange: "LUN 16/02 - VEN 20/02", title: "Walmart Solide, Tech en Rebond & Energie en Hausse -- Equilibre Fragile", subtitle: "Walmart Q4, rebond tech, energie, watchlist hebdo", publishedAt: "2026-02-15T08:00:00Z", slideCount: 26, tags: ["Walmart", "Tech", "Energie", "Earnings", "Rebond"], file: "actionsWeek8" },
];

// ═══════════ FIL ROUGE EDITIONS ═══════════
const FILROUGE_CATALOG = [
  { weekNumber: 15, year: 2026, dateRange: "MER 09/04 2026", title: "Cessez-le-feu US-Iran : Rally Historique, Petrole -16%, VIX sous 20", subtitle: "Delta marche, agenda 72h, watchlist, alerte cessez-le-feu/petrole/earnings", publishedAt: "2026-04-12T07:00:00Z", slideCount: 10, tags: ["Cessez-le-feu", "Rally", "Petrole", "VIX", "Earnings"], file: "filRougeWeek15" },
  { weekNumber: 14, year: 2026, dateRange: "MER 26/03 2026", title: "Nasdaq en Correction, Iran Escalade, Petrole >$100 -- Risk-Off Maximum", subtitle: "Delta marche, agenda 72h, watchlist, alerte Iran/Petrole/Stagflation", publishedAt: "2026-03-29T07:00:00Z", slideCount: 10, tags: ["Nasdaq", "Iran", "Petrole", "Correction", "Risk-Off"], file: "filRougeWeek14" },
  { weekNumber: 13, year: 2026, dateRange: "MER 19/03 2026", title: "Fed Statu Quo, Or en Chute Libre, Micron Explose -- Rotation Acceleree", subtitle: "Delta marche, agenda 72h, watchlist, alerte Fed/Or/Petrole", publishedAt: "2026-03-22T08:00:00Z", slideCount: 10, tags: ["Fed", "Or", "Micron", "Petrole", "Rotation"], file: "filRougeWeek13" },
  { weekNumber: 12, year: 2026, dateRange: "MER 12/03 2026", title: "Correction Officielle, FOMC en Vue et Nvidia GTC", subtitle: "Delta marche, agenda 72h, watchlist, alerte FOMC/GTC", publishedAt: "2026-03-15T08:00:00Z", slideCount: 10, tags: ["Correction", "FOMC", "Nvidia", "GTC", "Stagflation"], file: "filRougeWeek12" },
  { weekNumber: 11, year: 2026, dateRange: "MER 12/03 2026", title: "CPI Day, Oracle Earnings, Petrole >$80 -- Stagflation ou Soulagement", subtitle: "Delta marche, agenda 72h, watchlist, alerte CPI/Iran", publishedAt: "2026-03-12T06:30:00Z", slideCount: 10, tags: ["CPI", "Oracle", "Petrole", "Stagflation"], file: "filRougeWeek11" },
  { weekNumber: 10, year: 2026, dateRange: "MER 26/02 2026", title: "Frappes Iran, Petrole en Spike, Nvidia -8.5% -- Risk-Off Generalise", subtitle: "Delta marche, agenda 72h, watchlist, alerte risque Iran", publishedAt: "2026-02-26T06:30:00Z", slideCount: 10, tags: ["Iran", "Petrole", "Nvidia", "Risk-Off"], file: "filRougeWeek10" },
  { weekNumber: 9, year: 2026, dateRange: "MER 25/02 2026", title: "NVIDIA Earnings Impact, Rotation Sectorielle & Tarifs -- Marche en Tension", subtitle: "Delta marche, agenda 72h, watchlist, alerte tarifs", publishedAt: "2026-02-25T06:30:00Z", slideCount: 10, tags: ["NVIDIA", "Rotation", "Tarifs", "Tension"], file: "filRougeWeek9" },
  { weekNumber: 8, year: 2026, dateRange: "MER 18/02 2026", title: "Fed Minutes Dovish, Tech Rebondit & VIX en Baisse -- Accalmie Temporaire", subtitle: "Delta marche, agenda 72h, watchlist, alerte risque", publishedAt: "2026-02-18T06:30:00Z", slideCount: 10, tags: ["Fed", "Tech", "VIX", "Accalmie"], file: "filRougeWeek8" },
];

async function importAll() {
  const conn = await mysql.createConnection(connOpts);
  console.log("Connected to DB");

  let inserted = 0;
  let skipped = 0;
  let errors = 0;

  const allModules = [
    ...USA_CATALOG.map(c => ({ ...c, moduleType: "usa" })),
    ...MONDE_CATALOG.map(c => ({ ...c, moduleType: "monde" })),
    ...SUISSE_CATALOG.map(c => ({ ...c, moduleType: "suisse" })),
    ...ACTIONS_CATALOG.map(c => ({ ...c, moduleType: "actions" })),
    ...FILROUGE_CATALOG.map(c => ({ ...c, moduleType: "filrouge" })),
  ];

  for (const mod of allModules) {
    try {
      // Check if already exists
      const [existing] = await conn.execute(
        "SELECT id FROM editionModules WHERE weekNumber = ? AND year = ? AND moduleType = ? LIMIT 1",
        [mod.weekNumber, mod.year, mod.moduleType]
      );

      if (existing.length > 0) {
        console.log(`  SKIP ${mod.moduleType} S${mod.weekNumber} (already exists)`);
        skipped++;
        continue;
      }

      // Read the TS file and extract the JSON data
      const fs = await import('fs');
      const path = await import('path');
      const filePath = path.join(process.cwd(), 'server', 'routers', 'editions', `${mod.file}.ts`);
      
      if (!fs.existsSync(filePath)) {
        console.log(`  SKIP ${mod.moduleType} S${mod.weekNumber} (file not found: ${mod.file}.ts)`);
        skipped++;
        continue;
      }

      const content = fs.readFileSync(filePath, 'utf-8');
      
      // Extract the object literal from the TS file
      // Find the first { after the export const line and match to the end
      const exportMatch = content.match(/export const \w+[^=]*=\s*(\{[\s\S]*\});?\s*$/);
      if (!exportMatch) {
        console.log(`  ERROR ${mod.moduleType} S${mod.weekNumber} (could not parse export)`);
        errors++;
        continue;
      }

      let objStr = exportMatch[1];
      
      // Convert TS object literal to valid JSON
      // Remove trailing semicolons
      objStr = objStr.replace(/;\s*$/, '');
      
      // Handle template literals and string concatenation
      // Replace single quotes with double quotes (careful with apostrophes)
      // Actually, let's use a different approach - eval in a safe way
      // We'll use Function constructor to evaluate the object
      
      // Remove TypeScript type assertions
      objStr = objStr.replace(/as const/g, '');
      
      // The data is already structured - just store it as-is
      // We need to evaluate the JS object to get JSON
      const dataObj = new Function('return ' + objStr)();
      const jsonData = JSON.stringify(dataObj);

      await conn.execute(
        `INSERT INTO editionModules (weekNumber, year, moduleType, dateRange, title, subtitle, data, slideCount, tags, pdfUrl, isPublished, publishedAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
        [
          mod.weekNumber,
          mod.year,
          mod.moduleType,
          mod.dateRange,
          mod.title,
          mod.subtitle || null,
          jsonData,
          mod.slideCount,
          JSON.stringify(mod.tags),
          dataObj.pdfUrl || null,
          mod.publishedAt ? new Date(mod.publishedAt) : new Date(),
        ]
      );

      console.log(`  OK ${mod.moduleType} S${mod.weekNumber}`);
      inserted++;
    } catch (err) {
      console.error(`  ERROR ${mod.moduleType} S${mod.weekNumber}:`, err.message);
      errors++;
    }
  }

  console.log(`\nDone: ${inserted} inserted, ${skipped} skipped, ${errors} errors`);
  await conn.end();
}

importAll().catch(console.error);
