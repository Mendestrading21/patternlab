import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

// Theme content for 8 themes
const themes = [
  {
    id: 3,
    executiveSummary: `## Résumé exécutif
**Pourquoi ce thème compte maintenant :**
Le marché de l'IA générative est estimé à 67 milliards USD en 2025, avec une projection de 207 milliards USD d'ici 2030 (source : Bloomberg Intelligence, 2024). L'adoption en entreprise s'accélère : 65% des organisations utilisent désormais l'IA générative, contre 33% début 2024 (McKinsey Global Survey, 2025). NVIDIA a dépassé les 3 000 milliards USD de capitalisation, devenant brièvement la plus grande entreprise mondiale.

**7 points clés :**
1. Le marché des GPU pour l'IA représente ~80% des revenus data center de NVIDIA (~47 Mrd USD en FY2025)
2. Microsoft a investi plus de 13 milliards USD dans OpenAI et intègre Copilot dans toute sa suite
3. Les dépenses en infrastructure IA des hyperscalers dépassent 200 Mrd USD en 2025 (capex combiné AWS + Azure + GCP)
4. La course aux modèles open-source s'intensifie : Meta (Llama 3), Mistral, et DeepSeek challengent les modèles propriétaires
5. La régulation avance : EU AI Act en vigueur depuis août 2024, débats au Congrès US sur la gouvernance IA
6. Les revenus d'Anthropic (Claude) auraient atteint ~1 Mrd USD ARR début 2025 (source : The Information)
7. Le coût d'entraînement des modèles frontier dépasse 100 millions USD, créant des barrières à l'entrée massives`,
    context: `## Contexte & Historique
**Chronologie clé :**
- **2017** : Google publie "Attention Is All You Need", l'architecture Transformer qui fonde l'IA générative moderne
- **Nov 2022** : Lancement de ChatGPT par OpenAI — 100 millions d'utilisateurs en 2 mois, record historique
- **2023** : Course aux armements IA — Google (Bard/Gemini), Meta (Llama 2), Anthropic (Claude 2), Microsoft (Copilot)
- **2024** : GPT-4o, Claude 3.5 Sonnet, Gemini 1.5 Pro — les modèles deviennent multimodaux (texte, image, audio, vidéo)
- **Août 2024** : EU AI Act entre en vigueur — première régulation majeure au monde
- **2025** : L'IA agentique émerge — les modèles passent de la génération à l'exécution autonome de tâches
- **Fév 2025** : DeepSeek R1 (Chine) démontre qu'on peut rivaliser avec GPT-4 à une fraction du coût d'entraînement

**État actuel :**
Le secteur est dominé par un oligopole de fait : OpenAI, Google DeepMind, Anthropic, Meta AI, et Mistral. La concentration du compute (NVIDIA contrôle ~80% du marché GPU IA) crée un goulot d'étranglement. L'adoption entreprise passe du "proof of concept" au déploiement à l'échelle, avec des ROI encore difficiles à quantifier pour la majorité des cas d'usage.`,
    sectorMap: `## Cartographie du Secteur
**Chaîne de valeur de l'IA générative :**

| Segment | Acteurs clés | Part de marché estimée |
|---------|-------------|----------------------|
| **Hardware / Compute** | NVIDIA, AMD, Intel, Google (TPU) | NVIDIA ~80% GPU IA |
| **Cloud / Infrastructure** | AWS, Azure, GCP, Oracle Cloud | AWS ~31%, Azure ~25% |
| **Modèles Foundation** | OpenAI, Google, Anthropic, Meta, Mistral | OpenAI ~60% usage entreprise |
| **Plateformes / Middleware** | Databricks, Snowflake, Palantir | Marché fragmenté |
| **Applications verticales** | Salesforce, Adobe, ServiceNow | Intégration IA dans SaaS existant |
| **Open Source** | Meta (Llama), Mistral, Hugging Face | ~30% des déploiements |

**Sous-segments en forte croissance :**
- **IA agentique** : Systèmes autonomes capables d'exécuter des workflows complexes
- **Retrieval-Augmented Generation (RAG)** : Combinaison LLM + bases de données propriétaires
- **Multimodalité** : Modèles traitant texte, image, audio et vidéo simultanément
- **Edge AI** : Déploiement de modèles compacts sur appareils locaux (smartphones, IoT)`,
    drivers: `## Les moteurs du secteur
**Facteurs macro :**
- **Productivité** : McKinsey estime que l'IA générative pourrait ajouter 2 600 à 4 400 milliards USD de valeur annuelle à l'économie mondiale
- **Taux d'intérêt** : La baisse attendue des taux favorise les valorisations des entreprises tech à forte croissance
- **Géopolitique** : Course technologique US-Chine — les restrictions d'export de puces NVIDIA vers la Chine (règles d'octobre 2023) restructurent le marché

**Facteurs sectoriels :**
- **Loi de mise à l'échelle (scaling laws)** : Plus de compute = meilleurs modèles — incite des investissements massifs
- **Adoption entreprise** : Passage du POC au déploiement — Accenture rapporte 3 Mrd USD de commandes IA en 2024
- **Coût en baisse** : Le coût par token a chuté de ~90% entre GPT-3.5 et GPT-4o mini (source : OpenAI pricing)
- **Open source** : Llama 3 et Mistral démocratisent l'accès, réduisant la dépendance aux API propriétaires

**Facteurs réglementaires :**
- **EU AI Act** : Classification par risque, obligations de transparence pour les modèles "à usage général"
- **Executive Order Biden (oct 2023)** : Exigences de reporting pour les modèles frontier (>10^26 FLOP)
- **Copyright** : Procès en cours (NYT vs OpenAI) — l'issue déterminera le cadre juridique des données d'entraînement`,
    marketSize: `## Taille du marché
| Segment | 2024 | 2025E | 2030E | CAGR |
|---------|------|-------|-------|------|
| IA générative (total) | 44 Mrd USD | 67 Mrd USD | 207 Mrd USD | ~30% |
| GPU / Accélérateurs IA | 61 Mrd USD | 85 Mrd USD | 200+ Mrd USD | ~25% |
| Logiciel IA entreprise | 20 Mrd USD | 32 Mrd USD | 100 Mrd USD | ~35% |
| Services IA / Consulting | 15 Mrd USD | 25 Mrd USD | 80 Mrd USD | ~35% |

*Sources : Bloomberg Intelligence (2024), Gartner (2024), IDC Worldwide AI Spending Guide*

**Répartition géographique :** US ~55%, Europe ~20%, Chine ~15%, Reste du monde ~10%
**Répartition par vertical :** Tech/Media 30%, Finance 20%, Santé 15%, Industrie 12%, Retail 10%, Autres 13%`,
    businessModels: `## Modèles économiques
**1. Modèle "Compute as a Service" (NVIDIA, AMD)**
- Vente de GPU/accélérateurs + licences logicielles (CUDA, TensorRT)
- Marges brutes : NVIDIA ~75% (data center), AMD ~50%
- Avantage compétitif : écosystème CUDA, effet de réseau développeurs

**2. Modèle "API / Platform" (OpenAI, Anthropic, Google)**
- Facturation au token (input/output) — prix en baisse constante
- OpenAI : ~3.4 Mrd USD ARR estimé (fin 2024), mais pertes opérationnelles significatives
- Anthropic : ~1 Mrd USD ARR, financé par Amazon (8 Mrd USD investis)

**3. Modèle "Copilot / SaaS intégré" (Microsoft, Salesforce, Adobe)**
- Premium mensuel sur abonnement existant (Microsoft 365 Copilot : +30 USD/mois/utilisateur)
- Potentiel de revenus : Microsoft estime 10+ Mrd USD de revenus Copilot à terme
- Marge incrémentale élevée car infrastructure existante

**4. Modèle "Open Source + Services" (Meta, Mistral, Hugging Face)**
- Modèle gratuit + monétisation via cloud, support entreprise, fine-tuning
- Meta : Llama est un outil stratégique pour réduire la dépendance à Google/OpenAI
- Hugging Face : valorisé ~4.5 Mrd USD, plateforme de référence pour le ML`,
    keyPlayers: `## Les acteurs principaux
**Leaders (Large Cap) :**
| Entreprise | Ticker | Pays | Cap. boursière | Revenus IA estimés | Spécialité |
|-----------|--------|------|---------------|-------------------|------------|
| NVIDIA | NVDA | US | ~3 200 Mrd USD | ~47 Mrd USD (DC) | GPU IA, CUDA, DGX |
| Microsoft | MSFT | US | ~3 100 Mrd USD | ~25 Mrd USD | Azure AI, Copilot, OpenAI |
| Alphabet/Google | GOOGL | US | ~2 200 Mrd USD | ~15 Mrd USD | Gemini, GCP, DeepMind |
| Meta | META | US | ~1 500 Mrd USD | ~10 Mrd USD | Llama, IA publicitaire |
| Amazon/AWS | AMZN | US | ~2 100 Mrd USD | ~12 Mrd USD | Bedrock, Anthropic |

**Challengers :**
| Entreprise | Ticker | Cap. boursière | Focus |
|-----------|--------|---------------|-------|
| AMD | AMD | ~220 Mrd USD | MI300X, alternative NVIDIA |
| Broadcom | AVGO | ~900 Mrd USD | ASIC custom, networking IA |
| Palantir | PLTR | ~180 Mrd USD | IA entreprise, défense |
| Snowflake | SNOW | ~55 Mrd USD | Data cloud + IA |

**Émergents / Privés :**
- OpenAI (valorisation ~157 Mrd USD) — leader ChatGPT/GPT-4
- Anthropic (valorisation ~60 Mrd USD) — Claude, focus sécurité IA
- Mistral (valorisation ~6 Mrd USD) — champion européen open-source`,
    etfExposure: `## ETF & Exposition
| ETF | Ticker | AUM | Frais | Focus |
|-----|--------|-----|-------|-------|
| Global X Artificial Intelligence | BOTZ | ~2.5 Mrd USD | 0.68% | Robotique & IA |
| iShares Exponential Technologies | XT | ~3.2 Mrd USD | 0.46% | Technologies exponentielles |
| Roundhill Generative AI & Tech | CHAT | ~700 M USD | 0.75% | Pure-play IA générative |
| WisdomTree Artificial Intelligence | WTAI | ~400 M USD | 0.40% | IA large spectre |
| First Trust Nasdaq AI & Robotics | ROBT | ~400 M USD | 0.65% | IA + Robotique |

**Avantages des ETF IA :**
- Diversification face au risque de concentration (NVIDIA représente parfois 15-20% d'un ETF)
- Exposition aux "pioches et pelles" (infrastructure) plutôt qu'aux modèles (risque technologique élevé)

**Limites :**
- Forte corrélation avec le Nasdaq — pas de décorrélation sectorielle réelle
- Les plus grandes positions sont souvent les mêmes mega-caps (NVIDIA, Microsoft, Google)
- Les entreprises privées (OpenAI, Anthropic) ne sont pas accessibles via ETF

*Note : Les ETF mentionnés sont à titre informatif. Ceci ne constitue pas une recommandation.*`,
    catalysts: `## Catalyseurs à court terme
**T1-T2 2026 :**
- **Résultats NVIDIA (mai 2026)** : Le baromètre du secteur — guidance data center scrutée par le marché
- **Apple Intelligence expansion** : Déploiement de fonctionnalités IA sur iPhone 16/17, potentiel d'adoption massive
- **GPT-5 / Claude 4** : Prochaine génération de modèles frontier attendue — impact sur les benchmarks et l'adoption
- **Réglementation US** : Débats au Congrès sur un cadre fédéral IA — incertitude réglementaire

**T3-T4 2026 :**
- **EU AI Act application complète** : Obligations de conformité pour les modèles à usage général (août 2026)
- **Adoption entreprise** : Premiers ROI mesurables des déploiements Copilot/Gemini à grande échelle
- **IA agentique** : Lancement de produits autonomes (agents de code, agents de recherche)
- **Concurrence chinoise** : DeepSeek et Baidu continuent de progresser malgré les restrictions

**Événements clés à surveiller :**
- Earnings NVIDIA, Microsoft, Google, Meta (trimestriels)
- Conférence GTC NVIDIA (mars 2026)
- Google I/O et WWDC Apple (mai-juin 2026)
- Décisions FTC/DOJ sur les pratiques anticoncurrentielles dans l'IA`,
    risks: `## Risques
| Risque | Probabilité | Impact | Horizon |
|--------|------------|--------|---------|
| Bulle de valorisation IA | Moyenne | Élevé | 6-18 mois |
| Concentration NVIDIA | Élevée | Élevé | 12-24 mois |
| Régulation restrictive | Moyenne | Moyen | 12-36 mois |
| Déception ROI entreprise | Moyenne-Haute | Élevé | 6-12 mois |
| Risque géopolitique (Chine) | Moyenne | Élevé | Permanent |

**Détail des risques :**
- **Bulle de valorisation** : Le ratio P/E forward de NVIDIA (~35x) et les multiples des pure-plays IA intègrent une croissance parfaite. Toute déception sur les commandes GPU pourrait déclencher une correction sectorielle de 20-30%.
- **Concentration NVIDIA** : ~80% du marché GPU IA. Si AMD (MI300X) ou les ASIC custom (Google TPU, Amazon Trainium) gagnent des parts, NVIDIA pourrait voir ses marges se comprimer.
- **Déception ROI** : Gartner prédit que 30% des projets IA générative seront abandonnés après le POC d'ici fin 2025. Si les entreprises réduisent leurs budgets IA, l'ensemble de la chaîne de valeur serait impacté.
- **Régulation** : L'EU AI Act impose des obligations coûteuses. Une régulation similaire aux US pourrait ralentir l'innovation et augmenter les coûts de conformité.
- **Géopolitique** : Les restrictions d'export de puces vers la Chine pourraient s'intensifier, mais aussi stimuler l'innovation chinoise indépendante (DeepSeek).`,
    scenarios: `## Scénarios
**Scénario haussier (Bull) :**
**SI** l'adoption entreprise de l'IA générative s'accélère au-delà des projections (>80% des entreprises Fortune 500 en production d'ici fin 2026), **ET SI** les revenus Copilot/Gemini dépassent les attentes, **ALORS** le marché pourrait réévaluer à la hausse l'ensemble du secteur. Les GPU NVIDIA resteraient en pénurie, soutenant des marges >70%. Objectif sectoriel : +30-50% sur 12 mois.

**Scénario de base (Base) :**
L'adoption continue à un rythme soutenu mais avec des ajustements. Certaines entreprises réduisent leurs budgets IA après des POC décevants, tandis que d'autres accélèrent. NVIDIA maintient sa dominance mais AMD gagne 10-15% de parts. Le marché croît de ~25-30% annuellement. Volatilité élevée autour des earnings.

**Scénario baissier (Bear) :**
**SINON**, si les entreprises constatent un ROI insuffisant sur leurs investissements IA (le "AI winter" partiel), **ET SI** la régulation se durcit significativement (moratoire sur les modèles frontier), **ALORS** les valorisations pourraient corriger de 30-50%. Les commandes GPU ralentiraient, NVIDIA verrait ses revenus data center stagner, et les pure-plays IA (Palantir, C3.ai) seraient les plus impactés.

*Rappel : Ces scénarios sont des exercices de réflexion, pas des prédictions. Aucun scénario n'est plus probable qu'un autre.*`,
    glossary: `## Glossaire du secteur
1. **LLM (Large Language Model)** : Modèle d'IA entraîné sur de vastes corpus de texte, capable de générer du langage naturel. Exemples : GPT-4, Claude, Gemini, Llama.
2. **Transformer** : Architecture de réseau de neurones inventée par Google en 2017, base de tous les LLM modernes. Utilise un mécanisme d'"attention" pour traiter les séquences.
3. **Token** : Unité de texte traitée par un LLM (~0.75 mot en anglais). La facturation des API se fait au token (input + output).
4. **Fine-tuning** : Processus d'adaptation d'un modèle pré-entraîné à une tâche ou un domaine spécifique avec des données supplémentaires.
5. **RAG (Retrieval-Augmented Generation)** : Technique combinant un LLM avec une base de données externe pour améliorer la précision et réduire les hallucinations.
6. **Hallucination** : Génération de contenu faux ou inventé par un LLM, présenté avec confiance. Risque majeur pour les applications critiques.
7. **GPU (Graphics Processing Unit)** : Processeur massivement parallèle, devenu le standard pour l'entraînement et l'inférence IA. NVIDIA domine avec ses puces H100/B200.
8. **Inference** : Utilisation d'un modèle entraîné pour générer des réponses. Représente la majorité des coûts opérationnels en production.
9. **FLOP (Floating Point Operation)** : Mesure de la puissance de calcul. Les modèles frontier nécessitent >10^25 FLOP pour l'entraînement.
10. **IA Agentique** : Systèmes IA capables d'exécuter des tâches de manière autonome, en planifiant et utilisant des outils. Prochaine frontière de l'IA générative.`,
    checklist: `## Checklist de suivi
**Données à surveiller :**
- Revenus data center NVIDIA (trimestriel) — baromètre #1 du secteur
- Capex des hyperscalers (AWS, Azure, GCP) — indicateur d'investissement IA
- Nombre d'utilisateurs ChatGPT/Copilot (mensuel si disponible)
- Indice NASDAQ-100 et sous-indice IA
- Prix des GPU H100/B200 sur le marché secondaire

**Dates clés :**
- Earnings NVIDIA : mai 2026, août 2026
- Earnings Microsoft/Google/Meta : avril 2026, juillet 2026
- GTC NVIDIA : mars 2026
- EU AI Act — application complète : août 2026
- Google I/O : mai 2026
- WWDC Apple : juin 2026

**Indicateurs de retournement :**
- Baisse des commandes GPU NVIDIA (lead time)
- Réduction des budgets IA entreprise (surveys Gartner/McKinsey)
- Augmentation des licenciements dans les startups IA
- Régulation restrictive majeure (moratoire, interdiction)`,
    conclusion: `## Conclusion
L'IA générative est le thème d'investissement le plus transformateur de cette décennie. Le marché est en phase d'adoption rapide, avec des investissements massifs dans l'infrastructure (GPU, cloud, data centers) et une intégration croissante dans les logiciels d'entreprise.

**Points clés à retenir :**
- Le secteur est dominé par un petit nombre d'acteurs (NVIDIA, Microsoft, Google) — la concentration est à la fois une force et un risque
- Les valorisations intègrent une croissance parfaite — toute déception pourrait entraîner une correction significative
- La régulation (EU AI Act, débats US) introduit de l'incertitude mais aussi de la structure
- L'open source (Llama, Mistral) démocratise l'accès et pourrait redistribuer les cartes

*Ce dossier est fourni à titre informatif et éducatif uniquement. Il ne constitue en aucun cas un conseil d'investissement. Les marchés comportent des risques de perte en capital. Consultez un professionnel qualifié avant toute décision d'investissement.*`,
    sources: `## Sources
1. Bloomberg Intelligence — "Generative AI Market to Reach $1.3 Trillion by 2032" (2024)
2. McKinsey Global Survey — "The State of AI in 2025" (janvier 2025)
3. Gartner — "Predicts 2025: AI and the Future of Work" (2024)
4. NVIDIA — Rapports financiers FY2025 (SEC filings)
5. IDC — Worldwide Artificial Intelligence Spending Guide (2024)
6. The Information — "OpenAI Revenue Tracker" (2025)
7. EU AI Act — Texte officiel, Journal Officiel de l'UE (2024)
8. Grand View Research — "Generative AI Market Size Report" (2024)
9. Accenture — "Technology Vision 2025: AI at Scale"
10. Stanford HAI — "AI Index Report 2025"`
  },
  {
    id: 4,
    executiveSummary: `## Résumé exécutif
**Pourquoi ce thème compte maintenant :**
Le marché mondial de la cybersécurité est estimé à 203 milliards USD en 2025, avec une croissance annuelle de ~12-14% (source : Gartner, 2024). Les cyberattaques ont augmenté de 38% en 2024 par rapport à 2023 (Check Point Research). Le coût moyen d'une violation de données atteint 4.88 millions USD en 2024, un record (IBM Cost of a Data Breach Report).

**7 points clés :**
1. Le ransomware reste la menace #1 : les paiements de rançons ont dépassé 1.1 milliard USD en 2024 (Chainalysis)
2. L'IA est utilisée à la fois par les attaquants (phishing automatisé, deepfakes) et les défenseurs (détection, réponse)
3. Le modèle Zero Trust devient le standard — 67% des entreprises l'ont adopté ou sont en cours (Okta, 2024)
4. La réglementation s'intensifie : NIS2 (UE), DORA (finance), SEC cyber disclosure rules (US)
5. CrowdStrike domine l'endpoint avec ~18% de part de marché, suivi de Microsoft et SentinelOne
6. Le déficit de talents en cybersécurité atteint 4 millions de postes non pourvus mondialement (ISC2, 2024)
7. Les dépenses gouvernementales en cybersécurité explosent : budget US DoD cyber >13 Mrd USD en 2025`,
    context: `## Contexte & Historique
**Chronologie clé :**
- **2013** : Attaque Target — 40 millions de cartes bancaires compromises, prise de conscience du risque cyber
- **2017** : WannaCry et NotPetya — ransomwares mondiaux, dommages >10 Mrd USD
- **2020** : SolarWinds — attaque supply chain sophistiquée attribuée à la Russie, 18 000 organisations touchées
- **2021** : Colonial Pipeline — ransomware paralyse l'approvisionnement en carburant de la côte Est US
- **2023** : MOVEit — exploitation zero-day massive, >2 500 organisations impactées
- **2024** : CrowdStrike incident (juillet) — mise à jour défectueuse cause une panne mondiale, 8.5 millions de machines Windows affectées
- **2025** : L'IA générative transforme le paysage — attaques plus sophistiquées, défenses plus automatisées

**État actuel :**
Le secteur est en croissance structurelle, porté par la numérisation, le cloud, le travail hybride et l'explosion des surfaces d'attaque (IoT, OT, API). La consolidation s'accélère : les plateformes intégrées (CrowdStrike, Palo Alto) gagnent des parts face aux solutions point-à-point.`,
    sectorMap: `## Cartographie du Secteur
| Segment | Acteurs clés | Taille estimée 2025 |
|---------|-------------|-------------------|
| **Endpoint / XDR** | CrowdStrike, SentinelOne, Microsoft | ~25 Mrd USD |
| **Network Security** | Palo Alto, Fortinet, Check Point | ~22 Mrd USD |
| **Cloud Security (CNAPP)** | Wiz, Palo Alto, CrowdStrike | ~18 Mrd USD |
| **Identity & Access (IAM)** | Okta, CyberArk, Microsoft Entra | ~20 Mrd USD |
| **SIEM / SOAR** | Splunk (Cisco), Microsoft Sentinel | ~12 Mrd USD |
| **Email Security** | Proofpoint, Mimecast, Abnormal | ~8 Mrd USD |
| **Data Security / DLP** | Varonis, Rubrik, Cohesity | ~10 Mrd USD |

**Tendances structurelles :**
- **Platformisation** : Les clients veulent moins de vendors — CrowdStrike et Palo Alto se positionnent comme plateformes unifiées
- **Cloud-native** : Migration des solutions on-premise vers le cloud (SASE, CNAPP)
- **IA défensive** : Détection automatisée, réponse autonome, réduction du temps de réponse (MTTD/MTTR)`,
    drivers: `## Les moteurs du secteur
**Facteurs macro :**
- **Numérisation accélérée** : Le cloud, l'IoT et le travail hybride élargissent la surface d'attaque de manière exponentielle
- **Géopolitique** : Les cyberattaques étatiques (Russie, Chine, Iran, Corée du Nord) augmentent en fréquence et sophistication
- **Réglementation** : NIS2 (UE), DORA (secteur financier), SEC disclosure rules — les entreprises DOIVENT investir

**Facteurs sectoriels :**
- **Menaces IA** : Les attaquants utilisent l'IA pour automatiser le phishing, créer des deepfakes et contourner les défenses traditionnelles
- **Ransomware-as-a-Service** : Le modèle RaaS démocratise les cyberattaques — des groupes comme LockBit et BlackCat opèrent comme des franchises
- **Pénurie de talents** : 4 millions de postes non pourvus poussent les entreprises vers l'automatisation et les services managés (MSSP)
- **Cloud adoption** : La migration vers le cloud crée de nouveaux besoins en CNAPP, CSPM, et CWPP

**Facteurs réglementaires :**
- **NIS2 (UE)** : Obligations de cybersécurité étendues à 18 secteurs, amendes jusqu'à 10M EUR ou 2% du CA
- **DORA (UE)** : Résilience numérique obligatoire pour le secteur financier (en vigueur janvier 2025)
- **SEC Cyber Rules (US)** : Divulgation obligatoire des incidents cyber dans les 4 jours ouvrés`,
    marketSize: `## Taille du marché
| Segment | 2024 | 2025E | 2030E | CAGR |
|---------|------|-------|-------|------|
| Cybersécurité (total) | 183 Mrd USD | 203 Mrd USD | 350 Mrd USD | ~12% |
| Cloud Security | 14 Mrd USD | 18 Mrd USD | 45 Mrd USD | ~22% |
| Endpoint / XDR | 20 Mrd USD | 25 Mrd USD | 40 Mrd USD | ~14% |
| Identity (IAM) | 16 Mrd USD | 20 Mrd USD | 35 Mrd USD | ~15% |
| Services managés (MSSP) | 30 Mrd USD | 38 Mrd USD | 70 Mrd USD | ~16% |

*Sources : Gartner (2024), IDC Worldwide Security Spending Guide, MarketsandMarkets*

**Répartition géographique :** US ~45%, Europe ~25%, Asie-Pacifique ~20%, Reste du monde ~10%`,
    businessModels: `## Modèles économiques
**1. Modèle SaaS / Abonnement (CrowdStrike, Zscaler, SentinelOne)**
- ARR récurrent, facturation par endpoint/utilisateur/module
- CrowdStrike : ARR ~3.9 Mrd USD, marge brute ~78%, rétention nette >120%
- Avantage : revenus prévisibles, effet de plateforme (cross-sell de modules)

**2. Modèle Appliance + Abonnement (Fortinet, Palo Alto)**
- Vente de hardware (firewalls) + abonnements logiciels/services
- Fortinet : revenus ~5.8 Mrd USD, marge brute ~78%, forte base installée
- Transition vers le cloud (SASE) en cours — Palo Alto leader avec Prisma

**3. Modèle Plateforme intégrée (Microsoft, Cisco)**
- Cybersécurité intégrée dans l'écosystème existant (Microsoft 365, Azure)
- Microsoft Security : >20 Mrd USD ARR estimé — le plus grand acteur par revenus
- Avantage prix (bundle) mais perçu comme "good enough" vs best-of-breed

**4. Modèle Services managés / MSSP (Secureworks, Arctic Wolf)**
- Externalisation complète de la cybersécurité pour PME/ETI
- Croissance rapide (~20% CAGR) portée par la pénurie de talents
- Marges plus faibles (~50-60%) mais marché adressable énorme`,
    keyPlayers: `## Les acteurs principaux
**Leaders :**
| Entreprise | Ticker | Pays | Cap. boursière | ARR/Revenus | Spécialité |
|-----------|--------|------|---------------|-------------|------------|
| CrowdStrike | CRWD | US | ~85 Mrd USD | ~3.9 Mrd ARR | Endpoint XDR, plateforme Falcon |
| Palo Alto Networks | PANW | US | ~130 Mrd USD | ~7.5 Mrd rev. | Firewall, SASE, Cortex |
| Fortinet | FTNT | US | ~65 Mrd USD | ~5.8 Mrd rev. | Firewall, SD-WAN, SASE |
| Zscaler | ZS | US | ~30 Mrd USD | ~2.3 Mrd ARR | Zero Trust, SASE cloud |
| Microsoft Security | MSFT | US | (partie de MSFT) | >20 Mrd ARR | Defender, Sentinel, Entra |

**Challengers :**
| Entreprise | Ticker | Cap. boursière | Focus |
|-----------|--------|---------------|-------|
| SentinelOne | S | ~8 Mrd USD | Endpoint IA, Purple AI |
| CyberArk | CYBR | ~15 Mrd USD | Identity, PAM |
| Okta | OKTA | ~14 Mrd USD | Identity cloud |
| Varonis | VRNS | ~6 Mrd USD | Data security |

**Émergents / Privés :**
- Wiz (valorisation ~12 Mrd USD) — CNAPP leader, croissance explosive
- Abnormal Security — Email security IA
- Snyk — Sécurité développeur (DevSecOps)`,
    etfExposure: `## ETF & Exposition
| ETF | Ticker | AUM | Frais | Focus |
|-----|--------|-----|-------|-------|
| First Trust Nasdaq Cybersecurity | CIBR | ~7 Mrd USD | 0.60% | Large/mid cap cyber US |
| Global X Cybersecurity | BUG | ~1 Mrd USD | 0.50% | Pure-play cybersécurité |
| iShares Cybersecurity & Tech | IHAK | ~800 M USD | 0.47% | Cyber + tech adjacente |
| WisdomTree Cybersecurity | WCBR | ~300 M USD | 0.45% | Cybersécurité globale |
| L&G Cyber Security | USPY | ~2.5 Mrd USD | 0.69% | Cybersécurité globale (EU) |

**Avantages :**
- Exposition diversifiée à un secteur en croissance structurelle
- Moins de risque idiosyncratique qu'un titre individuel
- Le secteur est relativement défensif (dépenses non-discrétionnaires)

**Limites :**
- Concentration sur les large caps US — peu d'exposition aux émergents/privés
- Corrélation avec le Nasdaq reste significative
- Les ETF ne capturent pas les acteurs privés à forte croissance (Wiz, Snyk)

*Note : Les ETF mentionnés sont à titre informatif uniquement.*`,
    catalysts: `## Catalyseurs à court terme
**T1-T2 2026 :**
- **Application NIS2** : Les entreprises européennes doivent être conformes — boost des dépenses cyber en Europe
- **DORA en vigueur** : Le secteur financier européen investit massivement en résilience numérique
- **Résultats CrowdStrike** : Rebond post-incident juillet 2024 — la rétention client est le KPI clé
- **Consolidation M&A** : Palo Alto et CrowdStrike continuent d'acquérir pour élargir leurs plateformes

**T3-T4 2026 :**
- **Menaces IA** : Les premières cyberattaques majeures utilisant l'IA générative pourraient accélérer les budgets
- **Élections US (nov 2026 midterms)** : Risque accru de cyberattaques étatiques et désinformation
- **IPO Wiz ?** : Le leader CNAPP pourrait entrer en bourse, catalyseur pour tout le secteur cloud security
- **Budget défense US FY2027** : Composante cyber en hausse structurelle

**Signaux à surveiller :**
- Taux de rétention nette des leaders (>120% = sain)
- Nombre de violations de données majeures (tendance)
- Budgets IT/cyber dans les surveys CIO (Gartner, Morgan Stanley)`,
    risks: `## Risques
| Risque | Probabilité | Impact | Horizon |
|--------|------------|--------|---------|
| Compression des multiples | Moyenne | Moyen | 6-12 mois |
| Incident majeur d'un leader | Faible | Élevé | Permanent |
| Concurrence Microsoft | Élevée | Moyen | 12-24 mois |
| Ralentissement IT spending | Moyenne | Élevé | 6-18 mois |
| Commoditisation par l'IA | Faible | Moyen | 24-36 mois |

**Détail :**
- **Compression des multiples** : Les valorisations cyber sont élevées (CrowdStrike ~70x FCF). Un ralentissement macro pourrait comprimer les multiples de 20-30%.
- **Incident majeur** : L'incident CrowdStrike de juillet 2024 a montré qu'un leader peut perdre 30% en quelques jours. Le risque opérationnel est réel.
- **Microsoft** : Avec >20 Mrd USD ARR en sécurité et un bundle attractif, Microsoft grignote des parts dans l'identity, l'endpoint et le SIEM.
- **Ralentissement IT** : En cas de récession, les budgets IT sont réduits — même si la cyber est "non-discrétionnaire", les projets sont reportés.
- **IA défensive** : Si l'IA automatise la détection/réponse, les solutions traditionnelles pourraient se commoditiser.`,
    scenarios: `## Scénarios
**Scénario haussier (Bull) :**
**SI** les cyberattaques IA se multiplient et forcent une accélération des budgets cyber, **ET SI** la réglementation (NIS2, DORA) génère un cycle d'investissement massif en Europe, **ALORS** les leaders (CrowdStrike, Palo Alto) pourraient voir leur croissance s'accélérer à >25% et leurs multiples se maintenir. Le secteur surperformerait le Nasdaq de 10-20%.

**Scénario de base (Base) :**
La croissance du secteur se maintient à ~12-14% annuel. La consolidation continue (M&A). Les leaders gagnent des parts grâce à la platformisation. Les multiples se normalisent progressivement. CrowdStrike et Palo Alto restent les valeurs de référence.

**Scénario baissier (Bear) :**
**SINON**, si un ralentissement économique significatif pousse les entreprises à reporter leurs projets cyber, **ET SI** Microsoft capture une part croissante du marché avec son bundle, **ALORS** les pure-plays cyber pourraient voir leur croissance ralentir à <10% et leurs multiples se comprimer de 30-40%. SentinelOne et Zscaler seraient les plus vulnérables.

*Rappel : Ces scénarios sont des exercices de réflexion, pas des prédictions.*`,
    glossary: `## Glossaire du secteur
1. **Zero Trust** : Modèle de sécurité où aucun utilisateur ou appareil n'est automatiquement considéré comme fiable, même à l'intérieur du réseau. Vérification continue requise.
2. **XDR (Extended Detection & Response)** : Plateforme intégrant la détection et la réponse aux menaces sur endpoints, réseau, cloud et email en une seule console.
3. **SASE (Secure Access Service Edge)** : Architecture combinant réseau (SD-WAN) et sécurité (firewall, CASB, ZTNA) dans le cloud. Leaders : Zscaler, Palo Alto.
4. **CNAPP (Cloud-Native Application Protection Platform)** : Solution intégrée pour sécuriser les applications cloud-native (containers, serverless, IaC). Leader : Wiz.
5. **Ransomware** : Malware qui chiffre les données d'une victime et exige une rançon pour les déchiffrer. Modèle RaaS (Ransomware-as-a-Service) en expansion.
6. **SOAR (Security Orchestration, Automation & Response)** : Outils automatisant la réponse aux incidents de sécurité, réduisant le temps de réaction (MTTR).
7. **PAM (Privileged Access Management)** : Gestion des accès à privilèges élevés (administrateurs, comptes de service). Leader : CyberArk.
8. **MTTD/MTTR** : Mean Time To Detect / Mean Time To Respond — métriques clés mesurant l'efficacité d'un SOC.
9. **Supply Chain Attack** : Attaque ciblant un fournisseur pour compromettre ses clients (ex : SolarWinds 2020).
10. **Threat Intelligence** : Collecte et analyse de données sur les menaces cyber pour anticiper et prévenir les attaques.`,
    checklist: `## Checklist de suivi
**Données à surveiller :**
- ARR et taux de rétention nette de CrowdStrike, Palo Alto, Zscaler (trimestriel)
- Nombre de violations de données majeures (IBM X-Force, Verizon DBIR)
- Budgets IT/cyber dans les surveys CIO (Gartner, Morgan Stanley)
- Indice CIBR (First Trust Nasdaq Cybersecurity ETF) vs Nasdaq

**Dates clés :**
- Earnings CrowdStrike : mars 2026, juin 2026
- Earnings Palo Alto : février 2026, mai 2026
- RSA Conference : avril 2026 (San Francisco)
- Application NIS2 : en cours (2025-2026)
- DORA : en vigueur depuis janvier 2025

**Indicateurs de retournement :**
- Baisse du taux de rétention nette sous 115%
- Ralentissement de la croissance ARR sous 15% pour les leaders
- Réduction des budgets IT dans les surveys CIO
- Microsoft gagnant >30% de part dans un segment clé`,
    conclusion: `## Conclusion
La cybersécurité est un secteur en croissance structurelle, porté par des tendances de fond irréversibles : numérisation, cloud, IA, réglementation. Contrairement à d'autres secteurs tech, les dépenses cyber sont largement non-discrétionnaires — les entreprises ne peuvent pas "ne pas" investir.

**Points clés à retenir :**
- Le secteur croît à ~12-14% par an, avec des sous-segments (cloud security, identity) à >20%
- La platformisation favorise les leaders (CrowdStrike, Palo Alto) au détriment des solutions point-à-point
- Microsoft est le concurrent systémique à surveiller — son bundle est attractif pour les PME
- Les valorisations sont élevées mais justifiées par la visibilité et la récurrence des revenus

*Ce dossier est fourni à titre informatif et éducatif uniquement. Il ne constitue en aucun cas un conseil d'investissement.*`,
    sources: `## Sources
1. Gartner — "Forecast: Information Security, Worldwide, 2022-2028" (2024)
2. IBM — "Cost of a Data Breach Report 2024"
3. Check Point Research — "2024 Cyber Security Report"
4. ISC2 — "Cybersecurity Workforce Study 2024"
5. Chainalysis — "2024 Crypto Crime Report" (ransomware payments)
6. Okta — "State of Zero Trust Security 2024"
7. Verizon — "Data Breach Investigations Report 2024"
8. CrowdStrike, Palo Alto, Fortinet — SEC filings et earnings transcripts
9. European Commission — NIS2 Directive, DORA Regulation
10. Morgan Stanley — "CIO Survey: IT Spending Intentions" (2025)`
  },
  {
    id: 5,
    executiveSummary: `## Résumé exécutif
**Pourquoi ce thème compte maintenant :**
Les dépenses mondiales de défense ont atteint un record de 2 443 milliards USD en 2024 (source : SIPRI, 2025). L'Europe accélère son réarmement : l'Allemagne a créé un fonds spécial de 100 milliards EUR, la France augmente son budget à 413 milliards EUR sur 2024-2030. L'OTAN vise désormais 2.5% du PIB (contre 2% précédemment).

**7 points clés :**
1. Le budget défense US atteint ~886 milliards USD en FY2025 (source : DoD)
2. L'Europe augmente ses dépenses de ~15-20% par an — le plus fort taux depuis la Guerre froide
3. Rheinmetall (Allemagne) a vu son cours tripler en 3 ans, porté par le réarmement européen
4. Les drones et systèmes autonomes transforment le champ de bataille (leçons Ukraine)
5. La défense spatiale et la cyberdéfense deviennent des lignes budgétaires majeures
6. Les carnets de commandes des grands contractants sont au plus haut historique (Lockheed : 166 Mrd USD)
7. La course aux missiles hypersoniques s'intensifie entre US, Chine et Russie`,
    context: `## Contexte & Historique
**Chronologie clé :**
- **2014** : Annexion de la Crimée — premier réveil européen, engagement OTAN à 2% du PIB
- **2017-2021** : Budgets défense stagnants en Europe malgré l'engagement
- **Fév 2022** : Invasion de l'Ukraine — "Zeitenwende" (tournant historique) annoncé par Scholz
- **2022-2023** : Finlande et Suède rejoignent l'OTAN — élargissement historique
- **2024** : 23 pays OTAN atteignent le seuil de 2% du PIB (contre 7 en 2022)
- **2025** : Nouvel objectif OTAN à 2.5% — l'Europe lance des programmes d'armement massifs
- **2025** : Tensions croissantes en mer de Chine du Sud et détroit de Taïwan

**État actuel :**
Le secteur vit un supercycle de commandes sans précédent depuis la Guerre froide. Les carnets de commandes sont pleins pour 5-10 ans. Le défi principal est la capacité de production : les chaînes d'approvisionnement défense, dimensionnées pour le temps de paix, doivent s'adapter à une demande de temps de guerre.`,
    sectorMap: `## Cartographie du Secteur
| Segment | Acteurs clés | Taille estimée 2025 |
|---------|-------------|-------------------|
| **Aéronautique militaire** | Lockheed Martin, Boeing, Dassault | ~180 Mrd USD |
| **Systèmes terrestres** | Rheinmetall, General Dynamics, BAE | ~80 Mrd USD |
| **Naval** | Huntington Ingalls, Naval Group, Fincantieri | ~70 Mrd USD |
| **Missiles & Munitions** | RTX, MBDA, Northrop Grumman | ~60 Mrd USD |
| **Drones & Autonome** | Kratos, AeroVironment, Turkish Aerospace | ~25 Mrd USD |
| **Cyberdéfense** | Palantir, L3Harris, Thales | ~20 Mrd USD |
| **Spatial militaire** | SpaceX, Northrop, L3Harris | ~15 Mrd USD |
| **Électronique défense** | L3Harris, Thales, Leonardo | ~50 Mrd USD |

**Tendances structurelles :**
- **Drones** : La guerre en Ukraine a démontré l'efficacité des drones low-cost — les budgets explosent
- **Hypersonique** : Course technologique US/Chine/Russie pour les missiles à Mach 5+
- **IA militaire** : Systèmes autonomes, aide à la décision, reconnaissance automatique`,
    drivers: `## Les moteurs du secteur
**Facteurs macro :**
- **Géopolitique** : Guerre en Ukraine, tensions Chine-Taïwan, instabilité Moyen-Orient — le monde est plus dangereux
- **Réarmement européen** : L'Europe passe de 1.5% à 2.5% du PIB en défense — des centaines de milliards supplémentaires
- **Budget US** : Bipartisan support pour la défense — le budget ne baisse jamais significativement

**Facteurs sectoriels :**
- **Carnets de commandes record** : Lockheed Martin 166 Mrd USD, RTX 202 Mrd USD, Northrop 85 Mrd USD
- **Leçons Ukraine** : Besoin massif en munitions, drones, défense aérienne — les stocks sont bas
- **Modernisation** : Remplacement des équipements vieillissants (F-35 remplace F-16, nouveaux sous-marins)
- **Spatial & Cyber** : Nouveaux domaines de conflictualité = nouvelles lignes budgétaires

**Facteurs réglementaires :**
- **OTAN 2.5%** : Nouvel objectif contraignant pour les membres — pression politique forte
- **ITAR/Export controls** : Les restrictions d'export US structurent le marché (alliés vs adversaires)
- **Fonds européen de défense** : 8 Mrd EUR sur 2021-2027 pour la R&D défense européenne`,
    marketSize: `## Taille du marché
| Segment | 2024 | 2025E | 2030E | CAGR |
|---------|------|-------|-------|------|
| Défense mondiale (total) | 2 443 Mrd USD | 2 600 Mrd USD | 3 200 Mrd USD | ~5% |
| US Defense | 886 Mrd USD | 920 Mrd USD | 1 050 Mrd USD | ~4% |
| Europe Defense | 380 Mrd USD | 440 Mrd USD | 650 Mrd USD | ~10% |
| Drones militaires | 18 Mrd USD | 25 Mrd USD | 55 Mrd USD | ~20% |
| Cyberdéfense | 16 Mrd USD | 20 Mrd USD | 35 Mrd USD | ~15% |

*Sources : SIPRI (2025), NATO, Jane's Defence, Teal Group*

**Répartition :** US ~38%, Europe ~16%, Chine ~13%, Reste Asie ~15%, Moyen-Orient ~10%, Autres ~8%`,
    businessModels: `## Modèles économiques
**1. Grands contractants intégrés (Lockheed Martin, RTX, Northrop)**
- Contrats gouvernementaux long terme (5-20 ans), cost-plus ou fixed-price
- Marges opérationnelles : 10-15% (régulées par le gouvernement)
- Revenus très prévisibles grâce aux carnets de commandes pluriannuels
- Barrières à l'entrée massives : certifications, clearances, capital

**2. Spécialistes européens (Rheinmetall, BAE Systems, Thales)**
- Bénéficient du réarmement européen — croissance >15% par an
- Rheinmetall : leader munitions/véhicules blindés, carnet de commandes en forte hausse
- BAE Systems : diversifié (naval, aéro, électronique), exposition US + UK + Australie

**3. Nouveaux entrants tech (Palantir, Anduril, Shield AI)**
- Software-defined defense : IA, data analytics, systèmes autonomes
- Palantir : ~2.9 Mrd USD revenus, 55% gouvernement, marge brute >80%
- Anduril (privé, valorisation ~14 Mrd USD) : drones autonomes, tours de surveillance

**4. Munitions & Consommables (Rheinmetall, General Dynamics, Nammo)**
- Demande structurelle post-Ukraine — les stocks OTAN doivent être reconstitués
- Marges en hausse grâce aux volumes et à l'urgence des commandes`,
    keyPlayers: `## Les acteurs principaux
**Leaders US :**
| Entreprise | Ticker | Cap. boursière | Revenus | Carnet de commandes | Spécialité |
|-----------|--------|---------------|---------|-------------------|------------|
| Lockheed Martin | LMT | ~135 Mrd USD | ~68 Mrd USD | 166 Mrd USD | F-35, missiles, spatial |
| RTX Corporation | RTX | ~165 Mrd USD | ~73 Mrd USD | 202 Mrd USD | Moteurs (Pratt), missiles (Raytheon) |
| Northrop Grumman | NOC | ~75 Mrd USD | ~40 Mrd USD | 85 Mrd USD | B-21, spatial, cyber |
| General Dynamics | GD | ~80 Mrd USD | ~42 Mrd USD | 93 Mrd USD | Gulfstream, sous-marins, IT |
| L3Harris | LHX | ~45 Mrd USD | ~21 Mrd USD | 32 Mrd USD | Électronique, communications |

**Leaders européens :**
| Entreprise | Ticker | Cap. boursière | Spécialité |
|-----------|--------|---------------|------------|
| BAE Systems | BA. (LSE) | ~55 Mrd GBP | Naval, aéro, électronique |
| Rheinmetall | RHM (XETRA) | ~35 Mrd EUR | Munitions, véhicules blindés |
| Thales | HO (EPA) | ~35 Mrd EUR | Électronique, spatial, cyber |
| Leonardo | LDO (BIT) | ~18 Mrd EUR | Hélicoptères, électronique |
| Saab | SAAB-B (STO) | ~15 Mrd EUR | Gripen, sous-marins, radar |`,
    etfExposure: `## ETF & Exposition
| ETF | Ticker | AUM | Frais | Focus |
|-----|--------|-----|-------|-------|
| iShares U.S. Aerospace & Defense | ITA | ~7 Mrd USD | 0.40% | Défense US large cap |
| SPDR S&P Aerospace & Defense | XAR | ~2 Mrd USD | 0.35% | Défense US equal-weight |
| Invesco Aerospace & Defense | PPA | ~3 Mrd USD | 0.58% | Défense US |
| Global X Defense Tech | SHLD | ~500 M USD | 0.50% | Défense + tech globale |
| VanEck Defense | DFNS | ~1 Mrd USD | 0.55% | Défense globale (incl. Europe) |

**Avantages :**
- Exposition à un supercycle de commandes (5-10 ans de visibilité)
- Secteur défensif par nature — décorrélé des cycles économiques
- Dividendes stables (Lockheed ~2.5%, RTX ~2%, GD ~2%)

**Limites :**
- Les ETF US sont concentrés sur les primes contractors américains
- Peu d'exposition aux européens (Rheinmetall, BAE) dans les ETF US
- Risque politique : un changement de politique étrangère pourrait impacter les budgets

*Note : Les ETF mentionnés sont à titre informatif uniquement.*`,
    catalysts: `## Catalyseurs à court terme
**T1-T2 2026 :**
- **Budget défense US FY2027** : Soumission au Congrès — le montant et les priorités sont scrutés
- **Commandes européennes** : L'Allemagne, la Pologne et la France passent des commandes massives
- **Résultats Q1 2026** : Carnets de commandes et marges — les indicateurs clés
- **Situation Ukraine** : Toute escalation ou négociation impacte le sentiment sur le secteur

**T3-T4 2026 :**
- **Midterms US (nov 2026)** : La défense est bipartisane mais les priorités peuvent évoluer
- **Livraisons F-35** : Lockheed augmente la cadence — impact sur les revenus
- **Programmes européens** : SCAF (avion de combat franco-allemand), MGCS (char du futur)
- **Tensions Asie-Pacifique** : Taïwan, mer de Chine du Sud — catalyseur géopolitique permanent

**Signaux à surveiller :**
- Ratio book-to-bill des grands contractants (>1x = sain)
- Dépenses défense en % du PIB des pays OTAN
- Cadence de production des munitions (Rheinmetall, General Dynamics)`,
    risks: `## Risques
| Risque | Probabilité | Impact | Horizon |
|--------|------------|--------|---------|
| Accord de paix Ukraine | Faible-Moyenne | Moyen | 6-18 mois |
| Coupes budgétaires US | Faible | Élevé | 12-24 mois |
| Problèmes de production | Élevée | Moyen | 6-12 mois |
| Risque ESG / exclusion | Moyenne | Moyen | Permanent |
| Inflation des coûts | Élevée | Moyen | 6-18 mois |

**Détail :**
- **Accord de paix** : Un cessez-le-feu en Ukraine pourrait temporairement réduire l'urgence du réarmement, mais les programmes long terme (OTAN 2.5%) sont structurels.
- **Coupes budgétaires** : Peu probable à court terme (bipartisan support), mais un shutdown ou sequestration pourrait retarder les contrats.
- **Production** : Les chaînes d'approvisionnement défense sont tendues — pénuries de composants, délais de livraison allongés.
- **ESG** : Certains fonds excluent la défense — mais la tendance s'inverse (la défense est "nécessaire" pour la sécurité).
- **Inflation** : Les contrats fixed-price exposent les contractants à l'inflation des matériaux et de la main-d'œuvre.`,
    scenarios: `## Scénarios
**Scénario haussier (Bull) :**
**SI** les tensions géopolitiques s'intensifient (escalation Taïwan, prolongation guerre Ukraine), **ET SI** l'Europe accélère son réarmement au-delà de 2.5% du PIB, **ALORS** le secteur pourrait connaître un supercycle prolongé de 10+ ans. Les contractants européens (Rheinmetall, BAE) doubleraient leurs revenus. Les US primes maintiendraient une croissance de 5-8% avec des marges stables.

**Scénario de base (Base) :**
Le réarmement se poursuit à un rythme soutenu. L'Europe atteint progress
