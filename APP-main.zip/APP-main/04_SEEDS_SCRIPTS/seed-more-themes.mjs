/**
 * Seed 70 new thematic watchlists to reach 100+ total
 * Each with 5 watchlist items (companies/ETFs)
 */
import mysql from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

const conn = await mysql.createConnection(process.env.DATABASE_URL);

const [maxWl] = await conn.execute("SELECT MAX(id) as maxId FROM thematicWatchlists");
const [maxItem] = await conn.execute("SELECT MAX(id) as maxId FROM watchlistItems");
let wlId = Math.max(maxWl[0].maxId + 1, 40001);
let itemId = Math.max(maxItem[0].maxId + 1, 50001);
let sortOrder = 100;

const NEW_THEMES = [
  { slug: "edge-computing", title: "Edge Computing & IoT Industriel", icon: "Server", color: "#6366F1",
    thesis: "Le traitement des donnees migre vers la peripherie du reseau, reduisant la latence et permettant l'IA embarquee dans les usines et vehicules.",
    items: [
      { ticker: "ANET", name: "Arista Networks", sector: "Networking", mcap: "Large", thesis: "Leader switches datacenter et campus." },
      { ticker: "KEYS", name: "Keysight Technologies", sector: "Test & Mesure", mcap: "Large", thesis: "Instruments de test pour reseaux 5G et IoT." },
      { ticker: "SWKS", name: "Skyworks Solutions", sector: "Semi RF", mcap: "Mid", thesis: "Puces RF pour connectivite IoT et 5G." },
      { ticker: "LITE", name: "Lumentum Holdings", sector: "Photonique", mcap: "Mid", thesis: "Composants optiques pour reseaux edge." },
      { ticker: "CIEN", name: "Ciena Corporation", sector: "Optique", mcap: "Mid", thesis: "Solutions de mise en reseau optique." },
    ]
  },
  { slug: "metaverse-xr", title: "Metaverse & Realite Etendue (XR)", icon: "Globe", color: "#A855F7",
    thesis: "La convergence VR, AR et spatial computing ouvre de nouveaux marches dans le gaming, l'entreprise et l'education.",
    items: [
      { ticker: "META", name: "Meta Platforms", sector: "Social/VR", mcap: "Mega", thesis: "Investissement massif dans Reality Labs." },
      { ticker: "AAPL", name: "Apple Inc.", sector: "Hardware XR", mcap: "Mega", thesis: "Vision Pro et spatial computing premium." },
      { ticker: "U", name: "Unity Software", sector: "Moteur 3D", mcap: "Mid", thesis: "Moteur 3D dominant pour experiences immersives." },
      { ticker: "SNAP", name: "Snap Inc.", sector: "AR Social", mcap: "Mid", thesis: "Pioneer de la realite augmentee sociale." },
      { ticker: "QCOM", name: "Qualcomm", sector: "Puces XR", mcap: "Large", thesis: "Snapdragon XR equipe la majorite des casques." },
    ]
  },
  { slug: "generative-ai", title: "IA Generative & LLM", icon: "Brain", color: "#EC4899",
    thesis: "Les modeles de langage transforment la productivite, la creation de contenu et le developpement logiciel. Marche estime a 1.3T$ d'ici 2032.",
    items: [
      { ticker: "MSFT", name: "Microsoft", sector: "Cloud/AI", mcap: "Mega", thesis: "Partenariat OpenAI, Copilot dans Office 365." },
      { ticker: "GOOGL", name: "Alphabet", sector: "Search/AI", mcap: "Mega", thesis: "Gemini et DeepMind integres dans l'ecosysteme." },
      { ticker: "NVDA", name: "NVIDIA", sector: "GPU/AI", mcap: "Mega", thesis: "Infrastructure GPU indispensable pour l'entrainement." },
      { ticker: "CRM", name: "Salesforce", sector: "CRM/AI", mcap: "Large", thesis: "Einstein AI et agents autonomes pour entreprises." },
      { ticker: "PLTR", name: "Palantir", sector: "Data/AI", mcap: "Large", thesis: "AIP transforme les donnees en decisions operationnelles." },
    ]
  },
  { slug: "data-centers", title: "Data Centers & Infrastructure Cloud", icon: "Server", color: "#0EA5E9",
    thesis: "L'explosion de l'IA et du cloud necessite des investissements massifs en data centers. Le marche mondial depasse 300Md$ en 2025.",
    items: [
      { ticker: "EQIX", name: "Equinix", sector: "REIT DC", mcap: "Large", thesis: "Plus grand operateur mondial de data centers." },
      { ticker: "DLR", name: "Digital Realty", sector: "REIT DC", mcap: "Large", thesis: "Portefeuille mondial de data centers colocation." },
      { ticker: "VRT", name: "Vertiv Holdings", sector: "Cooling", mcap: "Large", thesis: "Refroidissement et alimentation pour data centers." },
      { ticker: "PSTG", name: "Pure Storage", sector: "Stockage", mcap: "Mid", thesis: "Solutions de stockage flash pour workloads AI." },
      { ticker: "SMCI", name: "Super Micro Computer", sector: "Serveurs", mcap: "Mid", thesis: "Serveurs GPU optimises pour l'IA." },
    ]
  },
  { slug: "5g-telecom", title: "5G & Telecommunications", icon: "Zap", color: "#14B8A6",
    thesis: "Le deploiement mondial de la 5G accelere avec des cas d'usage industriels. Le marche 5G atteindra 700Md$ d'ici 2030.",
    items: [
      { ticker: "T", name: "AT&T", sector: "Telecom", mcap: "Large", thesis: "Deploiement 5G massif aux Etats-Unis." },
      { ticker: "VZ", name: "Verizon", sector: "Telecom", mcap: "Large", thesis: "Leader 5G mmWave et C-Band." },
      { ticker: "ERIC", name: "Ericsson", sector: "Equipement", mcap: "Large", thesis: "Fournisseur d'infrastructure reseau 5G mondial." },
      { ticker: "NOK", name: "Nokia", sector: "Equipement", mcap: "Mid", thesis: "Solutions reseau 5G et private networks." },
      { ticker: "MRVL", name: "Marvell Technology", sector: "Semi 5G", mcap: "Large", thesis: "Puces custom pour infrastructure 5G." },
    ]
  },
  { slug: "gaming-esport", title: "Gaming & Esport", icon: "Rocket", color: "#F43F5E",
    thesis: "L'industrie du jeu video depasse 200Md$ de revenus annuels. Le cloud gaming, le mobile et l'esport accelerent la croissance.",
    items: [
      { ticker: "TTWO", name: "Take-Two Interactive", sector: "Editeur", mcap: "Large", thesis: "GTA VI, franchise NBA 2K, pipeline massif." },
      { ticker: "EA", name: "Electronic Arts", sector: "Editeur", mcap: "Large", thesis: "EA Sports FC, Apex Legends, revenus recurrents." },
      { ticker: "RBLX", name: "Roblox", sector: "Plateforme", mcap: "Mid", thesis: "Plateforme de creation et gaming social pour Gen Z." },
      { ticker: "ATVI", name: "Activision Blizzard", sector: "Editeur", mcap: "Mega", thesis: "Call of Duty, World of Warcraft, maintenant chez Microsoft." },
      { ticker: "SE", name: "Sea Limited", sector: "Gaming Asie", mcap: "Mid", thesis: "Garena et Free Fire dominent le gaming mobile en Asie." },
    ]
  },
  { slug: "medtech-devices", title: "MedTech & Dispositifs Medicaux", icon: "Heart", color: "#EF4444",
    thesis: "L'innovation en dispositifs medicaux (chirurgie robotique, diagnostics IA, wearables) transforme les soins de sante.",
    items: [
      { ticker: "ISRG", name: "Intuitive Surgical", sector: "Chirurgie robot", mcap: "Large", thesis: "Leader mondial de la chirurgie robotique avec da Vinci." },
      { ticker: "ABT", name: "Abbott Laboratories", sector: "Diagnostics", mcap: "Mega", thesis: "FreeStyle Libre et diagnostics innovants." },
      { ticker: "SYK", name: "Stryker", sector: "Orthopedie", mcap: "Large", thesis: "Implants et chirurgie assistee par robot Mako." },
      { ticker: "DXCM", name: "DexCom", sector: "CGM", mcap: "Large", thesis: "Surveillance continue du glucose, marche en expansion." },
      { ticker: "HOLX", name: "Hologic", sector: "Diagnostics", mcap: "Mid", thesis: "Diagnostics moleculaires et sante feminine." },
    ]
  },
  { slug: "genomique-crispr", title: "Genomique & Edition Genetique", icon: "Atom", color: "#D946EF",
    thesis: "CRISPR et les therapies geniques ouvrent une nouvelle ere medicale. Le marche de l'edition genetique atteindra 30Md$ d'ici 2030.",
    items: [
      { ticker: "CRSP", name: "CRISPR Therapeutics", sector: "Gene editing", mcap: "Mid", thesis: "Casgevy approuve, pipeline drepanocytose et oncologie." },
      { ticker: "NTLA", name: "Intellia Therapeutics", sector: "Gene editing", mcap: "Mid", thesis: "Therapies in vivo CRISPR pour maladies rares." },
      { ticker: "BEAM", name: "Beam Therapeutics", sector: "Base editing", mcap: "Small", thesis: "Edition de bases pour corrections genetiques precises." },
      { ticker: "ILMN", name: "Illumina", sector: "Sequencage", mcap: "Large", thesis: "Leader mondial du sequencage ADN." },
      { ticker: "PACB", name: "PacBio", sector: "Sequencage", mcap: "Small", thesis: "Sequencage long-read pour genomique de precision." },
    ]
  },
  { slug: "cannabis-legal", title: "Cannabis Legal & Regulation", icon: "Leaf", color: "#65A30D",
    thesis: "La legalisation progressive du cannabis aux US et en Europe cree un marche reglemente en forte croissance.",
    items: [
      { ticker: "TLRY", name: "Tilray Brands", sector: "Cannabis", mcap: "Mid", thesis: "Leader mondial cannabis medical et recreatif." },
      { ticker: "CGC", name: "Canopy Growth", sector: "Cannabis", mcap: "Small", thesis: "Partenariat Constellation Brands, marche canadien." },
      { ticker: "CRON", name: "Cronos Group", sector: "Cannabis", mcap: "Small", thesis: "Adosse a Altria, focus sur les derives." },
      { ticker: "CURLF", name: "Curaleaf Holdings", sector: "MSO US", mcap: "Mid", thesis: "Plus grand MSO americain par revenus." },
      { ticker: "GTBIF", name: "Green Thumb Industries", sector: "MSO US", mcap: "Mid", thesis: "MSO rentable avec forte presence multi-etats." },
    ]
  },
  { slug: "lithium-terres-rares", title: "Lithium & Terres Rares", icon: "Mountain", color: "#F59E0B",
    thesis: "La transition energetique depend du lithium, cobalt et terres rares. La securisation des chaines d'approvisionnement est un enjeu geopolitique majeur.",
    items: [
      { ticker: "ALB", name: "Albemarle", sector: "Lithium", mcap: "Large", thesis: "Premier producteur mondial de lithium." },
      { ticker: "SQM", name: "Sociedad Quimica y Minera", sector: "Lithium", mcap: "Mid", thesis: "Producteur chilien de lithium et iode." },
      { ticker: "LAC", name: "Lithium Americas", sector: "Lithium", mcap: "Small", thesis: "Projet Thacker Pass, plus grande mine US." },
      { ticker: "MP", name: "MP Materials", sector: "Terres rares", mcap: "Mid", thesis: "Seul producteur de terres rares aux US." },
      { ticker: "LTHM", name: "Livent/Arcadium", sector: "Lithium", mcap: "Mid", thesis: "Lithium hydroxide pour batteries EV premium." },
    ]
  },
  { slug: "hydrogene-vert", title: "Hydrogene Vert & Piles a Combustible", icon: "Flame", color: "#06B6D4",
    thesis: "L'hydrogene vert est un pilier de la decarbonation industrielle. Les subventions IRA et EU Green Deal accelerent le deploiement.",
    items: [
      { ticker: "PLUG", name: "Plug Power", sector: "H2 vert", mcap: "Mid", thesis: "Solutions hydrogene integrees pour logistique et industrie." },
      { ticker: "BLDP", name: "Ballard Power", sector: "Piles a combustible", mcap: "Small", thesis: "Piles a combustible pour transport lourd." },
      { ticker: "BE", name: "Bloom Energy", sector: "Piles SOFC", mcap: "Mid", thesis: "Serveurs energetiques a pile a combustible solide." },
      { ticker: "FCEL", name: "FuelCell Energy", sector: "Piles a combustible", mcap: "Small", thesis: "Centrales a pile a combustible pour production d'electricite." },
      { ticker: "APD", name: "Air Products", sector: "Gaz industriels", mcap: "Large", thesis: "Leader mondial des gaz industriels, investit massivement dans l'H2 vert." },
    ]
  },
  { slug: "infrastructure-us", title: "Infrastructure Americaine & IIJA", icon: "Building", color: "#78716C",
    thesis: "Le plan IIJA de 1.2T$ et l'IRA financent la renovation des routes, ponts, reseaux electriques et broadband aux US.",
    items: [
      { ticker: "CAT", name: "Caterpillar", sector: "Equipement BTP", mcap: "Mega", thesis: "Leader mondial des engins de construction." },
      { ticker: "VMC", name: "Vulcan Materials", sector: "Agregats", mcap: "Large", thesis: "Premier producteur d'agregats aux US." },
      { ticker: "MLM", name: "Martin Marietta", sector: "Materiaux", mcap: "Large", thesis: "Materiaux de construction pour infrastructures." },
      { ticker: "PWR", name: "Quanta Services", sector: "Services infra", mcap: "Large", thesis: "Construction et maintenance d'infrastructures electriques." },
      { ticker: "URI", name: "United Rentals", sector: "Location equip", mcap: "Large", thesis: "Plus grand loueur d'equipements de construction." },
    ]
  },
  { slug: "private-equity-alt", title: "Private Equity & Alternatives", icon: "Briefcase", color: "#1E3A5F",
    thesis: "Les gestionnaires d'actifs alternatifs beneficient de la democratisation du PE et du credit prive. AUM en forte croissance.",
    items: [
      { ticker: "BX", name: "Blackstone", sector: "PE/Immo", mcap: "Mega", thesis: "Plus grand gestionnaire d'actifs alternatifs au monde." },
      { ticker: "KKR", name: "KKR & Co", sector: "PE/Credit", mcap: "Large", thesis: "Pioneer du LBO, diversifie dans le credit et l'infra." },
      { ticker: "APO", name: "Apollo Global", sector: "Credit prive", mcap: "Large", thesis: "Leader du credit prive et des solutions de retraite." },
      { ticker: "ARES", name: "Ares Management", sector: "Credit", mcap: "Large", thesis: "Specialiste du credit direct et des CLOs." },
      { ticker: "CG", name: "Carlyle Group", sector: "PE global", mcap: "Large", thesis: "PE global avec expertise defense et aero." },
    ]
  },
  { slug: "dividendes-aristocrates", title: "Dividendes Aristocrates", icon: "Coins", color: "#CA8A04",
    thesis: "Les Dividend Aristocrats ont augmente leurs dividendes pendant 25+ annees consecutives. Strategie defensive et revenus passifs.",
    items: [
      { ticker: "JNJ", name: "Johnson & Johnson", sector: "Pharma/Conso", mcap: "Mega", thesis: "62 ans de hausses consecutives de dividendes." },
      { ticker: "PG", name: "Procter & Gamble", sector: "Conso staples", mcap: "Mega", thesis: "68 ans de hausses, marques incontournables." },
      { ticker: "KO", name: "Coca-Cola", sector: "Boissons", mcap: "Mega", thesis: "62 ans de hausses, distribution mondiale." },
      { ticker: "MMM", name: "3M Company", sector: "Industriel", mcap: "Large", thesis: "Conglomerat industriel diversifie, dividende solide." },
      { ticker: "CL", name: "Colgate-Palmolive", sector: "Hygiene", mcap: "Large", thesis: "61 ans de hausses, presence mondiale." },
    ]
  },
  { slug: "small-caps-us", title: "Small Caps US & Russell 2000", icon: "TrendingUp", color: "#F97316",
    thesis: "Les small caps US sont historiquement sous-evaluees par rapport aux large caps. Un rattrapage est possible si les taux baissent.",
    items: [
      { ticker: "IWM", name: "iShares Russell 2000 ETF", sector: "ETF Small Cap", mcap: "Large", thesis: "ETF de reference pour les small caps US." },
      { ticker: "SMCI", name: "Super Micro Computer", sector: "Serveurs AI", mcap: "Mid", thesis: "Serveurs AI en forte croissance." },
      { ticker: "CELH", name: "Celsius Holdings", sector: "Boissons", mcap: "Mid", thesis: "Boissons energetiques en forte croissance." },
      { ticker: "CAVA", name: "CAVA Group", sector: "Restauration", mcap: "Mid", thesis: "Chaine de restauration rapide mediterraneenne." },
      { ticker: "DUOL", name: "Duolingo", sector: "EdTech", mcap: "Mid", thesis: "App d'apprentissage des langues, monetisation en hausse." },
    ]
  },
];

for (const theme of NEW_THEMES) {
  const itemCount = theme.items.length;
  await conn.execute(
    `INSERT INTO thematicWatchlists (id, slug, title, thesis, icon, color, whatToWatch, themeRisks, itemCount, sortOrder, isActive) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`,
    [wlId, theme.slug, theme.title, theme.thesis, theme.icon, theme.color,
     JSON.stringify(["Suivre les resultats trimestriels", "Surveiller les changements reglementaires", "Analyser les flux institutionnels"]),
     JSON.stringify(["Risque de valorisation elevee", "Risque reglementaire", "Risque de concentration sectorielle", "Risque de liquidite", "Risque macro-economique"]),
     itemCount, sortOrder]
  );
  for (const item of theme.items) {
    await conn.execute(
      `INSERT INTO watchlistItems (id, watchlistId, name, ticker, sector, marketCapRange, whyItMatters, catalysts, risks, sortOrder) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [itemId, wlId, item.name, item.ticker, item.sector, item.mcap, item.thesis,
       JSON.stringify(["Resultats trimestriels", "Guidance forward", "Mouvements institutionnels"]),
       JSON.stringify(["Valorisation", "Competition", "Regulation"]),
       itemId - 50000]
    );
    itemId++;
  }
  wlId++;
  sortOrder++;
  console.log(`  + ${theme.title} (${itemCount} items)`);
}

console.log(`\nBatch 1 done. Total new themes: ${NEW_THEMES.length}`);
await conn.end();
