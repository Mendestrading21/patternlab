/**
 * Seed quiz questions for all 6 WMB formation modules
 * Run: node seed-quiz.mjs
 */
import "dotenv/config";
import mysql from "mysql2/promise";

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL not set");
  process.exit(1);
}

const questions = [
  // ═══════════════════════════════════════════════════════════
  // MODULE 1 — FONDAMENTAUX (category: "fondamentaux")
  // ═══════════════════════════════════════════════════════════
  {
    category: "fondamentaux",
    question: "Qu'est-ce qu'une action ?",
    options: JSON.stringify([
      "Un titre de propriété représentant une part du capital d'une entreprise",
      "Un prêt accordé à une entreprise",
      "Un contrat d'assurance financier",
      "Un instrument de dette émis par un État"
    ]),
    correctIndex: 0,
    explanation: "Une action est un titre de propriété qui représente une fraction du capital social d'une entreprise. L'actionnaire devient copropriétaire de la société.",
    difficulty: "facile",
    sortOrder: 1,
  },
  {
    category: "fondamentaux",
    question: "Quel est le rôle principal d'une bourse de valeurs ?",
    options: JSON.stringify([
      "Fixer le prix des matières premières",
      "Assurer la liquidité et la transparence des échanges de titres financiers",
      "Garantir les rendements des investisseurs",
      "Réguler les taux d'intérêt"
    ]),
    correctIndex: 1,
    explanation: "La bourse de valeurs est un marché organisé qui permet l'échange de titres financiers (actions, obligations) dans des conditions de transparence et de liquidité.",
    difficulty: "facile",
    sortOrder: 2,
  },
  {
    category: "fondamentaux",
    question: "Quelle est la différence entre le marché primaire et le marché secondaire ?",
    options: JSON.stringify([
      "Le marché primaire est réservé aux professionnels, le secondaire aux particuliers",
      "Le marché primaire concerne l'émission de nouveaux titres, le secondaire leur revente entre investisseurs",
      "Le marché primaire est plus risqué que le secondaire",
      "Il n'y a pas de différence, ce sont deux noms pour le même marché"
    ]),
    correctIndex: 1,
    explanation: "Le marché primaire est celui où les titres sont émis pour la première fois (IPO, émissions obligataires). Le marché secondaire est celui où ces titres sont ensuite échangés entre investisseurs.",
    difficulty: "moyen",
    sortOrder: 3,
  },
  {
    category: "fondamentaux",
    question: "Qu'est-ce qu'un dividende ?",
    options: JSON.stringify([
      "Une taxe prélevée sur les gains boursiers",
      "La part des bénéfices distribuée aux actionnaires",
      "Le prix d'achat d'une action",
      "Un frais de courtage"
    ]),
    correctIndex: 1,
    explanation: "Le dividende est la part des bénéfices qu'une entreprise décide de distribuer à ses actionnaires, généralement de façon trimestrielle ou annuelle.",
    difficulty: "facile",
    sortOrder: 4,
  },
  {
    category: "fondamentaux",
    question: "Qu'est-ce que la capitalisation boursière d'une entreprise ?",
    options: JSON.stringify([
      "Le chiffre d'affaires annuel de l'entreprise",
      "Le nombre total d'actions émises multiplié par le cours de l'action",
      "La valeur comptable de ses actifs",
      "Le montant de ses dettes"
    ]),
    correctIndex: 1,
    explanation: "La capitalisation boursière = nombre d'actions en circulation × prix de l'action. Elle représente la valeur de marché totale de l'entreprise.",
    difficulty: "facile",
    sortOrder: 5,
  },
  {
    category: "fondamentaux",
    question: "Qu'est-ce qu'un ordre au marché (market order) ?",
    options: JSON.stringify([
      "Un ordre exécuté au meilleur prix disponible immédiatement",
      "Un ordre qui ne s'exécute qu'à un prix fixé à l'avance",
      "Un ordre qui reste valable pendant 30 jours",
      "Un ordre réservé aux investisseurs institutionnels"
    ]),
    correctIndex: 0,
    explanation: "Un ordre au marché est exécuté immédiatement au meilleur prix disponible. Il garantit l'exécution mais pas le prix exact.",
    difficulty: "moyen",
    sortOrder: 6,
  },
  {
    category: "fondamentaux",
    question: "Qu'est-ce qu'une obligation ?",
    options: JSON.stringify([
      "Un titre de propriété dans une entreprise",
      "Un titre de créance représentant un prêt à un émetteur",
      "Un produit dérivé complexe",
      "Un fonds d'investissement"
    ]),
    correctIndex: 1,
    explanation: "Une obligation est un titre de créance : l'investisseur prête de l'argent à un émetteur (État, entreprise) qui s'engage à rembourser le capital et à verser des intérêts (coupons).",
    difficulty: "facile",
    sortOrder: 7,
  },
  {
    category: "fondamentaux",
    question: "Qu'est-ce que le PER (Price Earnings Ratio) ?",
    options: JSON.stringify([
      "Le ratio entre le prix de l'action et le bénéfice par action",
      "Le rendement annuel d'un investissement",
      "Le taux de distribution des dividendes",
      "La performance relative d'un fonds"
    ]),
    correctIndex: 0,
    explanation: "Le PER = cours de l'action / bénéfice net par action. Il indique combien de fois les bénéfices sont valorisés par le marché. Un PER élevé peut signifier que le marché anticipe une forte croissance.",
    difficulty: "moyen",
    sortOrder: 8,
  },
  {
    category: "fondamentaux",
    question: "Qu'est-ce qu'un ETF (Exchange-Traded Fund) ?",
    options: JSON.stringify([
      "Un fonds coté en bourse qui réplique un indice ou un panier d'actifs",
      "Un produit dérivé à effet de levier",
      "Un compte d'épargne à taux garanti",
      "Un type de crypto-monnaie"
    ]),
    correctIndex: 0,
    explanation: "Un ETF est un fonds indiciel coté en bourse qui réplique la performance d'un indice (S&P 500, MSCI World, etc.) ou d'un panier d'actifs. Il offre une diversification à faible coût.",
    difficulty: "moyen",
    sortOrder: 9,
  },
  {
    category: "fondamentaux",
    question: "Qu'est-ce que la diversification en investissement ?",
    options: JSON.stringify([
      "Investir tout son capital dans un seul secteur performant",
      "Répartir ses investissements sur différents actifs pour réduire le risque global",
      "Changer fréquemment de stratégie d'investissement",
      "Investir uniquement dans des actifs sans risque"
    ]),
    correctIndex: 1,
    explanation: "La diversification consiste à répartir ses investissements sur différents actifs, secteurs et zones géographiques afin de réduire le risque global du portefeuille.",
    difficulty: "facile",
    sortOrder: 10,
  },

  // ═══════════════════════════════════════════════════════════
  // MODULE 2 — VÉHICULES D'INVESTISSEMENT (category: "vehicules")
  // ═══════════════════════════════════════════════════════════
  {
    category: "vehicules",
    question: "Quelle est la principale différence entre un fonds actif et un fonds passif (ETF indiciel) ?",
    options: JSON.stringify([
      "Un fonds actif tente de battre le marché, un fonds passif réplique un indice",
      "Un fonds actif est toujours plus performant",
      "Un fonds passif est réservé aux investisseurs professionnels",
      "Il n'y a aucune différence de frais entre les deux"
    ]),
    correctIndex: 0,
    explanation: "Un fonds actif est géré par un gestionnaire qui sélectionne les titres pour tenter de surperformer. Un fonds passif (ETF indiciel) réplique simplement un indice de référence, avec des frais généralement plus bas.",
    difficulty: "facile",
    sortOrder: 1,
  },
  {
    category: "vehicules",
    question: "Qu'est-ce que le TER (Total Expense Ratio) d'un fonds ?",
    options: JSON.stringify([
      "Le rendement total annuel du fonds",
      "Le ratio des frais totaux annuels prélevés sur l'actif du fonds",
      "Le taux d'endettement du fonds",
      "Le nombre de transactions effectuées par an"
    ]),
    correctIndex: 1,
    explanation: "Le TER représente l'ensemble des frais annuels d'un fonds (gestion, administration, etc.) exprimés en pourcentage de l'actif net. Un TER bas est généralement préférable pour l'investisseur.",
    difficulty: "moyen",
    sortOrder: 2,
  },
  {
    category: "vehicules",
    question: "Qu'est-ce qu'un REIT (Real Estate Investment Trust) ?",
    options: JSON.stringify([
      "Un prêt immobilier à taux variable",
      "Une société cotée qui investit dans l'immobilier et distribue la majorité de ses revenus",
      "Un contrat d'assurance habitation",
      "Un fonds spéculatif immobilier"
    ]),
    correctIndex: 1,
    explanation: "Un REIT est une société cotée en bourse qui possède et gère des biens immobiliers. Elle est tenue de distribuer au moins 90% de ses revenus imposables sous forme de dividendes.",
    difficulty: "moyen",
    sortOrder: 3,
  },
  {
    category: "vehicules",
    question: "Qu'est-ce qu'une obligation à haut rendement (high yield) ?",
    options: JSON.stringify([
      "Une obligation émise par un État très solvable",
      "Une obligation émise par un émetteur dont la notation de crédit est inférieure à BBB-",
      "Une obligation à taux fixe garantie par l'État",
      "Une obligation convertible en actions"
    ]),
    correctIndex: 1,
    explanation: "Les obligations high yield sont émises par des entreprises ou États dont la notation est inférieure à investment grade (BBB-/Baa3). Elles offrent un rendement plus élevé pour compenser un risque de défaut supérieur.",
    difficulty: "difficile",
    sortOrder: 4,
  },
  {
    category: "vehicules",
    question: "Qu'est-ce que le rendement à l'échéance (yield to maturity) d'une obligation ?",
    options: JSON.stringify([
      "Le taux du coupon annuel uniquement",
      "Le rendement total attendu si l'obligation est conservée jusqu'à son échéance",
      "Le prix de vente de l'obligation sur le marché secondaire",
      "La prime de risque de l'obligation"
    ]),
    correctIndex: 1,
    explanation: "Le yield to maturity (YTM) est le rendement total attendu d'une obligation si elle est conservée jusqu'à son échéance, incluant les coupons et la plus ou moins-value par rapport au prix d'achat.",
    difficulty: "difficile",
    sortOrder: 5,
  },
  {
    category: "vehicules",
    question: "Qu'est-ce qu'un fonds de fonds ?",
    options: JSON.stringify([
      "Un fonds qui investit dans d'autres fonds d'investissement",
      "Un fonds qui n'investit que dans des obligations d'État",
      "Un fonds réservé aux très gros investisseurs",
      "Un fonds qui réplique deux indices simultanément"
    ]),
    correctIndex: 0,
    explanation: "Un fonds de fonds investit dans d'autres fonds plutôt que directement dans des titres. Il offre une diversification supplémentaire mais peut entraîner une superposition de frais.",
    difficulty: "moyen",
    sortOrder: 6,
  },
  {
    category: "vehicules",
    question: "Quelle est la particularité d'un ETF à réplication physique ?",
    options: JSON.stringify([
      "Il utilise des produits dérivés pour répliquer l'indice",
      "Il détient réellement les titres composant l'indice qu'il réplique",
      "Il ne peut être acheté que par des banques",
      "Il garantit un rendement minimum"
    ]),
    correctIndex: 1,
    explanation: "Un ETF à réplication physique détient effectivement les titres de l'indice sous-jacent, contrairement à la réplication synthétique qui utilise des swaps et dérivés.",
    difficulty: "moyen",
    sortOrder: 7,
  },
  {
    category: "vehicules",
    question: "Qu'est-ce que la duration d'une obligation ?",
    options: JSON.stringify([
      "La date d'échéance de l'obligation",
      "La sensibilité du prix de l'obligation aux variations de taux d'intérêt",
      "Le montant du coupon annuel",
      "Le nombre d'années depuis l'émission"
    ]),
    correctIndex: 1,
    explanation: "La duration mesure la sensibilité du prix d'une obligation aux variations de taux d'intérêt. Plus la duration est élevée, plus le prix de l'obligation est sensible aux mouvements de taux.",
    difficulty: "difficile",
    sortOrder: 8,
  },
  {
    category: "vehicules",
    question: "Qu'est-ce qu'un produit structuré ?",
    options: JSON.stringify([
      "Un simple compte d'épargne",
      "Un instrument financier combinant plusieurs produits (obligations, dérivés) pour créer un profil rendement/risque spécifique",
      "Un fonds indiciel classique",
      "Un prêt bancaire à taux fixe"
    ]),
    correctIndex: 1,
    explanation: "Un produit structuré combine généralement une composante obligataire (protection du capital) avec une composante dérivée (exposition à un sous-jacent). Il offre un profil rendement/risque personnalisé.",
    difficulty: "difficile",
    sortOrder: 9,
  },
  {
    category: "vehicules",
    question: "Quel est l'avantage principal d'un plan d'investissement programmé (DCA) ?",
    options: JSON.stringify([
      "Garantir un rendement positif",
      "Lisser le prix d'achat moyen en investissant régulièrement un montant fixe",
      "Éviter totalement les pertes en capital",
      "Obtenir un taux d'intérêt garanti"
    ]),
    correctIndex: 1,
    explanation: "Le Dollar Cost Averaging (DCA) consiste à investir un montant fixe à intervalles réguliers. Cette stratégie lisse le prix d'achat moyen et réduit l'impact de la volatilité à court terme.",
    difficulty: "facile",
    sortOrder: 10,
  },

  // ═══════════════════════════════════════════════════════════
  // MODULE 3 — ANALYSES (category: "analyses")
  // ═══════════════════════════════════════════════════════════
  {
    category: "analyses",
    question: "Quelle est la différence fondamentale entre l'analyse technique et l'analyse fondamentale ?",
    options: JSON.stringify([
      "L'analyse technique étudie les graphiques de prix, l'analyse fondamentale étudie la valeur intrinsèque d'un actif",
      "L'analyse technique est plus fiable que l'analyse fondamentale",
      "L'analyse fondamentale ne s'applique qu'aux obligations",
      "Il n'y a aucune différence pratique"
    ]),
    correctIndex: 0,
    explanation: "L'analyse technique se base sur l'étude des graphiques, volumes et indicateurs de prix. L'analyse fondamentale évalue la valeur intrinsèque d'un actif en étudiant ses données financières, son secteur et l'économie.",
    difficulty: "facile",
    sortOrder: 1,
  },
  {
    category: "analyses",
    question: "Qu'est-ce qu'un support en analyse technique ?",
    options: JSON.stringify([
      "Un niveau de prix où la demande est suffisamment forte pour empêcher le prix de baisser davantage",
      "Le prix le plus haut atteint par un actif",
      "Un indicateur de volume",
      "Le spread entre le bid et le ask"
    ]),
    correctIndex: 0,
    explanation: "Un support est un niveau de prix où la pression acheteuse est historiquement suffisante pour stopper ou inverser une baisse. C'est un concept clé de l'analyse technique.",
    difficulty: "facile",
    sortOrder: 2,
  },
  {
    category: "analyses",
    question: "Que mesure le RSI (Relative Strength Index) ?",
    options: JSON.stringify([
      "La volatilité d'un actif",
      "La force relative des mouvements haussiers par rapport aux mouvements baissiers sur une période donnée",
      "Le volume des transactions",
      "La corrélation entre deux actifs"
    ]),
    correctIndex: 1,
    explanation: "Le RSI mesure la vitesse et l'amplitude des mouvements de prix. Un RSI > 70 est considéré comme suracheté, < 30 comme survendu. Il oscille entre 0 et 100.",
    difficulty: "moyen",
    sortOrder: 3,
  },
  {
    category: "analyses",
    question: "Qu'est-ce que le ratio cours/bénéfice (P/E) en analyse fondamentale ?",
    options: JSON.stringify([
      "Le rapport entre le prix de l'action et le bénéfice net par action",
      "Le rendement du dividende",
      "Le ratio d'endettement de l'entreprise",
      "La marge bénéficiaire nette"
    ]),
    correctIndex: 0,
    explanation: "Le P/E ratio = prix de l'action / BPA. Il indique combien les investisseurs sont prêts à payer pour chaque unité de bénéfice. Un P/E élevé peut refléter des attentes de croissance forte.",
    difficulty: "moyen",
    sortOrder: 4,
  },
  {
    category: "analyses",
    question: "Qu'est-ce qu'une moyenne mobile (moving average) ?",
    options: JSON.stringify([
      "Le prix moyen d'un actif sur une période donnée, recalculé à chaque nouvelle donnée",
      "Le volume moyen de transactions",
      "La volatilité moyenne du marché",
      "Le rendement moyen d'un portefeuille"
    ]),
    correctIndex: 0,
    explanation: "Une moyenne mobile lisse les fluctuations de prix en calculant la moyenne sur une période définie (ex: 50 jours, 200 jours). Elle aide à identifier la tendance sous-jacente.",
    difficulty: "facile",
    sortOrder: 5,
  },
  {
    category: "analyses",
    question: "Qu'est-ce que le free cash flow (flux de trésorerie disponible) ?",
    options: JSON.stringify([
      "Le chiffre d'affaires total de l'entreprise",
      "La trésorerie générée par l'activité après déduction des investissements nécessaires",
      "Le montant des dividendes versés",
      "Le bénéfice net comptable"
    ]),
    correctIndex: 1,
    explanation: "Le free cash flow = cash flow opérationnel - dépenses d'investissement (CAPEX). Il représente la trésorerie réellement disponible pour rembourser la dette, verser des dividendes ou racheter des actions.",
    difficulty: "difficile",
    sortOrder: 6,
  },
  {
    category: "analyses",
    question: "Qu'est-ce qu'un chandelier japonais (candlestick) ?",
    options: JSON.stringify([
      "Un type de graphique qui montre l'ouverture, la clôture, le plus haut et le plus bas d'une période",
      "Un indicateur de volatilité",
      "Un type d'ordre boursier",
      "Un ratio financier"
    ]),
    correctIndex: 0,
    explanation: "Un chandelier japonais représente visuellement 4 informations : le prix d'ouverture, de clôture, le plus haut et le plus bas d'une période. Le corps montre l'écart ouverture/clôture, les mèches les extrêmes.",
    difficulty: "facile",
    sortOrder: 7,
  },
  {
    category: "analyses",
    question: "Qu'est-ce que le ratio dette/EBITDA ?",
    options: JSON.stringify([
      "Le nombre d'années nécessaires pour rembourser la dette avec les bénéfices opérationnels",
      "Le rendement de la dette",
      "Le taux d'intérêt moyen de la dette",
      "La proportion de dette à court terme"
    ]),
    correctIndex: 0,
    explanation: "Le ratio dette/EBITDA mesure le nombre d'années théoriques nécessaires pour rembourser la dette totale avec le résultat opérationnel. Un ratio > 4x est généralement considéré comme élevé.",
    difficulty: "difficile",
    sortOrder: 8,
  },
  {
    category: "analyses",
    question: "Qu'est-ce que les bandes de Bollinger ?",
    options: JSON.stringify([
      "Des niveaux de support et résistance fixes",
      "Un indicateur technique composé d'une moyenne mobile et de deux bandes d'écart-type",
      "Un type de graphique en barres",
      "Un indicateur de sentiment de marché"
    ]),
    correctIndex: 1,
    explanation: "Les bandes de Bollinger se composent d'une moyenne mobile (généralement 20 périodes) et de deux bandes situées à ±2 écarts-types. Elles mesurent la volatilité et identifient les conditions de surachat/survente.",
    difficulty: "moyen",
    sortOrder: 9,
  },
  {
    category: "analyses",
    question: "Qu'est-ce que l'analyse sectorielle ?",
    options: JSON.stringify([
      "L'étude d'un seul titre en isolation",
      "L'analyse comparative des secteurs économiques pour identifier ceux qui offrent les meilleures opportunités",
      "L'analyse exclusive des entreprises technologiques",
      "L'étude des taux d'intérêt par pays"
    ]),
    correctIndex: 1,
    explanation: "L'analyse sectorielle consiste à comparer les différents secteurs économiques (technologie, santé, énergie, etc.) pour identifier ceux qui sont en phase de croissance ou de déclin relatif.",
    difficulty: "moyen",
    sortOrder: 10,
  },

  // ═══════════════════════════════════════════════════════════
  // MODULE 4 — INDICES (category: "indices")
  // ═══════════════════════════════════════════════════════════
  {
    category: "indices",
    question: "Que représente le S&P 500 ?",
    options: JSON.stringify([
      "Les 500 plus grandes entreprises cotées aux États-Unis pondérées par capitalisation",
      "Les 500 entreprises les plus rentables au monde",
      "Un indice de 500 obligations d'État américaines",
      "Les 500 actions les plus échangées sur le NYSE"
    ]),
    correctIndex: 0,
    explanation: "Le S&P 500 regroupe les 500 plus grandes entreprises cotées aux États-Unis, pondérées par leur capitalisation boursière flottante. Il est considéré comme le meilleur baromètre du marché actions américain.",
    difficulty: "facile",
    sortOrder: 1,
  },
  {
    category: "indices",
    question: "Quelle est la particularité du Dow Jones Industrial Average ?",
    options: JSON.stringify([
      "Il est pondéré par les prix des actions (price-weighted), pas par la capitalisation",
      "Il contient 500 entreprises",
      "Il ne contient que des entreprises technologiques",
      "Il est calculé uniquement une fois par jour"
    ]),
    correctIndex: 0,
    explanation: "Le DJIA est un indice pondéré par les prix (price-weighted) de 30 grandes entreprises américaines. Une action à prix élevé a plus d'influence qu'une action à prix bas, indépendamment de la capitalisation.",
    difficulty: "moyen",
    sortOrder: 2,
  },
  {
    category: "indices",
    question: "Qu'est-ce que le NASDAQ Composite ?",
    options: JSON.stringify([
      "Un indice regroupant toutes les entreprises cotées sur le NASDAQ, à forte composante technologique",
      "Un indice de 30 valeurs industrielles",
      "Un indice obligataire américain",
      "Un indice des matières premières"
    ]),
    correctIndex: 0,
    explanation: "Le NASDAQ Composite inclut toutes les entreprises cotées sur le NASDAQ (plus de 3000). Il est fortement pondéré en valeurs technologiques (Apple, Microsoft, Amazon, etc.).",
    difficulty: "facile",
    sortOrder: 3,
  },
  {
    category: "indices",
    question: "Qu'est-ce que le VIX ?",
    options: JSON.stringify([
      "Un indice de volatilité implicite du S&P 500, souvent appelé 'indice de la peur'",
      "Un indice de valeurs technologiques",
      "Le taux directeur de la Fed",
      "Un indicateur de volume du marché"
    ]),
    correctIndex: 0,
    explanation: "Le VIX mesure la volatilité implicite attendue du S&P 500 sur 30 jours. Un VIX élevé (> 30) indique une forte incertitude, un VIX bas (< 15) un marché calme.",
    difficulty: "moyen",
    sortOrder: 4,
  },
  {
    category: "indices",
    question: "Qu'est-ce que le SMI (Swiss Market Index) ?",
    options: JSON.stringify([
      "L'indice phare de la bourse suisse regroupant les 20 plus grandes capitalisations",
      "Un indice de matières premières suisses",
      "Un indice obligataire suisse",
      "Un indice des banques européennes"
    ]),
    correctIndex: 0,
    explanation: "Le SMI regroupe les 20 plus grandes capitalisations cotées à la SIX Swiss Exchange (Nestlé, Novartis, Roche, UBS, etc.). Il est l'équivalent suisse du CAC 40 ou du DAX.",
    difficulty: "moyen",
    sortOrder: 5,
  },
  {
    category: "indices",
    question: "Qu'est-ce qu'un indice pondéré par la capitalisation ?",
    options: JSON.stringify([
      "Un indice où chaque composant a le même poids",
      "Un indice où le poids de chaque composant dépend de sa capitalisation boursière",
      "Un indice trié par ordre alphabétique",
      "Un indice basé sur le volume de transactions"
    ]),
    correctIndex: 1,
    explanation: "Dans un indice pondéré par la capitalisation (comme le S&P 500), les entreprises avec une plus grande capitalisation ont un poids plus important dans le calcul de l'indice.",
    difficulty: "facile",
    sortOrder: 6,
  },
  {
    category: "indices",
    question: "Qu'est-ce que le Russell 2000 ?",
    options: JSON.stringify([
      "Un indice des 2000 plus petites capitalisations américaines (small caps)",
      "Un indice de 2000 obligations",
      "Un indice des 2000 plus grandes entreprises mondiales",
      "Un indice de matières premières"
    ]),
    correctIndex: 0,
    explanation: "Le Russell 2000 regroupe les 2000 plus petites capitalisations de l'indice Russell 3000. Il est le principal baromètre des small caps américaines et reflète la santé de l'économie domestique.",
    difficulty: "moyen",
    sortOrder: 7,
  },
  {
    category: "indices",
    question: "Pourquoi le MSCI World est-il important pour un investisseur diversifié ?",
    options: JSON.stringify([
      "Il couvre environ 1500 entreprises de 23 pays développés, offrant une diversification mondiale",
      "Il garantit un rendement positif chaque année",
      "Il ne contient que des entreprises européennes",
      "Il est réservé aux investisseurs institutionnels"
    ]),
    correctIndex: 0,
    explanation: "Le MSCI World couvre environ 1500 entreprises de grande et moyenne capitalisation dans 23 pays développés. Il est souvent utilisé comme référence pour un portefeuille actions mondial diversifié.",
    difficulty: "moyen",
    sortOrder: 8,
  },
  {
    category: "indices",
    question: "Qu'est-ce qu'un bear market ?",
    options: JSON.stringify([
      "Une baisse de plus de 20% par rapport au dernier sommet",
      "Une hausse de plus de 20%",
      "Un marché avec un volume très faible",
      "Un marché où seules les obligations montent"
    ]),
    correctIndex: 0,
    explanation: "Un bear market (marché baissier) est défini par une baisse de 20% ou plus par rapport au dernier sommet. Un bull market (marché haussier) est une hausse de 20% ou plus depuis le dernier creux.",
    difficulty: "facile",
    sortOrder: 9,
  },
  {
    category: "indices",
    question: "Qu'est-ce que le rebalancement d'un indice ?",
    options: JSON.stringify([
      "L'ajout ou le retrait de composants et l'ajustement des pondérations selon des règles définies",
      "La fermeture temporaire de l'indice",
      "Le changement de devise de cotation",
      "La fusion de deux indices"
    ]),
    correctIndex: 0,
    explanation: "Le rebalancement est le processus périodique (trimestriel, semestriel) par lequel un indice ajuste ses composants et leurs pondérations selon ses règles méthodologiques.",
    difficulty: "moyen",
    sortOrder: 10,
  },

  // ═══════════════════════════════════════════════════════════
  // MODULE 5 — HISTOIRE (category: "histoire")
  // ═══════════════════════════════════════════════════════════
  {
    category: "histoire",
    question: "En quelle année a eu lieu le krach de Wall Street qui a déclenché la Grande Dépression ?",
    options: JSON.stringify([
      "1929",
      "1907",
      "1937",
      "1920"
    ]),
    correctIndex: 0,
    explanation: "Le krach de 1929 (Mardi noir, 29 octobre) a marqué le début de la Grande Dépression. Le Dow Jones a perdu environ 89% de sa valeur entre 1929 et 1932.",
    difficulty: "facile",
    sortOrder: 1,
  },
  {
    category: "histoire",
    question: "Qu'est-ce que la bulle des tulipes (Tulipmania) ?",
    options: JSON.stringify([
      "La première bulle spéculative documentée de l'histoire, aux Pays-Bas en 1637",
      "Une crise bancaire anglaise du 18e siècle",
      "Un krach boursier japonais",
      "Une fraude financière américaine"
    ]),
    correctIndex: 0,
    explanation: "La Tulipmania (1636-1637) aux Pays-Bas est considérée comme la première bulle spéculative de l'histoire. Les prix des bulbes de tulipes ont atteint des niveaux absurdes avant de s'effondrer brutalement.",
    difficulty: "moyen",
    sortOrder: 2,
  },
  {
    category: "histoire",
    question: "Qu'est-ce que la bulle Internet (dot-com bubble) ?",
    options: JSON.stringify([
      "Une bulle spéculative sur les entreprises technologiques et Internet entre 1997 et 2000",
      "Une crise bancaire de 2008",
      "Un krach pétrolier des années 1970",
      "Une bulle immobilière japonaise"
    ]),
    correctIndex: 0,
    explanation: "La bulle dot-com (1997-2000) a vu les valorisations des entreprises Internet atteindre des niveaux irrationnels. Le NASDAQ a perdu près de 78% entre mars 2000 et octobre 2002.",
    difficulty: "facile",
    sortOrder: 3,
  },
  {
    category: "histoire",
    question: "Quelle a été la cause principale de la crise financière de 2008 ?",
    options: JSON.stringify([
      "L'effondrement du marché des subprimes (prêts hypothécaires à risque) aux États-Unis",
      "Une guerre commerciale entre les États-Unis et la Chine",
      "L'éclatement de la bulle Internet",
      "Une crise de la dette souveraine européenne"
    ]),
    correctIndex: 0,
    explanation: "La crise de 2008 a été déclenchée par l'effondrement du marché des subprimes américains. Les prêts hypothécaires à risque, titrisés et disséminés dans le système financier mondial, ont provoqué une crise systémique.",
    difficulty: "facile",
    sortOrder: 4,
  },
  {
    category: "histoire",
    question: "Qu'est-ce que le Glass-Steagall Act (1933) ?",
    options: JSON.stringify([
      "Une loi américaine séparant les activités de banque commerciale et de banque d'investissement",
      "Un accord international sur les taux de change",
      "Une loi créant la Réserve fédérale",
      "Un traité commercial entre les États-Unis et l'Europe"
    ]),
    correctIndex: 0,
    explanation: "Le Glass-Steagall Act (1933) a imposé la séparation entre banques commerciales et banques d'investissement après le krach de 1929. Son abrogation partielle en 1999 (Gramm-Leach-Bliley Act) est souvent citée comme facteur de la crise de 2008.",
    difficulty: "difficile",
    sortOrder: 5,
  },
  {
    category: "histoire",
    question: "Qu'est-ce que le Lundi noir (Black Monday) de 1987 ?",
    options: JSON.stringify([
      "Le jour où le Dow Jones a perdu 22.6% en une seule séance, le 19 octobre 1987",
      "Le début de la Grande Dépression en 1929",
      "L'effondrement de Lehman Brothers en 2008",
      "Le krach du NASDAQ en 2000"
    ]),
    correctIndex: 0,
    explanation: "Le 19 octobre 1987, le Dow Jones a chuté de 22.6% en une seule journée — la plus forte baisse journalière de son histoire. La cause exacte reste débattue (trading automatisé, surévaluation).",
    difficulty: "moyen",
    sortOrder: 6,
  },
  {
    category: "histoire",
    question: "Qu'est-ce que les accords de Bretton Woods (1944) ?",
    options: JSON.stringify([
      "Des accords établissant un système monétaire international basé sur le dollar convertible en or",
      "Un traité de paix après la Seconde Guerre mondiale",
      "La création de l'Union européenne",
      "Un accord sur les tarifs douaniers"
    ]),
    correctIndex: 0,
    explanation: "Les accords de Bretton Woods (1944) ont établi un système monétaire international où le dollar était convertible en or et les autres devises étaient arrimées au dollar. Ce système a pris fin en 1971 (Nixon Shock).",
    difficulty: "difficile",
    sortOrder: 7,
  },
  {
    category: "histoire",
    question: "Quelle leçon principale peut-on tirer de la bulle japonaise des années 1980 ?",
    options: JSON.stringify([
      "Qu'un marché peut mettre des décennies à retrouver ses sommets après une bulle",
      "Que les bulles ne se produisent qu'aux États-Unis",
      "Que l'immobilier ne peut jamais baisser",
      "Que les banques centrales peuvent toujours empêcher les crises"
    ]),
    correctIndex: 0,
    explanation: "Le Nikkei 225 a atteint 38'957 points en décembre 1989. Il a fallu attendre 2024 (34 ans) pour retrouver ce niveau. C'est un rappel que les bulles peuvent avoir des conséquences durables.",
    difficulty: "moyen",
    sortOrder: 8,
  },
  {
    category: "histoire",
    question: "Qui est Benjamin Graham et pourquoi est-il important ?",
    options: JSON.stringify([
      "Le père de l'investissement dans la valeur (value investing) et mentor de Warren Buffett",
      "Le fondateur de la Réserve fédérale",
      "L'inventeur du trading algorithmique",
      "Le créateur du premier fonds indiciel"
    ]),
    correctIndex: 0,
    explanation: "Benjamin Graham (1894-1976) est considéré comme le père du value investing. Son livre 'The Intelligent Investor' (1949) reste une référence. Il a été le mentor de Warren Buffett à Columbia University.",
    difficulty: "moyen",
    sortOrder: 9,
  },
  {
    category: "histoire",
    question: "Qu'est-ce que le Flash Crash du 6 mai 2010 ?",
    options: JSON.stringify([
      "Une chute éclair de ~9% du Dow Jones en quelques minutes, causée par le trading algorithmique",
      "Un krach immobilier",
      "Une panne de courant à Wall Street",
      "Une fraude massive d'un trader"
    ]),
    correctIndex: 0,
    explanation: "Le 6 mai 2010, le Dow Jones a perdu environ 1000 points (~9%) en quelques minutes avant de rebondir. L'événement a été attribué au trading haute fréquence et a conduit à de nouvelles régulations (circuit breakers).",
    difficulty: "difficile",
    sortOrder: 10,
  },

  // ═══════════════════════════════════════════════════════════
  // MODULE 6 — OPTIONS (category: "options")
  // ═══════════════════════════════════════════════════════════
  {
    category: "options",
    question: "Qu'est-ce qu'une option d'achat (call) ?",
    options: JSON.stringify([
      "Un contrat donnant le droit (mais pas l'obligation) d'acheter un actif à un prix fixé",
      "Un contrat obligeant à vendre un actif",
      "Un type d'obligation convertible",
      "Un ordre d'achat au marché"
    ]),
    correctIndex: 0,
    explanation: "Un call donne à son détenteur le droit (pas l'obligation) d'acheter l'actif sous-jacent au prix d'exercice (strike) avant ou à la date d'expiration. L'acheteur paie une prime pour ce droit.",
    difficulty: "facile",
    sortOrder: 1,
  },
  {
    category: "options",
    question: "Qu'est-ce que le prix d'exercice (strike price) d'une option ?",
    options: JSON.stringify([
      "Le prix auquel le détenteur peut acheter ou vendre l'actif sous-jacent",
      "Le prix actuel de l'action sur le marché",
      "La prime payée pour l'option",
      "Le prix de clôture de l'action"
    ]),
    correctIndex: 0,
    explanation: "Le strike price est le prix fixé dans le contrat d'option auquel le détenteur peut exercer son droit d'achat (call) ou de vente (put) sur l'actif sous-jacent.",
    difficulty: "facile",
    sortOrder: 2,
  },
  {
    category: "options",
    question: "Qu'est-ce que la prime d'une option ?",
    options: JSON.stringify([
      "Le prix payé par l'acheteur au vendeur pour acquérir le contrat d'option",
      "Le dividende versé par l'action sous-jacente",
      "Le bénéfice garanti de l'option",
      "Le prix d'exercice de l'option"
    ]),
    correctIndex: 0,
    explanation: "La prime est le prix du contrat d'option. Elle est composée de la valeur intrinsèque (différence entre le prix du sous-jacent et le strike) et de la valeur temps (temps restant avant expiration).",
    difficulty: "facile",
    sortOrder: 3,
  },
  {
    category: "options",
    question: "Qu'est-ce qu'une option 'dans la monnaie' (in the money) ?",
    options: JSON.stringify([
      "Un call dont le prix du sous-jacent est supérieur au strike, ou un put dont le prix est inférieur au strike",
      "Une option qui a expiré",
      "Une option dont la prime est nulle",
      "Une option qui ne peut pas être exercée"
    ]),
    correctIndex: 0,
    explanation: "Une option est 'in the money' quand elle a une valeur intrinsèque positive. Pour un call : prix du sous-jacent > strike. Pour un put : prix du sous-jacent < strike.",
    difficulty: "moyen",
    sortOrder: 4,
  },
  {
    category: "options",
    question: "Qu'est-ce que le theta (θ) en trading d'options ?",
    options: JSON.stringify([
      "La mesure de la perte de valeur temps d'une option par jour",
      "La sensibilité de l'option aux variations du sous-jacent",
      "La volatilité implicite de l'option",
      "Le taux d'intérêt sans risque"
    ]),
    correctIndex: 0,
    explanation: "Le theta mesure la décroissance temporelle de la prime d'une option. Toutes choses égales par ailleurs, une option perd de la valeur chaque jour qui passe (time decay). Le theta s'accélère à l'approche de l'expiration.",
    difficulty: "moyen",
    sortOrder: 5,
  },
  {
    category: "options",
    question: "Qu'est-ce que le delta (Δ) d'une option ?",
    options: JSON.stringify([
      "La variation du prix de l'option pour une variation de 1$ du sous-jacent",
      "Le nombre de jours avant expiration",
      "Le volume de transactions de l'option",
      "Le spread entre le bid et le ask"
    ]),
    correctIndex: 0,
    explanation: "Le delta mesure la sensibilité du prix de l'option aux mouvements du sous-jacent. Un delta de 0.50 signifie que l'option gagne 0.50$ quand le sous-jacent monte de 1$. Les calls ont un delta positif, les puts négatif.",
    difficulty: "moyen",
    sortOrder: 6,
  },
  {
    category: "options",
    question: "Qu'est-ce qu'un covered call ?",
    options: JSON.stringify([
      "La vente d'un call sur un actif que l'on possède déjà en portefeuille",
      "L'achat simultané d'un call et d'un put",
      "La vente à découvert d'une action",
      "L'achat d'un call sans posséder le sous-jacent"
    ]),
    correctIndex: 0,
    explanation: "Un covered call consiste à vendre un call sur une action que l'on détient. On encaisse la prime, mais on limite le potentiel de hausse. C'est une stratégie de revenus complémentaires.",
    difficulty: "moyen",
    sortOrder: 7,
  },
  {
    category: "options",
    question: "Qu'est-ce que la volatilité implicite (IV) ?",
    options: JSON.stringify([
      "L'anticipation du marché sur la volatilité future du sous-jacent, intégrée dans le prix de l'option",
      "La volatilité historique mesurée sur les 30 derniers jours",
      "Le volume de transactions de l'option",
      "Le taux de rendement de l'option"
    ]),
    correctIndex: 0,
    explanation: "La volatilité implicite reflète les attentes du marché sur la volatilité future. Une IV élevée rend les options plus chères. Elle augmente généralement en période d'incertitude.",
    difficulty: "difficile",
    sortOrder: 8,
  },
  {
    category: "options",
    question: "Qu'est-ce qu'un straddle ?",
    options: JSON.stringify([
      "L'achat simultané d'un call et d'un put au même strike et à la même échéance",
      "La vente d'un call couvert",
      "L'achat de deux calls à des strikes différents",
      "La vente simultanée de deux puts"
    ]),
    correctIndex: 0,
    explanation: "Un straddle (long) consiste à acheter un call et un put au même strike et même échéance. On profite d'un mouvement important dans n'importe quelle direction. Le risque est limité à la prime totale payée.",
    difficulty: "difficile",
    sortOrder: 9,
  },
  {
    category: "options",
    question: "Quel est le risque maximum pour l'acheteur d'une option ?",
    options: JSON.stringify([
      "La prime payée pour l'option",
      "Un risque illimité",
      "Le prix du sous-jacent",
      "Le double de la prime"
    ]),
    correctIndex: 0,
    explanation: "L'acheteur d'une option (call ou put) risque au maximum la prime payée. C'est l'un des avantages des options : le risque est défini et limité dès le départ pour l'acheteur.",
    difficulty: "facile",
    sortOrder: 10,
  },
];

async function seed() {
  const conn = await mysql.createConnection(DATABASE_URL);
  
  // Check existing questions
  const [existing] = await conn.execute("SELECT COUNT(*) as cnt FROM quizQuestions");
  console.log(`Existing quiz questions: ${existing[0].cnt}`);
  
  if (existing[0].cnt > 0) {
    console.log("Clearing existing questions...");
    await conn.execute("DELETE FROM quizQuestions");
  }
  
  // Insert all questions
  for (const q of questions) {
    await conn.execute(
      "INSERT INTO quizQuestions (category, question, options, correctIndex, explanation, difficulty, sortOrder) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [q.category, q.question, q.options, q.correctIndex, q.explanation, q.difficulty, q.sortOrder]
    );
  }
  
  console.log(`Inserted ${questions.length} quiz questions across 6 modules`);
  
  // Verify
  const [counts] = await conn.execute(
    "SELECT category, COUNT(*) as cnt FROM quizQuestions GROUP BY category ORDER BY category"
  );
  console.log("Questions per module:");
  for (const row of counts) {
    console.log(`  ${row.category}: ${row.cnt}`);
  }
  
  await conn.end();
  console.log("Done!");
}

seed().catch(console.error);
