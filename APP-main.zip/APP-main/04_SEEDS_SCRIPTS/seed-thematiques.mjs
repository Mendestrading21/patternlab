import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const NEW_THEMES = [
  {
    slug: "quantique",
    title: "Informatique Quantique",
    thesis: "L'informatique quantique promet de résoudre des problèmes impossibles pour les ordinateurs classiques. Les géants tech investissent massivement dans cette technologie encore émergente, avec des applications potentielles en cryptographie, simulation moléculaire et optimisation.",
    icon: "Atom",
    color: "#7C3AED",
    whatToWatch: "Progrès en correction d'erreurs quantiques, annonces de 'quantum advantage', partenariats industriels, investissements gouvernementaux",
    themeRisks: "Technologie encore très expérimentale, horizons de rentabilité lointains, valorisations spéculatives, risque de 'hype cycle'",
    items: [
      { name: "IonQ", ticker: "IONQ", sector: "Quantum Computing", marketCapRange: "mid", whyItMatters: "Pure-play quantique coté en bourse, technologie à ions piégés" },
      { name: "Rigetti Computing", ticker: "RGTI", sector: "Quantum Computing", marketCapRange: "small", whyItMatters: "Processeurs quantiques supraconducteurs, cloud quantique" },
      { name: "D-Wave Quantum", ticker: "QBTS", sector: "Quantum Computing", marketCapRange: "small", whyItMatters: "Pionniers du quantum annealing, applications commerciales" },
      { name: "Alphabet (Google)", ticker: "GOOGL", sector: "Tech / Quantum", marketCapRange: "mega", whyItMatters: "Google Quantum AI, processeur Willow, quantum supremacy" },
      { name: "IBM", ticker: "IBM", sector: "Tech / Quantum", marketCapRange: "large", whyItMatters: "IBM Quantum, roadmap 100K+ qubits, Qiskit ecosystem" },
    ]
  },
  {
    slug: "space-economy",
    title: "Economie Spatiale",
    thesis: "Le marché spatial mondial est estimé à $630 milliards et pourrait dépasser $1.8T d'ici 2035. Satellites, lanceurs réutilisables, internet spatial et tourisme spatial transforment cette industrie autrefois réservée aux gouvernements.",
    icon: "Rocket",
    color: "#1E40AF",
    whatToWatch: "Contrats gouvernementaux (NASA, DoD), déploiement de constellations, coûts de lancement, régulation de l'espace",
    themeRisks: "Dépendance aux contrats publics, risques techniques élevés, concurrence intense, débris spatiaux",
    items: [
      { name: "Rocket Lab", ticker: "RKLB", sector: "Lanceurs spatiaux", marketCapRange: "mid", whyItMatters: "Lanceur Electron, Neutron en développement, composants satellites" },
      { name: "Intuitive Machines", ticker: "LUNR", sector: "Services lunaires", marketCapRange: "small", whyItMatters: "Alunisseurs commerciaux, contrats NASA CLPS" },
      { name: "Planet Labs", ticker: "PL", sector: "Imagerie satellite", marketCapRange: "small", whyItMatters: "Plus grande constellation d'imagerie terrestre, données géospatiales" },
      { name: "L3Harris Technologies", ticker: "LHX", sector: "Défense / Espace", marketCapRange: "large", whyItMatters: "Systèmes spatiaux militaires, satellites de communication" },
      { name: "Redwire", ticker: "RDW", sector: "Infrastructure spatiale", marketCapRange: "small", whyItMatters: "Fabrication spatiale, panneaux solaires, structures déployables" },
    ]
  },
  {
    slug: "blockchain-tokenisation",
    title: "Blockchain & Tokenisation",
    thesis: "La tokenisation d'actifs réels (immobilier, obligations, art) sur blockchain pourrait représenter un marché de $16T d'ici 2030 selon BCG. Les institutions financières traditionnelles adoptent progressivement cette technologie.",
    icon: "Link",
    color: "#F59E0B",
    whatToWatch: "Adoption institutionnelle, régulation (MiCA en Europe), ETF crypto, tokenisation d'actifs réels, stablecoins",
    themeRisks: "Régulation incertaine, volatilité extrême, risques de sécurité (hacks), adoption plus lente que prévu",
    items: [
      { name: "Coinbase", ticker: "COIN", sector: "Crypto exchange", marketCapRange: "large", whyItMatters: "Plus grande plateforme crypto US, services institutionnels, Base L2" },
      { name: "MicroStrategy", ticker: "MSTR", sector: "Bitcoin treasury", marketCapRange: "large", whyItMatters: "Plus grande réserve corporate de Bitcoin, proxy BTC" },
      { name: "Block (Square)", ticker: "XYZ", sector: "Fintech / Crypto", marketCapRange: "large", whyItMatters: "Cash App, Bitcoin mining, paiements décentralisés" },
      { name: "Marathon Digital", ticker: "MARA", sector: "Bitcoin mining", marketCapRange: "mid", whyItMatters: "Un des plus grands mineurs Bitcoin cotés" },
      { name: "Galaxy Digital", ticker: "GLXY", sector: "Crypto services", marketCapRange: "mid", whyItMatters: "Services financiers crypto, trading, asset management" },
    ]
  },
  {
    slug: "crypto-infrastructure",
    title: "Infrastructure Crypto",
    thesis: "Au-delà du trading, l'infrastructure crypto (custody, staking, oracles, L2) devient critique. Les institutions ont besoin de rails fiables pour opérer dans l'écosystème crypto.",
    icon: "Server",
    color: "#8B5CF6",
    whatToWatch: "Volumes de staking, adoption DeFi institutionnelle, régulation des stablecoins, interopérabilité cross-chain",
    themeRisks: "Risques smart contract, régulation hostile, concentration des validateurs, dépendance à Ethereum",
    items: [
      { name: "Coinbase", ticker: "COIN", sector: "Infrastructure crypto", marketCapRange: "large", whyItMatters: "Custody institutionnelle, staking, Base L2" },
      { name: "Robinhood", ticker: "HOOD", sector: "Fintech / Crypto", marketCapRange: "mid", whyItMatters: "Trading crypto retail, expansion des services" },
      { name: "Riot Platforms", ticker: "RIOT", sector: "Mining infrastructure", marketCapRange: "mid", whyItMatters: "Infrastructure de minage Bitcoin à grande échelle" },
      { name: "CleanSpark", ticker: "CLSK", sector: "Mining durable", marketCapRange: "mid", whyItMatters: "Minage Bitcoin avec énergie propre" },
    ]
  },
  {
    slug: "defense-cyber-etatique",
    title: "Defense & Cybersecurite Etatique",
    thesis: "Les budgets de défense mondiaux atteignent des records ($2.4T en 2024). La cybersécurité étatique est devenue un pilier stratégique face aux menaces de guerre hybride, espionnage et attaques sur les infrastructures critiques.",
    icon: "ShieldAlert",
    color: "#DC2626",
    whatToWatch: "Budgets OTAN, tensions géopolitiques, contrats gouvernementaux, réglementation cyber (NIS2, CMMC)",
    themeRisks: "Dépendance aux cycles budgétaires, risques géopolitiques, concentration des contrats, pression sur les marges",
    items: [
      { name: "Palantir Technologies", ticker: "PLTR", sector: "Data / Défense", marketCapRange: "large", whyItMatters: "Plateforme d'analyse pour gouvernements et armées" },
      { name: "CrowdStrike", ticker: "CRWD", sector: "Cybersécurité", marketCapRange: "large", whyItMatters: "Leader endpoint security, contrats gouvernementaux" },
      { name: "Booz Allen Hamilton", ticker: "BAH", sector: "Conseil défense", marketCapRange: "large", whyItMatters: "Premier consultant du gouvernement US en cyber" },
      { name: "Leidos Holdings", ticker: "LDOS", sector: "IT défense", marketCapRange: "large", whyItMatters: "Services IT pour le Pentagone et agences fédérales" },
      { name: "Palo Alto Networks", ticker: "PANW", sector: "Cybersécurité", marketCapRange: "large", whyItMatters: "Sécurité réseau et cloud pour gouvernements" },
    ]
  },
  {
    slug: "petrole-services",
    title: "Petrole & Services Petroliers",
    thesis: "Malgré la transition énergétique, le pétrole reste la première source d'énergie mondiale. Les services pétroliers profitent de la reprise des investissements E&P et de la complexité croissante des opérations offshore.",
    icon: "Droplet",
    color: "#92400E",
    whatToWatch: "Prix du Brent/WTI, décisions OPEC+, production US shale, stocks stratégiques, tensions Moyen-Orient",
    themeRisks: "Volatilité des prix, transition énergétique, risques géopolitiques, pression ESG sur le financement",
    items: [
      { name: "Schlumberger (SLB)", ticker: "SLB", sector: "Services pétroliers", marketCapRange: "large", whyItMatters: "N°1 mondial des services pétroliers, digital & décarbonation" },
      { name: "Halliburton", ticker: "HAL", sector: "Services pétroliers", marketCapRange: "large", whyItMatters: "Complétion et production, forte exposition Amérique du Nord" },
      { name: "Baker Hughes", ticker: "BKR", sector: "Services pétroliers", marketCapRange: "large", whyItMatters: "Équipements et services, transition vers le GNL" },
      { name: "ConocoPhillips", ticker: "COP", sector: "E&P", marketCapRange: "large", whyItMatters: "Plus grand producteur indépendant US" },
      { name: "Devon Energy", ticker: "DVN", sector: "E&P", marketCapRange: "large", whyItMatters: "Producteur shale, dividende variable lié au prix du pétrole" },
    ]
  },
  {
    slug: "gaz-naturel-lng",
    title: "Gaz Naturel & GNL",
    thesis: "Le gaz naturel est considéré comme le 'carburant de transition'. La demande de GNL explose avec la diversification énergétique européenne post-Ukraine et la croissance asiatique. Les US sont devenus le 1er exportateur mondial.",
    icon: "Flame",
    color: "#EA580C",
    whatToWatch: "Prix Henry Hub et TTF, capacités d'export GNL US, demande asiatique, politique énergétique US",
    themeRisks: "Surcapacité potentielle, concurrence renouvelables, régulation environnementale, volatilité saisonnière",
    items: [
      { name: "Cheniere Energy", ticker: "LNG", sector: "GNL export", marketCapRange: "large", whyItMatters: "N°1 de l'export de GNL aux US, Sabine Pass & Corpus Christi" },
      { name: "EQT Corporation", ticker: "EQT", sector: "Production gaz", marketCapRange: "large", whyItMatters: "Plus grand producteur de gaz naturel US" },
      { name: "Tellurian", ticker: "TELL", sector: "GNL", marketCapRange: "small", whyItMatters: "Projet Driftwood LNG, spéculatif mais potentiel élevé" },
      { name: "New Fortress Energy", ticker: "NFE", sector: "Infrastructure GNL", marketCapRange: "mid", whyItMatters: "Solutions GNL rapides pour marchés émergents" },
    ]
  },
  {
    slug: "vehicules-electriques",
    title: "Vehicules Electriques",
    thesis: "Les VE représentent ~20% des ventes mondiales de voitures neuves. La concurrence s'intensifie entre constructeurs traditionnels et nouveaux entrants, tandis que la Chine domine la chaîne de valeur.",
    icon: "Car",
    color: "#059669",
    whatToWatch: "Parts de marché, marges par véhicule, infrastructure de recharge, subventions (IRA), concurrence chinoise",
    themeRisks: "Guerre des prix, surcapacité, dépendance aux subventions, coûts des batteries, concurrence BYD",
    items: [
      { name: "Tesla", ticker: "TSLA", sector: "VE / Énergie", marketCapRange: "mega", whyItMatters: "Leader mondial VE, Supercharger network, robotaxi" },
      { name: "Rivian", ticker: "RIVN", sector: "VE", marketCapRange: "mid", whyItMatters: "Pick-ups et SUV électriques, partenariat Amazon" },
      { name: "Lucid Group", ticker: "LCID", sector: "VE premium", marketCapRange: "mid", whyItMatters: "Berline premium Air, technologie de batterie avancée" },
      { name: "ChargePoint", ticker: "CHPT", sector: "Infrastructure recharge", marketCapRange: "small", whyItMatters: "Plus grand réseau de recharge indépendant" },
      { name: "Li Auto", ticker: "LI", sector: "VE Chine", marketCapRange: "large", whyItMatters: "SUV hybrides rechargeables, forte croissance en Chine" },
    ]
  },
  {
    slug: "batteries-stockage",
    title: "Batteries & Stockage d'Energie",
    thesis: "Le marché mondial des batteries devrait atteindre $400B d'ici 2030. Le stockage d'énergie est critique pour l'intégration des renouvelables. Les technologies évoluent rapidement (solid-state, sodium-ion).",
    icon: "Battery",
    color: "#16A34A",
    whatToWatch: "Prix du lithium et nickel, capacités de production, technologies next-gen, politiques IRA/EU",
    themeRisks: "Volatilité des matières premières, domination chinoise de la chaîne, risques technologiques, surcapacité",
    items: [
      { name: "Albemarle", ticker: "ALB", sector: "Lithium", marketCapRange: "large", whyItMatters: "N°1 mondial du lithium, matière première clé des batteries" },
      { name: "QuantumScape", ticker: "QS", sector: "Batteries solid-state", marketCapRange: "mid", whyItMatters: "Pionniers batteries solid-state, partenariat VW" },
      { name: "Enphase Energy", ticker: "ENPH", sector: "Stockage résidentiel", marketCapRange: "large", whyItMatters: "Micro-onduleurs et batteries résidentielles" },
      { name: "Fluence Energy", ticker: "FLNC", sector: "Stockage grid", marketCapRange: "mid", whyItMatters: "Solutions de stockage à grande échelle, JV Siemens/AES" },
      { name: "Livent (Arcadium)", ticker: "ALTM", sector: "Lithium", marketCapRange: "mid", whyItMatters: "Producteur de lithium hydroxide pour batteries" },
    ]
  },
  {
    slug: "eau-infrastructures",
    title: "Eau & Infrastructures",
    thesis: "L'eau est la ressource la plus sous-évaluée. Vieillissement des infrastructures, stress hydrique croissant et réglementation plus stricte créent une demande structurelle pour les solutions de traitement et distribution d'eau.",
    icon: "Waves",
    color: "#0284C7",
    whatToWatch: "Investissements Infrastructure Act, sécheresses, réglementation PFAS, privatisation des services d'eau",
    themeRisks: "Régulation des prix, cycles d'investissement longs, exposition climatique, risques politiques",
    items: [
      { name: "Xylem", ticker: "XYL", sector: "Traitement eau", marketCapRange: "large", whyItMatters: "Solutions de traitement et transport d'eau, smart water" },
      { name: "American Water Works", ticker: "AWK", sector: "Utilities eau", marketCapRange: "large", whyItMatters: "Plus grande utility d'eau cotée aux US" },
      { name: "Veolia (ADR)", ticker: "VEOEY", sector: "Services environnementaux", marketCapRange: "large", whyItMatters: "Leader mondial eau, déchets, énergie" },
      { name: "Mueller Water Products", ticker: "MWA", sector: "Infrastructure eau", marketCapRange: "mid", whyItMatters: "Vannes, bouches d'incendie, infrastructure de distribution" },
    ]
  },
  {
    slug: "glp1-obesite",
    title: "GLP-1 & Traitement de l'Obesite",
    thesis: "Les médicaments GLP-1 (Ozempic, Wegovy, Mounjaro) représentent potentiellement le plus grand marché pharma de l'histoire, estimé à $150B+ d'ici 2030. Impact au-delà de l'obésité : cardiovasculaire, NASH, Alzheimer.",
    icon: "Pill",
    color: "#E11D48",
    whatToWatch: "Résultats cliniques (cardiovasculaire, NASH), accès et remboursement, concurrence pipeline, effets secondaires long terme",
    themeRisks: "Pression sur les prix, concurrence générique, effets secondaires inconnus, compliance patients",
    items: [
      { name: "Novo Nordisk", ticker: "NVO", sector: "Pharma / GLP-1", marketCapRange: "mega", whyItMatters: "Ozempic, Wegovy, leader mondial GLP-1" },
      { name: "Eli Lilly", ticker: "LLY", sector: "Pharma / GLP-1", marketCapRange: "mega", whyItMatters: "Mounjaro, Zepbound, pipeline GLP-1 next-gen" },
      { name: "Amgen", ticker: "AMGN", sector: "Pharma", marketCapRange: "large", whyItMatters: "MariTide (oral GLP-1), concurrent potentiel" },
      { name: "Viking Therapeutics", ticker: "VKTX", sector: "Biotech", marketCapRange: "mid", whyItMatters: "VK2735, candidat GLP-1 oral prometteur" },
      { name: "Structure Therapeutics", ticker: "GPCR", sector: "Biotech", marketCapRange: "small", whyItMatters: "GSBR-1290, GLP-1 oral small molecule" },
    ]
  },
  {
    slug: "silver-economy",
    title: "Vieillissement & Silver Economy",
    thesis: "D'ici 2050, 2.1 milliards de personnes auront plus de 60 ans. Le vieillissement démographique crée une demande structurelle en santé, assurance, résidences seniors et technologies d'assistance.",
    icon: "Users",
    color: "#6B7280",
    whatToWatch: "Démographie, dépenses Medicare/Medicaid, innovation medtech, politique de retraite",
    themeRisks: "Pression budgétaire sur les systèmes de santé, régulation des prix, cycles politiques",
    items: [
      { name: "UnitedHealth Group", ticker: "UNH", sector: "Assurance santé", marketCapRange: "mega", whyItMatters: "N°1 assurance santé US, Medicare Advantage" },
      { name: "HCA Healthcare", ticker: "HCA", sector: "Hôpitaux", marketCapRange: "large", whyItMatters: "Plus grand opérateur hospitalier privé US" },
      { name: "Medtronic", ticker: "MDT", sector: "Medtech", marketCapRange: "large", whyItMatters: "Dispositifs médicaux pour pathologies liées à l'âge" },
      { name: "Welltower", ticker: "WELL", sector: "REIT santé", marketCapRange: "large", whyItMatters: "REIT spécialisé résidences seniors et établissements de santé" },
      { name: "Intuitive Surgical", ticker: "ISRG", sector: "Chirurgie robotique", marketCapRange: "mega", whyItMatters: "Robot Da Vinci, chirurgie mini-invasive pour patients âgés" },
    ]
  },
  {
    slug: "ecommerce-logistique",
    title: "E-commerce & Logistique",
    thesis: "Le e-commerce mondial continue de croître à ~10% par an. La logistique du dernier kilomètre, l'automatisation des entrepôts et le commerce transfrontalier sont les moteurs de croissance.",
    icon: "ShoppingCart",
    color: "#F97316",
    whatToWatch: "Croissance GMV, marges logistiques, automatisation entrepôts, commerce social, live shopping",
    themeRisks: "Compression des marges, concurrence Amazon/Temu/Shein, coûts logistiques, saturation marchés matures",
    items: [
      { name: "Amazon", ticker: "AMZN", sector: "E-commerce / Cloud", marketCapRange: "mega", whyItMatters: "Dominant e-commerce US, AWS, logistique intégrée" },
      { name: "Shopify", ticker: "SHOP", sector: "E-commerce SaaS", marketCapRange: "large", whyItMatters: "Plateforme e-commerce pour PME, Shopify Fulfillment" },
      { name: "MercadoLibre", ticker: "MELI", sector: "E-commerce LatAm", marketCapRange: "large", whyItMatters: "Amazon d'Amérique latine, fintech Mercado Pago" },
      { name: "XPO Logistics", ticker: "XPO", sector: "Logistique", marketCapRange: "mid", whyItMatters: "Transport LTL, technologie logistique" },
    ]
  },
  {
    slug: "banques-taux",
    title: "Banques & Taux d'Interet",
    thesis: "Les banques profitent de la normalisation des taux d'intérêt après une décennie de taux bas. Les marges nettes d'intérêt s'améliorent, mais le risque crédit et la régulation restent des facteurs clés.",
    icon: "Landmark",
    color: "#1E3A5F",
    whatToWatch: "Politique Fed, courbe des taux, qualité du crédit, régulation Bâle III, résultats trimestriels",
    themeRisks: "Récession et défauts de crédit, crise immobilière commerciale, régulation renforcée, concurrence fintech",
    items: [
      { name: "JPMorgan Chase", ticker: "JPM", sector: "Banque universelle", marketCapRange: "mega", whyItMatters: "Plus grande banque US, diversification exemplaire" },
      { name: "Bank of America", ticker: "BAC", sector: "Banque universelle", marketCapRange: "mega", whyItMatters: "Sensible aux taux, forte base de dépôts" },
      { name: "Goldman Sachs", ticker: "GS", sector: "Banque d'investissement", marketCapRange: "large", whyItMatters: "Leader M&A et trading, gestion d'actifs" },
      { name: "Charles Schwab", ticker: "SCHW", sector: "Courtage", marketCapRange: "large", whyItMatters: "Plus grand courtier US, revenus liés aux taux" },
      { name: "KKR & Co", ticker: "KKR", sector: "Private equity", marketCapRange: "large", whyItMatters: "Alternative assets, bénéficie de la hausse des taux" },
    ]
  },
  {
    slug: "assurance-risk",
    title: "Assurance & Risk Management",
    thesis: "Le secteur de l'assurance bénéficie du 'hard market' (hausse des primes) et de la hausse des taux qui améliore les rendements des portefeuilles d'investissement. Les catastrophes climatiques augmentent la demande.",
    icon: "ShieldCheck",
    color: "#4338CA",
    whatToWatch: "Ratio combiné, primes en hausse, catastrophes naturelles, taux d'intérêt, InsurTech",
    themeRisks: "Catastrophes climatiques extrêmes, régulation des primes, concurrence InsurTech, risques de réserves",
    items: [
      { name: "Berkshire Hathaway", ticker: "BRK-B", sector: "Conglomérat / Assurance", marketCapRange: "mega", whyItMatters: "GEICO, Gen Re, plus grand assureur mondial" },
      { name: "Chubb", ticker: "CB", sector: "Assurance P&C", marketCapRange: "large", whyItMatters: "Leader assurance commerciale et particuliers haut de gamme" },
      { name: "Arch Capital", ticker: "ACGL", sector: "Réassurance", marketCapRange: "large", whyItMatters: "Réassurance et assurance spécialisée, excellente discipline" },
      { name: "Aon", ticker: "AON", sector: "Courtage assurance", marketCapRange: "large", whyItMatters: "N°2 mondial du courtage d'assurance" },
    ]
  },
  {
    slug: "or-valeurs-refuge",
    title: "Or & Valeurs Refuge",
    thesis: "L'or atteint des records historiques, porté par les achats des banques centrales, l'incertitude géopolitique et la dédollarisation. Les minières offrent un levier sur le prix de l'or.",
    icon: "Coins",
    color: "#CA8A04",
    whatToWatch: "Prix de l'or, achats banques centrales, taux réels, dollar index, tensions géopolitiques",
    themeRisks: "Hausse des taux réels, renforcement du dollar, baisse de la demande joaillerie, coûts miniers",
    items: [
      { name: "Newmont", ticker: "NEM", sector: "Mines d'or", marketCapRange: "large", whyItMatters: "Plus grand producteur d'or mondial" },
      { name: "Barrick Gold", ticker: "GOLD", sector: "Mines d'or", marketCapRange: "large", whyItMatters: "N°2 mondial, mines tier-1, exposition cuivre" },
      { name: "Agnico Eagle Mines", ticker: "AEM", sector: "Mines d'or", marketCapRange: "large", whyItMatters: "Mines premium au Canada, Australie, Finlande" },
      { name: "Franco-Nevada", ticker: "FNV", sector: "Royalties or", marketCapRange: "large", whyItMatters: "Modèle royalties/streaming, exposition sans risque minier" },
      { name: "Wheaton Precious Metals", ticker: "WPM", sector: "Streaming métaux", marketCapRange: "large", whyItMatters: "Streaming or et argent, marges élevées" },
    ]
  },
  {
    slug: "agriculture-foodtech",
    title: "Agriculture & Food Tech",
    thesis: "Nourrir 10 milliards d'humains d'ici 2050 nécessite une révolution agricole. Agriculture de précision, protéines alternatives, biotechnologies végétales et chaîne du froid sont les axes de croissance.",
    icon: "Wheat",
    color: "#65A30D",
    whatToWatch: "Prix des commodités agricoles, météo/sécheresses, politique agricole, adoption AgTech",
    themeRisks: "Volatilité des prix agricoles, risques climatiques, régulation OGM, adoption lente des nouvelles technologies",
    items: [
      { name: "Deere & Company", ticker: "DE", sector: "Équipement agricole", marketCapRange: "large", whyItMatters: "Leader mondial tracteurs, agriculture de précision, autonomie" },
      { name: "Corteva Agriscience", ticker: "CTVA", sector: "Semences / Crop protection", marketCapRange: "large", whyItMatters: "Semences et protection des cultures, biotech végétale" },
      { name: "Archer-Daniels-Midland", ticker: "ADM", sector: "Agri-business", marketCapRange: "large", whyItMatters: "Transformation et négoce de matières premières agricoles" },
      { name: "FMC Corporation", ticker: "FMC", sector: "Crop protection", marketCapRange: "mid", whyItMatters: "Solutions de protection des cultures, biologiques" },
      { name: "AppHarvest", ticker: "APPH", sector: "AgTech", marketCapRange: "small", whyItMatters: "Agriculture indoor, serres high-tech, culture durable" },
    ]
  },
  {
    slug: "deglobalisation",
    title: "De-globalisation & Relocalisation",
    thesis: "Le reshoring et le friend-shoring redessinent les chaînes d'approvisionnement mondiales. Les tensions US-Chine, la pandémie et les risques géopolitiques accélèrent la relocalisation industrielle, soutenue par l'IRA et le CHIPS Act.",
    icon: "Factory",
    color: "#78716C",
    whatToWatch: "Tarifs douaniers, CHIPS Act / IRA, investissements usines US, tensions US-Chine, nearshoring Mexique",
    themeRisks: "Coûts de relocalisation élevés, pénurie de main-d'œuvre, inflation, risques politiques",
    items: [
      { name: "Caterpillar", ticker: "CAT", sector: "Équipement industriel", marketCapRange: "mega", whyItMatters: "Indicateur de l'activité industrielle mondiale, construction" },
      { name: "Nucor", ticker: "NUE", sector: "Acier", marketCapRange: "large", whyItMatters: "Plus grand producteur d'acier US, bénéficiaire du reshoring" },
      { name: "Emerson Electric", ticker: "EMR", sector: "Automatisation", marketCapRange: "large", whyItMatters: "Automatisation industrielle, solutions pour usines" },
      { name: "Eaton Corporation", ticker: "ETN", sector: "Électrification", marketCapRange: "large", whyItMatters: "Infrastructure électrique pour nouvelles usines et data centers" },
      { name: "TSMC (ADR)", ticker: "TSM", sector: "Semi-conducteurs", marketCapRange: "mega", whyItMatters: "Fondeur N°1 mondial, usines en construction aux US (Arizona)" },
    ]
  },
];

async function main() {
  const conn = await mysql.createConnection(process.env.DATABASE_URL);
  
  let maxSortOrder = 12; // existing 12 themes
  
  for (const theme of NEW_THEMES) {
    maxSortOrder++;
    
    // Check if slug already exists
    const [existing] = await conn.query('SELECT id FROM thematicWatchlists WHERE slug = ?', [theme.slug]);
    if (existing.length > 0) {
      console.log(`SKIP: ${theme.slug} already exists`);
      continue;
    }
    
    // Insert the theme
    const [result] = await conn.query(
      `INSERT INTO thematicWatchlists (slug, title, thesis, icon, color, whatToWatch, themeRisks, itemCount, sortOrder, isActive, updatedAt, createdAt) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW())`,
      [theme.slug, theme.title, theme.thesis, theme.icon, theme.color, theme.whatToWatch, theme.themeRisks, theme.items.length, maxSortOrder]
    );
    
    const watchlistId = result.insertId;
    console.log(`ADDED: ${theme.slug} (id=${watchlistId})`);
    
    // Insert items
    for (let i = 0; i < theme.items.length; i++) {
      const item = theme.items[i];
      await conn.query(
        `INSERT INTO watchlistItems (watchlistId, name, ticker, sector, marketCapRange, whyItMatters, catalysts, risks, keyDates, sources, sortOrder, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, NULL, NULL, NULL, NULL, ?, NOW())`,
        [watchlistId, item.name, item.ticker, item.sector || '', item.marketCapRange, item.whyItMatters || '', i + 1]
      );
    }
    console.log(`  → ${theme.items.length} items added`);
  }
  
  // Final count
  const [count] = await conn.query('SELECT COUNT(*) as total FROM thematicWatchlists');
  console.log(`\nTotal thematic watchlists: ${count[0].total}`);
  
  await conn.end();
}

main().catch(console.error);
