# WMB — Export Éducatif & Données Complètes

Ce repository contient **l'intégralité du contenu éducatif et des données** qui ont été retirées du site WallStreet Market Brief lors de la Phase 2 (recentrage en média financier premium).

**Rien n'a été perdu.** Tout est ici, organisé et prêt à être réutilisé.

---

## Structure du repository

```
01_PAGES_EDUCATIVES/       → Pages React complètes (Formation, Glossaire, Quiz, Indicateurs, etc.)
02_DATA_EDUCATIVES/        → Fichiers de données TypeScript (1112 termes, 101 indicateurs, 152 figures, etc.)
03_COMPOSANTS_EDUCATIFS/   → Composants React réutilisables (GlossaryConcepts, IndicatorsLibrary)
04_SEEDS_SCRIPTS/          → Scripts de seeding DB (quiz, thèmes, thématiques, leçons)
05_PROMPTS_PROJET/         → Prompts DOCX du projet (Revue US, Suisse, Monde, etc.)
06_SCHEMA_DB/              → Schéma complet de la base de données (Drizzle ORM)
07_SERVER_ROUTERS/         → Routers tRPC éducatifs (academy, globalQuiz, glossaryV3)
08_EMAILS_TEMPLATES/       → Templates email + scripts d'envoi (newsletter, onboarding, etc.)
09_EDITIONS_DATA/          → Données des éditions newsletter (semaines 1 à 20+)
10_SHARED_CONFIG/          → Configuration partagée (siteConfig, wmbModuleSchema, types)
```

---

## Contenu détaillé

### 01_PAGES_EDUCATIVES (17 fichiers)
- `Formation.tsx` — Page principale de l'académie
- `FormationAnalyse.tsx` — Formation analyse technique
- `CourseDetail.tsx` — Détail d'un cours
- `LessonViewer.tsx` — Lecteur de leçon
- `Glossaire.tsx` — Glossaire interactif (1112 termes)
- `GlossairePresentation.tsx` — Page vitrine du glossaire
- `IndicateursPresentation.tsx` — Présentation des indicateurs
- `IndicateursTendance.tsx` — Bibliothèque des indicateurs (101)
- `Apprendre.tsx` — Page "Apprendre"
- `QuizPresentation.tsx` — Présentation du quiz
- `FiguresChartistes.tsx` — Figures chartistes (152)
- `AnalyseTechnique.tsx` — Analyse technique
- `Krachs.tsx` — Historique des krachs (71)
- `Strategies.tsx` — Stratégies de trading
- `StrategyDetail.tsx` — Détail d'une stratégie
- `DashboardGlossaire.tsx` — Glossaire dans le dashboard
- `DashboardIndicateurs.tsx` — Indicateurs dans le dashboard

### 02_DATA_EDUCATIVES (13 fichiers)
- `glossaryConcepts.ts` — 1112 termes financiers avec définitions
- `indicatorCases.ts` — 101 indicateurs techniques et macro
- `chartPatternCases.ts` — 152 figures chartistes avec exemples
- `tradingGuides.ts` — 118 guides de trading
- `tradingGuideCases.ts` — Cas pratiques des guides
- `formationAnalyse.ts` — Contenu de la formation analyse
- `promptsRecherche.ts` — Prompts de recherche
- Et plus...

### 04_SEEDS_SCRIPTS (22 fichiers)
Scripts pour reproduire toutes les données en base :
- `seed-quiz.mjs` — Quiz complet
- `seed-thematiques.mjs` — Thématiques sectorielles
- `seed-themes.mjs` — Thèmes du mois
- `seed-monthly-themes.mjs` — Thèmes mensuels
- Et plus...

### 08_EMAILS_TEMPLATES (24 fichiers)
- Templates d'emails (welcome, onboarding, free theme, admin notify)
- Scripts d'envoi (newsletter, weekly recap, editions, tests)

### 09_EDITIONS_DATA (40 fichiers)
- Données complètes de chaque édition newsletter (semaines 1 à 20+)
- Inclut les modules USA, Actions, Monde, Suisse

---

## Comment réutiliser ce contenu

1. **Réintégrer une page** : Copier le fichier `.tsx` dans `client/src/pages/` et ajouter la route dans `App.tsx`
2. **Réintégrer des données** : Copier le fichier `.ts` dans `client/src/data/`
3. **Reseed la DB** : Exécuter `node seed-*.mjs` avec les variables d'environnement DB configurées
4. **Réutiliser un router** : Copier dans `server/routers/` et l'enregistrer dans `server/routers.ts`

---

## Notes importantes

- Les données en base de données (users, progress, badges) n'ont **PAS** été supprimées — elles sont toujours dans la DB de production
- Les tables DB (courses, lessons, quizQuestions, glossary, etc.) sont toujours présentes dans le schéma
- Seul l'accès frontend a été masqué (redirections vers `/`)
- Aucun abonnement Stripe n'a été modifié

---

## Date d'export

16 juillet 2026 — Phase 2 WMB (recentrage média financier premium)
